_soft = true; _port = true; _nomsg = true
-- $Id: calls.lua,v 1.60 2016/11/07 13:11:28 roberto Exp $
-- See Copyright Notice in file all.lua

print("testing functions and calls")

local debug = require "debug"

-- get the opportunity to test 'type' too ;)

assert(type(1<2) == 'boolean')
assert(type(true) == 'boolean' and type(false) == 'boolean')
assert(type(nil) == 'nil'
   and type(-3) == 'number'
   and type'x' == 'string'
   and type{} == 'table'
   and type(type) == 'function')

assert(type(assert) == type(print))
function f (x) return a:x (x) end
assert(type(f) == 'function')
assert(not pcall(type))


do    -- test error in 'print' too...
  local tostring = _ENV.tostring

  _ENV.tostring = nil
  local st, msg = pcall(print, 1)
  assert(st == false and string.find(msg, "attempt to call a nil value"))

  _ENV.tostring = function () return {} end
  local st, msg = pcall(print, 1)
  assert(st == false and string.find(msg, "must return a string"))
  
  _ENV.tostring = tostring
end
