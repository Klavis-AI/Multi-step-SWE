_soft = true; _port = true; _nomsg = true
-- $Id: pm.lua,v 1.48 2016/11/07 13:11:28 roberto Exp $
-- See Copyright Notice in file all.lua

print('testing pattern matching')

local function checkerror (msg, f, ...)
  local s, err = pcall(f, ...)
  assert(not s and string.find(err, msg))
end


function f(s, p)
  local i,e = string.find(s, p)
  if i then return string.sub(s, i, e) end
end

a,b = string.find('', '')    -- empty patterns are tricky
assert(a == 1 and b == 0);
