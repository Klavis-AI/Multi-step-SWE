_soft = true; _port = true; _nomsg = true
-- $Id: sort.lua,v 1.38 2016/11/07 13:11:28 roberto Exp $
-- See Copyright Notice in file all.lua

print "testing (parts of) table library"

print "testing unpack"

local unpack = table.unpack

local maxI = math.maxinteger
local minI = math.mininteger


local function checkerror (msg, f, ...)
  local s, err = pcall(f, ...)
  assert(not s and string.find(err, msg))
end

