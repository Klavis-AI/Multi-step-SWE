local store = {}
local t = setmetatable({}, {
  __index = function(_, k) return "idx:" .. tostring(k) end,
  __newindex = function(_, k, v) store[k] = v end,
})
print(t.a, t[1])
t.x = 5
print(rawget(t, "x"), store.x)
local base = {b = 2}
local u = setmetatable({}, {__index = base})
print(u.b, tostring(u.c))
