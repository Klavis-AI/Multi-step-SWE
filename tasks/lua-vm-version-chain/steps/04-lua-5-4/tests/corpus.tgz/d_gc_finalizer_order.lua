local order = {}
do
  for i = 1, 3 do
    setmetatable({}, {__gc = function() order[#order + 1] = i end})
  end
end
collectgarbage()
collectgarbage()
print(table.concat(order, ","))
