local f, e = load([[
  local log = {}
  do
    local a <close> = setmetatable({}, {__close = function() log[#log+1] = "a" end})
    local b <close> = setmetatable({}, {__close = function() log[#log+1] = "b" end})
  end
  print(table.concat(log, ","))
  local ok, err = pcall(function()
    local c <close> = setmetatable({}, {__close = function(_, e) print("closed with", e) end})
    error("bang")
  end)
  print(ok, err)
]], "=c")
if f then f() else print("no", e) end
