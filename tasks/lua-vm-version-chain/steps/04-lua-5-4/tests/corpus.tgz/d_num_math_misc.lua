print(math.max(1, 2, 3), math.min(1, 2, 3), math.max(-1), math.min(-1))
print(math.sqrt(4), math.sqrt(2), math.exp(0), math.exp(1))
print(math.pi, math.huge)
print(math.floor(math.deg(math.pi) + 0.5), math.rad(180) == math.pi)
