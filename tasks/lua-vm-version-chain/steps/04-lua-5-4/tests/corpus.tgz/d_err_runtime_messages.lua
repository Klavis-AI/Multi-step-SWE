local cases = {
  "local x; return x.y",
  "local x; x.y = 1",
  "return undefinedglobal.field",
  "local t = {}; return t.a.b",
  "local t = {}; return t:nosuch()",
  "return nil + 1",
  "return {} + 1",
  "return 'a' + 1",
  "return 'a' .. {}",
  "return #nil",
  "return -{}",
  "return {} < {}",
  "return 1 < 'x'",
  "local f; f()",
  "local t = {}; t()",
  "return ('x')()",
  "local a, b, c; return (function() return b + 1 end)()",
}
local L = load
if _VERSION == "Lua 5.1" then L = loadstring end
for i, c in ipairs(cases) do
  local f, e = L(c, "=t")
  if not f then print(i, "SYNTAX", e)
  else local ok, r = pcall(f) print(i, ok, tostring(r)) end
end
