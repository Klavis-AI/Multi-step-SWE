print("before")
os.exit(3)
print("after")
