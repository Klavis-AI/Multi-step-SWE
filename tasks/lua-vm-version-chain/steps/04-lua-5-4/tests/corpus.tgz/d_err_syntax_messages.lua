local cases = {
  "return +", "local = 1", "if x then", "a b", "return 1 +", "for i=1 do end",
  "local function f() return end end", "x = 0x", "x = 1e", "x = [[unfinished",
  "x = 'unfinished", "::a:: ::a::", "goto nowhere", "break", "x = '\\q'",
  "f(", "return return", "local a <b> = 1", "x = 1 // 2", "x = 1 & 2", "x = 3 ~ 4",
  "global x", "x = 1; ;", "print(1)(", "t = {1,2,",
}
local L = load
if _VERSION == "Lua 5.1" then L = loadstring end
for i, c in ipairs(cases) do
  local f, e = L(c, "=t")
  print(i, f ~= nil, tostring(e))
end
