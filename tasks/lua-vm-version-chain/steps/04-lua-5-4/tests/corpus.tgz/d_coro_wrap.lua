local gen = coroutine.wrap(function()
  for i = 1, 3 do coroutine.yield(i) end
end)
print(gen(), gen(), gen())
local bad = coroutine.wrap(function() error("inside") end)
print(pcall(bad))
local w = coroutine.wrap(function() coroutine.yield(1) end)
w()
print(pcall(w))
