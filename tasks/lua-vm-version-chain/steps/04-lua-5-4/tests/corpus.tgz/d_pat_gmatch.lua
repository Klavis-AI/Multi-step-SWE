local out = {}
for w in ("one two three"):gmatch("%a+") do out[#out + 1] = w end
print(table.concat(out, "|"))
out = {}
for k, v in ("a=1,b=2"):gmatch("(%w+)=(%w+)") do out[#out + 1] = k .. v end
print(table.concat(out, "|"))
out = {}
for c in ("abc"):gmatch("") do out[#out + 1] = "." end
print(#out)
