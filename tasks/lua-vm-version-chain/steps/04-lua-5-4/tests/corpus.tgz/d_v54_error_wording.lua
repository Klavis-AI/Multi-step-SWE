local function D(s) local f, m = load(s, "=c") if not f then return m end local ok, e = pcall(f) return (not ok) and e end
print(D("local a = setmetatable({}, {__add = 34}); return a + 1"))
print(D("local a = setmetatable({}, {__lt = {}}); return a < a"))
print(D("local a = setmetatable({}, {__len = 3}); return #a"))
print(D("for k, v in 3 do end"))
print(D("for i = io.stdin, 10 do end"))
print(D("local x = 'x'; return x | 1"))
print(D("return '7' & 3"))
