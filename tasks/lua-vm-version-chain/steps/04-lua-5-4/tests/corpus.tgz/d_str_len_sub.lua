local s = "hello world"
print(#s, s:len(), string.len(s))
print(s:sub(1, 5), s:sub(7), s:sub(-5), s:sub(-5, -2), s:sub(0), s:sub(20), s:sub(3, 2))
print(("abc"):sub(-10, 10), ("abc"):sub(2, -1))
