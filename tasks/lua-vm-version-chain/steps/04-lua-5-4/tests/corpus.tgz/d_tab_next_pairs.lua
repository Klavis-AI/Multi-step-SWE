local t = {10, 20, 30}
local k, v = next(t)
print(k, v)
print(next(t, 3))
print(next({}))
local n = 0
for k, v in pairs(t) do n = n + v end
print(n)
n = 0
for i, v in ipairs(t) do n = n + i * v end
print(n)
print(pcall(next, t, "nokey"))
