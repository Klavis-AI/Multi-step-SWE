local t = {5, 2, 8, 1, 9, 3}
table.sort(t); print(table.concat(t, ","))
table.sort(t, function(a, b) return a > b end); print(table.concat(t, ","))
local s = {"banana", "apple", "cherry"}
table.sort(s); print(table.concat(s, ","))
print(pcall(table.sort, {1, 2, 3}, function() return true end))
print(pcall(table.sort, {1, "x"}))
