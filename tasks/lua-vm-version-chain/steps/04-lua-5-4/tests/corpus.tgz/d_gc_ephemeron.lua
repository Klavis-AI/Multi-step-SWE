local t = setmetatable({}, {__mode = "k"})
do
  local k = {}
  t[k] = {ref = k}          -- value points back at its own key
end
collectgarbage()
local n = 0
for _ in pairs(t) do n = n + 1 end
print("entries", n)
