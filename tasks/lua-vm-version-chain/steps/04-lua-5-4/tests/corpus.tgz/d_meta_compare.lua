local mt1 = {__eq = function() return true end, __lt = function() return true end,
             __le = function() return true end}
local a = setmetatable({}, mt1)
local b = setmetatable({}, mt1)
print(a == b, a < b, a <= b)
local mt2 = {__eq = function() return true end, __lt = function() return true end}
local c = setmetatable({}, mt2)
print(a == c)
print(pcall(function() return a < c end))
print(a == 1, 1 == a)
