print(type(table.create), type(debug.setcstacklimit))
print(pcall(collectgarbage, "param", "pause"))
print(pcall(collectgarbage, "param", "nosuch"))
print(pcall(collectgarbage, "setpause", 100))
print(pcall(string.dump, print))
print(select(2, pcall(function() error() end)))
local mt = {}
local cur = function(...) return select("#", ...) end
for i = 1, 16 do cur = setmetatable({}, {__call = cur}) end
print(pcall(cur))
