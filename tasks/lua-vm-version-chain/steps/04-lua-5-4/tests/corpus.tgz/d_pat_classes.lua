for _, p in ipairs{"%a+", "%d+", "%s+", "%w+", "%p+", "%u+", "%l+", "%x+",
                   "%A+", "%D+", "%S+", "%W+"} do
  print(p, tostring((" ab12,CD "):match(p)))
end
