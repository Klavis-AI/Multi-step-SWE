print("never")
