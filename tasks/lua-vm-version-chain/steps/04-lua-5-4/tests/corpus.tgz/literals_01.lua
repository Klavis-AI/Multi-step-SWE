_soft = true; _port = true; _nomsg = true
-- $Id: testes/literals.lua $
-- See Copyright Notice in file all.lua

print('testing scanner')

local debug = require "debug"


local function dostring (x) return assert(load(x), "")() end

dostring("x \v\f = \t\r 'a\0a' \v\f\f")
assert(x == 'a\0a' and string.len(x) == 3)
_G.x = nil

-- escape sequences
assert('\n\"\'\\' == [[

"'\]])
