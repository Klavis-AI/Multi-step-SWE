for _, s in ipairs{
  "do goto l end ::l::",
  "goto l ; do ::l:: end",
  "for i = 1, 2 do goto c ; ::c:: end",
  "repeat goto c ; ::c:: until true",
  "while true do goto out end ::out::",
  "do ::a:: end ::a::",
} do
  local f, e = load(s, "=c")
  print(f ~= nil, e)
end
