for _, p in ipairs{{7,2},{-7,2},{7,-2},{-7,-2},{6,3},{-6,3}} do
  io.write(p[1], "//", p[2], "=", tostring(p[1] // p[2]), " ")
  io.write(p[1], "%", p[2], "=", tostring(p[1] % p[2]), " ")
end
print()
print(7 / 2, 6 / 3, 2^2, 2^-1)
print(math.type and math.type(7 // 2), math.type and math.type(7 / 2))
print(1 == 1.0, math.type and math.type(1), "1" + 0, math.type and math.type("1" + 0))
