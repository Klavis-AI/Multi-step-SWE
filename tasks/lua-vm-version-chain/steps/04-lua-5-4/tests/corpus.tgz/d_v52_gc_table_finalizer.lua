local order = {}
do
  for i = 1, 3 do
    setmetatable({}, {__gc = function() order[#order + 1] = i end})
  end
end
collectgarbage()
collectgarbage()
table.sort(order)
print(#order, order[1], order[2], order[3])
local t = setmetatable({}, {})
print(pcall(function() getmetatable(t).__gc = function() end; t = nil; collectgarbage() end))
