for _, v in ipairs{1.0, 0.5, 255.5, 0.0} do
  local ok, r = pcall(string.format, "%a", v)
  print(ok, tostring(r))
end
