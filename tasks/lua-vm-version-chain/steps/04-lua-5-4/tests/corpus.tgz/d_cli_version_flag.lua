print("script also ran")
