print("before")
local t = nil
print(t.field)
print("after")
