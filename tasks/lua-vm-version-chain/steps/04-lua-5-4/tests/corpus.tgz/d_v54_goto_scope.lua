for _, s in ipairs{
  "do goto l; local x; ::l:: end",
  "goto l local x ::l::",
  "while true do goto continue; local v = 1; ::continue:: end",
  "break",
  "do break end",
} do
  local f, e = load(s, "=c")
  print(f ~= nil, e)
end
