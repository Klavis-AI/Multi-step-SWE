print(("aaa"):match("a*"), ("aaa"):match("a-b") == nil, ("aaa"):match("a+"))
print(("abc"):match("a?b"), ("bc"):match("a?b"))
print(("<<x>>"):match("<(.-)>"), ("<<x>>"):match("<(.*)>"))
print(("aaa"):gsub("a*", "X"))
