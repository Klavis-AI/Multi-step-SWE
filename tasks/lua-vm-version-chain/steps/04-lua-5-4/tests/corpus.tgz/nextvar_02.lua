_soft = true; _port = true; _nomsg = true
-- $Id: testes/nextvar.lua $
-- See Copyright Notice in file all.lua

print('testing tables, next, and for')

local function checkerror (msg, f, ...)
  local s, err = pcall(f, ...)
  assert(not s and string.find(err, msg))
end


local function check (t, na, nh)
  if not T then return end
  local a, h = T.querytab(t)
  if a ~= na or h ~= nh then
    print(na, nh, a, h)
    assert(nil)
  end
end


local a = {}

-- make sure table has lots of space in hash part
for i=1,100 do a[i.."+"] = true end
for i=1,100 do a[i.."+"] = undef end
-- fill hash part with numeric indices testing size operator
for i=1,100 do
  a[i] = true
  assert(#a == i)
end


do   -- rehash moving elements from array to hash
  local a = {}
  for i = 1, 100 do a[i] = i end
  check(a, 128, 0)

  for i = 5, 95 do a[i] = nil end
  check(a, 128, 0)

  a.x = 1     -- force a re-hash
  check(a, 4, 8)

  for i = 1, 4 do assert(a[i] == i) end
  for i = 5, 95 do assert(a[i] == nil) end
  for i = 96, 100 do assert(a[i] == i) end
  assert(a.x == 1)
end
