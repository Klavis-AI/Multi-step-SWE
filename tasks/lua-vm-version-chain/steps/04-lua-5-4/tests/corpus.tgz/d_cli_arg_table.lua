print(arg[0] ~= nil, arg[1], arg[2], arg[-1] ~= nil)
print(select("#", ...), ...)
