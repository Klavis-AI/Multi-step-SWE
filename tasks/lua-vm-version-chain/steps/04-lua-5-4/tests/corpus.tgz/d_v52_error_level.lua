local function lvl0() error("m", 0) end
local function lvl1() error("m", 1) end
local function lvl2() error("m", 2) end
for _, f in ipairs{lvl0, lvl1, lvl2} do
  local ok, e = pcall(f)
  print(ok, (tostring(e):gsub("^.-:%d+:", "<pos>:")))
end
print(select(2, pcall(error, setmetatable({}, {__tostring = function () return "OBJ" end}))))
