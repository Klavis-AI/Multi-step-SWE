print(1 < 2, 2 < 1, 1 <= 1, 1 == 1.0, "a" < "b", "A" < "a", "" < "a")
print(pcall(function() return 1 < "2" end))
print(pcall(function() return {} < {} end))
print(0/0 == 0/0, 0/0 < 1, 1 < 0/0, 0/0 <= 0/0)
