local ok, e = load("local function f(... n) return n.n, n[1], n[2] end return f(7,8)", "=c")
if ok then print(pcall(ok)) else print("no", e) end
local ok2, e2 = load("local function g(a, ... b) return a, b.n end return g(1,2,3)", "=c")
if ok2 then print(pcall(ok2)) else print("no", e2) end
