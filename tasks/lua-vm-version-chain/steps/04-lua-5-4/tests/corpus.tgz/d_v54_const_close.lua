local src = {
  "local x <const> = 1 return x",
  "local x <const> = 1 x = 2",
  "local x <close> = nil return 1",
  "local x <close> = 5",
  "local x <blah> = 1",
}
for _, s in ipairs(src) do
  local f, e = load(s, "=c")
  if f then print("ok", pcall(f)) else print("no", e) end
end
