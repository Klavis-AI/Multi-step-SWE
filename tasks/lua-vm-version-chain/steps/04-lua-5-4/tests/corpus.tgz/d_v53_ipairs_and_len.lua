local t = setmetatable({}, {__index = function (_, i) if i < 4 then return i * 11 end end,
                            __len = function () return 7 end})
local n = 0
for i, v in ipairs(t) do n = n + 1; io.write(i, "=", v, " ") end
print("count", n, "len", #t, "rawlen", rawlen(t))
print(select("#", table.unpack({1, 2, 3})), table.concat({1, 2, 3}, "-"))
