_soft = true; _port = true; _nomsg = true
-- $Id: testes/nextvar.lua $
-- See Copyright Notice in file all.lua

print('testing tables, next, and for')

local function checkerror (msg, f, ...)
  local s, err = pcall(f, ...)
  assert(not s and string.find(err, msg))
end


local function check (t, na, nh)
  if not T then return end
  local a, h = T.querytab(t)
  if a ~= na or h ~= nh then
    print(na, nh, a, h)
    assert(nil)
  end
end


local a = {}

-- make sure table has lots of space in hash part
for i=1,100 do a[i.."+"] = true end
for i=1,100 do a[i.."+"] = undef end
-- fill hash part with numeric indices testing size operator
for i=1,100 do
  a[i] = true
  assert(#a == i)
end


do   -- rehash moving elements from array to hash
  local a = {}
  for i = 1, 100 do a[i] = i end
  check(a, 128, 0)

  for i = 5, 95 do a[i] = nil end
  check(a, 128, 0)

  a.x = 1     -- force a re-hash
  check(a, 4, 8)

  for i = 1, 4 do assert(a[i] == i) end
  for i = 5, 95 do assert(a[i] == nil) end
  for i = 96, 100 do assert(a[i] == i) end
  assert(a.x == 1)
end


-- testing ipairs
local x = 0
for k,v in ipairs{10,20,30;x=12} do
  x = x + 1
  assert(k == x and v == x * 10)
end

for _ in ipairs{x=12, y=24} do assert(nil) end

-- test for 'false' x ipair
x = false
local i = 0
for k,v in ipairs{true,false,true,false} do
  i = i + 1
  x = not x
  assert(x == v)
end
assert(i == 4)

-- iterator function is always the same
assert(type(ipairs{}) == 'function' and ipairs{} == ipairs{})


do   -- overflow (must wrap-around)
  local f = ipairs{}
  local k, v = f({[math.mininteger] = 10}, math.maxinteger)
  assert(k == math.mininteger and v == 10)
  k, v = f({[math.mininteger] = 10}, k)
  assert(k == nil)
end

if not T then
  (Message or print)
    ('\n >>> testC not active: skipping tests for table sizes <<<\n')
else --[
-- testing table sizes


local function mp2 (n)   -- minimum power of 2 >= n
  local mp = 2^math.ceil(math.log(n, 2))
  assert(n == 0 or (mp/2 < n and n <= mp))
  return mp
end


-- testing C library sizes
do
  local s = 0
  for _ in pairs(math) do s = s + 1 end
  check(math, 0, mp2(s))
end


-- testing constructor sizes
local sizes = {0, 1, 2, 3, 4, 5, 7, 8, 9, 15, 16, 17,
  30, 31, 32, 33, 34, 254, 255, 256, 500, 1000}

for _, sa in ipairs(sizes) do    -- 'sa' is size of the array part
  local arr = {"return {"}
  for i = 1, sa do arr[1 + i] = "1," end    -- build array part
  for _, sh in ipairs(sizes) do    -- 'sh' is size of the hash part
    for j = 1, sh do   -- build hash part
      arr[1 + sa + j] = string.format('k%x=%d,', j, j)
    end
    arr[1 + sa + sh + 1] = "}"
    local prog = table.concat(arr)
    local f = assert(load(prog))
    collectgarbage("stop")
    f()    -- call once to ensure stack space
    -- make sure table is not resized after being created
    if sa == 0 or sh == 0 then
      T.alloccount(2);  -- header + array or hash part
    else
      T.alloccount(3);  -- header + array part + hash part
    end
    local t = f()
    T.alloccount();
    collectgarbage("restart")
    assert(#t == sa)
    check(t, sa, mp2(sh))
  end
end


-- tests with unknown number of elements
local a = {}
for i=1,sizes[#sizes] do a[i] = i end   -- build auxiliary table
for k in ipairs(sizes) do
  local t = {table.unpack(a,1,k)}
  assert(#t == k)
  check(t, k, 0)
  t = {1,2,3,table.unpack(a,1,k)}
  check(t, k+3, 0)
  assert(#t == k + 3)
end


-- testing tables dynamically built
local lim = 130
local a = {}; a[2] = 1; check(a, 0, 1)
a = {}; a[0] = 1; check(a, 0, 1); a[2] = 1; check(a, 0, 2)
a = {}; a[0] = 1; a[1] = 1; check(a, 1, 1)
a = {}
for i = 1,lim do
  a[i] = 1
  assert(#a == i)
  check(a, mp2(i), 0)
end

a = {}
for i = 1,lim do
  a['a'..i] = 1
  assert(#a == 0)
  check(a, 0, mp2(i))
end

a = {}
for i=1,16 do a[i] = i end
check(a, 16, 0)
do
  for i=1,11 do a[i] = undef end
  for i=30,50 do a[i] = true; a[i] = undef end   -- force a rehash (?)
  check(a, 0, 8)   -- 5 elements in the table
  a[10] = 1
  for i=30,50 do a[i] = true; a[i] = undef end   -- force a rehash (?)
  check(a, 0, 8)   -- only 6 elements in the table
  for i=1,14 do a[i] = true; a[i] = undef end
  for i=18,50 do a[i] = true; a[i] = undef end   -- force a rehash (?)
  check(a, 0, 4)   -- only 2 elements ([15] and [16])
end

-- reverse filling
for i=1,lim do
  local a = {}
  for i=i,1,-1 do a[i] = i end   -- fill in reverse
  check(a, mp2(i), 0)
end

-- size tests for vararg
lim = 35
local function foo (n, ...)
  local arg = {...}
  check(arg, n, 0)
  assert(select('#', ...) == n)
  arg[n+1] = true
  check(arg, mp2(n+1), 0)
  arg.x = true
  check(arg, mp2(n+1), 1)
end
local a = {}
for i=1,lim do a[i] = true; foo(i, table.unpack(a)) end


-- Table length with limit smaller than maximum value at array
local a = {}
for i = 1,64 do a[i] = true end    -- make its array size 64
for i = 1,64 do a[i] = nil end     -- erase all elements
assert(T.querytab(a) == 64)    -- array part has 64 elements
a[32] = true; a[48] = true;    -- binary search will find these ones
a[51] = true                   -- binary search will miss this one
assert(#a == 48)               -- this will set the limit
assert(select(4, T.querytab(a)) == 48)  -- this is the limit now
a[50] = true                   -- this will set a new limit
assert(select(4, T.querytab(a)) == 50)  -- this is the limit now
-- but the size is larger (and still inside the array part)
assert(#a == 51)

end  --]
