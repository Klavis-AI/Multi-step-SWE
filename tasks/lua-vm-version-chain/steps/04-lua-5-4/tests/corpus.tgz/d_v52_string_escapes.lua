print(#"\x41\x42", "\x41\x42")
print(("a\z
      b"))
print(pcall(load, "return '\\x'"))
print(string.rep("ab", 3, "-"))
print(("%q"):format("a\nb\0c"))
print(("%q"):format(1/3))
