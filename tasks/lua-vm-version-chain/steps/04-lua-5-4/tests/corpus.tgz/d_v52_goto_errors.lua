local cases = {
  "goto nowhere",
  "::a:: ::a::",
  "goto l local x ::l:: print(x)",
  "do ::l:: end goto l",
  "for i=1,2 do goto out end ::out::",
  "while true do goto done end ::done::",
}
for _, s in ipairs(cases) do
  local f, e = load(s, "=c")
  print(f ~= nil, e)
end
