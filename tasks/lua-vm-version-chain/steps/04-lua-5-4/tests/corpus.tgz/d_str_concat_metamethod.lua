local mt = {__concat = function(a, b) return "CAT" end}
local t = setmetatable({}, mt)
print(t .. "x", "x" .. t)
print(pcall(function() return {} .. "x" end))
print(1 .. 2, "a" .. 1 .. 2)
