if not string.pack then print("no string.pack") return end
print((string.pack("i4", 7)):byte(1, -1))
print(string.unpack("i4", string.pack("i4", -2)))
print(string.packsize("i4i8"))
print((string.pack(">I2", 258)):byte(1, -1))
print(string.unpack("<i2", "\1\2"))
print(pcall(string.pack, "i17", 1))
print((string.pack("s1", "hey")):byte(1, -1))
