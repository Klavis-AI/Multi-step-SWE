for _, s in ipairs{
  "global x  x = 1  return x",
  "global x  y = 1",
  "do global y; y = 1; X = 1 end",
  "global function f() return 7 end return f()",
  "global * ; zz = 1 return zz",
  "global x <const> = 1 x = 2",
  "global x <close> = nil",
  "local global = 1 return global",
  "global = 5 return global",
  "do global a, b = 1, 2; return a + b end",
} do
  local f, e = load(s, "=c")
  if f then print("ok", pcall(f)) else print("no", e) end
end
