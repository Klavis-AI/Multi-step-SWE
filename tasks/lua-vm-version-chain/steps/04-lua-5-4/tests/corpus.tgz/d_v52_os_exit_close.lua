print(type(os.exit))
local t = os.time{year = 2000, month = 1, day = 1, hour = 12}
print(type(t))
print(os.date("!%Y-%m-%d %H:%M:%S", 0))
print(os.difftime(100, 40))
