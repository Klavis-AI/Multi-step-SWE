local t = setmetatable({}, {__mode = "k"})
local keep = {}
t[keep] = 1
do local tmp = {} t[tmp] = 2 end
collectgarbage()
local n = 0
for k, v in pairs(t) do n = n + 1 end
print(n, t[keep])
