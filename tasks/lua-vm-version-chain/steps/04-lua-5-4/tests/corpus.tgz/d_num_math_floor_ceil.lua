for _, v in ipairs{0.5, -0.5, 1.5, -1.5, 2.5, -2.5, 0, 3, -3} do
  print(v, math.floor(v), math.ceil(v), math.abs(v))
end
