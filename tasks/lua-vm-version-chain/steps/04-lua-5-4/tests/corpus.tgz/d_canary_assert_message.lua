print("before")
assert(1 == 2, "one is not two")
print("after")
