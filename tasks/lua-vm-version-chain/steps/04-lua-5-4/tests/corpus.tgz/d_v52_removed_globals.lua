for _, n in ipairs{"setfenv", "getfenv", "loadstring", "unpack", "module"} do
  print(n, type(_G[n]))
end
for _, n in ipairs{"maxn", "unpack", "pack", "move"} do print("table."..n, type(table[n])) end
for _, n in ipairs{"log10", "mod", "pow", "atan2", "cosh", "frexp", "ldexp"} do
  print("math."..n, type(math[n]))
end
print("package.loaders", type(package.loaders), "package.searchers", type(package.searchers))
print("rawlen", type(rawlen), "bit32", type(bit32))
