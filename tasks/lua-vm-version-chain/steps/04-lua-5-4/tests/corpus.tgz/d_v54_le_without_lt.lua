local mt = {__lt = function(a, b) return a.v < b.v end}
local a, b = setmetatable({v=1}, mt), setmetatable({v=2}, mt)
print(pcall(function() return a < b end))
print(pcall(function() return a <= b end))
