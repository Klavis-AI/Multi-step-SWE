local log = {}
local function C(n, err)
  return setmetatable({}, {__close = function (_, e)
    log[#log + 1] = n .. ":" .. tostring(e)
    if err then error(err) end
  end})
end
local f, e = load([[
  local a <close> = ...
  local b <close> = ...
]], "=c")
print(f ~= nil, e)
local ok, msg = pcall(function ()
  local a <close> = C("a")
  local b <close> = C("b")
end)
print(ok, msg, table.concat(log, ","))
log = {}
local ok2, msg2 = pcall(function ()
  local a <close> = C("a")
  local b <close> = C("b", "boom")
end)
print(ok2, tostring(msg2):gsub("^.-:%d+:", "<pos>:"), table.concat(log, ","))
