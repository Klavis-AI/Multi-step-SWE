print("script", type(package.loaded.mymod))
