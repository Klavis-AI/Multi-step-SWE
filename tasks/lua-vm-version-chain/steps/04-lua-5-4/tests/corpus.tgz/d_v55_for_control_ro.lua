for _, s in ipairs{
  "for i = 1, 3 do i = i + 1 end",
  "for k, v in pairs({}) do k = 1 end",
  "for i = 1, 3 do local i = i + 1 end return 1",
} do
  local f, e = load(s, "=c")
  print(f ~= nil, e)
end
