local t = setmetatable({}, {
  __pairs = function(t) local i = 0
    return function() i = i + 1; if i <= 3 then return i, i * i end end, t, nil end,
  __len = function() return 99 end,
})
for k, v in pairs(t) do print("pairs", k, v) end
print("len", #t, rawlen(t))
local u = setmetatable({}, {__index = function(_, k) return k * 2 end})
print(pcall(function() return #u end))
