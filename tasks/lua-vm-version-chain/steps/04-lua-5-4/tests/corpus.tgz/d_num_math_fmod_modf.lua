print(math.fmod(7, 3), math.fmod(-7, 3), math.fmod(7, -3), math.fmod(-7, -3))
print(math.modf(3.7))
print(math.modf(-3.7))
print(math.modf(5))
