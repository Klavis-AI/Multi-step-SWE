io.write("partial\n")
error("fatal error here")
