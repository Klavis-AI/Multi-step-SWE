local function t(e) local ok, v = pcall(load("return " .. e, "=c")) print(e, ok, v) end
t("1 << 3") t("1 << 63") t("1 << 64") t("-1 >> 1") t("~5") t("5 & 3") t("5 | 3") t("5 ~ 3")
t("3.0 & 1") t("'3' & 1")
