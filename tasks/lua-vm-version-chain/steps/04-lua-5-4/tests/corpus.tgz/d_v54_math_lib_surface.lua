for _, n in ipairs{"pow", "atan2", "cosh", "sinh", "tanh", "frexp", "ldexp", "log10",
                   "ult", "tointeger", "type", "maxinteger", "mininteger"} do
  io.write(n, "=", type(math[n]), " ")
end
print()
print(math.ult and math.ult(1, 2), math.ult and math.ult(-1, 2))
print(pcall(math.random, 1, 2, 3))
print(math.type and math.type(math.abs(math.mininteger or -1)))
