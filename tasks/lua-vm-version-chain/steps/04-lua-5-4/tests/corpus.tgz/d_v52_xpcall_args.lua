print(xpcall(function(a, b) return a + b end, function(e) return "H:" .. tostring(e) end, 3, 4))
print(xpcall(function(a) error("boom " .. a) end, function(e) return "H:" .. tostring(e) end, 9))
print(select("#", xpcall(function() return 1, 2, 3 end, print)))
