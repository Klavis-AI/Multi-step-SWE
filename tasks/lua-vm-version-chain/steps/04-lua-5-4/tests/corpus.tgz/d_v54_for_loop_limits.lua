local maxi = math.maxinteger or 2^53
local n = 0
for i = maxi - 2, maxi do n = n + 1; if n > 4 then break end end
print("up", n)
local m = 0
local mini = math.mininteger or -2^53
for i = mini + 2, mini, -1 do m = m + 1; if m > 4 then break end end
print("down", m)
print(pcall(function () for i = 1, 10, 0 do end end))
for i = 1.0, 3.0 do io.write(i, " ") end print()
for i = 1, 3.5 do io.write(i, " ") end print()
