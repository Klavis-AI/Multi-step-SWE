local f = function (...) return select("#", ...) end
local cur = f
for i = 1, 14 do cur = setmetatable({}, {__call = cur}) end
print(pcall(cur))
cur = setmetatable({}, {__call = cur})
print(pcall(cur))
print(select(2, pcall(error)))
print(select(2, pcall(function () error() end)))
print(select(2, pcall(string.dump, print)))
print(select(2, load("break", "=c")))
