local x = 1
do local x = 2 print(x) end
print(x)
if true then local x = 3 print(x) end
print(x)
for x = 10, 10 do print(x) end
print(x)
local a, b = 1
print(a, b)
local c, d = 1, 2, 3
print(c, d)
