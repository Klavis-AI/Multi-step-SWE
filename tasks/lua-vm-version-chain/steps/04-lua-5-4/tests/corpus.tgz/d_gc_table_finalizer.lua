local log = {}
do
  local t = setmetatable({}, {__gc = function() log[#log + 1] = "collected" end})
end
collectgarbage()
collectgarbage()
print(#log)
