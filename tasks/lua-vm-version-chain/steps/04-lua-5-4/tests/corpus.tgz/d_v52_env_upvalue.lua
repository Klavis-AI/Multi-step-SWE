local function f() return x end
print(pcall(f))
local g = load("return x", "=g", "t", {x = 42})
print(pcall(g))
do
  local _ENV = {print = print, y = 7}
  print(y, type(_ENV))
end
print(rawequal(_ENV, _G))
local function h()
  local _ENV = setmetatable({}, {__index = _G})
  z = 5
  return z, rawget(_G, "z")
end
print(pcall(h))
