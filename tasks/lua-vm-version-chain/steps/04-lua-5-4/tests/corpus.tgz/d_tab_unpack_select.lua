local u = table.unpack or unpack
print(u{1, 2, 3})
print(u({1, 2, 3}, 2))
print(u({1, 2, 3}, 2, 3))
print(select("#", 1, 2, 3), select(2, "a", "b", "c"), select(-1, "a", "b", "c"))
print(pcall(select, 0, "a"))
print(select("#"))
