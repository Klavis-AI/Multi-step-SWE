for i = 1, 3 do io.write(i, " ") end print()
for i = 1.0, 3.0 do io.write(i, " ") end print()
for i = 1, 2, 0.5 do io.write(i, " ") end print()
print(pcall(function() for i = 1, 10, 0 do end end))
local n = 0
-- 5.3 wraps round here and never stops, so the count is bounded.
for i = math.maxinteger - 2, math.maxinteger do n = n + 1 if n > 4 then break end end
print("near maxinteger", n)
