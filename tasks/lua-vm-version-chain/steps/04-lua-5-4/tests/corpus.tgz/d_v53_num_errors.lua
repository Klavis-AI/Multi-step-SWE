local function E(f, ...) local ok, e = pcall(f, ...) print(ok, e) end
E(function() return 1 // 0 end)
E(function() return 1 % 0 end)
E(function() return 1.0 // 0 end)
E(function() return ("x"):rep(2, 3) end)
E(function() return math.type(math.random(0)) end)
E(function() return ("abc"):sub("x") end)
E(string.char, 300)
E(function() return 2^63 | 0 end)
