if not utf8 then print("no utf8") return end
print(utf8.char(72, 228, 8364, 66376))
print(utf8.len("h\u{e4}llo"))
for p, c in utf8.codes("a\u{20AC}b") do io.write(p, "=", c, " ") end
print()
print(utf8.codepoint("\u{20AC}", 1))
print(utf8.offset("a\u{20AC}b", 3))
print(utf8.charpattern)
