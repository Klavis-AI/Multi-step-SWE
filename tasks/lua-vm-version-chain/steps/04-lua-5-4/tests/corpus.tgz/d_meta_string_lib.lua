print(("x"):upper(), getmetatable("").__index == string)
local old = getmetatable("").__index
print(type(old))
print(type(("abc").len))
print(pcall(function() local s = "x" return s.nofield.x end))
