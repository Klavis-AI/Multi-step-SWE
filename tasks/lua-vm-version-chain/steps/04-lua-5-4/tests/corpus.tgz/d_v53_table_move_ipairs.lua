local a = {1,2,3,4,5}
print(table.concat(table.move(a, 2, 4, 1, {}), ","))
print(table.concat(table.move(a, 1, 5, 2), ","))
local t = setmetatable({}, {__index = function(_, k) if k < 4 then return k * 10 end end,
                            __ipairs = function() error("never") end})
local n = 0
for i, v in ipairs(t) do n = n + 1; print(i, v) end
print("ipairs count", n)
