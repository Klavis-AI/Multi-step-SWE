if not bit32 then print("no bit32") return end
print(bit32.band(0xF0F0, 0x0FF0), bit32.bor(1, 2, 4), bit32.bxor(0xFF, 0x0F))
print(bit32.bnot(0), bit32.lshift(1, 31), bit32.rshift(-1, 28), bit32.arshift(-16, 2))
print(bit32.extract(0xDEADBEEF, 4, 8), bit32.replace(0, 7, 0, 4))
print(bit32.lrotate(0x12345678, 8), bit32.rrotate(0x12345678, 8))
print(pcall(bit32.extract, 0, 40))
