do
  local i = 1
  ::top::
  if i <= 3 then print("i", i); i = i + 1; goto top end
end
for i = 1, 3 do
  for j = 1, 3 do
    if j == 2 then goto continue end
    print(i, j)
    ::continue::
  end
end
