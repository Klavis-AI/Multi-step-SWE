for _, s in ipairs{
  "for i = 1, 3 do i = 0 end",
  "for k, v in pairs({}) do v = 0 end",
  "for i = 1, 3 do local j = i end return 1",
  "local t = {} for i = 1, 3 do t[i] = i end return #t",
} do
  local f, e = load(s, "=c")
  if f then print("ok", pcall(f)) else print("no", e) end
end
