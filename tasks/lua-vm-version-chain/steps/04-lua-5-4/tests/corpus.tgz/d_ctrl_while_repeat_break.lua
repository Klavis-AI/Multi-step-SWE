local i = 0
while i < 5 do i = i + 1 end
print(i)
repeat i = i - 1 until i == 0
print(i)
for j = 1, 10 do if j == 3 then break end i = j end
print(i)
local n = 0
repeat local x = n; n = n + 1 until x >= 3
print(n)
