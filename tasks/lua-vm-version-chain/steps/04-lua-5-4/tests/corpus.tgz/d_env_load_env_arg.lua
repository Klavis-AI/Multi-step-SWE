local L = load
if _VERSION == "Lua 5.1" then L = loadstring end
local ok, f = pcall(load, "return a", "=t", "t", {a = 5})
if ok and type(f) == "function" then print(f()) else print("no env arg") end
local g = L("return _ENV ~= nil")
local ok2, r = pcall(g)
print(ok2, tostring(r))
