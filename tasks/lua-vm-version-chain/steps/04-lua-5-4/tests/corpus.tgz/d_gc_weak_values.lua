local t = setmetatable({}, {__mode = "v"})
local keep = {}
t[1] = keep
t[2] = {}
t.s = "string values are not removed"
collectgarbage()
print(t[1] == keep, t[2] == nil, t.s ~= nil)
