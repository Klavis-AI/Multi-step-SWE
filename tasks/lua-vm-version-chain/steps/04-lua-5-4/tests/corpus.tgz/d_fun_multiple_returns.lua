local function f() return 1, 2, 3 end
print(f())
print((f()))
local a, b = f()
print(a, b)
print(f(), 10)
local t = {f()}
print(#t)
local t2 = {f(), f()}
print(#t2)
