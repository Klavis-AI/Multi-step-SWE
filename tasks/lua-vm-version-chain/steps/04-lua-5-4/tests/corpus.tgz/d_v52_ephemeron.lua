local e = setmetatable({}, {__mode = "k"})
do
  local k = {}
  e[k] = {k}
  k = nil
end
collectgarbage()
local n = 0
for _ in pairs(e) do n = n + 1 end
print("ephemeron entries", n)
local strong = {}
local e2 = setmetatable({}, {__mode = "k"})
do local k = {}; strong[1] = k; e2[k] = "kept" end
collectgarbage()
local m = 0
for _, v in pairs(e2) do m = m + 1; print(v) end
print("kept", m)
