local L = load
if _VERSION == "Lua 5.1" then L = loadstring end
local f, e = L("do local i = 1 ::top:: i = i + 1 if i < 4 then goto top end return i end")
if f then print(f()) else print("SYNTAX: " .. tostring(e)) end
local g, e2 = L("for i = 1, 3 do if i == 2 then goto continue end ::continue:: end return 'ok'")
print(g and g() or ("SYNTAX: " .. tostring(e2)))
