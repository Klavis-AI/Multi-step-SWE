print(#{}, #{1, 2, 3}, #{1, nil}, #{[1] = 1, [2] = 2})
local t = {}
for i = 1, 10 do t[i] = i end
print(#t)
t[10] = nil
print(#t)
print(#"", #"abc")
