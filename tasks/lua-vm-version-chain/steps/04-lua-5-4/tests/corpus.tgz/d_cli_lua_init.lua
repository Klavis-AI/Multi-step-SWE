print("script body")
