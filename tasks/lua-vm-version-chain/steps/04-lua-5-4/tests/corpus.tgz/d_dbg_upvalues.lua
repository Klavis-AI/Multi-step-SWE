local a, b = 1, 2
local function f() return a + b end
print(debug.getupvalue(f, 1))
print(debug.getupvalue(f, 2))
print(tostring(debug.getupvalue(f, 3)))
print(debug.setupvalue(f, 1, 10), f())
print(type(debug.getregistry()))
