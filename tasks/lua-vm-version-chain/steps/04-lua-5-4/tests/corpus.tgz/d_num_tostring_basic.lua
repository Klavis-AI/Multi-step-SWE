for _, v in ipairs{0, 1, -1, 10, 100, 1e6, 1e7, 1e14, 1e15, 1e16, 0.5, 1.5, -0.5} do
  print(v, tostring(v), type(v))
end
