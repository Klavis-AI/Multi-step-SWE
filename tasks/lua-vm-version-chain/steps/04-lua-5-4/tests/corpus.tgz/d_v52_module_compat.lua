print(type(module), type(package.seeall), type(setfenv), type(getfenv))
print(type(unpack), type(loadstring), type(table.maxn), type(math.log10))
print(type(package.searchers), type(package.searchpath), type(package.loaders))
print(type(rawlen), type(table.pack), type(table.unpack), type(select))
if package.searchpath then print(package.searchpath("no.such.mod", "./?.lua")) end
