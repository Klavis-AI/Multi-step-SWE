print("before")
assert(false)
print("after")
