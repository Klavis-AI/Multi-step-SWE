print("10" + 1, "10" * "2", "0x10" + 0, " 3 " + 1)
print(pcall(function() return "a" + 1 end))
print(pcall(function() return {} + 1 end))
print(10 .. 20, 1.5 .. "", (2^31) .. "")
