local function fact(n) if n <= 1 then return 1 end return n * fact(n - 1) end
print(fact(10))
local function loop(n) if n == 0 then return "done" end return loop(n - 1) end
print(loop(100000))
local function mutual_a(n) if n == 0 then return "a" end return mutual_b(n - 1) end
function mutual_b(n) if n == 0 then return "b" end return mutual_a(n - 1) end
print(mutual_a(99999))
