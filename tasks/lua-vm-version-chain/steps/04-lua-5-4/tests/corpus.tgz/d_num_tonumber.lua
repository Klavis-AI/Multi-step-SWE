for _, s in ipairs{"10", "  10  ", "0x10", "0xA", "1e2", ".5", "5.", "-10", "+10",
                   "10a", "", " ", "0x", "1e", "--1", "0b101", "3.0", "1e999"} do
  print(string.format("%-10s", s), tostring(tonumber(s)))
end
