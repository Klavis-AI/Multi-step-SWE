print(1/0, -1/0, tostring(0/0), tostring(-(0/0)))
print(math.huge, -math.huge, 1e308, 1e309)
