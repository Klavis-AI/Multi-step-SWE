local cases = {
  function() return string.rep() end,
  function() return string.sub() end,
  function() return table.insert(nil, 1) end,
  function() return table.concat({{}}) end,
  function() return math.floor("x") end,
  function() return math.max() end,
  function() return setmetatable(1, {}) end,
  function() return setmetatable({}, 3) end,
  function() return ("x"):rep("a") end,
  function() return select("x", 1) end,
  function() return tostring() end,
  function() return ("abc"):sub({}) end,
}
for i, f in ipairs(cases) do
  local ok, e = pcall(f)
  print(i, ok, tostring(e))
end
