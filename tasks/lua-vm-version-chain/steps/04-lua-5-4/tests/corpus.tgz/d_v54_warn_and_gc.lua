print(type(warn))
if warn then warn("@on") warn("hello ", "world") warn("@off") warn("hidden") end
print(collectgarbage("count") > 0)
for _, o in ipairs{"collect", "step", "isrunning", "incremental", "generational"} do
  print(o, pcall(collectgarbage, o))
end
