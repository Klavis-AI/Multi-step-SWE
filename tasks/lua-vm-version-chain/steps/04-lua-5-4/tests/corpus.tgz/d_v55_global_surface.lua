local ld, ts = load, tostring
for _, s in ipairs{
  "global x  return x",
  "global x = 1  return x",
  "global f, g = 1, 2  return f + g",
  "global function h() return 5 end  return h()",
  "global *  return 1",
  "global <const> *  Y = 1",
  "do global k; k = 3 end  return k",
  "global m  m = 1  return m",
} do
  local f, e = ld(s, "=c")
  if f then local ok, r = pcall(f) print("ok", ok, r) else print("no", e) end
end
