_soft = true; _port = true; _nomsg = true
-- $Id: testes/locals.lua $
-- See Copyright Notice in file lua.h

global <const> *

print('testing local variables and environments')

local debug = require"debug"

local tracegc = require"tracegc"


-- bug in 5.1:

local function f(x) x = nil; return x end
assert(f(10) == nil)

local function f() local x; return x end
assert(f(10) == nil)

local function f(x) x = nil; local y; return x, y end
assert(f(10) == nil and select(2, f(20)) == nil)

do
  local i = 10
  do local i = 100; assert(i==100) end
  do local i = 1000; assert(i==1000) end
  assert(i == 10)
  if i ~= 10 then
    local i = 20
  else
    local i = 30
    assert(i == 30)
  end
end

