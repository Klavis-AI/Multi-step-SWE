_soft = true; _port = true; _nomsg = true
-- $Id: testes/closure.lua $
-- See Copyright Notice in file lua.h

global <const> *

print "testing closures"

do  -- bug in 5.4.7
  _ENV[true] = 10
  local function aux () return _ENV[1 < 2] end
  assert(aux() == 10)
  _ENV[true] = nil
end


local A,B = 0,{g=10}
local function f(x)
  local a = {}
  for i=1,1000 do
    local y = 0
    do
      a[i] = function () B.g = B.g+1; y = y+x; return y+A end
    end
  end
  local dummy = function () return a[A] end
  collectgarbage()
  A = 1; assert(dummy() == a[1]); A = 0;
  assert(a[1]() == x)
  assert(a[3]() == x)
  collectgarbage()
  assert(B.g == 12)
  return a
end
