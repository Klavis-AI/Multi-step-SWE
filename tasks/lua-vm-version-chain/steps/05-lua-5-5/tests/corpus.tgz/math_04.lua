_soft = true; _port = true; _nomsg = true
-- $Id: testes/math.lua $
-- See Copyright Notice in file lua.h

print("testing numbers and math lib")

local math = require "math"
local string = require "string"

global none

global<const> print, assert, pcall, type, pairs, load
global<const> tonumber, tostring, select

local<const> minint, maxint = math.mininteger, math.maxinteger

local intbits <const> = math.floor(math.log(maxint, 2) + 0.5) + 1
assert((1 << intbits) == 0)

assert(minint == 1 << (intbits - 1))
assert(maxint == minint - 1)

-- number of bits in the mantissa of a floating-point number
local floatbits = 24
do
  local p = 2.0^floatbits
  while p < p + 1.0 do
    p = p * 2.0
    floatbits = floatbits + 1
  end
end


-- maximum exponent for a floating-point number
local maxexp = 0
do
  local p = 2.0
  while p < math.huge do
    maxexp = maxexp + 1
    p = p + p
  end
end


local function isNaN (x)
  return (x ~= x)
end

assert(isNaN(0/0))
assert(not isNaN(1/0))


do
  local x = 2.0^floatbits
  assert(x > x - 1.0 and x == x + 1.0)

  local msg = "  %d-bit integers, %d-bit*2^%d floats"
  print(string.format(msg, intbits, floatbits, maxexp))
end

assert(math.type(0) == "integer" and math.type(0.0) == "float"
       and not math.type("10"))


local function checkerror (msg, f, ...)
  local s, err = pcall(f, ...)
  assert(not s and string.find(err, msg))
end

local msgf2i = "number.* has no integer representation"

-- float equality
local function eq (a,b,limit)
  if not limit then
    if floatbits >= 50 then limit = 1E-11
    else limit = 1E-5
    end
  end
  -- a == b needed for +inf/-inf
  return a == b or math.abs(a-b) <= limit
end
