_soft = true; _port = true; _nomsg = true
-- $Id: testes/goto.lua $
-- See Copyright Notice in file lua.h

global<const> require
global<const> print, load, assert, string, setmetatable
global<const> collectgarbage, error

print("testing goto and global declarations")

collectgarbage()

local function errmsg (code, m)
  local st, msg = load(code)
  assert(not st and string.find(msg, m))
end

-- cannot see label inside block
errmsg([[ goto l1; do ::l1:: end ]], "label 'l1'")
errmsg([[ do ::l1:: end goto l1; ]], "label 'l1'")

-- repeated label
errmsg([[ ::l1:: ::l1:: ]], "label 'l1'")
errmsg([[ ::l1:: do ::l1:: end]], "label 'l1'")



-- jumping over variable declaration
errmsg([[ goto l1; local aa ::l1:: ::l2:: print(3) ]], "scope of 'aa'")

errmsg([[ goto l2; global *; ::l1:: ::l2:: print(3) ]], "scope of '*'")

errmsg([[
do local bb, cc; goto l1; end
local aa
::l1:: print(3)
]], "scope of 'aa'")


-- jumping into a block
errmsg([[ do ::l1:: end goto l1 ]], "label 'l1'")
errmsg([[ goto l1 do ::l1:: end ]], "label 'l1'")

-- cannot continue a repeat-until with variables
errmsg([[
  repeat
    if x then goto cont end
    local xuxu = 10
    ::cont::
  until xuxu < x
]], "scope of 'xuxu'")

-- simple gotos
local x
do
  local y = 12
  goto l1
  ::l2:: x = x + 1; goto l3
  ::l1:: x = y; goto l2
end
::l3:: ::l3_1:: assert(x == 13)
