for _, s in ipairs{"math.pow(2,2)", "math.atan2(1,1)", "math.log10(10)",
                   "math.cosh(0)", "math.sinh(0)", "math.tanh(0)"} do
  local f = load("return " .. s, "=c")
  print(s, pcall(f))
end
