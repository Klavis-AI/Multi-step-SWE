-- The transcendental results go through %.14g: the last bit of a libm result
-- is not the same on every platform and is not what this checks.
local function g(...)
  local out = {}
  for i = 1, select("#", ...) do out[i] = string.format("%.14g", (select(i, ...))) end
  return table.concat(out, "\t")
end
print(math.pow(2, 10), math.pow(2, 0.5), math.pow(-8, 1/3) ~= math.pow(-8, 1/3))
print(math.log10(1000), math.log10(1), math.log10(0))
print(g(math.atan2(1, 1), math.atan2(0, -1), math.atan2(-1, 0)))
print(math.cosh(0), math.sinh(0), math.tanh(0))
print(g(math.cosh(1), math.sinh(1), math.tanh(1)))
print(math.ldexp(1, 10), math.ldexp(0.5, 3), math.ldexp(1, -1))
print(math.frexp(8))
print(math.frexp(0))
print(math.frexp(-0.5))
