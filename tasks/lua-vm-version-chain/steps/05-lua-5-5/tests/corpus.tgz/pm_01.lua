_soft = true; _port = true; _nomsg = true
-- $Id: testes/pm.lua $
-- See Copyright Notice in file lua.h

-- UTF-8 file


print('testing pattern matching')

global <const> *

local function checkerror (msg, f, ...)
  local s, err = pcall(f, ...)
  assert(not s and string.find(err, msg))
end


local function f (s, p)
  local i,e = string.find(s, p)
  if i then return string.sub(s, i, e) end
end
