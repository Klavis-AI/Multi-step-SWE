-- The compatibility wrappers are the float functions: their results are floats.
print(math.type(math.pow(2, 3)), math.type(math.ldexp(1, 3)))
print(math.pow(2, 63), math.pow(2, 64) == 2.0^64)
local m, e = math.frexp(2^53)
print(m, e, math.type(m), math.type(e))
