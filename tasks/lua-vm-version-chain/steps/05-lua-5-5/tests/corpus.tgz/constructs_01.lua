_soft = true; _port = true; _nomsg = true
-- $Id: testes/constructs.lua $
-- See Copyright Notice in file lua.h

;;print "testing syntax";;

local debug = require "debug"


local function checkload (s, msg)
  assert(string.find(select(2, load(s)), msg))
end

-- testing semicollons
local a
do ;;; end
; do ; a = 3; assert(a == 3) end;
;

