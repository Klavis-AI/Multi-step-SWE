_soft = true; _port = true; _nomsg = true
-- $Id: testes/gc.lua $
-- See Copyright Notice in file lua.h

print('testing incremental garbage collection')

local debug = require"debug"

assert(collectgarbage("isrunning"))

collectgarbage()

local oldmode = collectgarbage("incremental")

-- changing modes should return previous mode
assert(collectgarbage("generational") == "incremental")
assert(collectgarbage("generational") == "generational")
assert(collectgarbage("incremental") == "generational")
assert(collectgarbage("incremental") == "incremental")


local function nop () end

local function gcinfo ()
  return collectgarbage"count" * 1024
end


-- test weird parameters to 'collectgarbage'
do
  collectgarbage("incremental")
  local opause = collectgarbage("param", "pause", 100)
  local ostepmul = collectgarbage("param", "stepmul", 100)
  assert(collectgarbage("param", "pause") == 100)
  assert(collectgarbage("param", "stepmul") == 100)
  local t = {0, 2, 10, 90, 500, 5000, 30000, 0x7ffffffe}
  for i = 1, #t do
    collectgarbage("param", "pause", t[i])
    for j = 1, #t do
      collectgarbage("param", "stepmul", t[j])
      collectgarbage("step", t[j])
    end
  end
  -- restore original parameters
  collectgarbage("param", "pause", opause)
  collectgarbage("param", "stepmul", ostepmul)
  collectgarbage()
end
