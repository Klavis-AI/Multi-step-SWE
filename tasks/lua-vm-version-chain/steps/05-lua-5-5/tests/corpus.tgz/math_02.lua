_soft = true; _port = true; _nomsg = true
-- $Id: testes/math.lua $
-- See Copyright Notice in file lua.h

print("testing numbers and math lib")

local math = require "math"
local string = require "string"

global none

global<const> print, assert, pcall, type, pairs, load
global<const> tonumber, tostring, select

local<const> minint, maxint = math.mininteger, math.maxinteger

local intbits <const> = math.floor(math.log(maxint, 2) + 0.5) + 1
assert((1 << intbits) == 0)

assert(minint == 1 << (intbits - 1))
assert(maxint == minint - 1)

-- number of bits in the mantissa of a floating-point number
local floatbits = 24
do
  local p = 2.0^floatbits
  while p < p + 1.0 do
    p = p * 2.0
    floatbits = floatbits + 1
  end
end


-- maximum exponent for a floating-point number
local maxexp = 0
do
  local p = 2.0
  while p < math.huge do
    maxexp = maxexp + 1
    p = p + p
  end
end
