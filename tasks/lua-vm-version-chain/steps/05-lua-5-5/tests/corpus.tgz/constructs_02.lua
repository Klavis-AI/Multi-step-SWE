_soft = true; _port = true; _nomsg = true
-- $Id: testes/constructs.lua $
-- See Copyright Notice in file lua.h

;;print "testing syntax";;

local debug = require "debug"


local function checkload (s, msg)
  assert(string.find(select(2, load(s)), msg))
end

-- testing semicollons
local a
do ;;; end
; do ; a = 3; assert(a == 3) end;
;


-- invalid operations should not raise errors when not executed
if false then a = 3 // 0; a = 0 % 0 end


-- testing priorities

assert(2^3^2 == 2^(3^2));
assert(2^3*4 == (2^3)*4);
assert(2.0^-2 == 1/4 and -2^- -2 == - - -4);
assert(not nil and 2 and not(2>3 or 3<2));
assert(-3-1-5 == 0+0-9);
assert(-2^2 == -4 and (-2)^2 == 4 and 2*2-3-1 == 0);
assert(-3%5 == 2 and -3+5 == 2)
assert(2*1+3/3 == 3 and 1+2 .. 3*1 == "33");
assert(not(2+1 > 3*1) and "a".."b" > "a");

assert(0xF0 | 0xCC ~ 0xAA & 0xFD == 0xF4)
