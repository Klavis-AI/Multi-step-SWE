_soft = true; _port = true; _nomsg = true
-- $Id: testes/gc.lua $
-- See Copyright Notice in file lua.h

print('testing incremental garbage collection')

local debug = require"debug"

assert(collectgarbage("isrunning"))

collectgarbage()

local oldmode = collectgarbage("incremental")

-- changing modes should return previous mode
assert(collectgarbage("generational") == "incremental")
assert(collectgarbage("generational") == "generational")
assert(collectgarbage("incremental") == "generational")
assert(collectgarbage("incremental") == "incremental")


local function nop () end

local function gcinfo ()
  return collectgarbage"count" * 1024
end


-- test weird parameters to 'collectgarbage'
do
  collectgarbage("incremental")
  local opause = collectgarbage("param", "pause", 100)
  local ostepmul = collectgarbage("param", "stepmul", 100)
  assert(collectgarbage("param", "pause") == 100)
  assert(collectgarbage("param", "stepmul") == 100)
  local t = {0, 2, 10, 90, 500, 5000, 30000, 0x7ffffffe}
  for i = 1, #t do
    collectgarbage("param", "pause", t[i])
    for j = 1, #t do
      collectgarbage("param", "stepmul", t[j])
      collectgarbage("step", t[j])
    end
  end
  -- restore original parameters
  collectgarbage("param", "pause", opause)
  collectgarbage("param", "stepmul", ostepmul)
  collectgarbage()
end


--
-- test the "size" of basic GC steps (whatever they mean...)
--

























_G["while"] = 234


--
-- tests for GC activation when creating different kinds of objects
--
local function GC1 ()
  local u
  local b     -- (above 'u' it in the stack)
  local finish = false
  u = setmetatable({}, {__gc = function () finish = true end})
  b = {34}
  repeat u = {} until finish
  assert(b[1] == 34)   -- 'u' was collected, but 'b' was not

  finish = false; local i = 1
  u = setmetatable({}, {__gc = function () finish = true end})
  repeat i = i + 1; u = tostring(i) .. tostring(i) until finish
  assert(b[1] == 34)   -- 'u' was collected, but 'b' was not

  finish = false
  u = setmetatable({}, {__gc = function () finish = true end})
  repeat local i; u = function () return i end until finish
  assert(b[1] == 34)   -- 'u' was collected, but 'b' was not
end
