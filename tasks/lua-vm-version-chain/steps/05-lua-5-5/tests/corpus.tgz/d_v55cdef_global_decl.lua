-- The declaration itself works in either build.
local ok, err = load("global x\nx = 3\nreturn x")
print(ok ~= nil, err)
print(load("global x\nx = 3\nreturn x")())
print(select(2, load("global x\nreturn y", "=c")))
print(select(2, load("global function g() end\nreturn h", "=c")))
