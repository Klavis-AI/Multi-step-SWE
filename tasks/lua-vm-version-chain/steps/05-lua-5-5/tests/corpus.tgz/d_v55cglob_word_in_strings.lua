-- A reserved word is only reserved to the lexer.
local s = "global"
print(s, #s, s:upper(), ("the global x"):match("glo%a+"))
local t = {}
t["global"] = 1
print(t["global"], next(t))
print(("%s"):format("global"))
