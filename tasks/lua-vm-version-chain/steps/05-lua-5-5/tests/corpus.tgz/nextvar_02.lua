_soft = true; _port = true; _nomsg = true
-- $Id: testes/nextvar.lua $
-- See Copyright Notice in file lua.h

global <const> *

print('testing tables, next, and for')

local function checkerror (msg, f, ...)
  local s, err = pcall(f, ...)
  assert(not s and string.find(err, msg))
end



----------------------------------------------------------------
local function printTable (t)
  local a, h = T.querytab(t)
  print("array:")
  for i = 1, a do
    print("", T.querytab(t, i - 1))
  end
  print("hash:")
  for i = 1, h do
    print("", T.querytab(t, a + i - 1))
  end
end
----------------------------------------------------------------
local function countentries (t)
  local e = 0
  for _ in pairs(t) do e = e + 1 end
  return e
end
----------------------------------------------------------------


local function check (t, na, nh)
  if not T then return end
  local a, h = T.querytab(t)
  if a ~= na or h ~= nh then
    print(na, nh, a, h)
    assert(nil)
  end
end

