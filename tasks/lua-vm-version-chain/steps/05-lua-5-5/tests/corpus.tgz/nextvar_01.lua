_soft = true; _port = true; _nomsg = true
-- $Id: testes/nextvar.lua $
-- See Copyright Notice in file lua.h

global <const> *

print('testing tables, next, and for')

local function checkerror (msg, f, ...)
  local s, err = pcall(f, ...)
  assert(not s and string.find(err, msg))
end



----------------------------------------------------------------
local function printTable (t)
  local a, h = T.querytab(t)
  print("array:")
  for i = 1, a do
    print("", T.querytab(t, i - 1))
  end
  print("hash:")
  for i = 1, h do
    print("", T.querytab(t, a + i - 1))
  end
end
