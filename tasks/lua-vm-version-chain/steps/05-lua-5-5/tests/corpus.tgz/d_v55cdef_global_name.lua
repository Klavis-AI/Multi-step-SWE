-- With LUA_COMPAT_GLOBAL (the default) 'global' is still an ordinary name.
local global = 17
print(global)
local t = {global = 1, [global] = "k"}
print(t.global, t[17])
t.global = t.global + 1
print(t.global)
local function f(global) return global * 2 end
print(f(21))
for global = 1, 3 do io.write(global, " ") end
print()
print(load("local global = 1 return global")())
