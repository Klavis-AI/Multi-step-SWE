-- Without LUA_COMPAT_MATHLIB the names the macro restores are absent. ldexp
-- and frexp are not among them: this release has those in every build.
local names = {"pow", "atan2", "cosh", "sinh", "tanh", "log10", "ldexp", "frexp"}
for _, n in ipairs(names) do print(n, type(math[n])) end
print(pcall(function () return math.pow(2, 10) end))
print(math.log(1000, 10), math.atan(1, 1))
print(math.ldexp(1, 10), math.frexp(8))
