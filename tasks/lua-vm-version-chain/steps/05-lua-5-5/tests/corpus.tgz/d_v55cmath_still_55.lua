-- Everything else is still this release: the macro only adds names.
print(_VERSION)
print(math.type(1), math.type(1.0), math.maxinteger // 1)
local ok, err = load("local global = 1 return global")
print(ok ~= nil, err)
print(table.create ~= nil, math.ult(1, 2))
