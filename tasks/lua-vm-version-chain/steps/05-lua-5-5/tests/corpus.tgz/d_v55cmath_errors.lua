for _, s in ipairs{"math.pow('x', 2)", "math.pow(2)", "math.log10()",
                   "math.atan2(1)", "math.ldexp(1)", "math.frexp('a')",
                   "math.cosh({})"} do
  print(s, select(2, pcall(load("return " .. s, "=c"))))
end
