-- With LUA_COMPAT_GLOBAL=0 'global' is a reserved word.
for _, s in ipairs{"local global = 1",
                   "global = 1",
                   "print(global)",
                   "local t = {} t.global = 1",
                   "local t = {global = 1}",
                   "for global = 1, 2 do end",
                   "local function global() end",
                   "function global() end",
                   "local f = function(global) end"} do
  local f, e = load(s, "=c")
  print(f ~= nil, e)
end
