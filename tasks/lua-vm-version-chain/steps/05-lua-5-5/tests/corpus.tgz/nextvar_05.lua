_soft = true; _port = true; _nomsg = true
-- $Id: testes/nextvar.lua $
-- See Copyright Notice in file lua.h

global <const> *

print('testing tables, next, and for')

local function checkerror (msg, f, ...)
  local s, err = pcall(f, ...)
  assert(not s and string.find(err, msg))
end



----------------------------------------------------------------
local function printTable (t)
  local a, h = T.querytab(t)
  print("array:")
  for i = 1, a do
    print("", T.querytab(t, i - 1))
  end
  print("hash:")
  for i = 1, h do
    print("", T.querytab(t, a + i - 1))
  end
end
----------------------------------------------------------------
local function countentries (t)
  local e = 0
  for _ in pairs(t) do e = e + 1 end
  return e
end
----------------------------------------------------------------


local function check (t, na, nh)
  if not T then return end
  local a, h = T.querytab(t)
  if a ~= na or h ~= nh then
    print(na, nh, a, h)
    assert(nil)
  end
end


local a = {}

-- make sure table has lots of space in hash part
for i=1,100 do a[i.."+"] = true end
for i=1,100 do a[i.."+"] = undef end
-- fill hash part with numeric indices testing size operator
for i=1,100 do
  a[i] = true
  assert(#a == i)
end


do   -- rehash moving elements from array to hash
  local a = {}
  for i = 1, 100 do a[i] = i end
  check(a, 128, 0)

  for i = 5, 95 do a[i] = nil end
  check(a, 128, 0)

  a[129] = 1     -- force a re-hash
  check(a, 4, 8)   -- keys larger than 4 go to the hash part

  for i = 1, 4 do assert(a[i] == i) end
  for i = 5, 95 do assert(a[i] == nil) end
  for i = 96, 100 do assert(a[i] == i) end
  assert(a[129] == 1)
end


do    -- growing hash part keeping array part
  local a = table.create(1000)
  check(a, 1000, 0)
  a.x = 10
  check(a, 1000, 1)   -- array part keeps its elements
end


do   -- "growing" length of a prebuilt table
  local N = 100
  local a = table.create(N)
  for i = 1, N do
    a[#a + 1] = true
    assert(#a == i)
  end
  check(a, N, 0)
end


-- testing ipairs
local x = 0
for k,v in ipairs{10,20,30;x=12} do
  x = x + 1
  assert(k == x and v == x * 10)
end

for _ in ipairs{x=12, y=24} do assert(nil) end

-- test for 'false' x ipair
x = false
local i = 0
for k,v in ipairs{true,false,true,false} do
  i = i + 1
  x = not x
  assert(x == v)
end
