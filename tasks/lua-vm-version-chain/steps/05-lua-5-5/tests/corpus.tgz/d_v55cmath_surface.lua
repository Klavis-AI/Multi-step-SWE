-- LUA_COMPAT_MATHLIB brings back exactly the names 5.3 removed.
local names = {"pow", "atan2", "cosh", "sinh", "tanh", "log10", "ldexp", "frexp"}
for _, n in ipairs(names) do print(n, type(math[n])) end
local surface = {}
for k in pairs(math) do surface[#surface + 1] = k end
table.sort(surface)
print(table.concat(surface, " "))
