_soft = true; _port = true; _nomsg = true
-- $Id: testes/goto.lua $
-- See Copyright Notice in file lua.h

global<const> require
global<const> print, load, assert, string, setmetatable
global<const> collectgarbage, error

print("testing goto and global declarations")

collectgarbage()

local function errmsg (code, m)
  local st, msg = load(code)
  assert(not st and string.find(msg, m))
end

-- cannot see label inside block
errmsg([[ goto l1; do ::l1:: end ]], "label 'l1'")
