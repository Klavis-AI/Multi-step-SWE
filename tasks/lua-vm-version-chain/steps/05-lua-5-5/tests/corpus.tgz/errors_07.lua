_soft = true; _port = true; _nomsg = true
-- $Id: testes/errors.lua $
-- See Copyright Notice in file lua.h

print("testing errors")

local debug = require"debug"

-- avoid problems with 'strict' module (which may generate other error messages)
local mt = getmetatable(_G) or {}
local oldmm = mt.__index
mt.__index = nil

local function checkerr (msg, f, ...)
  local st, err = pcall(f, ...)
  assert(not st and string.find(err, msg))
end


local function doit (s)
  local f, msg = load(s)
  if not f then return msg end
  local cond, msg = pcall(f)
  return (not cond) and msg
end


local function checkmessage (prog, msg, debug)
  local m = doit(prog)
  if debug then print(m, msg) end
  assert(string.find(m, msg, 1, true))
end

local function checksyntax (prog, extra, token, line)
  local msg = doit(prog)
  if not string.find(token, "^<%a") and not string.find(token, "^char%(")
    then token = "'"..token.."'" end
  token = string.gsub(token, "(%p)", "%%%1")
  local pt = string.format([[^%%[string ".*"%%]:%d: .- near %s$]],
                           line, token)
  assert(string.find(msg, pt))
  assert(string.find(msg, msg, 1, true))
end


-- test error message with no extra info
assert(doit("error('hi', 0)") == 'hi')

-- test nil error message
assert(doit("error()") == "<no error object>")


-- test common errors/errors that crashed in the past
assert(doit("table.unpack({}, 1, n=2^30)"))
assert(doit("a=math.sin()"))
assert(not doit("tostring(1)") and doit("tostring()"))
assert(doit"tonumber()")
assert(doit"repeat until 1; a")
assert(doit"return;;")
assert(doit"assert(false)")
assert(doit"assert(nil)")
assert(doit("function a (... , ...) end"))
assert(doit("function a (, ...) end"))
assert(doit("local t={}; t = t[#t] + 1"))

checksyntax([[
  local a = {4

]], "'}' expected (to close '{' at line 1)", "<eof>", 3)


do   -- testing errors in goto/break
  local function checksyntax (prog, msg, line)
    local st, err = load(prog)
    assert(string.find(err, "line " .. line))
    assert(string.find(err, msg, 1, true))
  end

  checksyntax([[
    ::A:: a = 1
    ::A::
  ]], "label 'A' already defined", 1)

  checksyntax([[
    a = 1
    goto A
    do ::A:: end
  ]], "no visible label 'A'", 2)

end


if not T then
  (Message or print)
    ('\n >>> testC not active: skipping tests for messages in C <<<\n')
else
  print "testing memory error message"
  local a = {}
  for i = 1, 10000 do a[i] = true end   -- preallocate array
  collectgarbage()
  T.totalmem(T.totalmem() + 10000)
  -- force a memory error (by a small margin)
  local st, msg = pcall(function()
    for i = 1, 100000 do a[i] = tostring(i) end
  end)
  T.totalmem(0)
  assert(not st and msg == "not enough" .. " memory")

  -- stack space for luaL_traceback (bug in 5.4.6)
  local res = T.testC[[
    # push 16 elements on the stack
    pushnum 1; pushnum 1; pushnum 1; pushnum 1; pushnum 1;
    pushnum 1; pushnum 1; pushnum 1; pushnum 1; pushnum 1;
    pushnum 1; pushnum 1; pushnum 1; pushnum 1; pushnum 1;
    pushnum 1;
    # traceback should work with 4 remaining slots
    traceback xuxu 1;
    return 1
  ]]
  assert(string.find(res, "xuxu.-main chunk"))

  do   -- tests for error messages about extra arguments from __call
    local function createobj (n)
      -- function that raises an error on its n-th argument
      local code = string.format("argerror %d 'msg'", n)
      local func = T.makeCfunc(code)
      -- create a chain of 2 __call objects
      local M = setmetatable({}, {__call = func})
      M = setmetatable({}, {__call = M})
      -- put it as a method for a new object
      return {foo = M}
    end

  _G.a = createobj(1)   -- error in first (extra) argument
  checkmessage("a:foo()", "bad extra argument #1")

  _G.a = createobj(2)   -- error in second (extra) argument
  checkmessage("a:foo()", "bad extra argument #2")

  _G.a = createobj(3)   -- error in self (after two extra arguments)
  checkmessage("a:foo()", "bad self")

  _G.a = createobj(4)  -- error in first regular argument (after self)
  checkmessage("a:foo()", "bad argument #1")
  end
end


-- tests for better error messages

checkmessage("a = {} + 1", "arithmetic")
checkmessage("a = {} | 1", "bitwise operation")
checkmessage("a = {} < 1", "attempt to compare")
checkmessage("a = {} <= 1", "attempt to compare")

checkmessage("aaa=1; bbbb=2; aaa=math.sin(3)+bbbb(3)", "global 'bbbb'")
checkmessage("aaa={}; do local aaa=1 end aaa:bbbb(3)", "method 'bbbb'")
checkmessage("local a={}; a.bbbb(3)", "field 'bbbb'")
assert(not string.find(doit"aaa={13}; local bbbb=1; aaa[bbbb](3)", "'bbbb'"))
checkmessage("aaa={13}; local bbbb=1; aaa[bbbb](3)", "number")
checkmessage("aaa=(1)..{}", "a table value")

checkmessage("local function foo (...t) return t.xx + 1 end; foo()",
             "field 'xx'")

-- bug in 5.4.6
checkmessage("a = {_ENV = {}}; print(a._ENV.x + 1)", "field 'x'")

-- a similar bug, since 5.4.0
checkmessage("print(('_ENV').x + 1)", "field 'x'")

_G.aaa, _G.bbbb = nil

-- calls
checkmessage("local a; a(13)", "local 'a'")
checkmessage([[
  local a = setmetatable({}, {__add = 34})
  a = a + 1
]], "metamethod 'add'")
checkmessage([[
  local a = setmetatable({}, {__lt = {}})
  a = a > a
]], "metamethod 'lt'")
