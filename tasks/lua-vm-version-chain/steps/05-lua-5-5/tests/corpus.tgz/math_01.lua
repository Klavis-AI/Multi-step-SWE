_soft = true; _port = true; _nomsg = true
-- $Id: testes/math.lua $
-- See Copyright Notice in file lua.h

print("testing numbers and math lib")

local math = require "math"
local string = require "string"

global none

global<const> print, assert, pcall, type, pairs, load
global<const> tonumber, tostring, select

local<const> minint, maxint = math.mininteger, math.maxinteger

local intbits <const> = math.floor(math.log(maxint, 2) + 0.5) + 1
assert((1 << intbits) == 0)

