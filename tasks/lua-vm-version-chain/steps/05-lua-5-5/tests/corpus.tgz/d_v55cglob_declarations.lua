-- The declaration forms still work, and are the only use of the word.
print(load("global x\nx = 3\nreturn x")())
print(load("global function g() return 7 end\nreturn g()")())
print(select(2, load("global x\nreturn y", "=c")))
print(select(2, load("global x\nz = 1", "=c")))
print(load("global *\nw = 9\nreturn w")())
