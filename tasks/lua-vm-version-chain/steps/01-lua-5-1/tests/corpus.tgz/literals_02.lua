_soft = true; _port = true; _nomsg = true; local __asserts, __print = 0, print; assert = function (v, m, ...) __asserts = __asserts + 1; if not v then error(m == nil and "assertion failed!" or m, 2) end; return v, m, ... end
print('testing scanner')

local function dostring (x) return assert(loadstring(x))() end

dostring("x = 'a\0a'")
assert(x == 'a\0a' and string.len(x) == 3)

-- escape sequences
assert('\n\"\'\\' == [[

"'\]])

assert(string.find("\a\b\f\n\r\t\v", "^%c%c%c%c%c%c%c$"))

-- assume ASCII just for tests:
assert("\09912" == 'c12')
assert("\99ab" == 'cab')
assert("\099" == '\99')
assert("\099\n" == 'c\10')
assert('\0\0\0alo' == '\0' .. '\0\0' .. 'alo')

assert(010 .. 020 .. -030 == "1020-30")

-- long variable names

var = string.rep('a', 15000)
prog = string.format("%s = 5", var)
dostring(prog)
assert(_G[var] == 5)
var = nil
print('+')

-- escapes --
assert("\n\t" == [[

	]])
__print("asserts executed: " .. __asserts)
