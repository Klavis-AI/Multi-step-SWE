_soft = true; _port = true; _nomsg = true
;;print "testing syntax";;

local debug = require "debug"

-- testing semicollons
do ;;; end
; do ; a = 3; assert(a == 3) end;
;


-- testing priorities

assert(2^3^2 == 2^(3^2));
assert(2^3*4 == (2^3)*4);
assert(2^-2 == 1/4 and -2^- -2 == - - -4);
assert(not nil and 2 and not(2>3 or 3<2));
assert(-3-1-5 == 0+0-9);
assert(-2^2 == -4 and (-2)^2 == 4 and 2*2-3-1 == 0);
