_soft = true; _port = true; _nomsg = true
print('testing pattern matching')

function f(s, p)
  local i,e = string.find(s, p)
  if i then return string.sub(s, i, e) end
end

function f1(s, p)
  p = string.gsub(p, "%%([0-9])", function (s) return "%" .. (s+1) end)
  p = string.gsub(p, "^(^?)", "%1()", 1)
  p = string.gsub(p, "($?)$", "()%1", 1)
  local t = {string.match(s, p)}
  return string.sub(s, t[1], t[#t] - 1)
end

a,b = string.find('', '')    -- empty patterns are tricky
assert(a == 1 and b == 0);
a,b = string.find('alo', '')
