/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --seed 100101 --max-funcs 8
 * Seed:      100101
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
#pragma pack(push)
#pragma pack(1)
struct S0 {
   volatile uint8_t  f0;
   volatile uint8_t  f1;
};
#pragma pack(pop)

union U1 {
   uint32_t  f0;
   const int16_t  f1;
   const int8_t * f2;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_3[8] = {0x33992443L,0x33992443L,0x33992443L,0x33992443L,0x33992443L,0x33992443L,0x33992443L,0x33992443L};
static uint64_t g_29 = 0x55C59C3F9080254FLL;
static volatile uint64_t g_36 = 0UL;/* VOLATILE GLOBAL g_36 */
static volatile uint64_t * volatile g_35 = &g_36;/* VOLATILE GLOBAL g_35 */
static int32_t g_54 = 0L;
static int8_t g_77 = 1L;
static uint32_t g_79 = 0x4B48EDA2L;
static uint8_t g_85 = 251UL;
static uint64_t g_117 = 0x0850DA4A23C0F0EFLL;
static uint64_t *g_116 = &g_117;
static struct S0 g_120 = {0x2CL,0xE6L};/* VOLATILE GLOBAL g_120 */
static struct S0 g_121 = {8UL,0x0DL};/* VOLATILE GLOBAL g_121 */
static struct S0 g_122[4][6][1] = {{{{251UL,0x53L}},{{0xE5L,1UL}},{{251UL,0x53L}},{{251UL,0x53L}},{{0xE5L,1UL}},{{251UL,0x53L}}},{{{251UL,0x53L}},{{0xE5L,1UL}},{{251UL,0x53L}},{{251UL,0x53L}},{{0xE5L,1UL}},{{251UL,0x53L}}},{{{251UL,0x53L}},{{0xE5L,1UL}},{{251UL,0x53L}},{{251UL,0x53L}},{{0xE5L,1UL}},{{251UL,0x53L}}},{{{251UL,0x53L}},{{0xE5L,1UL}},{{251UL,0x53L}},{{251UL,0x53L}},{{0xE5L,1UL}},{{251UL,0x53L}}}};
static struct S0 g_123 = {0x07L,4UL};/* VOLATILE GLOBAL g_123 */
static struct S0 g_124 = {255UL,246UL};/* VOLATILE GLOBAL g_124 */
static struct S0 g_126 = {0xAFL,9UL};/* VOLATILE GLOBAL g_126 */
static struct S0 *g_125 = &g_126;
static struct S0 g_129[1][10][4] = {{{{0x49L,0x70L},{1UL,7UL},{1UL,7UL},{0x49L,0x70L}},{{247UL,0x5FL},{1UL,7UL},{0xD2L,246UL},{1UL,7UL}},{{1UL,7UL},{255UL,0UL},{0xD2L,246UL},{0xD2L,246UL}},{{247UL,0x5FL},{247UL,0x5FL},{0x49L,0x70L},{255UL,0UL}},{{0xD2L,246UL},{247UL,0x5FL},{0xD2L,246UL},{0x49L,0x70L}},{{0xD2L,246UL},{0x49L,0x70L},{0x49L,0x70L},{0xD2L,246UL}},{{1UL,7UL},{0x49L,0x70L},{255UL,0UL},{0x49L,0x70L}},{{0x49L,0x70L},{247UL,0x5FL},{255UL,0UL},{255UL,0UL}},{{1UL,7UL},{1UL,7UL},{0x49L,0x70L},{255UL,0UL}},{{0xD2L,246UL},{247UL,0x5FL},{0xD2L,246UL},{0x49L,0x70L}}}};
static uint32_t g_142 = 0xD451FECAL;
static uint64_t g_187 = 0x22307A3C17D6ECEDLL;
static int16_t g_191[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
static int64_t g_197 = 0xC323D9690AA6365CLL;
static int32_t g_198 = 0x51499A76L;
static uint64_t g_203 = 0xAA2B9E0A366A91BFLL;
static int32_t g_206 = 1L;
static uint16_t g_207 = 65535UL;
static union U1 g_218 = {6UL};
static int32_t *g_223 = (void*)0;
static int32_t * volatile *g_222[3] = {&g_223,&g_223,&g_223};
static int16_t *g_242 = &g_191[8];
static union U1 *g_249 = (void*)0;
static struct S0 g_265 = {0x31L,0xDFL};/* VOLATILE GLOBAL g_265 */
static int8_t *g_273 = &g_77;
static int8_t **g_272 = &g_273;
static int16_t g_306[2][1][8] = {{{0xB23EL,0xB23EL,0xB23EL,0xB23EL,0xB23EL,0xB23EL,0xB23EL,0xB23EL}},{{0xB23EL,0xB23EL,0xB23EL,0xB23EL,0xB23EL,0xB23EL,0xB23EL,0xB23EL}}};
static uint32_t g_337 = 4UL;
static int32_t g_380 = 0xB08A3A49L;
static uint64_t g_393 = 0x27F84D97D11164EALL;
static struct S0 g_414 = {0xB7L,0x93L};/* VOLATILE GLOBAL g_414 */
static uint32_t * volatile g_423 = (void*)0;/* VOLATILE GLOBAL g_423 */
static uint32_t * volatile *g_422 = &g_423;
static const uint64_t *g_432[8] = {&g_117,&g_117,&g_117,&g_117,&g_117,&g_117,&g_117,&g_117};
static const uint64_t * volatile *g_431 = &g_432[7];
static const uint64_t * volatile **g_430 = &g_431;
static int8_t g_453 = 9L;
static volatile uint16_t *g_472 = (void*)0;
static volatile uint16_t * volatile *g_471 = &g_472;
static int32_t g_499 = 3L;
static uint64_t ***g_516 = (void*)0;
static uint64_t **g_521 = &g_116;
static uint64_t ***g_520 = &g_521;
static uint16_t g_552 = 3UL;
static int64_t g_574 = (-1L);
static uint32_t g_781 = 0UL;
static union U1 * const *g_796 = (void*)0;
static union U1 * const * volatile *g_795 = &g_796;
static uint8_t g_840 = 0x4AL;
static uint8_t g_980 = 0x87L;
static uint32_t *g_1003 = &g_142;
static uint32_t * const *g_1002 = &g_1003;
static volatile struct S0 g_1082 = {0xF5L,0xA9L};/* VOLATILE GLOBAL g_1082 */
static uint32_t * volatile * volatile *g_1105 = &g_422;
static uint32_t * volatile * volatile * const *g_1104 = &g_1105;
static volatile struct S0 g_1138 = {247UL,0xAFL};/* VOLATILE GLOBAL g_1138 */
static volatile int32_t g_1148 = 9L;/* VOLATILE GLOBAL g_1148 */
static volatile int32_t *g_1147 = &g_1148;
static volatile int32_t ** volatile g_1149 = &g_1147;/* VOLATILE GLOBAL g_1149 */
static uint32_t g_1172 = 4294967287UL;
static struct S0 g_1176[6] = {{3UL,0x98L},{3UL,0x98L},{3UL,0x98L},{3UL,0x98L},{3UL,0x98L},{3UL,0x98L}};
static uint32_t *g_1181 = &g_1172;
static uint32_t **g_1180 = &g_1181;
static uint32_t ***g_1179 = &g_1180;
static int16_t **g_1216 = (void*)0;
static int16_t ***g_1215 = &g_1216;
static uint8_t g_1245 = 0x1FL;
static struct S0 g_1286[9] = {{0x25L,254UL},{0x25L,254UL},{0x25L,254UL},{0x25L,254UL},{0x25L,254UL},{0x25L,254UL},{0x25L,254UL},{0x25L,254UL},{0x25L,254UL}};
static const uint8_t g_1364 = 4UL;
static union U1 **g_1391 = &g_249;
static union U1 ***g_1390 = &g_1391;
static union U1 **** volatile g_1389 = &g_1390;/* VOLATILE GLOBAL g_1389 */
static int32_t ** volatile g_1452 = &g_223;/* VOLATILE GLOBAL g_1452 */
static volatile int32_t g_1555 = 2L;/* VOLATILE GLOBAL g_1555 */
static uint32_t g_1586 = 1UL;
static int8_t g_1591 = 0xBFL;
static const volatile struct S0 g_1594 = {1UL,0x9FL};/* VOLATILE GLOBAL g_1594 */
static int32_t ** volatile g_1614 = &g_223;/* VOLATILE GLOBAL g_1614 */
static volatile uint16_t g_1617 = 1UL;/* VOLATILE GLOBAL g_1617 */
static volatile int32_t * const *g_1622 = &g_1147;
static volatile int32_t * const ** volatile g_1621 = &g_1622;/* VOLATILE GLOBAL g_1621 */
static volatile int32_t * const ** volatile * volatile g_1620 = &g_1621;/* VOLATILE GLOBAL g_1620 */
static int32_t ** volatile g_1624[6][7][2] = {{{(void*)0,&g_223},{&g_223,&g_223},{(void*)0,&g_223},{&g_223,(void*)0},{&g_223,(void*)0},{&g_223,&g_223},{&g_223,&g_223}},{{&g_223,&g_223},{&g_223,(void*)0},{&g_223,(void*)0},{&g_223,&g_223},{(void*)0,&g_223},{&g_223,&g_223},{(void*)0,&g_223}},{{&g_223,(void*)0},{&g_223,(void*)0},{&g_223,&g_223},{&g_223,&g_223},{&g_223,&g_223},{&g_223,(void*)0},{&g_223,(void*)0}},{{&g_223,&g_223},{(void*)0,&g_223},{&g_223,&g_223},{(void*)0,&g_223},{&g_223,(void*)0},{&g_223,(void*)0},{&g_223,&g_223}},{{&g_223,&g_223},{&g_223,&g_223},{&g_223,(void*)0},{&g_223,(void*)0},{&g_223,&g_223},{(void*)0,&g_223},{&g_223,&g_223}},{{(void*)0,&g_223},{&g_223,(void*)0},{&g_223,(void*)0},{&g_223,&g_223},{&g_223,&g_223},{&g_223,&g_223},{&g_223,(void*)0}}};
static const struct S0 g_1640 = {1UL,0x98L};/* VOLATILE GLOBAL g_1640 */
static const uint64_t g_1788 = 18446744073709551615UL;
static volatile uint16_t * volatile ***g_1868 = (void*)0;
static uint64_t g_1901 = 18446744073709551613UL;
static const volatile struct S0 g_2017[5] = {{255UL,0UL},{255UL,0UL},{255UL,0UL},{255UL,0UL},{255UL,0UL}};
static struct S0 g_2028 = {0xA1L,0xC1L};/* VOLATILE GLOBAL g_2028 */
static int32_t ** volatile g_2050[3] = {&g_223,&g_223,&g_223};
static volatile struct S0 g_2054 = {0x14L,0x0AL};/* VOLATILE GLOBAL g_2054 */
static volatile struct S0 g_2190 = {2UL,0x2EL};/* VOLATILE GLOBAL g_2190 */
static struct S0 g_2191[4] = {{1UL,0xC1L},{1UL,0xC1L},{1UL,0xC1L},{1UL,0xC1L}};
static int8_t g_2264 = 1L;
static const uint32_t *g_2319 = &g_218.f0;
static const uint32_t * const *g_2318[4][7][5] = {{{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319},{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319},{&g_2319,(void*)0,&g_2319,(void*)0,&g_2319},{&g_2319,(void*)0,&g_2319,&g_2319,&g_2319},{&g_2319,&g_2319,&g_2319,&g_2319,(void*)0},{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319},{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319}},{{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319},{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319},{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319},{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319},{&g_2319,&g_2319,&g_2319,&g_2319,(void*)0},{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319},{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319}},{{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319},{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319},{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319},{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319},{&g_2319,&g_2319,&g_2319,&g_2319,(void*)0},{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319},{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319}},{{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319},{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319},{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319},{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319},{&g_2319,&g_2319,&g_2319,&g_2319,(void*)0},{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319},{&g_2319,&g_2319,&g_2319,&g_2319,&g_2319}}};
static const uint32_t * const * const *g_2317 = &g_2318[1][3][1];
static int32_t ** volatile g_2322 = &g_223;/* VOLATILE GLOBAL g_2322 */
static uint32_t g_2346 = 0x7490F4E3L;
static volatile struct S0 g_2347 = {247UL,249UL};/* VOLATILE GLOBAL g_2347 */
static volatile struct S0 g_2358 = {0xA2L,0xDBL};/* VOLATILE GLOBAL g_2358 */
static int32_t ***g_2363 = (void*)0;
static int32_t ****g_2362[7] = {&g_2363,&g_2363,&g_2363,&g_2363,&g_2363,&g_2363,&g_2363};
static int32_t *****g_2361[9][6] = {{&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1]},{&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1]},{&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1]},{&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1]},{&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1]},{&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1]},{&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1]},{&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1]},{&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1],&g_2362[1]}};
static volatile struct S0 g_2398 = {0x33L,0xE6L};/* VOLATILE GLOBAL g_2398 */
static int32_t g_2435 = 0L;
static const uint32_t g_2467 = 0xC47D00CDL;
static uint16_t *g_2501 = &g_552;
static uint16_t ** const g_2500 = &g_2501;
static uint16_t ** const *g_2499 = &g_2500;
static volatile struct S0 g_2559 = {255UL,0x33L};/* VOLATILE GLOBAL g_2559 */
static volatile struct S0 g_2575 = {249UL,0UL};/* VOLATILE GLOBAL g_2575 */
static uint32_t g_2612[5][2][8] = {{{0UL,6UL,0UL,6UL,0UL,4294967295UL,0x3FA97DFDL,0x3832C0FEL},{4294967286UL,4294967295UL,0xBC22DC4EL,4294967295UL,1UL,0UL,0UL,4294967295UL}},{{0x3FA97DFDL,4294967295UL,0xBC22DC4EL,0x3832C0FEL,0xBC22DC4EL,4294967295UL,0x3FA97DFDL,0UL},{1UL,0x5C302EE2L,4294967292UL,0x3832C0FEL,0x3FA97DFDL,4294967295UL,0UL,4294967295UL}},{{4294967286UL,0x3832C0FEL,0UL,4294967295UL,0x3FA97DFDL,4294967295UL,0UL,0x3832C0FEL},{1UL,4294967295UL,4294967286UL,4294967295UL,0xBC22DC4EL,4294967295UL,1UL,0UL}},{{0x3FA97DFDL,0x3832C0FEL,4294967292UL,0x5C302EE2L,1UL,4294967295UL,1UL,0x5C302EE2L},{4294967286UL,0x5C302EE2L,4294967286UL,4294967295UL,0UL,4294967295UL,0UL,0x5C302EE2L}},{{0UL,4294967295UL,0UL,0x5C302EE2L,0xBC22DC4EL,0UL,0UL,0UL},{0UL,4294967295UL,4294967292UL,4294967295UL,0UL,4294967295UL,0x3FA97DFDL,0x3832C0FEL}}};


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static struct S0 * func_9(const uint16_t  p_10, int32_t  p_11, uint32_t  p_12);
static uint8_t  func_15(int32_t * const  p_16, int32_t * const  p_17, int32_t * p_18);
static int32_t * const  func_19(int32_t * p_20);
static int32_t * func_21(uint8_t  p_22, uint16_t  p_23, int8_t * p_24, uint16_t  p_25);
static uint64_t * func_45(uint16_t  p_46, int32_t * const  p_47, uint32_t  p_48, uint8_t  p_49, const uint32_t  p_50);
static int32_t  func_60(int32_t * p_61, int8_t  p_62);
static int32_t * func_63(int32_t ** p_64, int16_t  p_65);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_29 g_35 g_54 g_77 g_79 g_85 g_117 g_471 g_306 g_116 g_142 g_242 g_499 g_191 g_516 g_273 g_207 g_521 g_430 g_431 g_432 g_203 g_198 g_574 g_552 g_272 g_125 g_453 g_218.f0 g_206 g_337 g_187 g_781 g_840 g_393 g_218.f1 g_380 g_1286 g_1138.f1 g_1147 g_1148 g_223 g_126 g_1172 g_1622 g_472 g_265.f0 g_1640 g_1180 g_1181 g_1389 g_1390 g_1391 g_249 g_1621 g_1452 g_1620 g_1614 g_980 g_121.f1 g_1364 g_1149 g_1179 g_129.f0 g_1591 g_1176.f0 g_1555 g_124.f0 g_1868 g_1594.f1 g_1901 g_123.f1 g_2017 g_2028 g_1104 g_1105 g_2054 g_1002 g_1003 g_1176.f1 g_2190 g_2191 g_197 g_265.f1 g_2346 g_2317 g_2318 g_2501 g_123.f0 g_2612
 * writes: g_29 g_54 g_77 g_79 g_85 g_117 g_471 g_453 g_191 g_197 g_520 g_207 g_552 g_198 g_574 g_393 g_206 g_116 g_187 g_781 g_980 g_306 g_499 g_380 g_337 g_203 g_126 g_1148 g_1172 g_1591 g_122 g_840 g_1390 g_1868 g_223 g_1901 g_1586 g_142 g_1147 g_2346 g_125
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int32_t *l_2 = &g_3[6];
    int32_t *l_4[5];
    int16_t l_5[7] = {8L,8L,8L,8L,8L,8L,8L};
    uint32_t l_6 = 0x29C8DDACL;
    uint64_t *l_28 = &g_29;
    int32_t **l_32 = &l_4[3];
    int32_t **l_51[1][4] = {{&l_2,&l_2,&l_2,&l_2}};
    int32_t **l_52 = &l_2;
    int8_t l_1062[6] = {0xE7L,(-1L),(-1L),0xE7L,(-1L),(-1L)};
    int64_t *l_1063[3];
    int32_t l_1064 = (-2L);
    uint8_t *l_1065 = (void*)0;
    uint8_t *l_1066 = &g_85;
    int32_t * const l_2013 = &g_3[1];
    uint32_t l_2015 = 0xA92D79F8L;
    int8_t l_2604[3];
    uint64_t l_2609 = 18446744073709551615UL;
    uint32_t l_2613 = 18446744073709551607UL;
    int64_t l_2614 = 0x3B3CAA037457197BLL;
    uint16_t l_2615 = 0UL;
    int i, j;
    for (i = 0; i < 5; i++)
        l_4[i] = (void*)0;
    for (i = 0; i < 3; i++)
        l_1063[i] = &g_197;
    for (i = 0; i < 3; i++)
        l_2604[i] = 1L;
    --l_6;
    g_125 = func_9(g_3[5], (l_2015 = (safe_rshift_func_int8_t_s_s((g_3[1] == func_15(func_19(func_21(((*l_1066) = (((l_1064 = (safe_add_func_uint8_t_u_u(0xE6L, (((*l_28) ^= 0x85C82F744ED25E42LL) <= (safe_sub_func_int32_t_s_s((((*l_32) = l_4[4]) == ((safe_div_func_uint32_t_u_u((g_35 != ((safe_lshift_func_uint16_t_u_u(((safe_mod_func_uint64_t_u_u((safe_lshift_func_uint16_t_u_s((safe_add_func_int8_t_s_s((((*g_521) = func_45(g_3[6], ((*l_52) = &g_3[4]), g_3[6], g_3[0], g_3[6])) == l_28), g_218.f1)), 8)), l_1062[5])) > 65527UL), 4)) , l_28)), g_840)) , (*l_52))), 6L)))))) ^ g_3[6]) >= (-1L))), g_203, (*g_272), g_337)), l_2013, &g_3[2])), g_142))), (*l_2013));
    l_2614 |= ((0L & (*g_2501)) || (g_980 = (((((safe_rshift_func_int8_t_s_s(((((0x30L == ((*l_1066)++)) >= (((g_380 <= (l_2604[2] = (**l_52))) != (safe_sub_func_int16_t_s_s((*g_242), (((((g_123.f0 == (safe_div_func_int16_t_s_s((l_2609 && (safe_mul_func_uint16_t_u_u((0x78B5091CF3017F13LL <= (**l_52)), 0UL))), (*g_242)))) , (*l_2)) & (-5L)) || (*g_242)) , (**l_52))))) <= g_2612[3][0][2])) | 0UL) <= (*l_2013)), (**g_272))) || 0UL) && 0x19L) || (*l_2013)) || l_2613)));
    return l_2615;
}


/* ------------------------------------------ */
/* 
 * reads : g_2017 g_125 g_2028 g_126 g_1104 g_1105 g_2054 g_1147 g_1148 g_499 g_207 g_242 g_191 g_1180 g_1181 g_85 g_1002 g_1003 g_1286 g_1138.f1 g_198 g_223 g_1622 g_1172 g_1620 g_1621 g_1149 g_1614 g_187 g_272 g_273 g_3 g_77 g_430 g_431 g_432 g_117 g_203 g_521 g_116 g_781 g_306 g_1176.f1 g_980 g_2190 g_2191 g_218.f0 g_197 g_54 g_265.f1 g_453 g_380 g_1179 g_2346 g_2317 g_2318
 * writes: g_126 g_198 g_54 g_499 g_197 g_79 g_1586 g_207 g_1148 g_85 g_191 g_142 g_980 g_187 g_380 g_337 g_203 g_1147 g_840 g_77 g_1172 g_223 g_306 g_2346
 */
static struct S0 * func_9(const uint16_t  p_10, int32_t  p_11, uint32_t  p_12)
{ /* block id: 893 */
    uint8_t l_2016 = 0x0FL;
    const uint32_t *l_2040 = &g_337;
    const uint32_t **l_2039 = &l_2040;
    const uint32_t ***l_2038 = &l_2039;
    int32_t l_2048[9][8] = {{0xD88D4963L,0xC4249F0DL,0L,0xABCEE258L,0x7A1C5884L,0x579F5872L,0x7A1C5884L,0xABCEE258L},{0x2969226CL,1L,0x2969226CL,0x1BC2362CL,1L,0x34CD6186L,0x32C8B8DDL,0xD88D4963L},{0xCD84237EL,2L,0xABCEE258L,1L,(-10L),0L,1L,0x6C400552L},{0xCD84237EL,0x9D91636DL,1L,1L,1L,0x2969226CL,1L,0x16A67585L},{0x2969226CL,(-1L),5L,0x9D91636DL,0x7A1C5884L,0x7A1C5884L,0x9D91636DL,5L},{0xD88D4963L,0xD88D4963L,(-4L),0x579F5872L,0x76F45526L,0x32C8B8DDL,0x1BC2362CL,0x34CD6186L},{0x579F5872L,1L,(-6L),(-2L),(-1L),1L,0xC4249F0DL,0x34CD6186L},{1L,0x1BC2362CL,0x16A67585L,0x579F5872L,7L,1L,9L,5L},{(-6L),0x16A67585L,0x76F45526L,0x9D91636DL,0x815C9798L,0x9D91636DL,0x76F45526L,0x16A67585L}};
    int32_t *l_2052 = &g_54;
    int32_t l_2113 = 0x8B435E98L;
    struct S0 **l_2116 = &g_125;
    int32_t *l_2130 = &g_198;
    uint64_t ****l_2151[5][1] = {{&g_516},{&g_516},{&g_516},{&g_516},{&g_516}};
    uint32_t l_2164 = 0x432F0608L;
    int32_t l_2217 = 0x224D1079L;
    uint64_t l_2219 = 3UL;
    union U1 l_2246 = {0x76B69D4AL};
    uint64_t l_2265 = 1UL;
    uint64_t l_2285 = 18446744073709551615UL;
    uint8_t *l_2340 = &g_980;
    uint8_t **l_2339 = &l_2340;
    const uint16_t *l_2407 = &g_207;
    const uint16_t **l_2406 = &l_2407;
    const uint16_t ***l_2405 = &l_2406;
    uint16_t *l_2490 = &g_207;
    uint16_t **l_2489 = &l_2490;
    uint16_t ***l_2488 = &l_2489;
    uint16_t ****l_2487 = &l_2488;
    uint8_t ****l_2574[1][5];
    const uint32_t ****l_2581 = &l_2038;
    const uint32_t *****l_2580 = &l_2581;
    uint32_t *** const *l_2582 = &g_1179;
    uint32_t *** const **l_2583 = &l_2582;
    uint32_t *** const *l_2585[4];
    uint32_t *** const **l_2584 = &l_2585[2];
    uint32_t *l_2586 = &g_2346;
    int64_t *l_2595 = &g_197;
    int i, j;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 5; j++)
            l_2574[i][j] = (void*)0;
    }
    for (i = 0; i < 4; i++)
        l_2585[i] = (void*)0;
    if (l_2016)
    { /* block id: 894 */
        (*g_125) = g_2017[2];
    }
    else
    { /* block id: 896 */
        uint16_t *l_2020 = &g_207;
        int32_t l_2025 = 1L;
        int8_t *** const l_2029 = &g_272;
        union U1 l_2053 = {4294967295UL};
        int32_t l_2063 = 1L;
        uint16_t l_2074 = 0x5FEFL;
        const struct S0 **l_2115 = (void*)0;
        int32_t *l_2118 = &g_206;
        int32_t l_2121 = 0xE7F2BF06L;
        int32_t l_2125[3][5] = {{0x16D98D3EL,0x16D98D3EL,(-2L),0x16D98D3EL,0x16D98D3EL},{2L,(-6L),2L,2L,(-6L)},{0x16D98D3EL,0L,0L,0x16D98D3EL,0L}};
        uint16_t l_2126 = 65535UL;
        uint64_t **l_2149 = &g_116;
        uint64_t **l_2150 = &g_116;
        int32_t l_2196 = 0x6F4C2C49L;
        int32_t **l_2229 = (void*)0;
        int32_t ***l_2228 = &l_2229;
        uint32_t l_2230 = 1UL;
        struct S0 **l_2237 = &g_125;
        struct S0 ***l_2236 = &l_2237;
        uint32_t l_2269 = 4294967295UL;
        uint16_t l_2272 = 0xC9DEL;
        struct S0 *l_2350 = &g_121;
        uint32_t l_2393[4][3] = {{1UL,1UL,1UL},{0xC37069E5L,0UL,0xC37069E5L},{1UL,1UL,1UL},{0xC37069E5L,0UL,0xC37069E5L}};
        const uint32_t *l_2466 = &g_2467;
        const uint32_t **l_2465 = &l_2466;
        uint16_t ***l_2498 = &l_2489;
        int32_t l_2551 = 0xF4781F18L;
        int32_t l_2552 = 0L;
        int i, j;
        if (((safe_mod_func_uint16_t_u_u(((void*)0 != l_2020), 0x17F0L)) ^ (safe_mul_func_uint16_t_u_u((0xAEL && ((safe_lshift_func_int16_t_s_u(l_2016, ((l_2025 > ((((safe_sub_func_int8_t_s_s((g_2028 , (l_2029 != &g_272)), p_10)) , p_10) <= l_2016) & p_10)) && 4294967295UL))) , 0xBDL)), p_10))))
        { /* block id: 897 */
            const uint32_t ****l_2041 = (void*)0;
            const uint32_t ****l_2042 = &l_2038;
            int32_t *l_2043 = &g_198;
            int32_t *l_2044 = &g_54;
            const union U1 l_2045 = {0x08A351E7L};
            int32_t *l_2046 = (void*)0;
            int32_t *l_2047[6] = {&g_3[6],&g_3[6],&g_3[1],&g_3[6],&g_3[6],&g_3[1]};
            int i;
            l_2048[2][5] ^= ((((*l_2044) = ((p_10 ^ ((void*)0 == &g_431)) , ((*l_2043) = ((0xD46EDBEDA680CB67LL || ((safe_unary_minus_func_int8_t_s((safe_unary_minus_func_int8_t_s((safe_add_func_int64_t_s_s((safe_rshift_func_uint16_t_u_s(((void*)0 != &g_1105), 5)), (safe_div_func_uint64_t_u_u((((*g_125) , (*g_1104)) != ((*l_2042) = (l_2025 , l_2038))), 18446744073709551614UL)))))))) <= p_11)) & p_11)))) , l_2045) , p_10);
        }
        else
        { /* block id: 902 */
            int32_t *l_2049[8] = {&g_499,&g_499,&g_499,&g_499,&g_499,&g_499,&g_499,&g_499};
            int32_t **l_2051[3];
            uint16_t **l_2062 = (void*)0;
            uint16_t *** const l_2061 = &l_2062;
            uint16_t l_2068 = 0xC676L;
            int64_t *l_2069 = &g_197;
            uint8_t *l_2216[7][4][4] = {{{(void*)0,&g_1245,&g_840,&g_1245},{&g_85,&g_980,&g_85,(void*)0},{&g_1245,&g_85,&g_840,&l_2016},{&g_840,&g_1245,&g_1245,&g_980}},{{&g_85,&g_85,&l_2016,&g_840},{&g_840,&l_2016,&g_840,&g_840},{&g_980,&g_85,&g_840,&g_840},{&g_840,&g_85,&g_85,&g_980}},{{(void*)0,(void*)0,&g_840,&g_840},{&g_85,&g_840,&g_1245,&g_1245},{&g_840,&g_840,&l_2016,(void*)0},{&g_840,(void*)0,&g_840,&l_2016}},{{&g_840,&g_980,&g_980,&g_840},{&g_1245,&g_980,&g_980,&l_2016},{&g_980,(void*)0,&g_980,(void*)0},{&g_85,&g_840,&g_85,&g_1245}},{{&g_840,&g_840,(void*)0,&g_840},{&g_85,(void*)0,&g_1245,&g_980},{&g_980,&g_85,(void*)0,&g_840},{&g_1245,&g_85,&g_85,&g_840}},{{&l_2016,&l_2016,&g_1245,&g_840},{&g_840,&g_85,&g_1245,&g_980},{(void*)0,&g_1245,&g_85,&l_2016},{&g_85,&g_85,&g_85,(void*)0}},{{&g_85,&g_980,(void*)0,&g_1245},{&g_840,&g_1245,&g_1245,&g_980},{&g_980,&g_980,&g_1245,&g_980},{&g_840,&l_2016,(void*)0,&g_85}}};
            int16_t *l_2218 = (void*)0;
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_2051[i] = &l_2049[1];
            l_2052 = l_2049[1];
lbl_2129:
            (*l_2052) |= (((*g_125) , (l_2053 , g_2054)) , (*g_1147));
            if ((safe_mul_func_uint8_t_u_u(p_11, ((((((safe_mul_func_int16_t_s_s(l_2053.f1, (safe_lshift_func_uint16_t_u_s(0x5FCEL, 10)))) && ((void*)0 != l_2061)) , (0x89L || (l_2063 != ((*l_2069) = ((p_10 != (safe_div_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(l_2068, (*l_2052))), p_12))) <= (-1L)))))) | p_10) , p_12) , 0x2FL))))
            { /* block id: 906 */
                int32_t l_2091 = (-1L);
                int32_t l_2112 = 0L;
                int32_t l_2114 = (-10L);
                int32_t *l_2131 = &l_2025;
                for (g_79 = (-9); (g_79 != 39); g_79 = safe_add_func_uint32_t_u_u(g_79, 8))
                { /* block id: 909 */
                    int16_t **l_2090 = &g_242;
                    int64_t l_2094 = 3L;
                    int32_t l_2122 = 0x9D33B0A7L;
                    int32_t l_2123 = (-1L);
                    for (g_1586 = 0; (g_1586 <= 13); g_1586 = safe_add_func_uint32_t_u_u(g_1586, 6))
                    { /* block id: 912 */
                        int8_t l_2085 = (-4L);
                        (*g_1147) = (p_11 ^ ((*l_2069) = (l_2074 <= (((safe_mod_func_int64_t_s_s((safe_rshift_func_int16_t_s_u(((safe_mod_func_uint16_t_u_u(((*l_2020) |= ((void*)0 == &g_521)), (((((safe_rshift_func_uint16_t_u_s(p_11, ((*g_242) >= (safe_sub_func_int16_t_s_s(0x5F13L, l_2085))))) , (safe_lshift_func_uint16_t_u_u((safe_mul_func_int16_t_s_s((((((void*)0 != l_2090) < 0x6C81BD2F356F554ELL) && p_11) && p_10), 0xE4AEL)), (*l_2052)))) , 0xCA68L) | (-8L)) || p_11))) | l_2091), 7)), (-1L))) , (void*)0) != (*g_1180)))));
                    }
                    for (g_198 = 0; (g_198 <= 2); g_198 += 1)
                    { /* block id: 919 */
                        uint8_t *l_2099 = &g_85;
                        int32_t l_2104[3][4] = {{0xB43F6DE9L,0xB43F6DE9L,0x53458228L,0xB43F6DE9L},{0xB43F6DE9L,0x080B9380L,0x080B9380L,0xB43F6DE9L},{0x080B9380L,0xB43F6DE9L,0x080B9380L,0x080B9380L}};
                        uint8_t *l_2117 = &g_980;
                        int i, j;
                        l_2118 = (l_2049[(g_198 + 4)] = func_21(((*l_2117) = (safe_add_func_uint16_t_u_u((((**g_1002) = (((l_2094 == (g_85 &= (0x746E40E05A9E6B05LL | (-1L)))) , ((**l_2090) ^= (safe_sub_func_int16_t_s_s(1L, ((*l_2020) ^= (safe_mul_func_uint8_t_u_u(((*l_2099)--), 252UL))))))) == (((safe_lshift_func_uint16_t_u_s((((l_2104[0][2] && (safe_mul_func_uint8_t_u_u((safe_unary_minus_func_uint16_t_u((l_2114 = ((safe_mul_func_int8_t_s_s((p_10 <= ((l_2112 = (safe_mod_func_int8_t_s_s(p_11, l_2104[1][3]))) > 0x45L)), l_2113)) ^ 0x1AF64B2A164B298ELL)))), 0L))) != 0x958B7ABBL) & 4294967295UL), l_2074)) , l_2115) != l_2116))) , 65534UL), l_2104[0][2]))), p_12, l_2099, p_11));
                        (**g_1622) = (safe_div_func_int16_t_s_s(p_12, p_12));
                        (*l_2052) = ((*g_242) != p_11);
                    }
                    if (((**g_1180) < p_12))
                    { /* block id: 933 */
                        (*g_125) = (*g_125);
                        (*g_1149) = (***g_1620);
                    }
                    else
                    { /* block id: 936 */
                        int32_t l_2124 = 2L;
                        --l_2126;
                    }
                }
                for (g_840 = 0; (g_840 <= 0); g_840 += 1)
                { /* block id: 942 */
                    uint64_t **l_2148 = &g_116;
                    int i;
                    (**l_2116) = (**l_2116);
                    if (p_10)
                        goto lbl_2129;
                    for (g_79 = 0; (g_79 <= 2); g_79 += 1)
                    { /* block id: 947 */
                        l_2131 = (l_2130 = (*g_1614));
                    }
                    if ((safe_mul_func_int16_t_s_s((safe_rshift_func_uint16_t_u_u(((*l_2020)++), ((*l_2052) < ((safe_lshift_func_int8_t_s_u(((***l_2029) = (safe_add_func_int32_t_s_s(((safe_sub_func_int8_t_s_s(((&g_520 != ((((p_11 & (safe_div_func_int64_t_s_s(0x5A7CD8A5E5D00D6CLL, 0x42DFC24FFB797793LL))) | (p_12 <= p_12)) , ((safe_add_func_uint16_t_u_u(((((**l_2116) , (l_2149 = l_2148)) != l_2150) , p_11), 1L)) > 0x475AL)) , l_2151[3][0])) != 8UL), g_187)) == p_12), 9L))), g_3[6])) > p_11)))), 0x7812L)))
                    { /* block id: 954 */
                        uint8_t l_2162[1][4][1] = {{{0xD4L},{3UL},{0xD4L},{3UL}}};
                        int i, j, k;
                        (*l_2052) = (((*g_242) ^= (safe_lshift_func_uint8_t_u_s(((((*l_2020) = 0xE5AAL) != 65535UL) && (safe_lshift_func_int16_t_s_u((safe_add_func_int64_t_s_s((((((0x17093E34L == (safe_sub_func_uint16_t_u_u((safe_sub_func_int64_t_s_s(l_2162[0][3][0], p_11)), ((~((((*g_1181) = 0x8C9AF8B0L) || (l_2162[0][3][0] , ((((((*g_273) &= p_12) , l_2162[0][3][0]) == p_10) != 0UL) && (*l_2052)))) || 1UL)) >= (***g_430))))) , 0UL) && 0x186F30CFL) >= (****g_1620)) >= l_2162[0][2][0]), (**g_521))), g_781))), p_10))) & p_12);
                        ++l_2164;
                        (*g_1614) = &p_11;
                    }
                    else
                    { /* block id: 962 */
                        uint16_t l_2181[7] = {0x33C3L,0x33C3L,0x33C3L,0x33C3L,0x33C3L,0x33C3L,0x33C3L};
                        int16_t *l_2182 = (void*)0;
                        int16_t *l_2183 = (void*)0;
                        int16_t *l_2184 = (void*)0;
                        int16_t *l_2185 = &g_306[1][0][6];
                        uint8_t *l_2189 = &g_980;
                        int i;
                        if (p_12)
                            break;
                        (*g_125) = ((safe_sub_func_uint32_t_u_u(((p_11 != (safe_add_func_int64_t_s_s((p_12 == (safe_mul_func_uint16_t_u_u((--(*l_2020)), (safe_mul_func_int8_t_s_s((safe_mod_func_uint8_t_u_u(((((safe_lshift_func_int16_t_s_s((l_2053 , l_2181[3]), ((*l_2185) |= (*g_242)))) , (((!(((*l_2189) ^= (safe_rshift_func_int8_t_s_u(p_12, g_1176[1].f1))) , (&g_1245 != (void*)0))) == g_203) != p_10)) | g_187) | (*g_242)), p_11)), p_11))))), l_2181[3]))) > l_2025), p_11)) , g_2190);
                        l_2131 = (*g_1614);
                    }
                    for (g_85 = 1; (g_85 <= 7); g_85 += 1)
                    { /* block id: 972 */
                        int i, j;
                        l_2131 = &l_2048[(g_840 + 4)][(g_840 + 4)];
                    }
                }
            }
            else
            { /* block id: 976 */
                (**l_2116) = g_2191[0];
            }
            p_11 |= (safe_mod_func_uint16_t_u_u(g_1138.f1, (((safe_mul_func_uint8_t_u_u((((((65535UL ^ (l_2196 != (((safe_div_func_uint32_t_u_u(((safe_div_func_int64_t_s_s((safe_mul_func_int8_t_s_s(((void*)0 != g_125), (safe_sub_func_uint8_t_u_u(((safe_div_func_uint8_t_u_u(((((-8L) > (safe_add_func_uint16_t_u_u(g_218.f0, (safe_mul_func_uint8_t_u_u(1UL, (safe_unary_minus_func_uint32_t_u((((safe_lshift_func_uint8_t_u_u((g_85 = ((safe_mul_func_uint8_t_u_u((g_980 = (g_840 = g_77)), 0L)) > 0x18FE489D95BC7E12LL)), g_1172)) <= g_207) && (**g_431))))))))) > g_207) <= (**g_1180)), (*l_2052))) > 0x87094A8490D42AA5LL), p_12)))), 0x407D85B59B5BF14ALL)) && l_2217), 0x2572C9DBL)) <= p_10) || 0xE0171A42E9325C57LL))) ^ 1UL) , l_2218) == l_2020) >= l_2219), p_12)) > g_197) && (***g_430))));
        }
        p_11 = (((*g_116) , (((((p_11 != (*l_2052)) || (safe_add_func_int64_t_s_s((6L >= 0xA980638AE6CAB7C2LL), ((safe_div_func_uint8_t_u_u((((((safe_sub_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u((l_2228 != &l_2229), l_2230)), p_10)) >= (*l_2052)) ^ (-1L)) && (**g_272)) && g_265.f1), p_11)) < 0x261D59F6D0E5C27DLL)))) <= p_12) & (*g_1181)) & p_11)) < p_12);
        (*l_2052) = (((-7L) <= (p_12 || (g_2017[2].f0 != ((((void*)0 != l_2029) == ((((safe_add_func_int64_t_s_s((!(((*g_242) ^= ((safe_mod_func_uint16_t_u_u(65535UL, (((g_453 < (&g_125 != ((*l_2236) = (l_2116 = &g_125)))) || (*l_2052)) , (-1L)))) , 0xC8D9L)) , (*l_2052))), (*l_2052))) <= p_12) , 0xB87BL) , (*g_242))) || 0xE6F2L)))) | p_12);
        for (g_380 = 0; (g_380 >= (-5)); g_380 = safe_sub_func_int8_t_s_s(g_380, 6))
        { /* block id: 991 */
            int16_t * const l_2241[10][10][2] = {{{&g_191[8],&g_306[1][0][6]},{&g_306[1][0][6],&g_306[0][0][1]},{&g_191[8],&g_306[1][0][6]},{&g_191[8],&g_306[0][0][1]},{&g_191[8],&g_191[8]},{&g_306[1][0][6],&g_306[1][0][6]},{&g_191[6],(void*)0},{&g_306[1][0][6],&g_191[8]},{&g_306[1][0][6],&g_191[8]},{&g_306[0][0][4],&g_306[1][0][6]}},{{(void*)0,&g_191[8]},{&g_306[1][0][6],(void*)0},{&g_306[1][0][0],&g_306[1][0][6]},{&g_191[8],&g_306[1][0][5]},{&g_306[1][0][6],&g_306[1][0][6]},{&g_306[1][0][5],&g_306[1][0][6]},{&g_191[7],&g_191[8]},{&g_306[1][0][6],&g_306[1][0][6]},{&g_191[8],(void*)0},{&g_306[0][0][4],(void*)0}},{{&g_191[8],&g_191[8]},{&g_191[5],&g_191[8]},{&g_191[8],(void*)0},{&g_306[0][0][4],&g_191[8]},{(void*)0,&g_306[1][0][0]},{&g_306[0][0][1],&g_191[5]},{&g_306[0][0][6],&g_191[8]},{&g_306[1][0][7],&g_191[8]},{&g_306[1][0][5],&g_306[1][0][7]},{&g_191[8],&g_191[8]}},{{&g_191[5],&g_191[8]},{&g_306[1][0][5],(void*)0},{&g_191[8],&g_191[8]},{(void*)0,&g_191[6]},{&g_306[0][0][1],(void*)0},{&g_306[1][0][0],&g_191[8]},{(void*)0,&g_306[0][0][1]},{&g_191[8],&g_191[0]},{&g_191[6],&g_191[8]},{(void*)0,&g_306[0][0][1]}},{{&g_306[0][0][4],&g_191[8]},{&g_306[1][0][0],&g_306[1][0][0]},{(void*)0,&g_191[6]},{&g_306[0][0][6],&g_191[8]},{&g_191[8],&g_191[8]},{(void*)0,&g_191[8]},{&g_191[8],(void*)0},{&g_191[8],&g_191[8]},{(void*)0,&g_191[8]},{&g_191[8],&g_191[8]}},{{&g_306[0][0][6],&g_191[6]},{(void*)0,&g_306[1][0][0]},{&g_306[1][0][0],&g_191[8]},{&g_306[0][0][4],&g_306[0][0][1]},{(void*)0,&g_191[8]},{&g_191[6],&g_191[0]},{&g_191[8],&g_306[0][0][1]},{(void*)0,&g_191[8]},{&g_306[1][0][0],(void*)0},{&g_306[0][0][1],&g_191[6]}},{{(void*)0,&g_191[8]},{&g_191[8],(void*)0},{&g_306[1][0][5],&g_191[8]},{&g_191[5],&g_191[8]},{&g_191[8],&g_306[1][0][7]},{&g_306[1][0][5],&g_191[8]},{&g_306[1][0][7],&g_191[8]},{&g_306[0][0][6],&g_191[5]},{&g_306[0][0][1],&g_306[1][0][0]},{(void*)0,&g_191[8]}},{{&g_306[0][0][4],(void*)0},{&g_191[8],&g_191[8]},{&g_191[5],&g_191[8]},{&g_191[8],(void*)0},{&g_306[0][0][4],&g_191[8]},{(void*)0,&g_306[1][0][0]},{&g_306[0][0][1],&g_191[5]},{&g_306[0][0][6],&g_191[8]},{&g_306[1][0][7],&g_191[8]},{&g_306[1][0][5],&g_306[1][0][7]}},{{&g_191[8],&g_191[8]},{&g_191[5],&g_191[8]},{&g_306[1][0][5],(void*)0},{&g_191[8],&g_191[8]},{(void*)0,&g_191[6]},{&g_306[0][0][1],(void*)0},{&g_306[1][0][0],&g_191[8]},{(void*)0,&g_306[0][0][1]},{&g_191[8],&g_191[0]},{&g_191[6],&g_191[8]}},{{(void*)0,&g_306[0][0][1]},{&g_306[0][0][4],&g_191[8]},{&g_306[1][0][0],&g_306[1][0][0]},{(void*)0,&g_191[6]},{&g_306[0][0][6],&g_191[8]},{&g_191[8],&g_191[8]},{(void*)0,&g_191[8]},{&g_191[8],(void*)0},{&g_191[8],&g_191[8]},{(void*)0,&g_191[8]}}};
            uint8_t *l_2242 = &g_980;
            int32_t l_2245 = 0L;
            int64_t *l_2247 = &g_197;
            int64_t *l_2248 = &g_574;
            uint32_t **l_2273 = &g_1003;
            int32_t l_2277 = 0x37D1EA68L;
            int32_t l_2279[2][3] = {{(-7L),4L,4L},{(-7L),4L,4L}};
            int32_t l_2288 = 0L;
            int16_t l_2312[3];
            const union U1 l_2338 = {0UL};
            int32_t ****l_2360[3];
            int32_t *****l_2359 = &l_2360[1];
            uint32_t l_2366 = 0UL;
            int32_t l_2391 = 0xDB075ABAL;
            uint32_t l_2408 = 0UL;
            const uint32_t *l_2463[8][2][8] = {{{&g_142,&g_781,&l_2408,&g_142,&l_2408,&g_781,&g_142,&l_2393[3][0]},{&g_1586,&l_2393[1][0],(void*)0,&g_142,&g_142,(void*)0,&l_2393[1][0],&g_1586}},{{&l_2393[3][0],&g_142,&g_781,&l_2408,&g_142,&l_2408,&g_781,&l_2393[3][0]},{&l_2408,(void*)0,&g_1586,&l_2408,&l_2393[3][0],&l_2393[3][0],&l_2408,&g_1586}},{{&l_2393[3][0],&l_2393[3][0],&g_142,&g_781,&l_2408,&g_142,&l_2408,&g_781},{&g_1586,&g_781,&g_1586,&l_2393[3][0],&g_781,(void*)0,(void*)0,&g_781}},{{&g_781,(void*)0,(void*)0,&g_781,&l_2393[3][0],&g_1586,&g_781,&g_1586},{&g_781,&l_2408,&g_142,&l_2408,&g_781,&g_142,&l_2393[3][0],&l_2393[3][0]}},{{&g_1586,&l_2408,&l_2393[3][0],&l_2393[3][0],&l_2408,&g_1586,(void*)0,&l_2408},{&l_2393[3][0],(void*)0,&l_2393[3][0],&l_2393[3][0],&l_2393[3][0],(void*)0,&l_2393[3][0],&g_1586}},{{&l_2408,&g_781,&g_142,&l_2393[3][0],&l_2393[3][0],&g_142,&g_781,&l_2408},{&g_1586,&l_2393[3][0],(void*)0,&l_2393[3][0],&l_2393[3][0],&l_2393[3][0],(void*)0,&l_2393[3][0]}},{{&l_2408,(void*)0,&g_1586,&l_2408,&l_2393[3][0],&l_2393[3][0],&l_2408,&g_1586},{&l_2393[3][0],&l_2393[3][0],&g_142,&g_781,&l_2408,&g_142,&l_2408,&g_781}},{{&g_1586,&g_781,&g_1586,&l_2393[3][0],&g_781,(void*)0,(void*)0,&g_781},{&g_781,(void*)0,(void*)0,&g_781,&l_2393[3][0],&g_1586,&g_781,&g_1586}}};
            const uint32_t **l_2462 = &l_2463[3][0][4];
            int32_t *** const l_2496 = &l_2229;
            uint16_t **l_2520 = &g_2501;
            uint8_t ***l_2572 = (void*)0;
            uint8_t ****l_2571 = &l_2572;
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_2312[i] = 0x45A9L;
            for (i = 0; i < 3; i++)
                l_2360[i] = (void*)0;
        }
    }
    (*l_2052) = (safe_add_func_int8_t_s_s(((***g_1179) != (((((*l_2580) = &l_2038) == ((*l_2584) = ((*l_2583) = l_2582))) & p_11) < ((*l_2586) &= 0x9DCF5AF9L))), ((void*)0 != (*g_2317))));
    (*l_2052) ^= 0x74A4447EL;
    (**g_1622) |= (safe_rshift_func_uint16_t_u_u(((safe_div_func_uint64_t_u_u(p_12, (safe_lshift_func_uint8_t_u_u(p_11, p_12)))) > (safe_lshift_func_uint8_t_u_s(((((*l_2595) ^= p_10) < 6L) , 0x8EL), (((safe_div_func_int64_t_s_s(((p_11 , (*l_2052)) < 0L), 0x81D2320A0211C2E6LL)) , l_2586) == l_2586)))), 3));
    return &g_265;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint8_t  func_15(int32_t * const  p_16, int32_t * const  p_17, int32_t * p_18)
{ /* block id: 890 */
    int64_t l_2014 = (-8L);
    return l_2014;
}


/* ------------------------------------------ */
/* 
 * reads : g_125 g_126 g_1622 g_1147 g_1148 g_471 g_472 g_242 g_191 g_265.f0 g_1640 g_273 g_77 g_116 g_218.f1 g_1180 g_1181 g_1172 g_187 g_203 g_79 g_781 g_1389 g_1390 g_1391 g_249 g_54 g_272 g_521 g_1621 g_1452 g_223 g_1620 g_1614 g_980 g_121.f1 g_337 g_499 g_218.f0 g_1364 g_552 g_198 g_207 g_1149 g_1179 g_840 g_129.f0 g_1591 g_1176.f0 g_380 g_1555 g_431 g_432 g_117 g_124.f0 g_1868 g_1594.f1 g_1901 g_123.f1 g_1286 g_1138.f1 g_85 g_430 g_306
 * writes: g_207 g_126 g_1172 g_1148 g_191 g_187 g_203 g_197 g_29 g_552 g_337 g_77 g_1591 g_223 g_79 g_122 g_840 g_980 g_1390 g_574 g_1868 g_1901 g_54 g_380 g_85
 */
static int32_t * const  func_19(int32_t * p_20)
{ /* block id: 578 */
    int32_t l_1319 = 0L;
    const int64_t *l_1338 = &g_197;
    union U1 *l_1351 = (void*)0;
    const struct S0 *l_1371 = &g_1176[0];
    int32_t l_1393 = 0xF7CD947FL;
    int32_t l_1402 = 0xBAB461CDL;
    int32_t l_1404 = 0L;
    int16_t l_1407[4][1] = {{(-1L)},{3L},{(-1L)},{3L}};
    int32_t l_1408 = 0x21D9B05BL;
    uint64_t l_1409 = 18446744073709551612UL;
    union U1 ***l_1426 = (void*)0;
    int32_t l_1457 = 1L;
    int64_t l_1458 = (-3L);
    int32_t l_1459[2][4] = {{(-6L),1L,1L,(-6L)},{1L,(-6L),1L,1L}};
    int64_t l_1461 = 0x08EBEB049BF3EF7ALL;
    int16_t l_1463[6][9] = {{0x491EL,0L,0x491EL,1L,0x491EL,0L,0x491EL,1L,0x491EL},{(-4L),(-4L),0xC577L,0x6911L,4L,4L,0x6911L,0xC577L,(-4L)},{0x12C0L,1L,0x9F34L,1L,0x12C0L,1L,0x9F34L,1L,0x12C0L},{4L,0x6911L,0xC577L,(-4L),(-4L),0xC577L,0x6911L,4L,4L},{0x491EL,1L,0x491EL,0L,0x491EL,1L,0x491EL,0L,0x491EL},{4L,(-4L),0x6911L,0x6911L,(-4L),4L,0xC577L,0xC577L,4L}};
    const int16_t **l_1485[3][1];
    const int16_t ***l_1484 = &l_1485[2][0];
    int8_t l_1537[9] = {(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)};
    int32_t l_1549[9][4] = {{0L,0L,(-7L),(-5L)},{0L,(-9L),0xBE606F6EL,0L},{0x6069CB1FL,(-5L),0L,(-2L)},{0xBE606F6EL,(-9L),0L,0x6069CB1FL},{(-9L),(-7L),(-7L),(-9L)},{0L,0x6069CB1FL,(-7L),(-2L)},{(-9L),0xBE606F6EL,0L,0xBE606F6EL},{0xBE606F6EL,(-7L),0L,0xBE606F6EL},{0L,0xBE606F6EL,(-2L),(-2L)}};
    int32_t *l_1625 = (void*)0;
    const uint32_t l_1666 = 18446744073709551608UL;
    uint8_t l_1696 = 0xC6L;
    int32_t **l_1707 = &l_1625;
    int32_t ***l_1706 = &l_1707;
    uint64_t **l_1757 = &g_116;
    const uint64_t * const l_1787 = &g_1788;
    const uint64_t * const *l_1786[3][5] = {{&l_1787,&l_1787,(void*)0,(void*)0,&l_1787},{&l_1787,&l_1787,(void*)0,&l_1787,&l_1787},{&l_1787,&l_1787,&l_1787,(void*)0,&l_1787}};
    const uint64_t * const **l_1785 = &l_1786[2][2];
    uint16_t *l_1805 = (void*)0;
    int i, j;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
            l_1485[i][j] = (void*)0;
    }
lbl_1752:
    for (g_207 = 2; (g_207 <= 8); g_207 += 1)
    { /* block id: 581 */
        uint64_t l_1330 = 0xB75DFDBDC6EF7E8ALL;
        uint8_t l_1333 = 1UL;
        int32_t l_1339 = 5L;
        int32_t *l_1340 = &g_380;
        uint8_t *l_1341 = (void*)0;
        uint8_t *l_1342 = &g_840;
        int64_t l_1365 = 1L;
        int32_t l_1399 = 0x5EE2BC3CL;
        int32_t l_1401 = 0xC9DB37A1L;
        int32_t l_1403[2][4][5] = {{{0L,(-1L),(-1L),(-1L),0L},{(-7L),(-1L),0x0902BB6DL,0L,0x0902BB6DL},{0x0902BB6DL,0x0902BB6DL,(-1L),0L,0xAC05614BL},{(-1L),(-7L),(-7L),(-1L),0x0902BB6DL}},{{(-1L),0L,0x90DABCF6L,0x90DABCF6L,0L},{0x0902BB6DL,(-7L),0x90DABCF6L,(-1L),(-1L)},{(-7L),0x0902BB6DL,(-7L),0x90DABCF6L,(-1L)},{0L,(-1L),(-1L),(-1L),0L}}};
        struct S0 **l_1421 = &g_125;
        int32_t l_1425 = 1L;
        int32_t l_1460 = (-1L);
        uint16_t *l_1500 = &g_552;
        int64_t l_1616 = (-3L);
        int i, j, k;
    }
lbl_1658:
    (*g_125) = (*g_125);
    for (g_207 = 0; (g_207 <= 7); g_207++)
    { /* block id: 713 */
        uint32_t l_1633 = 0UL;
        int32_t l_1655 = 0L;
        uint32_t l_1683[3];
        int32_t l_1687 = (-1L);
        int32_t l_1689 = 7L;
        int32_t l_1690 = 0x08629817L;
        int32_t l_1692 = 0x0CCD04FBL;
        int32_t l_1693[5];
        int32_t l_1711 = 0x8D17ACB2L;
        uint64_t ****l_1719 = &g_516;
        int32_t ****l_1723 = &l_1706;
        struct S0 *l_1749 = &g_120;
        uint16_t l_1793 = 0x2B94L;
        union U1 l_1860 = {4294967295UL};
        int8_t **l_1864 = &g_273;
        uint16_t l_1865 = 0xEA4EL;
        uint32_t * const *l_1873 = &g_1181;
        uint32_t * const **l_1872 = &l_1873;
        uint32_t * const ***l_1871 = &l_1872;
        uint32_t l_1879 = 18446744073709551615UL;
        int32_t l_1911 = 0x67B394C1L;
        uint16_t **** const *l_1917 = (void*)0;
        uint8_t *l_1971 = (void*)0;
        uint8_t *l_1972 = &l_1696;
        int8_t l_1979 = 0x34L;
        int32_t l_1994 = 0x88402E4FL;
        uint16_t *l_2002 = &l_1865;
        uint16_t *l_2005 = (void*)0;
        int16_t l_2006 = 0x5A1FL;
        uint8_t *l_2007 = &g_980;
        int8_t *l_2008 = (void*)0;
        int8_t *l_2009 = &g_1591;
        int32_t *l_2010 = (void*)0;
        int32_t *l_2011 = (void*)0;
        int32_t *l_2012 = &g_54;
        int i;
        for (i = 0; i < 3; i++)
            l_1683[i] = 3UL;
        for (i = 0; i < 5; i++)
            l_1693[i] = 0xF23C8442L;
        for (g_1172 = 0; (g_1172 == 43); g_1172++)
        { /* block id: 716 */
            (**g_1622) |= ((safe_div_func_uint32_t_u_u(4294967293UL, l_1633)) && l_1633);
        }
        if ((l_1633 | ((void*)0 == (*g_471))))
        { /* block id: 719 */
            int32_t l_1651 = 0x6046F8F2L;
            uint16_t *l_1656 = &g_552;
            int32_t l_1688[5][4][1] = {{{8L},{1L},{(-1L)},{0xAE3A3107L}},{{0x1FB3434FL},{0xAE3A3107L},{(-1L)},{1L}},{{8L},{0L},{8L},{1L}},{{(-1L)},{0xAE3A3107L},{0x1FB3434FL},{0xAE3A3107L}},{{(-1L)},{1L},{8L},{0L}}};
            int16_t l_1695 = (-1L);
            int32_t ***l_1708 = &l_1707;
            int32_t l_1722[5];
            uint64_t **l_1756 = &g_116;
            uint64_t **** const l_1796 = &g_520;
            union U1 ***l_1842 = &g_1391;
            uint32_t ****l_1874 = (void*)0;
            uint8_t l_1929 = 1UL;
            uint8_t l_1933[6] = {0x89L,0x89L,0x89L,0x89L,0x89L,0x89L};
            uint16_t l_1963 = 0x3C8EL;
            int i, j, k;
            for (i = 0; i < 5; i++)
                l_1722[i] = (-1L);
            for (l_1404 = 4; (l_1404 <= (-5)); --l_1404)
            { /* block id: 722 */
                uint16_t * const l_1641 = &g_207;
                int32_t l_1645[9] = {0x6008B5A6L,0x6008B5A6L,5L,0x6008B5A6L,0x6008B5A6L,5L,0x6008B5A6L,0x6008B5A6L,5L};
                int32_t l_1646 = 3L;
                int64_t *l_1652 = &g_197;
                int64_t *l_1653 = (void*)0;
                int64_t *l_1654[4][9][7] = {{{&g_574,&l_1461,&l_1458,(void*)0,&g_574,&l_1461,&l_1458},{&l_1461,&g_574,(void*)0,(void*)0,(void*)0,&l_1458,&l_1458},{&l_1458,&l_1458,&l_1458,&g_574,(void*)0,(void*)0,&l_1458},{&l_1461,&l_1461,&l_1461,&l_1458,(void*)0,&l_1461,&l_1458},{&g_574,&l_1458,(void*)0,&l_1458,(void*)0,&l_1458,&g_574},{&g_574,&l_1461,&l_1458,&l_1458,&g_574,&l_1458,&l_1458},{&l_1461,&l_1458,&g_574,(void*)0,&g_574,&l_1461,&l_1458},{&l_1458,&g_574,&l_1458,&l_1458,&l_1458,(void*)0,&l_1458},{&g_574,&l_1461,(void*)0,&g_574,(void*)0,&l_1458,&l_1458}},{{&g_574,&l_1461,&l_1461,&l_1458,&g_574,&l_1461,&g_574},{&g_574,(void*)0,&l_1458,(void*)0,&g_574,&g_574,&g_574},{(void*)0,&g_574,&l_1461,&g_574,&l_1458,&g_574,&l_1458},{&g_574,&g_574,&g_574,&l_1458,(void*)0,&l_1461,&g_574},{&g_574,&l_1458,&l_1458,(void*)0,&g_574,&g_574,&g_574},{(void*)0,&l_1458,&l_1458,(void*)0,&l_1458,&g_574,(void*)0},{&l_1458,&g_574,&g_574,&g_574,&l_1458,&l_1458,&g_574},{&g_574,&l_1458,&l_1461,&g_574,&l_1458,&g_574,&g_574},{&g_574,&g_574,&l_1461,(void*)0,(void*)0,&l_1458,&l_1458}},{{&g_574,&g_574,&l_1461,(void*)0,(void*)0,&g_574,&g_574},{&l_1458,&g_574,&l_1458,&l_1458,&l_1458,&g_574,&l_1458},{(void*)0,&g_574,&l_1461,&g_574,&l_1458,&g_574,&g_574},{&g_574,&g_574,(void*)0,&g_574,&l_1458,&g_574,&g_574},{&g_574,&l_1458,&l_1461,&l_1458,&g_574,&l_1458,&g_574},{(void*)0,&g_574,&l_1458,&g_574,(void*)0,&g_574,&g_574},{&l_1458,&l_1458,&l_1461,&l_1458,&l_1458,&l_1458,&l_1458},{&l_1458,&l_1458,&l_1461,&g_574,&g_574,&g_574,&g_574},{(void*)0,&g_574,&l_1461,&g_574,&l_1458,&g_574,&l_1458}},{{&g_574,&g_574,&g_574,&l_1458,(void*)0,&l_1461,&g_574},{&g_574,&l_1458,&l_1458,(void*)0,&g_574,&g_574,&g_574},{(void*)0,&l_1458,&l_1458,(void*)0,&l_1458,&g_574,(void*)0},{&l_1458,&g_574,&g_574,&g_574,&l_1458,&l_1458,&g_574},{&g_574,&l_1458,&l_1461,&g_574,&l_1458,&g_574,&g_574},{&g_574,&g_574,&l_1461,(void*)0,(void*)0,&l_1458,&l_1458},{&g_574,&g_574,&l_1461,(void*)0,(void*)0,&g_574,&g_574},{&l_1458,&g_574,&l_1458,&l_1458,&l_1458,&g_574,&l_1458},{(void*)0,&g_574,&l_1461,&g_574,&l_1458,&g_574,&g_574}}};
                uint64_t *l_1657 = &g_29;
                int8_t l_1681 = 0xBBL;
                struct S0 *l_1750 = &g_120;
                int i, j, k;
                (*g_1147) = (safe_add_func_uint32_t_u_u((((*g_242) &= (safe_lshift_func_uint16_t_u_s(0xF798L, 2))) >= (g_265.f0 || (g_1640 , (*g_273)))), (((*l_1657) = (l_1641 == ((safe_add_func_int32_t_s_s((((!0xE0L) || (l_1655 = ((*l_1652) = (l_1645[4] >= (((((l_1646 &= l_1537[7]) ^ ((safe_mod_func_uint32_t_u_u(((safe_div_func_int32_t_s_s(((((((*g_116) = 0x7EB5DADC94519FF1LL) != l_1645[5]) , 0xCAAEL) && l_1651) ^ 1UL), l_1633)) , 4294967295UL), l_1651)) || 0x44L)) < g_218.f1) , (**g_1180)) || l_1633))))) >= l_1645[4]), l_1633)) , l_1656))) && l_1645[4])));
                if (l_1651)
                { /* block id: 730 */
                    int8_t l_1661 = 0x55L;
                    int32_t l_1684 = 2L;
                    int32_t l_1686 = (-1L);
                    int32_t l_1691 = 1L;
                    int32_t l_1694[8] = {0xE7FE722FL,0xE7FE722FL,0xE7FE722FL,0xE7FE722FL,0xE7FE722FL,0xE7FE722FL,0xE7FE722FL,0xE7FE722FL};
                    uint32_t l_1699[6] = {7UL,18446744073709551611UL,7UL,7UL,18446744073709551611UL,7UL};
                    int32_t *l_1702 = &l_1688[2][1][0];
                    int i;
                    if (g_1172)
                        goto lbl_1658;
                    if (((safe_sub_func_uint16_t_u_u(l_1661, (0xC5454EAE34FBF89BLL != (*g_116)))) <= (safe_div_func_int32_t_s_s((safe_mod_func_int8_t_s_s(l_1666, l_1651)), (safe_mod_func_int64_t_s_s((g_79 < (((*g_242) = 0xF58AL) & g_781)), (4294967295UL ^ l_1661)))))))
                    { /* block id: 733 */
                        uint8_t l_1682 = 0x35L;
                        l_1683[1] |= (safe_add_func_int32_t_s_s(((void*)0 != (***g_1389)), ((((((l_1651 ^ ((l_1661 < (safe_div_func_int16_t_s_s((g_54 , l_1633), ((*l_1656) = 65535UL)))) == (((**g_521) = ((safe_mod_func_uint32_t_u_u((safe_div_func_uint8_t_u_u((((safe_lshift_func_int8_t_s_s((l_1661 && l_1645[4]), (**g_272))) , l_1681) <= (-7L)), l_1681)), l_1661)) <= l_1682)) == l_1682))) > 0L) < l_1682) ^ l_1661) < 18446744073709551606UL) > 0x83L)));
                        if ((***g_1621))
                            continue;
                    }
                    else
                    { /* block id: 738 */
                        int32_t *l_1685[5][1][8] = {{{&l_1655,&l_1645[4],&g_3[6],&g_499,&g_3[6],&l_1645[4],&l_1655,&l_1655}},{{&l_1645[4],&g_499,(void*)0,(void*)0,&g_499,&l_1645[4],&l_1549[2][3],&l_1645[4]}},{{&g_499,&l_1645[4],&l_1549[2][3],&l_1645[4],&g_499,(void*)0,(void*)0,&g_499}},{{&l_1645[4],&l_1655,&l_1655,&l_1645[4],&g_3[6],&g_499,&g_3[6],&l_1645[4]}},{{&l_1655,&g_3[6],&l_1655,(void*)0,&l_1549[2][3],&l_1549[2][3],(void*)0,&l_1655}}};
                        int i, j, k;
                        ++l_1696;
                        ++l_1699[3];
                        if ((*g_1147))
                            continue;
                        return (*g_1452);
                    }
                    (*l_1702) &= (****g_1620);
                }
                else
                { /* block id: 745 */
                    int32_t l_1712 = 0x452605EAL;
                    int32_t *****l_1724 = &l_1723;
                    struct S0 *l_1751 = &g_265;
                    for (g_337 = 0; (g_337 > 35); g_337 = safe_add_func_int16_t_s_s(g_337, 5))
                    { /* block id: 748 */
                        int32_t **l_1705 = &l_1625;
                        (*l_1705) = (*g_1614);
                    }
                    l_1708 = l_1706;
                    (*g_1147) |= (((((**g_272) = (safe_sub_func_int8_t_s_s(((l_1711 | (l_1712 < (0xD6L < ((l_1712 >= (((((safe_mul_func_uint16_t_u_u((safe_add_func_int8_t_s_s((safe_mod_func_int64_t_s_s(((void*)0 == l_1719), (l_1692 | ((*l_1657) = (!0L))))), ((((+l_1711) >= (*g_273)) || l_1646) ^ l_1712))), l_1712)) >= l_1722[4]) , 4294967295UL) >= l_1712) , g_980)) ^ l_1689)))) ^ 1L), 0UL))) <= l_1692) <= l_1712) == l_1645[4]);
                    (*g_1147) = (((((((*l_1724) = l_1723) == ((safe_div_func_int32_t_s_s(((safe_sub_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u(((void*)0 == &g_574), (safe_mul_func_int16_t_s_s(0x5B0CL, ((((safe_mul_func_uint8_t_u_u(1UL, (safe_lshift_func_int8_t_s_s((-3L), (safe_div_func_int16_t_s_s(((safe_mul_func_uint16_t_u_u(0x3096L, ((safe_lshift_func_int16_t_s_u(((*g_242) = (safe_lshift_func_uint8_t_u_s((l_1689 = (((safe_lshift_func_int8_t_s_u((g_1591 = (safe_mod_func_uint8_t_u_u(((((**g_272) = ((((l_1749 != (l_1751 = l_1750)) == l_1683[1]) == l_1646) > 0L)) | l_1681) , 1UL), l_1681))), g_781)) < g_121.f1) , l_1712)), l_1646))), g_337)) >= l_1645[1]))) > l_1687), l_1693[4])))))) | g_499) != (*g_116)) ^ l_1712))))), l_1645[4])) >= 0xA9L), (**g_1180))) , &l_1706)) ^ l_1712) , 0x89FEFF8EL) , (**g_272)) & g_218.f0);
                }
            }
            if ((0x9FE728DD06E8116DLL == 0x42F26C16724992C0LL))
            { /* block id: 764 */
                uint64_t l_1769 = 1UL;
                int32_t l_1771 = 0L;
                int32_t l_1772 = 0x02C86950L;
                int32_t l_1833 = 5L;
                int32_t l_1835 = 1L;
                uint64_t l_1836 = 0x59FD926774675DE8LL;
                union U1 ***l_1844 = &g_1391;
                int8_t l_1867[9][10] = {{1L,1L,1L,0x6FL,0x12L,5L,0x73L,1L,0xA2L,0x73L},{0x43L,0x72L,(-6L),0xD6L,0x72L,9L,0x73L,9L,0x72L,0xD6L},{0L,1L,0L,(-6L),0x73L,0x98L,(-6L),(-1L),0x81L,0L},{(-1L),0x43L,0xA2L,0x6FL,1L,(-1L),(-1L),(-1L),(-1L),1L},{0x43L,0L,0L,0x43L,0x81L,0x72L,1L,9L,0L,(-1L)},{0x81L,(-1L),(-6L),0x98L,0x73L,(-6L),0L,1L,0L,(-6L)},{0x6FL,0x43L,1L,0x43L,0x6FL,0xB1L,0xD6L,0x6FL,(-1L),0x73L},{1L,0x81L,0x98L,0x6FL,(-1L),0x72L,0x73L,0x81L,0x81L,0x73L},{9L,0x6FL,(-6L),(-6L),0x6FL,9L,0x98L,0x43L,0x72L,(-6L)}};
                int32_t *l_1870[10] = {&g_206,&g_206,&g_206,&g_206,&g_206,&g_206,&g_206,&g_206,&g_206,&g_206};
                int i, j;
                (**g_1622) |= (g_1364 & l_1683[1]);
                for (l_1695 = 0; (l_1695 <= 0); l_1695 += 1)
                { /* block id: 768 */
                    uint16_t l_1753 = 0UL;
                    int32_t *l_1758[9][3] = {{&l_1393,&l_1687,&l_1687},{(void*)0,(void*)0,(void*)0},{&l_1393,&l_1393,&l_1393},{&g_3[7],(void*)0,(void*)0},{&g_3[6],&g_3[6],&l_1687},{&g_380,(void*)0,(void*)0},{&l_1687,&l_1393,&l_1711},{&g_380,(void*)0,&g_380},{&g_3[6],&l_1687,&l_1711}};
                    uint16_t **l_1768 = (void*)0;
                    uint16_t *** const l_1767 = &l_1768;
                    int8_t *l_1770 = &g_1591;
                    const uint64_t ***l_1782 = (void*)0;
                    const uint64_t ****l_1783 = &l_1782;
                    const uint64_t * const **l_1784[5];
                    int i, j;
                    for (i = 0; i < 5; i++)
                        l_1784[i] = (void*)0;
                    if (g_1172)
                        goto lbl_1752;
                    (***l_1723) = p_20;
                    (**g_1622) |= (l_1459[1][1] &= (4294967295UL >= ((safe_mul_func_uint16_t_u_u(((l_1757 = l_1756) == ((*g_273) , l_1756)), l_1753)) , 0L)));
                    l_1688[3][3][0] |= (safe_mod_func_int64_t_s_s(((safe_mul_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_s(((safe_lshift_func_int8_t_s_u(((*g_273) = ((void*)0 != l_1767)), 7)) | ((*l_1770) = l_1769)), 12)), 0xD2L)) || ((*l_1656)--)), ((**g_521) = (safe_rshift_func_int16_t_s_s(((safe_rshift_func_uint8_t_u_u((+(safe_mul_func_uint8_t_u_u((((*l_1783) = l_1782) == (l_1785 = l_1784[0])), ((safe_div_func_int32_t_s_s(((safe_mul_func_int16_t_s_s(l_1772, (((*g_1620) != (l_1706 = &l_1707)) && g_198))) | l_1793), (*g_1181))) , g_207)))), 7)) && (**g_1180)), 6)))));
                    for (g_79 = 0; (g_79 <= 0); g_79 += 1)
                    { /* block id: 784 */
                        int i, j, k;
                        g_122[(l_1695 + 2)][(g_79 + 3)][l_1695] = (*g_125);
                        (**g_1149) = 0x9D541C72L;
                    }
                }
                if ((((safe_mod_func_uint32_t_u_u((***g_1179), (**g_1180))) | (((&g_520 != l_1796) , (**g_1622)) || (l_1688[2][0][0] & (l_1723 != &g_1621)))) || (safe_div_func_uint32_t_u_u((*g_1181), 0x10B4E857L))))
                { /* block id: 789 */
                    int32_t **l_1801[9] = {&g_223,&g_223,&g_223,&g_223,&g_223,&g_223,&g_223,&g_223,&g_223};
                    int i;
                    (**g_1622) &= (247UL < (l_1772 , (~(((*l_1706) = &g_223) != (((*g_242) | (!l_1771)) , l_1801[1])))));
                    l_1688[2][2][0] &= ((((safe_rshift_func_int8_t_s_s(((void*)0 != &l_1695), 0)) && (g_840 ^= (~(***g_1621)))) , (void*)0) == (l_1656 = l_1805));
                    (**g_1149) &= l_1722[4];
                    for (l_1695 = (-28); (l_1695 > (-10)); l_1695 = safe_add_func_uint64_t_u_u(l_1695, 1))
                    { /* block id: 798 */
                        const uint8_t l_1826 = 7UL;
                        int8_t *l_1829 = (void*)0;
                        int8_t *l_1830 = &g_1591;
                        int32_t l_1831 = (-10L);
                        int64_t l_1832 = 0L;
                        int32_t l_1834[4][10][6] = {{{0x6BD76B98L,1L,0xCF9B98E6L,1L,0xA872E502L,1L},{0x718CD7EEL,0x1947EB8BL,0x718CD7EEL,0x2B348721L,0x219AF3C5L,0xD1E5182BL},{1L,0L,0x46E11BF1L,0x15BDBF1AL,(-10L),0xC545C1EFL},{1L,0x6F2B102AL,0xEE13C03BL,0x15BDBF1AL,0x81E59C25L,1L},{1L,0xB959BEAAL,0x6F2B102AL,1L,0x74B3DC2CL,0x718CD7EEL},{0xCF9B98E6L,0xD1E5182BL,1L,1L,0xF3F9C35AL,0xB959BEAAL},{(-6L),3L,(-10L),0x2B348721L,1L,1L},{0x46E11BF1L,0xC07B5FFDL,0x9166D772L,0x74B3DC2CL,0x10FBCFCDL,0x10FBCFCDL},{0xC545C1EFL,1L,1L,0xC545C1EFL,0xEE13C03BL,0x46E11BF1L},{0L,(-10L),0x81E59C25L,0x9D833E1CL,0L,1L}},{{0xC07B5FFDL,1L,1L,0x4CA42394L,0L,0L},{1L,(-10L),0xA872E502L,0x219AF3C5L,0xEE13C03BL,0x8F86AFC9L},{0x15BDBF1AL,1L,0x2E52FFEDL,0xA872E502L,0x10FBCFCDL,0x2B348721L},{0x718CD7EEL,0xC07B5FFDL,0xD1E5182BL,0x6BD76B98L,1L,0xA872E502L},{0L,3L,0x74B3DC2CL,(-10L),0xF3F9C35AL,0L},{0x74B3DC2CL,0xD1E5182BL,0x77A8DA8EL,0xD1E5182BL,0x74B3DC2CL,1L},{1L,0xB959BEAAL,0x2B348721L,0xF3F9C35AL,0x81E59C25L,0xEE13C03BL},{0x219AF3C5L,0x6F2B102AL,0xC07B5FFDL,0xB959BEAAL,(-10L),0xEE13C03BL},{0x77A8DA8EL,0L,0x2B348721L,0x9166D772L,0x718CD7EEL,1L},{(-10L),0L,0x77A8DA8EL,(-6L),1L,0L}},{{0x2E52FFEDL,1L,0x74B3DC2CL,1L,(-6L),0xA872E502L},{(-5L),1L,0xD1E5182BL,0L,0x2E52FFEDL,0x2B348721L},{0x8F86AFC9L,1L,0x2E52FFEDL,0x2E52FFEDL,1L,0x8F86AFC9L},{3L,0x9D833E1CL,0xA872E502L,0L,0x15BDBF1AL,0L},{1L,1L,1L,0x81E59C25L,(-5L),1L},{1L,0x2B348721L,0x81E59C25L,0L,0x77A8DA8EL,0x46E11BF1L},{3L,0x15BDBF1AL,1L,0x2E52FFEDL,0xA872E502L,0x10FBCFCDL},{0x8F86AFC9L,0L,0x9166D772L,0L,0xB959BEAAL,1L},{(-5L),0x9166D772L,(-10L),1L,(-4L),0xB959BEAAL},{0x2E52FFEDL,0x718CD7EEL,1L,(-6L),1L,0x718CD7EEL}},{{(-10L),0x77A8DA8EL,0x6F2B102AL,0x9166D772L,0L,1L},{0x77A8DA8EL,0x4CA42394L,0xEE13C03BL,0xB959BEAAL,0x8F86AFC9L,0xC545C1EFL},{0x219AF3C5L,0x4CA42394L,0x46E11BF1L,0xF3F9C35AL,0L,1L},{1L,0x77A8DA8EL,0xCF9B98E6L,0xD1E5182BL,1L,1L},{0x74B3DC2CL,0xCF9B98E6L,0x81E59C25L,0x2E52FFEDL,0x46E11BF1L,0xC545C1EFL},{0xC545C1EFL,0x77A8DA8EL,0x6BD76B98L,(-6L),(-5L),0L},{0xCF9B98E6L,0L,3L,1L,1L,3L},{0L,0L,(-6L),0x718CD7EEL,1L,0x77A8DA8EL},{1L,1L,0x2B348721L,(-10L),3L,(-6L)},{0xD8B322E7L,1L,0x2B348721L,0x81E59C25L,0L,0x77A8DA8EL}}};
                        uint8_t *l_1839 = &g_980;
                        int i, j, k;
                        (**g_1149) ^= (-9L);
                        l_1404 &= (safe_add_func_uint16_t_u_u((((((*l_1830) = ((*g_125) , ((**g_272) = ((safe_add_func_uint16_t_u_u((safe_lshift_func_int16_t_s_s(l_1769, (((**l_1756) = 1UL) >= g_129[0][3][3].f0))), (((l_1772 ^= (safe_mod_func_uint8_t_u_u((((*g_242) = (*g_242)) < (((safe_mul_func_int8_t_s_s((-1L), (safe_sub_func_int8_t_s_s(((safe_add_func_int32_t_s_s((-1L), (safe_rshift_func_int16_t_s_u(((safe_div_func_int16_t_s_s(l_1826, (safe_mul_func_uint8_t_u_u(0xA2L, (**g_272))))) <= l_1769), l_1683[1])))) | l_1651), 0xF4L)))) | (*g_1181)) == l_1826)), l_1771))) > g_1591) || (***g_1179)))) & 2L)))) != g_840) | 0x37L) <= 0xFDD7A00BL), g_840));
                        l_1836--;
                        l_1834[0][3][1] |= (((*l_1839)++) && (**g_272));
                    }
                }
                else
                { /* block id: 810 */
                    union U1 ****l_1843 = &g_1390;
                    union U1 ***l_1845 = &g_1391;
                    int32_t l_1859 = 6L;
                    int8_t ***l_1863[2];
                    int64_t *l_1866 = &g_574;
                    int i;
                    for (i = 0; i < 2; i++)
                        l_1863[i] = &g_272;
                    (*g_1147) = (((*g_242) && (((((*l_1843) = l_1842) != (l_1845 = l_1844)) != ((safe_add_func_uint64_t_u_u((l_1771 ^= (((((!(safe_mul_func_int16_t_s_s((safe_div_func_uint8_t_u_u(1UL, (safe_rshift_func_int16_t_s_s((safe_mul_func_int16_t_s_s((safe_mul_func_uint8_t_u_u(g_1176[1].f0, (*g_273))), (((g_552 & l_1833) || (l_1859 > l_1859)) >= 0x4FB1L))), l_1859)))), g_380))) , (-7L)) >= 0L) , g_1555) >= (*g_116))), l_1683[1])) | l_1835)) < 0UL)) ^ 0x6C1389E0L);
                    if ((l_1833 |= (((l_1867[0][4] = ((((l_1860 , 18446744073709551612UL) >= ((*l_1866) = ((((**g_272) = (((((safe_mul_func_uint8_t_u_u(((l_1864 = (void*)0) == &g_273), l_1859)) , ((**g_431) , &l_1845)) == (void*)0) | (l_1865 || g_124.f0)) & 0xFC30L)) ^ l_1859) && 0xC0F696392A20C705LL))) , 1L) < (**g_431))) , 0UL) , 0x7EC06FCEL)))
                    { /* block id: 820 */
                        if (l_1633)
                            goto lbl_1752;
                        return p_20;
                    }
                    else
                    { /* block id: 823 */
                        volatile uint16_t * volatile ****l_1869 = &g_1868;
                        (*l_1869) = g_1868;
                    }
                    (**l_1708) = (*l_1707);
                }
                if ((l_1688[2][2][0] = (l_1402 = l_1772)))
                { /* block id: 830 */
                    (*g_1147) ^= (l_1871 == l_1874);
                    (**l_1708) = (**l_1708);
                }
                else
                { /* block id: 833 */
                    uint32_t l_1880 = 0x140F29D5L;
                    int32_t l_1888 = 1L;
                    int32_t l_1892 = 0xB9A8938DL;
                    int32_t l_1958 = 2L;
                    int32_t l_1962 = 0x3CCC1211L;
                    if ((safe_mul_func_int8_t_s_s(((+6UL) >= (+l_1879)), (**g_272))))
                    { /* block id: 834 */
                        uint32_t l_1887 = 0x1B039DD0L;
                        uint16_t *l_1891 = &l_1793;
                        uint8_t l_1902 = 4UL;
                        uint16_t **l_1921 = &l_1656;
                        uint16_t ***l_1920 = &l_1921;
                        uint16_t ****l_1919[6] = {&l_1920,&l_1920,&l_1920,&l_1920,&l_1920,&l_1920};
                        uint16_t *****l_1918 = &l_1919[2];
                        uint8_t *l_1930 = (void*)0;
                        uint8_t *l_1931 = &g_840;
                        uint8_t *l_1932 = &l_1929;
                        int i;
                        (**g_1622) = l_1880;
                        l_1655 ^= (((g_1901 ^= ((((safe_rshift_func_int8_t_s_s(((g_337 , (l_1880 , (l_1892 = (safe_mul_func_int8_t_s_s((safe_rshift_func_int16_t_s_s(l_1887, (l_1888 = l_1887))), ((safe_mul_func_int16_t_s_s(l_1880, (*g_242))) == ((*l_1891) &= l_1887))))))) != ((safe_mod_func_int32_t_s_s((((*g_273) == (safe_rshift_func_uint16_t_u_u((safe_lshift_func_int8_t_s_s(((safe_sub_func_int16_t_s_s(0x6A68L, l_1695)) , (**g_272)), 6)), g_1594.f1))) ^ 1L), l_1693[4])) || l_1880)), 1)) | g_1364) , l_1888) <= g_1172)) , 0x1E3729C3L) , l_1880);
                        l_1902 |= (***g_1621);
                        l_1888 = (safe_div_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u(((l_1933[4] = ((safe_add_func_int64_t_s_s((((**g_1180) = (safe_rshift_func_int8_t_s_s((l_1911 && (((safe_mul_func_uint16_t_u_u((safe_unary_minus_func_uint8_t_u((safe_mod_func_uint32_t_u_u((((l_1917 = (void*)0) != (((((-9L) < g_123.f1) , l_1892) ^ l_1902) , l_1918)) >= ((((*l_1932) = ((*l_1931) = (safe_lshift_func_uint16_t_u_u((safe_sub_func_int64_t_s_s(((~(safe_mod_func_uint32_t_u_u(((0xEE6EL != (g_191[0] > 0xA818L)) || 0xDF3BL), 1UL))) , g_380), l_1929)), 3)))) ^ g_781) == l_1887)), (**g_1180))))), g_380)) & 18446744073709551613UL) , (***g_1179))), l_1892))) | l_1902), g_1901)) && 0xE5422A36B4907348LL)) <= l_1902), l_1902)), 0x854E1696L));
                    }
                    else
                    { /* block id: 848 */
                        uint64_t l_1934 = 18446744073709551615UL;
                        if (l_1860.f0)
                            goto lbl_1658;
                        (**g_1622) |= (l_1934 == ((***g_1179) , 1UL));
                    }
                    for (g_54 = (-6); (g_54 >= 7); ++g_54)
                    { /* block id: 854 */
                        (*g_1147) |= l_1892;
                        (**l_1708) = (**l_1708);
                    }
                    for (l_1696 = 0; (l_1696 <= 2); l_1696 += 1)
                    { /* block id: 860 */
                        int32_t l_1939 = 0x2C17D15EL;
                        p_20 = func_21(((safe_lshift_func_uint16_t_u_u(l_1939, 0)) || ((**l_1873) = (safe_rshift_func_uint8_t_u_u((((*g_273) &= (-8L)) < (safe_mod_func_int16_t_s_s((safe_lshift_func_int8_t_s_u(l_1933[0], 2)), (safe_lshift_func_int16_t_s_s(((-7L) == (safe_sub_func_int32_t_s_s(1L, (safe_rshift_func_uint16_t_u_u(((safe_div_func_uint16_t_u_u(g_198, l_1880)) > 0x534408B9L), 3))))), l_1939))))), l_1939)))), l_1695, (*g_272), l_1880);
                    }
                    for (l_1865 = (-14); (l_1865 == 12); l_1865++)
                    { /* block id: 867 */
                        int16_t l_1956 = 0x7A3EL;
                        int32_t l_1957 = 1L;
                        int32_t l_1959 = (-1L);
                        int32_t l_1960 = (-1L);
                        int32_t l_1961[10][2][4] = {{{1L,0x3A2FB00CL,0xA361982DL,(-6L)},{(-6L),0x40EE34AFL,0x0850B915L,0xA361982DL}},{{0x587F9D3CL,0x40EE34AFL,0xA39EC356L,(-6L)},{0x40EE34AFL,0x3A2FB00CL,0x22E8077FL,0x3A2FB00CL}},{{0xC66D8607L,0x0850B915L,0xE2DE90AFL,7L},{0x22E8077FL,(-1L),3L,0L}},{{7L,3L,0x40EE34AFL,0xE2DE90AFL},{7L,1L,3L,0xC3A42655L}},{{0x22E8077FL,0xE2DE90AFL,0xE2DE90AFL,0x22E8077FL},{0xC66D8607L,(-6L),0x22E8077FL,0x36E1C576L}},{{0x40EE34AFL,0xC3A42655L,0xA39EC356L,0x44C281B2L},{0x587F9D3CL,0L,0x0850B915L,0x44C281B2L}},{{(-6L),0xC3A42655L,0xA361982DL,0x36E1C576L},{1L,(-6L),1L,0x22E8077FL}},{{0x0850B915L,0xE2DE90AFL,7L,0xC3A42655L},{0x44C281B2L,1L,0x36E1C576L,0xE2DE90AFL}},{{0x3A2FB00CL,3L,0x36E1C576L,0L},{0x44C281B2L,(-1L),7L,7L}},{{0x0850B915L,0x0850B915L,1L,0x3A2FB00CL},{1L,0x3A2FB00CL,0xA361982DL,(-6L)}}};
                        int i, j, k;
                        l_1963++;
                    }
                }
            }
            else
            { /* block id: 871 */
                const union U1 l_1966[10] = {{1UL},{1UL},{1UL},{1UL},{1UL},{1UL},{1UL},{1UL},{1UL},{1UL}};
                int i;
                (*l_1707) = p_20;
            }
            return p_20;
        }
        else
        { /* block id: 875 */
            if (l_1696)
                goto lbl_1658;
        }
        (*l_2012) |= ((((safe_mul_func_int8_t_s_s(((*l_2009) |= ((safe_add_func_uint8_t_u_u((--(*l_1972)), (((*l_2007) |= (safe_add_func_uint64_t_u_u((safe_div_func_uint64_t_u_u((l_1879 > l_1979), (safe_mod_func_int16_t_s_s(((safe_mul_func_int8_t_s_s(0x92L, ((safe_add_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u((--g_85), (safe_rshift_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u(l_1994, (l_1690 = (safe_mod_func_int32_t_s_s((l_1689 | ((*g_242) = 6L)), ((safe_unary_minus_func_uint16_t_u(((*g_125) , (safe_lshift_func_uint8_t_u_u(((((*g_116) = (((safe_rshift_func_uint8_t_u_u(((((***g_1179) = (((*l_2002)--) || ((**g_1622) <= ((((((((((l_2005 != &g_552) & l_1693[3]) >= 0xE05CEDD1C136646DLL) , (void*)0) == (void*)0) <= 1L) >= 0x227AF886C1AAA369LL) ^ g_198) , l_1711) , (-1L))))) || 0x3E5E1F91L) >= 8UL), g_1364)) >= 5L) <= l_2006)) && (***g_430)) & (-8L)), g_79))))) , l_1463[1][7])))))), 7)))), g_306[0][0][7])) <= (**g_272)))) > (**g_272)), l_1687)))), l_1549[2][3]))) , (**g_272)))) == 0x4EL)), l_1693[4])) && (***g_1621)) < l_1711) <= l_1693[4]);
    }
    return p_20;
}


/* ------------------------------------------ */
/* 
 * reads : g_187 g_380 g_337 g_203 g_1286 g_125 g_242 g_191 g_1138.f1 g_77 g_198 g_1147 g_1148 g_223 g_85
 * writes: g_187 g_380 g_337 g_203 g_126 g_1148
 */
static int32_t * func_21(uint8_t  p_22, uint16_t  p_23, int8_t * p_24, uint16_t  p_25)
{ /* block id: 457 */
    int32_t l_1083 = 0L;
    int32_t l_1097 = 0x68C8DD3FL;
    uint32_t * const *l_1131 = &g_1003;
    uint64_t *** const l_1134 = &g_521;
    uint64_t ***l_1135[6][9] = {{&g_521,&g_521,(void*)0,&g_521,(void*)0,&g_521,&g_521,&g_521,&g_521},{&g_521,(void*)0,&g_521,&g_521,&g_521,&g_521,(void*)0,&g_521,&g_521},{&g_521,&g_521,&g_521,&g_521,(void*)0,&g_521,&g_521,&g_521,&g_521},{&g_521,(void*)0,&g_521,(void*)0,&g_521,&g_521,&g_521,&g_521,&g_521},{&g_521,&g_521,(void*)0,&g_521,(void*)0,&g_521,(void*)0,&g_521,(void*)0},{&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521}};
    int32_t **l_1142 = &g_223;
    int32_t ***l_1141 = &l_1142;
    int32_t l_1189[10][6][4] = {{{0x23C5542BL,(-1L),0x61079837L,0x6556CDB2L},{0x280DABAEL,5L,9L,0L},{0x9F000BDAL,0x4B1E8B2AL,0x6556CDB2L,(-4L)},{0x23C5542BL,0x61079837L,0xF0C3597FL,0x280DABAEL},{5L,(-1L),0x280DABAEL,0x23C5542BL},{5L,(-1L),0xF0C3597FL,0xF0C3597FL}},{{0x23C5542BL,0x23C5542BL,0x6556CDB2L,0xD4C59491L},{0x9F000BDAL,0x6556CDB2L,9L,0x4B1E8B2AL},{0xF0C3597FL,(-1L),1L,9L},{9L,(-1L),0x23C5542BL,0x4B1E8B2AL},{(-1L),0x6556CDB2L,(-1L),0xD4C59491L},{(-1L),0x23C5542BL,0x61079837L,0xF0C3597FL}},{{(-4L),(-1L),0xD4C59491L,0x23C5542BL},{0x4B1E8B2AL,(-1L),0xD4C59491L,0x280DABAEL},{(-4L),0x61079837L,0x61079837L,(-4L)},{(-1L),0x4B1E8B2AL,(-1L),0L},{(-1L),0L,0x23C5542BL,(-1L)},{9L,5L,1L,(-1L)}},{{0xF0C3597FL,0L,9L,0L},{0x9F000BDAL,0x4B1E8B2AL,0x6556CDB2L,(-4L)},{0x23C5542BL,0x61079837L,0xF0C3597FL,0x280DABAEL},{5L,(-1L),0x280DABAEL,0x23C5542BL},{5L,(-1L),0xF0C3597FL,0xF0C3597FL},{0x23C5542BL,0x23C5542BL,0x6556CDB2L,0xD4C59491L}},{{0x9F000BDAL,0x6556CDB2L,9L,0x4B1E8B2AL},{0xF0C3597FL,(-1L),1L,9L},{9L,(-1L),0x23C5542BL,0x4B1E8B2AL},{(-1L),0x6556CDB2L,(-1L),0xD4C59491L},{(-1L),0x23C5542BL,0x61079837L,0xF0C3597FL},{(-4L),(-1L),0xD4C59491L,0x23C5542BL}},{{0x4B1E8B2AL,(-1L),0xD4C59491L,0x280DABAEL},{(-4L),0x61079837L,0x61079837L,(-4L)},{(-1L),0x4B1E8B2AL,(-1L),0L},{(-1L),0L,0x23C5542BL,(-1L)},{9L,5L,1L,(-1L)},{0xF0C3597FL,0L,9L,0L}},{{0x9F000BDAL,0x4B1E8B2AL,0x6556CDB2L,(-4L)},{0x23C5542BL,0x61079837L,0xF0C3597FL,0x280DABAEL},{5L,(-1L),0x280DABAEL,0x23C5542BL},{5L,(-1L),0xF0C3597FL,0xF0C3597FL},{0x23C5542BL,0x23C5542BL,0x6556CDB2L,0xD4C59491L},{0x9F000BDAL,0x6556CDB2L,9L,0x4B1E8B2AL}},{{0xF0C3597FL,(-1L),1L,9L},{9L,(-1L),0x23C5542BL,0x4B1E8B2AL},{(-1L),0x6556CDB2L,(-1L),0xD4C59491L},{(-1L),0x23C5542BL,0x61079837L,0xF0C3597FL},{(-4L),(-1L),0xD4C59491L,0x23C5542BL},{0x4B1E8B2AL,(-1L),0xD4C59491L,0x280DABAEL}},{{(-4L),0x61079837L,0x61079837L,(-4L)},{0x61079837L,(-4L),0x64B9AD72L,0x23C5542BL},{0x64B9AD72L,0x23C5542BL,9L,5L},{0x4B1E8B2AL,0L,0x280DABAEL,5L},{(-1L),0x23C5542BL,0x4B1E8B2AL,0x23C5542BL},{0xD4C59491L,(-4L),(-1L),0x9F000BDAL}},{{9L,1L,(-1L),0xF0C3597FL},{0L,5L,0xF0C3597FL,9L},{0L,0x61079837L,(-1L),(-1L)},{9L,9L,(-1L),(-1L)},{0xD4C59491L,(-1L),0x4B1E8B2AL,(-4L)},{(-1L),0x64B9AD72L,0x280DABAEL,0x4B1E8B2AL}}};
    int64_t l_1190 = 0x2E05001F32F2E77ALL;
    uint16_t *l_1204 = &g_552;
    uint16_t **l_1203 = &l_1204;
    int16_t **l_1214[9] = {(void*)0,&g_242,&g_242,(void*)0,&g_242,&g_242,(void*)0,&g_242,&g_242};
    int16_t ***l_1213 = &l_1214[7];
    union U1 **l_1251 = &g_249;
    int16_t l_1291 = 1L;
    int i, j, k;
    for (g_187 = 0; (g_187 > 28); g_187 = safe_add_func_uint64_t_u_u(g_187, 5))
    { /* block id: 460 */
        uint16_t l_1071 = 65535UL;
        uint32_t *l_1114 = &g_142;
        int32_t **l_1133 = &g_223;
        int32_t ***l_1132[9] = {&l_1133,&l_1133,&l_1133,&l_1133,&l_1133,&l_1133,&l_1133,&l_1133,&l_1133};
        union U1 l_1202 = {0xD10CB2E7L};
        uint32_t *l_1230 = &l_1202.f0;
        int16_t l_1244 = 1L;
        uint64_t l_1250 = 0x0FB250CE45F1D73BLL;
        int i;
        for (g_380 = 0; (g_380 > (-4)); --g_380)
        { /* block id: 463 */
            uint8_t l_1074 = 0xF3L;
            int32_t l_1088 = (-7L);
            union U1 l_1101 = {5UL};
            uint32_t *l_1113 = &g_142;
            int32_t l_1143 = 0x585E7C7BL;
            int32_t l_1188[1];
            uint32_t l_1191 = 3UL;
            uint16_t **l_1205[10] = {&l_1204,&l_1204,&l_1204,&l_1204,&l_1204,&l_1204,&l_1204,&l_1204,&l_1204,&l_1204};
            union U1 **l_1209 = &g_249;
            uint16_t l_1259[2][2][2] = {{{1UL,1UL},{1UL,1UL}},{{1UL,1UL},{1UL,1UL}}};
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_1188[i] = 0xD39437A2L;
        }
    }
    for (g_337 = (-10); (g_337 >= 17); g_337 = safe_add_func_uint8_t_u_u(g_337, 6))
    { /* block id: 567 */
        int64_t l_1289 = 0L;
        int32_t l_1290 = 0L;
        int32_t l_1292 = (-1L);
        int32_t l_1293 = 0x23A3B42AL;
        int32_t l_1294 = (-8L);
        int32_t l_1295 = 1L;
        int32_t l_1296 = 7L;
        int32_t l_1297 = 0xC6D8FDD0L;
        int32_t l_1298 = (-6L);
        int32_t l_1299 = 9L;
        int32_t l_1300 = 0xB35A8DE7L;
        int16_t ***l_1314[5] = {&l_1214[7],&l_1214[7],&l_1214[7],&l_1214[7],&l_1214[7]};
        int i;
        for (g_203 = (-2); (g_203 <= 54); g_203 = safe_add_func_int64_t_s_s(g_203, 5))
        { /* block id: 570 */
            int32_t *l_1287 = &l_1189[6][2][2];
            int32_t *l_1288[9][7][4] = {{{&g_54,&g_198,&g_198,(void*)0},{&g_54,&g_198,&g_198,&g_3[6]},{&l_1189[0][2][2],(void*)0,&g_3[6],&g_3[6]},{&l_1189[6][1][2],&l_1189[6][1][2],&g_3[4],&g_380},{(void*)0,&g_3[6],&g_54,&g_3[6]},{&g_206,&g_54,&l_1189[0][2][2],&g_54},{&g_198,&g_54,&g_206,&g_3[6]}},{{&g_54,&g_3[6],&g_198,&g_380},{&g_198,&l_1189[6][1][2],&g_54,&g_3[6]},{&g_198,(void*)0,&g_3[4],&g_3[6]},{(void*)0,&g_198,&g_54,(void*)0},{&g_198,&g_198,&g_54,&g_198},{&l_1189[6][1][2],&g_3[1],&g_3[4],(void*)0},{&g_3[6],&g_54,&g_3[7],&g_3[6]}},{{&g_198,&g_198,&g_206,&g_3[2]},{&g_54,&g_3[0],&g_206,&l_1189[0][2][2]},{&g_198,&g_3[6],&g_198,&l_1189[0][2][2]},{&g_206,&l_1189[6][1][2],&g_198,&g_3[2]},{&g_380,&g_198,&g_3[4],&g_198},{(void*)0,&g_54,&l_1189[0][2][2],&g_499},{&l_1189[0][2][2],&g_54,&g_3[7],&g_198}},{{&g_3[1],&g_3[6],&g_198,&g_380},{&g_3[1],&g_198,&g_3[7],&l_1189[0][2][2]},{&l_1189[0][2][2],&g_380,&l_1189[0][2][2],&g_3[6]},{(void*)0,&g_3[0],&g_3[4],(void*)0},{&g_380,&g_3[6],&g_198,&g_198},{&g_206,&g_3[1],&g_3[4],&g_3[6]},{&g_54,&g_3[2],(void*)0,&g_3[7]}},{{&g_3[2],&g_206,&g_206,&g_3[6]},{(void*)0,&l_1189[0][2][2],&g_198,&g_3[6]},{&g_198,&l_1189[0][2][2],&g_206,&g_198},{&l_1189[0][2][2],&g_499,&g_3[6],&l_1189[0][2][2]},{&g_499,&g_54,&l_1097,&g_3[4]},{&l_1189[0][2][2],&g_3[6],&g_206,&g_206},{&g_54,&l_1189[0][2][2],&l_1189[0][2][2],&g_54}},{{(void*)0,&g_198,&g_499,&l_1097},{&g_3[6],&l_1189[0][2][2],(void*)0,&g_54},{&g_3[7],&g_3[4],(void*)0,&g_54},{&g_206,&l_1189[0][2][2],&g_3[6],&l_1097},{&l_1189[0][2][2],&g_198,&l_1189[6][1][2],&g_54},{&l_1189[0][2][2],&l_1189[0][2][2],&g_3[6],&g_206},{&g_3[6],&g_3[6],(void*)0,&g_3[4]}},{{&g_3[2],&g_54,&g_499,&l_1189[0][2][2]},{&g_3[6],&g_499,&l_1189[0][2][2],&g_198},{&g_3[6],&l_1189[0][2][2],&g_3[4],&g_3[6]},{&g_206,&l_1189[0][2][2],&l_1189[6][1][2],&g_3[6]},{&g_3[6],&g_206,&l_1097,&g_3[7]},{&g_206,&g_3[2],&g_3[6],&g_3[6]},{&g_198,&g_198,(void*)0,&g_54}},{{&g_198,&g_206,(void*)0,&l_1189[0][2][2]},{(void*)0,&g_206,(void*)0,&g_3[6]},{&g_3[7],&g_198,&g_206,&g_54},{&g_206,&g_499,&g_198,&g_198},{&g_499,&g_198,&g_198,&g_3[4]},{&g_206,&g_3[2],&g_206,&g_499},{&g_3[7],&l_1189[0][2][2],(void*)0,&g_3[7]}},{{(void*)0,&g_3[7],(void*)0,&l_1097},{&g_198,&l_1189[0][2][2],(void*)0,&g_198},{&g_198,&g_3[4],&g_3[6],&g_54},{&g_206,&g_206,&l_1097,&l_1097},{&g_3[6],&g_54,&l_1189[6][1][2],&g_198},{&g_206,&l_1189[0][2][2],&g_3[4],&g_198},{&g_3[6],&g_198,&l_1189[0][2][2],&g_3[4]}}};
            uint32_t l_1301 = 9UL;
            uint16_t *l_1313 = &g_207;
            int16_t * const *l_1316 = &g_242;
            int16_t * const **l_1315 = &l_1316;
            int i, j, k;
            (*g_125) = g_1286[6];
            --l_1301;
            (*g_1147) = ((~(*g_242)) ^ ((safe_rshift_func_int16_t_s_s((*g_242), (((safe_mul_func_uint8_t_u_u(g_1138.f1, (safe_mul_func_uint8_t_u_u((safe_mul_func_int8_t_s_s((*p_24), (((((void*)0 == l_1313) != (l_1314[0] == l_1315)) | (((safe_lshift_func_int8_t_s_s((65535UL >= 0xD79AL), 5)) , (void*)0) == (*l_1141))) && p_22))), 0xFDL)))) == (*g_242)) ^ 1L))) ^ g_198));
        }
        if ((*g_1147))
            break;
    }
    return (**l_1141);
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_54 g_77 g_79 g_85 g_117 g_471 g_306 g_116 g_142 g_242 g_499 g_191 g_516 g_273 g_207 g_521 g_430 g_431 g_432 g_203 g_198 g_574 g_552 g_272 g_125 g_453 g_218.f0 g_206 g_337 g_187 g_781 g_840 g_393
 * writes: g_54 g_77 g_79 g_85 g_117 g_471 g_453 g_191 g_197 g_520 g_207 g_552 g_198 g_574 g_393 g_206 g_116 g_187 g_781 g_980 g_306 g_499
 */
static uint64_t * func_45(uint16_t  p_46, int32_t * const  p_47, uint32_t  p_48, uint8_t  p_49, const uint32_t  p_50)
{ /* block id: 5 */
    int32_t *l_53 = &g_54;
    const int8_t l_59[3] = {1L,1L,1L};
    int8_t *l_76[10][6][4] = {{{&g_77,&g_77,&g_77,(void*)0},{&g_77,&g_77,&g_77,(void*)0},{&g_77,&g_77,&g_77,&g_77},{&g_77,&g_77,&g_77,&g_77},{&g_77,&g_77,(void*)0,&g_77},{&g_77,&g_77,&g_77,&g_77}},{{&g_77,(void*)0,&g_77,&g_77},{&g_77,&g_77,&g_77,&g_77},{&g_77,&g_77,&g_77,&g_77},{&g_77,&g_77,&g_77,&g_77},{&g_77,&g_77,(void*)0,&g_77},{&g_77,&g_77,&g_77,(void*)0}},{{&g_77,&g_77,&g_77,&g_77},{&g_77,&g_77,(void*)0,&g_77},{&g_77,(void*)0,&g_77,&g_77},{&g_77,&g_77,&g_77,&g_77},{&g_77,(void*)0,&g_77,&g_77},{&g_77,&g_77,&g_77,&g_77}},{{&g_77,&g_77,&g_77,(void*)0},{&g_77,&g_77,&g_77,&g_77},{(void*)0,&g_77,&g_77,&g_77},{&g_77,&g_77,&g_77,&g_77},{(void*)0,&g_77,&g_77,&g_77},{&g_77,&g_77,&g_77,&g_77}},{{&g_77,&g_77,(void*)0,(void*)0},{&g_77,&g_77,(void*)0,&g_77},{&g_77,&g_77,&g_77,(void*)0},{&g_77,&g_77,&g_77,&g_77},{&g_77,&g_77,&g_77,(void*)0},{&g_77,&g_77,&g_77,&g_77}},{{(void*)0,&g_77,&g_77,&g_77},{&g_77,&g_77,(void*)0,&g_77},{&g_77,&g_77,(void*)0,&g_77},{&g_77,&g_77,&g_77,&g_77},{(void*)0,&g_77,&g_77,(void*)0},{&g_77,&g_77,&g_77,&g_77}},{{&g_77,&g_77,(void*)0,&g_77},{&g_77,(void*)0,&g_77,&g_77},{&g_77,&g_77,(void*)0,&g_77},{&g_77,(void*)0,&g_77,&g_77},{&g_77,&g_77,&g_77,&g_77},{&g_77,&g_77,(void*)0,(void*)0}},{{&g_77,&g_77,&g_77,&g_77},{&g_77,(void*)0,&g_77,&g_77},{&g_77,&g_77,(void*)0,&g_77},{&g_77,(void*)0,&g_77,&g_77},{&g_77,&g_77,(void*)0,&g_77},{&g_77,&g_77,&g_77,&g_77}},{{&g_77,(void*)0,&g_77,&g_77},{(void*)0,&g_77,&g_77,&g_77},{&g_77,(void*)0,(void*)0,&g_77},{&g_77,&g_77,(void*)0,&g_77},{&g_77,&g_77,&g_77,&g_77},{(void*)0,&g_77,&g_77,(void*)0}},{{&g_77,&g_77,&g_77,&g_77},{&g_77,&g_77,&g_77,&g_77},{&g_77,(void*)0,&g_77,&g_77},{&g_77,&g_77,(void*)0,&g_77},{&g_77,&g_77,(void*)0,&g_77},{(void*)0,&g_77,(void*)0,&g_77}}};
    uint32_t *l_78 = &g_79;
    int32_t **l_522 = &l_53;
    uint32_t l_559 = 0x09F4590FL;
    int32_t *l_560 = &g_198;
    int32_t l_564[6] = {1L,1L,1L,1L,1L,1L};
    int16_t l_566 = 0x65E9L;
    uint8_t l_567 = 0x3EL;
    uint16_t *l_581 = &g_552;
    uint16_t * const *l_580 = &l_581;
    union U1 l_674 = {4294967295UL};
    union U1 **l_748 = &g_249;
    uint64_t *l_771[1];
    union U1 *l_797 = &l_674;
    uint16_t l_810 = 0x81A5L;
    uint32_t **l_1011[2][7] = {{&g_1003,&g_1003,&g_1003,&g_1003,&g_1003,&g_1003,&g_1003},{&g_1003,&g_1003,&g_1003,&g_1003,&g_1003,&g_1003,&g_1003}};
    uint32_t l_1028 = 18446744073709551615UL;
    int64_t l_1037 = 0xFFB836205E27A5B9LL;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_771[i] = &g_203;
    (*l_53) = (*p_47);
    if (((*l_560) ^= (safe_rshift_func_int8_t_s_s((safe_rshift_func_int16_t_s_u(((p_46 , (((l_59[0] | (g_3[2] < func_60(((*l_522) = func_63(&l_53, (safe_mod_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_u((safe_add_func_int64_t_s_s(g_3[1], g_3[6])), 13)), (safe_sub_func_uint16_t_u_u((((*l_78) &= ((((safe_mul_func_int8_t_s_s((p_46 , (g_77 ^= ((1L != 0x7989L) , g_54))), g_54)) == (-1L)) < 0x0BF1997376B242CFLL) , g_77)) < 7UL), 0xB970L)))))), p_49))) , 1UL) & g_306[1][0][6])) && 18446744073709551615UL), l_559)), p_46))))
    { /* block id: 229 */
        uint64_t l_561[9];
        int32_t l_562[2][8][10] = {{{0x49766D96L,(-1L),0x9C5FDC82L,(-4L),1L,0x5AD9B93BL,(-8L),4L,0xA3A1EEB7L,1L},{0x9C5FDC82L,8L,(-1L),(-1L),1L,1L,0L,1L,1L,(-1L)},{1L,(-8L),1L,0x49766D96L,0xEF417A13L,(-4L),1L,(-1L),0xF8C64C08L,(-6L)},{(-8L),0xEF417A13L,0L,0x9C5FDC82L,1L,0xFA6E6C67L,0x8FB2D6D6L,(-1L),(-1L),0x8FB2D6D6L},{0xA3A1EEB7L,0xF8C64C08L,1L,1L,0xF8C64C08L,0xA3A1EEB7L,(-1L),1L,0x9D2878E2L,0L},{8L,0x9332AC86L,(-1L),(-8L),0x2372DF97L,0xF8C64C08L,0xFA6E6C67L,4L,0x5AD9B93BL,0x9C5FDC82L},{8L,0x8FB2D6D6L,0x9C5FDC82L,0xA3A1EEB7L,(-1L),0xA3A1EEB7L,0x9C5FDC82L,0x8FB2D6D6L,8L,0x9D2878E2L},{0xA3A1EEB7L,0x9C5FDC82L,0x8FB2D6D6L,8L,0x9D2878E2L,0xFA6E6C67L,0xEF417A13L,1L,(-6L),4L}},{{(-8L),(-1L),0x9332AC86L,8L,(-6L),(-4L),(-4L),(-6L),8L,0x9332AC86L},{1L,1L,0xF8C64C08L,0xA3A1EEB7L,(-1L),1L,0x9D2878E2L,0L,0x5AD9B93BL,0x49766D96L},{0x9C5FDC82L,0L,0xEF417A13L,(-8L),(-4L),0x5AD9B93BL,0x9D2878E2L,0xA3A1EEB7L,0x9D2878E2L,0x5AD9B93BL},{0x49766D96L,1L,(-8L),1L,0x49766D96L,0xEF417A13L,(-4L),1L,(-1L),0xF8C64C08L},{(-1L),(-1L),8L,0x9C5FDC82L,(-8L),0x8FB2D6D6L,0xEF417A13L,0x9332AC86L,0xF8C64C08L,0xF8C64C08L},{(-4L),0x9C5FDC82L,(-1L),0x49766D96L,0x49766D96L,(-1L),0x9C5FDC82L,(-4L),1L,0x5AD9B93BL},{0x5AD9B93BL,0x8FB2D6D6L,1L,(-1L),(-4L),0x9332AC86L,0xFA6E6C67L,0x2372DF97L,0xA3A1EEB7L,0x49766D96L},{4L,0x9332AC86L,1L,(-4L),(-1L),0x2372DF97L,(-1L),(-4L),1L,0x9332AC86L}}};
        int32_t *l_563[3];
        int8_t l_565[4][4] = {{(-2L),(-1L),(-1L),(-1L)},{0L,(-1L),(-1L),(-1L)},{0L,(-1L),0L,0x07L},{(-1L),(-1L),0x07L,0x07L}};
        int i, j, k;
        for (i = 0; i < 9; i++)
            l_561[i] = 0UL;
        for (i = 0; i < 3; i++)
            l_563[i] = &g_54;
        l_561[4] ^= 1L;
        ++l_567;
    }
    else
    { /* block id: 232 */
        int32_t **l_575 = &l_560;
        int32_t l_596 = 0x78397B9DL;
        int32_t *l_597[3][3] = {{&g_198,&g_198,&g_198},{&g_198,&g_198,&g_198},{&g_198,&g_198,&g_198}};
        uint16_t **l_610 = &l_581;
        uint32_t *l_615[5][7] = {{&l_559,&g_337,&l_559,&g_337,&l_559,&g_337,&l_559},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_559,&g_337,&l_559,&g_337,&l_559,&g_337,&l_559},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_559,&g_337,&l_559,&g_337,&l_559,&g_337,&l_559}};
        int16_t l_616[4][6] = {{0x2BCCL,0x8777L,0xE65FL,8L,0xE65FL,0x8777L},{0xE65FL,0x2BCCL,(-2L),0xA81BL,0xA81BL,(-2L)},{0xE65FL,0xE65FL,0xA81BL,8L,0xD9F8L,8L},{0x2BCCL,0xE65FL,0x2BCCL,(-2L),0xA81BL,0xA81BL}};
        uint64_t *l_622[9][9] = {{&g_393,&g_187,(void*)0,(void*)0,&g_187,&g_393,(void*)0,(void*)0,&g_393},{&g_117,&g_203,&g_393,&g_203,&g_117,&g_203,&g_393,&g_203,&g_117},{&g_187,(void*)0,(void*)0,&g_187,&g_393,(void*)0,(void*)0,&g_393,&g_187},{&g_203,&g_203,&g_203,&g_203,&g_203,&g_203,&g_203,&g_203,&g_203},{&g_187,&g_187,(void*)0,(void*)0,&g_393,&g_393,(void*)0,(void*)0,&g_187},{&g_117,&g_203,&g_393,&g_203,&g_117,&g_203,&g_393,&g_203,&g_117},{&g_393,(void*)0,(void*)0,&g_187,&g_187,(void*)0,(void*)0,&g_393,&g_393},{&g_203,&g_203,&g_203,&g_203,&g_203,&g_203,&g_203,&g_203,&g_203},{&g_393,&g_187,(void*)0,(void*)0,&g_187,&g_393,(void*)0,(void*)0,&g_393}};
        int8_t **l_652 = &l_76[3][5][2];
        uint32_t l_657 = 0xF62FD211L;
        union U1 l_754 = {0x05F91934L};
        uint8_t l_766 = 5UL;
        int i, j;
        l_564[1] ^= ((safe_rshift_func_int16_t_s_s((**l_522), (*g_242))) | ((safe_add_func_int32_t_s_s(((g_574 ^ (p_49 <= (&g_499 != ((*l_575) = (*l_522))))) & (safe_add_func_uint8_t_u_u((((safe_rshift_func_int8_t_s_u((&g_472 == l_580), 1)) <= (((safe_rshift_func_int8_t_s_u((safe_mul_func_uint16_t_u_u((safe_div_func_int32_t_s_s(((safe_add_func_int32_t_s_s((((**g_521) = ((g_552--) <= (safe_rshift_func_uint16_t_u_s((safe_lshift_func_uint8_t_u_s(((void*)0 != &p_50), 6)), (*l_53))))) != 0xEE69D5CD04E3F198LL), 0x32511D66L)) , 0xBB9C8593L), g_142)), p_46)), l_596)) ^ (-1L)) || (**l_522))) , p_50), p_49))), (**l_522))) >= p_48));
        if ((((safe_rshift_func_int16_t_s_u(((safe_add_func_int32_t_s_s((((*l_560) = (((safe_lshift_func_int16_t_s_s((9UL < ((*l_78) |= 4294967289UL)), 12)) >= p_46) > (safe_lshift_func_int8_t_s_s(7L, 5)))) && (safe_div_func_int64_t_s_s((p_49 ^ (((*l_610) = &g_552) != (void*)0)), g_3[6]))), (((safe_mul_func_uint16_t_u_u((safe_div_func_uint32_t_u_u((l_616[0][3] = p_49), (*p_47))), 65535UL)) == p_49) | p_49))) || 0x719CC22F351CA033LL), p_46)) != p_46) == g_191[8]))
        { /* block id: 241 */
            int32_t *l_617 = &l_596;
            int16_t **l_620 = (void*)0;
            int32_t l_624 = 0x7104FEB8L;
            int8_t l_648 = 0x8DL;
            int32_t l_660 = 0xFC576EEFL;
            int32_t l_690[2][1];
            uint16_t *l_720 = &g_207;
            int i, j;
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 1; j++)
                    l_690[i][j] = 0x9752282EL;
            }
lbl_703:
            l_617 = (*l_575);
            for (g_207 = 0; (g_207 == 19); ++g_207)
            { /* block id: 245 */
                int16_t **l_621 = &g_242;
                int32_t l_625 = 0x652B5645L;
                int8_t **l_651 = &g_273;
                uint32_t l_658 = 0UL;
                uint64_t l_659 = 18446744073709551606UL;
                int32_t l_691 = 9L;
                int32_t l_693[6][7][6] = {{{(-10L),0xE2CB77A9L,3L,1L,0L,0x3EE22270L},{0L,7L,1L,0x30724D32L,0L,0x61A8A0F5L},{0x4DDFE5F4L,0xC86B7254L,(-8L),0x4A90048CL,0L,1L},{0x565D7768L,1L,0xE2CB77A9L,1L,0x30724D32L,1L},{7L,(-3L),0x565D7768L,0x941DD0CAL,0x565D7768L,0x6ACD1B31L},{0xA17043C5L,(-1L),0x61A8A0F5L,0L,(-10L),1L},{0L,0x762E5CBBL,0x4DDFE5F4L,(-8L),0xEA986B2BL,0x3EE22270L}},{{0x3EE22270L,0x762E5CBBL,1L,(-1L),(-10L),0xBB8EAD91L},{0L,(-1L),0xBBAB8AAAL,0L,0L,0x30724D32L},{0xE2CB77A9L,0x6ACD1B31L,0x8AA33E64L,0x565D7768L,0L,(-3L)},{(-1L),0xEA986B2BL,1L,0x18AF3D08L,0x0D5C24C1L,0x4A5E0AADL},{0L,0x4A5E0AADL,0xEA986B2BL,0x8AA33E64L,3L,0x18AF3D08L},{0x4DDFE5F4L,(-1L),(-1L),0xE2CB77A9L,0x30724D32L,0x762E5CBBL},{(-1L),(-1L),0L,0xF8E0A70FL,0x762E5CBBL,0xBBAB8AAAL}},{{(-8L),(-1L),0x4EE360FDL,0x5DD92639L,0x5DD92639L,0x4EE360FDL},{1L,1L,0L,0L,1L,0xA17043C5L},{0x4EE360FDL,(-1L),0x565D7768L,(-1L),0x03569463L,0L},{0x0D5C24C1L,0x4EE360FDL,0x565D7768L,5L,1L,0xA17043C5L},{0x18AF3D08L,5L,0L,0x61A8A0F5L,(-1L),0x4EE360FDL},{0x61A8A0F5L,(-1L),0x4EE360FDL,3L,0x4A90048CL,0xBBAB8AAAL},{0x8AA33E64L,0xC186CB1BL,0L,0x3EE22270L,0x696C2292L,0x762E5CBBL}},{{0x696C2292L,(-6L),(-1L),1L,0xBBAB8AAAL,0x18AF3D08L},{0L,7L,0xEA986B2BL,0L,1L,0x4A5E0AADL},{1L,0x0D5C24C1L,1L,0xBBAB8AAAL,7L,(-3L)},{0x4A90048CL,0L,0x8AA33E64L,0x30724D32L,0x4DDFE5F4L,0x30724D32L},{0xBBAB8AAAL,3L,0xBBAB8AAAL,1L,4L,0xBB8EAD91L},{0x03569463L,0L,1L,(-1L),0xA17043C5L,0x3EE22270L},{0xD1CFB70EL,0xBBAB8AAAL,0x4DDFE5F4L,(-1L),0x941DD0CAL,1L}},{{0x03569463L,(-8L),0x61A8A0F5L,1L,0xE2CB77A9L,0x6ACD1B31L},{0xBBAB8AAAL,0L,0L,0x30724D32L,0x61A8A0F5L,0x4DDFE5F4L},{0x4A90048CL,0L,(-1L),0xBBAB8AAAL,1L,1L},{1L,0x03569463L,0x18AF3D08L,0L,(-6L),0x941DD0CAL},{0L,0x349CD841L,1L,1L,1L,7L},{0x696C2292L,0x4DDFE5F4L,5L,0x3EE22270L,0x18AF3D08L,(-1L)},{0x8AA33E64L,1L,1L,3L,0L,0L}},{{0x61A8A0F5L,0L,0L,0x61A8A0F5L,0xC186CB1BL,0x349CD841L},{0x18AF3D08L,0L,7L,5L,0x4DDFE5F4L,0L},{0L,0x4EE360FDL,0x18AF3D08L,0L,0x4DDFE5F4L,1L},{6L,0xD1CFB70EL,0x03569463L,0x696C2292L,(-3L),0L},{0L,0x61A8A0F5L,(-1L),0x4EE360FDL,3L,0x4A90048CL},{0x18AF3D08L,1L,0L,0L,0x565D7768L,0L},{(-8L),0xBB8EAD91L,0x6ACD1B31L,(-1L),0x03569463L,(-3L)}}};
                uint8_t l_700[10] = {0xC3L,0x33L,7UL,0x33L,0xC3L,0xC3L,0x33L,7UL,0x33L,0xC3L};
                int i, j, k;
                for (g_574 = 7; (g_574 >= 2); g_574 -= 1)
                { /* block id: 248 */
                    uint64_t **l_623 = &l_622[5][2];
                    int i;
                    (**l_522) = g_191[(g_574 + 1)];
                    (**l_575) = ((g_191[(g_574 + 1)] , (l_620 != l_621)) <= (*l_617));
                    l_624 = ((*l_617) = ((g_54 , (*g_521)) == ((*l_623) = l_622[5][2])));
                    if ((*p_47))
                        continue;
                }
                if (l_625)
                    continue;
                l_625 &= (safe_mod_func_int32_t_s_s(((safe_mul_func_int16_t_s_s((safe_mul_func_int16_t_s_s(p_49, (safe_sub_func_uint64_t_u_u(0x80D8E23CCB29C3B7LL, (safe_sub_func_int32_t_s_s((((safe_div_func_uint32_t_u_u(((safe_add_func_int32_t_s_s((safe_add_func_int64_t_s_s(((safe_add_func_uint32_t_u_u((safe_div_func_int16_t_s_s((((*l_560) ^ (((safe_div_func_int8_t_s_s(1L, ((l_648 ^ ((l_651 == l_652) != ((*l_78) = ((*l_617) > (safe_add_func_uint8_t_u_u((safe_mul_func_int8_t_s_s((p_49 == l_657), 1UL)), l_658)))))) || (*g_116)))) , l_659) == (*l_617))) != (*l_560)), l_660)), p_50)) ^ (*p_47)), 4UL)), 0UL)) >= (**g_272)), p_49)) != 0xC2B1125AL) , (*p_47)), (*p_47))))))), p_49)) <= 255UL), 3UL));
                if ((safe_rshift_func_int16_t_s_u(0x73ACL, (g_125 != (((*l_651) != (void*)0) , g_125)))))
                { /* block id: 259 */
                    uint8_t l_673 = 1UL;
                    int32_t l_687 = 6L;
                    int32_t l_692 = 0x2E559130L;
                    int32_t l_694 = 8L;
                    int32_t l_697 = 1L;
                    int32_t l_698 = 0x27F3C70DL;
                    int32_t l_699[5];
                    int i;
                    for (i = 0; i < 5; i++)
                        l_699[i] = 0L;
                    l_625 |= ((**l_575) = (1UL ^ (safe_mod_func_uint64_t_u_u(((*g_116) = (safe_rshift_func_int8_t_s_u((safe_mod_func_uint16_t_u_u((safe_mod_func_int32_t_s_s(((safe_mod_func_int32_t_s_s((l_673 >= 0UL), (l_673 ^ p_48))) , (l_674 , (*l_617))), (l_624 = (safe_rshift_func_uint8_t_u_u(((**g_272) >= (safe_mul_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u(((g_453 &= (g_3[6] == 0UL)) & p_48), p_49)), l_673))), g_218.f0))))), l_673)), 0))), 0x8707F77939585662LL))));
                    for (g_393 = 0; (g_393 <= 16); g_393 = safe_add_func_int8_t_s_s(g_393, 1))
                    { /* block id: 267 */
                        int32_t *l_683 = &l_564[1];
                        uint64_t *l_684 = &g_187;
                        (*l_575) = l_683;
                        return l_684;
                    }
                    for (g_393 = 8; (g_393 != 36); ++g_393)
                    { /* block id: 273 */
                        int32_t l_688 = 1L;
                        int32_t l_689 = 0xED6F1A73L;
                        int32_t l_695 = 0xACA1CFF6L;
                        int32_t l_696[3][1];
                        int i, j;
                        for (i = 0; i < 3; i++)
                        {
                            for (j = 0; j < 1; j++)
                                l_696[i][j] = 0x0F14A72CL;
                        }
                        l_700[3]++;
                    }
                }
                else
                { /* block id: 276 */
                    uint32_t l_714[3];
                    uint16_t *l_722 = &g_552;
                    uint16_t **l_721 = &l_722;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_714[i] = 18446744073709551615UL;
                    if (g_203)
                        goto lbl_703;
                    l_691 ^= (safe_mod_func_int64_t_s_s((safe_add_func_uint64_t_u_u((safe_div_func_uint8_t_u_u(((*l_53) , (4294967286UL != (safe_div_func_int8_t_s_s((safe_sub_func_uint16_t_u_u(6UL, l_714[1])), (safe_lshift_func_uint16_t_u_s((((safe_unary_minus_func_int8_t_s((*g_273))) , ((safe_add_func_int64_t_s_s((((*l_610) = l_720) == ((*l_721) = &g_552)), ((*l_617) , (l_714[1] , 5L)))) | 0xFE79AB76C8654775LL)) != (**l_575)), (*g_242))))))), p_48)), p_48)), p_46));
                    (**l_575) = 0xD21F6073L;
                }
            }
        }
        else
        { /* block id: 284 */
            int8_t l_728 = 0x64L;
            uint16_t *l_739 = &g_207;
            int32_t l_740[1];
            int i;
            for (i = 0; i < 1; i++)
                l_740[i] = 9L;
            for (g_206 = 2; (g_206 <= 7); g_206 += 1)
            { /* block id: 287 */
                uint8_t l_763 = 3UL;
                for (g_197 = 0; (g_197 <= 7); g_197 += 1)
                { /* block id: 290 */
                    union U1 *l_755 = &l_674;
                    int16_t *l_756 = &g_306[0][0][7];
                    uint32_t l_759[9] = {18446744073709551615UL,1UL,1UL,18446744073709551615UL,1UL,1UL,18446744073709551615UL,1UL,1UL};
                    int32_t l_762 = 0x92CB646BL;
                    int i;
                    for (g_198 = 2; (g_198 <= 7); g_198 += 1)
                    { /* block id: 293 */
                        uint32_t *l_724 = &g_142;
                        uint32_t **l_723 = &l_724;
                        uint8_t *l_741 = &g_85;
                        int32_t l_746 = (-1L);
                        union U1 ***l_749 = (void*)0;
                        union U1 **l_750 = (void*)0;
                        union U1 **l_751 = &g_249;
                        (**l_575) = (((*l_723) = (void*)0) != &p_48);
                        l_564[5] ^= (safe_rshift_func_uint16_t_u_s(((l_728 = ((+(-3L)) , p_49)) & p_49), (((safe_div_func_uint8_t_u_u(((*l_741) &= (safe_mul_func_uint16_t_u_u((safe_lshift_func_int8_t_s_s((((safe_sub_func_int8_t_s_s((safe_lshift_func_uint8_t_u_s((l_615[1][6] != ((*l_723) = &g_142)), (**g_272))), (((**l_575) = (((*l_610) = &p_46) == l_739)) > (-1L)))) <= 1L) < l_740[0]), (**g_272))), 0x6F05L))), g_79)) ^ (*g_242)) || 4294967290UL)));
                        (**l_522) = ((safe_lshift_func_int8_t_s_u(((*g_273) = ((safe_rshift_func_int8_t_s_s(0xB7L, ((((*p_47) | l_746) , ((((!((((void*)0 == &g_472) > ((l_750 = l_748) == (g_337 , l_751))) , ((*g_242) = (((safe_add_func_int64_t_s_s(((void*)0 != &g_125), 0x54F4FFF0B419043CLL)) , l_754) , (*g_242))))) , l_755) != &g_218) , l_756)) == (void*)0))) <= 1L)), g_198)) <= (-1L));
                    }
                    for (g_79 = 2; (g_79 <= 7); g_79 += 1)
                    { /* block id: 309 */
                        uint8_t l_757 = 0UL;
                        int32_t l_758 = 1L;
                        int i;
                        l_757 |= ((*l_53) = (*l_53));
                        (*l_560) ^= l_757;
                        (*l_560) = (((*g_521) = l_622[5][7]) == g_432[g_206]);
                        ++l_759[6];
                    }
                    --l_763;
                }
            }
        }
        l_766--;
        for (g_54 = (-10); (g_54 > 27); g_54 = safe_add_func_int64_t_s_s(g_54, 1))
        { /* block id: 324 */
            (*l_575) = (*l_575);
            return l_771[0];
        }
    }
    (*l_560) = (+g_85);
    for (g_187 = 0; (g_187 == 35); g_187 = safe_add_func_uint16_t_u_u(g_187, 1))
    { /* block id: 332 */
        int32_t *l_775 = (void*)0;
        int32_t *l_776 = &l_564[4];
        int32_t l_777 = 0x7AA3415CL;
        int32_t *l_778 = &g_499;
        int32_t *l_779 = &l_777;
        int32_t *l_780[1][8];
        union U1 *l_798 = &l_674;
        uint32_t l_901 = 8UL;
        uint64_t ** const *l_982[5];
        uint64_t ** const **l_981 = &l_982[0];
        uint16_t *l_1034 = &l_810;
        struct S0 **l_1042 = (void*)0;
        uint32_t l_1055 = 4294967295UL;
        uint8_t *l_1058 = &g_980;
        int16_t *l_1061 = &g_306[0][0][6];
        int i, j;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 8; j++)
                l_780[i][j] = &g_499;
        }
        for (i = 0; i < 5; i++)
            l_982[i] = &g_521;
        g_781--;
        for (l_777 = 2; (l_777 >= 0); l_777 -= 1)
        { /* block id: 336 */
            uint16_t * const **l_786[8][1][1] = {{{&l_580}},{{&l_580}},{{&l_580}},{{&l_580}},{{&l_580}},{{&l_580}},{{&l_580}},{{&l_580}}};
            uint32_t **l_805 = (void*)0;
            uint32_t ***l_804 = &l_805;
            int16_t *l_817 = &l_566;
            int64_t l_828 = 7L;
            const uint8_t l_851 = 252UL;
            union U1 **l_854 = (void*)0;
            int32_t l_903 = 0x653FF385L;
            int32_t l_945[7][1] = {{0xA19FAF02L},{0L},{0xA19FAF02L},{0L},{0xA19FAF02L},{0L},{0xA19FAF02L}};
            uint8_t l_946 = 0xE5L;
            uint64_t *l_949 = &g_117;
            uint32_t **l_1009 = &g_1003;
            int32_t **l_1020 = &l_779;
            const uint64_t l_1041 = 18446744073709551610UL;
            int i, j, k;
            for (g_453 = 3; (g_453 >= 0); g_453 -= 1)
            { /* block id: 339 */
                const int16_t *l_785[9][5] = {{&l_674.f1,&l_674.f1,&l_674.f1,&l_674.f1,&l_674.f1},{&l_674.f1,&l_674.f1,&l_674.f1,&l_674.f1,&l_674.f1},{&l_674.f1,&l_674.f1,&l_674.f1,&l_674.f1,&l_674.f1},{&l_674.f1,&l_674.f1,&l_674.f1,&l_674.f1,&l_674.f1},{&l_674.f1,&l_674.f1,&l_674.f1,&l_674.f1,&l_674.f1},{&l_674.f1,&l_674.f1,&l_674.f1,&l_674.f1,&l_674.f1},{&l_674.f1,&l_674.f1,&l_674.f1,&l_674.f1,&l_674.f1},{&l_674.f1,&l_674.f1,&l_674.f1,&l_674.f1,&l_674.f1},{&l_674.f1,&l_674.f1,&l_674.f1,&l_674.f1,&l_674.f1}};
                const int16_t **l_784 = &l_785[6][3];
                uint16_t **l_788 = &l_581;
                uint16_t ***l_787 = &l_788;
                int i, j;
                (*l_560) ^= ((((*l_784) = (void*)0) == (void*)0) < (l_786[2][0][0] != l_787));
            }
        }
        (*l_778) = ((l_1042 != l_1042) | (safe_lshift_func_uint16_t_u_s((safe_lshift_func_int16_t_s_s((*g_242), (safe_rshift_func_uint8_t_u_s((safe_lshift_func_int16_t_s_s((((*l_1061) = (((safe_sub_func_uint64_t_u_u((safe_mul_func_uint8_t_u_u((((*l_776) = 0UL) | (l_1055 < ((--g_117) | ((&g_980 == l_1058) < ((*l_1058) = g_840))))), ((safe_div_func_int32_t_s_s(((**l_522) ^= (p_49 | 0x73L)), (*p_47))) , p_50))), 0x1C32185AAA05BC94LL)) ^ p_46) & 0xF4BDL)) || g_393), p_49)), 6)))), p_46)));
    }
    return l_771[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_273 g_77 g_207 g_85 g_54 g_521 g_116 g_430 g_431 g_432 g_117 g_203 g_242 g_191 g_3
 * writes: g_77 g_207 g_552 g_85 g_117 g_191
 */
static int32_t  func_60(int32_t * p_61, int8_t  p_62)
{ /* block id: 217 */
    uint16_t *l_535 = &g_207;
    uint16_t **l_541 = &l_535;
    uint16_t ***l_540 = &l_541;
    int32_t l_544 = 0x42B55E2AL;
    int32_t l_550[4];
    uint16_t *l_551 = &g_552;
    uint8_t *l_553 = (void*)0;
    uint8_t *l_554 = &g_85;
    int32_t l_555 = 1L;
    int8_t l_556 = 0xA0L;
    int32_t *l_557[3][3] = {{&g_206,&g_206,&g_206},{&g_380,&g_499,&g_380},{&g_206,&g_206,&g_206}};
    uint32_t l_558 = 0UL;
    int i, j;
    for (i = 0; i < 4; i++)
        l_550[i] = (-1L);
    l_558 &= (safe_add_func_int8_t_s_s((((*g_273) &= (-6L)) == (safe_rshift_func_int8_t_s_u(((safe_rshift_func_int8_t_s_u((safe_add_func_uint8_t_u_u(((safe_mod_func_int32_t_s_s((safe_lshift_func_int16_t_s_s(((--(*l_535)) == ((*g_242) = (safe_lshift_func_uint8_t_u_s(((0xE0FF5CEE79E77842LL ^ (0x892EEE32L || 0x7B7341E7L)) , (((((*l_540) = &l_535) != &g_472) != ((((((**g_521) = ((safe_sub_func_int16_t_s_s(l_544, (safe_sub_func_int32_t_s_s((!(((*l_554) |= (safe_mul_func_int16_t_s_s(l_544, ((((*l_551) = (l_550[3] = (0x258D6AF7FF2847BBLL & l_544))) || 0x2C6BL) , l_544)))) , (*p_61))), 0L)))) ^ l_544)) && (***g_430)) , (*g_242)) & 0xDB8DL) == 0xC55755A7L)) > p_62)), 3)))), g_3[6])), (-4L))) < p_62), 0L)), p_62)) > l_555), l_556))), (-1L)));
    return (*p_61);
}


/* ------------------------------------------ */
/* 
 * reads : g_85 g_3 g_79 g_77 g_117 g_471 g_54 g_306 g_116 g_142 g_242 g_499 g_191 g_516 g_273
 * writes: g_85 g_54 g_79 g_117 g_471 g_77 g_453 g_191 g_197 g_520
 */
static int32_t * func_63(int32_t ** p_64, int16_t  p_65)
{ /* block id: 9 */
    uint8_t *l_84 = &g_85;
    uint32_t *l_88 = &g_79;
    int32_t l_89[3];
    struct S0 *l_128 = &g_129[0][3][3];
    int32_t *l_184[4][7][5] = {{{(void*)0,&l_89[1],&l_89[1],&l_89[1],(void*)0},{(void*)0,&l_89[1],&g_3[6],(void*)0,(void*)0},{&g_3[7],&l_89[1],&l_89[1],&l_89[1],&l_89[1]},{&g_54,&g_54,&l_89[1],&g_3[6],&g_3[6]},{&g_3[1],&g_3[7],(void*)0,&g_54,&g_3[1]},{&g_3[7],(void*)0,&l_89[2],(void*)0,&g_3[7]},{(void*)0,(void*)0,&g_3[2],&g_3[6],(void*)0}},{{&l_89[1],&l_89[1],(void*)0,&g_54,&g_3[6]},{&l_89[1],&g_3[2],&g_3[6],(void*)0,(void*)0},{&g_3[6],&g_54,&l_89[1],&l_89[2],&g_3[7]},{(void*)0,&l_89[1],(void*)0,(void*)0,&g_3[1]},{&g_54,&g_3[6],(void*)0,(void*)0,&g_3[6]},{(void*)0,(void*)0,&g_54,&g_3[2],&l_89[1]},{&l_89[1],&l_89[0],&g_3[6],&l_89[1],(void*)0}},{{(void*)0,&l_89[1],&l_89[1],&g_3[6],&g_54},{&g_3[5],&g_3[6],(void*)0,&g_3[6],&g_54},{&l_89[1],&g_3[5],&l_89[1],(void*)0,(void*)0},{(void*)0,&l_89[1],&g_3[6],(void*)0,&g_3[6]},{&g_3[6],&g_3[6],(void*)0,&g_3[5],(void*)0},{&l_89[1],&l_89[1],&l_89[1],&g_54,&g_3[6]},{(void*)0,(void*)0,&l_89[1],(void*)0,&l_89[1]}},{{&g_54,&l_89[1],&g_3[6],&g_3[5],&l_89[1]},{&g_54,&g_3[6],(void*)0,(void*)0,&l_89[1]},{&l_89[0],&l_89[1],(void*)0,&l_89[1],&l_89[1]},{&g_3[6],&g_3[5],&g_3[6],&g_3[6],&l_89[1]},{&g_3[6],&g_3[6],&g_3[6],&g_3[6],&g_54},{&g_3[2],&l_89[1],(void*)0,&g_3[7],&l_89[1]},{&g_3[6],&l_89[2],&g_3[6],&g_54,(void*)0}}};
    int32_t **l_183 = &l_184[2][3][0];
    int16_t **l_355[7][2][4] = {{{&g_242,&g_242,(void*)0,&g_242},{&g_242,&g_242,&g_242,(void*)0}},{{&g_242,(void*)0,(void*)0,&g_242},{&g_242,(void*)0,&g_242,(void*)0}},{{(void*)0,&g_242,&g_242,&g_242},{&g_242,&g_242,(void*)0,&g_242}},{{&g_242,&g_242,&g_242,(void*)0},{&g_242,(void*)0,(void*)0,&g_242}},{{&g_242,(void*)0,&g_242,(void*)0},{(void*)0,&g_242,&g_242,&g_242}},{{&g_242,&g_242,(void*)0,&g_242},{&g_242,&g_242,&g_242,(void*)0}},{{&g_242,(void*)0,(void*)0,&g_242},{&g_242,(void*)0,&g_242,(void*)0}}};
    union U1 l_360 = {1UL};
    int32_t l_415 = 1L;
    int64_t *l_454 = &g_197;
    int32_t l_458 = 4L;
    uint64_t **l_518 = &g_116;
    uint64_t ***l_517[2];
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_89[i] = 0xADEF089EL;
    for (i = 0; i < 2; i++)
        l_517[i] = &l_518;
    if (((((safe_mul_func_uint16_t_u_u((((*l_84)++) & ((void*)0 != l_88)), l_89[1])) & (-1L)) , ((safe_rshift_func_int16_t_s_s(((l_89[1] & (-1L)) < ((*l_88) = (safe_mul_func_int8_t_s_s((((p_65 | g_85) , (safe_div_func_uint64_t_u_u((safe_add_func_int64_t_s_s((((**p_64) = (safe_mod_func_uint32_t_u_u((g_3[1] , p_65), 0x4A9589ABL))) >= l_89[1]), g_79)), g_77))) , 0x1AL), 0UL)))), 2)) & p_65)) == p_65))
    { /* block id: 13 */
        uint32_t *l_104 = &g_79;
        int32_t l_113 = 0xB16C6279L;
        int8_t l_185 = 0xB4L;
        int32_t l_188 = 5L;
        union U1 l_245[6][5] = {{{4294967291UL},{4294967291UL},{4294967291UL},{4294967291UL},{4294967291UL}},{{0xF9857E4DL},{0xF9857E4DL},{0xF9857E4DL},{0xF9857E4DL},{0xF9857E4DL}},{{4294967291UL},{4294967291UL},{4294967291UL},{4294967291UL},{4294967291UL}},{{0xF9857E4DL},{0xF9857E4DL},{0xF9857E4DL},{0xF9857E4DL},{0xF9857E4DL}},{{4294967291UL},{4294967291UL},{4294967291UL},{4294967291UL},{4294967291UL}},{{0xF9857E4DL},{0xF9857E4DL},{0xF9857E4DL},{0xF9857E4DL},{0xF9857E4DL}}};
        int32_t l_313 = (-1L);
        uint16_t l_361 = 0x481AL;
        uint32_t l_399 = 0UL;
        int64_t l_410 = 0x4C693E4D5C52ED2ALL;
        struct S0 *l_413 = &g_414;
        int i, j;
    }
    else
    { /* block id: 178 */
        uint16_t l_476 = 0x1E61L;
        for (g_117 = 0; (g_117 > 8); ++g_117)
        { /* block id: 181 */
            volatile uint16_t * volatile **l_473 = &g_471;
            (*l_473) = g_471;
        }
        for (g_77 = (-8); (g_77 >= 24); g_77 = safe_add_func_int8_t_s_s(g_77, 2))
        { /* block id: 186 */
            l_476 &= 0xA8174C16L;
        }
        (**p_64) &= 0xAE68F09BL;
    }
    for (g_77 = (-4); (g_77 > 22); g_77 = safe_add_func_uint8_t_u_u(g_77, 1))
    { /* block id: 193 */
        uint32_t l_479 = 0x5C9364D3L;
        union U1 *l_498 = (void*)0;
        uint32_t **l_501 = &l_88;
        uint32_t **l_503 = &l_88;
        uint32_t ***l_502 = &l_503;
        uint64_t ***l_519 = &l_518;
        for (p_65 = 0; (p_65 <= 0); p_65 += 1)
        { /* block id: 196 */
            --l_479;
            for (g_453 = 9; (g_453 >= 0); g_453 -= 1)
            { /* block id: 200 */
                int i, j, k;
                if (g_306[p_65][p_65][(p_65 + 3)])
                    break;
            }
        }
        (**p_64) = (safe_sub_func_int32_t_s_s((-9L), (+((l_479 <= (!(safe_unary_minus_func_int64_t_s(((*l_454) = ((((~((l_479 < (**p_64)) == (~(safe_div_func_uint16_t_u_u(((((((*g_242) = (safe_add_func_uint16_t_u_u(((((~(((p_65 > ((p_65 < l_479) < (4UL < ((**p_64) != 0x155228BAL)))) , (*g_116)) && 1UL)) == g_142) , l_498) == &g_218), 0x16F6L))) != 0L) < 0x2CC20C23L) == p_65) || g_3[6]), p_65))))) < l_479) != g_499) && p_65)))))) , p_65))));
        (*l_183) = &g_198;
        (**p_64) |= (((((*g_242) < l_479) && ((safe_unary_minus_func_uint16_t_u(((l_501 = &l_88) == ((*l_502) = &l_88)))) && l_479)) ^ (l_479 ^ ((safe_add_func_uint8_t_u_u(((safe_rshift_func_int8_t_s_u((safe_add_func_uint64_t_u_u(((safe_lshift_func_uint16_t_u_s((safe_lshift_func_int16_t_s_s(((l_517[1] = g_516) == (g_520 = l_519)), p_65)), p_65)) == p_65), l_479)), g_117)) ^ (*g_273)), p_65)) < 4294967292UL))) | 0xFC33BFADL);
    }
    (*p_64) = (*l_183);
    return &g_54;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_29, "g_29", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    transparent_crc(g_54, "g_54", print_hash_value);
    transparent_crc(g_77, "g_77", print_hash_value);
    transparent_crc(g_79, "g_79", print_hash_value);
    transparent_crc(g_85, "g_85", print_hash_value);
    transparent_crc(g_117, "g_117", print_hash_value);
    transparent_crc(g_120.f0, "g_120.f0", print_hash_value);
    transparent_crc(g_120.f1, "g_120.f1", print_hash_value);
    transparent_crc(g_121.f0, "g_121.f0", print_hash_value);
    transparent_crc(g_121.f1, "g_121.f1", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_122[i][j][k].f0, "g_122[i][j][k].f0", print_hash_value);
                transparent_crc(g_122[i][j][k].f1, "g_122[i][j][k].f1", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_123.f0, "g_123.f0", print_hash_value);
    transparent_crc(g_123.f1, "g_123.f1", print_hash_value);
    transparent_crc(g_124.f0, "g_124.f0", print_hash_value);
    transparent_crc(g_124.f1, "g_124.f1", print_hash_value);
    transparent_crc(g_126.f0, "g_126.f0", print_hash_value);
    transparent_crc(g_126.f1, "g_126.f1", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_129[i][j][k].f0, "g_129[i][j][k].f0", print_hash_value);
                transparent_crc(g_129[i][j][k].f1, "g_129[i][j][k].f1", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_142, "g_142", print_hash_value);
    transparent_crc(g_187, "g_187", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_191[i], "g_191[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_197, "g_197", print_hash_value);
    transparent_crc(g_198, "g_198", print_hash_value);
    transparent_crc(g_203, "g_203", print_hash_value);
    transparent_crc(g_206, "g_206", print_hash_value);
    transparent_crc(g_207, "g_207", print_hash_value);
    transparent_crc(g_218.f0, "g_218.f0", print_hash_value);
    transparent_crc(g_218.f1, "g_218.f1", print_hash_value);
    transparent_crc(g_265.f0, "g_265.f0", print_hash_value);
    transparent_crc(g_265.f1, "g_265.f1", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_306[i][j][k], "g_306[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_337, "g_337", print_hash_value);
    transparent_crc(g_380, "g_380", print_hash_value);
    transparent_crc(g_393, "g_393", print_hash_value);
    transparent_crc(g_414.f0, "g_414.f0", print_hash_value);
    transparent_crc(g_414.f1, "g_414.f1", print_hash_value);
    transparent_crc(g_453, "g_453", print_hash_value);
    transparent_crc(g_499, "g_499", print_hash_value);
    transparent_crc(g_552, "g_552", print_hash_value);
    transparent_crc(g_574, "g_574", print_hash_value);
    transparent_crc(g_781, "g_781", print_hash_value);
    transparent_crc(g_840, "g_840", print_hash_value);
    transparent_crc(g_980, "g_980", print_hash_value);
    transparent_crc(g_1082.f0, "g_1082.f0", print_hash_value);
    transparent_crc(g_1082.f1, "g_1082.f1", print_hash_value);
    transparent_crc(g_1138.f0, "g_1138.f0", print_hash_value);
    transparent_crc(g_1138.f1, "g_1138.f1", print_hash_value);
    transparent_crc(g_1148, "g_1148", print_hash_value);
    transparent_crc(g_1172, "g_1172", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_1176[i].f0, "g_1176[i].f0", print_hash_value);
        transparent_crc(g_1176[i].f1, "g_1176[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1245, "g_1245", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1286[i].f0, "g_1286[i].f0", print_hash_value);
        transparent_crc(g_1286[i].f1, "g_1286[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1364, "g_1364", print_hash_value);
    transparent_crc(g_1555, "g_1555", print_hash_value);
    transparent_crc(g_1586, "g_1586", print_hash_value);
    transparent_crc(g_1591, "g_1591", print_hash_value);
    transparent_crc(g_1594.f0, "g_1594.f0", print_hash_value);
    transparent_crc(g_1594.f1, "g_1594.f1", print_hash_value);
    transparent_crc(g_1617, "g_1617", print_hash_value);
    transparent_crc(g_1640.f0, "g_1640.f0", print_hash_value);
    transparent_crc(g_1640.f1, "g_1640.f1", print_hash_value);
    transparent_crc(g_1788, "g_1788", print_hash_value);
    transparent_crc(g_1901, "g_1901", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_2017[i].f0, "g_2017[i].f0", print_hash_value);
        transparent_crc(g_2017[i].f1, "g_2017[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2028.f0, "g_2028.f0", print_hash_value);
    transparent_crc(g_2028.f1, "g_2028.f1", print_hash_value);
    transparent_crc(g_2054.f0, "g_2054.f0", print_hash_value);
    transparent_crc(g_2054.f1, "g_2054.f1", print_hash_value);
    transparent_crc(g_2190.f0, "g_2190.f0", print_hash_value);
    transparent_crc(g_2190.f1, "g_2190.f1", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_2191[i].f0, "g_2191[i].f0", print_hash_value);
        transparent_crc(g_2191[i].f1, "g_2191[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2264, "g_2264", print_hash_value);
    transparent_crc(g_2346, "g_2346", print_hash_value);
    transparent_crc(g_2347.f0, "g_2347.f0", print_hash_value);
    transparent_crc(g_2347.f1, "g_2347.f1", print_hash_value);
    transparent_crc(g_2358.f0, "g_2358.f0", print_hash_value);
    transparent_crc(g_2358.f1, "g_2358.f1", print_hash_value);
    transparent_crc(g_2398.f0, "g_2398.f0", print_hash_value);
    transparent_crc(g_2398.f1, "g_2398.f1", print_hash_value);
    transparent_crc(g_2435, "g_2435", print_hash_value);
    transparent_crc(g_2467, "g_2467", print_hash_value);
    transparent_crc(g_2559.f0, "g_2559.f0", print_hash_value);
    transparent_crc(g_2559.f1, "g_2559.f1", print_hash_value);
    transparent_crc(g_2575.f0, "g_2575.f0", print_hash_value);
    transparent_crc(g_2575.f1, "g_2575.f1", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_2612[i][j][k], "g_2612[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 640
   depth: 1, occurrence: 16
XXX total union variables: 21

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 52
breakdown:
   depth: 1, occurrence: 195
   depth: 2, occurrence: 47
   depth: 3, occurrence: 8
   depth: 4, occurrence: 2
   depth: 5, occurrence: 3
   depth: 7, occurrence: 1
   depth: 8, occurrence: 2
   depth: 10, occurrence: 1
   depth: 11, occurrence: 2
   depth: 14, occurrence: 1
   depth: 16, occurrence: 1
   depth: 17, occurrence: 1
   depth: 18, occurrence: 2
   depth: 19, occurrence: 3
   depth: 21, occurrence: 3
   depth: 22, occurrence: 2
   depth: 23, occurrence: 5
   depth: 24, occurrence: 1
   depth: 25, occurrence: 4
   depth: 26, occurrence: 3
   depth: 27, occurrence: 1
   depth: 28, occurrence: 1
   depth: 29, occurrence: 3
   depth: 30, occurrence: 1
   depth: 31, occurrence: 1
   depth: 33, occurrence: 1
   depth: 34, occurrence: 2
   depth: 38, occurrence: 1
   depth: 40, occurrence: 1
   depth: 42, occurrence: 1
   depth: 52, occurrence: 1

XXX total number of pointers: 515

XXX times a variable address is taken: 1130
XXX times a pointer is dereferenced on RHS: 350
breakdown:
   depth: 1, occurrence: 250
   depth: 2, occurrence: 75
   depth: 3, occurrence: 19
   depth: 4, occurrence: 6
XXX times a pointer is dereferenced on LHS: 373
breakdown:
   depth: 1, occurrence: 296
   depth: 2, occurrence: 69
   depth: 3, occurrence: 8
XXX times a pointer is compared with null: 51
XXX times a pointer is compared with address of another variable: 18
XXX times a pointer is compared with another pointer: 17
XXX times a pointer is qualified to be dereferenced: 8914

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1315
   level: 2, occurrence: 559
   level: 3, occurrence: 206
   level: 4, occurrence: 73
   level: 5, occurrence: 17
XXX number of pointers point to pointers: 248
XXX number of pointers point to scalars: 243
XXX number of pointers point to structs: 14
XXX percent of pointers has null in alias set: 27.2
XXX average alias set size: 1.43

XXX times a non-volatile is read: 2152
XXX times a non-volatile is write: 1098
XXX times a volatile is read: 118
XXX    times read thru a pointer: 46
XXX times a volatile is write: 50
XXX    times written thru a pointer: 37
XXX times a volatile is available for access: 4.28e+03
XXX percentage of non-volatile access: 95.1

XXX forward jumps: 1
XXX backward jumps: 13

XXX stmts: 192
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 28
   depth: 1, occurrence: 27
   depth: 2, occurrence: 23
   depth: 3, occurrence: 17
   depth: 4, occurrence: 46
   depth: 5, occurrence: 51

XXX percentage a fresh-made variable is used: 16.2
XXX percentage an existing variable is used: 83.8
********************* end of statistics **********************/

