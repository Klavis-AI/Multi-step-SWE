/* inline.c - nested inlining, always_inline, cold path */
#include <stdio.h>

static inline int leaf_step(int x)
{
    return x * 3 + 1;
}

static inline int middle_step(int x)
{
    return leaf_step(x) + leaf_step(x + 1);
}

static inline __attribute__((always_inline)) int forced_step(int x)
{
    return middle_step(x) ^ 0x5a;
}

__attribute__((noinline, cold)) static int cold_branch(int x)
{
    char pad[48];
    for (unsigned i = 0; i < sizeof pad; i++) {
        pad[i] = (char) (x + (int) i);
    }
    return pad[7] + x;
}

int hot_entry(int x)
{
    if (__builtin_expect(x > 100000, 0)) {
        return cold_branch(x);
    }
    return forced_step(x) + middle_step(x * 2);
}

int second_entry(int x)
{
    int t = 0;
    for (int i = 0; i < 4; i++) {
        t += hot_entry(x + i);
    }
    return t;
}

int main(int argc, char **argv)
{
    (void) argv;
    printf("%d\n", second_entry(argc));
    return 0;
}
