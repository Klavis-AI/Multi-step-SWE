/* mixed_c.c - third translation unit of a mixed-DWARF-version executable */
static int c_helper(int x, int y)
{
    if (x > y) {
        return x - y;
    }
    return y - x;
}

int mixed_c_entry(int x)
{
    return c_helper(x, 17) + c_helper(x * 2, 3);
}
