/* thr.c - several threads parked in known frames, then a fault on the main thread */
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

static volatile int ready_count;

static int park_inner(int id)
{
    __atomic_add_fetch(&ready_count, 1, __ATOMIC_SEQ_CST);
    for (;;) {
        pause();
    }
    return id;
}

static int park_outer(int id) { return park_inner(id) + 1; }

static void *worker(void *arg)
{
    long id = (long) arg;
    return (void *) (long) park_outer((int) id);
}

int main(void)
{
    pthread_t t[3];
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, 256 * 1024);
    for (long i = 0; i < 3; i++) {
        pthread_create(&t[i], &attr, worker, (void *) i);
    }
    while (__atomic_load_n(&ready_count, __ATOMIC_SEQ_CST) < 3) {
        usleep(1000);
    }
    usleep(50000);
    printf("threads ready\n");
    fflush(stdout);
    volatile int *p = (int *) 0;
    return *p;
}
