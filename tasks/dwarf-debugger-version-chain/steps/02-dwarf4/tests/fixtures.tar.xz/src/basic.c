/* basic.c - globals, statics, recursion, switch, string data */
#include <stdio.h>
#include <string.h>

int g_int = 42;
static double g_double = 1.5;
char g_array[64] = "the quick brown fox";
static const char *g_ptr = "pointer target";
long g_bss_long;
static int g_bss_arr[24];

static int square(int v) { return v * v; }

int accumulate(const int *values, int n)
{
    int total = 0;
    for (int i = 0; i < n; i++) {
        total += square(values[i]);
    }
    return total;
}

int classify(int v)
{
    switch (v & 7) {
    case 0: return 100;
    case 1: return 101;
    case 2: return 102;
    case 3: return g_int;
    case 4: return (int) g_double;
    case 5: return g_array[3];
    case 6: return (int) strlen(g_ptr);
    default: return -1;
    }
}

int recurse(int depth, int acc)
{
    if (depth <= 0) {
        return acc;
    }
    return recurse(depth - 1, acc + classify(depth));
}

int mixer(int a, long b, char c, double d)
{
    int r = a + (int) b + c;
    if (d > 0.0) {
        r += (int) d;
    }
    g_bss_long = b;
    g_bss_arr[a & 15] = r;
    return r;
}

int main(int argc, char **argv)
{
    int vals[8] = { 1, 2, 3, 4, 5, 6, 7, 8 };
    int s = accumulate(vals, 8);
    s += recurse(6, 0);
    s += mixer(argc, 9L, 'x', 2.5);
    printf("%d %s\n", s, argv[0] ? "y" : "n");
    return s & 1;
}
