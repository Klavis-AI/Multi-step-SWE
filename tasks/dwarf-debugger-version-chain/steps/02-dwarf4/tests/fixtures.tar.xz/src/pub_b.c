/* pub_b.c - public sample: inlining chain and a cold branch */
#include <stdio.h>

static inline int tiny(int x) { return x + 7; }
static inline int small(int x) { return tiny(x) * 2; }
static inline int medium(int x) { return small(x) + small(x + 3); }

__attribute__((noinline, cold)) static int seldom(int x)
{
    char pad[32];
    for (unsigned i = 0; i < sizeof pad; i++) pad[i] = (char) (x + (int) i);
    return pad[5] + x;
}

int entry_point(int x)
{
    if (__builtin_expect(x > 999999, 0)) return seldom(x);
    return medium(x) + medium(x * 3);
}

int main(int argc, char **argv)
{
    (void) argv;
    printf("%d\n", entry_point(argc));
    return 0;
}
