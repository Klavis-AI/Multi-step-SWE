/* mixed_a.c - one translation unit of a mixed-DWARF-version executable */
#include <stdio.h>
int mixed_b_entry(int x);
int mixed_c_entry(int x);

static int a_helper(int x) { return x * 5 + 2; }

int a_entry(int x)
{
    int t = a_helper(x);
    t += mixed_b_entry(x + 1);
    return t;
}

int main(int argc, char **argv)
{
    (void) argv;
    printf("%d\n", a_entry(argc) + mixed_c_entry(argc));
    return 0;
}
