/* pub_e.c - public sample: threads parked, main faults */
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
static volatile int pub_ready;
static int hold_inner(int id) { __atomic_add_fetch(&pub_ready, 1, __ATOMIC_SEQ_CST); for (;;) pause(); return id; }
static int hold_outer(int id) { return hold_inner(id) + 1; }
static void *runner(void *a) { return (void *) (long) hold_outer((int) (long) a); }
int main(void)
{
    pthread_t t[2];
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, 256 * 1024);
    for (long i = 0; i < 2; i++) pthread_create(&t[i], &attr, runner, (void *) i);
    while (__atomic_load_n(&pub_ready, __ATOMIC_SEQ_CST) < 2) usleep(1000);
    usleep(50000);
    printf("pub threads\n");
    fflush(stdout);
    volatile int *p = (int *) 0;
    return *p;
}
