/* pub_d.c - public sample: deep chain that faults, for a core file */
#include <stdio.h>
#include <string.h>
static int stage_d(int d, const char *t)
{
    char b[24];
    strncpy(b, t, sizeof b - 1);
    b[sizeof b - 1] = 0;
    volatile int *p = (int *) 0;
    if (d > 0) return *p;
    return (int) strlen(b);
}
static int stage_c(int d, const char *t) { return stage_d(d + 1, t) + 1; }
static int stage_b(int d, const char *t) { return stage_c(d + 1, t) + 2; }
int stage_a(int d, const char *t) { return stage_b(d + 1, t) + 3; }
int main(int argc, char **argv)
{
    (void) argv;
    printf("pub deep\n");
    fflush(stdout);
    return stage_a(argc, "pub-tag");
}
