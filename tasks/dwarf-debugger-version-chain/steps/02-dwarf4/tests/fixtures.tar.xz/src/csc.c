/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --seed 100303 --max-funcs 8
 * Seed:      100303
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
#pragma pack(push)
#pragma pack(1)
struct S0 {
   uint8_t  f0;
   const int8_t  f1;
   const int64_t  f2;
   int32_t  f3;
   int32_t  f4;
   int8_t  f5;
   uint64_t  f6;
   uint8_t  f7;
   uint8_t  f8;
};
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
struct S1 {
   volatile signed f0 : 12;
   signed f1 : 6;
   const unsigned f2 : 27;
   unsigned f3 : 18;
   signed f4 : 20;
   volatile unsigned f5 : 31;
};
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
struct S2 {
   volatile unsigned f0 : 21;
};
#pragma pack(pop)

union U3 {
   const int8_t * f0;
   const struct S0  f1;
   signed f2 : 4;
   unsigned f3 : 24;
};

/* --- GLOBAL VARIABLES --- */
static const volatile int8_t g_3 = (-1L);/* VOLATILE GLOBAL g_3 */
static const volatile int8_t *g_2 = &g_3;
static int8_t g_5 = 0x69L;
static int32_t g_8 = (-2L);
static volatile int32_t g_11 = 0x4795ED7CL;/* VOLATILE GLOBAL g_11 */
static int32_t g_12 = 0x49A2F381L;
static int32_t g_45 = 0x820F90F5L;
static int32_t g_69 = 0L;
static int32_t *g_79 = (void*)0;
static int32_t **g_78 = &g_79;
static uint32_t g_94 = 0UL;
static uint32_t g_123 = 0xCFF8D1E4L;
static uint8_t g_125 = 249UL;
static int8_t g_136[7] = {(-7L),(-7L),(-7L),(-7L),(-7L),(-7L),(-7L)};
static struct S0 g_169 = {0x73L,-4L,0x83898E21F576C3BBLL,0xA4160963L,0x3BD90028L,0xECL,0x404F4F1AD9D65D8ELL,0UL,0x42L};
static volatile uint64_t g_183 = 0xF565D056814D9410LL;/* VOLATILE GLOBAL g_183 */
static volatile uint64_t *g_182 = &g_183;
static int16_t g_185 = 0x0568L;
static int32_t * volatile ***g_186 = (void*)0;
static int64_t g_188 = 0x2A6C9F1C0895ADC9LL;
static const int32_t *g_193[3][6] = {{&g_12,&g_69,&g_69,&g_12,&g_45,&g_12},{&g_12,&g_45,&g_12,&g_69,&g_69,&g_12},{(void*)0,(void*)0,&g_69,(void*)0,&g_69,(void*)0}};
static uint16_t g_223 = 65529UL;
static const uint32_t g_294[9] = {0xAFCFC309L,0xAFCFC309L,0xAFCFC309L,0xAFCFC309L,0xAFCFC309L,0xAFCFC309L,0xAFCFC309L,0xAFCFC309L,0xAFCFC309L};
static union U3 g_310 = {0};
static int32_t g_313[3][9] = {{(-4L),0xEA268230L,0xC8FF3749L,0xEA268230L,(-4L),0x9A20B887L,0x9A20B887L,(-4L),0xEA268230L},{7L,(-1L),7L,0xC8FF3749L,(-1L),(-1L),0xC8FF3749L,(-4L),1L},{1L,(-4L),0xC8FF3749L,(-1L),(-1L),0xC8FF3749L,(-4L),1L,(-4L)}};
static int32_t g_315[2] = {0L,0L};
static int16_t g_360 = 0x6D04L;
static uint16_t *g_525 = &g_223;
static uint64_t g_542 = 0x5ACD4CEF0FBD404CLL;
static int32_t ** const **g_668 = (void*)0;
static uint32_t g_670 = 0x4080DF3BL;
static union U3 *g_673 = &g_310;
static union U3 **g_672 = &g_673;
static struct S2 g_739 = {1323};/* VOLATILE GLOBAL g_739 */
static struct S2 g_743 = {438};/* VOLATILE GLOBAL g_743 */
static uint32_t *g_757 = &g_123;
static uint32_t **g_756 = &g_757;
static union U3 ***g_767 = &g_672;
static int32_t g_790 = 0x976EAD8DL;
static uint32_t *g_833 = &g_94;
static uint32_t **g_832[8][5][1] = {{{&g_833},{&g_833},{&g_833},{&g_833},{&g_833}},{{&g_833},{&g_833},{&g_833},{&g_833},{&g_833}},{{&g_833},{&g_833},{&g_833},{&g_833},{&g_833}},{{&g_833},{&g_833},{&g_833},{&g_833},{&g_833}},{{&g_833},{&g_833},{&g_833},{&g_833},{&g_833}},{{&g_833},{&g_833},{&g_833},{&g_833},{&g_833}},{{&g_833},{&g_833},{&g_833},{&g_833},{&g_833}},{{&g_833},{&g_833},{&g_833},{&g_833},{&g_833}}};
static int32_t g_835 = 1L;
static uint64_t g_887 = 18446744073709551615UL;
static uint8_t * const g_915 = (void*)0;
static uint8_t * const *g_914[2] = {&g_915,&g_915};
static int8_t g_935 = 0x16L;
static int16_t g_970 = 4L;
static int64_t *g_1000 = &g_188;
static int64_t **g_999 = &g_1000;
static struct S1 g_1006[3] = {{-4,-3,10701,404,752,22349},{-4,-3,10701,404,752,22349},{-4,-3,10701,404,752,22349}};
static struct S1 g_1007 = {8,1,322,495,-1023,259};/* VOLATILE GLOBAL g_1007 */
static struct S1 g_1008 = {-17,-4,9886,240,776,19550};/* VOLATILE GLOBAL g_1008 */
static struct S1 g_1009 = {-32,1,7562,307,428,4033};/* VOLATILE GLOBAL g_1009 */
static struct S1 g_1010 = {58,0,3703,390,224,42648};/* VOLATILE GLOBAL g_1010 */
static struct S1 g_1011 = {30,0,4334,465,-857,23426};/* VOLATILE GLOBAL g_1011 */
static struct S1 g_1012[2][4] = {{{8,-1,690,49,978,13031},{8,-1,690,49,978,13031},{8,-1,690,49,978,13031},{8,-1,690,49,978,13031}},{{8,-1,690,49,978,13031},{8,-1,690,49,978,13031},{8,-1,690,49,978,13031},{8,-1,690,49,978,13031}}};
static struct S1 g_1013 = {-56,3,7222,469,-402,9224};/* VOLATILE GLOBAL g_1013 */
static struct S0 g_1017[1] = {{252UL,-1L,-8L,0x8C42660EL,0x4021D908L,0xE4L,8UL,254UL,3UL}};
static union U3 g_1069 = {0};
static uint16_t g_1071[3] = {0UL,0UL,0UL};
static struct S1 g_1140 = {6,6,7328,155,-898,9229};/* VOLATILE GLOBAL g_1140 */
static struct S1 g_1145 = {34,0,5110,370,547,10710};/* VOLATILE GLOBAL g_1145 */
static struct S1 *g_1144 = &g_1145;
static struct S1 **g_1143 = &g_1144;
static struct S1 ***g_1142 = &g_1143;
static uint8_t g_1148 = 4UL;
static int64_t g_1216 = (-8L);
static uint64_t g_1226 = 0x12212BD0759ED774LL;
static struct S0 * volatile g_1247 = &g_1017[0];/* VOLATILE GLOBAL g_1247 */
static struct S0 * volatile *g_1246 = &g_1247;
static struct S1 g_1270 = {62,-2,3275,263,-773,7891};/* VOLATILE GLOBAL g_1270 */
static int32_t g_1450[6][1][4] = {{{0x89CB73C4L,0L,0x89CB73C4L,0x565977C0L}},{{0xE77DD42DL,0xB576C796L,0x565977C0L,0x565977C0L}},{{0L,0L,0x8A010E54L,0xB576C796L}},{{0xB576C796L,0xE77DD42DL,0x8A010E54L,0xE77DD42DL}},{{0L,0x89CB73C4L,0x565977C0L,0x8A010E54L}},{{0xE77DD42DL,0x89CB73C4L,0x89CB73C4L,0xE77DD42DL}}};
static const union U3 g_1491 = {0};
static const union U3 *g_1490 = &g_1491;
static const union U3 **g_1489 = &g_1490;
static const union U3 ***g_1488[7] = {&g_1489,&g_1489,&g_1489,&g_1489,&g_1489,&g_1489,&g_1489};
static const union U3 ****g_1487 = &g_1488[2];
static struct S0 g_1503 = {247UL,0x54L,1L,0xE70DBE2CL,0x8CB9C573L,0x87L,7UL,0x25L,0xC0L};
static struct S2 g_1507 = {826};/* VOLATILE GLOBAL g_1507 */
static int16_t *g_1514[3][7] = {{&g_185,&g_970,&g_185,&g_970,&g_185,&g_185,&g_970},{&g_360,&g_970,&g_360,&g_970,&g_970,&g_360,&g_970},{&g_970,(void*)0,&g_185,&g_185,(void*)0,&g_970,(void*)0}};
static int16_t **g_1513 = &g_1514[2][3];
static union U3 ****g_1574 = &g_767;
static union U3 *****g_1573 = &g_1574;
static union U3 *****g_1575 = &g_1574;
static struct S2 g_1813 = {933};/* VOLATILE GLOBAL g_1813 */
static struct S2 *g_1815 = (void*)0;
static struct S2 g_1818 = {428};/* VOLATILE GLOBAL g_1818 */
static int32_t g_1831 = 0L;
static int8_t g_1877 = 0xEDL;
static int8_t *g_1903 = &g_935;
static int8_t g_1965 = 0xDBL;
static const struct S1 g_1973 = {57,-5,1171,508,356,14764};/* VOLATILE GLOBAL g_1973 */
static int32_t ***g_1989[2][7][1] = {{{&g_78},{&g_78},{&g_78},{&g_78},{&g_78},{&g_78},{&g_78}},{{&g_78},{&g_78},{&g_78},{&g_78},{&g_78},{&g_78},{&g_78}}};
static int32_t *g_2014 = &g_8;
static int64_t g_2052[4] = {0x71E699FB92A9F23FLL,0x71E699FB92A9F23FLL,0x71E699FB92A9F23FLL,0x71E699FB92A9F23FLL};
static union U3 * const *g_2130 = &g_673;
static union U3 * const **g_2129 = &g_2130;
static union U3 * const ***g_2128 = &g_2129;
static union U3 * const ****g_2127 = &g_2128;
static int32_t *g_2262 = &g_1831;
static const struct S2 g_2290 = {201};/* VOLATILE GLOBAL g_2290 */
static struct S2 g_2388 = {1201};/* VOLATILE GLOBAL g_2388 */
static struct S2 g_2396 = {1109};/* VOLATILE GLOBAL g_2396 */
static uint8_t g_2418[5][4] = {{0x73L,0x73L,252UL,0x73L},{0x73L,250UL,250UL,0x73L},{250UL,0x73L,250UL,250UL},{0x73L,0x73L,252UL,0x73L},{0x73L,250UL,250UL,0x73L}};
static volatile struct S2 g_2528 = {333};/* VOLATILE GLOBAL g_2528 */
static volatile struct S2 g_2581 = {819};/* VOLATILE GLOBAL g_2581 */
static struct S2 g_2660 = {897};/* VOLATILE GLOBAL g_2660 */
static struct S2 g_2673 = {1228};/* VOLATILE GLOBAL g_2673 */
static volatile union U3 g_2693 = {0};/* VOLATILE GLOBAL g_2693 */
static volatile union U3 *g_2692 = &g_2693;
static volatile union U3 ** const g_2691 = &g_2692;
static struct S2 g_2759 = {927};/* VOLATILE GLOBAL g_2759 */
static volatile struct S2 g_2761 = {76};/* VOLATILE GLOBAL g_2761 */
static struct S2 g_2773 = {215};/* VOLATILE GLOBAL g_2773 */
static volatile uint8_t g_2812 = 255UL;/* VOLATILE GLOBAL g_2812 */
static const struct S1 g_2841[7] = {{53,1,4868,316,867,37387},{53,1,4868,316,867,37387},{53,1,4868,316,867,37387},{53,1,4868,316,867,37387},{53,1,4868,316,867,37387},{53,1,4868,316,867,37387},{53,1,4868,316,867,37387}};
static volatile struct S2 g_2927 = {85};/* VOLATILE GLOBAL g_2927 */
static int32_t *g_2974[1][6][4] = {{{&g_1450[2][0][1],&g_1450[2][0][1],&g_315[0],&g_1450[2][0][1]},{&g_1450[2][0][1],(void*)0,(void*)0,&g_1450[2][0][1]},{(void*)0,&g_1450[2][0][1],(void*)0,(void*)0},{&g_1450[2][0][1],&g_1450[2][0][1],&g_315[0],&g_1450[2][0][1]},{&g_1450[2][0][1],(void*)0,(void*)0,&g_1450[2][0][1]},{&g_315[0],(void*)0,&g_315[0],&g_315[0]}}};
static volatile struct S2 g_2985[8][3][3] = {{{{1344},{1344},{1387}},{{722},{1208},{1403}},{{351},{140},{368}}},{{{506},{1403},{1068}},{{104},{351},{368}},{{1407},{135},{1403}}},{{{639},{1111},{1387}},{{825},{42},{1367}},{{368},{1367},{140}}},{{{368},{639},{639}},{{825},{1068},{696}},{{639},{486},{318}}},{{{1407},{104},{1384}},{{104},{696},{1407}},{{506},{104},{760}}},{{{351},{486},{722}},{{722},{1068},{486}},{{1344},{639},{515}}},{{{1403},{1367},{515}},{{486},{42},{486}},{{385},{1111},{722}}},{{{1277},{135},{760}},{{1387},{351},{1407}},{{661},{1403},{1384}}}};
static int16_t ***g_3006 = (void*)0;
static uint32_t g_3012[2][3][6] = {{{0xC1C76D82L,0x14050B87L,8UL,0x14050B87L,0xC1C76D82L,8UL},{0x14050B87L,0xC1C76D82L,8UL,0x9182388EL,0x9182388EL,8UL},{0x9182388EL,0x9182388EL,8UL,0xC1C76D82L,0x14050B87L,8UL}},{{0xC1C76D82L,0x14050B87L,8UL,0x14050B87L,0xC1C76D82L,8UL},{0x14050B87L,0xC1C76D82L,8UL,0x9182388EL,0x9182388EL,8UL},{0x9182388EL,0x9182388EL,8UL,0xC1C76D82L,0x14050B87L,8UL}}};
static const int16_t *g_3024 = &g_185;
static const int16_t **g_3023 = &g_3024;
static const int16_t ***g_3022 = &g_3023;
static struct S0 ***g_3034 = (void*)0;
static volatile int8_t g_3049 = 0x4CL;/* VOLATILE GLOBAL g_3049 */
static uint32_t ** const *g_3061 = (void*)0;
static uint32_t ** const ** volatile g_3060 = &g_3061;/* VOLATILE GLOBAL g_3060 */
static struct S2 g_3175[3][2][1] = {{{{530}},{{530}}},{{{530}},{{530}}},{{{530}},{{530}}}};
static uint32_t *g_3197[9] = {&g_670,&g_670,&g_670,&g_670,&g_670,&g_670,&g_670,&g_670,&g_670};
static const struct S0 g_3226 = {0UL,1L,0x3542AA5F143591B9LL,0x5E09F0A2L,-1L,1L,0x6800109CC6357F2FLL,254UL,0UL};
static struct S2 * volatile g_3232 = &g_1507;/* VOLATILE GLOBAL g_3232 */
static struct S1 g_3255[3][2] = {{{-48,-3,9478,257,-155,11601},{-48,-3,9478,257,-155,11601}},{{-48,-3,9478,257,-155,11601},{-48,-3,9478,257,-155,11601}},{{-48,-3,9478,257,-155,11601},{-48,-3,9478,257,-155,11601}}};
static volatile union U3 *g_3320 = &g_2693;
static struct S2 * volatile *g_3340 = &g_3232;
static struct S2 * volatile ** volatile g_3339[2][5] = {{&g_3340,&g_3340,&g_3340,&g_3340,&g_3340},{&g_3340,&g_3340,&g_3340,&g_3340,&g_3340}};
static int32_t g_3344 = 0xE2AD50A6L;
static struct S2 g_3350 = {1438};/* VOLATILE GLOBAL g_3350 */
static struct S2 g_3371 = {312};/* VOLATILE GLOBAL g_3371 */
static const int32_t g_3388 = 0L;
static volatile int32_t g_3400 = (-10L);/* VOLATILE GLOBAL g_3400 */
static const uint32_t *g_3422 = &g_123;
static const uint32_t **g_3421 = &g_3422;
static uint8_t g_3426[7][9][2] = {{{255UL,0x64L},{255UL,255UL},{0xD4L,0x59L},{1UL,251UL},{0xEAL,0xFEL},{0x64L,0xEAL},{1UL,0x92L},{1UL,0xEAL},{0x64L,0xFEL}},{{0xEAL,251UL},{1UL,0x59L},{0xD4L,255UL},{255UL,0x64L},{255UL,0xC3L},{255UL,255UL},{250UL,1UL},{1UL,0UL},{0x2BL,0xFEL}},{{0xC3L,0x2BL},{1UL,0xBEL},{247UL,0xEAL},{0xC3L,5UL},{0xEAL,0UL},{0x8BL,5UL},{1UL,0x7FL},{0x92L,0xF9L},{0xC9L,0xF9L}},{{0x92L,0x7FL},{1UL,5UL},{246UL,0x64L},{0xD4L,0x1BL},{0xF9L,0xD4L},{0xDFL,0x2BL},{251UL,8UL},{0xF9L,0xB3L},{8UL,0x64L}},{{247UL,0UL},{1UL,0x92L},{0x7FL,0xF9L},{255UL,3UL},{0x92L,0x92L},{7UL,5UL},{247UL,255UL},{0xD4L,0xB3L},{3UL,0xD4L}},{{251UL,0x15L},{251UL,0xD4L},{3UL,0xB3L},{0xD4L,255UL},{247UL,5UL},{7UL,0x92L},{0x92L,3UL},{255UL,0xF9L},{0x7FL,0x92L}},{{1UL,0UL},{247UL,0x64L},{8UL,0xB3L},{0xF9L,8UL},{251UL,0x2BL},{0xDFL,0xD4L},{0xF9L,0x1BL},{0xD4L,0x64L},{246UL,5UL}}};
static struct S2 g_3427 = {876};/* VOLATILE GLOBAL g_3427 */
static int64_t g_3433[4][9][2] = {{{(-1L),1L},{1L,(-1L)},{1L,1L},{(-1L),(-1L)},{(-1L),1L},{1L,(-1L)},{1L,1L},{(-1L),(-1L)},{(-1L),1L}},{{1L,(-1L)},{1L,1L},{(-1L),(-1L)},{(-1L),1L},{1L,(-1L)},{1L,1L},{(-1L),(-1L)},{(-1L),1L},{1L,(-1L)}},{{1L,1L},{(-1L),(-1L)},{(-1L),1L},{1L,(-1L)},{1L,1L},{(-1L),(-1L)},{(-1L),1L},{1L,(-1L)},{1L,1L}},{{(-1L),(-1L)},{(-1L),1L},{1L,(-1L)},{1L,1L},{(-1L),(-1L)},{(-1L),1L},{1L,(-1L)},{1L,1L},{(-1L),(-1L)}}};
static volatile struct S1 g_3449 = {40,-5,6776,256,-542,28840};/* VOLATILE GLOBAL g_3449 */
static uint16_t g_3472 = 0x7978L;
static struct S2 g_3475 = {538};/* VOLATILE GLOBAL g_3475 */
static volatile int64_t g_3508 = 0x491D13888AFF3F21LL;/* VOLATILE GLOBAL g_3508 */
static volatile struct S1 g_3521 = {-24,-6,6512,465,321,13511};/* VOLATILE GLOBAL g_3521 */
static int8_t g_3576 = 0x9AL;
static const int32_t ** volatile g_3584 = (void*)0;/* VOLATILE GLOBAL g_3584 */
static const int32_t ** volatile g_3585[3] = {&g_193[0][3],&g_193[0][3],&g_193[0][3]};
static struct S2 g_3587 = {0};/* VOLATILE GLOBAL g_3587 */
static struct S2 g_3602 = {283};/* VOLATILE GLOBAL g_3602 */
static struct S2 g_3625 = {1305};/* VOLATILE GLOBAL g_3625 */
static const struct S1 *g_3665 = &g_1006[2];
static const struct S1 ** volatile g_3664[10][2][2] = {{{&g_3665,&g_3665},{&g_3665,&g_3665}},{{&g_3665,&g_3665},{&g_3665,&g_3665}},{{&g_3665,&g_3665},{&g_3665,&g_3665}},{{&g_3665,&g_3665},{&g_3665,&g_3665}},{{&g_3665,&g_3665},{&g_3665,&g_3665}},{{&g_3665,&g_3665},{&g_3665,&g_3665}},{{&g_3665,&g_3665},{&g_3665,&g_3665}},{{&g_3665,&g_3665},{&g_3665,&g_3665}},{{&g_3665,&g_3665},{&g_3665,&g_3665}},{{&g_3665,&g_3665},{&g_3665,&g_3665}}};
static const struct S1 ** volatile g_3666 = &g_3665;/* VOLATILE GLOBAL g_3666 */
static int32_t *****g_3700 = (void*)0;
static struct S1 g_3701 = {62,6,11405,481,319,10733};/* VOLATILE GLOBAL g_3701 */
static uint32_t g_3728 = 0xCFAA8C09L;
static const volatile struct S2 g_3729 = {674};/* VOLATILE GLOBAL g_3729 */
static struct S2 g_3750[8][1][5] = {{{{1209},{177},{503},{746},{164}}},{{{164},{746},{503},{177},{1209}}},{{{164},{177},{968},{177},{164}}},{{{1209},{177},{503},{746},{164}}},{{{164},{746},{503},{177},{1209}}},{{{164},{177},{968},{177},{164}}},{{{1209},{177},{503},{746},{164}}},{{{164},{746},{503},{177},{1209}}}};
static struct S2 g_3780 = {1271};/* VOLATILE GLOBAL g_3780 */
static volatile struct S2 g_3826 = {583};/* VOLATILE GLOBAL g_3826 */
static volatile struct S2 g_3859 = {1372};/* VOLATILE GLOBAL g_3859 */
static struct S2 g_3887[1][1][4] = {{{{1395},{1395},{1395},{1395}}}};
static uint32_t *** const *g_3943 = (void*)0;
static const struct S2 g_3945 = {1348};/* VOLATILE GLOBAL g_3945 */
static const struct S2 g_3964 = {1095};/* VOLATILE GLOBAL g_3964 */
static uint64_t g_4008 = 9UL;
static struct S2 g_4091[1] = {{1382}};
static struct S2 g_4113[2][1][2] = {{{{1205},{1205}}},{{{1205},{1205}}}};
static volatile struct S2 g_4114[7][5][7] = {{{{957},{743},{1446},{112},{112},{1446},{743}},{{1206},{1231},{1238},{1442},{994},{713},{572}},{{552},{696},{1441},{330},{244},{353},{624}},{{1404},{777},{901},{1442},{941},{1206},{713}},{{591},{624},{779},{112},{400},{248},{111}}},{{{637},{659},{837},{1289},{728},{888},{510}},{{1315},{3},{1204},{740},{181},{1383},{1446}},{{407},{728},{814},{1148},{1294},{450},{450}},{{751},{1204},{1349},{1204},{751},{299},{3}},{{1231},{1090},{1404},{58},{399},{36},{1346}}},{{{112},{1240},{349},{696},{624},{244},{1039}},{{1231},{58},{561},{450},{1107},{1090},{1101}},{{751},{881},{534},{1340},{1343},{552},{611}},{{407},{1114},{510},{650},{58},{637},{434}},{{1315},{342},{1361},{353},{1202},{349},{1340}}},{{{637},{159},{462},{323},{901},{323},{462}},{{591},{591},{460},{927},{854},{729},{1240}},{{1404},{200},{910},{407},{510},{837},{941}},{{552},{751},{330},{482},{854},{1169},{696}},{{1206},{267},{323},{994},{901},{58},{399}}},{{{534},{683},{1441},{400},{1383},{751},{1202}},{{1090},{1312},{460},{1294},{510},{36},{1101}},{{1383},{1343},{1204},{916},{1202},{779},{482}},{{381},{1404},{1442},{1442},{1404},{381},{267}},{{1240},{742},{683},{482},{916},{854},{743}}},{{{1442},{58},{400},{594},{450},{777},{1289}},{{299},{742},{44},{729},{349},{1441},{364}},{{1312},{1404},{1356},{888},{1418},{267},{1346}},{{1340},{1343},{552},{611},{299},{460},{349}},{{1346},{1312},{910},{994},{135},{1206},{434}}},{{{779},{683},{611},{1383},{342},{342},{1383}},{{1231},{1206},{1231},{1238},{1442},{994},{713}},{{181},{349},{850},{1204},{729},{1169},{552}},{{1356},{200},{888},{399},{434},{994},{561}},{{854},{611},{916},{743},{850},{342},{111}}}};
static uint8_t g_4118 = 0xE1L;
static volatile struct S2 g_4155 = {984};/* VOLATILE GLOBAL g_4155 */
static const int16_t ***** volatile g_4157 = (void*)0;/* VOLATILE GLOBAL g_4157 */


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t * func_15(int64_t  p_16, uint32_t  p_17, const int8_t * p_18);
static uint8_t  func_21(int16_t  p_22);
static int16_t  func_36(int8_t  p_37, uint8_t  p_38, int8_t  p_39, uint32_t  p_40);
static uint8_t  func_41(int8_t * p_42);
static int8_t * func_43(int8_t * p_44);
static uint16_t  func_55(int32_t * p_56, uint16_t  p_57);
static int32_t * func_58(const uint64_t  p_59, int16_t  p_60, int32_t  p_61, int32_t * p_62);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_3175 g_525 g_223 g_756 g_757 g_45 g_182 g_183 g_1000 g_188 g_3023 g_3024 g_185 g_169.f3 g_123 g_1503.f7 g_999 g_1246 g_2014 g_3 g_3022 g_1503.f6 g_833 g_94 g_2660 g_3232 g_3255 g_1071 g_1903 g_935 g_5 g_1017.f6 g_8 g_3320 g_2691 g_2692 g_2693 g_3339 g_3344 g_78 g_3350 g_11 g_3371 g_3340 g_3388 g_3400 g_169.f4 g_970 g_1017 g_3421 g_3427 g_3422 g_1503.f0 g_3449 g_3475 g_79 g_125 g_3508 g_3521 g_1142 g_1143 g_1144 g_1145 g_360 g_1247 g_1513 g_1514 g_169.f0 g_12 g_1575 g_1574 g_767 g_672 g_673 g_3576 g_3587 g_3602 g_1450 g_3625 g_2052 g_1507 g_3945 g_3964 g_1270.f2 g_1148 g_4008 g_4091 g_4113 g_4114 g_4118 g_4155
 * writes: g_5 g_8 g_223 g_123 g_45 g_3197 g_1247 g_1503.f6 g_1507 g_1071 g_935 g_94 g_1017.f6 g_1017.f7 g_3344 g_188 g_79 g_2052 g_3421 g_3426 g_1503.f0 g_125 g_360 g_1503.f7 g_1514 g_887 g_169.f0 g_12 g_169.f7 g_169.f3 g_1450 g_2974 g_3943 g_970 g_185 g_4008 g_2759 g_2396 g_1144
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int8_t * const l_4 = &g_5;
    int32_t *l_2502 = &g_45;
    struct S1 * const *l_3017 = &g_1144;
    const uint32_t l_3029 = 0x07BD0818L;
    uint32_t ** const *l_3059 = (void*)0;
    const union U3 ***l_3070 = &g_1489;
    uint32_t l_3164 = 0xC34AF19FL;
    uint8_t l_3201 = 253UL;
    uint32_t l_3203 = 4UL;
    int32_t l_3212 = 0x2F067D48L;
    int32_t l_3273 = 1L;
    struct S0 l_3312 = {0x5DL,0x4FL,0xB8B3EFFC142CC928LL,0xD5C0A849L,0x3EF3DA4DL,0xAEL,18446744073709551615UL,0xC1L,1UL};
    const uint32_t *l_3327 = &g_670;
    int32_t *l_3349[1][10][2] = {{{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0}}};
    union U3 **** const *l_3374 = &g_1574;
    struct S2 *l_3399[9] = {&g_2759,&g_2759,&g_2759,&g_2759,&g_2759,&g_2759,&g_2759,&g_2759,&g_2759};
    uint8_t l_3401 = 255UL;
    uint32_t l_3444 = 0xBA49AB93L;
    int32_t l_3446 = 0xF5707485L;
    const int64_t l_3577[6] = {0x77870A1B0D3F6ECBLL,0x77870A1B0D3F6ECBLL,0x77870A1B0D3F6ECBLL,0x77870A1B0D3F6ECBLL,0x77870A1B0D3F6ECBLL,0x77870A1B0D3F6ECBLL};
    uint16_t l_3579 = 1UL;
    uint32_t l_3624[2];
    uint32_t l_3645 = 1UL;
    uint64_t l_3653 = 0UL;
    int32_t l_3676 = 9L;
    uint64_t l_3678[1];
    uint16_t l_3702 = 0xA9FFL;
    uint64_t l_3762 = 0xAA9E69595580E019LL;
    struct S2 * const *l_3862 = &l_3399[3];
    struct S2 * const **l_3861 = &l_3862;
    uint32_t *l_3896 = &g_670;
    uint16_t l_3902 = 2UL;
    uint16_t l_3996 = 65526UL;
    struct S1 ****l_4031 = &g_1142;
    uint32_t *l_4089[2][7] = {{&l_3203,&g_3728,&g_3728,&l_3203,&g_3728,&g_3728,&l_3203},{&g_3728,&l_3203,&g_3728,&g_3728,&l_3203,&g_3728,&g_3728}};
    uint64_t l_4090 = 0x055516A13217A38FLL;
    int16_t ***l_4096 = &g_1513;
    uint64_t l_4135 = 18446744073709551615UL;
    int16_t l_4158[8][7][1] = {{{0xAD81L},{0xBF53L},{0xAD81L},{0L},{0x1D15L},{(-1L)},{(-7L)}},{{0x248CL},{0L},{0x248CL},{(-7L)},{(-1L)},{0x1D15L},{0L}},{{0xAD81L},{0xBF53L},{0xAD81L},{0L},{0x1D15L},{(-1L)},{(-7L)}},{{0x248CL},{0L},{0x248CL},{(-7L)},{(-1L)},{0x1D15L},{0L}},{{0xAD81L},{0xBF53L},{0xAD81L},{0L},{0x1D15L},{(-1L)},{(-7L)}},{{0x248CL},{0L},{0L},{0L},{0x82C0L},{1L},{0xBF53L}},{{(-7L)},{(-7L)},{(-7L)},{0xBF53L},{1L},{0x82C0L},{0L}},{{0L},{0L},{0L},{0L},{0x82C0L},{1L},{0xBF53L}}};
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_3624[i] = 0x56E43726L;
    for (i = 0; i < 1; i++)
        l_3678[i] = 0x05AE651048ECAD8BLL;
    if ((g_2 != l_4))
    { /* block id: 1 */
        int32_t l_23[1];
        uint32_t l_2503[9][1][5] = {{{0UL,0UL,0UL,0UL,0UL}},{{0UL,0xB2CEED1EL,0UL,0xB2CEED1EL,0UL}},{{0UL,0UL,0UL,0UL,0UL}},{{0UL,0xB2CEED1EL,0UL,0xB2CEED1EL,0UL}},{{0UL,0UL,0UL,0UL,0UL}},{{0UL,0xB2CEED1EL,0UL,0xB2CEED1EL,0UL}},{{0UL,0UL,0UL,0UL,0UL}},{{0UL,0xB2CEED1EL,0UL,0xB2CEED1EL,0UL}},{{0UL,0UL,0UL,0UL,0UL}}};
        int32_t l_2982 = (-8L);
        const int16_t ***l_3025 = &g_3023;
        int64_t **l_3038 = &g_1000;
        int32_t l_3039 = 0x3233E721L;
        const uint32_t l_3153 = 18446744073709551615UL;
        const int8_t l_3174 = 0xF1L;
        int16_t *l_3189 = (void*)0;
        int16_t *l_3190 = (void*)0;
        int16_t *l_3191[2];
        uint32_t *l_3194[10][5] = {{&g_3012[1][0][3],&g_3012[0][1][1],&g_3012[1][0][3],&g_3012[0][1][1],&g_3012[0][1][1]},{(void*)0,&g_3012[0][1][1],&g_3012[1][1][1],&g_3012[0][1][1],(void*)0},{&g_3012[1][0][3],&g_3012[0][0][5],&g_3012[0][1][1],(void*)0,&g_3012[0][1][1]},{&g_3012[0][2][3],&g_3012[0][2][3],&g_3012[1][1][1],(void*)0,&g_3012[1][1][0]},{&g_3012[0][0][5],&g_3012[1][0][3],&g_3012[1][0][3],&g_3012[0][0][5],&g_3012[0][1][1]},{&g_3012[0][1][1],(void*)0,&g_670,&g_670,(void*)0},{&g_3012[0][1][1],&g_3012[1][0][3],&g_3012[0][1][1],&g_3012[0][1][1],&g_3012[0][1][1]},{&g_670,&g_3012[0][2][3],&g_670,&g_670,&g_3012[1][1][1]},{(void*)0,&g_3012[0][0][5],&g_3012[0][1][1],&g_3012[0][0][5],(void*)0},{&g_670,&g_3012[0][1][1],&g_3012[0][2][3],(void*)0,&g_3012[0][2][3]}};
        uint32_t **l_3195 = (void*)0;
        uint32_t **l_3196[7][5][4] = {{{&l_3194[1][2],&l_3194[8][4],&l_3194[0][3],(void*)0},{&l_3194[1][2],(void*)0,&l_3194[6][3],&g_757},{&l_3194[1][2],(void*)0,&l_3194[0][3],&g_757},{&l_3194[1][2],&g_757,&l_3194[1][2],&l_3194[8][4]},{&l_3194[4][4],(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,&l_3194[8][4]},{&l_3194[1][2],&g_757,&l_3194[3][1],&g_757},{&g_757,(void*)0,&l_3194[4][4],&g_757},{&g_757,(void*)0,&l_3194[4][4],(void*)0},{&g_757,&l_3194[8][4],&l_3194[3][1],&l_3194[1][2]}},{{&l_3194[1][2],&l_3194[7][0],(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{&l_3194[4][4],&l_3194[7][0],&l_3194[1][2],&l_3194[1][2]},{&l_3194[1][2],&l_3194[8][4],&l_3194[0][3],(void*)0},{&l_3194[1][2],(void*)0,&l_3194[6][3],&g_757}},{{&l_3194[1][2],(void*)0,&l_3194[0][3],&g_757},{&l_3194[1][2],&g_757,&l_3194[1][2],&l_3194[8][4]},{&l_3194[4][4],(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&l_3194[7][0]},{&g_757,(void*)0,(void*)0,&l_3194[8][4]}},{{&l_3194[1][2],(void*)0,&g_757,(void*)0},{&l_3194[1][2],(void*)0,&g_757,(void*)0},{&l_3194[1][2],&l_3194[7][0],(void*)0,&g_757},{&g_757,&g_757,&l_3194[6][3],(void*)0},{&l_3194[6][3],(void*)0,&l_3194[1][2],(void*)0}},{{&g_757,&g_757,&l_3194[0][3],&g_757},{(void*)0,&l_3194[7][0],&l_3194[1][2],(void*)0},{&l_3194[0][3],(void*)0,&l_3194[4][4],(void*)0},{&l_3194[0][3],(void*)0,&l_3194[1][2],&l_3194[8][4]},{(void*)0,(void*)0,&l_3194[0][3],&l_3194[7][0]}},{{&g_757,&g_757,&l_3194[1][2],(void*)0},{&l_3194[6][3],&g_757,&l_3194[6][3],&l_3194[7][0]},{&g_757,(void*)0,(void*)0,&l_3194[8][4]},{&l_3194[1][2],(void*)0,&g_757,(void*)0},{&l_3194[1][2],(void*)0,&g_757,(void*)0}}};
        uint16_t *l_3200 = (void*)0;
        uint64_t l_3202 = 18446744073709551615UL;
        int16_t l_3267 = 0x7AEAL;
        uint64_t l_3317 = 0x8DBC6A358251EA39LL;
        int32_t **l_3322 = &l_2502;
        struct S2 **l_3346 = &g_1815;
        struct S2 ***l_3345 = &l_3346;
        int32_t l_3359[1];
        uint64_t l_3387[5][10][5] = {{{0xD5084C96E89071B5LL,0x266806653973C3AELL,1UL,0x266806653973C3AELL,0xD5084C96E89071B5LL},{0x28B2869A91B93138LL,18446744073709551612UL,0x6DB293400F35F01FLL,0x28B2869A91B93138LL,0x2F117F70BB6B78A3LL},{0xA58DCCD245C679D5LL,0x37130CA4079B7E92LL,0x4E582EB244681200LL,0xFF82F06ABA52B1CELL,0x4E582EB244681200LL},{0x2B31785E5270AE0ALL,0x2B31785E5270AE0ALL,8UL,18446744073709551612UL,0x2F117F70BB6B78A3LL},{0UL,0xFF82F06ABA52B1CELL,1UL,18446744073709551615UL,0xD5084C96E89071B5LL},{0x2F117F70BB6B78A3LL,0x6DB293400F35F01FLL,7UL,0x2B31785E5270AE0ALL,0x28B2869A91B93138LL},{0xA58DCCD245C679D5LL,0xFF82F06ABA52B1CELL,0xD81A1AAC5724FBD1LL,0x266806653973C3AELL,0xA58DCCD245C679D5LL},{0UL,0x2B31785E5270AE0ALL,0x6DB293400F35F01FLL,0x6DB293400F35F01FLL,0x2B31785E5270AE0ALL},{0xD5084C96E89071B5LL,0x37130CA4079B7E92LL,1UL,0x266806653973C3AELL,0UL},{0x2B31785E5270AE0ALL,18446744073709551612UL,0xE76BDB0152552A0BLL,0x2B31785E5270AE0ALL,0x2F117F70BB6B78A3LL}},{{0x4E582EB244681200LL,0x266806653973C3AELL,0x4E582EB244681200LL,18446744073709551615UL,0xA58DCCD245C679D5LL},{0x2B31785E5270AE0ALL,0x28B2869A91B93138LL,7UL,18446744073709551612UL,0UL},{0xD5084C96E89071B5LL,0xFF82F06ABA52B1CELL,1UL,0xFF82F06ABA52B1CELL,0xD5084C96E89071B5LL},{0UL,18446744073709551612UL,7UL,0x28B2869A91B93138LL,0x2B31785E5270AE0ALL},{0xA58DCCD245C679D5LL,18446744073709551615UL,0x4E582EB244681200LL,0x266806653973C3AELL,0x4E582EB244681200LL},{0x2F117F70BB6B78A3LL,0x2B31785E5270AE0ALL,0xE76BDB0152552A0BLL,18446744073709551612UL,0x2B31785E5270AE0ALL},{0UL,0x266806653973C3AELL,1UL,0x37130CA4079B7E92LL,0xD5084C96E89071B5LL},{0x2B31785E5270AE0ALL,0x6DB293400F35F01FLL,0x6DB293400F35F01FLL,0x2B31785E5270AE0ALL,0UL},{0xA58DCCD245C679D5LL,0x266806653973C3AELL,0xD81A1AAC5724FBD1LL,0xFF82F06ABA52B1CELL,0xA58DCCD245C679D5LL},{0x28B2869A91B93138LL,0x2B31785E5270AE0ALL,7UL,0x6DB293400F35F01FLL,0x2F117F70BB6B78A3LL}},{{0xD5084C96E89071B5LL,18446744073709551615UL,1UL,0xFF82F06ABA52B1CELL,0UL},{0x2F117F70BB6B78A3LL,18446744073709551612UL,8UL,0x2B31785E5270AE0ALL,0x2B31785E5270AE0ALL},{0x4E582EB244681200LL,0xFF82F06ABA52B1CELL,0x4E582EB244681200LL,0x37130CA4079B7E92LL,0xA58DCCD245C679D5LL},{0x2F117F70BB6B78A3LL,0x28B2869A91B93138LL,0x6DB293400F35F01FLL,18446744073709551612UL,0x28B2869A91B93138LL},{0xD5084C96E89071B5LL,0x266806653973C3AELL,1UL,0x266806653973C3AELL,0xD5084C96E89071B5LL},{0x28B2869A91B93138LL,0x6DB293400F35F01FLL,0xE76BDB0152552A0BLL,18446744073709551608UL,0UL},{0x4E582EB244681200LL,1UL,0xD81A1AAC5724FBD1LL,18446744073709551615UL,0xD81A1AAC5724FBD1LL},{0x28B2869A91B93138LL,0x28B2869A91B93138LL,18446744073709551615UL,0x6DB293400F35F01FLL,0UL},{1UL,18446744073709551615UL,1UL,0x39E30E5F4AC07780LL,0UL},{0UL,0xE76BDB0152552A0BLL,8UL,0x28B2869A91B93138LL,18446744073709551608UL}},{{0x4E582EB244681200LL,18446744073709551615UL,0xA58DCCD245C679D5LL,0x37130CA4079B7E92LL,0x4E582EB244681200LL},{2UL,0x28B2869A91B93138LL,0xE76BDB0152552A0BLL,0xE76BDB0152552A0BLL,0x28B2869A91B93138LL},{0UL,1UL,1UL,0x37130CA4079B7E92LL,1UL},{0x28B2869A91B93138LL,0x6DB293400F35F01FLL,18446744073709551612UL,0x28B2869A91B93138LL,0UL},{0xD81A1AAC5724FBD1LL,0x37130CA4079B7E92LL,0xD81A1AAC5724FBD1LL,0x39E30E5F4AC07780LL,0x4E582EB244681200LL},{0x28B2869A91B93138LL,18446744073709551608UL,8UL,0x6DB293400F35F01FLL,2UL},{0UL,18446744073709551615UL,0x4643E240F251A728LL,18446744073709551615UL,0UL},{2UL,0x6DB293400F35F01FLL,8UL,18446744073709551608UL,0x28B2869A91B93138LL},{0x4E582EB244681200LL,0x39E30E5F4AC07780LL,0xD81A1AAC5724FBD1LL,0x37130CA4079B7E92LL,0xD81A1AAC5724FBD1LL},{0UL,0x28B2869A91B93138LL,18446744073709551612UL,0x6DB293400F35F01FLL,0x28B2869A91B93138LL}},{{1UL,0x37130CA4079B7E92LL,1UL,1UL,0UL},{0x28B2869A91B93138LL,0xE76BDB0152552A0BLL,0xE76BDB0152552A0BLL,0x28B2869A91B93138LL,2UL},{0x4E582EB244681200LL,0x37130CA4079B7E92LL,0xA58DCCD245C679D5LL,18446744073709551615UL,0x4E582EB244681200LL},{18446744073709551608UL,0x28B2869A91B93138LL,8UL,0xE76BDB0152552A0BLL,0UL},{0UL,0x39E30E5F4AC07780LL,1UL,18446744073709551615UL,1UL},{0UL,0x6DB293400F35F01FLL,18446744073709551615UL,0x28B2869A91B93138LL,0x28B2869A91B93138LL},{0xD81A1AAC5724FBD1LL,18446744073709551615UL,0xD81A1AAC5724FBD1LL,1UL,0x4E582EB244681200LL},{0UL,18446744073709551608UL,0xE76BDB0152552A0BLL,0x6DB293400F35F01FLL,18446744073709551608UL},{0UL,0x37130CA4079B7E92LL,0x4643E240F251A728LL,0x37130CA4079B7E92LL,0UL},{18446744073709551608UL,0x6DB293400F35F01FLL,0xE76BDB0152552A0BLL,18446744073709551608UL,0UL}}};
        int32_t *l_3406 = &l_3039;
        uint8_t l_3445 = 1UL;
        union U3 *l_3546 = (void*)0;
        int8_t l_3590 = 0L;
        int8_t l_3598 = 1L;
        union U3 *** const *l_3603 = &g_767;
        uint32_t l_3610[5][7] = {{1UL,0x2B246E68L,0xCA142D6EL,0xE4AB713AL,0xCA142D6EL,0x2B246E68L,1UL},{0x82D13675L,0x6B72310DL,0x82D13675L,0x82D13675L,0x6B72310DL,0x82D13675L,0x82D13675L},{1UL,0xE4AB713AL,0x046FAA9DL,0xE4AB713AL,1UL,0x5531F318L,1UL},{0x6B72310DL,0x82D13675L,0x82D13675L,0x6B72310DL,0x82D13675L,0x82D13675L,0x6B72310DL},{0xCA142D6EL,0xE4AB713AL,0xCA142D6EL,0x2B246E68L,1UL,0x2B246E68L,0xCA142D6EL}};
        int64_t l_3614[5];
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_23[i] = 0L;
        for (i = 0; i < 2; i++)
            l_3191[i] = &g_185;
        for (i = 0; i < 1; i++)
            l_3359[i] = (-1L);
        for (i = 0; i < 5; i++)
            l_3614[i] = 1L;
lbl_3230:
        for (g_5 = (-26); (g_5 >= 0); ++g_5)
        { /* block id: 4 */
            uint64_t l_19 = 0x9A6FDD8FB8CEFFB9LL;
            int32_t l_2992 = 0x756149FFL;
            struct S0 *l_3032 = &g_1503;
            struct S0 **l_3031 = &l_3032;
            struct S0 ***l_3030[10][6] = {{&l_3031,&l_3031,&l_3031,&l_3031,&l_3031,&l_3031},{&l_3031,&l_3031,&l_3031,&l_3031,&l_3031,&l_3031},{&l_3031,&l_3031,&l_3031,&l_3031,&l_3031,&l_3031},{&l_3031,&l_3031,&l_3031,&l_3031,&l_3031,&l_3031},{&l_3031,&l_3031,&l_3031,&l_3031,&l_3031,&l_3031},{&l_3031,&l_3031,&l_3031,&l_3031,&l_3031,&l_3031},{&l_3031,&l_3031,&l_3031,&l_3031,&l_3031,&l_3031},{&l_3031,&l_3031,&l_3031,&l_3031,&l_3031,&l_3031},{&l_3031,&l_3031,&l_3031,&l_3031,&l_3031,&l_3031},{&l_3031,&l_3031,&l_3031,&l_3031,&l_3031,&l_3031}};
            uint64_t l_3035 = 1UL;
            uint32_t *l_3054[10][3] = {{(void*)0,(void*)0,(void*)0},{&g_670,&g_123,&g_670},{(void*)0,(void*)0,(void*)0},{&g_670,&g_123,&g_670},{(void*)0,(void*)0,(void*)0},{&g_670,&g_123,&g_670},{(void*)0,(void*)0,(void*)0},{&g_670,&g_123,&g_670},{(void*)0,(void*)0,(void*)0},{&g_670,&g_123,&g_670}};
            int32_t l_3155 = 0x1327AE8FL;
            int32_t *l_3157 = &l_2982;
            int i, j;
            for (g_8 = (-15); (g_8 != 14); g_8++)
            { /* block id: 7 */
                int8_t *l_20[9][3] = {{&g_5,(void*)0,&g_5},{&g_5,&g_5,(void*)0},{&g_5,(void*)0,(void*)0},{(void*)0,(void*)0,&g_5},{(void*)0,&g_5,&g_5},{&g_5,(void*)0,&g_5},{&g_5,&g_5,(void*)0},{&g_5,&g_5,(void*)0},{&g_5,&g_5,&g_5}};
                int16_t l_2988 = (-8L);
                int8_t l_3011 = 1L;
                uint32_t * const *l_3016 = &g_757;
                uint32_t * const ** const l_3015 = &l_3016;
                int32_t l_3077 = 1L;
                int32_t l_3090 = (-3L);
                int16_t **l_3126 = &g_1514[2][3];
                int16_t **l_3127 = &g_1514[0][5];
                int16_t **l_3128[7] = {&g_1514[2][1],&g_1514[2][1],&g_1514[2][3],&g_1514[2][1],&g_1514[2][1],&g_1514[2][3],&g_1514[2][1]};
                int16_t **l_3129 = &g_1514[2][6];
                int16_t *** const l_3125[3][8] = {{&l_3128[3],&l_3128[3],&l_3129,(void*)0,&l_3129,&l_3128[3],&l_3128[3],&l_3129},{&l_3126,&l_3129,&l_3129,&l_3126,&l_3127,&l_3126,&l_3129,&l_3129},{&l_3129,&l_3127,(void*)0,(void*)0,&l_3127,&l_3129,&l_3127,(void*)0}};
                int16_t *** const *l_3124 = &l_3125[0][5];
                int i, j;
            }
            if (l_3153)
                continue;
        }
        if ((((((void*)0 != &g_1071[1]) <= ((((safe_add_func_uint16_t_u_u((safe_add_func_uint32_t_u_u((((((safe_lshift_func_int8_t_s_s(l_3174, 2)) < 0xCEC9L) ^ (g_3175[0][1][0] , ((safe_sub_func_uint32_t_u_u(((((**g_756) = (safe_unary_minus_func_uint16_t_u(((*g_525)++)))) ^ (safe_rshift_func_int16_t_s_u((((safe_mul_func_uint8_t_u_u(l_3174, (safe_sub_func_int32_t_s_s((safe_add_func_int16_t_s_s(((*l_2502) |= 1L), (((((safe_mul_func_int16_t_s_s(((g_3197[4] = l_3194[1][2]) != ((((safe_rshift_func_uint16_t_u_s((l_3201 ^= ((0x6C3D9207L > l_3153) != 0xE295L)), l_3202)) || (*g_182)) || (*g_1000)) , (*g_756))), (**g_3023))) != l_2503[2][0][3]) , l_2503[2][0][3]) ^ g_169.f3) < 6UL))), 0x2DA43B8CL)))) <= 0x1986L) < l_3029), 8))) , (*g_757)), l_3153)) | l_3153))) && l_3203) , 4294967288UL), 0xCB25A346L)), 0x9211L)) == g_1503.f7) >= (**g_999)) > 4294967293UL)) & 65528UL) ^ 0x4B671243L))
        { /* block id: 1511 */
            struct S0 *l_3204 = &g_1017[0];
            int32_t l_3211 = 1L;
            const int32_t l_3220 = (-1L);
            int32_t **l_3323[10] = {&g_2014,&g_2014,&g_2014,&l_2502,&l_2502,&g_2014,&g_2014,&g_2014,&l_2502,&l_2502};
            union U3 ***l_3377 = &g_672;
            union U3 **** const l_3376 = &l_3377;
            union U3 **** const *l_3375[2];
            union U3 **** const *l_3378 = (void*)0;
            struct S1 ***l_3391 = &g_1143;
            uint32_t **l_3420 = &g_3197[7];
            uint8_t *l_3434 = &g_1503.f0;
            union U3 *****l_3441[8][7][2] = {{{(void*)0,(void*)0},{(void*)0,&g_1574},{(void*)0,(void*)0},{(void*)0,&g_1574},{(void*)0,(void*)0},{(void*)0,&g_1574},{(void*)0,(void*)0}},{{(void*)0,&g_1574},{(void*)0,(void*)0},{(void*)0,&g_1574},{(void*)0,(void*)0},{(void*)0,&g_1574},{(void*)0,(void*)0},{(void*)0,&g_1574}},{{(void*)0,(void*)0},{(void*)0,&g_1574},{(void*)0,(void*)0},{(void*)0,&g_1574},{(void*)0,(void*)0},{(void*)0,&g_1574},{(void*)0,(void*)0}},{{(void*)0,&g_1574},{(void*)0,(void*)0},{(void*)0,&g_1574},{(void*)0,(void*)0},{(void*)0,&g_1574},{(void*)0,(void*)0},{(void*)0,&g_1574}},{{(void*)0,(void*)0},{(void*)0,&g_1574},{(void*)0,(void*)0},{(void*)0,&g_1574},{(void*)0,(void*)0},{&g_1574,&g_1574},{(void*)0,&g_1574}},{{(void*)0,&g_1574},{&g_1574,(void*)0},{(void*)0,&g_1574},{(void*)0,(void*)0},{&g_1574,&g_1574},{(void*)0,&g_1574},{(void*)0,&g_1574}},{{&g_1574,(void*)0},{(void*)0,&g_1574},{(void*)0,(void*)0},{&g_1574,&g_1574},{(void*)0,&g_1574},{(void*)0,&g_1574},{&g_1574,(void*)0}},{{(void*)0,&g_1574},{(void*)0,(void*)0},{&g_1574,&g_1574},{(void*)0,&g_1574},{(void*)0,&g_1574},{&g_1574,(void*)0},{(void*)0,&g_1574}}};
            int i, j, k;
            for (i = 0; i < 2; i++)
                l_3375[i] = &l_3376;
lbl_3231:
            (*g_1246) = l_3204;
            if ((((safe_add_func_int32_t_s_s((safe_add_func_int8_t_s_s((9L > (((((((safe_rshift_func_uint16_t_u_u(l_3202, 0)) || (l_3211 >= l_3211)) && ((l_3211 > l_23[0]) == ((*g_2014) = (((*g_525) < 0x39FAL) ^ l_23[0])))) > l_3211) >= l_3212) && l_3211) ^ l_3211)), (*g_2))), 0xF24EB2B5L)) || 65535UL) && (-1L)))
            { /* block id: 1514 */
                int16_t *** const l_3213[7][10] = {{&g_1513,&g_1513,(void*)0,&g_1513,&g_1513,&g_1513,&g_1513,&g_1513,&g_1513,&g_1513},{&g_1513,(void*)0,(void*)0,&g_1513,&g_1513,(void*)0,&g_1513,&g_1513,&g_1513,&g_1513},{&g_1513,&g_1513,(void*)0,(void*)0,&g_1513,&g_1513,(void*)0,&g_1513,&g_1513,&g_1513},{&g_1513,&g_1513,(void*)0,&g_1513,&g_1513,(void*)0,&g_1513,&g_1513,&g_1513,&g_1513},{&g_1513,&g_1513,(void*)0,&g_1513,&g_1513,&g_1513,&g_1513,(void*)0,&g_1513,&g_1513},{&g_1513,&g_1513,(void*)0,&g_1513,&g_1513,(void*)0,(void*)0,&g_1513,&g_1513,(void*)0},{&g_1513,&g_1513,(void*)0,&g_1513,&g_1513,&g_1513,&g_1513,&g_1513,&g_1513,&g_1513}};
                const struct S0 * const l_3225 = &g_3226;
                const struct S0 * const *l_3224[10][8] = {{&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225},{&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225},{&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225},{&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225},{&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225},{&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225},{&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225},{&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225},{&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225},{&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225,&l_3225}};
                const struct S0 * const **l_3223 = &l_3224[5][2];
                int32_t l_3227 = 0x385309DDL;
                struct S0 ****l_3304 = &g_3034;
                int i, j;
                if ((0x2995L > (((l_3213[6][4] != &g_3023) & (*g_182)) < (safe_rshift_func_int16_t_s_s(((safe_div_func_int64_t_s_s(((safe_mod_func_int16_t_s_s(l_3220, ((safe_div_func_uint32_t_u_u((&l_3204 == ((*l_3223) = (void*)0)), ((*g_2014) = 0x42FE5673L))) , ((*l_2502) && (**g_999))))) != l_2503[2][0][3]), l_3220)) , (***g_3022)), l_3227)))))
                { /* block id: 1517 */
                    uint8_t l_3258[2];
                    uint16_t *l_3259 = (void*)0;
                    uint16_t *l_3260 = &g_1071[2];
                    int32_t l_3268 = 0x2A9003B9L;
                    int32_t l_3269 = 0x73442241L;
                    int32_t l_3270 = 0x990AD17CL;
                    int i;
                    for (i = 0; i < 2; i++)
                        l_3258[i] = 0x99L;
                    for (g_1503.f6 = 0; (g_1503.f6 == 36); ++g_1503.f6)
                    { /* block id: 1520 */
                        if (g_1503.f6)
                            goto lbl_3230;
                        return (*g_833);
                    }
                    if (g_169.f3)
                        goto lbl_3231;
                    (*g_3232) = g_2660;
                    l_3270 |= (safe_div_func_int32_t_s_s((safe_sub_func_int64_t_s_s((l_3227 > (*g_757)), (g_1017[0].f6 &= (safe_add_func_int64_t_s_s((((*g_833) ^= (safe_div_func_uint16_t_u_u((safe_rshift_func_int16_t_s_s((l_3211 = ((safe_mod_func_uint8_t_u_u(0UL, (safe_sub_func_uint16_t_u_u(((safe_sub_func_uint8_t_u_u(((safe_add_func_uint16_t_u_u((*g_525), (safe_mul_func_int8_t_s_s(((*l_4) &= ((*g_1903) |= (safe_sub_func_int16_t_s_s((g_3255[2][0] , (safe_lshift_func_uint16_t_u_s(l_3258[0], 14))), (++(*l_3260)))))), l_23[0])))) , 1UL), (safe_add_func_uint64_t_u_u(((((l_3268 = (safe_div_func_int16_t_s_s(l_3267, l_3258[0]))) ^ 0xDEL) >= l_3153) & 0x3085E71DL), (*l_2502))))) || 0L), (*g_525))))) , (*l_2502))), 8)), l_3227))) , l_3269), (*l_2502)))))), (*g_2014)));
                }
                else
                { /* block id: 1534 */
                    uint16_t l_3275[5] = {0x6F93L,0x6F93L,0x6F93L,0x6F93L,0x6F93L};
                    uint64_t l_3299 = 18446744073709551615UL;
                    const int32_t l_3313 = 0x38A3370DL;
                    int32_t l_3314 = 0x00CEAD2CL;
                    int i;
                    for (g_45 = (-9); (g_45 > 23); ++g_45)
                    { /* block id: 1537 */
                        int32_t *l_3274[9][1] = {{&l_3211},{&l_3039},{&l_3039},{&l_3211},{&l_3039},{&l_3039},{&l_3211},{&l_3039},{&l_3039}};
                        int i, j;
                        l_3275[1]--;
                        l_3039 &= ((*g_2014) &= (!((safe_div_func_uint64_t_u_u(0xF6ECBB7B4DA4CC25LL, (safe_mod_func_uint64_t_u_u((l_3275[2] && (!(((~(safe_add_func_uint64_t_u_u((safe_div_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u(((l_2982 , (((*g_757) = ((safe_rshift_func_int8_t_s_u((safe_rshift_func_uint16_t_u_u(65531UL, ((l_3211 && ((safe_mod_func_int64_t_s_s((**g_999), (safe_lshift_func_uint8_t_u_s((&g_1989[0][6][0] != &g_1989[1][5][0]), ((l_3153 <= 0L) == (*g_525)))))) < l_3211)) || (**g_3023)))), 5)) & (**g_999))) != l_3275[3])) != l_3299), 65535UL)), 0x34C49863L)), (*g_182)))) != (**g_999)) <= l_3275[0]))), l_23[0])))) != 65527UL)));
                    }
                    l_3314 = ((((((*l_2502) | (safe_mul_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u(((l_3304 != &g_3034) ^ 2UL), (*g_525))), (safe_rshift_func_uint16_t_u_s(((!0x7D20377D316A6E42LL) , (((safe_mod_func_int64_t_s_s((safe_rshift_func_int8_t_s_s(l_3275[1], (l_3312 , ((0x7450C2BBFD4FA013LL >= 0xD6F6F7DACD2ED743LL) || 9L)))), 0x951BA67A9490A3F6LL)) == (*g_525)) >= (-1L))), (*l_2502)))))) == l_3299) < l_3227) <= l_3313) & (*g_182));
                }
            }
            else
            { /* block id: 1545 */
                int32_t l_3326 = 0x7E73C0BDL;
                int32_t l_3367 = 0L;
                uint64_t l_3370 = 0UL;
                (*g_2014) = (safe_sub_func_uint8_t_u_u(l_3317, ((*l_4) = l_3220)));
                if (((safe_rshift_func_uint16_t_u_s(((*g_525) = (((**g_756) ^= (((((g_3320 == (void*)0) && (*l_2502)) || ((~(((**g_2691) , (l_3322 = &l_2502)) == l_3323[9])) ^ (0UL ^ ((void*)0 != &g_1965)))) & (*l_2502)) == (*l_2502))) & l_3326)), l_3326)) & 1UL))
                { /* block id: 1551 */
                    int16_t l_3336 = 0x7044L;
                    uint8_t *l_3342 = (void*)0;
                    uint8_t *l_3343 = &g_1017[0].f7;
                    struct S0 l_3365[1][5] = {{{0xFFL,3L,3L,0xD048053BL,0x403578FFL,0x1AL,0x1CDBD9168AF2906FLL,5UL,0x8CL},{0xFFL,3L,3L,0xD048053BL,0x403578FFL,0x1AL,0x1CDBD9168AF2906FLL,5UL,0x8CL},{0xFFL,3L,3L,0xD048053BL,0x403578FFL,0x1AL,0x1CDBD9168AF2906FLL,5UL,0x8CL},{0xFFL,3L,3L,0xD048053BL,0x403578FFL,0x1AL,0x1CDBD9168AF2906FLL,5UL,0x8CL},{0xFFL,3L,3L,0xD048053BL,0x403578FFL,0x1AL,0x1CDBD9168AF2906FLL,5UL,0x8CL}}};
                    int i, j;
                    if ((((void*)0 != l_3327) == ((((safe_sub_func_int32_t_s_s(((safe_rshift_func_uint16_t_u_s((safe_div_func_int16_t_s_s((((safe_mul_func_uint8_t_u_u((**l_3322), (l_3336 < ((((*g_525)++) >= (((((**l_3322) && (**g_999)) , g_3339[1][1]) == (((g_3344 |= (((*l_3343) = (+(g_1071[2] |= 0x5A63L))) == 255UL)) < (-1L)) , l_3345)) < (*l_2502))) , (*g_757))))) == l_3336) , l_3326), (***g_3022))), (*g_3024))) >= 0xC91255B774174F04LL), (**l_3322))) <= l_3336) , 1L) , (**l_3322))))
                    { /* block id: 1556 */
                        uint8_t l_3348 = 0xD4L;
                        (*g_2014) ^= ((*l_2502) <= ((+(**l_3322)) & ((**l_3038) = l_3348)));
                        (*l_2502) = l_3336;
                        (*g_2014) |= (((*l_2502) |= l_3336) & l_3326);
                        (*l_3322) = &l_3273;
                    }
                    else
                    { /* block id: 1563 */
                        uint16_t *l_3362[7] = {&g_1071[2],&g_1071[2],&g_1071[2],&g_1071[2],&g_1071[2],&g_1071[2],&g_1071[2]};
                        const int32_t l_3366 = 8L;
                        int i;
                        (*g_78) = l_3349[0][0][0];
                        l_3367 ^= ((*g_2014) ^= (g_3350 , ((safe_rshift_func_uint16_t_u_s(((**l_3322) = (((safe_rshift_func_uint16_t_u_s((++(*g_525)), 14)) || 0xE28D38F7L) || ((**l_3322) ^ (safe_sub_func_int8_t_s_s((-10L), l_3359[0]))))), 7)) >= ((safe_add_func_int16_t_s_s(((g_1071[0] &= l_3326) < (safe_add_func_int32_t_s_s((l_3365[0][0] , (g_11 < l_3366)), l_3366))), l_3326)) || 0x0A2FL))));
                    }
                }
                else
                { /* block id: 1571 */
                    (*l_2502) &= ((safe_mul_func_int8_t_s_s(0L, l_3370)) ^ (*g_757));
                    (*l_2502) &= (-1L);
                }
                (**g_3340) = g_3371;
            }
            if ((safe_sub_func_uint32_t_u_u((&g_2128 != (l_3378 = (l_3375[0] = l_3374))), ((safe_div_func_uint64_t_u_u(((safe_sub_func_uint8_t_u_u(((2L | ((void*)0 != (**g_3022))) <= ((*l_2502) , ((safe_div_func_int32_t_s_s(((-9L) || (*l_2502)), ((l_3387[2][5][1] = ((safe_add_func_uint32_t_u_u(((**l_3322) & (*g_1903)), (*g_2014))) , (***g_3022))) || (*g_3024)))) & 6UL))), 0x53L)) <= g_3388), 18446744073709551615UL)) ^ 0x43A3L))))
            { /* block id: 1580 */
                int16_t l_3394[5][4] = {{0xDB69L,(-1L),0xDB69L,0xDB69L},{(-1L),(-1L),0x1D0AL,(-1L)},{(-1L),0xDB69L,0xDB69L,(-1L)},{0xDB69L,(-1L),0xDB69L,0xDB69L},{(-1L),(-1L),0x1D0AL,(-1L)}};
                int32_t l_3417 = 1L;
                int32_t l_3428 = 1L;
                int i, j;
                (*g_2014) = (safe_mul_func_int8_t_s_s((((((((void*)0 != l_3391) & (((safe_mod_func_uint64_t_u_u((((((l_3394[2][3] | (((g_1071[0] ^= (*g_525)) , &g_186) == (void*)0)) | ((safe_add_func_uint16_t_u_u(((((*g_1000) = (safe_rshift_func_int16_t_s_u(((**l_3322) = ((**l_3322) <= ((void*)0 != l_3399[1]))), 10))) , (*g_525)) || (*l_2502)), (***g_3022))) || g_3400)) > g_169.f4) == l_3394[2][3]) == 0x5341C195D03204F0LL), 0xB323E0142BA3E884LL)) || l_3394[3][0]) , (*g_1903))) > 0x1FCDL) || 0xDCL) == (*g_757)) , 0xE5L), 248UL));
                ++l_3401;
                for (l_3273 = 0; (l_3273 >= (-6)); l_3273--)
                { /* block id: 1588 */
                    int64_t l_3415[2][3] = {{(-6L),(-6L),(-6L)},{8L,8L,8L}};
                    int i, j;
                    for (g_223 = 0; (g_223 <= 0); g_223 += 1)
                    { /* block id: 1591 */
                        int64_t *l_3409 = &g_2052[2];
                        int64_t *l_3416[1][2];
                        const uint32_t ***l_3423[9] = {&g_3421,&g_3421,&g_3421,&g_3421,&g_3421,&g_3421,&g_3421,&g_3421,&g_3421};
                        int32_t l_3424 = 4L;
                        uint16_t *l_3425 = &g_1071[2];
                        int i, j;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 2; j++)
                                l_3416[i][j] = &l_3415[0][1];
                        }
                        (*l_3322) = l_3406;
                        l_3428 |= (((**g_999) = (**g_999)) | (((safe_add_func_uint16_t_u_u((((*l_3409) = (*l_2502)) >= ((!(*g_182)) != (g_3426[0][5][0] = ((*l_3425) = (((g_970 == (((4294967292UL > ((**g_756) = (safe_lshift_func_int16_t_s_s(((l_3417 = l_3415[0][2]) || ((((((((l_3420 != ((*l_3204) , (g_3421 = g_3421))) , 252UL) > l_3424) != (**g_756)) , 0x27L) & l_3394[1][3]) && 0UL) | (*g_525))), (*l_3406))))) , &g_1142) != (void*)0)) | 0x1E5DL) >= 0x00L))))), 0L)) , g_3427) , 0x517A80B04B310219LL));
                    }
                }
            }
            else
            { /* block id: 1603 */
                (*g_2014) = ((*g_3422) != 0x4DECCCFEL);
            }
            l_3446 = (((safe_sub_func_uint64_t_u_u((*l_2502), (safe_div_func_uint8_t_u_u(((l_3445 &= (((((++(*l_3434)) && ((((((safe_mul_func_int8_t_s_s((safe_mod_func_uint32_t_u_u((*g_3422), (-1L))), (((((0x4C06L | (((l_3441[5][4][1] = &g_1574) == (void*)0) >= (safe_sub_func_uint16_t_u_u(((*l_3406) < (*g_1000)), ((l_3444 |= (*g_2014)) , (*g_525)))))) || 1UL) ^ 0x7BL) != (**l_3322)) >= (*l_3406)))) < (*g_525)) & (*g_525)) >= (**l_3322)) < 8L) < 0x5664L)) & (*g_1903)) != (**g_999)) , (*l_3406))) <= (**g_3023)), (-6L))))) & 0x585FL) < (*g_2));
        }
        else
        { /* block id: 1611 */
            uint32_t l_3458 = 0x5C338609L;
            int32_t l_3459 = 0L;
            uint64_t *l_3463 = (void*)0;
            uint64_t *l_3464 = &l_3202;
            int32_t l_3468[9] = {0x00011DA1L,0x00011DA1L,0x00011DA1L,0x00011DA1L,0x00011DA1L,0x00011DA1L,0x00011DA1L,0x00011DA1L,0x00011DA1L};
            uint32_t * const *l_3516 = &g_833;
            int16_t l_3593 = 8L;
            int32_t l_3617 = (-5L);
            int32_t l_3644[1][5][7] = {{{0L,0L,0L,0x547A9A62L,0L,(-1L),0x37D950FCL},{0L,0L,(-1L),0L,0x37D950FCL,0L,(-1L)},{7L,7L,0xC4504DCEL,0x547A9A62L,0L,0xBB197659L,7L},{7L,(-1L),0L,0L,(-1L),(-1L),0L},{0L,0x37D950FCL,0L,(-1L),0L,0L,0L}}};
            int32_t l_3646 = 0L;
            int i, j, k;
            if ((safe_mod_func_uint32_t_u_u(((g_3449 , (((*l_3406) | (((**l_3322) , 1L) == (((0x00AE0940B60FC800LL == ((*l_3464) = (safe_sub_func_uint8_t_u_u(((safe_add_func_uint8_t_u_u((safe_sub_func_uint16_t_u_u(((safe_rshift_func_uint16_t_u_s((l_3458 >= (*l_3406)), 14)) <= l_3459), ((+(safe_mod_func_uint8_t_u_u(l_3459, (**l_3322)))) <= 65535UL))), (**l_3322))) == 0x2725L), 0x6EL)))) < l_3458) | (*g_182)))) , 1UL)) | 0xB474E5C8L), (**g_756))))
            { /* block id: 1613 */
                uint16_t l_3465 = 0UL;
                if (l_3465)
                { /* block id: 1614 */
                    l_3468[4] = (safe_sub_func_uint16_t_u_u((&l_3459 == (((void*)0 != &g_1989[1][5][0]) , &l_3212)), (*g_525)));
                }
                else
                { /* block id: 1616 */
                    uint16_t * const l_3471 = &g_3472;
                    uint16_t * const *l_3470 = &l_3471;
                    uint16_t * const **l_3469 = &l_3470;
                    uint16_t **l_3473 = &l_3200;
                    uint16_t ***l_3474 = &l_3473;
                    int32_t l_3478 = (-4L);
                    if ((((*l_3469) = &g_525) == ((*l_3474) = l_3473)))
                    { /* block id: 1619 */
                        return (*g_833);
                    }
                    else
                    { /* block id: 1621 */
                        uint16_t l_3477 = 3UL;
                        (**g_3340) = g_3475;
                        (*l_3406) &= (~((l_3478 ^= l_3477) | 0xA596L));
                        (*l_3322) = (*g_78);
                    }
                    for (l_3478 = 0; (l_3478 >= 19); l_3478++)
                    { /* block id: 1629 */
                        return l_3478;
                    }
                    (*g_78) = &l_3446;
                    for (g_125 = 1; (g_125 >= 41); g_125++)
                    { /* block id: 1635 */
                        int32_t l_3498[3];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_3498[i] = 5L;
                        (*l_3322) = ((safe_div_func_int16_t_s_s((***g_3022), (((**g_999) = (safe_mul_func_int8_t_s_s((((&g_186 == (void*)0) > 0x5B0D41ACL) || ((safe_mul_func_int16_t_s_s((safe_mod_func_uint32_t_u_u((safe_unary_minus_func_int32_t_s((safe_mod_func_uint16_t_u_u(((safe_add_func_uint16_t_u_u(l_3478, (l_3468[5] = ((safe_rshift_func_int8_t_s_u(l_3498[2], ((safe_sub_func_int32_t_s_s(((*g_79) |= (safe_lshift_func_uint8_t_u_u((safe_div_func_uint64_t_u_u(l_3478, (**g_999))), 6))), ((~((safe_mul_func_int8_t_s_s(0x34L, 7UL)) , 0x3B2DD3B2ED240450LL)) || (*g_3422)))) != l_3458))) > g_3508)))) != (**g_756)), (*g_525))))), 0x6E011BA7L)), l_3478)) > l_3458)), (*l_3406)))) || l_3459))) , (*l_3322));
                    }
                }
                for (l_3312.f8 = 9; (l_3312.f8 == 31); l_3312.f8 = safe_add_func_int16_t_s_s(l_3312.f8, 1))
                { /* block id: 1644 */
                    struct S0 l_3515 = {253UL,0xD1L,0x9141597DF0081C0FLL,0xD9092D58L,0x2A6F2CCBL,0x02L,0x4EAA68999A65F0B3LL,0xE9L,0x40L};
                    uint8_t *l_3524 = &g_1503.f0;
                    int32_t l_3525 = 1L;
                    l_2982 &= (safe_rshift_func_int16_t_s_s((((**g_999) ^= (((safe_sub_func_uint64_t_u_u(((l_3515 , (l_3516 != ((l_3525 = ((((((safe_sub_func_int32_t_s_s(((safe_mul_func_int16_t_s_s(l_3515.f3, (g_3521 , ((((*g_1903) >= (safe_mod_func_int16_t_s_s(l_3465, (*g_525)))) , (***g_1142)) , (((*l_3524) = 0xCBL) >= 7UL))))) , (*l_3406)), (*l_3406))) , (*g_757)) | 0xA4EE072FL) ^ 1L) > 0x45F0DB5E641F44EALL) , 0L)) , &g_833))) ^ 0x6F90DCE8L), l_3465)) < 0x6FA7562BL) <= l_3515.f7)) <= 0x4E166653F5BFDBB6LL), (*l_3406)));
                    for (g_360 = 0; (g_360 >= (-26)); --g_360)
                    { /* block id: 1651 */
                        return (*g_833);
                    }
                }
                for (g_1503.f7 = 0; (g_1503.f7 <= 1); g_1503.f7 += 1)
                { /* block id: 1657 */
                    uint64_t l_3528 = 0xCEFDC7F3019AE15ALL;
                    (*g_1246) = (*g_1246);
                    for (l_3444 = 0; (l_3444 <= 1); l_3444 += 1)
                    { /* block id: 1661 */
                        (*g_2014) ^= 0x52C00F0AL;
                        if (l_3528)
                            break;
                    }
                }
            }
            else
            { /* block id: 1666 */
                int16_t *l_3537 = &g_360;
                int16_t **l_3538 = &l_3191[0];
                int32_t l_3539 = 0L;
                int16_t l_3578[3];
                uint16_t l_3580 = 0xDAFCL;
                int32_t l_3589 = (-1L);
                int32_t l_3592 = 0x1C2820EFL;
                int8_t l_3594 = (-1L);
                int32_t l_3596 = (-4L);
                int32_t l_3597[2][10][8] = {{{0x24E6421DL,0xEF205CD1L,0x8976C6ABL,(-1L),0x7F80B1EDL,1L,0xA3F3B6AEL,0L},{(-1L),(-1L),0xC3A4A01DL,0x3BA72799L,0x7F80B1EDL,0x3BA72799L,0xC3A4A01DL,(-1L)},{0x24E6421DL,0L,(-1L),0L,1L,0x3BA72799L,0x24E6421DL,0x4963D565L},{0x7F80B1EDL,(-1L),0x8976C6ABL,0xEF205CD1L,0x24E6421DL,1L,0x24E6421DL,0xEF205CD1L},{(-1L),0xEF205CD1L,(-1L),0x3BA72799L,0xA3F3B6AEL,0L,0xC3A4A01DL,0xEF205CD1L},{0xA3F3B6AEL,0L,0xC3A4A01DL,0xEF205CD1L,1L,0x4963D565L,0xA3F3B6AEL,0x4963D565L},{0xA3F3B6AEL,0L,0x8976C6ABL,0L,0xA3F3B6AEL,1L,0x7F80B1EDL,(-1L)},{(-1L),0L,1L,0x3BA72799L,0x24E6421DL,0x4963D565L,0xC3A4A01DL,0L},{0x7F80B1EDL,0L,1L,(-1L),1L,0L,0x7F80B1EDL,0x4963D565L},{0x24E6421DL,0xEF205CD1L,0x8976C6ABL,(-1L),0x7F80B1EDL,1L,0xA3F3B6AEL,0x3BA72799L}},{{0x38C16A49L,0x4963D565L,0x8976C6ABL,0x8330CF00L,(-1L),0x8330CF00L,0x8976C6ABL,0x4963D565L},{1L,1L,0x38C16A49L,0x3BA72799L,0x5B130844L,0x8330CF00L,1L,0x96BA1E88L},{(-1L),0x4963D565L,0x7F80B1EDL,0L,1L,(-1L),1L,0L},{0x38C16A49L,0L,0x38C16A49L,0x8330CF00L,0xC3A4A01DL,1L,0x8976C6ABL,0L},{0xC3A4A01DL,1L,0x8976C6ABL,0L,0x5B130844L,0x96BA1E88L,0xC3A4A01DL,0x96BA1E88L},{0xC3A4A01DL,0x3BA72799L,0x7F80B1EDL,0x3BA72799L,0xC3A4A01DL,(-1L),(-1L),0x4963D565L},{0x38C16A49L,0x3BA72799L,0x5B130844L,0x8330CF00L,1L,0x96BA1E88L,0x8976C6ABL,0x3BA72799L},{(-1L),1L,0x5B130844L,0x4963D565L,0x5B130844L,1L,(-1L),0x96BA1E88L},{1L,0L,0x7F80B1EDL,0x4963D565L,(-1L),(-1L),0xC3A4A01DL,0x3BA72799L},{0x38C16A49L,0x4963D565L,0x8976C6ABL,0x8330CF00L,(-1L),0x8330CF00L,0x8976C6ABL,0x4963D565L}}};
                int i, j, k;
                for (i = 0; i < 3; i++)
                    l_3578[i] = (-5L);
                (*g_2014) |= ((((*g_1142) != (void*)0) < ((safe_add_func_uint8_t_u_u((safe_rshift_func_int8_t_s_s((*g_1903), (safe_mul_func_int8_t_s_s((((*g_182) > (g_887 = (safe_sub_func_uint64_t_u_u((l_3537 == ((*l_3538) = ((*g_1513) = (*g_1513)))), (l_3539 > (safe_add_func_uint8_t_u_u(6UL, (safe_rshift_func_int8_t_s_u(l_3539, l_3458))))))))) | l_3458), (-1L))))), 0x9FL)) && 0L)) != (*l_3406));
                for (g_169.f0 = 0; (g_169.f0 != 12); ++g_169.f0)
                { /* block id: 1673 */
                    const int32_t *l_3583 = &g_790;
                    const int32_t **l_3586 = &l_3583;
                    int32_t l_3588 = (-5L);
                    int32_t l_3591 = 0x16E8B806L;
                    int32_t l_3595[10][5] = {{0xC9D92BEAL,5L,1L,(-5L),1L},{1L,1L,0x9A05681CL,0x9BF0FF60L,0x79FB1B82L},{1L,0x82C6C2B7L,0x79FB1B82L,(-2L),(-1L)},{0xC9D92BEAL,0L,9L,0xADF521D0L,1L},{0x0220D398L,0x82C6C2B7L,0x82C6C2B7L,0x0220D398L,0x28627A21L},{0x51C27BDAL,1L,0x82C6C2B7L,0x79FB1B82L,(-2L)},{0x79FB1B82L,5L,9L,0xC9D92BEAL,0x82C6C2B7L},{0L,0x51C27BDAL,0x79FB1B82L,0x79FB1B82L,0x51C27BDAL},{(-1L),(-5L),0x9A05681CL,0x0220D398L,0x51C27BDAL},{5L,1L,1L,0xADF521D0L,0x82C6C2B7L}};
                    uint64_t l_3599 = 0UL;
                    int i, j;
                    for (g_12 = 0; (g_12 <= 8); g_12 += 1)
                    { /* block id: 1676 */
                        uint32_t l_3564 = 0xF944F8A4L;
                        int32_t l_3565 = (-2L);
                        uint8_t *l_3573 = &g_169.f7;
                        uint8_t *l_3574 = &g_1503.f0;
                        uint8_t *l_3575 = &g_1503.f7;
                        int i;
                        l_3468[g_12] ^= (((****g_1575) == l_3546) && ((*g_525) = ((*l_3406) > 0UL)));
                        (*l_3406) ^= ((*l_2502) = ((safe_div_func_uint32_t_u_u(((safe_mul_func_int8_t_s_s((safe_sub_func_int16_t_s_s(((!(*g_182)) | (safe_mul_func_uint16_t_u_u(((((*g_1903) || (safe_add_func_int16_t_s_s((((safe_mod_func_uint8_t_u_u(((safe_div_func_uint8_t_u_u(((*l_3575) = (((&g_313[0][1] != (void*)0) == ((safe_mul_func_int16_t_s_s(((l_3565 &= ((*l_3537) = (l_3564 != l_3468[5]))) <= ((safe_div_func_int16_t_s_s(((safe_mul_func_uint16_t_u_u(((safe_mul_func_int8_t_s_s((+((*l_3574) |= ((*l_3573) = (l_3458 < l_3458)))), l_3468[1])) , l_3468[0]), (***g_3022))) != (*g_3024)), (*g_3024))) == l_3468[g_12])), 1UL)) < (*g_757))) & 0x19A1F7DEL)), (**l_3322))) <= (-1L)), 0xA5L)) != l_3459) <= l_3539), (*g_525)))) ^ g_3576) > (-4L)), (**g_3023)))), (-1L))), l_3577[0])) != 4UL), l_3578[2])) , (-9L)));
                        if (l_3579)
                            continue;
                        --l_3580;
                    }
                    (*l_3586) = l_3583;
                    (**g_3340) = g_3587;
                    ++l_3599;
                }
            }
            (**g_3340) = g_3602;
            for (g_169.f3 = 3; (g_169.f3 >= 0); g_169.f3 -= 1)
            { /* block id: 1697 */
                union U3 ****l_3604[5] = {&g_767,&g_767,&g_767,&g_767,&g_767};
                int32_t l_3615 = (-1L);
                int i;
                for (l_3444 = 0; (l_3444 <= 8); l_3444 += 1)
                { /* block id: 1700 */
                    int64_t l_3605 = 0xC3A3DB172EBB3943LL;
                    uint8_t *l_3613 = &g_169.f0;
                    int32_t l_3616 = (-9L);
                    uint64_t l_3628 = 18446744073709551615UL;
                    int i;
                    l_3616 |= ((l_3603 != l_3604[2]) != ((*l_3464) = ((l_3605 | ((l_3605 < ((***g_1142) , (safe_mul_func_uint16_t_u_u((safe_lshift_func_int8_t_s_s(((((l_3610[1][1] <= ((((*l_3613) = (safe_add_func_uint8_t_u_u(l_3605, (0x8FEAL > (-2L))))) <= (*g_2)) & (*g_525))) < 1L) || l_3614[3]) && l_3468[4]), l_3615)), l_3615)))) < (*g_1000))) & (*g_2014))));
                    for (l_3202 = 0; (l_3202 <= 3); l_3202 += 1)
                    { /* block id: 1706 */
                        return l_3617;
                    }
                    (*g_78) = (*l_3322);
                    for (l_3593 = 0; (l_3593 <= 0); l_3593 += 1)
                    { /* block id: 1712 */
                        int32_t l_3623 = 0x7C2990DDL;
                        int64_t *l_3627 = &l_3614[3];
                        int64_t **l_3626 = &l_3627;
                        int i, j, k;
                        (*l_3406) = (((((g_1450[(g_169.f3 + 2)][l_3593][g_169.f3] ^= 7L) < (safe_unary_minus_func_int64_t_s((l_3468[(g_169.f3 + 5)] , (**g_999))))) > 18446744073709551611UL) ^ ((**g_3023) >= ((0x01L <= 0L) && (l_3616 == (safe_div_func_int64_t_s_s(((safe_sub_func_uint16_t_u_u((((*l_3406) <= l_3623) || 0x514345DEA4B9512FLL), l_3624[0])) > l_3458), (*g_182))))))) & (-1L));
                        l_3628 &= ((l_3312 , ((g_3625 , (*g_999)) == ((*l_3626) = (void*)0))) >= (g_2052[l_3593] |= (**g_999)));
                        (*g_78) = &l_3615;
                    }
                }
                l_3468[(g_169.f3 + 1)] = 0x917973B9L;
                l_3468[(g_169.f3 + 1)] = (+((safe_mod_func_int8_t_s_s(((*l_4) &= (-5L)), ((*g_1903) ^= (*l_3406)))) <= (((*g_525)++) && l_3593)));
                (*g_2014) |= ((((safe_rshift_func_uint8_t_u_s(0x84L, ((safe_lshift_func_uint8_t_u_s(((*l_3406) , (0x31B9964136C8A2C6LL == (((*g_525) , ((*l_3464) = (((l_3646 |= ((*g_1247) , (((*l_3406) ^= 0x8D97L) && (l_3459 == ((safe_rshift_func_uint16_t_u_s(((((safe_rshift_func_int16_t_s_u((((safe_mod_func_int16_t_s_s((l_3468[4] |= (**g_3023)), ((l_3644[0][4][1] = 0xCD74L) & (-10L)))) > 8L) && l_3615), l_3459)) == l_3459) , l_3468[(g_169.f3 + 1)]) , (*g_525)), l_3645)) > l_3615))))) >= (*g_757)) && l_3615))) && (*g_1000)))), (*g_1903))) <= l_3615))) != 0x7716L) , (**g_999)) < 7UL);
                for (l_3598 = 1; (l_3598 >= 0); l_3598 -= 1)
                { /* block id: 1734 */
                    if ((*l_3406))
                        break;
                }
            }
        }
    }
    else
    { /* block id: 1739 */
        const struct S1 *l_3663 = (void*)0;
        int32_t l_3669 = 0x68AEBBDBL;
        int32_t l_3677 = 0xF5D941D3L;
        int32_t l_3703 = 0x3DD2F92CL;
        uint64_t l_3706 = 0xA4BD229C2FCFA2FCLL;
        struct S0 *l_3732 = &g_1017[0];
        int32_t *l_3767 = &l_3677;
        uint32_t l_3824 = 0x08D3654AL;
        uint32_t l_3827 = 0x79515105L;
        uint32_t *l_3847 = &l_3624[0];
        uint32_t **l_3869 = &g_833;
        uint8_t l_3923 = 0x16L;
        int32_t l_3933 = 0L;
        int32_t l_3937 = 0xFA0B5BCDL;
        uint32_t l_3938 = 1UL;
        union U3 ***l_3950 = &g_672;
        int16_t l_4141 = 0x9C63L;
        const int16_t ****l_4156 = &g_3022;
        if (((*g_3232) , (-7L)))
        { /* block id: 1740 */
            int64_t l_3656 = (-7L);
            struct S0 ****l_3657 = &g_3034;
            int32_t l_3668 = 1L;
            int32_t l_3673 = (-6L);
            int32_t l_3674[1][2][5] = {{{0x37238140L,(-9L),0x37238140L,0x37238140L,(-9L)},{(-9L),0x37238140L,0x37238140L,(-9L),0x37238140L}}};
            uint32_t l_3683 = 0x5111D347L;
            uint8_t l_3733 = 0x5AL;
            union U3 l_3736[7][4][7] = {{{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}}}};
            int8_t l_3821 = 1L;
            uint64_t l_3822 = 0UL;
            int32_t l_3825 = 0L;
            int64_t **l_3844 = &g_1000;
            uint32_t l_3855 = 8UL;
            int i, j, k;
        }
        else
        { /* block id: 1852 */
            int8_t l_3930 = 1L;
            int32_t l_3931 = 1L;
            int32_t l_3932 = 0xBD5A26F0L;
            int32_t l_3934 = (-7L);
            int32_t l_3935 = (-1L);
            int64_t l_3936[4][9][7] = {{{0x218AD385E3970C0FLL,0L,0x4515FDC8DFBA22E9LL,0xC2C76B7F5B23E5F1LL,0L,0L,0xC2C76B7F5B23E5F1LL},{0x2BB708A848A5DA75LL,(-1L),0x2BB708A848A5DA75LL,0x886A6C65B0B56CEFLL,0x2AC6080ED38A19CCLL,1L,9L},{0L,0x2AC6080ED38A19CCLL,(-1L),0xC6DCFF2FD6B22149LL,(-2L),1L,0x550E6C80B80320BBLL},{(-1L),0xD3F04E266BC59458LL,0x93131EC8E12B6A36LL,0x6D9DE360ABED9978LL,(-3L),1L,(-2L)},{1L,0xBF9F36173948B081LL,3L,0x76660B25631CD1ACLL,(-1L),0L,(-1L)},{1L,0x76E8D2CA8E1F9167LL,1L,1L,0x76660B25631CD1ACLL,0x2AC6080ED38A19CCLL,0x844FC37F20BAB1F3LL},{1L,0x530487D462B8F62ALL,1L,1L,0x271813820F530378LL,0x8E469AD59E57AD95LL,0L},{1L,(-4L),0x4FA755584E2BBA6DLL,0xE731E7BF5CBF7935LL,0x6E3E45BBBDEBF889LL,6L,0x42741B15E4FEF359LL},{0x4FB8A6A6F1393922LL,0L,6L,0x90DB5011F890BD10LL,0L,0x185817E5575206AELL,1L}},{{1L,0x3574605E03996F72LL,1L,0x886A6C65B0B56CEFLL,1L,1L,0x88753E1E01B17D72LL},{0x898F01BA028EA388LL,0x0BB5C10304280B6CLL,0xF0E7DD06BC13B37ELL,0x51A78B4D53833360LL,(-3L),1L,0x4FA755584E2BBA6DLL},{0xC5764361A6B719D8LL,0x2BB708A848A5DA75LL,1L,0xCEB8E1E51C4EF52CLL,0x76660B25631CD1ACLL,0xBF9F36173948B081LL,0x90DB5011F890BD10LL},{0xC5764361A6B719D8LL,0L,0x530487D462B8F62ALL,0x0BB5C10304280B6CLL,(-6L),0x530487D462B8F62ALL,9L},{0x898F01BA028EA388LL,0L,0x13CC201FDB43A612LL,1L,1L,0x2DA1571EB6552587LL,(-1L)},{1L,0x844FC37F20BAB1F3LL,0x576C3A0B8EE41B66LL,0x885020AECD6F0A64LL,0x93131EC8E12B6A36LL,1L,0x4515FDC8DFBA22E9LL},{0x4FB8A6A6F1393922LL,0x271813820F530378LL,1L,1L,0x3574605E03996F72LL,0L,0x9515897C50DF6057LL},{1L,0x4515FDC8DFBA22E9LL,(-1L),(-6L),0xB5A26CDEE94CCB09LL,(-9L),9L},{1L,0L,0xC2C76B7F5B23E5F1LL,0xCEB8E1E51C4EF52CLL,1L,0x42C8CDAB0B826FBCLL,(-5L)}},{{0x9515897C50DF6057LL,2L,9L,0x1B0CADFB1AF9D66DLL,9L,2L,0x9515897C50DF6057LL},{(-1L),0x0ADC1094D0E834ABLL,0xFB389FA18394D257LL,0x530487D462B8F62ALL,(-4L),0x898F01BA028EA388LL,0L},{0x76660B25631CD1ACLL,0x6E3E45BBBDEBF889LL,0x185817E5575206AELL,0x90DB5011F890BD10LL,0xCEB8E1E51C4EF52CLL,(-2L),(-1L)},{0x844FC37F20BAB1F3LL,5L,0xFB389FA18394D257LL,0x9515897C50DF6057LL,1L,0x559653E3F36A5B5CLL,9L},{1L,0xD3F04E266BC59458LL,9L,0x8E469AD59E57AD95LL,9L,0x3B31AD5CE0AB62B8LL,0L},{0x1B0CADFB1AF9D66DLL,0xB143E95AAD8530DELL,0xC2C76B7F5B23E5F1LL,0L,0x9515897C50DF6057LL,0x576C3A0B8EE41B66LL,0xC5764361A6B719D8LL},{0L,(-9L),(-1L),(-1L),(-9L),0x559653E3F36A5B5CLL,0x88753E1E01B17D72LL},{0x530487D462B8F62ALL,0x90DB5011F890BD10LL,1L,(-9L),0L,0xFB389FA18394D257LL,0x3574605E03996F72LL},{0x4515FDC8DFBA22E9LL,0xE4438BEA1220985ALL,0x576C3A0B8EE41B66LL,0x88753E1E01B17D72LL,0x886A6C65B0B56CEFLL,0x802932384B6D700DLL,0x2BB708A848A5DA75LL}},{{1L,0L,0x13CC201FDB43A612LL,0x175FFFB68946F144LL,0x17D239F94AD8A0F8LL,2L,0L},{0x271813820F530378LL,1L,0x530487D462B8F62ALL,6L,0x4FB8A6A6F1393922LL,1L,1L},{9L,0xB143E95AAD8530DELL,1L,9L,0x4FB8A6A6F1393922LL,0xCC894C074D452C16LL,1L},{0x88753E1E01B17D72LL,0x13CC201FDB43A612LL,0xF0E7DD06BC13B37ELL,0xD3F04E266BC59458LL,0x17D239F94AD8A0F8LL,0L,0x93131EC8E12B6A36LL},{(-1L),0x4FB8A6A6F1393922LL,1L,0x6AC1196EEC540F9FLL,0x886A6C65B0B56CEFLL,0x379C6289F9CB5C29LL,0x523F792262FF7FF2LL},{0xCDD1774790AC204ELL,0x6E3E45BBBDEBF889LL,6L,1L,0L,0x62A77B69C93E3288LL,0x17D239F94AD8A0F8LL},{(-9L),6L,1L,0xB0A6D0811FC80AE7LL,1L,0x62A77B69C93E3288LL,0L},{1L,0x3B31AD5CE0AB62B8LL,0xAEC51AC06E3268DDLL,0xC2C76B7F5B23E5F1LL,0xC76CCD93607B196CLL,0x42C8CDAB0B826FBCLL,0x62A77B69C93E3288LL},{9L,0x42741B15E4FEF359LL,0x0ADC1094D0E834ABLL,0x523F792262FF7FF2LL,1L,0xD3F04E266BC59458LL,1L}}};
            uint32_t l_4003[10][10] = {{4294967288UL,0xF7F12930L,0xF7F12930L,4294967288UL,4294967288UL,0UL,1UL,0UL,0xCE1FE004L,0xAC67D125L},{1UL,0xC23372F7L,0xCE1FE004L,1UL,0xF7F12930L,0UL,0xF7F12930L,1UL,0xCE1FE004L,0xC23372F7L},{4294967295UL,9UL,0x0B985C47L,4294967288UL,0x8E90F11BL,0xCBFAB05AL,0UL,0xCE1FE004L,4294967288UL,4294967288UL},{9UL,0xAC67D125L,0xCBFAB05AL,0UL,0UL,0xCBFAB05AL,0xAC67D125L,9UL,4294967288UL,0UL},{4294967295UL,0x0B985C47L,1UL,9UL,0x72065D45L,0UL,0UL,0UL,0UL,0UL},{1UL,0x72065D45L,1UL,0x72065D45L,1UL,0UL,4294967288UL,9UL,0xAC67D125L,0xCBFAB05AL},{4294967288UL,0x8E90F11BL,0xCBFAB05AL,0UL,0xCE1FE004L,4294967288UL,4294967288UL,0xCE1FE004L,0UL,0xCBFAB05AL},{0UL,0UL,0x0B985C47L,0xCBFAB05AL,1UL,0xC23372F7L,0xCE1FE004L,1UL,0xF7F12930L,0UL},{1UL,0UL,0xCE1FE004L,0xAC67D125L,0x72065D45L,0xAC67D125L,0xCE1FE004L,0UL,1UL,0UL},{0x8E90F11BL,0UL,0xF7F12930L,1UL,0UL,4294967295UL,4294967288UL,0x72065D45L,0x72065D45L,4294967288UL}};
            uint32_t l_4015[8][1] = {{4294967291UL},{4294967288UL},{4294967288UL},{4294967291UL},{4294967288UL},{4294967288UL},{4294967291UL},{4294967288UL}};
            const uint64_t l_4024 = 18446744073709551614UL;
            int16_t ***l_4094 = &g_1513;
            uint32_t l_4110[3][8] = {{0x59AF7FB3L,5UL,4294967294UL,5UL,0x59AF7FB3L,0x59AF7FB3L,5UL,4294967294UL},{0x59AF7FB3L,0x59AF7FB3L,5UL,4294967294UL,5UL,0x59AF7FB3L,0x59AF7FB3L,5UL},{0UL,5UL,5UL,0UL,1UL,0UL,5UL,5UL}};
            struct S0 *l_4119[6][4] = {{&g_1017[0],&g_169,&g_1503,&g_1503},{&g_169,&g_169,&g_1017[0],&g_1503},{(void*)0,&g_169,(void*)0,&g_1017[0]},{(void*)0,&g_1017[0],&g_1017[0],(void*)0},{&g_169,&g_1017[0],&g_1503,&g_1017[0]},{&g_1017[0],&g_169,&g_1503,&g_1503}};
            int64_t ***l_4147[2][2] = {{&g_999,&g_999},{&g_999,&g_999}};
            int32_t l_4152 = 0x2B4EBB3CL;
            int i, j, k;
            for (g_123 = 0; (g_123 <= 0); g_123 += 1)
            { /* block id: 1855 */
                int32_t *l_3926 = &l_3669;
                (*g_78) = &l_3273;
                for (l_3703 = 0; (l_3703 >= 0); l_3703 -= 1)
                { /* block id: 1859 */
                    uint32_t l_3927 = 0xD01AF110L;
                    --l_3923;
                    for (g_45 = 0; (g_45 >= 0); g_45 -= 1)
                    { /* block id: 1863 */
                        int i, j, k;
                        g_2974[g_45][(g_123 + 3)][g_45] = l_3926;
                        ++l_3927;
                    }
                }
            }
            l_3938++;
            if (((***g_3022) | (((*g_1903) || (*g_1903)) ^ l_3931)))
            { /* block id: 1870 */
                int32_t l_3944 = 6L;
                union U3 ***l_3946[8] = {&g_672,&g_672,&g_672,&g_672,&g_672,&g_672,&g_672,&g_672};
                int32_t l_3954 = (-5L);
                int32_t l_3957 = 0L;
                int32_t l_3958[10] = {0xB3BAA24DL,0L,0L,0xEE8C007EL,0L,0L,0xEE8C007EL,0L,0L,0xEE8C007EL};
                uint32_t l_3959 = 0x32BF5C28L;
                uint32_t l_4016[2][4][7] = {{{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{18446744073709551615UL,1UL,18446744073709551615UL,1UL,18446744073709551615UL,1UL,18446744073709551615UL},{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{18446744073709551615UL,1UL,18446744073709551615UL,1UL,18446744073709551615UL,1UL,18446744073709551615UL}},{{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{18446744073709551615UL,1UL,18446744073709551615UL,1UL,18446744073709551615UL,1UL,18446744073709551615UL},{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{18446744073709551615UL,1UL,18446744073709551615UL,1UL,18446744073709551615UL,1UL,18446744073709551615UL}}};
                uint64_t *l_4065 = &g_4008;
                uint64_t *l_4066 = &g_1017[0].f6;
                int i, j, k;
lbl_4092:
                if ((*g_2014))
                { /* block id: 1871 */
                    uint32_t *** const l_3942 = &g_756;
                    uint32_t *** const *l_3941[2][6][8] = {{{&l_3942,(void*)0,(void*)0,&l_3942,(void*)0,(void*)0,&l_3942,(void*)0},{&l_3942,&l_3942,&l_3942,&l_3942,&l_3942,&l_3942,&l_3942,&l_3942},{(void*)0,&l_3942,(void*)0,(void*)0,&l_3942,(void*)0,(void*)0,&l_3942},{&l_3942,(void*)0,(void*)0,&l_3942,(void*)0,(void*)0,&l_3942,(void*)0},{&l_3942,&l_3942,&l_3942,&l_3942,&l_3942,&l_3942,&l_3942,&l_3942},{(void*)0,&l_3942,(void*)0,(void*)0,&l_3942,(void*)0,(void*)0,&l_3942}},{{&l_3942,(void*)0,(void*)0,&l_3942,(void*)0,(void*)0,&l_3942,(void*)0},{&l_3942,&l_3942,&l_3942,&l_3942,&l_3942,&l_3942,&l_3942,&l_3942},{(void*)0,&l_3942,(void*)0,(void*)0,&l_3942,(void*)0,(void*)0,&l_3942},{&l_3942,(void*)0,(void*)0,&l_3942,(void*)0,(void*)0,&l_3942,(void*)0},{&l_3942,&l_3942,&l_3942,&l_3942,&l_3942,&l_3942,&l_3942,&l_3942},{(void*)0,&l_3942,(void*)0,(void*)0,&l_3942,(void*)0,(void*)0,&l_3942}}};
                    uint16_t *l_3949 = &l_3702;
                    int32_t l_3951 = 0x2D48012CL;
                    int32_t l_3952 = 4L;
                    int32_t l_3953 = 0x4F9D4896L;
                    int32_t l_3955 = 0xA778B6DBL;
                    int32_t l_3956 = 0x4891BC53L;
                    int i, j, k;
                    g_3943 = l_3941[0][0][7];
                    l_3944 &= ((*l_3767) ^= l_3930);
                    if ((g_3945 , (l_3946[7] == (((*l_3949) = ((*g_525)++)) , l_3950))))
                    { /* block id: 1877 */
                        l_3959++;
                        (*g_2014) |= ((*l_2502) = (safe_mul_func_int8_t_s_s(2L, l_3956)));
                    }
                    else
                    { /* block id: 1881 */
                        (**g_3340) = g_3964;
                    }
                }
                else
                { /* block id: 1884 */
                    const uint32_t l_3986[10] = {0x3ACB904FL,18446744073709551607UL,18446744073709551607UL,0x3ACB904FL,18446744073709551607UL,18446744073709551607UL,0x3ACB904FL,18446744073709551607UL,18446744073709551607UL,0x3ACB904FL};
                    int16_t *l_3992 = &g_970;
                    const int32_t l_3993 = 0xAC83E95EL;
                    int16_t *l_3994 = &g_360;
                    int32_t l_3995 = 0x49EAACEAL;
                    int32_t l_3999 = 5L;
                    const uint32_t ***l_4013 = &g_3421;
                    int i;
                    if ((((~((*l_3847) = (safe_mul_func_uint8_t_u_u((*l_2502), (safe_sub_func_int32_t_s_s((safe_sub_func_uint16_t_u_u((((*g_182) == (safe_rshift_func_int16_t_s_s(((safe_mod_func_int16_t_s_s((l_3995 = (((*l_3994) = ((safe_add_func_int64_t_s_s((safe_unary_minus_func_int32_t_s(((safe_add_func_int64_t_s_s((+((*l_3767) = ((safe_lshift_func_int8_t_s_u(0xE1L, 0)) | (safe_mul_func_int8_t_s_s(((l_3959 >= 0x0892DF0D848C122CLL) && l_3986[8]), (((*g_2014) ^= (((((safe_sub_func_uint8_t_u_u(((((*g_525) = ((***g_3022) >= ((l_3944 , (((((!(((((((safe_sub_func_int8_t_s_s((((((*l_3992) &= (*g_3024)) & 65535UL) > l_3993) || (*l_3767)), l_3957)) , (*l_3767)) >= l_3993) || (*l_3767)) , &l_3312) != (void*)0) > (*l_3767))) <= (-7L)) && l_3930) == (**g_999)) | (-4L))) <= 0x1353FB5FL))) | g_1270.f2) & 4UL), l_3935)) & (*l_3767)) == (**g_3421)) <= (*g_3422)) & (*l_3767))) | 5UL)))))), 0L)) <= 0xF95BL))), 0x7192FD70E6FC0668LL)) , (*g_3024))) < l_3958[5])), l_3986[8])) >= l_3986[8]), 11))) < 0x1956CB91L), l_3959)), (**g_3421))))))) ^ g_1148) , l_3935))
                    { /* block id: 1892 */
                        l_3996--;
                        (*l_3767) ^= ((*g_2014) = l_3935);
                        (*g_78) = (*g_78);
                    }
                    else
                    { /* block id: 1897 */
                        int8_t l_4000 = 1L;
                        int32_t l_4001 = 0x184A610AL;
                        int32_t l_4002[9] = {0x6CE155F7L,(-7L),0x6CE155F7L,0x6CE155F7L,(-7L),0x6CE155F7L,0x6CE155F7L,(-7L),0x6CE155F7L};
                        uint8_t *l_4014[6] = {&g_1503.f0,&g_1503.f0,&g_1503.f0,&g_1503.f0,&g_1503.f0,&g_1503.f0};
                        uint8_t l_4017[1][4][7] = {{{252UL,0x30L,252UL,0x30L,252UL,0x30L,252UL},{0xDBL,3UL,3UL,0xDBL,0xDBL,3UL,3UL},{246UL,0x30L,246UL,0x30L,246UL,0x30L,246UL},{0xDBL,0xDBL,3UL,3UL,0xDBL,0xDBL,3UL}}};
                        int i, j, k;
                        --l_4003[4][0];
                        (*g_78) = &l_3958[3];
                        l_4017[0][0][2]++;
                        return l_4016[1][1][2];
                    }
                    if (l_3579)
                        goto lbl_4046;
lbl_4046:
                    for (g_185 = 0; (g_185 >= (-24)); g_185 = safe_sub_func_int16_t_s_s(g_185, 8))
                    { /* block id: 1910 */
                        struct S1 *****l_4032 = &l_4031;
                        int32_t l_4045 = 9L;
                        (*g_78) = &l_3934;
                        (*l_2502) |= (safe_div_func_uint16_t_u_u(l_4024, (safe_mul_func_int8_t_s_s(((safe_lshift_func_uint8_t_u_u((l_3958[4] ^= 0x7DL), 5)) != ((safe_sub_func_uint8_t_u_u((((((*l_4032) = l_4031) == &g_1142) <= 0x3510L) <= (safe_sub_func_uint8_t_u_u((safe_mod_func_uint32_t_u_u(l_4016[1][0][0], (safe_mul_func_int8_t_s_s(((safe_lshift_func_uint16_t_u_u((safe_mod_func_uint32_t_u_u((*g_3422), l_4016[0][2][5])), 14)) && (safe_sub_func_uint32_t_u_u(l_4045, 0x82E7F024L))), (*l_3767))))), 8UL))), 1L)) == (**g_3421))), 247UL))));
                    }
                    l_3958[3] &= 0L;
                }
                (*g_2014) = 0x99A05796L;
                if (((safe_sub_func_int32_t_s_s(((*l_3767) ^= l_3931), ((safe_rshift_func_int16_t_s_u(((safe_mod_func_int64_t_s_s((safe_rshift_func_uint8_t_u_u((*l_2502), ((safe_sub_func_int8_t_s_s(((safe_rshift_func_uint8_t_u_u((safe_add_func_uint32_t_u_u((*g_757), ((safe_rshift_func_int16_t_s_u((safe_sub_func_int64_t_s_s((0x8FA4D6DC9EE6F4B5LL != ((*l_4065) ^= (*g_182))), ((*l_4066) = (0xE769F5B5L & l_3930)))), 11)) <= (safe_add_func_uint16_t_u_u(((((safe_unary_minus_func_int16_t_s((safe_rshift_func_uint16_t_u_u(65530UL, 4)))) , (safe_div_func_int32_t_s_s(((safe_sub_func_uint64_t_u_u(((*g_1903) >= l_3932), l_4003[4][0])) && l_3930), l_3827))) & (*g_2014)) , 0xA008L), (*g_525)))))), 7)) >= 0UL), 0xE0L)) ^ (*g_3422)))), g_12)) >= 0x74L), l_3932)) > 0UL))) , 1L))
                { /* block id: 1923 */
                    int32_t l_4086 = 0x3832A488L;
                    uint8_t *l_4087 = &g_2418[0][3];
                    uint16_t *l_4088 = &l_3996;
                    (*l_3767) = (l_3931 = ((((l_4089[1][1] = &l_3203) == (void*)0) , 0x85E6L) ^ l_4090));
                }
                else
                { /* block id: 1931 */
                    (**l_3862) = g_4091[0];
                    l_3349[0][0][0] = ((*g_78) = &l_3934);
                    if (l_3935)
                        goto lbl_4092;
                }
            }
            else
            { /* block id: 1937 */
                uint8_t *l_4093 = &g_169.f0;
                int16_t ****l_4095[8][1] = {{&g_3006},{&g_3006},{&g_3006},{&g_3006},{&g_3006},{&g_3006},{&g_3006},{&g_3006}};
                int32_t l_4100 = 0L;
                int32_t l_4101[2][6][9] = {{{0x679ECC25L,0L,0x677FBA8FL,1L,0L,1L,8L,7L,1L},{0x679ECC25L,0x946EF15EL,0xB1F45C51L,1L,0x946EF15EL,1L,8L,0L,8L},{0x679ECC25L,7L,1L,1L,7L,0x679ECC25L,8L,0x946EF15EL,0x55BCBC91L},{0x679ECC25L,0L,0x677FBA8FL,1L,0L,1L,8L,7L,1L},{0x679ECC25L,0x946EF15EL,0xB1F45C51L,1L,0x946EF15EL,1L,8L,0L,8L},{0x679ECC25L,7L,1L,1L,7L,0x679ECC25L,8L,0x946EF15EL,0x55BCBC91L}},{{0x679ECC25L,0L,0x677FBA8FL,1L,0L,1L,8L,7L,1L},{0x679ECC25L,0x946EF15EL,0xB1F45C51L,1L,0x946EF15EL,1L,8L,0L,8L},{0x679ECC25L,7L,1L,1L,7L,0x679ECC25L,8L,0x946EF15EL,0x55BCBC91L},{0x679ECC25L,0L,0x677FBA8FL,1L,0L,1L,8L,7L,1L},{0x679ECC25L,0x946EF15EL,0xB1F45C51L,1L,0x946EF15EL,1L,8L,0L,8L},{0x679ECC25L,7L,1L,1L,7L,0x679ECC25L,8L,0x946EF15EL,0x55BCBC91L}}};
                int16_t l_4140 = 0xCD7EL;
                int32_t l_4153 = 1L;
                int i, j, k;
                if ((((*l_4093) ^= (((*g_756) == (void*)0) <= (-1L))) ^ ((l_4096 = l_4094) == &g_3023)))
                { /* block id: 1940 */
                    uint16_t l_4104[2];
                    int32_t l_4107 = 0x0A9D3A49L;
                    int32_t l_4108 = 0x75DF0EC7L;
                    int32_t l_4109[6] = {5L,0xC8DE36F8L,5L,5L,0xC8DE36F8L,5L};
                    int i;
                    for (i = 0; i < 2; i++)
                        l_4104[i] = 0x1CDFL;
                    for (g_223 = (-15); (g_223 < 22); g_223++)
                    { /* block id: 1943 */
                        int32_t l_4099[2];
                        int32_t l_4102 = 6L;
                        int32_t l_4103 = 0xEE2E7E91L;
                        int i;
                        for (i = 0; i < 2; i++)
                            l_4099[i] = (-1L);
                        --l_4104[0];
                        --l_4110[1][2];
                        (**l_3862) = ((*g_1247) , (l_4102 , g_4113[1][0][0]));
                        (**l_3862) = g_4114[1][3][2];
                    }
                }
                else
                { /* block id: 1949 */
                    uint64_t l_4115 = 3UL;
                    l_4115--;
                }
                (*l_3767) |= g_4118;
                (*g_1246) = l_4119[3][3];
                if ((safe_mod_func_int32_t_s_s((((0UL && (*g_1903)) ^ (l_4095[4][0] == ((*l_3732) , (((*l_3767) = (safe_sub_func_uint16_t_u_u(((safe_mod_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u((safe_mul_func_int8_t_s_s(l_4101[1][2][6], (safe_unary_minus_func_uint32_t_u(l_4101[0][1][4])))), (safe_div_func_int8_t_s_s((251UL < (safe_mul_func_uint16_t_u_u(((((l_4135 != (((*g_525) &= (((safe_mod_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u((*l_3767), l_4140)), l_4101[1][1][7])) && 0UL) > 1L)) , (*g_525))) < (*l_3767)) ^ (*l_3767)) || (*g_1000)), 8L))), (*l_3767))))), 0xC1L)) , 0UL), l_3932))) , (void*)0)))) | (***g_3022)), (**g_3421))))
                { /* block id: 1956 */
                    uint64_t l_4142[10] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
                    int i;
                    ++l_4142[2];
                    (*g_2014) |= 1L;
                    return l_4101[1][0][0];
                }
                else
                { /* block id: 1960 */
                    int64_t ***l_4146[3];
                    int64_t ****l_4145[10][7] = {{&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2]},{&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0]},{&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2]},{&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0]},{&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2]},{&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0]},{&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2]},{&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0]},{&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2],&l_4146[2]},{&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0],&l_4146[0]}};
                    int32_t l_4154[7][3] = {{0L,(-6L),(-4L)},{(-1L),(-6L),0L},{0xD99BEB74L,(-6L),(-6L)},{0L,(-6L),(-4L)},{(-1L),(-6L),0L},{0xD99BEB74L,(-6L),(-6L)},{0L,(-6L),(-4L)}};
                    int i, j;
                    for (i = 0; i < 3; i++)
                        l_4146[i] = (void*)0;
                    l_3767 = &l_3273;
                    l_4154[6][1] = ((l_4024 , (*l_3732)) , (((l_4100 && (((**g_999) = ((l_4147[1][1] = &g_999) == &g_999)) | (safe_add_func_int32_t_s_s(((*l_2502) = ((*g_2014) = ((safe_add_func_int8_t_s_s(((*g_1903) ^= l_3935), 0x78L)) < (((*l_3767) = l_4152) , (1UL && (*g_525)))))), l_4153)))) <= l_4100) && (*g_182)));
                    for (l_3212 = 2; (l_3212 <= 9); l_3212 += 1)
                    { /* block id: 1971 */
                        (**g_3340) = g_4155;
                        (*l_2502) = ((*g_525) , (*l_3767));
                    }
                    l_4156 = l_4156;
                }
            }
        }
        (**g_1142) = (**g_1142);
    }
    return l_4158[5][5][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_1143 g_1144 g_1145 g_1503.f6 g_1000 g_188 g_78 g_79 g_2673 g_756 g_757 g_123 g_136 g_525 g_182 g_183 g_2691 g_45 g_999 g_1903 g_169.f7 g_1142 g_832 g_833 g_935 g_2759 g_2761 g_1503.f5 g_360 g_2773 g_223 g_125 g_1071 g_1450 g_2812 g_2692 g_2693 g_2262 g_1831 g_313 g_315 g_69 g_94 g_8 g_5 g_12 g_169 g_186 g_185 g_294 g_310 g_1226 g_1148 g_670 g_1503.f0 g_2927 g_835 g_1487 g_1488 g_1489 g_1490 g_767 g_672 g_673 g_2974 g_1009
 * writes: g_1503.f6 g_79 g_188 g_223 g_45 g_935 g_169.f7 g_2660 g_1144 g_1503.f5 g_360 g_125 g_1903 g_123 g_1450 g_2812 g_69 g_94 g_185 g_169.f3 g_193 g_136 g_186 g_169.f0 g_169.f8 g_169.f6 g_1017.f5 g_169.f5 g_1226 g_1148 g_670 g_315 g_1503.f0 g_1813 g_835
 */
static int32_t * func_15(int64_t  p_16, uint32_t  p_17, const int8_t * p_18)
{ /* block id: 1217 */
    uint32_t ***l_2507 = &g_832[6][1][0];
    uint32_t ****l_2506 = &l_2507;
    uint32_t *****l_2508 = &l_2506;
    const union U3 l_2515 = {0};
    int32_t l_2518 = 1L;
    int32_t l_2519 = 0x8B083D4EL;
    uint32_t ****l_2520 = &l_2507;
    int32_t l_2557 = 0xA4AB54D5L;
    int32_t l_2577 = 6L;
    uint64_t l_2578 = 9UL;
    uint32_t l_2606 = 0xEFC4FF85L;
    int32_t *l_2610 = &g_45;
    union U3 **l_2662[10][9] = {{&g_673,&g_673,&g_673,&g_673,&g_673,&g_673,&g_673,&g_673,&g_673},{&g_673,&g_673,&g_673,&g_673,&g_673,(void*)0,&g_673,&g_673,&g_673},{&g_673,(void*)0,&g_673,&g_673,&g_673,&g_673,&g_673,(void*)0,&g_673},{(void*)0,&g_673,&g_673,(void*)0,(void*)0,(void*)0,&g_673,(void*)0,&g_673},{&g_673,&g_673,&g_673,(void*)0,(void*)0,(void*)0,&g_673,&g_673,(void*)0},{(void*)0,(void*)0,&g_673,(void*)0,(void*)0,&g_673,(void*)0,&g_673,&g_673},{&g_673,&g_673,&g_673,&g_673,&g_673,&g_673,&g_673,(void*)0,(void*)0},{&g_673,&g_673,(void*)0,(void*)0,&g_673,&g_673,(void*)0,(void*)0,&g_673},{&g_673,&g_673,&g_673,(void*)0,&g_673,(void*)0,(void*)0,&g_673,&g_673},{&g_673,&g_673,&g_673,&g_673,(void*)0,(void*)0,(void*)0,&g_673,(void*)0}};
    int16_t *l_2686 = &g_360;
    int16_t *l_2687 = &g_360;
    uint32_t l_2719 = 0xF58E02B5L;
    struct S2 **l_2768 = (void*)0;
    uint8_t l_2803 = 0x44L;
    int32_t l_2860 = 1L;
    int32_t l_2861 = 0xC776B6A5L;
    int32_t l_2862 = 1L;
    int32_t l_2863 = 0xC0E1EC32L;
    struct S0 *l_2870[5] = {&g_1017[0],&g_1017[0],&g_1017[0],&g_1017[0],&g_1017[0]};
    struct S0 **l_2869 = &l_2870[2];
    int32_t ** const ** const *l_2897 = &g_668;
    uint32_t l_2922 = 0UL;
    int32_t *l_2949 = &g_315[0];
    int32_t l_2959[4][4][1] = {{{0xB7BCF229L},{0x873FE45BL},{1L},{0x873FE45BL}},{{0xB7BCF229L},{0xD01BE5D0L},{0xB7BCF229L},{0x873FE45BL}},{{1L},{0x873FE45BL},{0xB7BCF229L},{0xD01BE5D0L}},{{0xB7BCF229L},{0x873FE45BL},{1L},{0x873FE45BL}}};
    uint16_t **l_2964[7][7][5] = {{{&g_525,&g_525,&g_525,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525},{(void*)0,&g_525,&g_525,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,(void*)0},{&g_525,&g_525,&g_525,(void*)0,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525}},{{&g_525,&g_525,(void*)0,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525},{&g_525,(void*)0,&g_525,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525},{&g_525,&g_525,(void*)0,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525}},{{&g_525,&g_525,(void*)0,&g_525,&g_525},{&g_525,(void*)0,&g_525,&g_525,&g_525},{&g_525,&g_525,(void*)0,&g_525,&g_525},{&g_525,&g_525,(void*)0,(void*)0,&g_525},{&g_525,&g_525,(void*)0,&g_525,&g_525},{&g_525,&g_525,(void*)0,(void*)0,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525}},{{&g_525,&g_525,(void*)0,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525},{&g_525,&g_525,(void*)0,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525},{&g_525,&g_525,&g_525,(void*)0,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525}},{{(void*)0,&g_525,(void*)0,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525},{&g_525,&g_525,(void*)0,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525}},{{(void*)0,&g_525,(void*)0,&g_525,&g_525},{(void*)0,&g_525,&g_525,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525},{&g_525,&g_525,&g_525,(void*)0,&g_525},{(void*)0,&g_525,&g_525,&g_525,&g_525},{(void*)0,(void*)0,(void*)0,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525}},{{&g_525,&g_525,(void*)0,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,(void*)0},{&g_525,(void*)0,&g_525,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525},{&g_525,&g_525,&g_525,&g_525,&g_525},{(void*)0,(void*)0,&g_525,&g_525,&g_525}}};
    int16_t l_2965 = 0xBB89L;
    int32_t l_2973 = 1L;
    int i, j, k;
    if ((((safe_sub_func_uint16_t_u_u(((((((**g_1143) , ((*l_2508) = l_2506)) != (((p_16 <= ((safe_rshift_func_int8_t_s_s((-2L), (((!p_16) , (((safe_unary_minus_func_uint16_t_u((l_2515 , p_17))) & 0xEDL) | (((safe_add_func_uint8_t_u_u(((l_2518 > 0x50L) >= p_17), 0x22L)) || p_16) <= 0xE4B5A4EA86071C77LL))) >= l_2519))) | p_16)) < l_2519) , l_2520)) >= 0x02F03F24L) & p_17) <= p_17), l_2519)) >= 0x6989037601E5E118LL) | l_2519))
    { /* block id: 1219 */
        l_2518 = 0L;
    }
    else
    { /* block id: 1221 */
        uint32_t l_2525[4] = {0UL,0UL,0UL,0UL};
        int32_t l_2551[9][9][3] = {{{0x8B0DD09BL,1L,0x78DEFD6FL},{0x94F29EF3L,0x9A721EA3L,(-6L)},{0xBEA3F69DL,0x8B0DD09BL,0x78DEFD6FL},{0xF77E3D4FL,0xF700FCD6L,0xCAD77327L},{1L,0x534B053AL,0x844ECE63L},{(-6L),0x9400B5A0L,1L},{0xBEA3F69DL,1L,0x1BF96E43L},{0x46595A4AL,0x9400B5A0L,0x46595A4AL},{0x8B0DD09BL,0x534B053AL,1L}},{{0xC69B6069L,0xF700FCD6L,0x94F29EF3L},{0x55775084L,0x8B0DD09BL,0x1BF96E43L},{0x946853C8L,0x9A721EA3L,0xFA7B87D9L},{0x55775084L,1L,0x844ECE63L},{0xC69B6069L,1L,0x89460961L},{0x8B0DD09BL,0x55775084L,0x78DEFD6FL},{0x46595A4AL,0x9A721EA3L,0xF77E3D4FL},{0xBEA3F69DL,0x78DEFD6FL,0x78DEFD6FL},{(-6L),0xF700FCD6L,0x89460961L}},{{1L,0xBEA3F69DL,0x844ECE63L},{0xF77E3D4FL,0x9400B5A0L,0xFA7B87D9L},{0xBEA3F69DL,0x6609A336L,0x1BF96E43L},{0x94F29EF3L,0x9400B5A0L,0x94F29EF3L},{0x8B0DD09BL,0xBEA3F69DL,1L},{(-1L),0xF700FCD6L,0x46595A4AL},{0x55775084L,0x78DEFD6FL,0x1BF96E43L},{(-1L),0x9A721EA3L,1L},{0x55775084L,0x55775084L,0x844ECE63L}},{{(-1L),1L,0xCAD77327L},{0x8B0DD09BL,1L,0x78DEFD6FL},{0x94F29EF3L,0x9A721EA3L,(-6L)},{0xBEA3F69DL,0x8B0DD09BL,0x78DEFD6FL},{0xF77E3D4FL,0xF700FCD6L,0xCAD77327L},{1L,0x534B053AL,0x844ECE63L},{(-6L),0x9400B5A0L,1L},{0xBEA3F69DL,1L,0x1BF96E43L},{0x46595A4AL,0x9400B5A0L,0x46595A4AL}},{{0x8B0DD09BL,0x534B053AL,1L},{0xC69B6069L,0xF700FCD6L,0x94F29EF3L},{0x55775084L,0x8B0DD09BL,0x1BF96E43L},{0x946853C8L,0x9A721EA3L,0xFA7B87D9L},{0x55775084L,1L,0x844ECE63L},{0xC69B6069L,1L,0x89460961L},{0x8B0DD09BL,0x55775084L,0x78DEFD6FL},{0x46595A4AL,0x9A721EA3L,0xF77E3D4FL},{0xBEA3F69DL,0x78DEFD6FL,0x78DEFD6FL}},{{(-6L),0xF700FCD6L,0x89460961L},{1L,0xBEA3F69DL,0x844ECE63L},{0xF77E3D4FL,0x9400B5A0L,0xFA7B87D9L},{0xBEA3F69DL,0x6609A336L,0x1BF96E43L},{0x94F29EF3L,0x9400B5A0L,0x94F29EF3L},{0x8B0DD09BL,0xBEA3F69DL,1L},{(-1L),0xF700FCD6L,0x46595A4AL},{1L,0x6609A336L,0x844ECE63L},{0x89460961L,0xF700FCD6L,(-6L)}},{{1L,1L,1L},{0x46595A4AL,9L,0xFA7B87D9L},{1L,0xBFCA6505L,0x6609A336L},{(-1L),0xF700FCD6L,(-1L)},{0x8B0DD09BL,1L,0x6609A336L},{0L,1L,0xFA7B87D9L},{1L,0x78DEFD6FL,1L},{(-1L),0x84C31DF8L,(-6L)},{0x8B0DD09BL,1L,0x844ECE63L}},{{0x946853C8L,0x84C31DF8L,0x946853C8L},{1L,0x78DEFD6FL,0xBFCA6505L},{0x94F29EF3L,1L,(-1L)},{1L,1L,0x844ECE63L},{0xCAD77327L,0xF700FCD6L,0xF77E3D4FL},{1L,0xBFCA6505L,1L},{0x94F29EF3L,9L,1L},{1L,1L,0x6609A336L},{0x946853C8L,0xF700FCD6L,0L}},{{0x8B0DD09BL,0x6609A336L,0x6609A336L},{(-1L),1L,1L},{1L,0x8B0DD09BL,1L},{0L,0x84C31DF8L,0xF77E3D4FL},{0x8B0DD09BL,0x1BF96E43L,0x844ECE63L},{(-1L),0x84C31DF8L,(-1L)},{1L,0x8B0DD09BL,0xBFCA6505L},{0x46595A4AL,1L,0x946853C8L},{1L,0x6609A336L,0x844ECE63L}}};
        int32_t *l_2587[9];
        struct S2 **l_2605[5];
        struct S2 ***l_2604 = &l_2605[3];
        uint16_t l_2664 = 0xABEDL;
        int16_t l_2736 = 1L;
        int32_t *l_2760 = &g_1450[2][0][1];
        int32_t l_2847 = (-1L);
        int64_t l_2851[4][3][4] = {{{(-2L),(-1L),(-1L),(-2L)},{(-1L),(-2L),(-1L),(-1L)},{(-2L),(-2L),(-1L),(-2L)}},{{(-2L),(-1L),(-1L),(-2L)},{(-1L),(-2L),(-1L),(-1L)},{(-2L),(-2L),(-1L),(-2L)}},{{(-2L),(-1L),(-1L),(-2L)},{(-1L),(-2L),(-1L),(-1L)},{(-2L),(-2L),(-1L),(-2L)}},{{(-2L),(-1L),(-1L),(-2L)},{(-1L),(-2L),(-1L),(-1L)},{(-2L),(-2L),(-1L),(-2L)}}};
        struct S0 **l_2872[1];
        uint32_t l_2882 = 0xE2BF05FAL;
        union U3 l_2895 = {0};
        uint8_t l_2912[4];
        int i, j, k;
        for (i = 0; i < 9; i++)
            l_2587[i] = (void*)0;
        for (i = 0; i < 5; i++)
            l_2605[i] = &g_1815;
        for (i = 0; i < 1; i++)
            l_2872[i] = &l_2870[2];
        for (i = 0; i < 4; i++)
            l_2912[i] = 0x00L;
        for (g_1503.f6 = 11; (g_1503.f6 >= 36); g_1503.f6 = safe_add_func_int64_t_s_s(g_1503.f6, 8))
        { /* block id: 1224 */
            int32_t l_2536 = (-1L);
            int32_t l_2564[1][5][3] = {{{0L,0xCFFF6951L,0xDFE17EBFL},{0xBE92F29EL,0xCFFF6951L,0xBE92F29EL},{0x7606BC38L,0L,0xDFE17EBFL},{0x7606BC38L,0x7606BC38L,0L},{0xBE92F29EL,0L,0L}}};
            union U3 l_2617 = {0};
            int32_t l_2620 = 0xA9D1841FL;
            uint8_t l_2625 = 0x92L;
            const int8_t l_2641 = (-2L);
            uint16_t l_2661 = 65535UL;
            int i, j, k;
        }
        (*g_78) = ((*g_1000) , &l_2551[0][3][1]);
        if (((**g_78) = p_17))
        { /* block id: 1284 */
lbl_2919:
            ++l_2664;
        }
        else
        { /* block id: 1286 */
            int32_t **l_2688[1][7][9] = {{{&l_2587[7],&l_2587[5],&l_2587[0],&l_2587[0],&l_2587[5],&l_2587[7],&l_2587[7],&l_2610,&l_2587[3]},{&l_2587[0],&l_2610,&l_2587[7],&l_2610,&l_2587[7],&g_2014,&l_2610,&l_2587[6],&l_2610},{&l_2587[7],&l_2587[7],&g_79,&l_2587[8],&l_2610,&g_2014,&l_2587[7],&g_2014,&l_2610},{&g_79,&l_2587[6],&l_2587[6],&g_79,&g_2014,&g_2014,&l_2587[8],&l_2587[7],&g_79},{(void*)0,&l_2587[8],&l_2587[3],&l_2610,&l_2610,&l_2587[8],&g_2014,&g_2014,&g_79},{(void*)0,&l_2587[0],&g_2014,&l_2587[7],&l_2610,(void*)0,&l_2610,&l_2587[7],&g_2014},{&l_2587[7],&l_2587[7],(void*)0,&l_2587[7],&g_79,&l_2587[6],&l_2587[7],&l_2587[7],&l_2587[7]}}};
            int8_t l_2705 = 9L;
            int32_t *l_2717 = &g_169.f4;
            const uint64_t l_2735[7][3][9] = {{{1UL,0xC9ED3CC2A5620B75LL,1UL,0x769B3E3A2B3E9E51LL,0x8B1EA9369D29924ELL,1UL,18446744073709551610UL,18446744073709551615UL,18446744073709551615UL},{1UL,0xC9ED3CC2A5620B75LL,18446744073709551615UL,0x8B1EA9369D29924ELL,18446744073709551615UL,0xC9ED3CC2A5620B75LL,1UL,18446744073709551610UL,0xD4E2A9F9E1772C95LL},{18446744073709551610UL,1UL,0x8B1EA9369D29924ELL,0x769B3E3A2B3E9E51LL,1UL,0xC9ED3CC2A5620B75LL,1UL,0x769B3E3A2B3E9E51LL,0x8B1EA9369D29924ELL}},{{0x8B1EA9369D29924ELL,0x8B1EA9369D29924ELL,2UL,0xBD51B02404C0F002LL,0xD4E2A9F9E1772C95LL,1UL,0xC9ED3CC2A5620B75LL,18446744073709551610UL,0xC9ED3CC2A5620B75LL},{0x8B1EA9369D29924ELL,1UL,1UL,1UL,1UL,0x8B1EA9369D29924ELL,0xBD51B02404C0F002LL,18446744073709551615UL,0x907B4BCBE04F95D7LL},{18446744073709551610UL,0x769B3E3A2B3E9E51LL,2UL,0x907B4BCBE04F95D7LL,1UL,1UL,0x907B4BCBE04F95D7LL,2UL,0x769B3E3A2B3E9E51LL}},{{1UL,0xC1D08EFD9F1DE2E3LL,0x8B1EA9369D29924ELL,1UL,0xD4E2A9F9E1772C95LL,0x769B3E3A2B3E9E51LL,0xBD51B02404C0F002LL,0xBD51B02404C0F002LL,0x769B3E3A2B3E9E51LL},{1UL,2UL,18446744073709551615UL,2UL,1UL,0xC1D08EFD9F1DE2E3LL,0xC9ED3CC2A5620B75LL,0x8B1EA9369D29924ELL,0x907B4BCBE04F95D7LL},{0xC9ED3CC2A5620B75LL,0xC1D08EFD9F1DE2E3LL,1UL,2UL,18446744073709551615UL,2UL,1UL,0xC1D08EFD9F1DE2E3LL,0xC9ED3CC2A5620B75LL}},{{0xBD51B02404C0F002LL,0x769B3E3A2B3E9E51LL,0xD4E2A9F9E1772C95LL,1UL,0x8B1EA9369D29924ELL,0xC1D08EFD9F1DE2E3LL,1UL,0xC1D08EFD9F1DE2E3LL,0x8B1EA9369D29924ELL},{0x907B4BCBE04F95D7LL,1UL,1UL,0x907B4BCBE04F95D7LL,2UL,0x769B3E3A2B3E9E51LL,18446744073709551610UL,0x8B1EA9369D29924ELL,0xD4E2A9F9E1772C95LL},{0xBD51B02404C0F002LL,0x8B1EA9369D29924ELL,1UL,1UL,1UL,1UL,0x8B1EA9369D29924ELL,0xBD51B02404C0F002LL,18446744073709551615UL}},{{0xC9ED3CC2A5620B75LL,1UL,0xD4E2A9F9E1772C95LL,0xBD51B02404C0F002LL,2UL,0x8B1EA9369D29924ELL,0x8B1EA9369D29924ELL,2UL,0xBD51B02404C0F002LL},{1UL,0xC9ED3CC2A5620B75LL,1UL,0x769B3E3A2B3E9E51LL,0x8B1EA9369D29924ELL,1UL,18446744073709551610UL,18446744073709551615UL,18446744073709551615UL},{1UL,0xC9ED3CC2A5620B75LL,18446744073709551615UL,0x8B1EA9369D29924ELL,18446744073709551615UL,0xC9ED3CC2A5620B75LL,1UL,18446744073709551610UL,0xD4E2A9F9E1772C95LL}},{{18446744073709551610UL,1UL,0x8B1EA9369D29924ELL,0x769B3E3A2B3E9E51LL,1UL,0xC9ED3CC2A5620B75LL,1UL,0x769B3E3A2B3E9E51LL,0x8B1EA9369D29924ELL},{0x8B1EA9369D29924ELL,0x8B1EA9369D29924ELL,2UL,0xBD51B02404C0F002LL,0xD4E2A9F9E1772C95LL,1UL,0xC9ED3CC2A5620B75LL,18446744073709551610UL,0xC9ED3CC2A5620B75LL},{0x8B1EA9369D29924ELL,1UL,1UL,1UL,1UL,0x8B1EA9369D29924ELL,0xBD51B02404C0F002LL,18446744073709551615UL,0x907B4BCBE04F95D7LL}},{{18446744073709551610UL,0x769B3E3A2B3E9E51LL,2UL,0x907B4BCBE04F95D7LL,1UL,1UL,0x8B1EA9369D29924ELL,0xC9ED3CC2A5620B75LL,0xC1D08EFD9F1DE2E3LL},{0x907B4BCBE04F95D7LL,0xD4E2A9F9E1772C95LL,2UL,1UL,18446744073709551615UL,0xC1D08EFD9F1DE2E3LL,0x769B3E3A2B3E9E51LL,0x769B3E3A2B3E9E51LL,0xC1D08EFD9F1DE2E3LL},{1UL,0xC9ED3CC2A5620B75LL,18446744073709551610UL,0xC9ED3CC2A5620B75LL,1UL,0xD4E2A9F9E1772C95LL,0xBD51B02404C0F002LL,2UL,0x8B1EA9369D29924ELL}}};
            struct S1 *l_2804 = &g_1009;
            int8_t l_2806 = 4L;
            uint8_t l_2815 = 0x24L;
            struct S0 l_2904 = {0x7CL,0xD5L,5L,0x27BD6CF1L,2L,1L,6UL,0x06L,0x29L};
            union U3 *l_2950 = &g_1069;
            int i, j, k;
            if ((((safe_mod_func_int32_t_s_s((safe_mul_func_uint8_t_u_u(1UL, p_16)), (safe_add_func_int8_t_s_s((g_2673 , ((safe_rshift_func_uint8_t_u_u((((((((*g_525) = (safe_rshift_func_uint8_t_u_s((safe_sub_func_uint64_t_u_u((safe_add_func_uint64_t_u_u(0x53DD6FAD4D341861LL, ((*g_1000) = ((((safe_add_func_uint16_t_u_u((safe_mod_func_int16_t_s_s(((l_2686 = l_2686) == l_2687), ((((&l_2610 == l_2688[0][3][6]) , (safe_mod_func_int32_t_s_s(((p_16 || 0x30E9L) & 1L), 0x85D394ADL))) < (**g_756)) & 4294967295UL))), 0xBB88L)) ^ p_17) != p_17) != p_16)))), p_17)), (*p_18)))) != p_16) != (*g_182)) , g_2691) == (void*)0) < p_16), 0)) & 250UL)), 0xDBL)))) == (*l_2610)) | 1UL))
            { /* block id: 1290 */
                int32_t l_2706 = 0x1E161926L;
                int32_t l_2707[3][1];
                uint16_t l_2708 = 0xD362L;
                uint64_t *l_2718[5] = {&l_2578,&l_2578,&l_2578,&l_2578,&l_2578};
                struct S0 l_2762 = {9UL,0xB5L,-6L,0xB9E26A66L,0L,0xFEL,0xFDD31DD6DE33A296LL,255UL,3UL};
                union U3 l_2763 = {0};
                int i, j;
                for (i = 0; i < 3; i++)
                {
                    for (j = 0; j < 1; j++)
                        l_2707[i][j] = 9L;
                }
                (**g_78) &= (safe_sub_func_uint64_t_u_u((safe_mod_func_uint8_t_u_u((((safe_add_func_int32_t_s_s((((((*l_2610) = (((safe_div_func_uint32_t_u_u(((-1L) != 18446744073709551613UL), (**g_756))) == ((+(safe_div_func_uint32_t_u_u((**g_756), (*l_2610)))) == (-8L))) > (9L >= ((**g_999) = (*g_1000))))) , &l_2519) == &l_2519) != (-1L)), l_2705)) || (-5L)) | 0xD7DB9FF62942D74ALL), 0x0CL)), 0x67C94A75C0EF7119LL));
                if (g_1145.f4)
                    goto lbl_2711;
lbl_2711:
                l_2708++;
                if ((safe_div_func_uint32_t_u_u(0UL, (safe_mul_func_uint8_t_u_u((((0x3DL || (safe_unary_minus_func_uint32_t_u((l_2717 == &g_313[0][6])))) , (*g_1144)) , (((l_2719++) & ((((*g_1903) = (((l_2707[2][0] = ((safe_rshift_func_uint8_t_u_u(((safe_sub_func_int16_t_s_s(l_2707[0][0], (safe_rshift_func_uint16_t_u_u((safe_sub_func_int32_t_s_s(((2L && (((+(safe_mul_func_uint32_t_u_u((*l_2610), (1L != p_16)))) == p_17) < l_2735[4][1][8])) < p_16), (*g_757))), 8)))) & 6L), 5)) , l_2736)) <= p_17) , (*p_18))) & p_16) , 2L)) , l_2708)), p_17)))))
                { /* block id: 1299 */
                    uint64_t l_2749 = 0UL;
                    for (g_169.f7 = 0; (g_169.f7 >= 25); g_169.f7++)
                    { /* block id: 1302 */
                        (*g_79) &= (((*g_1000) |= ((***g_1142) , ((safe_mod_func_int8_t_s_s(((safe_lshift_func_uint8_t_u_u(p_17, (safe_sub_func_int16_t_s_s(((((***l_2520) != l_2717) , 0x6F63L) | (safe_mul_func_uint8_t_u_u(((p_16 , (safe_mul_func_uint8_t_u_u((l_2749 , ((safe_sub_func_uint8_t_u_u((safe_div_func_uint8_t_u_u((safe_unary_minus_func_uint16_t_u((safe_rshift_func_int16_t_s_u((1L & (((*l_2610) , 0x47L) < 0L)), p_16)))), p_17)), (*g_1903))) > 7L)), p_16))) , p_17), l_2707[1][0]))), (-1L))))) > 0x83L), (*l_2610))) || p_16))) > p_16);
                    }
                    (**l_2508) = &g_832[5][1][0];
                    l_2760 = (g_2759 , &l_2577);
                    g_2660 = g_2761;
                }
                else
                { /* block id: 1309 */
                    uint32_t l_2782 = 0x2C64602FL;
                    (*g_1143) = ((l_2762 , (**g_1143)) , (**g_1142));
                    for (g_1503.f5 = 6; (g_1503.f5 >= 0); g_1503.f5 -= 1)
                    { /* block id: 1313 */
                        struct S2 * const l_2770 = (void*)0;
                        struct S2 * const *l_2769 = &l_2770;
                        uint32_t ***l_2774[3];
                        uint64_t l_2783 = 3UL;
                        int i;
                        for (i = 0; i < 3; i++)
                            l_2774[i] = (void*)0;
                        (*l_2610) = (((l_2763 , ((safe_mul_func_int16_t_s_s(((*l_2686) &= g_136[g_1503.f5]), (g_136[g_1503.f5] && (safe_sub_func_int32_t_s_s((((*l_2604) = l_2768) == (l_2769 = &g_1815)), (((safe_add_func_uint32_t_u_u(((g_2773 , l_2774[0]) != (void*)0), (((((((safe_mul_func_uint16_t_u_u((safe_mod_func_uint32_t_u_u((safe_lshift_func_int16_t_s_s(((+(((*g_525) = ((p_17 | (*g_525)) || p_16)) >= 0UL)) & p_17), 14)), l_2782)), (*l_2610))) , p_16) > (*p_18)) , p_16) || (*l_2610)) <= 18446744073709551615UL) < (*p_18)))) == (*p_18)) , l_2762.f8)))))) || 7UL)) <= l_2783) > l_2782);
                    }
                    (*g_78) = (void*)0;
                }
            }
            else
            { /* block id: 1322 */
                int8_t *l_2795 = &g_136[0];
                const int32_t l_2828 = 4L;
                struct S1 **l_2833 = &g_1144;
                int32_t *l_2835 = &g_315[0];
                for (g_125 = 0; (g_125 <= 2); g_125 += 1)
                { /* block id: 1325 */
                    int64_t l_2802 = 0x7A4FD13B51406576LL;
                    for (g_223 = 0; (g_223 <= 2); g_223 += 1)
                    { /* block id: 1328 */
                        int8_t **l_2796 = &l_2795;
                        const int32_t l_2800 = 0x33C199CDL;
                        uint16_t *l_2801 = &l_2664;
                        int i;
                        (*l_2760) ^= (65530UL == (((safe_div_func_uint16_t_u_u((safe_div_func_int8_t_s_s((((+((((**g_1143) , (safe_div_func_uint64_t_u_u(0UL, ((*g_1000) = 0x27FE39BC143DEE84LL)))) <= ((**g_756) = ((safe_lshift_func_int8_t_s_s(((safe_add_func_int64_t_s_s(g_1071[g_223], (((((*l_2796) = (g_1903 = l_2795)) == ((((*l_2801) = ((((**g_78) , (safe_sub_func_uint8_t_u_u((safe_unary_minus_func_uint64_t_u(0UL)), (((((*g_757) || 0x684612CEL) , p_16) , p_17) <= 8L)))) && g_1071[g_223]) ^ l_2800)) == 0xFA5BL) , &g_136[0])) == 1L) & l_2802))) < (-1L)), (*p_18))) >= 0xC247EC472636F6CFLL))) & 6L)) == l_2803) >= 0x05L), p_16)), (*g_525))) || (-9L)) > l_2800));
                    }
                }
                if (p_16)
                { /* block id: 1337 */
                    int8_t l_2805 = 1L;
                    int32_t l_2807 = 0L;
                    int32_t l_2808 = 0x38596ACAL;
                    int32_t l_2809 = 1L;
                    int32_t l_2810 = 0x9B8E5278L;
                    int32_t l_2811 = (-2L);
                    (*l_2610) &= 0L;
                    (**g_1142) = l_2804;
                    --g_2812;
                }
                else
                { /* block id: 1341 */
                    int16_t l_2834 = 0xFF7AL;
                    l_2815++;
                    (*g_78) = &l_2577;
                    l_2610 = func_58((safe_sub_func_int16_t_s_s(((safe_mod_func_uint64_t_u_u(((++(**g_756)) || (safe_mul_func_int8_t_s_s((*p_18), (safe_add_func_uint8_t_u_u((((l_2828 == (((safe_lshift_func_int8_t_s_u(((**g_1143) , ((*p_18) > ((safe_add_func_uint64_t_u_u(p_16, (((**g_2691) , l_2833) != (void*)0))) || 4UL))), 7)) || l_2834) , 0x47FDDBACL)) >= l_2834) && p_16), (*p_18)))))), (*g_1000))) > 1UL), 0x8587L)), p_16, (*g_2262), l_2835);
                }
            }
            for (g_69 = 0; (g_69 > (-19)); g_69 = safe_sub_func_int64_t_s_s(g_69, 7))
            { /* block id: 1350 */
                struct S2 *l_2844 = &g_743;
                int32_t *l_2845 = &g_45;
                int32_t l_2852 = 2L;
                int32_t l_2855[10] = {9L,1L,9L,1L,9L,1L,9L,1L,9L,1L};
                int8_t l_2881 = 0L;
                const int32_t l_2899 = 1L;
                int i;
            }
            for (g_1226 = (-24); (g_1226 <= 42); g_1226++)
            { /* block id: 1393 */
                int64_t l_2936 = 0L;
                int32_t l_2943 = (-7L);
                int32_t l_2944 = 3L;
                int32_t *l_2948 = &l_2862;
                for (g_1148 = 0; (g_1148 > 46); g_1148++)
                { /* block id: 1396 */
                    for (g_670 = 0; (g_670 <= 0); g_670 += 1)
                    { /* block id: 1399 */
                        int i;
                        if (g_45)
                            goto lbl_2919;
                        g_315[g_670] = 0L;
                        if (g_315[(g_670 + 1)])
                            break;
                    }
                    for (g_1503.f0 = (-16); (g_1503.f0 <= 36); g_1503.f0++)
                    { /* block id: 1406 */
                        l_2922++;
                        (*l_2760) = (safe_rshift_func_uint8_t_u_u(p_16, p_16));
                        g_1813 = g_2927;
                    }
                    (*l_2760) |= ((((safe_rshift_func_uint16_t_u_s((safe_div_func_uint64_t_u_u(((safe_sub_func_uint8_t_u_u(1UL, p_16)) < (safe_sub_func_uint16_t_u_u((*g_525), (p_17 & l_2936)))), (65535UL || (safe_mul_func_uint8_t_u_u(p_17, (0x7315ADF326BFD92CLL == (safe_rshift_func_int8_t_s_u(l_2936, 1)))))))), 11)) >= p_17) || (-6L)) || 0x37021C46L);
                }
                for (l_2519 = (-7); (l_2519 == (-3)); l_2519 = safe_add_func_int64_t_s_s(l_2519, 8))
                { /* block id: 1415 */
                    int32_t *l_2947 = &l_2863;
                    (*l_2760) &= (l_2944 ^= ((0x66L && (l_2943 = ((*g_1903) &= 0x1EL))) ^ 0xAE129D038F740033LL));
                    for (g_835 = (-26); (g_835 != 21); ++g_835)
                    { /* block id: 1422 */
                        return l_2949;
                    }
                    (*l_2949) = ((void*)0 == l_2950);
                }
            }
        }
    }
    (*l_2949) = ((safe_add_func_uint32_t_u_u((p_17 >= (((*l_2949) <= ((((*l_2949) < ((safe_mul_func_uint8_t_u_u(0xF8L, (safe_add_func_uint8_t_u_u((l_2959[0][2][0] && (safe_mod_func_uint8_t_u_u((safe_div_func_int8_t_s_s((*l_2610), (((***g_1487) == (((*l_2686) = ((void*)0 != l_2964[0][6][3])) , (**g_767))) || 1UL))), (*l_2610)))), p_17)))) > 0L)) > (*g_1000)) || l_2965)) & (**g_999))), 8UL)) , p_17);
    (*g_78) = &l_2959[0][2][0];
    return g_2974[0][2][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_169.f5 g_1903 g_69 g_525 g_223 g_935 g_2014 g_8 g_78 g_1246 g_1017.f7 g_1815 g_999 g_1000 g_790 g_2262 g_1831 g_313 g_1017.f8 g_1503.f6 g_767 g_672 g_294 g_315 g_757 g_123 g_1010.f2 g_1270.f2 g_188 g_1450 g_1142 g_1143 g_1017 g_2418 g_756 g_169.f0 g_1574 g_833 g_1489 g_1490 g_1491 g_2127 g_2128 g_1575 g_5 g_79 g_360 g_136
 * writes: g_169.f5 g_935 g_1503.f6 g_542 g_2262 g_79 g_223 g_1815 g_188 g_69 g_790 g_315 g_673 g_1503.f5 g_169.f6 g_1877 g_1071 g_1450 g_125 g_169.f0 g_1831 g_94 g_2052 g_999 g_360 g_136
 */
static uint8_t  func_21(int16_t  p_22)
{ /* block id: 12 */
    const int64_t l_32 = 0x3279329BFAEAD221LL;
    int8_t *l_35 = (void*)0;
    int16_t *l_2490 = (void*)0;
    int16_t *l_2491 = &g_360;
    const uint32_t l_2492 = 0x0BDE5240L;
    int32_t l_2493 = 0xF9AA5D33L;
    int8_t l_2494 = 0xBBL;
    l_2493 &= ((p_22 ^ (safe_rshift_func_uint16_t_u_s((safe_add_func_int8_t_s_s(((p_22 | (safe_sub_func_int16_t_s_s((safe_lshift_func_int16_t_s_s((l_32 , ((*l_2491) ^= (safe_sub_func_int8_t_s_s((((&g_5 != l_35) , (func_36(((*g_1903) = ((p_22 == 1L) < func_41(func_43(&g_5)))), l_32, p_22, p_22) , 0x6BL)) , l_32), 0xF7L)))), 15)), l_2492))) <= p_22), l_32)), p_22))) && 0xB2BEL);
    return l_2494;
}


/* ------------------------------------------ */
/* 
 * reads : g_69 g_525 g_223 g_1903 g_935 g_2014 g_8 g_78 g_1246 g_1017.f7 g_1815 g_999 g_1000 g_790 g_2262 g_1831 g_313 g_1017.f8 g_1503.f6 g_767 g_672 g_294 g_315 g_757 g_123 g_1010.f2 g_1270.f2 g_188 g_1450 g_1142 g_1143 g_1017 g_2418 g_756 g_169.f0 g_1574 g_833 g_1489 g_1490 g_1491 g_2127 g_2128 g_1575 g_5 g_79 g_136
 * writes: g_1503.f6 g_542 g_935 g_2262 g_79 g_223 g_1815 g_188 g_69 g_790 g_315 g_673 g_1503.f5 g_169.f6 g_1877 g_1071 g_1450 g_125 g_169.f0 g_1831 g_94 g_2052 g_999 g_136
 */
static int16_t  func_36(int8_t  p_37, uint8_t  p_38, int8_t  p_39, uint32_t  p_40)
{ /* block id: 1041 */
    uint64_t l_2204 = 0xBFB7874E325BD0D0LL;
    int32_t l_2219 = 5L;
    struct S1 ***l_2233 = &g_1143;
    int64_t ***l_2256 = (void*)0;
    int32_t *l_2261 = &g_1503.f4;
    struct S0 *l_2319 = &g_1017[0];
    int32_t *l_2320 = &g_315[0];
    union U3 *l_2327 = &g_310;
    int32_t l_2336 = 0L;
    int32_t l_2337 = 0xFF523533L;
    int32_t l_2338[4][5][2] = {{{(-1L),(-10L)},{(-8L),(-8L)},{1L,0x9C3C25CAL},{(-1L),0xBF20BC57L},{0x9C3C25CAL,(-4L)}},{{0L,0x9C3C25CAL},{(-8L),1L},{(-8L),0x9C3C25CAL},{0L,(-4L)},{0x9C3C25CAL,0xBF20BC57L}},{{(-1L),0x9C3C25CAL},{1L,(-8L)},{(-8L),(-10L)},{(-1L),(-4L)},{(-10L),(-4L)}},{{(-1L),(-10L)},{(-8L),(-8L)},{1L,0x9C3C25CAL},{(-1L),0xBF20BC57L},{0x9C3C25CAL,(-4L)}}};
    uint32_t **l_2358 = &g_757;
    int8_t *l_2372[2][2][2] = {{{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0}}};
    int64_t ***l_2398 = &g_999;
    union U3 ****l_2466 = &g_767;
    int32_t ***l_2472 = &g_78;
    int i, j, k;
    if (l_2204)
    { /* block id: 1042 */
        uint8_t l_2207 = 250UL;
        uint32_t **l_2214 = &g_833;
        uint64_t *l_2217 = &g_1503.f6;
        int32_t *l_2218[9] = {&g_8,&g_315[1],&g_315[1],&g_8,&g_315[1],&g_315[1],&g_8,&g_315[1],&g_315[1]};
        int i;
        l_2219 = (safe_sub_func_int8_t_s_s(l_2207, (p_40 , (((*l_2217) = ((safe_mul_func_int8_t_s_s((safe_div_func_uint8_t_u_u(((safe_mul_func_int8_t_s_s(((l_2214 != (void*)0) <= (g_69 <= (0xB127L != (*g_525)))), (l_2204 | (((safe_lshift_func_int16_t_s_s(l_2204, p_39)) > p_39) , (-8L))))) & l_2207), l_2204)), l_2204)) || p_39)) , l_2207))));
    }
    else
    { /* block id: 1045 */
        int8_t l_2246[5][2] = {{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)}};
        int32_t l_2250[4];
        union U3 **l_2265[6] = {(void*)0,&g_673,(void*)0,(void*)0,&g_673,(void*)0};
        const int8_t l_2377[5][2][8] = {{{8L,0L,0xBEL,(-1L),0x86L,8L,0L,0xBDL},{(-3L),0x56L,0x83L,1L,1L,0x83L,0x56L,(-3L)}},{{6L,0x9CL,0L,0x54L,0x49L,0x44L,1L,0L},{0x8FL,0x49L,(-3L),0xBEL,0x54L,0x44L,6L,8L}},{{2L,0x9CL,8L,0x83L,0L,0x83L,8L,0x9CL},{8L,0x56L,0xE4L,0L,0L,8L,0L,0xBEL}},{{0L,0L,0x83L,(-3L),8L,(-1L),0L,(-3L)},{(-1L),(-3L),0xE4L,8L,0x49L,0x49L,8L,0xE4L}},{{0x49L,0x49L,8L,0xE4L,(-3L),(-1L),6L,0x54L},{(-1L),8L,(-3L),0x83L,0L,0L,1L,0x54L}}};
        struct S1 ****l_2378 = &g_1142;
        int32_t **l_2436 = &g_2262;
        int32_t *l_2438[7][2] = {{&g_69,&g_69},{&g_69,&g_69},{&g_69,&g_69},{&g_69,&g_69},{&g_69,&g_69},{&g_69,&g_69},{&g_69,&g_69}};
        const struct S0 l_2450 = {1UL,0x47L,0x5D712F3771AFC1C2LL,0xD0F7E544L,0x395BC634L,0x41L,3UL,252UL,255UL};
        int32_t ** const *l_2471 = &g_78;
        int32_t l_2482 = 0xC5392D06L;
        int8_t l_2487[1][2];
        int8_t l_2489 = 0x44L;
        int i, j, k;
        for (i = 0; i < 4; i++)
            l_2250[i] = 0xACC3B839L;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 2; j++)
                l_2487[i][j] = (-8L);
        }
        for (p_40 = 0; (p_40 <= 10); p_40++)
        { /* block id: 1048 */
            struct S1 ***l_2234 = &g_1143;
            struct S0 **l_2235 = (void*)0;
            int32_t l_2247[10];
            uint32_t l_2249 = 1UL;
            const int8_t l_2266 = (-1L);
            const int64_t *l_2269 = &g_188;
            const int64_t **l_2268[9][9] = {{&l_2269,&l_2269,&l_2269,&l_2269,&l_2269,&l_2269,&l_2269,&l_2269,(void*)0},{&l_2269,&l_2269,(void*)0,&l_2269,(void*)0,&l_2269,&l_2269,&l_2269,(void*)0},{&l_2269,&l_2269,&l_2269,(void*)0,(void*)0,&l_2269,&l_2269,&l_2269,(void*)0},{&l_2269,&l_2269,&l_2269,&l_2269,&l_2269,(void*)0,(void*)0,&l_2269,&l_2269},{&l_2269,&l_2269,(void*)0,&l_2269,&l_2269,&l_2269,&l_2269,&l_2269,(void*)0},{&l_2269,&l_2269,&l_2269,&l_2269,&l_2269,&l_2269,(void*)0,&l_2269,(void*)0},{&l_2269,&l_2269,(void*)0,&l_2269,&l_2269,(void*)0,&l_2269,&l_2269,(void*)0},{&l_2269,&l_2269,&l_2269,&l_2269,&l_2269,&l_2269,&l_2269,&l_2269,(void*)0},{&l_2269,&l_2269,(void*)0,&l_2269,(void*)0,&l_2269,&l_2269,&l_2269,(void*)0}};
            const int64_t ***l_2267 = &l_2268[0][0];
            int32_t l_2271 = 0xF6325901L;
            const struct S2 *l_2292 = (void*)0;
            uint32_t *l_2350 = &g_94;
            const uint32_t l_2393 = 18446744073709551615UL;
            int16_t ***l_2397[5] = {&g_1513,&g_1513,&g_1513,&g_1513,&g_1513};
            uint16_t **l_2435 = &g_525;
            struct S0 l_2457 = {247UL,0x2CL,0L,9L,0x2F6242A4L,0xF5L,18446744073709551615UL,255UL,1UL};
            int32_t *****l_2460 = (void*)0;
            int64_t *l_2486 = &g_2052[2];
            int16_t l_2488 = 0xFA0CL;
            int i, j;
            for (i = 0; i < 10; i++)
                l_2247[i] = 6L;
            for (g_542 = (-2); (g_542 < 30); g_542 = safe_add_func_uint16_t_u_u(g_542, 1))
            { /* block id: 1051 */
                struct S1 ****l_2232[8][8][4] = {{{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,(void*)0,(void*)0},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,(void*)0,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,(void*)0,&g_1142,&g_1142}},{{&g_1142,&g_1142,&g_1142,(void*)0},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,(void*)0,(void*)0}},{{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,(void*)0,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,(void*)0,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,(void*)0},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,(void*)0}},{{&g_1142,&g_1142,(void*)0,&g_1142},{(void*)0,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,(void*)0},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142}},{{(void*)0,&g_1142,(void*)0,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,(void*)0},{&g_1142,&g_1142,(void*)0,&g_1142},{(void*)0,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,(void*)0}},{{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{(void*)0,&g_1142,(void*)0,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142}},{{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,(void*)0},{&g_1142,&g_1142,(void*)0,&g_1142},{(void*)0,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,(void*)0},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142}},{{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{(void*)0,&g_1142,(void*)0,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,&g_1142},{&g_1142,&g_1142,&g_1142,(void*)0},{&g_1142,&g_1142,(void*)0,&g_1142}}};
                struct S0 *l_2237 = (void*)0;
                struct S0 **l_2236[4];
                int32_t l_2248 = (-1L);
                int i, j, k;
                for (i = 0; i < 4; i++)
                    l_2236[i] = &l_2237;
                l_2250[1] &= (((safe_lshift_func_uint16_t_u_u((p_40 | ((((safe_lshift_func_int8_t_s_u((safe_sub_func_int16_t_s_s(((l_2233 = ((safe_rshift_func_uint8_t_u_u(p_38, 2)) , (void*)0)) != l_2234), (l_2235 != l_2236[1]))), ((((safe_sub_func_uint8_t_u_u((safe_rshift_func_int8_t_s_s((((safe_div_func_int8_t_s_s(p_39, (((safe_mul_func_uint8_t_u_u((0x9D4D636AC42B4206LL > 18446744073709551615UL), 0x4EL)) < l_2204) && p_38))) , l_2246[2][0]) != l_2219), (*g_1903))), 1UL)) ^ l_2219) ^ l_2246[0][1]) , p_39))) , l_2247[0]) , 0xDA57E8C6L) >= l_2248)), l_2249)) , (void*)0) != (void*)0);
            }
            if (((void*)0 == &g_832[6][1][0]))
            { /* block id: 1055 */
                int32_t l_2258 = 4L;
                int32_t *l_2272 = (void*)0;
                const struct S2 *l_2289[2][2] = {{&g_2290,&g_2290},{&g_2290,&g_2290}};
                int i, j;
                if ((safe_add_func_uint64_t_u_u(p_39, 0xD8E457CF4CA57ED3LL)))
                { /* block id: 1056 */
                    for (g_935 = 0; (g_935 == (-7)); g_935 = safe_sub_func_int32_t_s_s(g_935, 6))
                    { /* block id: 1059 */
                        l_2247[5] = (+((void*)0 != l_2256));
                    }
                }
                else
                { /* block id: 1062 */
                    l_2219 = l_2204;
                }
                if (((*g_2014) , (p_39 , p_37)))
                { /* block id: 1065 */
                    int32_t *l_2257[2][4][10] = {{{(void*)0,&l_2247[0],&g_45,&l_2250[1],&l_2247[0],&g_12,&g_45,&g_45,&g_45,&g_45},{&g_12,&g_45,&g_45,&g_45,&g_45,&g_12,&l_2247[0],&l_2250[1],&g_45,&l_2247[0]},{(void*)0,&g_45,(void*)0,&l_2247[0],&g_790,&g_12,&g_790,&l_2247[0],&g_45,&g_790},{&g_8,&g_45,&g_1450[1][0][1],&l_2247[0],&g_45,&l_2250[1],&g_790,&g_1450[1][0][1],&g_1450[1][0][1],&g_790}},{{&l_2250[1],&g_790,&g_1450[1][0][1],&g_1450[1][0][1],&g_790,&l_2250[1],&g_45,&l_2247[0],&g_1450[1][0][1],&g_45},{&g_8,&g_790,&g_45,&l_2247[0],&g_790,&g_12,&g_790,&l_2247[0],&g_45,&g_790},{&g_8,&g_45,&g_1450[1][0][1],&l_2247[0],&g_45,&l_2250[1],&g_790,&g_1450[1][0][1],&g_1450[1][0][1],&g_790},{&l_2250[1],&g_790,&g_1450[1][0][1],&g_1450[1][0][1],&g_790,&l_2250[1],&g_45,&l_2247[0],&g_1450[1][0][1],&g_45}}};
                    int32_t *l_2264 = &l_2258;
                    int32_t **l_2263 = &l_2264;
                    int64_t ***l_2270 = &g_999;
                    int i, j, k;
                    l_2250[1] &= (l_2258 |= (l_2219 = p_38));
                    l_2271 &= ((safe_mul_func_int8_t_s_s(((l_2261 != ((*l_2263) = (g_2262 = &g_313[0][1]))) || ((void*)0 == l_2265[1])), (((0x6A29DA7EAE0860E1LL ^ l_2266) >= p_38) , ((l_2250[1] &= (l_2247[0] = l_2258)) < (l_2267 == l_2270))))) < 3L);
                    (*g_78) = l_2272;
                }
                else
                { /* block id: 1075 */
                    struct S2 *l_2281 = (void*)0;
                    struct S0 *l_2288 = &g_169;
                    struct S0 **l_2287 = &l_2288;
                    for (g_223 = 0; (g_223 <= 48); g_223++)
                    { /* block id: 1078 */
                        struct S2 **l_2280 = &g_1815;
                        int32_t l_2286[10];
                        int i;
                        for (i = 0; i < 10; i++)
                            l_2286[i] = 0x3FFE4015L;
                        l_2219 = (((0x88C6L && (g_1246 != g_1246)) != (safe_unary_minus_func_uint16_t_u((*g_525)))) | 1L);
                        l_2286[7] &= (((((**g_999) = (safe_rshift_func_uint16_t_u_u((((*l_2280) = (g_1017[0].f7 , g_1815)) == l_2281), 0))) , (-1L)) & (*g_2014)) || ((*g_525) , ((safe_mul_func_int8_t_s_s(((*g_525) > (safe_mod_func_int8_t_s_s(0xA3L, (0x8AL || 1L)))), p_39)) | l_2250[3])));
                        if (p_38)
                            break;
                    }
                    (*l_2287) = (void*)0;
                }
                if ((l_2250[0] = p_39))
                { /* block id: 1088 */
                    const struct S2 **l_2291 = &l_2289[0][0];
                    l_2292 = ((*l_2291) = l_2289[0][0]);
                    if (p_37)
                        continue;
                }
                else
                { /* block id: 1092 */
                    for (g_69 = 29; (g_69 > (-3)); --g_69)
                    { /* block id: 1095 */
                        int64_t l_2295 = (-1L);
                        int32_t *l_2296 = &g_790;
                        l_2247[0] |= 0L;
                        (*l_2296) ^= l_2295;
                        l_2219 = 0x2176B7DFL;
                    }
                }
            }
            else
            { /* block id: 1101 */
                uint64_t *l_2310 = &g_1503.f6;
                const struct S0 *l_2318 = (void*)0;
                const struct S0 **l_2317 = &l_2318;
                int32_t *l_2321 = &l_2219;
                if ((safe_mul_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_u(((safe_add_func_uint16_t_u_u(((l_2234 != ((*g_2262) , l_2234)) ^ (l_2219 = 7UL)), ((safe_add_func_uint8_t_u_u((safe_mod_func_uint64_t_u_u((+(safe_add_func_int64_t_s_s(((((*l_2310) |= g_1017[0].f8) >= (((p_38 & p_39) & (safe_add_func_int64_t_s_s((safe_sub_func_int64_t_s_s((safe_rshift_func_uint16_t_u_u(((*g_525) = (((*l_2317) = (void*)0) != l_2319)), 2)), l_2204)), l_2246[2][0]))) != 0xDF9C85E5L)) > 5L), 0x3BFB2A94C3E1F6E4LL))), l_2247[2])), 7UL)) & p_39))) & 0x2DC9L), 11)), 0xFF5FL)))
                { /* block id: 1106 */
                    uint8_t l_2326 = 3UL;
                    if (p_39)
                    { /* block id: 1107 */
                        l_2321 = l_2320;
                        (*l_2320) = (+0xD31CL);
                        return p_38;
                    }
                    else
                    { /* block id: 1111 */
                        int32_t l_2323 = 0x780991ADL;
                        (*l_2320) = ((l_2233 != (void*)0) , 0x07B776CAL);
                        l_2250[0] = l_2323;
                        (*l_2320) = (l_2326 = (((*g_525) = (safe_lshift_func_uint8_t_u_u(l_2249, 0))) <= 4UL));
                    }
                }
                else
                { /* block id: 1118 */
                    return p_37;
                }
                (**g_767) = l_2327;
            }
            for (g_1503.f5 = 0; (g_1503.f5 > (-9)); g_1503.f5--)
            { /* block id: 1125 */
                int32_t *l_2330 = &l_2247[3];
                int32_t *l_2331 = &g_1450[1][0][0];
                int32_t *l_2332 = &g_315[0];
                int32_t *l_2333 = &l_2247[2];
                int32_t *l_2334 = (void*)0;
                int32_t *l_2335[3][2][1] = {{{(void*)0},{&g_315[0]}},{{(void*)0},{&g_315[0]}},{{(void*)0},{&g_315[0]}}};
                uint8_t l_2339 = 0x08L;
                struct S1 ****l_2379[9] = {&l_2234,&l_2234,(void*)0,&l_2234,&l_2234,(void*)0,&l_2234,&l_2234,(void*)0};
                uint64_t *l_2380 = &g_1503.f6;
                int32_t l_2382 = 0x04833BA4L;
                uint8_t *l_2429 = &g_169.f0;
                const int8_t *l_2444 = (void*)0;
                union U3 l_2455 = {0};
                struct S0 l_2462 = {255UL,-1L,0x6B557CEB5A3202DDLL,-6L,-9L,0L,4UL,0x09L,0x3BL};
                int i, j, k;
                l_2339--;
                for (g_169.f6 = (-12); (g_169.f6 <= 46); ++g_169.f6)
                { /* block id: 1129 */
                    const union U3 l_2351 = {0};
                    uint32_t l_2357 = 0UL;
                    uint8_t l_2359 = 0xE8L;
                    for (g_223 = 0; (g_223 == 15); g_223 = safe_add_func_int32_t_s_s(g_223, 9))
                    { /* block id: 1132 */
                        uint8_t *l_2356[8][4][8] = {{{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125}},{{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125}},{{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125}},{{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125}},{{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125}},{{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125}},{{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125}},{{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125},{&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125,&g_169.f8,&g_125}}};
                        int i, j, k;
                        l_2359 |= ((((safe_mul_func_int16_t_s_s(((((void*)0 != l_2319) <= (((*g_1000) = ((((safe_rshift_func_int8_t_s_s((&p_40 != (l_2350 = l_2330)), 2)) , (l_2351 , g_294[6])) <= (safe_sub_func_uint32_t_u_u((((safe_mul_func_int8_t_s_s(p_39, (l_2247[9] = p_39))) , ((p_37 & l_2357) , l_2247[0])) , (*l_2320)), (*g_757)))) || l_2250[1])) >= g_1010.f2)) , 4L), 0xE5E3L)) , &g_757) != l_2358) > (*l_2320));
                        if (l_2246[1][0])
                            continue;
                    }
                    return (*l_2320);
                }
                for (g_1877 = 11; (g_1877 >= (-21)); g_1877 = safe_sub_func_int32_t_s_s(g_1877, 2))
                { /* block id: 1143 */
                    uint32_t l_2381 = 0x54A1BF91L;
                    struct S2 *l_2387 = &g_2388;
                    struct S1 **l_2403 = (void*)0;
                    const uint8_t l_2421 = 0UL;
                    if (((*l_2333) = ((((g_1270.f2 , (safe_mul_func_int8_t_s_s(((safe_add_func_int64_t_s_s((safe_mod_func_int16_t_s_s((safe_sub_func_int64_t_s_s((safe_div_func_uint8_t_u_u((&p_37 == l_2372[0][0][1]), 0xE4L)), ((safe_add_func_int32_t_s_s(0x4524DB42L, (safe_sub_func_int64_t_s_s(((l_2377[0][0][0] , l_2378) == l_2379[5]), (((void*)0 != l_2380) , (*g_1000)))))) , 18446744073709551615UL))), 0xE996L)), (**g_999))) , 0xF9L), 0L))) || p_38) , 9UL) || (*g_1903))))
                    { /* block id: 1145 */
                        l_2381 = l_2247[4];
                        if (l_2271)
                            continue;
                        if (p_38)
                            continue;
                        if (l_2382)
                            break;
                    }
                    else
                    { /* block id: 1150 */
                        struct S0 l_2394 = {0x8EL,0x70L,-1L,0x00C254CBL,0L,0x02L,0xE605D80BA958DED5LL,0x04L,0xCDL};
                        struct S2 *l_2395 = &g_2396;
                        (*l_2331) = (safe_mul_func_int16_t_s_s(((l_2381 && (((safe_unary_minus_func_uint64_t_u((~((p_37 || (g_1071[2] = ((*g_525) = (p_40 & (l_2387 == (void*)0))))) <= l_2246[1][0])))) , (p_37 < (safe_sub_func_int16_t_s_s(((((safe_mul_func_uint8_t_u_u(l_2393, (l_2394 , l_2377[0][0][0]))) && 0xED3DL) , (void*)0) == l_2395), (-6L))))) > p_38)) && 0xE6L), p_39));
                        if ((*l_2331))
                            continue;
                        return p_40;
                    }
                    for (g_125 = 0; (g_125 <= 2); g_125 += 1)
                    { /* block id: 1159 */
                        int32_t l_2405 = (-1L);
                        int i, j;
                        l_2405 = (((l_2397[0] != (void*)0) <= (l_2398 != (((safe_rshift_func_int8_t_s_s((p_39 = ((*g_1903) |= l_2249)), ((((*l_2380) = (safe_div_func_uint8_t_u_u(((**l_2378) != l_2403), p_40))) | (((*g_525) > (!p_40)) >= 8L)) | p_38))) < l_2381) , l_2398))) , l_2381);
                        (*l_2333) ^= p_38;
                        return l_2246[2][0];
                    }
                    if ((((((-1L) >= ((*g_1000) = (+((safe_lshift_func_uint16_t_u_u(((safe_lshift_func_uint16_t_u_s((~(((safe_sub_func_int8_t_s_s(((*g_757) || l_2246[4][1]), ((((*l_2319) , ((safe_div_func_int8_t_s_s(((safe_mul_func_uint16_t_u_u(l_2271, 0x63BAL)) && g_2418[0][3]), (safe_add_func_int8_t_s_s(((p_38 , l_2246[0][1]) && 1L), p_37)))) != (*l_2320))) != (**g_756)) && 1UL))) != 0x0DL) < (-1L))), l_2247[0])) || l_2247[0]), (*g_525))) , l_2393)))) ^ p_37) != l_2421) || p_40))
                    { /* block id: 1168 */
                        return p_39;
                    }
                    else
                    { /* block id: 1170 */
                        uint64_t l_2424 = 0x9EFBEED16EEA332CLL;
                        (*l_2333) = (0xE30B3DCFL > (safe_sub_func_int8_t_s_s(l_2424, (*g_1903))));
                    }
                }
                if ((((*l_2333) || 0UL) , (safe_div_func_uint64_t_u_u(((((*l_2429) ^= (safe_rshift_func_int16_t_s_u(l_2247[3], 2))) <= (p_40 & (-9L))) < (l_2271 = ((safe_lshift_func_int16_t_s_u((safe_lshift_func_int8_t_s_u(0x18L, p_38)), (*g_525))) , ((*l_2333) <= (*l_2320))))), p_39))))
                { /* block id: 1176 */
                    uint16_t * const *l_2434 = (void*)0;
                    (*l_2320) &= ((l_2434 != l_2435) >= ((void*)0 == l_2436));
                }
                else
                { /* block id: 1178 */
                    uint64_t l_2439 = 18446744073709551615UL;
                    union U3 l_2454[4][8][6] = {{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}}};
                    int8_t l_2461 = 0xBBL;
                    int32_t ****l_2464 = &g_1989[1][5][0];
                    int32_t *****l_2463 = &l_2464;
                    union U3 ****l_2467 = &g_767;
                    int i, j, k;
                    for (g_1831 = 2; (g_1831 >= 0); g_1831 -= 1)
                    { /* block id: 1181 */
                        int32_t *l_2437 = &l_2219;
                        l_2438[1][0] = l_2437;
                        l_2439--;
                        (***g_1574) = l_2327;
                    }
                    for (p_37 = 8; (p_37 >= 1); p_37 -= 1)
                    { /* block id: 1188 */
                        uint64_t l_2453 = 0xDCEDC0E328235152LL;
                        uint16_t **l_2456 = (void*)0;
                        int32_t l_2465 = 0x19E56B09L;
                        int i, j;
                        (*l_2333) &= (safe_mod_func_uint16_t_u_u(((l_2444 != (void*)0) & 247UL), (~(-7L))));
                        (*l_2331) |= (safe_mul_func_uint8_t_u_u(((*g_525) != ((*g_525) >= l_2439)), ((((*g_833) = p_39) , (*l_2320)) , (l_2450 , ((*g_1903) = (((safe_unary_minus_func_int32_t_s((+((**g_1489) , (l_2249 , 0xA586L))))) == p_38) == l_2453))))));
                        l_2465 |= ((((((l_2454[3][7][3] , ((((((((l_2455 , ((l_2456 != (void*)0) == (*g_757))) & ((((*l_2330) |= (p_39 = ((l_2457 , (p_39 && (safe_mod_func_int32_t_s_s((((*l_2380) = ((void*)0 != l_2460)) , (*l_2320)), (*g_757))))) || p_38))) , (*g_525)) && 4UL)) && l_2461) , l_2462) , p_40) , (*g_2127)) == (*g_1575)) ^ (*g_1903))) , (void*)0) != l_2463) == (**g_999)) > (**g_756)) | (*l_2332));
                        (*l_2333) |= (l_2466 == l_2467);
                    }
                }
            }
            l_2337 = (((safe_sub_func_uint32_t_u_u(((l_2488 |= (4294967295UL && (!((l_2247[0] &= (l_2471 == l_2472)) , (safe_lshift_func_int8_t_s_s(((l_2487[0][0] = ((safe_add_func_int8_t_s_s((p_38 , (((((p_38 > ((*l_2320) = ((*g_1000) = (-8L)))) | ((safe_mod_func_int64_t_s_s((+((*l_2486) = (safe_div_func_uint16_t_u_u((l_2482 , (*g_525)), (safe_sub_func_int64_t_s_s((safe_unary_minus_func_uint32_t_u(p_40)), p_39)))))), 1UL)) && p_39)) >= g_5) && g_313[0][1]) , 0xC6L)), 0xBFL)) , p_39)) & p_39), (*g_1903))))))) >= l_2489), 1UL)) < 0x44L) | p_40);
        }
        (**l_2472) = (**l_2471);
        (*l_2398) = &g_1000;
    }
    return (*l_2320);
}


/* ------------------------------------------ */
/* 
 * reads : g_169.f5
 * writes: g_169.f5
 */
static uint8_t  func_41(int8_t * p_42)
{ /* block id: 855 */
    struct S2 *l_1817 = &g_1818;
    struct S2 **l_1819 = &l_1817;
    int32_t l_1820 = (-5L);
    int32_t l_1828 = 0x4CD0EE8EL;
    int32_t l_1829 = (-5L);
    int32_t l_1830[7][6] = {{3L,1L,1L,3L,0x80738261L,0xAB94CC39L},{1L,2L,0x12E7999BL,0xAB94CC39L,0x712A8CB6L,(-4L)},{0x712A8CB6L,0x80738261L,0x75760DE6L,0x80738261L,0x712A8CB6L,0x80C1D529L},{(-4L),2L,0xDF8977BDL,0xEC00808DL,0x80738261L,0x12E7999BL},{0x12E7999BL,1L,2L,2L,1L,0x12E7999BL},{0xEC00808DL,0xAB94CC39L,0xDF8977BDL,0x712A8CB6L,0x12E7999BL,0x80C1D529L},{1L,(-4L),0x75760DE6L,0x12E7999BL,0x75760DE6L,(-4L)}};
    int16_t l_1832[2];
    uint16_t l_1834 = 1UL;
    int32_t *** const l_1851 = &g_78;
    int32_t *** const *l_1850[9][9] = {{(void*)0,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851},{&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851},{&l_1851,&l_1851,&l_1851,&l_1851,(void*)0,&l_1851,&l_1851,&l_1851,&l_1851},{&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,(void*)0,&l_1851,&l_1851,&l_1851},{(void*)0,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851},{&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851},{&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,(void*)0,&l_1851,(void*)0,&l_1851},{&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,(void*)0,&l_1851,&l_1851},{&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851,&l_1851}};
    int32_t *** const * const *l_1849 = &l_1850[0][8];
    uint8_t l_1874 = 255UL;
    const union U3 *l_1890[7][1][3] = {{{(void*)0,&g_310,&g_1491}},{{(void*)0,(void*)0,&g_310}},{{&g_310,&g_310,&g_310}},{{&g_310,&g_1491,&g_1491}},{{&g_310,&g_1491,&g_310}},{{(void*)0,&g_310,&g_1491}},{{(void*)0,(void*)0,&g_310}}};
    int64_t **l_1896 = &g_1000;
    int8_t l_1913[3];
    const struct S1 * const l_1972 = &g_1973;
    const struct S1 * const *l_1971 = &l_1972;
    struct S0 l_2032 = {0xD6L,0xB7L,-5L,1L,0x94104779L,0xFEL,0xADB902ED9ACA4354LL,0xD2L,251UL};
    int32_t l_2062 = 0x85BEE4BDL;
    struct S1 ****l_2106 = &g_1142;
    union U3 *** const **l_2126 = (void*)0;
    union U3 * const ****l_2131[9];
    int16_t l_2184 = 0x0383L;
    int16_t l_2197[9][10][2] = {{{0L,0L},{(-4L),0L},{(-4L),0L},{0L,1L},{0L,0xB402L},{3L,8L},{0x260BL,(-1L)},{(-1L),0x3972L},{0x8307L,0L},{(-1L),0x260BL}},{{0x1098L,8L},{0x3972L,(-1L)},{3L,0xD975L},{1L,0L},{1L,2L},{(-1L),0L},{0xB402L,1L},{1L,0L},{2L,(-4L)},{3L,(-1L)}},{{0xBE76L,0x1098L},{8L,0L},{0xD975L,0L},{8L,0xBE76L},{0L,1L},{0L,0x8307L},{3L,0x8307L},{0L,1L},{0L,0xBE76L},{8L,0L}},{{0xD975L,0L},{8L,0x1098L},{0xBE76L,(-1L)},{3L,(-4L)},{2L,0L},{1L,1L},{0xB402L,0L},{(-1L),2L},{1L,0L},{1L,0xD975L}},{{3L,(-1L)},{0x3972L,8L},{0x1098L,0x260BL},{(-1L),0L},{0x8307L,0x3972L},{(-1L),(-1L)},{0x260BL,8L},{3L,0xB402L},{0L,1L},{0L,0x2B72L}},{{2L,2L},{2L,0x2B72L},{0L,0x385CL},{0x2B72L,0x3972L},{0L,0xBE76L},{0L,(-7L)},{(-7L),3L},{0x260BL,2L},{1L,0L},{0xE0D3L,0x89D8L}},{{3L,1L},{0L,0L},{3L,0L},{0x385CL,0L},{0L,2L},{0x3972L,3L},{0x703AL,0L},{0L,2L},{0L,0L},{(-1L),0xE0D3L}},{{0x89D8L,0L},{0L,2L},{0xBE76L,(-1L)},{0L,0x703AL},{0L,0x260BL},{0L,0x260BL},{0L,0x703AL},{0L,(-1L)},{0xBE76L,2L},{0L,0L}},{{0x89D8L,0xE0D3L},{(-1L),0L},{0L,2L},{0L,0L},{0x703AL,3L},{0x3972L,2L},{0L,0L},{0x385CL,0L},{3L,0L},{0L,1L}}};
    int64_t l_2202 = 1L;
    uint64_t l_2203 = 18446744073709551615UL;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1832[i] = 0x15C4L;
    for (i = 0; i < 3; i++)
        l_1913[i] = 0L;
    for (i = 0; i < 9; i++)
        l_2131[i] = &g_2128;
    (*l_1819) = l_1817;
    for (g_169.f5 = 6; (g_169.f5 >= 0); g_169.f5 -= 1)
    { /* block id: 859 */
        int32_t *l_1821 = &g_45;
        int32_t *l_1822 = &l_1820;
        int32_t *l_1823 = &g_69;
        int32_t l_1824[6][3][6] = {{{1L,0xA1F593C5L,0xA1F593C5L,1L,0x962223B7L,7L},{0x91EB735FL,7L,0L,0x72D5E635L,0L,(-4L)},{0xA8D9F2C6L,1L,0x962223B7L,9L,0L,0x8AE14F11L}},{{1L,7L,(-1L),0xA8D9F2C6L,0x962223B7L,(-1L)},{0x359BD8AAL,0xA1F593C5L,0x549A5DACL,0xA8D9F2C6L,7L,1L},{1L,0x549A5DACL,0x8AE14F11L,9L,0x8AE14F11L,0x549A5DACL}},{{0xA8D9F2C6L,0L,0x8AE14F11L,0x72D5E635L,0xA1F593C5L,1L},{0x91EB735FL,(-4L),0x549A5DACL,1L,(-4L),(-1L)},{1L,(-4L),(-1L),0x5ED3932AL,0xA1F593C5L,0x8AE14F11L}},{{0xC69F5899L,0L,0x962223B7L,1L,0x8AE14F11L,(-4L)},{0xC69F5899L,0x549A5DACL,0L,0x5ED3932AL,7L,7L},{1L,0xA1F593C5L,0xA1F593C5L,1L,0x962223B7L,7L}},{{0x91EB735FL,7L,0L,0x72D5E635L,0L,(-4L)},{0xA8D9F2C6L,1L,0x962223B7L,9L,0L,0x8AE14F11L},{1L,7L,(-1L),0xA8D9F2C6L,0x962223B7L,(-1L)}},{{0x359BD8AAL,0xA1F593C5L,0x549A5DACL,0xA8D9F2C6L,7L,1L},{1L,0x549A5DACL,0x8AE14F11L,9L,0x8AE14F11L,0x549A5DACL},{0xA8D9F2C6L,0L,0x8AE14F11L,0x72D5E635L,0xA1F593C5L,1L}}};
        int32_t *l_1825 = &g_1450[1][0][0];
        int32_t *l_1826 = &g_45;
        int32_t *l_1827[7] = {&g_315[1],&g_315[1],&g_315[1],&g_315[1],&g_315[1],&g_315[1],&g_315[1]};
        int8_t l_1833 = (-2L);
        uint8_t l_1846 = 255UL;
        int64_t l_1872 = 0x2704CD782255C6B0LL;
        int64_t **l_1895 = &g_1000;
        int32_t l_1926 = (-1L);
        int32_t l_1927 = 0x99CB9CEBL;
        int8_t **l_1966[6] = {&g_1903,&g_1903,&g_1903,&g_1903,&g_1903,&g_1903};
        union U3 l_1969 = {0};
        uint32_t l_1974 = 0x0103624AL;
        struct S0 l_1996 = {0xE8L,4L,3L,-4L,0x93E52E98L,7L,0xEA7C6D6B7A567F5FLL,9UL,3UL};
        int32_t ***l_2002 = (void*)0;
        int64_t l_2004 = 1L;
        const int16_t *l_2007 = &g_970;
        const int16_t **l_2006 = &l_2007;
        uint16_t l_2011 = 0x491AL;
        struct S2 **l_2027[5];
        struct S0 l_2081 = {0UL,0x73L,0x08090F0A78AF1776LL,0xCDEE4A86L,0x97D14653L,-1L,0UL,0xC9L,0x96L};
        const uint16_t l_2105 = 8UL;
        int32_t l_2185[8][5] = {{0L,0L,1L,0xACA42F98L,0xACA42F98L},{0L,0L,0L,1L,0xACA42F98L},{0L,0x0DB80E53L,0xACA42F98L,0x0DB80E53L,0L},{0L,0x0DB80E53L,0L,0L,0L},{0L,0L,0xACA42F98L,0L,1L},{0x0DB80E53L,0L,0L,0x0DB80E53L,0L},{0x0DB80E53L,0L,1L,1L,0L},{0L,0L,1L,0xACA42F98L,0xACA42F98L}};
        int i, j, k;
        for (i = 0; i < 5; i++)
            l_2027[i] = (void*)0;
        ++l_1834;
    }
    return l_2203;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int8_t * func_43(int8_t * p_44)
{ /* block id: 13 */
    uint32_t l_50 = 0UL;
    int32_t *l_68 = &g_69;
    int32_t *l_75 = &g_8;
    int32_t **l_74 = &l_75;
    int32_t l_83 = 0xB496A2A5L;
    int32_t l_1629 = 0xB5CCF482L;
    int16_t *l_1773 = &g_360;
    struct S2 **l_1774 = (void*)0;
    const int32_t *l_1777[6];
    uint32_t **l_1786 = &g_833;
    int32_t l_1792 = 0xFA4DCA58L;
    int8_t *l_1816 = &g_136[1];
    int i;
    for (i = 0; i < 6; i++)
        l_1777[i] = &g_45;
    return l_1816;
}


/* ------------------------------------------ */
/* 
 * reads : g_835 g_1000 g_757 g_123 g_542 g_1007.f3 g_1017.f4 g_525 g_223 g_767 g_756 g_1017.f8 g_78 g_188 g_169.f0 g_315 g_69 g_45 g_1148 g_8 g_12 g_935 g_1490 g_1491 g_999 g_670
 * writes: g_188 g_542 g_672 g_123 g_169.f0 g_315 g_69 g_1142 g_935 g_670 g_1573 g_1575 g_1450 g_1008.f4
 */
static uint16_t  func_55(int32_t * p_56, uint16_t  p_57)
{ /* block id: 473 */
    const int16_t *l_1100 = &g_185;
    const int16_t **l_1101 = &l_1100;
    int16_t *l_1102[10] = {&g_360,&g_360,&g_360,&g_360,&g_360,&g_360,&g_360,&g_360,&g_360,&g_360};
    uint32_t *l_1107 = &g_94;
    uint8_t *l_1120 = &g_1017[0].f7;
    int32_t l_1121 = 0x81424CD2L;
    uint16_t l_1122 = 65532UL;
    uint64_t *l_1123 = &g_542;
    struct S1 *l_1139 = &g_1140;
    struct S1 **l_1138[6] = {&l_1139,&l_1139,&l_1139,&l_1139,&l_1139,&l_1139};
    struct S1 ***l_1137 = &l_1138[2];
    int32_t l_1171 = 1L;
    int32_t l_1172 = 0x598F4662L;
    int32_t l_1174 = 0x9980BE06L;
    int32_t l_1175 = 0xE4F24ED5L;
    struct S0 l_1201 = {1UL,1L,0x27294AC62F84FF71LL,0x36BF8000L,7L,0xCCL,18446744073709551611UL,0x97L,0xA6L};
    uint32_t l_1211 = 0xA408D3A6L;
    int8_t l_1222 = (-1L);
    uint32_t **l_1235 = &g_757;
    struct S0 **l_1248 = (void*)0;
    int32_t l_1257 = 0xBE3AF405L;
    int32_t l_1258[8];
    int64_t l_1260[9] = {0xAAB4D1ABF7D69A5DLL,0xAAB4D1ABF7D69A5DLL,0xAAB4D1ABF7D69A5DLL,0xAAB4D1ABF7D69A5DLL,0xAAB4D1ABF7D69A5DLL,0xAAB4D1ABF7D69A5DLL,0xAAB4D1ABF7D69A5DLL,0xAAB4D1ABF7D69A5DLL,0xAAB4D1ABF7D69A5DLL};
    int32_t ***l_1288[8] = {&g_78,&g_78,&g_78,&g_78,&g_78,&g_78,&g_78,&g_78};
    int32_t ****l_1287[8][8] = {{&l_1288[2],&l_1288[2],(void*)0,&l_1288[2],&l_1288[2],&l_1288[2],&l_1288[2],(void*)0},{&l_1288[2],&l_1288[2],&l_1288[2],(void*)0,&l_1288[2],&l_1288[2],&l_1288[2],&l_1288[2]},{&l_1288[2],&l_1288[2],&l_1288[2],&l_1288[2],(void*)0,&l_1288[2],&l_1288[2],&l_1288[2]},{&l_1288[2],(void*)0,(void*)0,(void*)0,(void*)0,&l_1288[2],(void*)0,(void*)0},{&l_1288[2],(void*)0,&l_1288[2],&l_1288[2],&l_1288[2],&l_1288[2],(void*)0,&l_1288[2]},{&l_1288[2],&l_1288[2],(void*)0,&l_1288[2],&l_1288[2],&l_1288[2],&l_1288[2],(void*)0},{&l_1288[2],&l_1288[2],&l_1288[2],(void*)0,&l_1288[2],&l_1288[2],&l_1288[2],&l_1288[2]},{&l_1288[2],&l_1288[2],&l_1288[2],&l_1288[2],(void*)0,&l_1288[2],&l_1288[2],&l_1288[2]}};
    int32_t **** const *l_1286[9][9] = {{(void*)0,&l_1287[0][0],&l_1287[7][0],(void*)0,&l_1287[2][2],&l_1287[2][2],(void*)0,&l_1287[7][0],&l_1287[0][0]},{(void*)0,&l_1287[0][0],&l_1287[7][0],(void*)0,&l_1287[2][2],&l_1287[2][2],(void*)0,&l_1287[7][0],&l_1287[0][0]},{(void*)0,&l_1287[0][0],&l_1287[7][0],(void*)0,&l_1287[2][2],&l_1287[2][2],(void*)0,&l_1287[7][0],&l_1287[0][0]},{(void*)0,&l_1287[0][0],&l_1287[7][0],(void*)0,&l_1287[2][2],&l_1287[2][2],(void*)0,&l_1287[7][0],&l_1287[0][0]},{(void*)0,&l_1287[0][0],&l_1287[7][0],(void*)0,&l_1287[2][2],&l_1287[2][2],&l_1287[2][2],(void*)0,&l_1287[2][2]},{&l_1287[2][2],&l_1287[2][2],(void*)0,&l_1287[2][2],&l_1287[2][2],&l_1287[2][2],&l_1287[2][2],(void*)0,&l_1287[2][2]},{&l_1287[2][2],&l_1287[2][2],(void*)0,&l_1287[2][2],&l_1287[2][2],&l_1287[2][2],&l_1287[2][2],(void*)0,&l_1287[2][2]},{&l_1287[2][2],&l_1287[2][2],(void*)0,&l_1287[2][2],&l_1287[2][2],&l_1287[2][2],&l_1287[2][2],(void*)0,&l_1287[2][2]},{&l_1287[2][2],&l_1287[2][2],(void*)0,&l_1287[2][2],&l_1287[2][2],&l_1287[2][2],&l_1287[2][2],(void*)0,&l_1287[2][2]}};
    int32_t *l_1289 = &l_1121;
    uint64_t l_1310 = 0xCA3E286846069545LL;
    int32_t l_1419[10] = {0xB7B4F4BFL,0xEA163780L,0xEA163780L,0xB7B4F4BFL,0xEA163780L,0xEA163780L,0xB7B4F4BFL,0xEA163780L,0xEA163780L,0xB7B4F4BFL};
    int64_t **l_1426[8] = {&g_1000,&g_1000,&g_1000,&g_1000,&g_1000,&g_1000,&g_1000,&g_1000};
    int8_t *l_1471 = &g_5;
    int8_t **l_1470 = &l_1471;
    int16_t l_1472 = (-4L);
    struct S2 *l_1506 = &g_1507;
    struct S2 **l_1505 = &l_1506;
    uint32_t l_1526 = 3UL;
    const int16_t l_1549 = 0x5DB7L;
    int i, j;
    for (i = 0; i < 8; i++)
        l_1258[i] = 0x7A9E1B8FL;
    if (((((((*g_1000) = (safe_add_func_uint32_t_u_u(((~p_57) & (safe_add_func_uint64_t_u_u((((*l_1101) = l_1100) == (l_1102[1] = l_1102[1])), ((void*)0 == &g_169)))), (safe_rshift_func_int16_t_s_u(g_835, 15))))) , (((safe_lshift_func_uint16_t_u_u((l_1107 != p_56), 14)) && (safe_rshift_func_int8_t_s_s((((*l_1123) |= ((safe_rshift_func_int16_t_s_u((safe_div_func_uint64_t_u_u((safe_add_func_int8_t_s_s(((!(+(safe_mod_func_int16_t_s_s((((l_1120 == (void*)0) ^ 0xCD24L) <= l_1121), p_57)))) , 0xEAL), l_1122)), l_1121)), 6)) != (*g_757))) > p_57), 1))) & g_1007.f3)) & g_1017[0].f4) , (*g_525)) | 0L))
    { /* block id: 478 */
        union U3 l_1131 = {0};
        union U3 **l_1132 = &g_673;
        const uint32_t *l_1133 = (void*)0;
        (*g_767) = (void*)0;
        l_1121 = (safe_lshift_func_int8_t_s_s((((safe_lshift_func_uint8_t_u_s((safe_add_func_uint32_t_u_u(((**g_756) && ((**g_756) = (~(p_56 != (l_1131 , l_1133))))), p_57)), p_57)) ^ g_1017[0].f8) , 0x75L), 0));
    }
    else
    { /* block id: 482 */
        const int32_t *l_1134 = (void*)0;
        (*g_78) = p_56;
        for (g_188 = 0; (g_188 <= 1); g_188 += 1)
        { /* block id: 486 */
            const int32_t *l_1135 = &l_1121;
            l_1135 = l_1134;
            for (g_169.f0 = 0; (g_169.f0 <= 1); g_169.f0 += 1)
            { /* block id: 490 */
                int32_t *l_1136 = &g_69;
                struct S1 ****l_1141[8] = {&l_1137,&l_1137,&l_1137,&l_1137,&l_1137,&l_1137,&l_1137,&l_1137};
                int i;
                (*l_1136) |= (g_315[g_188] ^= ((void*)0 == &l_1107));
                l_1137 = (g_1142 = l_1137);
                return p_57;
            }
        }
    }
    if ((g_45 && (((safe_mul_func_uint8_t_u_u((0x53C7440FL && g_1148), (safe_lshift_func_uint16_t_u_u((((safe_mod_func_int32_t_s_s((safe_sub_func_uint32_t_u_u(1UL, (**g_78))), l_1121)) || (((void*)0 == &g_756) || (*p_56))) ^ 18446744073709551608UL), 5)))) & l_1122) && (*p_56))))
    { /* block id: 499 */
        return p_57;
    }
    else
    { /* block id: 501 */
        int16_t l_1162 = 0x420FL;
        int32_t l_1166 = 0x388879F1L;
        int32_t l_1169 = (-1L);
        int32_t l_1170 = 0x752CC63CL;
        int32_t l_1173 = 1L;
        uint16_t l_1176[8] = {4UL,4UL,0x63DFL,4UL,4UL,0x63DFL,4UL,4UL};
        uint32_t l_1213 = 0x1ED8457BL;
        uint64_t l_1214 = 3UL;
        uint64_t l_1218[2];
        uint16_t l_1249 = 0xB933L;
        int64_t l_1306 = (-1L);
        int32_t l_1309 = 0x34180052L;
        uint16_t l_1345 = 0xB581L;
        int32_t l_1375 = 0x21420698L;
        int32_t l_1377 = 0L;
        int32_t l_1386 = (-5L);
        int32_t l_1387 = (-9L);
        uint8_t l_1442 = 0x71L;
        const union U3 *l_1485 = (void*)0;
        const union U3 **l_1484 = &l_1485;
        const union U3 ***l_1483[3];
        const union U3 ****l_1482[10] = {&l_1483[2],&l_1483[2],&l_1483[2],&l_1483[2],&l_1483[2],&l_1483[2],&l_1483[2],&l_1483[2],&l_1483[2],&l_1483[2]};
        int64_t l_1567 = 0x6CF5A948EE05AD3FLL;
        int32_t *l_1587 = &l_1173;
        uint64_t l_1623 = 0x041769512F0EA6C0LL;
        int8_t *l_1624 = &l_1201.f5;
        int i;
        for (i = 0; i < 2; i++)
            l_1218[i] = 0x7D92940432A000EFLL;
        for (i = 0; i < 3; i++)
            l_1483[i] = &l_1484;
        for (g_935 = 29; (g_935 > (-8)); g_935 = safe_sub_func_uint8_t_u_u(g_935, 1))
        { /* block id: 504 */
            int32_t l_1157 = (-6L);
            int32_t *l_1158 = (void*)0;
            int32_t *l_1159 = (void*)0;
            int32_t *l_1160 = &l_1157;
            int32_t *l_1161 = &l_1121;
            int32_t *l_1163 = &l_1157;
            int32_t *l_1164 = (void*)0;
            int32_t *l_1165 = (void*)0;
            int32_t l_1167 = 1L;
            int32_t *l_1168[7][7][2] = {{{&g_315[1],&l_1121},{&l_1157,&g_8},{&l_1166,&l_1157},{(void*)0,&g_315[1]},{&g_8,&g_315[1]},{(void*)0,&l_1157},{&l_1166,&g_8}},{{&l_1157,&l_1121},{&g_315[1],&l_1166},{&g_69,(void*)0},{&g_315[0],&g_315[0]},{&g_45,&l_1166},{&l_1167,(void*)0},{&l_1121,&g_315[1]}},{{&l_1166,&l_1121},{&l_1121,&l_1167},{&l_1121,&l_1121},{&l_1166,&g_315[1]},{&l_1121,(void*)0},{&l_1167,&l_1166},{&g_45,&g_315[0]}},{{&g_315[0],(void*)0},{&g_69,&l_1166},{&g_315[1],&l_1121},{&l_1157,&g_8},{&l_1166,&l_1157},{(void*)0,&g_315[1]},{&g_8,&g_315[1]}},{{(void*)0,&l_1157},{&l_1166,&g_8},{&l_1157,&l_1121},{&g_315[1],&l_1166},{&g_69,(void*)0},{&g_315[0],&g_315[0]},{&g_45,&l_1166}},{{&l_1167,(void*)0},{&l_1121,&g_315[1]},{&l_1166,&l_1121},{&l_1121,&l_1167},{&l_1121,&l_1121},{&l_1166,&g_315[1]},{&l_1121,(void*)0}},{{&l_1167,&l_1166},{&g_45,&g_315[0]},{&g_315[0],(void*)0},{&g_69,&l_1166},{&g_315[1],&l_1121},{&l_1157,&g_8},{&l_1166,&l_1157}}};
            int64_t l_1186 = 1L;
            int16_t l_1191 = 0x2247L;
            union U3 ***l_1208 = (void*)0;
            int32_t l_1217 = 5L;
            int16_t l_1225 = 1L;
            uint32_t l_1245 = 0x4BB5332FL;
            int16_t **l_1361[4] = {&l_1102[4],&l_1102[4],&l_1102[4],&l_1102[4]};
            int32_t l_1373 = (-1L);
            uint64_t l_1389 = 0UL;
            uint16_t l_1432 = 65527UL;
            int32_t *l_1504 = &l_1172;
            int i, j, k;
            ++l_1176[0];
        }
        (*l_1289) ^= (safe_mul_func_int8_t_s_s(((((safe_add_func_uint8_t_u_u(p_57, l_1549)) | ((safe_sub_func_int16_t_s_s((safe_mul_func_int8_t_s_s(0x66L, p_57)), (((p_57 & ((*g_1490) , ((*g_1000) = (safe_sub_func_int32_t_s_s(((l_1345 | ((safe_mul_func_uint8_t_u_u((((**g_756) == l_1375) | 4294967287UL), p_57)) <= (**g_999))) , (*p_56)), l_1169))))) ^ p_57) , (*g_525)))) < 0L)) ^ 0x46A3DF46L) | (-4L)), l_1162));
        for (g_670 = (-28); (g_670 < 29); g_670++)
        { /* block id: 690 */
            uint16_t l_1584[10][2][7] = {{{5UL,5UL,5UL,5UL,0UL,5UL,5UL},{65535UL,65535UL,65533UL,3UL,65533UL,65535UL,65535UL}},{{5UL,5UL,0UL,5UL,5UL,5UL,5UL},{0xE805L,1UL,0xE805L,65533UL,65533UL,0xE805L,1UL}},{{5UL,0x2C36L,0UL,0UL,0x2C36L,5UL,0x2C36L},{0xE805L,65533UL,65533UL,0xE805L,1UL,0xE805L,65533UL}},{{5UL,5UL,5UL,0UL,5UL,5UL,5UL},{65535UL,65533UL,3UL,65533UL,65535UL,65535UL,65533UL}},{{1UL,0x2C36L,1UL,5UL,5UL,1UL,0x2C36L},{65533UL,1UL,3UL,3UL,1UL,65533UL,1UL}},{{1UL,5UL,5UL,1UL,0x2C36L,1UL,5UL},{65535UL,65535UL,65533UL,3UL,65533UL,65535UL,65535UL}},{{5UL,5UL,0UL,5UL,5UL,5UL,5UL},{0xE805L,1UL,0xE805L,65533UL,65533UL,0xE805L,1UL}},{{5UL,0x2C36L,0UL,0UL,0x2C36L,5UL,0x2C36L},{0xE805L,65533UL,65533UL,0xE805L,1UL,0xE805L,65533UL}},{{5UL,5UL,5UL,0UL,5UL,5UL,5UL},{65535UL,65533UL,3UL,65533UL,65535UL,65535UL,65533UL}},{{1UL,0x2C36L,1UL,5UL,5UL,1UL,0x2C36L},{65533UL,1UL,3UL,3UL,1UL,65533UL,1UL}}};
            union U3 *l_1592[10] = {&g_1069,(void*)0,&g_1069,&g_1069,(void*)0,&g_1069,&g_1069,(void*)0,&g_1069,&g_1069};
            int32_t l_1603 = 0x7178F276L;
            int i, j, k;
            (*l_1289) = (safe_lshift_func_uint8_t_u_u(0x1BL, 7));
            for (g_542 = 0; (g_542 != 16); g_542 = safe_add_func_uint16_t_u_u(g_542, 8))
            { /* block id: 694 */
                int32_t l_1570 = 0x9598532FL;
                union U3 ****l_1572 = (void*)0;
                union U3 *****l_1571 = &l_1572;
                int32_t l_1583 = (-7L);
                union U3 *l_1591 = &g_1069;
                uint16_t l_1601 = 65527UL;
                int32_t l_1602 = 1L;
                int32_t l_1605 = 0xFC405F68L;
                uint32_t l_1606[2][1][6];
                int i, j, k;
                for (i = 0; i < 2; i++)
                {
                    for (j = 0; j < 1; j++)
                    {
                        for (k = 0; k < 6; k++)
                            l_1606[i][j][k] = 0x388C887EL;
                    }
                }
                g_1450[1][0][0] = (~(((((l_1567 >= (*g_525)) || (safe_mul_func_int16_t_s_s(l_1306, ((*l_1289) = l_1570)))) | (((*g_757) = 0xCF905907L) >= (((((*g_1000) = (**g_999)) == ((g_1575 = (g_1573 = l_1571)) == &l_1482[5])) | (((safe_rshift_func_int8_t_s_u((safe_div_func_int64_t_s_s(((+(safe_div_func_int16_t_s_s(p_57, l_1583))) | l_1584[5][0][2]), l_1584[2][1][6])), p_57)) , (*g_525)) == l_1386)) >= l_1584[5][0][2]))) , (**g_756)) | l_1387));
                for (g_123 = 16; (g_123 < 54); g_123 = safe_add_func_uint8_t_u_u(g_123, 8))
                { /* block id: 703 */
                    uint16_t l_1588 = 9UL;
                    union U3 l_1600 = {0};
                    int32_t l_1604 = (-1L);
                    l_1587 = p_56;
                    l_1588 ^= (*p_56);
                    for (l_1169 = 26; (l_1169 == 3); --l_1169)
                    { /* block id: 708 */
                        (*l_1484) = (l_1592[2] = l_1591);
                        l_1603 = (((l_1601 = (safe_rshift_func_uint8_t_u_s(p_57, ((!(-1L)) <= (((((safe_mul_func_int32_t_s_s((safe_mul_func_uint16_t_u_u((*l_1587), p_57)), ((*l_1289) = (l_1600 , ((l_1588 && (&g_1226 != (void*)0)) != 255UL))))) < 0L) < 0xBBB9ADB6L) , 0xA873DBE2L) >= 0xABDBC74EL))))) , l_1602) == p_57);
                        return (*g_525);
                    }
                    --l_1606[1][0][2];
                }
                if (l_1584[5][0][2])
                    continue;
            }
            return p_57;
        }
        g_1008.f4 = (((((*l_1624) = (p_57 || (safe_lshift_func_uint8_t_u_u(((safe_add_func_int64_t_s_s((safe_mod_func_uint64_t_u_u((safe_mul_func_int8_t_s_s((((*l_1587) = (*p_56)) && ((**g_756) = (((safe_add_func_int16_t_s_s((*l_1587), (*l_1587))) , (((safe_rshift_func_int8_t_s_u(((**g_78) > 9L), 3)) , (((*l_1587) != (safe_div_func_uint8_t_u_u(((*p_56) | ((*l_1289) = (p_57 == 0x4E6FL))), g_935))) & 4294967295UL)) ^ 7L)) | 255UL))), p_57)), (*g_1000))), p_57)) , 0x17L), l_1623)))) , l_1624) == l_1624) == p_57);
    }
    (*g_78) = p_56;
    (*l_1289) = (p_57 ^ (*l_1289));
    return p_57;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_69 g_94 g_78 g_5 g_123 g_12 g_125 g_136 g_169 g_182 g_186 g_45 g_223 g_188 g_185 g_294 g_310 g_313 g_999 g_1000 g_315 g_79
 * writes: g_69 g_94 g_123 g_185 g_188 g_169.f3 g_193 g_223 g_136 g_186 g_169.f0 g_360 g_169.f8 g_169.f6 g_1017.f5 g_169.f5 g_79
 */
static int32_t * func_58(const uint64_t  p_59, int16_t  p_60, int32_t  p_61, int32_t * p_62)
{ /* block id: 20 */
    int32_t *** const l_101 = &g_78;
    int32_t l_126 = (-10L);
    int32_t l_128[7][5] = {{0xEDE604A3L,0x47586045L,0x3A7FA890L,0xEDE604A3L,0x5A8EECE7L},{0x6915C511L,0x47586045L,0x64B9282FL,0x6915C511L,0x5A8EECE7L},{0xEDE604A3L,0x64B9282FL,0x64B9282FL,0xEDE604A3L,0L},{0xEDE604A3L,0x47586045L,0x3A7FA890L,0xEDE604A3L,0x5A8EECE7L},{0x6915C511L,0x47586045L,0x64B9282FL,0x6915C511L,0x5A8EECE7L},{0xEDE604A3L,0x64B9282FL,0x64B9282FL,0xEDE604A3L,0L},{0xEDE604A3L,0x47586045L,0x3A7FA890L,0xEDE604A3L,0x5A8EECE7L}};
    const int32_t *l_139 = &g_12;
    const int32_t * const *l_138[9] = {&l_139,&l_139,&l_139,&l_139,&l_139,&l_139,&l_139,&l_139,&l_139};
    uint8_t l_141 = 249UL;
    int32_t ***l_179 = &g_78;
    int32_t ****l_178[1][9][2] = {{{(void*)0,&l_179},{&l_179,&l_179},{(void*)0,(void*)0},{(void*)0,&l_179},{&l_179,&l_179},{&l_179,(void*)0},{(void*)0,(void*)0},{&l_179,&l_179},{&l_179,&l_179}}};
    int64_t *l_309 = (void*)0;
    const int32_t **l_456 = &l_139;
    const int32_t *** const l_455 = &l_456;
    const int32_t *** const *l_454 = &l_455;
    const int32_t *** const **l_453 = &l_454;
    int8_t l_498 = (-2L);
    const uint16_t *l_526 = &g_223;
    int8_t l_550 = 1L;
    union U3 l_566 = {0};
    const struct S0 l_577 = {0xF8L,-9L,1L,0xB55CEB61L,4L,0x19L,0x7B4863C9E36545A4LL,5UL,255UL};
    struct S2 *l_754 = (void*)0;
    int64_t *l_827 = &g_188;
    uint32_t l_849 = 0x459018B8L;
    int8_t l_880 = (-1L);
    int16_t l_903 = 0x6EE5L;
    int8_t l_963 = 0x2BL;
    int8_t l_983 = 0x5CL;
    uint32_t **l_1030 = &g_757;
    int32_t l_1034 = 1L;
    const uint32_t l_1080 = 4294967295UL;
    uint8_t *l_1081 = &g_169.f8;
    int16_t *l_1086[4];
    uint32_t l_1091 = 0UL;
    int32_t *l_1094 = (void*)0;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_1086[i] = &g_360;
lbl_609:
    for (p_60 = 0; (p_60 != (-9)); --p_60)
    { /* block id: 23 */
        int32_t *l_87[9] = {&g_69,&g_69,&g_69,&g_69,&g_69,&g_69,&g_69,&g_69,&g_69};
        int32_t ***l_102 = &g_78;
        int8_t l_127 = 0x92L;
        uint16_t l_225[8][5][3] = {{{1UL,0x6713L,65528UL},{65526UL,0xD625L,0x5271L},{0x989AL,65529UL,0x2E4DL},{0xD27AL,0xD625L,5UL},{0x68CFL,0x6713L,0x989AL}},{{1UL,0x1A5EL,0x1907L},{1UL,65534UL,1UL},{0UL,65526UL,65535UL},{0x6C71L,65528UL,0UL},{0UL,0x5271L,6UL}},{{65528UL,0x2E4DL,0x68CFL},{0UL,5UL,1UL},{0x6C71L,0x989AL,0UL},{0UL,0x1907L,0xD27AL},{1UL,1UL,9UL}},{{1UL,65535UL,0x2AFEL},{0x68CFL,0UL,0xFCDEL},{0xD27AL,6UL,0x2559L},{0x989AL,0x68CFL,0xFCDEL},{65526UL,1UL,0x2AFEL}},{{1UL,0UL,9UL},{65535UL,0xD27AL,0xD27AL},{0x9D0CL,9UL,0UL},{65535UL,0x2AFEL,1UL},{0UL,0xFCDEL,0x68CFL}},{{65535UL,0x2559L,6UL},{65534UL,0xFCDEL,0UL},{0x5271L,0x2AFEL,65535UL},{0x6AD9L,9UL,1UL},{0x1907L,0xD27AL,0x1907L}},{{0xCEE7L,0UL,0x989AL},{0xCBA6L,1UL,5UL},{65526UL,0x68CFL,0x2E4DL},{1UL,6UL,0x5271L},{65526UL,0UL,65528UL}},{{0xCBA6L,65535UL,65526UL},{0xCEE7L,1UL,65534UL},{0x1907L,0x1907L,0x1A5EL},{0x6AD9L,0x989AL,0x6713L},{0x5271L,5UL,0xD625L}}};
        int64_t *l_238 = (void*)0;
        uint32_t l_241 = 0UL;
        uint32_t l_274 = 0xFC520527L;
        int64_t l_314[4] = {(-3L),(-3L),(-3L),(-3L)};
        int16_t l_325 = 1L;
        int64_t l_333 = (-3L);
        int i, j, k;
        l_87[1] = p_62;
        if ((*p_62))
        { /* block id: 25 */
            int32_t l_88 = 0xBC77BB9FL;
            for (g_69 = 7; (g_69 >= 2); g_69 -= 1)
            { /* block id: 28 */
                int i;
                l_87[g_69] = l_87[g_69];
            }
            if (l_88)
                continue;
        }
        else
        { /* block id: 32 */
            int32_t *l_97 = &g_69;
            int64_t l_100 = (-1L);
            int32_t ****l_103 = &l_102;
            uint32_t *l_121 = (void*)0;
            uint32_t *l_122 = &g_123;
            uint8_t *l_124[6];
            int i;
            for (i = 0; i < 6; i++)
                l_124[i] = &g_125;
            for (g_69 = 29; (g_69 != 15); g_69 = safe_sub_func_int16_t_s_s(g_69, 2))
            { /* block id: 35 */
                uint8_t l_91 = 0x92L;
                l_91++;
                --g_94;
                (*g_78) = l_97;
                l_100 ^= (safe_rshift_func_int16_t_s_u((-1L), 10));
            }
            l_128[0][1] = ((p_60 >= (l_101 == ((*l_103) = l_102))) || ((g_8 , ((+(2UL < (***l_101))) != (safe_add_func_int32_t_s_s((((safe_add_func_uint16_t_u_u(g_5, (g_69 , (safe_mod_func_int32_t_s_s((safe_lshift_func_int16_t_s_s(((safe_rshift_func_uint16_t_u_u((safe_div_func_uint32_t_u_u((safe_rshift_func_int16_t_s_s(((l_126 = (((*l_122) ^= (safe_mul_func_int8_t_s_s((-8L), p_60))) < p_61)) <= 0x56L), l_127)), (**g_78))), 8)) , 0x9EA6L), (***l_101))), 5L))))) & (***l_102)) & 0x9F9BF173AA3328DBLL), 0L)))) , 0UL));
            if ((****l_103))
                break;
        }
        for (l_127 = 0; (l_127 != 9); l_127 = safe_add_func_uint8_t_u_u(l_127, 9))
        { /* block id: 49 */
            int8_t *l_135[4];
            int32_t l_137 = 0x64EC0B5BL;
            const int32_t * const **l_140 = &l_138[8];
            int32_t l_226 = 4L;
            int32_t l_227[3][8][6] = {{{(-10L),0L,(-1L),0L,(-10L),(-1L)},{0L,(-10L),(-1L),0x37C62FE8L,0x37C62FE8L,(-1L)},{0x37C62FE8L,0x37C62FE8L,(-1L),(-10L),0L,(-1L)},{(-10L),0L,(-1L),0L,(-10L),(-1L)},{0L,(-10L),(-1L),0x37C62FE8L,0x37C62FE8L,(-1L)},{0x37C62FE8L,0x37C62FE8L,(-1L),(-10L),0L,(-1L)},{(-10L),0L,(-1L),0L,(-10L),(-1L)},{1L,0x2152D3ADL,0x37C62FE8L,(-1L),(-1L),0x37C62FE8L}},{{(-1L),(-1L),0x37C62FE8L,0x2152D3ADL,1L,0x37C62FE8L},{0x2152D3ADL,1L,0x37C62FE8L,1L,0x2152D3ADL,0x37C62FE8L},{1L,0x2152D3ADL,0x37C62FE8L,(-1L),(-1L),0x37C62FE8L},{(-1L),(-1L),0x37C62FE8L,0x2152D3ADL,1L,0x37C62FE8L},{0x2152D3ADL,1L,0x37C62FE8L,1L,0x2152D3ADL,0x37C62FE8L},{1L,0x2152D3ADL,0x37C62FE8L,(-1L),(-1L),0x37C62FE8L},{(-1L),(-1L),0x37C62FE8L,0x2152D3ADL,1L,0x37C62FE8L},{0x2152D3ADL,1L,0x37C62FE8L,1L,0x2152D3ADL,0x37C62FE8L}},{{1L,0x2152D3ADL,0x37C62FE8L,(-1L),(-1L),0x37C62FE8L},{(-1L),(-1L),0x37C62FE8L,0x2152D3ADL,1L,0x37C62FE8L},{0x2152D3ADL,1L,0x37C62FE8L,1L,0x2152D3ADL,0x37C62FE8L},{1L,0x2152D3ADL,0x37C62FE8L,(-1L),(-1L),0x37C62FE8L},{(-1L),(-1L),0x37C62FE8L,0x2152D3ADL,1L,0x37C62FE8L},{0x2152D3ADL,1L,0x37C62FE8L,1L,0x2152D3ADL,0x37C62FE8L},{1L,0x2152D3ADL,0x37C62FE8L,(-1L),(-1L),0x37C62FE8L},{(-1L),(-1L),0x37C62FE8L,0x2152D3ADL,1L,0x37C62FE8L}}};
            int32_t *****l_300 = (void*)0;
            int64_t l_391 = 0xC914B24BAECFAE71LL;
            int i, j, k;
            for (i = 0; i < 4; i++)
                l_135[i] = &g_136[0];
            if (((safe_mod_func_int16_t_s_s((safe_lshift_func_int8_t_s_u((l_137 = 0x62L), (***l_101))), (p_60 && (&g_79 != ((*l_140) = l_138[3]))))) || l_141))
            { /* block id: 52 */
                const int32_t **l_142 = &l_139;
                int32_t l_155 = (-3L);
                int32_t *l_160 = &l_137;
                int32_t l_164 = 0x4937C963L;
                int32_t **** const l_181 = &l_102;
                (*l_142) = (**l_140);
                for (l_126 = 0; (l_126 <= 8); l_126 += 1)
                { /* block id: 56 */
                    uint8_t *l_161 = &l_141;
                    uint32_t l_189 = 0x2CAB3758L;
                    const int32_t **l_192[2][4][2];
                    int i, j, k;
                    for (i = 0; i < 2; i++)
                    {
                        for (j = 0; j < 4; j++)
                        {
                            for (k = 0; k < 2; k++)
                                l_192[i][j][k] = &l_139;
                        }
                    }
                    l_164 = (safe_sub_func_int16_t_s_s((safe_mul_func_int8_t_s_s((safe_mul_func_uint16_t_u_u((safe_div_func_uint64_t_u_u(((safe_sub_func_uint8_t_u_u((((safe_lshift_func_int16_t_s_s(p_59, 4)) > (l_155 = (**g_78))) , ((((((***l_101) >= ((***l_101) > (safe_lshift_func_int8_t_s_s((0x67F6L || (***l_140)), 2)))) >= (l_87[l_126] == (l_160 = l_87[l_126]))) >= (++(*l_161))) < ((0x9310AB7D55596E05LL < g_125) , (***l_102))) ^ g_8)), p_60)) || 0x10L), g_125)), 0x07DCL)), g_136[0])), g_136[2]));
                    for (g_94 = 1; (g_94 <= 4); g_94 += 1)
                    { /* block id: 63 */
                        int32_t ****l_168 = &l_102;
                        int32_t *****l_167 = &l_168;
                        int32_t *****l_180 = &l_178[0][2][1];
                        int16_t *l_184 = &g_185;
                        int64_t *l_187 = &g_188;
                        int i, j;
                        l_128[(g_94 + 2)][g_94] &= (g_12 , (safe_sub_func_int8_t_s_s(((*l_160) & ((((*l_187) = (((*l_167) = &l_102) == ((g_169 , (safe_add_func_uint8_t_u_u((safe_mod_func_uint8_t_u_u((((safe_mul_func_int16_t_s_s(((*l_184) = ((((-1L) ^ p_60) , (0xC6L < 0x0EL)) && ((((safe_rshift_func_int16_t_s_u((((*l_180) = l_178[0][2][1]) != l_181), g_8)) , (void*)0) != g_182) != p_60))), p_60)) == g_169.f0) != g_169.f0), g_12)), p_60))) , g_186))) , l_87[g_94]) == l_87[l_126])), g_8)));
                        --l_189;
                        if ((***l_140))
                            break;
                        if ((***l_101))
                            continue;
                    }
                    for (g_169.f3 = 0; (g_169.f3 <= 6); g_169.f3 += 1)
                    { /* block id: 75 */
                        return l_87[l_126];
                    }
                    g_193[0][3] = (**l_140);
                }
            }
            else
            { /* block id: 80 */
                uint16_t *l_222 = &g_223;
                int32_t l_224 = 0x598EEF55L;
                int64_t l_228 = 0xDCF5DE5156066C03LL;
                const int32_t ***l_303[4];
                const int32_t ****l_302[6][1][2] = {{{&l_303[1],&l_303[1]}},{{&l_303[0],&l_303[3]}},{{&l_303[1],&l_303[3]}},{{&l_303[0],&l_303[1]}},{{&l_303[1],&l_303[1]}},{{&l_303[1],&l_303[1]}}};
                const int32_t *****l_301 = &l_302[5][0][1];
                int32_t l_312 = 0L;
                int32_t l_317 = 0x76FF9F77L;
                int32_t l_318 = 0xDCCEB260L;
                int32_t l_324 = 0x50EC15D1L;
                int32_t l_334 = (-1L);
                int32_t l_335 = 3L;
                int32_t l_336 = 0x2C240B1CL;
                int32_t l_338 = 9L;
                int32_t l_339 = (-1L);
                int32_t l_340 = 0L;
                int32_t l_341 = 8L;
                int32_t l_342 = (-9L);
                int32_t l_343 = 0x4255D528L;
                int32_t l_344 = 1L;
                uint8_t *l_361[3][5] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_169.f7,&g_125,&g_169.f7,&g_169.f7,&g_125},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
                uint64_t *l_368 = &g_169.f6;
                const int32_t l_392[6][7] = {{0L,0L,0x638CB481L,0x638CB481L,0L,0L,0x638CB481L},{0x439C47E3L,0xF2A3EEABL,0x439C47E3L,0xF2A3EEABL,0x439C47E3L,0xF2A3EEABL,0x439C47E3L},{0L,0x638CB481L,0x638CB481L,0L,0L,0x638CB481L,0x638CB481L},{5L,0xF2A3EEABL,5L,0xF2A3EEABL,5L,0xF2A3EEABL,5L},{0L,0L,0x638CB481L,0x638CB481L,0L,0L,0x638CB481L},{0x439C47E3L,0xF2A3EEABL,0x439C47E3L,0xF2A3EEABL,0x439C47E3L,0xF2A3EEABL,0x439C47E3L}};
                int32_t ***l_416 = (void*)0;
                int i, j, k;
                for (i = 0; i < 4; i++)
                    l_303[i] = (void*)0;
                if ((safe_add_func_uint8_t_u_u((((((safe_mul_func_int8_t_s_s((g_169.f7 | ((((safe_mul_func_int16_t_s_s(((safe_div_func_uint8_t_u_u(g_169.f6, g_8)) && ((safe_lshift_func_int8_t_s_s(((safe_lshift_func_uint8_t_u_s((((safe_sub_func_int16_t_s_s((safe_add_func_uint64_t_u_u(g_94, p_59)), ((l_227[1][5][1] = ((l_226 = (l_225[3][0][2] &= ((safe_div_func_int64_t_s_s(((safe_div_func_uint16_t_u_u(((((safe_div_func_uint32_t_u_u((((safe_div_func_int8_t_s_s((g_136[1] = (safe_add_func_uint16_t_u_u(0UL, ((*l_222) = ((l_137 = (safe_mod_func_uint16_t_u_u(((*l_101) == (void*)0), (((*g_78) == (void*)0) , p_60)))) <= g_169.f8))))), 0xB8L)) & 2L) & 0xD7962437L), (*p_62))) >= g_5) < (*l_139)) <= (*p_62)), l_224)) || p_61), 0xBA2822E894D0847CLL)) | g_169.f8))) >= 6L)) <= p_59))) < 0xB7D10769E08EB9DCLL) != p_61), l_228)) && p_59), p_59)) && 0x09A9BC9FA815E18FLL)), g_123)) < p_59) >= p_60) < p_59)), p_61)) & 0x58L) , &l_141) != &g_125) | p_59), p_60)))
                { /* block id: 87 */
                    int64_t l_244 = 0x1A4B412E4D6ACB4FLL;
                    int64_t *l_266 = &l_228;
                    int8_t l_295 = 0xA3L;
                    int32_t l_296 = 0x01F71444L;
                    if ((*p_62))
                    { /* block id: 88 */
                        g_186 = g_186;
                        if ((*p_62))
                            continue;
                        (**l_101) = (*g_78);
                        l_137 = (*p_62);
                    }
                    else
                    { /* block id: 93 */
                        int8_t l_237[10][6][4] = {{{5L,0xD2L,0x98L,0x05L},{(-1L),(-1L),0x01L,7L},{1L,0x01L,0xEEL,0L},{0x05L,0x1AL,3L,1L},{(-1L),0x41L,0L,0x43L},{0x41L,0xBFL,0L,0xC7L}},{{0xE9L,0xDFL,0xDBL,0x05L},{0x6BL,(-9L),(-4L),0x4DL},{0x12L,(-2L),0x6BL,0xA1L},{0xCFL,0xCDL,(-1L),0xD1L},{0xA1L,(-1L),0x38L,0x76L},{(-1L),0x6BL,(-1L),6L}},{{0xB3L,0L,(-4L),1L},{0x10L,0L,1L,(-1L)},{0xD3L,1L,(-3L),(-3L)},{0x36L,0x36L,0xB3L,0L},{0xDBL,0xECL,0x81L,2L},{0x44L,0x98L,0x76L,0x81L}},{{(-1L),0x98L,0x4DL,2L},{0x98L,0xECL,0L,0L},{(-4L),0x36L,0x3AL,(-3L)},{(-9L),1L,0x1DL,(-1L)},{(-10L),0L,(-1L),1L},{(-1L),0L,(-9L),6L}},{{0x1AL,0x6BL,0xCDL,0x76L},{0xEEL,(-1L),0xEEL,0xD1L},{0xC8L,0xCDL,0xECL,0xA1L},{0x44L,(-2L),0xC7L,0x4DL},{1L,(-9L),1L,0x05L},{3L,0xDFL,0x6BL,0xC7L}},{{8L,0xBFL,0x1AL,0x43L},{0x7EL,(-4L),6L,0x09L},{9L,0xA1L,0x6BL,0xEEL},{2L,0x85L,0x09L,0xB3L},{(-7L),1L,0x5BL,0x13L},{0x05L,0x90L,(-7L),(-1L)}},{{0x38L,0x59L,0xCFL,0xE9L},{(-1L),0x76L,0xD3L,3L},{0xBFL,0xC8L,1L,0xDAL},{(-2L),1L,0xA2L,0x0BL},{0x59L,1L,0x59L,0xDBL},{0x3AL,(-1L),0xCBL,(-1L)}},{{0xDFL,1L,0x89L,(-1L)},{0L,(-1L),0x89L,8L},{0xDFL,0x43L,0xCBL,9L},{0x3AL,(-1L),0x59L,0x5BL},{0x59L,0x5BL,0xA2L,7L},{(-2L),0xCDL,1L,0xE0L}},{{0xBFL,0x10L,0xD3L,0L},{(-1L),0xD2L,0xCFL,0x6BL},{0x38L,(-2L),(-7L),0x36L},{0x05L,0x6BL,0x5BL,0x7EL},{(-7L),0x38L,0x12L,0xCDL},{9L,0xB1L,0xD3L,0L}},{{0xC7L,5L,(-1L),0x5BL},{0x05L,0x6BL,0xA1L,0x38L},{8L,(-7L),0x3AL,0xBFL},{0xA2L,(-1L),0xCDL,0x89L},{1L,0xA2L,0xD1L,0x6BL},{0x5BL,(-1L),(-1L),0x43L}}};
                        int64_t **l_239 = (void*)0;
                        int64_t **l_240 = &l_238;
                        int i, j, k;
                        l_227[1][5][1] ^= (safe_lshift_func_int16_t_s_s((safe_lshift_func_int8_t_s_u(g_169.f4, (0L >= (((g_45 >= 0x7A2EE58EL) & ((safe_lshift_func_uint16_t_u_u(((*l_222) &= g_8), (((*l_240) = ((((((g_188 != (safe_mod_func_uint64_t_u_u(0x4BDAF0493C28935DLL, g_169.f2))) > ((((((g_136[0] && l_237[5][2][1]) < (*p_62)) != 0xCD3D93C69FD8C011LL) <= l_237[1][1][0]) && l_237[8][1][3]) >= 0UL)) > p_59) == p_61) , l_237[0][5][3]) , l_238)) != &g_188))) > g_69)) | (*p_62))))), 9));
                        l_241 |= (*p_62);
                        l_226 = (safe_rshift_func_int8_t_s_s(l_244, ((safe_add_func_int64_t_s_s(6L, ((safe_rshift_func_uint16_t_u_u(0x359DL, ((safe_sub_func_uint8_t_u_u((((safe_add_func_uint64_t_u_u(((((g_136[5] = (0x48L > (safe_sub_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u((safe_mod_func_int32_t_s_s(0x33177101L, (safe_mul_func_int8_t_s_s(((safe_mul_func_uint16_t_u_u(g_169.f8, l_237[5][2][1])) > (safe_sub_func_int8_t_s_s((g_136[3] <= g_169.f0), 0x5AL))), g_169.f8)))), g_45)), (-7L))))) || 0xE7L) <= (-1L)) || p_60), g_12)) && 0x8FE576D7L) , 250UL), 2L)) & 0xA2L))) != g_125))) == (***l_140))));
                        l_227[0][2][3] = l_228;
                    }
                    l_224 |= (*p_62);
                    l_227[2][3][1] &= (0xA3F30FDAL && (*p_62));
                    if ((((~((*l_266) = (-1L))) , (void*)0) != (void*)0))
                    { /* block id: 105 */
                        int32_t l_270 = 1L;
                        int16_t *l_271 = &g_185;
                        int32_t l_275 = 0xFE3D08FBL;
                        l_275 ^= ((((((g_94 ^ ((safe_mul_func_int16_t_s_s((l_228 && (~((***l_140) & g_123))), (0xF8BE54F4L != ((l_270 && ((*l_271) = 0xBA17L)) <= (safe_rshift_func_uint8_t_u_u((g_5 < ((l_227[2][6][4] = g_169.f0) || p_60)), g_169.f8)))))) | p_61)) < l_244) , 0UL) ^ l_274) <= g_123) , 0x0B81AB11L);
                        return (*g_78);
                    }
                    else
                    { /* block id: 110 */
                        int32_t l_293 = 0xAE1F0B0FL;
                        l_296 = (safe_div_func_uint8_t_u_u((safe_add_func_uint32_t_u_u(((***l_140) , ((safe_mul_func_int8_t_s_s((0x11ECB1D280DFA0F3LL == (~((((g_136[5] , ((((safe_mul_func_uint16_t_u_u(((&g_186 != (void*)0) && 0xAEAADFABC0FDD523LL), ((safe_mul_func_int8_t_s_s((((+(g_185 |= 0xD3FDL)) & (safe_sub_func_int64_t_s_s(((((safe_lshift_func_int16_t_s_s((!(*p_62)), 3)) , ((((l_293 , 0xFDF6L) , (*p_62)) , 0x4214107A232681D3LL) <= 0xDC34DCA40A1BE3DCLL)) , &p_62) != &g_79), (***l_102)))) , g_185), (-1L))) && g_136[0]))) >= g_294[1]) == l_293) > l_295)) == (*p_62)) < l_295) == 0x4E7043E7L))), 0x6BL)) < 0x11L)), g_8)), l_224));
                    }
                }
                else
                { /* block id: 114 */
                    union U3 l_299 = {0};
                    uint8_t *l_304 = &g_169.f0;
                    int32_t l_305 = 0x492963F9L;
                    int32_t l_319 = (-1L);
                    int32_t l_320 = 0xB1EE8401L;
                    int32_t l_321[2];
                    int i;
                    for (i = 0; i < 2; i++)
                        l_321[i] = (-1L);
                    l_224 = (safe_sub_func_uint32_t_u_u(((&g_125 != (((l_299 , l_300) == l_301) , (void*)0)) || ((1L > ((((*l_304) = ((*p_62) > 0L)) != (((g_169.f1 != 255UL) ^ 0L) >= 0x23L)) , 0x0AL)) & (***l_179))), (*p_62)));
                    if ((((**l_179) = p_62) == (void*)0))
                    { /* block id: 118 */
                        g_69 = l_305;
                        return (*g_78);
                    }
                    else
                    { /* block id: 121 */
                        int8_t l_311[1][3];
                        int32_t l_316 = 0xA6D0993DL;
                        int32_t l_322 = 7L;
                        int32_t l_323 = 1L;
                        int32_t l_326 = 9L;
                        int32_t l_327 = (-8L);
                        int32_t l_328 = 0x2F2C54B8L;
                        int32_t l_329 = 0xC0A801A0L;
                        int32_t l_330 = 5L;
                        int32_t l_331 = (-1L);
                        int32_t l_332[6][6] = {{(-1L),(-1L),(-8L),(-1L),(-1L),(-8L)},{(-1L),(-1L),(-8L),(-1L),(-1L),(-8L)},{(-1L),(-1L),(-8L),(-1L),(-1L),(-8L)},{(-1L),(-1L),(-8L),(-1L),(-1L),(-8L)},{(-1L),(-1L),(-8L),(-1L),(-1L),(-8L)},{(-1L),(-1L),(-8L),(-1L),(-1L),(-8L)}};
                        int32_t l_337 = 0L;
                        uint32_t l_345 = 18446744073709551615UL;
                        int i, j;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 3; j++)
                                l_311[i][j] = 0x29L;
                        }
                        l_311[0][1] = (((((!4L) , (((**g_78) || (**g_78)) | 0xC1L)) <= (safe_mod_func_uint16_t_u_u(g_125, g_125))) , l_309) == (g_310 , &l_228));
                        ++l_345;
                        if ((*p_62))
                            break;
                    }
                }
                if (((safe_lshift_func_int8_t_s_u((safe_sub_func_uint64_t_u_u(((*l_368) = ((safe_add_func_int32_t_s_s(0x9A1F309CL, 1UL)) || (((l_318 = (safe_sub_func_uint8_t_u_u(((**g_78) , 255UL), (safe_div_func_int64_t_s_s(((safe_lshift_func_int8_t_s_s((g_360 = 1L), ((((g_169.f8 |= 250UL) >= (((((safe_mod_func_int32_t_s_s(((g_136[1] = p_60) <= ((p_61 >= (safe_sub_func_int16_t_s_s(((safe_add_func_int8_t_s_s(0xBBL, 0x38L)) != p_60), g_169.f1))) <= 8L)), 0x0897814FL)) , 0x2778L) | p_60) | p_61) && (***l_140))) > (***l_140)) <= 0x8D25674C8F2BE39FLL))) > 0UL), g_123))))) & 8L) >= 0L))), (***l_102))), g_169.f7)) && (***l_140)))
                { /* block id: 132 */
                    uint16_t *l_377 = &l_225[6][0][2];
                    int32_t l_378 = 1L;
                    uint32_t *l_383 = (void*)0;
                    uint32_t *l_384 = &g_123;
                    uint32_t *l_390[2][7][3] = {{{&l_241,&l_241,&l_241},{&l_241,&l_241,(void*)0},{&l_241,&l_241,&l_241},{&l_241,&l_241,(void*)0},{&l_241,&l_241,&l_241},{&l_241,&l_241,(void*)0},{&l_241,&l_241,&l_241}},{{&l_241,&l_241,(void*)0},{&l_241,&l_241,&l_241},{&l_241,&l_241,(void*)0},{&l_241,&l_241,&l_241},{&l_241,&l_241,(void*)0},{&l_241,&l_241,&l_241},{&l_241,&l_241,(void*)0}}};
                    int32_t l_393 = (-10L);
                    int64_t *l_419 = &l_314[0];
                    int i, j, k;
                    l_393 |= ((safe_sub_func_uint64_t_u_u((((safe_mul_func_int8_t_s_s((safe_sub_func_uint32_t_u_u((safe_add_func_int32_t_s_s((g_69 = (((((l_377 = &g_223) != (void*)0) <= (l_391 = (((g_169.f3 & l_378) , (((safe_add_func_int32_t_s_s((safe_add_func_uint32_t_u_u(g_136[3], ((*l_384)++))), (safe_lshift_func_uint8_t_u_u(0x6FL, 0)))) == (+0xB7L)) , &l_127)) == l_361[2][0]))) <= (**g_78)) , 0x0295ACDAL)), l_378)), 4L)), l_378)) | 5L) || 0x16DBC8E6L), 0xEB1C2A432E1B7502LL)) , l_392[4][5]);
                    l_339 &= (((*l_419) = (safe_div_func_int8_t_s_s((((safe_mul_func_int8_t_s_s(p_61, (safe_lshift_func_int16_t_s_u(((((safe_rshift_func_int16_t_s_s(((safe_add_func_uint8_t_u_u(((safe_mod_func_uint8_t_u_u((g_169.f0 |= g_169.f4), p_61)) >= (((+(l_378 = 0xA468L)) < 0xCBL) > (safe_div_func_int16_t_s_s((safe_sub_func_int64_t_s_s((~((((((((l_102 != l_416) | (safe_rshift_func_uint16_t_u_u(0UL, 14))) || (p_60 & g_313[0][1])) <= p_61) == 9UL) | g_313[0][1]) , (void*)0) == l_222)), (***l_140))), 0xE0F4L)))), 0x5CL)) & l_393), 0)) | g_185) , (-3L)) ^ p_61), 3)))) || (-6L)) > 0x55D13CAC38BA2AB4LL), p_59))) , (**g_78));
                }
                else
                { /* block id: 142 */
                    int32_t * const l_421 = &l_128[0][1];
                    for (l_341 = 0; (l_341 <= 2); l_341 += 1)
                    { /* block id: 145 */
                        int32_t ***l_420 = (void*)0;
                        int i, j;
                        l_128[(l_341 + 3)][(l_341 + 1)] |= ((void*)0 != l_420);
                        (*l_421) |= (g_313[l_341][(l_341 + 1)] != ((p_62 != l_421) > (g_169.f8 ^= 254UL)));
                    }
                    return (**l_102);
                }
            }
        }
    }
    for (g_185 = 0; (g_185 == 2); ++g_185)
    { /* block id: 157 */
        uint8_t l_434 = 0x02L;
        int16_t *l_435 = &g_360;
        int32_t l_436[6] = {0x8A88C634L,0x8A88C634L,0x374A7284L,0x8A88C634L,0x8A88C634L,0x374A7284L};
        int32_t ***l_442 = &g_78;
        int32_t ***l_443 = &g_78;
        uint16_t l_508 = 0xB834L;
        const uint32_t l_576 = 0x599A7B77L;
        uint64_t *l_578 = &g_169.f6;
        uint16_t l_603 = 8UL;
        int32_t l_617 = (-1L);
        uint32_t **l_618 = (void*)0;
        uint16_t **l_725 = (void*)0;
        struct S2 *l_738 = &g_739;
        uint32_t * const *l_759 = &g_757;
        struct S0 l_786 = {0xF9L,0x03L,2L,6L,0xA9FE60D7L,0x19L,0x8480FE3438F587A7LL,5UL,5UL};
        int32_t l_848 = 0xCAD83F89L;
        union U3 l_857 = {0};
        union U3 **l_864[10] = {&g_673,&g_673,&g_673,&g_673,&g_673,&g_673,&g_673,&g_673,&g_673,&g_673};
        int64_t *l_867 = &g_188;
        const uint32_t l_1062 = 4294967295UL;
        int i;
    }
    if ((!((((l_566 , (g_1017[0].f5 = (((safe_div_func_uint16_t_u_u(((safe_mul_func_int8_t_s_s((safe_add_func_int32_t_s_s(l_1080, 0xE8F4657FL)), ((*l_1081) = ((void*)0 == &l_754)))) <= ((*p_62) || (***l_179))), (p_60 = (safe_mul_func_int16_t_s_s(p_60, (safe_mod_func_uint8_t_u_u((p_61 >= p_59), 250UL))))))) || 65535UL) == p_59))) && p_60) | (**g_999)) ^ p_61)))
    { /* block id: 463 */
lbl_1087:
        for (g_169.f5 = 0; g_169.f5 < 7; g_169.f5 += 1)
        {
            g_136[g_169.f5] = 0x7BL;
        }
        if (g_223)
            goto lbl_609;
        if (g_169.f5)
            goto lbl_1087;
    }
    else
    { /* block id: 467 */
        int32_t l_1088 = 0x097B5FFCL;
        int32_t l_1089 = 0x7C9B0932L;
        int32_t l_1090[9][6] = {{(-1L),(-5L),(-5L),(-1L),(-5L),(-5L)},{(-1L),(-5L),(-5L),(-1L),(-5L),(-5L)},{(-1L),(-5L),(-5L),(-1L),(-5L),(-5L)},{(-1L),(-5L),(-5L),(-1L),(-5L),(-5L)},{(-1L),(-5L),(-5L),(-1L),(-5L),(-5L)},{(-1L),(-5L),(-5L),(-1L),(-5L),(-5L)},{(-1L),(-5L),(-5L),(-1L),(-5L),(-5L)},{(-1L),(-5L),(-5L),(-1L),(-5L),(-5L)},{(-1L),(-5L),(-5L),(-1L),(-5L),(-5L)}};
        int i, j;
        ++l_1091;
    }
    (*g_78) = l_1094;
    return p_62;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    transparent_crc(g_94, "g_94", print_hash_value);
    transparent_crc(g_123, "g_123", print_hash_value);
    transparent_crc(g_125, "g_125", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_136[i], "g_136[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_169.f0, "g_169.f0", print_hash_value);
    transparent_crc(g_169.f1, "g_169.f1", print_hash_value);
    transparent_crc(g_169.f2, "g_169.f2", print_hash_value);
    transparent_crc(g_169.f3, "g_169.f3", print_hash_value);
    transparent_crc(g_169.f4, "g_169.f4", print_hash_value);
    transparent_crc(g_169.f5, "g_169.f5", print_hash_value);
    transparent_crc(g_169.f6, "g_169.f6", print_hash_value);
    transparent_crc(g_169.f7, "g_169.f7", print_hash_value);
    transparent_crc(g_169.f8, "g_169.f8", print_hash_value);
    transparent_crc(g_183, "g_183", print_hash_value);
    transparent_crc(g_185, "g_185", print_hash_value);
    transparent_crc(g_188, "g_188", print_hash_value);
    transparent_crc(g_223, "g_223", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_294[i], "g_294[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_313[i][j], "g_313[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_315[i], "g_315[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_360, "g_360", print_hash_value);
    transparent_crc(g_542, "g_542", print_hash_value);
    transparent_crc(g_670, "g_670", print_hash_value);
    transparent_crc(g_739.f0, "g_739.f0", print_hash_value);
    transparent_crc(g_743.f0, "g_743.f0", print_hash_value);
    transparent_crc(g_790, "g_790", print_hash_value);
    transparent_crc(g_835, "g_835", print_hash_value);
    transparent_crc(g_887, "g_887", print_hash_value);
    transparent_crc(g_935, "g_935", print_hash_value);
    transparent_crc(g_970, "g_970", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_1006[i].f0, "g_1006[i].f0", print_hash_value);
        transparent_crc(g_1006[i].f1, "g_1006[i].f1", print_hash_value);
        transparent_crc(g_1006[i].f2, "g_1006[i].f2", print_hash_value);
        transparent_crc(g_1006[i].f3, "g_1006[i].f3", print_hash_value);
        transparent_crc(g_1006[i].f4, "g_1006[i].f4", print_hash_value);
        transparent_crc(g_1006[i].f5, "g_1006[i].f5", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1007.f0, "g_1007.f0", print_hash_value);
    transparent_crc(g_1007.f1, "g_1007.f1", print_hash_value);
    transparent_crc(g_1007.f2, "g_1007.f2", print_hash_value);
    transparent_crc(g_1007.f3, "g_1007.f3", print_hash_value);
    transparent_crc(g_1007.f4, "g_1007.f4", print_hash_value);
    transparent_crc(g_1007.f5, "g_1007.f5", print_hash_value);
    transparent_crc(g_1008.f0, "g_1008.f0", print_hash_value);
    transparent_crc(g_1008.f1, "g_1008.f1", print_hash_value);
    transparent_crc(g_1008.f2, "g_1008.f2", print_hash_value);
    transparent_crc(g_1008.f3, "g_1008.f3", print_hash_value);
    transparent_crc(g_1008.f4, "g_1008.f4", print_hash_value);
    transparent_crc(g_1008.f5, "g_1008.f5", print_hash_value);
    transparent_crc(g_1009.f0, "g_1009.f0", print_hash_value);
    transparent_crc(g_1009.f1, "g_1009.f1", print_hash_value);
    transparent_crc(g_1009.f2, "g_1009.f2", print_hash_value);
    transparent_crc(g_1009.f3, "g_1009.f3", print_hash_value);
    transparent_crc(g_1009.f4, "g_1009.f4", print_hash_value);
    transparent_crc(g_1009.f5, "g_1009.f5", print_hash_value);
    transparent_crc(g_1010.f0, "g_1010.f0", print_hash_value);
    transparent_crc(g_1010.f1, "g_1010.f1", print_hash_value);
    transparent_crc(g_1010.f2, "g_1010.f2", print_hash_value);
    transparent_crc(g_1010.f3, "g_1010.f3", print_hash_value);
    transparent_crc(g_1010.f4, "g_1010.f4", print_hash_value);
    transparent_crc(g_1010.f5, "g_1010.f5", print_hash_value);
    transparent_crc(g_1011.f0, "g_1011.f0", print_hash_value);
    transparent_crc(g_1011.f1, "g_1011.f1", print_hash_value);
    transparent_crc(g_1011.f2, "g_1011.f2", print_hash_value);
    transparent_crc(g_1011.f3, "g_1011.f3", print_hash_value);
    transparent_crc(g_1011.f4, "g_1011.f4", print_hash_value);
    transparent_crc(g_1011.f5, "g_1011.f5", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_1012[i][j].f0, "g_1012[i][j].f0", print_hash_value);
            transparent_crc(g_1012[i][j].f1, "g_1012[i][j].f1", print_hash_value);
            transparent_crc(g_1012[i][j].f2, "g_1012[i][j].f2", print_hash_value);
            transparent_crc(g_1012[i][j].f3, "g_1012[i][j].f3", print_hash_value);
            transparent_crc(g_1012[i][j].f4, "g_1012[i][j].f4", print_hash_value);
            transparent_crc(g_1012[i][j].f5, "g_1012[i][j].f5", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1013.f0, "g_1013.f0", print_hash_value);
    transparent_crc(g_1013.f1, "g_1013.f1", print_hash_value);
    transparent_crc(g_1013.f2, "g_1013.f2", print_hash_value);
    transparent_crc(g_1013.f3, "g_1013.f3", print_hash_value);
    transparent_crc(g_1013.f4, "g_1013.f4", print_hash_value);
    transparent_crc(g_1013.f5, "g_1013.f5", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_1017[i].f0, "g_1017[i].f0", print_hash_value);
        transparent_crc(g_1017[i].f1, "g_1017[i].f1", print_hash_value);
        transparent_crc(g_1017[i].f2, "g_1017[i].f2", print_hash_value);
        transparent_crc(g_1017[i].f3, "g_1017[i].f3", print_hash_value);
        transparent_crc(g_1017[i].f4, "g_1017[i].f4", print_hash_value);
        transparent_crc(g_1017[i].f5, "g_1017[i].f5", print_hash_value);
        transparent_crc(g_1017[i].f6, "g_1017[i].f6", print_hash_value);
        transparent_crc(g_1017[i].f7, "g_1017[i].f7", print_hash_value);
        transparent_crc(g_1017[i].f8, "g_1017[i].f8", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_1071[i], "g_1071[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1140.f0, "g_1140.f0", print_hash_value);
    transparent_crc(g_1140.f1, "g_1140.f1", print_hash_value);
    transparent_crc(g_1140.f2, "g_1140.f2", print_hash_value);
    transparent_crc(g_1140.f3, "g_1140.f3", print_hash_value);
    transparent_crc(g_1140.f4, "g_1140.f4", print_hash_value);
    transparent_crc(g_1140.f5, "g_1140.f5", print_hash_value);
    transparent_crc(g_1145.f0, "g_1145.f0", print_hash_value);
    transparent_crc(g_1145.f1, "g_1145.f1", print_hash_value);
    transparent_crc(g_1145.f2, "g_1145.f2", print_hash_value);
    transparent_crc(g_1145.f3, "g_1145.f3", print_hash_value);
    transparent_crc(g_1145.f4, "g_1145.f4", print_hash_value);
    transparent_crc(g_1145.f5, "g_1145.f5", print_hash_value);
    transparent_crc(g_1148, "g_1148", print_hash_value);
    transparent_crc(g_1216, "g_1216", print_hash_value);
    transparent_crc(g_1226, "g_1226", print_hash_value);
    transparent_crc(g_1270.f0, "g_1270.f0", print_hash_value);
    transparent_crc(g_1270.f1, "g_1270.f1", print_hash_value);
    transparent_crc(g_1270.f2, "g_1270.f2", print_hash_value);
    transparent_crc(g_1270.f3, "g_1270.f3", print_hash_value);
    transparent_crc(g_1270.f4, "g_1270.f4", print_hash_value);
    transparent_crc(g_1270.f5, "g_1270.f5", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_1450[i][j][k], "g_1450[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1503.f0, "g_1503.f0", print_hash_value);
    transparent_crc(g_1503.f1, "g_1503.f1", print_hash_value);
    transparent_crc(g_1503.f2, "g_1503.f2", print_hash_value);
    transparent_crc(g_1503.f3, "g_1503.f3", print_hash_value);
    transparent_crc(g_1503.f4, "g_1503.f4", print_hash_value);
    transparent_crc(g_1503.f5, "g_1503.f5", print_hash_value);
    transparent_crc(g_1503.f6, "g_1503.f6", print_hash_value);
    transparent_crc(g_1503.f7, "g_1503.f7", print_hash_value);
    transparent_crc(g_1503.f8, "g_1503.f8", print_hash_value);
    transparent_crc(g_1507.f0, "g_1507.f0", print_hash_value);
    transparent_crc(g_1813.f0, "g_1813.f0", print_hash_value);
    transparent_crc(g_1818.f0, "g_1818.f0", print_hash_value);
    transparent_crc(g_1831, "g_1831", print_hash_value);
    transparent_crc(g_1877, "g_1877", print_hash_value);
    transparent_crc(g_1965, "g_1965", print_hash_value);
    transparent_crc(g_1973.f0, "g_1973.f0", print_hash_value);
    transparent_crc(g_1973.f1, "g_1973.f1", print_hash_value);
    transparent_crc(g_1973.f2, "g_1973.f2", print_hash_value);
    transparent_crc(g_1973.f3, "g_1973.f3", print_hash_value);
    transparent_crc(g_1973.f4, "g_1973.f4", print_hash_value);
    transparent_crc(g_1973.f5, "g_1973.f5", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_2052[i], "g_2052[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2290.f0, "g_2290.f0", print_hash_value);
    transparent_crc(g_2388.f0, "g_2388.f0", print_hash_value);
    transparent_crc(g_2396.f0, "g_2396.f0", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_2418[i][j], "g_2418[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2528.f0, "g_2528.f0", print_hash_value);
    transparent_crc(g_2581.f0, "g_2581.f0", print_hash_value);
    transparent_crc(g_2660.f0, "g_2660.f0", print_hash_value);
    transparent_crc(g_2673.f0, "g_2673.f0", print_hash_value);
    transparent_crc(g_2759.f0, "g_2759.f0", print_hash_value);
    transparent_crc(g_2761.f0, "g_2761.f0", print_hash_value);
    transparent_crc(g_2773.f0, "g_2773.f0", print_hash_value);
    transparent_crc(g_2812, "g_2812", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_2841[i].f0, "g_2841[i].f0", print_hash_value);
        transparent_crc(g_2841[i].f1, "g_2841[i].f1", print_hash_value);
        transparent_crc(g_2841[i].f2, "g_2841[i].f2", print_hash_value);
        transparent_crc(g_2841[i].f3, "g_2841[i].f3", print_hash_value);
        transparent_crc(g_2841[i].f4, "g_2841[i].f4", print_hash_value);
        transparent_crc(g_2841[i].f5, "g_2841[i].f5", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2927.f0, "g_2927.f0", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_2985[i][j][k].f0, "g_2985[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_3012[i][j][k], "g_3012[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3049, "g_3049", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_3175[i][j][k].f0, "g_3175[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3226.f0, "g_3226.f0", print_hash_value);
    transparent_crc(g_3226.f1, "g_3226.f1", print_hash_value);
    transparent_crc(g_3226.f2, "g_3226.f2", print_hash_value);
    transparent_crc(g_3226.f3, "g_3226.f3", print_hash_value);
    transparent_crc(g_3226.f4, "g_3226.f4", print_hash_value);
    transparent_crc(g_3226.f5, "g_3226.f5", print_hash_value);
    transparent_crc(g_3226.f6, "g_3226.f6", print_hash_value);
    transparent_crc(g_3226.f7, "g_3226.f7", print_hash_value);
    transparent_crc(g_3226.f8, "g_3226.f8", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_3255[i][j].f0, "g_3255[i][j].f0", print_hash_value);
            transparent_crc(g_3255[i][j].f1, "g_3255[i][j].f1", print_hash_value);
            transparent_crc(g_3255[i][j].f2, "g_3255[i][j].f2", print_hash_value);
            transparent_crc(g_3255[i][j].f3, "g_3255[i][j].f3", print_hash_value);
            transparent_crc(g_3255[i][j].f4, "g_3255[i][j].f4", print_hash_value);
            transparent_crc(g_3255[i][j].f5, "g_3255[i][j].f5", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_3344, "g_3344", print_hash_value);
    transparent_crc(g_3350.f0, "g_3350.f0", print_hash_value);
    transparent_crc(g_3371.f0, "g_3371.f0", print_hash_value);
    transparent_crc(g_3388, "g_3388", print_hash_value);
    transparent_crc(g_3400, "g_3400", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_3426[i][j][k], "g_3426[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3427.f0, "g_3427.f0", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_3433[i][j][k], "g_3433[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3449.f0, "g_3449.f0", print_hash_value);
    transparent_crc(g_3449.f1, "g_3449.f1", print_hash_value);
    transparent_crc(g_3449.f2, "g_3449.f2", print_hash_value);
    transparent_crc(g_3449.f3, "g_3449.f3", print_hash_value);
    transparent_crc(g_3449.f4, "g_3449.f4", print_hash_value);
    transparent_crc(g_3449.f5, "g_3449.f5", print_hash_value);
    transparent_crc(g_3472, "g_3472", print_hash_value);
    transparent_crc(g_3475.f0, "g_3475.f0", print_hash_value);
    transparent_crc(g_3508, "g_3508", print_hash_value);
    transparent_crc(g_3521.f0, "g_3521.f0", print_hash_value);
    transparent_crc(g_3521.f1, "g_3521.f1", print_hash_value);
    transparent_crc(g_3521.f2, "g_3521.f2", print_hash_value);
    transparent_crc(g_3521.f3, "g_3521.f3", print_hash_value);
    transparent_crc(g_3521.f4, "g_3521.f4", print_hash_value);
    transparent_crc(g_3521.f5, "g_3521.f5", print_hash_value);
    transparent_crc(g_3576, "g_3576", print_hash_value);
    transparent_crc(g_3587.f0, "g_3587.f0", print_hash_value);
    transparent_crc(g_3602.f0, "g_3602.f0", print_hash_value);
    transparent_crc(g_3625.f0, "g_3625.f0", print_hash_value);
    transparent_crc(g_3701.f0, "g_3701.f0", print_hash_value);
    transparent_crc(g_3701.f1, "g_3701.f1", print_hash_value);
    transparent_crc(g_3701.f2, "g_3701.f2", print_hash_value);
    transparent_crc(g_3701.f3, "g_3701.f3", print_hash_value);
    transparent_crc(g_3701.f4, "g_3701.f4", print_hash_value);
    transparent_crc(g_3701.f5, "g_3701.f5", print_hash_value);
    transparent_crc(g_3728, "g_3728", print_hash_value);
    transparent_crc(g_3729.f0, "g_3729.f0", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_3750[i][j][k].f0, "g_3750[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3780.f0, "g_3780.f0", print_hash_value);
    transparent_crc(g_3826.f0, "g_3826.f0", print_hash_value);
    transparent_crc(g_3859.f0, "g_3859.f0", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_3887[i][j][k].f0, "g_3887[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3945.f0, "g_3945.f0", print_hash_value);
    transparent_crc(g_3964.f0, "g_3964.f0", print_hash_value);
    transparent_crc(g_4008, "g_4008", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_4091[i].f0, "g_4091[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_4113[i][j][k].f0, "g_4113[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_4114[i][j][k].f0, "g_4114[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_4118, "g_4118", print_hash_value);
    transparent_crc(g_4155.f0, "g_4155.f0", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 1111
   depth: 1, occurrence: 63
XXX total union variables: 22

XXX non-zero bitfields defined in structs: 9
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 1
XXX volatile bitfields defined in structs: 3
XXX structs with bitfields in the program: 150
breakdown:
   indirect level: 0, occurrence: 56
   indirect level: 1, occurrence: 28
   indirect level: 2, occurrence: 22
   indirect level: 3, occurrence: 17
   indirect level: 4, occurrence: 17
   indirect level: 5, occurrence: 10
XXX full-bitfields structs in the program: 34
breakdown:
   indirect level: 0, occurrence: 34
XXX times a bitfields struct's address is taken: 50
XXX times a bitfields struct on LHS: 3
XXX times a bitfields struct on RHS: 67
XXX times a single bitfield on LHS: 10
XXX times a single bitfield on RHS: 32

XXX max expression depth: 53
breakdown:
   depth: 1, occurrence: 383
   depth: 2, occurrence: 91
   depth: 3, occurrence: 13
   depth: 4, occurrence: 6
   depth: 5, occurrence: 5
   depth: 6, occurrence: 3
   depth: 7, occurrence: 3
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 13, occurrence: 2
   depth: 14, occurrence: 2
   depth: 15, occurrence: 2
   depth: 16, occurrence: 3
   depth: 17, occurrence: 3
   depth: 18, occurrence: 3
   depth: 19, occurrence: 8
   depth: 20, occurrence: 3
   depth: 21, occurrence: 3
   depth: 23, occurrence: 1
   depth: 24, occurrence: 7
   depth: 25, occurrence: 5
   depth: 26, occurrence: 2
   depth: 27, occurrence: 6
   depth: 28, occurrence: 3
   depth: 29, occurrence: 1
   depth: 30, occurrence: 2
   depth: 31, occurrence: 6
   depth: 32, occurrence: 2
   depth: 33, occurrence: 1
   depth: 34, occurrence: 1
   depth: 37, occurrence: 1
   depth: 43, occurrence: 1
   depth: 47, occurrence: 1
   depth: 53, occurrence: 1

XXX total number of pointers: 728

XXX times a variable address is taken: 1544
XXX times a pointer is dereferenced on RHS: 838
breakdown:
   depth: 1, occurrence: 625
   depth: 2, occurrence: 131
   depth: 3, occurrence: 75
   depth: 4, occurrence: 6
   depth: 5, occurrence: 1
XXX times a pointer is dereferenced on LHS: 556
breakdown:
   depth: 1, occurrence: 489
   depth: 2, occurrence: 62
   depth: 3, occurrence: 3
   depth: 4, occurrence: 2
XXX times a pointer is compared with null: 86
XXX times a pointer is compared with address of another variable: 24
XXX times a pointer is compared with another pointer: 27
XXX times a pointer is qualified to be dereferenced: 15591

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 3151
   level: 2, occurrence: 735
   level: 3, occurrence: 584
   level: 4, occurrence: 73
   level: 5, occurrence: 31
XXX number of pointers point to pointers: 340
XXX number of pointers point to scalars: 326
XXX number of pointers point to structs: 46
XXX percent of pointers has null in alias set: 31.3
XXX average alias set size: 1.47

XXX times a non-volatile is read: 3919
XXX times a non-volatile is write: 1775
XXX times a volatile is read: 62
XXX    times read thru a pointer: 40
XXX times a volatile is write: 20
XXX    times written thru a pointer: 16
XXX times a volatile is available for access: 3.6e+03
XXX percentage of non-volatile access: 98.6

XXX forward jumps: 3
XXX backward jumps: 15

XXX stmts: 372
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 24
   depth: 1, occurrence: 29
   depth: 2, occurrence: 32
   depth: 3, occurrence: 60
   depth: 4, occurrence: 108
   depth: 5, occurrence: 119

XXX percentage a fresh-made variable is used: 17.8
XXX percentage an existing variable is used: 82.2
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

