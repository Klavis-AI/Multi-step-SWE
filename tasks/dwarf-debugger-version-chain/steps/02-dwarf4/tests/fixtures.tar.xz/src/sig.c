/* sig.c - a fault inside a signal handler: the core carries a signal frame */
#include <signal.h>
#include <stdio.h>
#include <string.h>

static int handler_inner(int v)
{
    volatile int *p = (int *) 0;
    return *p + v;
}

static void handler(int sig)
{
    printf("in handler %d\n", sig);
    fflush(stdout);
    handler_inner(sig);
}

static int raise_from(int depth)
{
    if (depth > 0) {
        return raise_from(depth - 1) + 1;
    }
    raise(SIGUSR1);
    return 0;
}

int main(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = handler;
    sigaction(SIGUSR1, &sa, 0);
    printf("sig start\n");
    fflush(stdout);
    return raise_from(3);
}
