/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --seed 100202 --max-funcs 8
 * Seed:      100202
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   uint16_t  f0;
   const uint8_t  f1;
};

/* --- GLOBAL VARIABLES --- */
static uint64_t g_6 = 1UL;
static uint16_t g_12 = 2UL;
static int32_t g_39 = (-6L);
static int64_t g_44 = 5L;
static uint64_t g_81[6][8] = {{0xDCCE65120B879B68LL,1UL,0xDCCE65120B879B68LL,0xDCCE65120B879B68LL,1UL,0xDCCE65120B879B68LL,0xDCCE65120B879B68LL,1UL},{1UL,0xDCCE65120B879B68LL,0xDCCE65120B879B68LL,1UL,0xDCCE65120B879B68LL,0xDCCE65120B879B68LL,1UL,0xDCCE65120B879B68LL},{1UL,1UL,0x543B57941993E367LL,1UL,1UL,0x543B57941993E367LL,1UL,1UL},{0xDCCE65120B879B68LL,1UL,0xDCCE65120B879B68LL,0xDCCE65120B879B68LL,1UL,0xDCCE65120B879B68LL,0xDCCE65120B879B68LL,1UL},{1UL,0xDCCE65120B879B68LL,0xDCCE65120B879B68LL,1UL,0xDCCE65120B879B68LL,0xDCCE65120B879B68LL,1UL,0xDCCE65120B879B68LL},{1UL,1UL,0x543B57941993E367LL,1UL,1UL,0x543B57941993E367LL,0xDCCE65120B879B68LL,0xDCCE65120B879B68LL}};
static uint64_t *g_95 = (void*)0;
static uint64_t *g_97 = &g_81[5][0];
static volatile union U0 g_98 = {65531UL};/* VOLATILE GLOBAL g_98 */
static int64_t g_103 = 1L;
static int16_t g_106 = 4L;
static int32_t g_126 = 0x78952EB5L;
static int32_t *g_125 = &g_126;
static int16_t g_139 = 0x1153L;
static int32_t ** volatile g_145 = &g_125;/* VOLATILE GLOBAL g_145 */
static volatile uint16_t *g_157 = &g_98.f0;
static int8_t g_162 = 1L;
static volatile uint8_t * volatile g_211 = (void*)0;/* VOLATILE GLOBAL g_211 */
static uint32_t g_214 = 0x44DF11EFL;
static volatile int32_t g_217[1][1] = {{0xB37E2C82L}};
static int16_t *g_270 = &g_106;
static int16_t **g_269[4][3][6] = {{{&g_270,&g_270,&g_270,&g_270,&g_270,&g_270},{&g_270,&g_270,&g_270,&g_270,&g_270,&g_270},{&g_270,&g_270,&g_270,&g_270,&g_270,&g_270}},{{&g_270,&g_270,&g_270,&g_270,&g_270,&g_270},{&g_270,&g_270,&g_270,&g_270,&g_270,&g_270},{&g_270,&g_270,&g_270,&g_270,&g_270,&g_270}},{{&g_270,&g_270,&g_270,&g_270,&g_270,&g_270},{&g_270,&g_270,&g_270,&g_270,&g_270,&g_270},{&g_270,&g_270,&g_270,&g_270,&g_270,&g_270}},{{&g_270,&g_270,&g_270,&g_270,&g_270,&g_270},{&g_270,&g_270,&g_270,&g_270,&g_270,&g_270},{&g_270,&g_270,&g_270,&g_270,&g_270,&g_270}}};
static int16_t ***g_268 = &g_269[2][1][1];
static int16_t ***g_271[7][1][9] = {{{&g_269[2][1][1],&g_269[2][2][5],&g_269[2][1][1],&g_269[2][1][1],&g_269[2][2][2],&g_269[2][1][1],&g_269[2][1][1],&g_269[2][2][5],&g_269[2][1][1]}},{{(void*)0,&g_269[2][1][1],&g_269[0][0][1],&g_269[2][1][1],&g_269[2][2][2],&g_269[0][1][2],&g_269[2][1][1],&g_269[2][1][1],&g_269[2][1][1]}},{{&g_269[2][1][1],&g_269[2][1][1],&g_269[2][1][1],&g_269[3][0][5],&g_269[0][0][1],&g_269[0][0][1],&g_269[3][0][5],&g_269[2][1][1],&g_269[2][1][1]}},{{(void*)0,&g_269[2][2][2],&g_269[2][1][1],&g_269[1][2][2],(void*)0,&g_269[0][0][1],&g_269[2][1][1],&g_269[0][1][2],&g_269[2][1][1]}},{{&g_269[2][1][1],&g_269[3][0][5],&g_269[2][2][2],&g_269[2][1][1],&g_269[2][1][1],&g_269[0][1][2],&g_269[2][1][1],&g_269[2][1][1],&g_269[2][2][2]}},{{&g_269[2][2][2],&g_269[2][2][2],&g_269[0][1][1],&g_269[2][1][1],&g_269[2][1][1],&g_269[2][1][1],&g_269[2][1][1],&g_269[2][1][1],(void*)0}},{{&g_269[1][2][2],&g_269[2][1][1],&g_269[2][2][5],&g_269[2][1][1],(void*)0,&g_269[2][1][1],&g_269[2][1][1],(void*)0,&g_269[2][1][1]}}};
static int8_t g_303 = 1L;
static int32_t ** volatile g_304 = &g_125;/* VOLATILE GLOBAL g_304 */
static volatile int32_t g_320 = 0x7FCBA1A6L;/* VOLATILE GLOBAL g_320 */
static int64_t g_356 = 0xD11AE85B09196A86LL;
static int64_t * const g_360 = &g_356;
static int64_t * const  volatile *g_359 = &g_360;
static int8_t *g_376 = &g_162;
static int8_t * volatile *g_375[9] = {&g_376,&g_376,&g_376,&g_376,&g_376,&g_376,&g_376,&g_376,&g_376};
static int8_t * volatile * volatile * volatile g_374 = &g_375[1];/* VOLATILE GLOBAL g_374 */
static uint32_t g_398 = 0UL;
static int64_t *g_437 = &g_356;
static int64_t **g_436 = &g_437;
static uint8_t g_469 = 0UL;
static uint8_t *g_468 = &g_469;
static volatile uint16_t g_506 = 0UL;/* VOLATILE GLOBAL g_506 */
static int32_t g_577 = (-7L);
static uint16_t g_592 = 0xFFE7L;
static uint64_t * const *g_610 = &g_97;
static uint64_t * const ** volatile g_609 = &g_610;/* VOLATILE GLOBAL g_609 */
static int32_t * volatile g_628 = &g_126;/* VOLATILE GLOBAL g_628 */
static int16_t g_681[8][9] = {{(-8L),1L,0x918CL,0x5DE5L,1L,0x918CL,0x551AL,0xC2D0L,6L},{0x9471L,0x1665L,0x918CL,(-1L),(-1L),0x918CL,0x1665L,0x9471L,6L},{0xC2D0L,0x551AL,0x918CL,1L,0x5DE5L,0x918CL,1L,(-8L),6L},{(-8L),1L,0x918CL,0x5DE5L,1L,0x918CL,0x551AL,0xC2D0L,6L},{0x9471L,0x1665L,0x918CL,(-1L),(-1L),0x918CL,0x1665L,0x9471L,1L},{0x30BEL,5L,0x5DE5L,0x3025L,0L,0x5DE5L,0x02F5L,0x5901L,1L},{0x5901L,0x02F5L,0x5DE5L,0L,0x3025L,0x5DE5L,5L,0x30BEL,1L},{0x3401L,(-1L),0x5DE5L,0L,0L,0x5DE5L,(-1L),0x3401L,1L}};
static int16_t g_684 = 0L;
static const uint8_t g_688[10][8][3] = {{{0x17L,0UL,253UL},{0xF6L,0UL,0xF6L},{0x14L,0UL,255UL},{0UL,255UL,0xBEL},{0UL,250UL,0UL},{0x7EL,0x18L,7UL},{0UL,0x2FL,9UL},{0UL,9UL,255UL}},{{0x14L,7UL,7UL},{0xF6L,0x28L,250UL},{0x17L,3UL,0x74L},{253UL,1UL,0UL},{248UL,8UL,0UL},{1UL,8UL,0xBEL},{9UL,0x98L,0x17L},{250UL,0xF4L,1UL}},{{1UL,254UL,1UL},{0UL,9UL,246UL},{0x3EL,0x14L,0xA5L},{0UL,0x7EL,0x7EL},{0UL,0x75L,8UL},{253UL,0UL,0xF0L},{255UL,0UL,253UL},{0x43L,0UL,0x27L}},{{1UL,0UL,0x17L},{0x28L,0UL,1UL},{0UL,0x75L,1UL},{2UL,0x7EL,7UL},{252UL,0x14L,250UL},{0xF0L,9UL,250UL},{255UL,254UL,255UL},{0xF6L,0xF4L,0x4CL}},{{255UL,0x98L,0x74L},{0xB8L,8UL,9UL},{1UL,8UL,0UL},{9UL,1UL,1UL},{9UL,3UL,1UL},{0UL,0x28L,1UL},{7UL,7UL,255UL},{0x4CL,9UL,0x28L}},{{250UL,0x2FL,8UL},{0UL,0x18L,0x97L},{248UL,250UL,8UL},{0xB8L,255UL,0x28L},{1UL,0UL,255UL},{0x27L,0UL,1UL},{1UL,0UL,1UL},{0UL,0x77L,1UL}},{{252UL,0x3EL,0UL},{0x97L,0x7EL,9UL},{0xA5L,0x2FL,0x74L},{0xF0L,0x35L,0x4CL},{0x14L,7UL,255UL},{0x43L,0UL,250UL},{0UL,0UL,3UL},{0xF6L,1UL,0x18L}},{{1UL,0UL,1UL},{0x7EL,0UL,0x3AL},{8UL,0xA5L,1UL},{1UL,1UL,0x1EL},{0x40L,0xF5L,254UL},{1UL,2UL,0UL},{8UL,1UL,0x86L},{0x7EL,255UL,0xAFL}},{{1UL,3UL,1UL},{0xF6L,0UL,0UL},{0UL,0x14L,255UL},{0x6CL,0UL,1UL},{7UL,255UL,1UL},{0UL,0x4CL,0xF6L},{1UL,0x2FL,0UL},{0xCFL,1UL,1UL}},{{0x17L,1UL,0x45L},{0xE8L,0x7EL,253UL},{255UL,0x40L,0x40L},{0x1EL,0UL,0x46L},{0UL,252UL,1UL},{0x27L,0UL,0x18L},{0UL,6UL,0x63L},{1UL,0UL,0xF6L}}};
static const uint8_t g_690 = 1UL;
static int64_t g_720 = 0xFD3C3772CC89E80DLL;
static volatile int64_t g_721 = 0x150021FA4D966C7FLL;/* VOLATILE GLOBAL g_721 */
static int32_t * const  volatile g_797[7][10] = {{&g_577,&g_126,&g_577,&g_577,&g_126,&g_577,&g_126,&g_577,&g_577,&g_126},{&g_577,&g_126,&g_577,&g_577,&g_126,&g_577,&g_126,&g_577,&g_577,&g_126},{&g_577,&g_126,&g_577,&g_577,&g_126,&g_577,&g_126,&g_577,&g_577,&g_126},{&g_577,&g_126,&g_577,&g_577,&g_126,&g_577,&g_126,&g_577,&g_577,&g_126},{&g_577,&g_126,&g_577,&g_577,&g_126,&g_577,&g_126,&g_577,&g_577,&g_126},{&g_577,&g_126,&g_577,&g_577,&g_126,&g_577,&g_126,&g_577,&g_577,&g_126},{&g_577,&g_126,&g_577,&g_577,&g_126,&g_577,&g_126,&g_577,&g_577,&g_126}};
static uint8_t *g_809 = (void*)0;
static int64_t g_828 = (-1L);
static int32_t * volatile g_870[3] = {(void*)0,(void*)0,(void*)0};
static int64_t g_920 = (-10L);
static union U0 g_922[8][8] = {{{65533UL},{0UL},{65533UL},{9UL},{9UL},{65533UL},{0UL},{65533UL}},{{1UL},{9UL},{65535UL},{9UL},{1UL},{1UL},{9UL},{65535UL}},{{1UL},{1UL},{9UL},{65535UL},{9UL},{1UL},{1UL},{9UL}},{{65533UL},{9UL},{9UL},{65533UL},{0UL},{65533UL},{9UL},{9UL}},{{9UL},{0UL},{65535UL},{65535UL},{0UL},{9UL},{0UL},{65535UL}},{{65535UL},{1UL},{65535UL},{65533UL},{65533UL},{65535UL},{1UL},{65535UL}},{{9UL},{65533UL},{0UL},{65533UL},{9UL},{9UL},{65533UL},{0UL}},{{9UL},{9UL},{65533UL},{0UL},{65533UL},{9UL},{9UL},{65533UL}}};
static const int8_t *****g_971[3] = {(void*)0,(void*)0,(void*)0};
static int32_t g_1014 = 0x3BA88EA6L;
static int16_t **** volatile g_1033 = &g_271[0][0][7];/* VOLATILE GLOBAL g_1033 */
static int32_t ** volatile g_1034[6][10] = {{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{(void*)0,&g_125,&g_125,&g_125,(void*)0,&g_125,&g_125,&g_125,(void*)0,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{(void*)0,&g_125,&g_125,&g_125,(void*)0,&g_125,&g_125,&g_125,(void*)0,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{(void*)0,&g_125,&g_125,&g_125,(void*)0,&g_125,&g_125,&g_125,(void*)0,&g_125}};
static int32_t ** volatile g_1035[3] = {&g_125,&g_125,&g_125};
static const int32_t ** volatile g_1064 = (void*)0;/* VOLATILE GLOBAL g_1064 */
static const int64_t *g_1097 = &g_720;
static const int64_t ** const g_1096 = &g_1097;
static const int64_t ** const *g_1095 = &g_1096;
static int32_t * const  volatile *g_1101 = (void*)0;
static int32_t * volatile g_1113 = &g_126;/* VOLATILE GLOBAL g_1113 */
static const int64_t ** const **g_1132 = (void*)0;
static int32_t *g_1162 = &g_39;
static int32_t ** volatile g_1161 = &g_1162;/* VOLATILE GLOBAL g_1161 */
static int32_t ** volatile g_1167 = &g_125;/* VOLATILE GLOBAL g_1167 */
static uint8_t g_1280 = 246UL;
static const volatile uint64_t g_1285 = 0x32FDF0BD9B604AB8LL;/* VOLATILE GLOBAL g_1285 */
static int32_t * volatile g_1308 = &g_577;/* VOLATILE GLOBAL g_1308 */
static uint8_t g_1360 = 255UL;
static int32_t * volatile g_1377[2] = {(void*)0,(void*)0};
static const int32_t *g_1412 = (void*)0;
static const int32_t ** volatile g_1411 = &g_1412;/* VOLATILE GLOBAL g_1411 */
static union U0 *g_1462 = &g_922[4][1];
static union U0 ** const  volatile g_1461[1][5][8] = {{{(void*)0,&g_1462,&g_1462,(void*)0,&g_1462,&g_1462,(void*)0,&g_1462},{(void*)0,(void*)0,&g_1462,(void*)0,(void*)0,&g_1462,(void*)0,(void*)0},{&g_1462,(void*)0,&g_1462,&g_1462,(void*)0,&g_1462,&g_1462,(void*)0},{(void*)0,&g_1462,&g_1462,(void*)0,&g_1462,&g_1462,(void*)0,&g_1462},{(void*)0,(void*)0,&g_1462,(void*)0,(void*)0,&g_1462,(void*)0,(void*)0}}};
static union U0 ** volatile g_1463 = &g_1462;/* VOLATILE GLOBAL g_1463 */
static uint32_t *g_1594 = (void*)0;
static uint32_t ** const g_1593 = &g_1594;
static uint32_t ** const * volatile g_1592 = &g_1593;/* VOLATILE GLOBAL g_1592 */
static uint8_t * volatile *g_1623 = (void*)0;
static uint8_t * volatile **g_1622 = &g_1623;
static uint8_t * volatile *** volatile g_1621 = &g_1622;/* VOLATILE GLOBAL g_1621 */
static volatile uint64_t g_1626 = 18446744073709551609UL;/* VOLATILE GLOBAL g_1626 */
static uint32_t g_1641 = 7UL;
static const uint8_t ** const ***g_1679 = (void*)0;
static int32_t g_1703 = 0L;
static union U0 ** volatile g_1764 = &g_1462;/* VOLATILE GLOBAL g_1764 */
static uint8_t ****g_1774 = (void*)0;
static int64_t ***g_1783 = &g_436;
static int64_t ****g_1782 = &g_1783;
static int64_t *****g_1781 = &g_1782;
static int32_t * volatile * volatile g_1874 = &g_1377[0];/* VOLATILE GLOBAL g_1874 */
static uint32_t **g_1896 = &g_1594;
static uint32_t ***g_1895 = &g_1896;
static volatile uint32_t **g_1911 = (void*)0;
static volatile uint32_t *** volatile g_1912[4][9] = {{&g_1911,&g_1911,&g_1911,&g_1911,&g_1911,&g_1911,&g_1911,&g_1911,&g_1911},{&g_1911,&g_1911,&g_1911,&g_1911,&g_1911,&g_1911,&g_1911,&g_1911,&g_1911},{&g_1911,&g_1911,&g_1911,&g_1911,&g_1911,&g_1911,&g_1911,&g_1911,&g_1911},{&g_1911,&g_1911,&g_1911,&g_1911,&g_1911,&g_1911,&g_1911,&g_1911,&g_1911}};
static uint32_t * const **g_1931 = (void*)0;
static int32_t ** const  volatile g_1999 = (void*)0;/* VOLATILE GLOBAL g_1999 */
static int8_t **g_2021 = &g_376;
static int8_t ** const *g_2020 = &g_2021;
static int32_t ** volatile g_2048 = (void*)0;/* VOLATILE GLOBAL g_2048 */
static int32_t ** volatile g_2049 = &g_125;/* VOLATILE GLOBAL g_2049 */
static uint8_t g_2129 = 1UL;
static union U0 **g_2199[3][10] = {{&g_1462,&g_1462,(void*)0,&g_1462,&g_1462,&g_1462,&g_1462,&g_1462,&g_1462,&g_1462},{&g_1462,&g_1462,&g_1462,&g_1462,&g_1462,&g_1462,&g_1462,&g_1462,&g_1462,&g_1462},{&g_1462,&g_1462,(void*)0,&g_1462,&g_1462,&g_1462,&g_1462,&g_1462,&g_1462,&g_1462}};
static union U0 ***g_2198[1] = {&g_2199[1][4]};
static union U0 ***g_2200 = &g_2199[2][5];
static const uint16_t g_2259 = 0xC217L;
static int32_t * volatile * volatile g_2298 = &g_125;/* VOLATILE GLOBAL g_2298 */
static int32_t * volatile * volatile * volatile g_2297 = &g_2298;/* VOLATILE GLOBAL g_2297 */
static int32_t * volatile * volatile * volatile *g_2296 = &g_2297;
static uint32_t **g_2313 = (void*)0;
static int64_t g_2422 = (-1L);
static uint32_t g_2423 = 0x0CCD4F39L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_18(uint16_t * p_19, int64_t  p_20);
static uint16_t * func_21(int64_t  p_22, int32_t  p_23, int64_t  p_24, int16_t  p_25, uint16_t * p_26);
static int16_t  func_31(int32_t  p_32);
static int32_t  func_33(int32_t  p_34, uint64_t  p_35, uint16_t  p_36, uint8_t  p_37);
static uint32_t  func_45(uint16_t  p_46, const uint32_t  p_47, uint64_t  p_48, uint32_t  p_49, const int32_t * p_50);
static int8_t  func_60(uint8_t  p_61, int32_t * p_62, uint64_t * p_63, uint32_t  p_64);
static int32_t * func_65(uint8_t  p_66, int16_t  p_67, uint16_t  p_68);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_39 g_303 g_97 g_157 g_98.f0 g_125 g_126 g_1783 g_436 g_437 g_1782 g_1097 g_720 g_2021 g_376 g_162 g_270 g_106 g_1308 g_577 g_360 g_920 g_1014 g_592 g_922.f0 g_81 g_359 g_356 g_469 g_139 g_1592 g_1593 g_688 g_2296 g_2020 g_1641 g_2297 g_2298 g_269 g_468 g_2313 g_1911 g_922.f1 g_684 g_268 g_1781 g_1095 g_1096 g_1167 g_103 g_1703 g_2422 g_2423 g_214 g_44
 * writes: g_12 g_44 g_303 g_81 g_126 g_922.f0 g_437 g_356 g_1014 g_592 g_2129 g_469 g_139 g_162 g_2313 g_1641 g_106 g_684 g_103 g_1703 g_920
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint16_t *l_11 = &g_12;
    int32_t l_13 = 1L;
    int32_t *l_38[7][8] = {{&g_39,&g_39,(void*)0,(void*)0,&g_39,&g_39,(void*)0,&g_39},{&g_39,&g_39,(void*)0,&g_39,&g_39,(void*)0,(void*)0,&g_39},{&g_39,(void*)0,(void*)0,&g_39,&g_39,&g_39,&g_39,&g_39},{(void*)0,&g_39,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_39,&g_39,(void*)0,&g_39,(void*)0,&g_39,(void*)0,&g_39},{&g_39,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_39},{(void*)0,&g_39,&g_39,&g_39,&g_39,&g_39,(void*)0,(void*)0}};
    int32_t l_40 = 0xE7359842L;
    uint32_t l_41 = 1UL;
    uint64_t *l_42 = (void*)0;
    uint64_t *l_43[7][7][5] = {{{(void*)0,&g_6,&g_6,&g_6,&g_6},{(void*)0,&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,(void*)0,&g_6},{&g_6,(void*)0,&g_6,&g_6,(void*)0},{&g_6,(void*)0,(void*)0,(void*)0,(void*)0},{&g_6,(void*)0,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,(void*)0,&g_6}},{{&g_6,&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,(void*)0,&g_6,(void*)0},{&g_6,&g_6,(void*)0,&g_6,&g_6},{(void*)0,(void*)0,(void*)0,(void*)0,&g_6},{(void*)0,(void*)0,&g_6,&g_6,&g_6}},{{&g_6,&g_6,&g_6,(void*)0,&g_6},{&g_6,&g_6,(void*)0,&g_6,&g_6},{&g_6,&g_6,(void*)0,(void*)0,&g_6},{(void*)0,&g_6,&g_6,&g_6,&g_6},{(void*)0,&g_6,(void*)0,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6,&g_6}},{{&g_6,&g_6,&g_6,&g_6,&g_6},{&g_6,(void*)0,(void*)0,(void*)0,(void*)0},{&g_6,&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,(void*)0,(void*)0,&g_6},{&g_6,&g_6,&g_6,(void*)0,&g_6},{(void*)0,&g_6,&g_6,&g_6,(void*)0},{&g_6,(void*)0,&g_6,&g_6,(void*)0}},{{(void*)0,&g_6,&g_6,(void*)0,&g_6},{&g_6,&g_6,&g_6,&g_6,&g_6},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_6,&g_6,&g_6,&g_6,&g_6},{&g_6,(void*)0,&g_6,&g_6,&g_6},{&g_6,&g_6,(void*)0,&g_6,&g_6},{(void*)0,&g_6,(void*)0,&g_6,&g_6}},{{&g_6,(void*)0,&g_6,&g_6,&g_6},{(void*)0,&g_6,&g_6,&g_6,&g_6},{&g_6,(void*)0,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6,(void*)0},{&g_6,&g_6,&g_6,&g_6,&g_6},{(void*)0,&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6,(void*)0}},{{&g_6,(void*)0,&g_6,(void*)0,(void*)0},{&g_6,(void*)0,(void*)0,&g_6,&g_6},{(void*)0,&g_6,&g_6,(void*)0,&g_6},{&g_6,(void*)0,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,(void*)0,&g_6},{(void*)0,&g_6,&g_6,(void*)0,&g_6}}};
    int32_t l_53 = 6L;
    uint16_t *l_2390 = (void*)0;
    uint16_t *l_2391 = &g_592;
    uint16_t l_2392 = 0xE263L;
    int32_t *l_2393 = &g_1703;
    uint32_t *l_2397 = &g_1641;
    int64_t *l_2419 = &g_920;
    const uint16_t l_2420[3] = {0xFEF6L,0xFEF6L,0xFEF6L};
    int32_t *l_2421 = &l_13;
    int8_t l_2424 = 0x8FL;
    int32_t *l_2425 = &g_1014;
    uint32_t l_2449 = 0xCD3F1DC3L;
    const int16_t * const l_2454 = &g_681[1][1];
    const int16_t * const *l_2453 = &l_2454;
    int16_t l_2455 = 0x3062L;
    int64_t * const **l_2456 = (void*)0;
    int64_t * const *l_2458 = &g_360;
    int64_t * const **l_2457 = &l_2458;
    int32_t l_2459 = 0xFC44F52DL;
    int8_t l_2460 = 0xEEL;
    int i, j, k;
    (*l_2393) |= ((*g_125) = (safe_add_func_int16_t_s_s((safe_lshift_func_uint16_t_u_s((g_6 , ((*l_2391) = (g_922[5][6].f0 = ((safe_add_func_uint8_t_u_u(((safe_rshift_func_uint16_t_u_u(((*l_11) = g_6), 3)) >= l_13), (safe_mul_func_uint16_t_u_u(((0xD658L && ((*g_270) = (safe_sub_func_uint8_t_u_u((l_11 == ((func_18(func_21(((*g_360) = (safe_sub_func_int32_t_s_s(((safe_lshift_func_int16_t_s_u(func_31(func_33((l_40 = g_6), (g_44 = l_41), g_39, (func_45((safe_lshift_func_int8_t_s_u((0L <= l_53), 2)), g_6, g_39, g_6, &g_39) & l_41))), 12)) , l_40), l_53))), g_920, l_53, l_53, l_11), l_41) <= l_13) , &g_2259)), 0L)))) == l_41), 0x171AL)))) | 0xAFL)))), l_53)), l_2392)));
    (*l_2425) ^= (safe_mod_func_int8_t_s_s(((**g_2021) = ((*l_2393) & (((((~(*g_157)) == ((((l_2397 != ((*l_2393) , l_38[3][2])) , ((safe_mod_func_uint64_t_u_u(((!(*l_2393)) | ((~(safe_div_func_uint16_t_u_u(((((safe_sub_func_int16_t_s_s((safe_unary_minus_func_uint64_t_u((*l_2393))), ((((((safe_lshift_func_uint16_t_u_s((((safe_mod_func_int64_t_s_s(((safe_rshift_func_uint8_t_u_s(((((*l_2421) = ((*g_125) = (((safe_mul_func_int16_t_s_s(((*l_2393) , ((safe_mul_func_int16_t_s_s(((((safe_add_func_int64_t_s_s(((*l_2419) = ((****g_1782) = 6L)), (*l_2393))) && (*l_2393)) | (*l_2393)) & (*g_270)), 0xF314L)) ^ 253UL)), l_2420[1])) != (*l_2393)) >= (*l_2393)))) , 0xBEB66CE235BBF772LL) == 18446744073709551607UL), (***g_2020))) , (*l_2393)), 1L)) , g_2422) , g_2423), l_2424)) && (*l_2393)) , 0xCBD8L) <= g_214) >= g_44) & 0xDF2468A31390052BLL))) != (*l_2393)) , 0xBB44L) >= (***g_268)), (-9L)))) && (*g_376))), (*l_2393))) | (*g_468))) || 0xD957L) , (*l_2421))) || (*g_97)) != (*l_2393)) >= (*l_2393)))), (*l_2393)));
    (*l_2425) = (safe_mod_func_int8_t_s_s((safe_mod_func_int16_t_s_s((safe_mod_func_int64_t_s_s((safe_add_func_uint16_t_u_u(((safe_div_func_int32_t_s_s((safe_sub_func_uint16_t_u_u((((((*l_2457) = ((safe_mul_func_int8_t_s_s(((***g_268) , (~(+(3L || (!(safe_mod_func_uint8_t_u_u((*l_2425), (safe_mul_func_uint16_t_u_u(((*l_2391) = ((safe_rshift_func_uint8_t_u_s(((l_2449 >= 0xB4L) >= 1UL), ((safe_add_func_uint16_t_u_u((*g_157), (((((!1UL) , l_2453) != (*g_268)) <= (*l_2425)) >= (*g_270)))) , (**g_2021)))) & l_2455)), 0x61E1L))))))))), (*l_2421))) , (*g_1783))) == (*g_1783)) && (**g_436)) == (*l_2421)), (*l_2421))), l_2459)) ^ (*l_2393)), 0x6AFEL)), (*l_2425))), 0x1E16L)), l_2460));
    return (*l_2425);
}


/* ------------------------------------------ */
/* 
 * reads : g_684 g_268 g_269 g_270 g_106 g_125 g_126 g_592 g_157 g_98.f0 g_1781 g_1782 g_1783 g_436 g_437 g_356 g_1095 g_1096 g_1097 g_720 g_468 g_469 g_1167 g_922.f0 g_97 g_81 g_359 g_360 g_1592 g_1593 g_688 g_2296 g_2020 g_2021 g_376 g_1641 g_2297 g_2298 g_2313 g_1911 g_922.f1 g_103
 * writes: g_684 g_592 g_126 g_106 g_1014 g_922.f0 g_2129 g_469 g_139 g_162 g_2313 g_1641 g_103
 */
static int32_t  func_18(uint16_t * p_19, int64_t  p_20)
{ /* block id: 1036 */
    int32_t l_2328 = 1L;
    uint8_t l_2343 = 0x61L;
    int32_t l_2350 = 0L;
    int32_t l_2351[3][3];
    uint32_t l_2352 = 0xCAA50289L;
    int32_t **l_2363[4][7] = {{&g_1162,(void*)0,(void*)0,(void*)0,&g_1162,&g_1162,(void*)0},{&g_1162,&g_1162,&g_1162,(void*)0,(void*)0,&g_1162,&g_1162},{(void*)0,&g_1162,(void*)0,(void*)0,&g_1162,(void*)0,&g_1162},{&g_1162,(void*)0,(void*)0,&g_1162,&g_1162,&g_1162,(void*)0}};
    uint16_t *l_2383 = &g_922[5][6].f0;
    uint16_t *l_2384[7] = {&g_592,&g_592,&g_592,&g_592,&g_592,&g_592,&g_592};
    int i, j;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
            l_2351[i][j] = 1L;
    }
    for (g_684 = 0; (g_684 != 3); ++g_684)
    { /* block id: 1039 */
        int32_t l_2325 = 0x40B5EBE3L;
        int16_t l_2342 = 0x375FL;
        int32_t l_2344 = 4L;
        (*g_125) ^= (safe_rshift_func_int8_t_s_u((((-10L) < ((((void*)0 == p_19) ^ ((l_2325 >= ((*p_19) = (p_20 ^ ((~p_20) ^ (safe_unary_minus_func_uint64_t_u(0x9F5D49091EDA5D48LL)))))) , (0x1DEC7084L != (p_20 <= (***g_268))))) <= 5UL)) >= l_2325), l_2328));
        l_2344 = ((safe_sub_func_int64_t_s_s(((safe_div_func_uint64_t_u_u((safe_unary_minus_func_int8_t_s(p_20)), (safe_rshift_func_int16_t_s_s(((*g_270) = p_20), 11)))) != l_2325), (safe_add_func_uint32_t_u_u((p_20 , (p_20 != (safe_add_func_int32_t_s_s(l_2328, (l_2325 && (((safe_lshift_func_uint16_t_u_u(((l_2342 , (*p_19)) , (*p_19)), (*g_157))) <= (-1L)) == l_2342)))))), l_2343)))) != 0x2FL);
    }
    if (((*****g_1781) , l_2343))
    { /* block id: 1045 */
        int32_t *l_2345 = &g_1703;
        int32_t *l_2346 = &g_1014;
        int32_t *l_2347 = &g_126;
        int32_t *l_2348 = (void*)0;
        int32_t *l_2349[3];
        int i;
        for (i = 0; i < 3; i++)
            l_2349[i] = &g_1014;
        ++l_2352;
    }
    else
    { /* block id: 1047 */
        uint8_t l_2378 = 248UL;
        int32_t l_2379[1][6];
        int8_t l_2387 = 3L;
        int i, j;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 6; j++)
                l_2379[i][j] = 0L;
        }
        for (g_126 = 0; (g_126 > (-4)); g_126 = safe_sub_func_uint8_t_u_u(g_126, 8))
        { /* block id: 1050 */
            const uint8_t l_2367 = 1UL;
            l_2379[0][5] = (l_2343 ^ (safe_sub_func_uint32_t_u_u((safe_sub_func_int16_t_s_s((safe_lshift_func_uint8_t_u_s(((l_2363[1][0] != (void*)0) , (safe_unary_minus_func_int16_t_s(((*p_19) == (safe_add_func_int64_t_s_s((***g_1095), l_2367)))))), 4)), (safe_mod_func_int64_t_s_s(((safe_mod_func_uint16_t_u_u(((safe_rshift_func_uint16_t_u_s(65535UL, 15)) ^ (-6L)), (safe_lshift_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_s(0x39L, p_20)) , l_2378), (*g_468))))) ^ 0UL), 0x3D92FF0CECDE521BLL)))), 1UL)));
        }
        l_2387 &= (~(p_20 | (safe_add_func_uint32_t_u_u((l_2383 == (l_2384[5] = func_21((**g_1096), (**g_1167), (*g_1097), p_20, &g_592))), (safe_lshift_func_uint8_t_u_u(p_20, 4))))));
        for (g_103 = 0; (g_103 == (-9)); g_103 = safe_sub_func_uint64_t_u_u(g_103, 2))
        { /* block id: 1057 */
            return p_20;
        }
    }
    return p_20;
}


/* ------------------------------------------ */
/* 
 * reads : g_1014 g_592 g_922.f0 g_157 g_98.f0 g_97 g_81 g_359 g_360 g_356 g_125 g_126 g_469 g_139 g_162 g_1592 g_1593 g_688 g_2296 g_2020 g_2021 g_376 g_1641 g_2297 g_2298 g_269 g_468 g_2313 g_1911 g_922.f1 g_437 g_270
 * writes: g_1014 g_592 g_922.f0 g_2129 g_126 g_469 g_139 g_162 g_2313 g_1641 g_106
 */
static uint16_t * func_21(int64_t  p_22, int32_t  p_23, int64_t  p_24, int16_t  p_25, uint16_t * p_26)
{ /* block id: 945 */
    int16_t l_2125 = 0L;
    int32_t l_2126 = 1L;
    uint64_t l_2138[9] = {18446744073709551607UL,18446744073709551607UL,18446744073709551607UL,18446744073709551607UL,18446744073709551607UL,18446744073709551607UL,18446744073709551607UL,18446744073709551607UL,18446744073709551607UL};
    uint8_t *l_2139 = &g_1360;
    int32_t l_2151 = 0x3835B051L;
    int32_t l_2152[4][7][5] = {{{(-1L),(-2L),(-9L),1L,8L},{0xC925BA6DL,0xB06DE14BL,(-2L),0L,(-1L)},{0x3F6355FCL,(-4L),0xEC7B29D5L,0x615663EBL,0L},{0xEB51F844L,0xDC8E4014L,0x6F6049B1L,(-5L),0xC925BA6DL},{1L,8L,1L,0x45398F29L,(-7L)},{0x3F6355FCL,0L,(-7L),0L,1L},{0xB06DE14BL,1L,0xC925BA6DL,(-1L),(-9L)}},{{4L,(-8L),0L,(-8L),4L},{0x80AD20DCL,(-5L),(-1L),(-7L),0x46D3D0A2L},{1L,0L,8L,0xEB51F844L,(-8L)},{8L,0x72062039L,0L,(-5L),0x46D3D0A2L},{0x6CD090F0L,0xEB51F844L,8L,(-1L),4L},{0x46D3D0A2L,0xDC8E4014L,0x72062039L,0L,(-9L)},{0x253F7EAEL,0xC77E130DL,(-9L),(-7L),1L}},{{1L,0x45398F29L,(-1L),0x80AD20DCL,1L},{1L,0xEC7B29D5L,0x6F6049B1L,(-2L),(-1L)},{0x253F7EAEL,(-7L),0L,(-4L),0L},{0x46D3D0A2L,0x46D3D0A2L,(-7L),(-9L),0xC925BA6DL},{0x6CD090F0L,(-1L),0x27C4DDC1L,(-7L),0L},{8L,0x253F7EAEL,0xEC7B29D5L,1L,(-7L)},{1L,(-1L),0L,0xDC8E4014L,0x5C9A53A8L}},{{0x80AD20DCL,0x46D3D0A2L,0xDC8E4014L,0x72062039L,0L},{4L,(-7L),1L,0x6F6049B1L,0x615663EBL},{0xB06DE14BL,0xEC7B29D5L,0x3FC420B4L,0x6CD090F0L,8L},{0x3F6355FCL,0x45398F29L,0x3FC420B4L,(-1L),0x80AD20DCL},{0L,0xC77E130DL,1L,0x3F6355FCL,0x6BF71778L},{0xC77E130DL,0xDC8E4014L,0xDC8E4014L,0xC77E130DL,0x6CD090F0L},{(-2L),0xEB51F844L,0L,0L,1L}}};
    int16_t ***l_2170 = &g_269[2][0][4];
    uint64_t l_2185[3];
    union U0 **l_2196[4][4] = {{&g_1462,&g_1462,&g_1462,&g_1462},{&g_1462,&g_1462,&g_1462,&g_1462},{&g_1462,&g_1462,&g_1462,&g_1462},{&g_1462,&g_1462,&g_1462,&g_1462}};
    union U0 ***l_2195 = &l_2196[0][2];
    int32_t ***l_2205[2];
    int8_t ***l_2223 = &g_2021;
    uint8_t **l_2265 = &g_809;
    uint8_t ***l_2264[4][10] = {{&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265},{&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265},{&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265},{&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265,&l_2265}};
    uint8_t ****l_2263 = &l_2264[2][7];
    uint32_t l_2285 = 18446744073709551609UL;
    int16_t **l_2306 = &g_270;
    uint32_t ***l_2314 = &g_2313;
    int8_t l_2315 = (-2L);
    uint32_t *l_2316 = (void*)0;
    uint32_t *l_2317 = &g_1641;
    const int64_t l_2318 = (-1L);
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_2185[i] = 0x743FD0416CBB4D05LL;
    for (i = 0; i < 2; i++)
        l_2205[i] = (void*)0;
    for (g_1014 = 7; (g_1014 >= 0); g_1014 -= 1)
    { /* block id: 948 */
        uint32_t l_2123[6];
        int32_t l_2124 = 0L;
        uint8_t *l_2140 = &g_469;
        int16_t l_2141 = 2L;
        int32_t *l_2142 = &l_2126;
        int32_t *l_2143 = &g_1703;
        int32_t *l_2144 = &g_126;
        int32_t *l_2145 = &g_1703;
        int32_t *l_2146 = &g_577;
        int32_t *l_2147 = &l_2126;
        int32_t *l_2148 = &l_2124;
        int32_t *l_2149 = &g_126;
        int32_t *l_2150[10] = {&l_2124,&l_2124,&l_2124,&l_2124,&l_2124,&l_2124,&l_2124,&l_2124,&l_2124,&l_2124};
        uint32_t l_2153 = 9UL;
        int16_t **l_2164 = &g_270;
        int32_t **l_2219 = &g_1162;
        int8_t *l_2282 = &g_162;
        int i;
        for (i = 0; i < 6; i++)
            l_2123[i] = 0xA93BE1BCL;
        (*g_125) |= ((safe_add_func_uint8_t_u_u((((safe_sub_func_uint32_t_u_u(((l_2140 = ((((safe_add_func_uint64_t_u_u((safe_mod_func_uint16_t_u_u((g_592--), (p_25 , (safe_add_func_int32_t_s_s((0x6B7DC135L < ((safe_rshift_func_uint16_t_u_u((((safe_unary_minus_func_uint16_t_u((l_2123[0] &= (g_922[5][6].f0++)))) == l_2124) > ((l_2126 = l_2125) || (safe_sub_func_uint16_t_u_u((0xE6L & (g_2129 = p_22)), (safe_rshift_func_uint16_t_u_s((((safe_lshift_func_uint8_t_u_u(((safe_sub_func_uint16_t_u_u((*g_157), ((-1L) || (safe_rshift_func_uint8_t_u_s(((*g_97) <= p_25), 2))))) || l_2138[8]), 2)) ^ 0xECADL) <= 0x5E112E36L), l_2124)))))), 13)) == l_2124)), p_24))))), p_23)) && p_22) >= (**g_359)) , l_2139)) != (void*)0), l_2124)) && 0xABL) | 0x0537L), l_2141)) && l_2141);
        l_2153--;
        for (g_469 = 0; (g_469 <= 7); g_469 += 1)
        { /* block id: 959 */
            int16_t ***l_2156 = &g_269[1][2][2];
            int16_t ****l_2157 = &g_268;
            int16_t l_2169 = 0xA081L;
            int32_t ***l_2171 = (void*)0;
            int32_t l_2173[1][7] = {{0xADAE8C9FL,0x690F1D89L,0xADAE8C9FL,0xADAE8C9FL,0x690F1D89L,0xADAE8C9FL,0xADAE8C9FL}};
            const int8_t *l_2283 = &g_303;
            int i, j;
        }
    }
    for (g_139 = 0; (g_139 == 12); g_139 = safe_add_func_int32_t_s_s(g_139, 6))
    { /* block id: 1019 */
        union U0 l_2295[4] = {{0x5D56L},{0x5D56L},{0x5D56L},{0x5D56L}};
        int32_t l_2299 = 0x83CBDCB8L;
        int i;
        for (g_162 = 0; (g_162 <= 10); ++g_162)
        { /* block id: 1022 */
            if (p_22)
                break;
        }
        (*g_125) = (((void*)0 != (*g_1592)) | ((g_688[6][7][0] & (safe_mul_func_uint8_t_u_u((l_2295[1] , 0x1EL), ((g_2296 == (void*)0) & ((l_2299 &= ((***g_2020) = 0xA7L)) , 0x39L))))) & g_1641));
    }
    (****g_2296) ^= (-3L);
    p_23 ^= (safe_sub_func_int16_t_s_s(((*g_270) = ((*g_157) >= (!(((~((safe_lshift_func_int8_t_s_u(((((*l_2170) != (l_2306 = (*l_2170))) , (safe_rshift_func_int16_t_s_u(((*g_468) ^ ((-7L) > (((*l_2317) = (((((0UL | (p_25 , (safe_mod_func_uint16_t_u_u(0x6F26L, (safe_rshift_func_int16_t_s_u((((*l_2314) = g_2313) != g_1911), 6)))))) < l_2315) >= 0xDE09C777L) == 0x15L) & p_22)) && l_2318))), 0))) != (-1L)), 6)) > (*g_360))) | g_922[5][6].f1) || (*g_437))))), 0UL));
    return &g_592;
}


/* ------------------------------------------ */
/* 
 * reads : g_1783 g_436 g_437 g_1782 g_1097 g_720 g_2021 g_376 g_162 g_270 g_106 g_1308 g_577 g_125
 * writes: g_922.f0 g_437 g_126
 */
static int16_t  func_31(int32_t  p_32)
{ /* block id: 938 */
    int32_t l_2084 = 8L;
    union U0 l_2085 = {1UL};
    int32_t l_2102[10] = {1L,1L,1L,1L,1L,1L,1L,1L,1L,1L};
    uint32_t l_2103[10] = {4UL,0x10D0A6F8L,4UL,4UL,0x10D0A6F8L,4UL,4UL,0x10D0A6F8L,4UL,4UL};
    uint64_t l_2104[3][3] = {{0UL,0UL,0UL},{0x41BC36AF1AF97ADELL,0x41BC36AF1AF97ADELL,0x41BC36AF1AF97ADELL},{0UL,0UL,0UL}};
    uint8_t l_2105 = 0xC4L;
    int i, j;
    (*g_125) = (((safe_div_func_uint16_t_u_u(((safe_rshift_func_int16_t_s_s((safe_mod_func_int64_t_s_s((((l_2102[4] = ((safe_add_func_int8_t_s_s((l_2084 != (g_922[5][6].f0 = 0x5169L)), (((l_2085 , (!(!((l_2085 , (void*)0) == ((***g_1782) = (**g_1783)))))) & (safe_mod_func_int64_t_s_s((safe_lshift_func_uint16_t_u_u(p_32, (safe_sub_func_uint16_t_u_u(((safe_mod_func_int32_t_s_s((safe_div_func_uint64_t_u_u(((safe_mul_func_int8_t_s_s(((*g_1097) <= (safe_add_func_int8_t_s_s(((**g_2021) < 9L), l_2084))), (-1L))) != p_32), l_2084)), l_2084)) , 65531UL), 65533UL)))), 1UL))) && l_2085.f1))) && 0x461736A3L)) < l_2085.f0) || (*g_270)), p_32)), 10)) & l_2103[5]), p_32)) == l_2104[0][2]) , (*g_1308));
    return l_2105;
}


/* ------------------------------------------ */
/* 
 * reads : g_303 g_97 g_157 g_98.f0 g_125 g_126
 * writes: g_303 g_81 g_126
 */
static int32_t  func_33(int32_t  p_34, uint64_t  p_35, uint16_t  p_36, uint8_t  p_37)
{ /* block id: 815 */
    int16_t l_1834[9] = {0x9BD8L,0x0A9AL,0x9BD8L,0x0A9AL,0x9BD8L,0x0A9AL,0x9BD8L,0x0A9AL,0x9BD8L};
    uint8_t *****l_1845 = &g_1774;
    int32_t l_1856 = 0x2E0BAEA6L;
    int32_t l_1862 = 0xE9F2D704L;
    int32_t l_1865 = 0L;
    int32_t l_1866 = (-3L);
    int32_t l_1867 = 0x41C3A515L;
    int32_t l_1869[6][3] = {{0xD8D8ECEEL,0xD8D8ECEEL,0L},{0xD8D8ECEEL,0xD8D8ECEEL,0L},{0xD8D8ECEEL,0xD8D8ECEEL,0L},{0xD8D8ECEEL,0xD8D8ECEEL,0L},{0xD8D8ECEEL,0xD8D8ECEEL,0L},{0xD8D8ECEEL,0xD8D8ECEEL,0L}};
    int8_t l_1870[2][9][6] = {{{(-4L),0x6DL,0L,0xD7L,0xD7L,0L},{(-4L),(-4L),0xD7L,(-1L),4L,(-1L)},{0x6DL,(-4L),0x6DL,0L,0xD7L,0xD7L},{0xB3L,0x6DL,0x6DL,0xB3L,(-4L),(-1L)},{(-1L),0xB3L,0xD7L,0xB3L,(-1L),0L},{0xB3L,(-1L),0L,0L,(-1L),0xB3L},{0x6DL,0xB3L,(-4L),(-1L),(-4L),0xB3L},{(-4L),0x6DL,0L,0xD7L,0xD7L,0L},{(-4L),(-4L),0xD7L,(-1L),4L,(-1L)}},{{0x6DL,(-4L),0x6DL,0L,0xD7L,0xD7L},{0xB3L,0x6DL,0x6DL,0xB3L,(-4L),(-1L)},{(-1L),0xB3L,0xD7L,0xB3L,(-1L),0L},{0xB3L,(-1L),0L,0L,(-1L),0xB3L},{0x6DL,0xB3L,(-4L),(-1L),(-4L),0xB3L},{(-4L),0x6DL,0L,0xD7L,0xD7L,0L},{(-4L),(-4L),0xD7L,(-1L),4L,(-1L)},{0x6DL,(-4L),0x6DL,0L,0xD7L,0xD7L},{0xB3L,0x6DL,0x6DL,0xB3L,(-4L),(-1L)}}};
    union U0 l_1882[1][6][2] = {{{{9UL},{9UL}},{{0x2075L},{9UL}},{{9UL},{0x2075L}},{{9UL},{9UL}},{{0x2075L},{9UL}},{{9UL},{0x2075L}}}};
    int8_t **l_1909 = (void*)0;
    int8_t ***l_1908[7][2] = {{&l_1909,&l_1909},{&l_1909,&l_1909},{&l_1909,&l_1909},{&l_1909,&l_1909},{&l_1909,&l_1909},{&l_1909,&l_1909},{&l_1909,&l_1909}};
    uint64_t l_1934[8] = {18446744073709551612UL,18446744073709551612UL,18446744073709551612UL,18446744073709551612UL,18446744073709551612UL,18446744073709551612UL,18446744073709551612UL,18446744073709551612UL};
    uint32_t l_2059 = 0UL;
    uint32_t l_2075 = 7UL;
    int i, j, k;
    for (g_303 = 0; (g_303 > 4); g_303++)
    { /* block id: 818 */
        uint64_t l_1799[2];
        int32_t l_1800 = 0x4BAEAE8AL;
        uint32_t l_1832 = 0UL;
        int16_t *l_1840 = &g_681[4][4];
        int32_t l_1857 = 0xA04FC209L;
        int32_t l_1858 = 0xDAE0E5ECL;
        int32_t l_1860[5][1][5] = {{{0x2553808AL,1L,1L,0x2553808AL,0x2553808AL}},{{4L,1L,4L,1L,4L}},{{0x2553808AL,0x2553808AL,1L,1L,0x2553808AL}},{{0xF73BB091L,1L,0xF73BB091L,1L,0xF73BB091L}},{{0x2553808AL,1L,1L,0x2553808AL,0x2553808AL}}};
        int16_t l_1875 = 0x3E15L;
        uint32_t ***l_1897 = &g_1896;
        int64_t l_1928 = (-4L);
        int16_t l_1961[3][4][9];
        uint32_t l_1963 = 0x48D8D80DL;
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_1799[i] = 18446744073709551615UL;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 4; j++)
            {
                for (k = 0; k < 9; k++)
                    l_1961[i][j][k] = 1L;
            }
        }
    }
    (*g_125) ^= (((safe_div_func_uint64_t_u_u((((((+(((safe_rshift_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u(l_1866, (safe_rshift_func_int16_t_s_s(l_2059, (((safe_mul_func_uint16_t_u_u((p_37 , (((*g_97) = ((safe_mul_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_s(((safe_mul_func_int8_t_s_s(0xE3L, ((safe_sub_func_int16_t_s_s(l_1882[0][3][1].f0, (safe_lshift_func_int16_t_s_s((0x678FD7F9ACD8F425LL > p_34), ((!(-8L)) <= ((safe_sub_func_uint64_t_u_u(l_1870[0][0][3], p_34)) ^ l_2059)))))) & l_1870[1][6][4]))) < 0x15L), l_1866)), p_35)) != p_34)) <= 0xB9ED296334703BE0LL)), l_1834[2])) == p_37) == (-9L)))))), p_37)) , p_36) <= l_2075)) | (-1L)) & l_1856) && 0xE72FB430F5D47B4ALL) > p_34), l_1870[0][0][4])) <= (*g_157)) ^ p_37);
    return l_1865;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint32_t  func_45(uint16_t  p_46, const uint32_t  p_47, uint64_t  p_48, uint32_t  p_49, const int32_t * p_50)
{ /* block id: 4 */
    uint32_t l_56 = 0x883CE717L;
    int32_t * const l_59 = &g_39;
    uint64_t *l_573[2];
    int16_t *l_751 = &g_681[5][3];
    int32_t *l_753 = &g_577;
    uint16_t *l_781[4];
    int64_t *l_788[7] = {&g_720,&g_720,&g_720,&g_720,&g_720,&g_720,&g_720};
    uint32_t *l_789[5][6] = {{&l_56,&g_214,&g_214,&l_56,(void*)0,&l_56},{&l_56,(void*)0,&l_56,&g_214,&g_214,&l_56},{(void*)0,(void*)0,&g_214,(void*)0,&g_214,(void*)0},{&g_214,(void*)0,(void*)0,(void*)0,(void*)0,&g_214},{(void*)0,&g_214,(void*)0,&g_214,(void*)0,(void*)0}};
    int32_t l_794[3];
    const int64_t l_889 = 0x59ABE11C411532CDLL;
    int32_t l_898 = (-8L);
    union U0 *l_928 = &g_922[0][2];
    int64_t ***l_988 = &g_436;
    int64_t ****l_987 = &l_988;
    uint16_t l_997 = 0xF6D7L;
    uint32_t l_998 = 0x47DE28E0L;
    uint16_t l_1052[10][10] = {{0xE120L,0x3661L,2UL,0xE120L,0x11B1L,0xB92FL,0x3661L,0x3661L,0xB92FL,0x11B1L},{0xE120L,5UL,5UL,0xE120L,65535UL,0x688EL,0x3661L,5UL,0x688EL,0x11B1L},{0x688EL,0x3661L,5UL,0x688EL,0x11B1L,0x688EL,5UL,0x3661L,0x688EL,65535UL},{0xE120L,0x3661L,2UL,0xE120L,0x11B1L,0xB92FL,0x3661L,0x3661L,0xB92FL,0x11B1L},{0xE120L,5UL,5UL,0xE120L,65535UL,0x688EL,0x3661L,5UL,0x688EL,0x11B1L},{0x688EL,0x3661L,5UL,0x688EL,0x11B1L,0x688EL,5UL,0x3661L,0x688EL,65535UL},{0xE120L,0x3661L,2UL,0xE120L,0x11B1L,0xB92FL,0x3661L,0x3661L,0xB92FL,0x11B1L},{0xE120L,5UL,5UL,0xE120L,65535UL,0x688EL,0x3661L,5UL,0x688EL,0x11B1L},{0x688EL,0x3661L,5UL,0x688EL,0x11B1L,0x688EL,5UL,0x3661L,0x688EL,65535UL},{0xE120L,0x3661L,2UL,0xE120L,0x11B1L,0xB92FL,0x3661L,0x3661L,0xB92FL,0x11B1L}};
    uint32_t l_1085 = 0xAC509707L;
    int8_t **l_1129 = &g_376;
    int8_t ** const *l_1128 = &l_1129;
    int8_t ** const ** const l_1127 = &l_1128;
    int32_t * const l_1166 = (void*)0;
    int8_t l_1177 = (-3L);
    uint16_t * const l_1222[6] = {&g_592,&g_592,&g_592,&g_592,&g_592,&g_592};
    int32_t *l_1283[8][5][1] = {{{&l_898},{&l_898},{&l_898},{&l_898},{&l_898}},{{&g_39},{&g_39},{&l_898},{&l_898},{&l_898}},{{&l_898},{&l_898},{&l_898},{&l_898},{&g_39}},{{&g_39},{&g_39},{&l_898},{&l_898},{&g_39}},{{&l_898},{&l_898},{&g_39},{&g_39},{&g_39}},{{&g_39},{&l_898},{&l_898},{&g_39},{&l_898}},{{&l_898},{&g_39},{&g_39},{&g_39},{&g_39}},{{&l_898},{&l_898},{&g_39},{&l_898},{&l_898}}};
    uint8_t l_1332 = 0x7BL;
    int8_t l_1348[3];
    int32_t l_1509 = 0x0C917B49L;
    int8_t l_1633 = 0x0EL;
    const uint8_t *l_1677[5];
    const uint8_t **l_1676 = &l_1677[0];
    const uint8_t *** const l_1675 = &l_1676;
    const uint8_t *** const *l_1674 = &l_1675;
    const uint8_t *** const **l_1673[8] = {&l_1674,&l_1674,&l_1674,&l_1674,&l_1674,&l_1674,&l_1674,&l_1674};
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_573[i] = &g_6;
    for (i = 0; i < 4; i++)
        l_781[i] = &g_592;
    for (i = 0; i < 3; i++)
        l_794[i] = 0x0558820FL;
    for (i = 0; i < 3; i++)
        l_1348[i] = 0x32L;
    for (i = 0; i < 5; i++)
        l_1677[i] = (void*)0;
    return p_46;
}


/* ------------------------------------------ */
/* 
 * reads : g_214 g_126 g_81 g_98.f1 g_609 g_162 g_628 g_469 g_6 g_360 g_356 g_157 g_98.f0 g_374 g_375 g_376 g_97 g_681 g_106
 * writes: g_214 g_126 g_592 g_610 g_162 g_469 g_81 g_684
 */
static int8_t  func_60(uint8_t  p_61, int32_t * p_62, uint64_t * p_63, uint32_t  p_64)
{ /* block id: 265 */
    uint64_t l_578[6][1];
    int8_t l_611 = 1L;
    int32_t l_612 = 0x99B5B4CDL;
    int32_t l_613 = 2L;
    int32_t l_616 = 0xA6E8B9E0L;
    int32_t l_617 = 0x56791202L;
    int32_t l_619 = 0xF0F3C961L;
    int32_t l_620 = (-8L);
    int16_t ***l_643 = &g_269[2][1][1];
    uint32_t l_652 = 5UL;
    uint8_t *l_658 = &g_469;
    const uint8_t *l_689 = &g_690;
    int8_t l_691 = 1L;
    int32_t l_709 = 0xE871E28DL;
    int32_t l_714[10][2] = {{0xB40560D2L,1L},{0L,0L},{0L,0L},{0L,1L},{0L,0L},{0L,0L},{0L,1L},{0xB40560D2L,0xB40560D2L},{0L,0xB40560D2L},{0xB40560D2L,1L}};
    int32_t l_722[4];
    uint64_t l_728 = 0UL;
    int i, j;
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 1; j++)
            l_578[i][j] = 2UL;
    }
    for (i = 0; i < 4; i++)
        l_722[i] = 0L;
    for (g_214 = 0; (g_214 >= 57); g_214 = safe_add_func_int64_t_s_s(g_214, 9))
    { /* block id: 268 */
        const uint64_t *l_584 = &g_81[1][2];
        const uint64_t **l_583[7] = {&l_584,&l_584,&l_584,&l_584,&l_584,&l_584,&l_584};
        int32_t l_587 = 0x9572D00FL;
        uint16_t l_599 = 0x9893L;
        uint64_t * const *l_608 = (void*)0;
        int32_t l_618 = 0xF6559CCFL;
        uint64_t l_622 = 0UL;
        uint16_t l_680[2][5][3] = {{{0UL,0x6CBAL,0x6CBAL},{0x820FL,0xBA2BL,0xBA2BL},{0UL,0x6CBAL,0x6CBAL},{0x820FL,0xBA2BL,0xBA2BL},{0UL,0x6CBAL,0x6CBAL}},{{0x820FL,0xBA2BL,0xBA2BL},{0UL,0x6CBAL,0x6CBAL},{0x820FL,0xBA2BL,0xBA2BL},{0UL,0x6CBAL,0x6CBAL},{0x820FL,0xBA2BL,0xBA2BL}}};
        const uint8_t *l_687 = &g_688[5][0][0];
        int32_t l_704 = 1L;
        int32_t l_708 = 0xB7E22BB5L;
        int32_t l_710 = 0xD28D076BL;
        int32_t l_711[6][1][5] = {{{1L,(-1L),0x3F1DB46FL,0x7E62F09FL,0x3F1DB46FL}},{{7L,7L,0xB17F939CL,7L,7L}},{{0x3F1DB46FL,0x7E62F09FL,0x3F1DB46FL,(-1L),1L}},{{7L,0x25BE46B3L,0x25BE46B3L,7L,0x25BE46B3L}},{{1L,0x7E62F09FL,0x5B4E1015L,0x7E62F09FL,1L}},{{0x25BE46B3L,7L,0x25BE46B3L,0x25BE46B3L,7L}}};
        int32_t l_719 = 1L;
        int i, j, k;
        for (p_61 = 0; (p_61 <= 0); p_61 += 1)
        { /* block id: 271 */
            uint16_t l_600 = 0UL;
            int32_t l_602 = 0L;
            int32_t l_603 = 0xE9260B8BL;
            int32_t l_615[9];
            int8_t l_703[3];
            int32_t l_718 = 0L;
            int16_t l_724 = 0x432EL;
            uint8_t l_725 = 253UL;
            int i;
            for (i = 0; i < 9; i++)
                l_615[i] = (-8L);
            for (i = 0; i < 3; i++)
                l_703[i] = (-5L);
            for (g_126 = 4; (g_126 >= 1); g_126 -= 1)
            { /* block id: 274 */
                int32_t *l_576[10][2][3] = {{{&g_126,&g_126,&g_126},{&g_126,&g_577,&g_577}},{{&g_126,&g_126,&g_126},{&g_126,&g_577,&g_577}},{{&g_126,&g_126,&g_577},{&g_126,&g_577,&g_126}},{{&g_126,&g_126,&g_577},{&g_126,&g_126,&g_577}},{{&g_126,&g_126,&g_126},{&g_577,&g_577,&g_577}},{{&g_126,&g_126,&g_126},{&g_126,&g_577,&g_577}},{{&g_126,&g_126,&g_126},{&g_126,&g_577,&g_577}},{{&g_126,&g_126,&g_577},{&g_126,&g_577,&g_126}},{{&g_126,&g_126,&g_577},{&g_126,&g_126,&g_577}},{{&g_126,&g_126,&g_126},{&g_577,&g_577,&g_577}}};
                uint16_t l_601 = 0x2269L;
                int i, j, k;
                --l_578[4][0];
                if (g_81[g_126][(p_61 + 5)])
                { /* block id: 276 */
                    int32_t l_590 = (-10L);
                    uint16_t *l_591 = &g_592;
                    int32_t l_598 = 1L;
                    int32_t l_604 = 0x003ED057L;
                    int i, j, k;
                    if ((g_98.f1 > (((safe_lshift_func_uint16_t_u_s(((l_583[4] == &l_584) , (p_61 >= ((safe_sub_func_uint16_t_u_u((((((l_587 = p_61) == ((*l_591) = (l_590 |= (safe_sub_func_int64_t_s_s((p_61 || 252UL), p_64))))) && (!((safe_rshift_func_uint16_t_u_u(((*l_591) = (safe_div_func_uint8_t_u_u((l_598 = (l_590 && g_126)), l_590))), l_599)) == l_590))) >= l_600) <= 253UL), p_64)) != p_61))), l_599)) >= 0xC39BA61CD64EC881LL) & l_601)))
                    { /* block id: 282 */
                        return l_598;
                    }
                    else
                    { /* block id: 284 */
                        uint16_t l_605 = 2UL;
                        l_603 = (l_602 = p_64);
                        ++l_605;
                    }
                    for (l_590 = 0; (l_590 <= 0); l_590 += 1)
                    { /* block id: 291 */
                        (*g_609) = l_608;
                    }
                    l_587 = l_611;
                    return l_598;
                }
                else
                { /* block id: 296 */
                    int32_t l_614 = 0xCE5FA401L;
                    int32_t l_621 = 7L;
                    l_622--;
                    l_618 &= (+(safe_lshift_func_int8_t_s_s((l_599 , p_61), p_61)));
                }
            }
            for (g_162 = 4; (g_162 >= 0); g_162 -= 1)
            { /* block id: 303 */
                int32_t l_639 = (-1L);
                int32_t l_644[5][3] = {{0xDFDF2AAAL,0x5FF0C6CFL,0xDFDF2AAAL},{0L,0L,0L},{0xDFDF2AAAL,0x5FF0C6CFL,0xDFDF2AAAL},{0L,0L,0L},{0xDFDF2AAAL,0x5FF0C6CFL,0xDFDF2AAAL}};
                int32_t l_651 = 0x9E693314L;
                int32_t l_705 = 0xE2E6F12EL;
                int32_t l_706 = 0x7EDFE20FL;
                int32_t l_707 = 0x4C2D8317L;
                int32_t l_712 = 4L;
                int32_t l_713[4] = {0x8C02E472L,0x8C02E472L,0x8C02E472L,0x8C02E472L};
                uint16_t l_715 = 0x31EBL;
                int i, j;
                if ((g_81[g_162][(p_61 + 4)] && (-2L)))
                { /* block id: 304 */
                    (*g_628) = g_81[g_162][(p_61 + 4)];
                }
                else
                { /* block id: 306 */
                    uint8_t *l_636 = &g_469;
                    int32_t l_647 = 0x25375059L;
                    int32_t l_648 = 0L;
                    int32_t l_649 = 0L;
                    int32_t l_650[10][1][10] = {{{(-1L),8L,(-1L),(-3L),0x2C37A285L,0x8D203E1EL,0xCA6EBD91L,0xF2088829L,0xCA6EBD91L,0x8D203E1EL}},{{0x9CE60CD5L,0x2C37A285L,(-1L),0x2C37A285L,0x9CE60CD5L,0xF2088829L,9L,(-3L),0x40FB4F8EL,1L}},{{9L,0xEF0A2A8DL,1L,0xF2088829L,(-3L),6L,6L,(-3L),0xF2088829L,1L}},{{0xF2088829L,0xF2088829L,8L,1L,0x9CE60CD5L,1L,(-3L),(-1L),0xD8F124FFL,0x8D203E1EL}},{{(-1L),0xCA6EBD91L,(-3L),0x40FB4F8EL,0x2C37A285L,0x40FB4F8EL,(-3L),0xCA6EBD91L,(-1L),0xF2088829L}},{{0xEF0A2A8DL,0xF2088829L,0xD8F124FFL,0x9CE60CD5L,0x8D203E1EL,(-1L),6L,0x2C37A285L,0x2C37A285L,6L}},{{0xCA6EBD91L,0xEF0A2A8DL,0x9CE60CD5L,0x9CE60CD5L,0xEF0A2A8DL,0xCA6EBD91L,9L,(-1L),(-1L),1L}},{{1L,0x2C37A285L,0xF2088829L,0x40FB4F8EL,0xD8F124FFL,8L,0xCA6EBD91L,8L,0xD8F124FFL,0x40FB4F8EL}},{{1L,8L,1L,1L,6L,0xCA6EBD91L,0x40FB4F8EL,0x8D203E1EL,0xF2088829L,(-1L)}},{{0xCA6EBD91L,0x40FB4F8EL,0x8D203E1EL,0xF2088829L,(-1L),(-1L),0xF2088829L,0x8D203E1EL,0x40FB4F8EL,0xCA6EBD91L}}};
                    int i, j, k;
                    for (l_602 = 0; (l_602 >= 0); l_602 -= 1)
                    { /* block id: 309 */
                        uint16_t l_629 = 1UL;
                        l_620 = (l_629 = l_615[1]);
                        return g_81[g_162][(p_61 + 4)];
                    }
                    if ((safe_add_func_uint32_t_u_u((safe_mul_func_uint8_t_u_u((safe_rshift_func_int8_t_s_s((g_81[2][4] | (((p_61 == (0L >= ((l_639 = ((*l_636)++)) & ((+(8L || (*p_63))) != (((0x3F2F952DE3C79237LL || 0x685A2A2E1C39099BLL) | (((((safe_lshift_func_int16_t_s_u(0xBF56L, (&g_269[3][1][3] == l_643))) , p_62) != (void*)0) || l_612) >= l_644[3][2])) == (*g_360)))))) , 0x31C4L) & p_61)), 3)), l_622)), p_61)))
                    { /* block id: 316 */
                        int32_t *l_645 = &l_603;
                        int32_t *l_646[6][5] = {{&l_603,&l_603,&g_577,&l_603,&l_603},{&l_617,&l_603,&l_617,&l_617,&l_603},{&l_603,&l_617,&l_617,&l_603,&l_617},{&l_603,&l_603,&g_577,&l_603,&l_603},{&l_617,&l_603,&l_617,&l_617,&l_603},{&l_603,&l_617,&l_617,&l_603,&l_617}};
                        int i, j;
                        l_652--;
                    }
                    else
                    { /* block id: 318 */
                        uint64_t l_655[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_655[i] = 0x44414B9A09B9192DLL;
                        l_650[4][0][5] = l_655[0];
                    }
                }
                for (l_602 = 0; (l_602 <= 5); l_602 += 1)
                { /* block id: 324 */
                    int16_t l_679 = 0x9C30L;
                    int64_t * const *l_683 = &g_437;
                    int64_t * const **l_682 = &l_683;
                    const uint8_t *l_685 = &g_469;
                    int32_t *l_693 = &l_616;
                    int32_t *l_694 = &g_577;
                    int32_t *l_695 = (void*)0;
                    int32_t *l_696 = &l_615[1];
                    int32_t *l_697 = &l_613;
                    int32_t *l_698 = (void*)0;
                    int32_t *l_699 = &l_651;
                    int32_t *l_700 = &l_613;
                    int32_t *l_701 = (void*)0;
                    int32_t *l_702[5][6][7] = {{{&l_587,&l_616,(void*)0,&l_603,&l_603,(void*)0,&l_603},{&l_639,&l_615[1],&l_616,(void*)0,(void*)0,&l_620,&l_612},{&l_615[1],&l_616,&l_617,(void*)0,&l_615[1],&l_615[1],(void*)0},{&l_603,(void*)0,&l_603,(void*)0,&l_603,&l_587,(void*)0},{(void*)0,&l_603,(void*)0,(void*)0,&g_577,(void*)0,&g_577},{&l_639,(void*)0,&l_603,&l_603,&g_577,&l_587,&l_616}},{{&l_612,&l_615[1],&l_651,&l_617,&l_651,&l_615[1],&l_612},{&l_612,&l_603,&l_615[1],(void*)0,(void*)0,&l_616,&l_603},{&l_617,&l_639,(void*)0,&l_587,&l_639,&l_617,&l_639},{&l_639,&l_615[1],&g_577,&l_603,&l_612,&l_639,&l_612},{(void*)0,&l_603,&l_603,(void*)0,&l_612,&l_615[1],(void*)0},{&l_651,(void*)0,&l_587,&g_577,&l_639,(void*)0,&l_603}},{{(void*)0,&l_639,&g_577,&l_587,(void*)0,&l_651,(void*)0},{&l_615[1],&l_612,(void*)0,&l_603,&l_603,(void*)0,&l_612},{&l_639,&l_612,&l_603,&g_577,&l_615[1],&l_639,&l_639},{&l_617,&l_639,&l_587,(void*)0,&l_639,&l_617,&l_603},{&l_616,(void*)0,(void*)0,&g_577,&l_587,&l_603,&l_603},{(void*)0,&l_603,(void*)0,&l_603,(void*)0,&l_603,&l_587}},{{(void*)0,&l_615[1],(void*)0,&l_587,(void*)0,&l_617,&l_615[1]},{&l_639,&l_639,&l_615[1],&g_577,&l_620,&l_639,&l_615[1]},{(void*)0,&l_587,&l_639,(void*)0,&l_615[1],(void*)0,&l_639},{(void*)0,(void*)0,&l_639,&l_603,&l_587,&l_651,&l_603},{&l_616,(void*)0,&l_615[1],&l_587,(void*)0,(void*)0,&l_587},{&l_617,&l_620,(void*)0,(void*)0,&l_587,&l_615[1],&l_620}},{{&l_639,&l_615[1],(void*)0,(void*)0,&l_615[1],&l_639,&l_620},{&l_615[1],&l_587,(void*)0,(void*)0,&l_620,&l_617,&l_587},{(void*)0,(void*)0,&l_587,&l_615[1],(void*)0,&l_616,&l_603},{&l_651,&l_587,&l_603,&l_639,(void*)0,(void*)0,&l_639},{(void*)0,&l_615[1],(void*)0,&l_639,&l_587,(void*)0,&l_615[1]},{&l_639,&l_620,&g_577,&l_615[1],&l_639,&l_639,&l_615[1]}}};
                    int16_t l_723 = 0x176CL;
                    int i, j, k;
                    if ((~1UL))
                    { /* block id: 325 */
                        uint8_t **l_657[1];
                        int32_t l_669 = 0xEC9C5B02L;
                        int8_t *l_676 = &l_611;
                        const uint8_t **l_686[10][1] = {{&l_685},{&l_685},{&l_685},{&l_685},{&l_685},{&l_685},{&l_685},{&l_685},{&l_685},{&l_685}};
                        int32_t *l_692 = &l_620;
                        int i, j;
                        for (i = 0; i < 1; i++)
                            l_657[i] = &g_468;
                        (*l_692) = ((((l_658 = &g_469) != (l_689 = (l_687 = ((g_684 = (safe_mod_func_int16_t_s_s(((((safe_mul_func_uint8_t_u_u((((g_81[g_162][(p_61 + 1)] = (safe_div_func_uint64_t_u_u((safe_mul_func_int8_t_s_s((((((((safe_lshift_func_uint16_t_u_s((*g_157), 15)) && (l_669 ^ ((((&g_610 != ((safe_lshift_func_int8_t_s_u((l_680[1][4][0] |= (((safe_lshift_func_int8_t_s_s(((*l_676) &= (0x9B6EED34C43B6C6DLL || ((safe_lshift_func_int8_t_s_u((***g_374), p_61)) , (*g_97)))), ((safe_lshift_func_uint8_t_u_s(l_679, l_639)) <= l_644[3][0]))) || l_611) <= 1UL)), 3)) , (void*)0)) >= 0x813AL) | (-1L)) || g_681[7][0]))) > p_61) && (*p_63)) && g_106) , &g_436) == l_682), l_679)), p_61))) , &g_437) == (void*)0), (*g_376))) , p_61) > p_61) == p_61), 1L))) , l_685)))) , 0UL) >= l_691);
                    }
                    else
                    { /* block id: 334 */
                        return l_602;
                    }
                    l_715++;
                    l_725--;
                    ++l_728;
                }
            }
        }
        return l_620;
    }
    return l_578[0][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_81 g_98 g_95 g_39 g_106 g_125 g_97 g_126 g_103 g_157 g_98.f0 g_303 g_162 g_211 g_214 g_145 g_268 g_304 g_359 g_356 g_374 g_320 g_398 g_270 g_269 g_6 g_436 g_360 g_468 g_437 g_506 g_376 g_139
 * writes: g_81 g_95 g_97 g_103 g_106 g_126 g_303 g_162 g_214 g_268 g_271 g_139 g_125 g_398 g_270 g_436 g_356 g_468 g_506 g_374
 */
static int32_t * func_65(uint8_t  p_66, int16_t  p_67, uint16_t  p_68)
{ /* block id: 5 */
    uint64_t *l_80 = &g_81[4][2];
    int32_t l_84 = (-1L);
    uint64_t **l_93 = (void*)0;
    uint64_t **l_94 = &l_80;
    uint64_t *l_96 = &g_81[4][0];
    const int32_t *l_101 = (void*)0;
    int64_t *l_102 = &g_103;
    int32_t l_104[3];
    int16_t *l_105 = &g_106;
    int32_t *l_140 = &g_39;
    union U0 l_150 = {0x5D6BL};
    const int64_t l_197[1] = {0L};
    int8_t *l_212 = &g_162;
    int32_t l_218 = 0x49BFD98BL;
    uint32_t l_226[10] = {0UL,0x9452628CL,0UL,0UL,0x9452628CL,0UL,0UL,0x9452628CL,0UL,0UL};
    uint8_t l_336[10] = {0x6FL,0x6FL,255UL,0x6FL,0x6FL,255UL,0x6FL,0x6FL,255UL,0x6FL};
    uint32_t l_370[5][6] = {{0x94170DBCL,4294967292UL,0x3E7BC1A0L,0x852DD881L,0UL,4294967294UL},{0UL,0x3E7BC1A0L,4294967288UL,0x94170DBCL,0x94170DBCL,4294967288UL},{0x3E7BC1A0L,0x3E7BC1A0L,0x81EB79B5L,0UL,0UL,0x94170DBCL},{0x546763C7L,4294967292UL,0x852DD881L,0x81EB79B5L,0UL,0x81EB79B5L},{0x852DD881L,0x546763C7L,0x852DD881L,4294967294UL,0x3E7BC1A0L,0x94170DBCL}};
    uint16_t l_447[4] = {65535UL,65535UL,65535UL,65535UL};
    const int64_t **l_564 = (void*)0;
    uint32_t l_567 = 0x28560B79L;
    int i, j;
    for (i = 0; i < 3; i++)
        l_104[i] = 0xCA31B866L;
    if ((safe_lshift_func_uint16_t_u_u(((safe_lshift_func_int16_t_s_s(((*l_105) &= (safe_mul_func_int16_t_s_s(((safe_div_func_int64_t_s_s(((safe_sub_func_uint64_t_u_u((++(*l_80)), l_84)) || (safe_rshift_func_int16_t_s_s((((safe_sub_func_uint32_t_u_u((safe_add_func_int64_t_s_s(((((*l_102) = (l_84 = (safe_add_func_int64_t_s_s((0xB5DCL == (((g_95 = ((*l_94) = l_80)) == (g_97 = l_96)) && (g_98 , (*g_95)))), ((safe_add_func_uint64_t_u_u((0x18L && ((void*)0 != l_101)), 5L)) != g_81[2][1]))))) <= g_81[5][2]) , 0L), l_104[1])), p_67)) && g_39) < g_81[2][0]), l_104[1]))), l_104[1])) , 0x295AL), p_67))), p_68)) > p_68), 5)))
    { /* block id: 13 */
        uint32_t l_107 = 18446744073709551615UL;
        int16_t *l_138[5][6] = {{&g_106,(void*)0,&g_106,(void*)0,&g_106,(void*)0},{&g_139,(void*)0,&g_139,(void*)0,&g_139,(void*)0},{&g_106,(void*)0,&g_106,(void*)0,&g_106,(void*)0},{&g_139,(void*)0,&g_139,(void*)0,&g_139,(void*)0},{&g_106,(void*)0,&g_106,(void*)0,&g_106,(void*)0}};
        int32_t *l_160 = (void*)0;
        int8_t *l_161 = &g_162;
        int64_t l_163 = 4L;
        int32_t l_216 = (-1L);
        int32_t l_219 = 0xF8867BC2L;
        int32_t l_220 = 0x2668A2AEL;
        int32_t l_221 = 0xCB0D776FL;
        int32_t l_224[4] = {2L,2L,2L,2L};
        uint32_t l_245 = 0x916AA3D3L;
        uint32_t l_307 = 0x890D70B6L;
        uint64_t l_333 = 18446744073709551613UL;
        int64_t *l_343 = &g_103;
        uint32_t l_397 = 4294967293UL;
        int32_t l_400 = (-5L);
        int8_t l_401 = 0x4EL;
        union U0 l_435 = {0x4C62L};
        uint16_t l_476[2];
        uint8_t *l_503 = &l_336[8];
        uint8_t l_529 = 0x01L;
        int i, j;
        for (i = 0; i < 2; i++)
            l_476[i] = 0x96E8L;
lbl_504:
        if (l_107)
        { /* block id: 14 */
            int32_t *l_108 = &l_84;
            int32_t **l_109[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            int32_t *l_110 = &l_104[2];
            int i;
            l_110 = l_108;
        }
        else
        { /* block id: 16 */
            uint64_t *l_123 = &g_6;
            int32_t l_124 = (-1L);
            for (l_107 = 27; (l_107 >= 2); l_107 = safe_sub_func_int8_t_s_s(l_107, 2))
            { /* block id: 19 */
                int32_t *l_144 = &l_104[1];
                for (p_66 = 0; (p_66 < 5); ++p_66)
                { /* block id: 22 */
                    for (g_106 = (-10); (g_106 != (-13)); g_106 = safe_sub_func_uint64_t_u_u(g_106, 3))
                    { /* block id: 25 */
                        int32_t *l_127 = (void*)0;
                        int16_t **l_137[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_137[i] = (void*)0;
                        l_104[1] |= (safe_add_func_uint16_t_u_u(p_66, (safe_sub_func_uint64_t_u_u(((0x1441E233L <= (((void*)0 != l_123) != (p_67 , ((l_124 ^ ((l_127 = g_125) != &g_126)) , ((safe_mod_func_int16_t_s_s((safe_div_func_int16_t_s_s((!(((*g_125) = (safe_sub_func_int16_t_s_s((l_124 , 0x50A9L), p_67))) , 0x21BA6C3C0C88640ELL)), 65535UL)), 65535UL)) != p_68))))) , (*g_97)), l_107))));
                        if (l_124)
                            continue;
                        (*l_127) = (safe_lshift_func_uint8_t_u_u((&g_106 != (l_138[1][0] = &g_106)), 0));
                        return l_140;
                    }
                }
                if ((*g_125))
                    continue;
                for (p_66 = 0; (p_66 <= 55); ++p_66)
                { /* block id: 38 */
                    int32_t *l_143 = &l_104[1];
                }
            }
            if (g_39)
                goto lbl_164;
        }
lbl_164:
        (*g_125) = (safe_sub_func_int8_t_s_s(g_103, ((&g_106 == ((safe_mod_func_int32_t_s_s(p_68, ((l_150 , ((*l_161) &= ((g_126 | ((safe_sub_func_int64_t_s_s((safe_div_func_int8_t_s_s((safe_lshift_func_int16_t_s_u(((g_157 != ((safe_mul_func_uint16_t_u_u((*g_157), (l_84 = ((l_107 , l_160) != l_101)))) , g_157)) ^ 0x066401EE1831F773LL), g_81[5][2])), g_81[4][2])), l_107)) , p_66)) > 65532UL))) ^ p_67))) , &p_67)) | l_163)));
        for (l_107 = 0; (l_107 > 56); l_107 = safe_add_func_int8_t_s_s(l_107, 5))
        { /* block id: 50 */
            uint32_t l_190 = 1UL;
            uint8_t l_202[10] = {1UL,0xEAL,1UL,0xEAL,1UL,0xEAL,1UL,0xEAL,1UL,0xEAL};
            int32_t l_229 = 6L;
            int32_t l_230 = 0xFDA64624L;
            int32_t l_233 = 0x3001FCD4L;
            int32_t l_236 = 0L;
            int32_t l_237 = 0xAFE7F47FL;
            int32_t l_239 = 5L;
            int32_t l_240 = 0L;
            int32_t l_242 = (-2L);
            int32_t l_243[8];
            uint32_t l_321 = 0UL;
            int32_t *l_326 = &l_243[7];
            uint16_t *l_399 = &l_150.f0;
            uint64_t *l_461 = &g_81[1][5];
            int32_t *l_535 = &l_218;
            int i;
            for (i = 0; i < 8; i++)
                l_243[i] = (-1L);
            for (g_103 = 0; (g_103 <= 4); g_103 += 1)
            { /* block id: 53 */
                int32_t **l_187[2];
                int32_t *l_191 = (void*)0;
                uint16_t l_203 = 0xC8DBL;
                uint8_t *l_206 = (void*)0;
                uint8_t *l_207 = &l_202[4];
                int16_t **l_209 = &l_138[g_103][g_103];
                int16_t ***l_208 = &l_209;
                uint32_t *l_213 = &g_214;
                int8_t l_215 = 0xA8L;
                int i, j;
                for (i = 0; i < 2; i++)
                    l_187[i] = &g_125;
                for (l_163 = 4; (l_163 >= 1); l_163 -= 1)
                { /* block id: 56 */
                    if (l_163)
                    { /* block id: 57 */
                        (*g_125) ^= 0x61DE361CL;
                    }
                    else
                    { /* block id: 59 */
                        uint8_t l_167 = 0x5FL;
                        int32_t l_170 = 0xC4E49CAFL;
                        uint16_t *l_184 = &l_150.f0;
                        int i, j;
                        l_190 = ((l_167 = l_104[2]) & (safe_add_func_int16_t_s_s(l_170, (safe_div_func_uint64_t_u_u(l_170, ((*g_97) = ((0x9E293F4BB62B1260LL | 8L) && (safe_sub_func_int8_t_s_s(((~0xD4091144L) == ((safe_mod_func_int64_t_s_s((((safe_sub_func_uint64_t_u_u((safe_rshift_func_int8_t_s_s((safe_rshift_func_int8_t_s_u((((--(*l_184)) , (void*)0) == l_187[0]), ((safe_mod_func_int64_t_s_s(p_67, g_81[4][2])) | 0x6DL))), 6)), p_66)) != l_170) & p_67), (-9L))) , 0x62E6A661FA26FBF5LL)), p_67)))))))));
                        return l_191;
                    }
                }
                l_203 = (safe_add_func_uint64_t_u_u(((*g_97) = l_150.f1), (safe_div_func_int64_t_s_s((((!(l_197[0] > (g_126 | (*g_125)))) , (safe_sub_func_uint16_t_u_u(((safe_sub_func_int16_t_s_s(((l_202[4] == (-1L)) <= 0x8A76L), l_163)) , (l_104[1] & 0L)), 1UL))) , 0xD30B3EA340A379BBLL), 0xF09C2FEE76F7154ELL))));
                if ((p_68 , ((((*l_213) |= ((safe_div_func_uint8_t_u_u((((0x9225F199L > ((((*l_207) = p_66) | (((*l_208) = &l_105) == (l_84 , (void*)0))) == (((+((0x34E9L || (g_211 == (void*)0)) & (-9L))) , l_190) & g_106))) , &g_162) != l_212), g_81[5][4])) | l_190)) != 0UL) <= p_67)))
                { /* block id: 72 */
                    for (g_126 = 3; (g_126 >= 1); g_126 -= 1)
                    { /* block id: 75 */
                        return &g_39;
                    }
                    l_216 |= ((**g_145) = (255UL || l_215));
                    if ((*g_125))
                        break;
                    return l_140;
                }
                else
                { /* block id: 82 */
                    int8_t l_222 = 0xC6L;
                    int32_t l_223 = 0L;
                    int32_t l_225 = 0x4AC5FBAFL;
                    int32_t l_231 = (-6L);
                    int32_t l_232 = 0x24005893L;
                    int32_t l_234 = 0xE9C46A30L;
                    int32_t l_235 = 1L;
                    int32_t l_238 = 0x4C335884L;
                    int32_t l_241 = 0x702D28A0L;
                    int32_t l_244 = (-1L);
                    int64_t *l_254 = &l_163;
                    uint16_t *l_265[1][3][2] = {{{&l_150.f0,&l_203},{&l_150.f0,&l_150.f0},{&l_203,&l_150.f0}}};
                    int i, j, k;
                    ++l_226[3];
                    for (g_162 = 0; g_162 < 3; g_162 += 1)
                    {
                        l_104[g_162] = 0xE4CBC4FEL;
                    }
                    l_245++;
                    g_271[5][0][1] = (g_268 = ((0xA87B3A4DL != (safe_sub_func_int32_t_s_s((safe_mul_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((((((*l_254) &= l_107) && (++(**l_94))) , 0xBAFCB356L) , (safe_sub_func_int16_t_s_s((safe_mod_func_int64_t_s_s((safe_lshift_func_int8_t_s_s((((safe_add_func_uint16_t_u_u(65535UL, ((void*)0 == l_265[0][0][1]))) <= (safe_sub_func_uint32_t_u_u(p_67, (0xDFB2AA1FC9FD4B6ALL <= 18446744073709551608UL)))) | 255UL), g_81[4][2])), l_225)), 65535UL))), g_162)), 5UL)), 0xE3BBB778L))) , g_268));
                }
                for (l_242 = 0; (l_242 <= 4); l_242 += 1)
                { /* block id: 93 */
                    l_216 &= (**g_145);
                    (*g_125) ^= (+p_67);
                    for (g_126 = 0; (g_126 <= 4); g_126 += 1)
                    { /* block id: 98 */
                        uint8_t l_273[8] = {0UL,249UL,0UL,249UL,0UL,249UL,0UL,249UL};
                        int i;
                        l_273[3]--;
                    }
                }
            }
            if ((*g_125))
            { /* block id: 103 */
                int32_t l_301 = (-7L);
                int32_t l_317 = 5L;
                for (g_139 = 4; (g_139 != 12); g_139 = safe_add_func_uint8_t_u_u(g_139, 8))
                { /* block id: 106 */
                    int8_t *l_302 = &g_303;
                    int32_t *l_305 = &l_240;
                    int32_t *l_306[5][4][3] = {{{&l_220,(void*)0,&l_220},{&l_104[1],&l_104[1],&l_104[2]},{&l_243[7],&l_104[1],(void*)0},{&g_126,(void*)0,&l_104[1]}},{{&l_104[1],&l_104[1],&l_224[3]},{&l_220,&g_126,&l_104[1]},{&l_84,(void*)0,(void*)0},{(void*)0,&l_233,&l_104[2]}},{{(void*)0,&l_104[2],&l_220},{&l_84,&l_243[7],&l_224[2]},{&l_220,&l_104[1],&l_239},{&l_104[1],&l_243[7],&l_220}},{{&g_126,&l_104[2],&g_126},{&l_243[7],&l_233,&g_126},{&l_104[1],(void*)0,&l_220},{&l_220,&g_126,&l_239}},{{&l_233,&l_104[1],&l_224[2]},{&l_220,(void*)0,&l_220},{&l_104[1],&l_104[1],&l_104[2]},{&l_243[7],&l_104[1],(void*)0}}};
                    int i, j, k;
                    (*g_125) = (safe_sub_func_uint32_t_u_u((((safe_sub_func_uint32_t_u_u((safe_sub_func_int64_t_s_s(((((safe_unary_minus_func_uint32_t_u(0x43A748A0L)) == ((*l_102) = (safe_sub_func_uint64_t_u_u(((*g_157) , (((safe_mod_func_int8_t_s_s(((*l_302) = (safe_rshift_func_uint8_t_u_u(0x87L, (((safe_lshift_func_int16_t_s_s(8L, 14)) > ((p_67 == (((safe_sub_func_uint64_t_u_u(((safe_mod_func_uint16_t_u_u(p_68, (safe_mul_func_uint8_t_u_u(p_68, (safe_lshift_func_int8_t_s_s(g_39, ((*l_212) = g_98.f0))))))) >= (-6L)), 0xE6ECA0ADB7E7919DLL)) >= g_214) && l_301)) , p_68)) >= l_218)))), p_67)) , (-8L)) , 18446744073709551611UL)), (*g_97))))) ^ p_67) & (-4L)), p_68)), p_68)) == 9UL) < p_67), l_240));
                    (*g_304) = &l_219;
                    l_307--;
                    for (g_303 = 0; (g_303 != 4); ++g_303)
                    { /* block id: 115 */
                        return l_160;
                    }
                }
                for (p_68 = (-19); (p_68 == 60); p_68 = safe_add_func_uint8_t_u_u(p_68, 6))
                { /* block id: 121 */
                    int8_t l_316 = 0xDDL;
                    int32_t l_318 = (-1L);
                    int32_t l_319[3][1][6] = {{{8L,8L,0xA849FEBDL,8L,8L,0xA849FEBDL}},{{8L,8L,0xA849FEBDL,8L,8L,0xA849FEBDL}},{{8L,8L,0xA849FEBDL,8L,8L,0xA849FEBDL}}};
                    int32_t **l_324 = (void*)0;
                    int32_t **l_325[3][2][6] = {{{&g_125,&g_125,(void*)0,(void*)0,&g_125,&g_125},{(void*)0,&g_125,&g_125,&g_125,&g_125,&g_125}},{{&g_125,(void*)0,&g_125,(void*)0,&g_125,(void*)0},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125}},{{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,&g_125,&g_125,(void*)0,&g_125,(void*)0}}};
                    int i, j, k;
                    for (l_229 = 3; (l_229 <= 9); l_229 += 1)
                    { /* block id: 124 */
                        int32_t *l_314 = &l_237;
                        int32_t *l_315[9][2] = {{&l_84,&l_243[7]},{&l_221,&l_84},{(void*)0,(void*)0},{(void*)0,&l_84},{&l_221,&l_243[7]},{&l_84,&l_243[7]},{&l_221,&l_84},{(void*)0,(void*)0},{(void*)0,&l_84}};
                        int i, j;
                        --l_321;
                        if ((**g_145))
                            break;
                    }
                    l_326 = (void*)0;
                }
                if (p_68)
                    continue;
            }
            else
            { /* block id: 131 */
                int32_t *l_327 = &l_229;
                int32_t *l_328 = &l_243[7];
                int32_t *l_329 = &l_216;
                int32_t *l_330 = &l_239;
                int32_t *l_331[3][6][6] = {{{&l_216,&g_126,&l_221,&g_126,&l_216,(void*)0},{&l_240,&l_237,&l_237,&g_126,&l_240,&l_243[7]},{&l_216,&l_237,&l_221,&l_237,&l_216,&l_243[7]},{&l_240,&g_126,&l_237,&l_237,&l_240,(void*)0},{&l_216,&g_126,&l_221,&g_126,&l_216,(void*)0},{&l_240,&l_237,&l_237,&g_126,&l_240,&l_243[7]}},{{&l_216,&l_237,&l_221,&l_237,&l_216,&l_243[7]},{&l_240,&g_126,&l_237,&l_237,&l_240,(void*)0},{&l_216,&g_126,&l_221,&g_126,&l_216,(void*)0},{&l_240,&l_237,&l_237,&g_126,&l_240,&l_243[7]},{&l_216,&l_237,&l_221,&l_237,&l_216,&l_243[7]},{&l_240,&g_126,&l_237,&l_237,&l_240,(void*)0}},{{&l_216,&g_126,&l_221,&g_126,&l_216,(void*)0},{&l_240,&l_237,&l_237,&g_126,&l_240,&l_243[7]},{&l_216,&l_237,&l_221,&l_237,&l_216,&l_243[7]},{&l_240,&g_126,&l_237,&l_237,&l_240,(void*)0},{&l_216,&g_126,&l_221,&g_126,&l_216,(void*)0},{&l_240,&l_237,&l_237,&g_126,&l_240,&l_243[7]}}};
                int32_t l_332 = (-1L);
                int i, j, k;
                l_333++;
                (*l_329) &= ((*l_328) = 0x9717E372L);
                l_336[8]--;
            }
            if ((g_81[4][0] != p_68))
            { /* block id: 137 */
                uint8_t * const l_366 = &l_202[1];
                int32_t l_368 = 0x6A7E92C8L;
                int8_t * volatile * volatile * volatile l_377 = &g_375[2];/* VOLATILE GLOBAL l_377 */
                int64_t **l_390 = &l_102;
                int32_t *l_450 = &l_400;
                uint16_t l_456 = 0xFA52L;
                const uint64_t *l_462 = &l_333;
                if (((*g_125) = l_163))
                { /* block id: 139 */
                    union U0 l_341 = {0x3AE9L};
                    int64_t * const l_355 = &g_356;
                    int64_t * const *l_354 = &l_355;
                    uint8_t *l_367 = &l_336[8];
                    int16_t *l_373 = (void*)0;
                    union U0 *l_403 = &l_341;
                    union U0 **l_402 = &l_403;
                    (*g_125) = (*g_125);
                    for (p_68 = 0; (p_68 > 31); p_68 = safe_add_func_uint32_t_u_u(p_68, 6))
                    { /* block id: 143 */
                        int64_t **l_342[1][2];
                        const int64_t *l_345[7][10][1] = {{{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]}},{{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]}},{{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]}},{{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]}},{{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]}},{{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]}},{{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]},{&l_197[0]}}};
                        const int64_t **l_344 = &l_345[6][8][0];
                        int64_t * const *l_358 = &l_355;
                        int64_t * const **l_357 = &l_358;
                        int32_t l_369 = 0x931B0B80L;
                        int8_t **l_372 = &l_161;
                        int8_t ***l_371 = &l_372;
                        int i, j, k;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 2; j++)
                                l_342[i][j] = &l_102;
                        }
                        (*l_371) = ((((*g_157) == (l_341 , ((l_343 = &g_103) != ((*l_344) = &l_163)))) < (safe_add_func_int8_t_s_s(((safe_rshift_func_int8_t_s_u((~((((*g_125) != ((~((((*l_96) = ((safe_add_func_int64_t_s_s(((((*l_357) = (l_354 = (void*)0)) == g_359) == p_67), (safe_lshift_func_int16_t_s_s((((((!((safe_add_func_uint32_t_u_u(g_214, (*g_125))) , 0L)) || 0x535FF06FB2C722C5LL) , l_366) == l_367) >= l_368), l_229)))) < 65535UL)) < 0x43B3CD1F539C6CFDLL) , 0xF93C2539L)) , l_369)) ^ l_104[2]) , l_370[2][3])), 3)) | l_369), g_356))) , (void*)0);
                    }
                    for (l_307 = 0; (l_307 <= 9); l_307 += 1)
                    { /* block id: 153 */
                        (*g_125) &= (&p_67 == l_373);
                        l_377 = g_374;
                        l_401 |= (safe_rshift_func_uint8_t_u_s((safe_lshift_func_uint8_t_u_u((safe_add_func_int32_t_s_s(0L, ((l_150 , (((((((safe_div_func_uint32_t_u_u((safe_rshift_func_uint8_t_u_u((safe_sub_func_int8_t_s_s((l_390 != &g_360), ((((safe_mul_func_uint16_t_u_u((g_398 |= ((safe_mul_func_int16_t_s_s(p_66, (((safe_rshift_func_int8_t_s_u(l_368, ((p_67 ^ g_320) & (*g_125)))) ^ l_226[9]) <= p_66))) ^ l_397)), 0L)) && 18446744073709551609UL) , 0xAC6DC376L) && 1UL))), p_68)), (-1L))) , l_399) == g_270) , l_400) | 0x026BL) , (void*)0) == &g_376)) , p_67))), 1)), 6));
                    }
                    (*l_402) = (void*)0;
                }
                else
                { /* block id: 160 */
                    int8_t *l_421[5] = {&l_401,&l_401,&l_401,&l_401,&l_401};
                    int32_t l_423 = 0L;
                    uint32_t l_432[10] = {4UL,0x2E1C9E03L,0x45599334L,0x2E1C9E03L,4UL,4UL,0x2E1C9E03L,0x45599334L,0x2E1C9E03L,4UL};
                    int32_t l_446[9] = {0x97BD82C9L,0x657B17DBL,0x657B17DBL,0x97BD82C9L,0x657B17DBL,0x657B17DBL,0x97BD82C9L,0x657B17DBL,0x657B17DBL};
                    int32_t *l_451 = &l_220;
                    int32_t *l_452 = &l_423;
                    int32_t *l_453 = &l_240;
                    int32_t *l_454 = &l_104[2];
                    int32_t *l_455[6] = {(void*)0,&g_126,&g_126,(void*)0,&g_126,&g_126};
                    int i;
                    if ((*g_125))
                    { /* block id: 161 */
                        uint32_t l_406[2][8] = {{0x450083CAL,0x78D34727L,0x78D34727L,0x450083CAL,0x78D34727L,0x78D34727L,0x450083CAL,0x78D34727L},{0x450083CAL,0x450083CAL,0x0B965632L,0x450083CAL,0x450083CAL,0x0B965632L,0x450083CAL,0x450083CAL}};
                        int64_t ***l_438 = &g_436;
                        int32_t *l_441 = (void*)0;
                        int32_t *l_442 = (void*)0;
                        int32_t *l_443 = (void*)0;
                        int32_t *l_444 = &l_368;
                        int32_t *l_445[10][3][7] = {{{&l_230,(void*)0,&l_423,&l_229,(void*)0,&l_221,&l_224[2]},{&l_423,&l_240,&l_219,&l_236,&l_229,&l_236,&l_219},{&l_242,&l_242,&l_216,(void*)0,&l_104[2],&l_239,&l_233}},{{(void*)0,(void*)0,&l_243[7],&l_236,&l_221,&l_229,&l_224[2]},{&l_233,&l_243[7],&g_126,&l_224[2],&l_104[2],&l_243[5],(void*)0},{&l_243[7],&l_243[7],&l_224[2],&l_368,&l_229,&l_368,&l_237}},{{(void*)0,&l_221,&l_84,&l_368,(void*)0,&l_240,&l_224[0]},{&l_239,&l_104[1],&g_126,&l_219,(void*)0,&l_243[7],&l_240},{&l_243[7],&l_104[0],&l_368,&l_220,&l_221,&l_236,&l_243[7]}},{{(void*)0,&l_243[7],&l_104[1],&l_216,&l_224[1],&l_104[1],&l_243[7]},{(void*)0,&l_104[2],&l_243[5],&l_104[0],&l_216,&l_237,&l_368},{&l_243[7],&g_126,&l_229,&l_243[5],&l_239,&l_368,&l_224[1]}},{{&l_239,&l_237,(void*)0,&l_243[5],(void*)0,(void*)0,&l_104[1]},{(void*)0,&l_240,&l_219,(void*)0,(void*)0,&l_219,&l_240},{&l_243[7],&l_224[2],&l_104[1],&l_423,&l_104[0],&l_104[1],&l_423}},{{&l_233,&l_104[1],&l_236,&g_126,&l_221,&l_423,&l_224[0]},{(void*)0,&l_423,&l_237,&l_423,&l_224[2],(void*)0,&l_216},{&l_242,&l_368,&l_243[7],&l_224[2],&l_239,&l_229,&l_229}},{{(void*)0,&g_126,&l_423,&l_368,&l_368,&l_224[2],&l_240},{(void*)0,(void*)0,&l_237,&l_423,(void*)0,&l_423,&l_230},{&l_224[1],&l_243[7],&l_230,&l_229,&l_236,&l_423,&l_423}},{{(void*)0,(void*)0,(void*)0,&l_221,&l_216,&l_423,&l_423},{(void*)0,&l_239,(void*)0,&g_126,&l_423,&l_221,&l_230},{&l_221,&l_242,&l_368,&l_221,&l_243[7],&l_233,&l_240}},{{&l_243[7],&l_221,&l_221,&l_240,&l_243[7],(void*)0,&l_229},{&l_221,&l_216,&l_237,&l_239,&l_237,&l_216,&l_221},{&l_368,&g_126,(void*)0,&l_240,&l_230,&l_104[1],&l_368}},{{&l_236,&l_240,(void*)0,&l_221,&l_243[5],&l_221,&l_243[5]},{&l_243[7],&l_220,(void*)0,&g_126,&l_243[7],&l_104[1],&l_224[1]},{&l_104[1],(void*)0,&l_237,&l_219,(void*)0,&l_368,(void*)0}}};
                        int i, j, k;
                        (*g_125) |= (safe_sub_func_uint16_t_u_u(l_406[0][2], (safe_div_func_uint64_t_u_u((safe_add_func_uint8_t_u_u(((((safe_mul_func_int16_t_s_s(((safe_lshift_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u((safe_rshift_func_int16_t_s_s((((safe_sub_func_uint64_t_u_u(p_66, ((((**l_390) |= ((l_138[0][5] != ((**g_268) = &p_67)) >= ((void*)0 != l_421[3]))) & (g_303 , (~l_370[2][3]))) && l_216))) ^ p_67) <= p_68), 5)), 0xCFB8L)), 2)) > p_67), (*g_157))) != g_6) , (*g_270)) , l_423), p_67)), p_68))));
                        (*g_125) = ((g_214 = ((safe_mul_func_int16_t_s_s(((*l_105) = (safe_rshift_func_uint8_t_u_s(((((safe_sub_func_int32_t_s_s(l_432[3], g_106)) == p_67) || (((**g_359) = (safe_sub_func_uint8_t_u_u((((l_435 , (((*l_438) = g_436) == &g_437)) ^ (safe_sub_func_uint16_t_u_u((*g_157), l_432[1]))) , 8UL), 0x78L))) >= 0xEA8AA2FDAF063AF9LL)) && 0x9397BDFBL), 0))), 0x90EEL)) >= p_67)) < g_162);
                        --l_447[2];
                    }
                    else
                    { /* block id: 171 */
                        return &g_39;
                    }
                    l_456--;
                    for (g_214 = (-19); (g_214 <= 53); ++g_214)
                    { /* block id: 177 */
                        (*l_454) |= (0x9A27L == p_66);
                    }
                    (*l_452) &= (l_461 != l_462);
                }
                return &g_39;
            }
            else
            { /* block id: 183 */
                int32_t **l_466 = (void*)0;
                int32_t **l_467 = &l_326;
                if (((safe_unary_minus_func_uint64_t_u((safe_mul_func_int16_t_s_s(p_66, (((((*l_467) = &l_236) == ((((g_468 = &p_66) == (void*)0) >= 0x109BFE47L) , (*g_304))) != ((((*g_97) & ((safe_div_func_uint64_t_u_u((0x0146L ^ ((safe_mod_func_int32_t_s_s((safe_rshift_func_int8_t_s_s((g_126 || p_68), p_66)), l_476[0])) && p_66)), (*g_97))) == 6L)) >= p_68) != 0x3590L)) >= (-4L)))))) < l_230))
                { /* block id: 186 */
                    int64_t l_481 = (-5L);
                    int32_t *l_505[5];
                    uint32_t l_528 = 0x8E2B2039L;
                    int i;
                    for (i = 0; i < 5; i++)
                        l_505[i] = &l_104[0];
                    (*l_467) = (((safe_div_func_int8_t_s_s(((safe_mod_func_uint32_t_u_u(0x85252CC8L, (((((l_481 || 0L) > (safe_mod_func_uint32_t_u_u(g_398, (((**l_467) = (g_106 , (**g_145))) , (safe_sub_func_uint32_t_u_u((((*g_468) |= ((safe_mul_func_uint8_t_u_u(((((((((safe_add_func_int32_t_s_s(((safe_mul_func_int8_t_s_s(l_481, ((safe_mul_func_uint8_t_u_u(((((*l_105) ^= (*l_326)) && l_400) >= 0xFB27FCA3L), 254UL)) , (*l_326)))) || (*l_326)), 0L)) && 0xC9L) && 0xEA594716C15A44C4LL) != (**l_467)) != p_67) , (void*)0) != (void*)0) | l_481), 0UL)) ^ (*g_360))) ^ 0x0FL), (*l_326))))))) < p_67) <= 0xDBL) , (**g_145)))) <= p_68), g_162)) >= p_68) , (void*)0);
                    for (l_401 = 21; (l_401 > 11); --l_401)
                    { /* block id: 193 */
                        int8_t **l_502[8] = {&l_212,&l_212,&l_212,&l_212,&l_212,&l_212,&l_212,&l_212};
                        int i;
                        (*g_125) = (((safe_mod_func_uint16_t_u_u(l_107, p_68)) != (safe_rshift_func_uint8_t_u_s(p_68, ((((*g_437) = (safe_sub_func_uint64_t_u_u(((*l_80) = 7UL), 0xAF113294E3F70947LL))) , (l_161 = &g_303)) != (((g_468 = &p_66) != l_503) , (void*)0))))) == g_126);
                        if (l_190)
                            goto lbl_504;
                    }
                    --g_506;
                    for (l_190 = 0; (l_190 > 3); ++l_190)
                    { /* block id: 204 */
                        int32_t *l_511 = (void*)0;
                        int32_t **l_516 = &l_140;
                        int64_t l_530 = (-10L);
                        l_511 = &l_216;
                        l_530 |= (safe_div_func_uint8_t_u_u(((safe_add_func_int16_t_s_s(((&g_39 == ((*l_516) = l_326)) && ((safe_mul_func_int8_t_s_s((safe_lshift_func_uint16_t_u_u(((((((&l_476[0] != ((((((l_220 |= ((l_224[2] <= 65535UL) != (((*l_212) |= (safe_add_func_uint16_t_u_u(((0xB43315F4L || (p_66 && (*g_468))) <= (safe_div_func_uint8_t_u_u((((safe_mod_func_uint32_t_u_u((!p_68), (*g_125))) , 0x1CF04AE1EF74E5CDLL) | p_67), 3UL))), p_67))) , l_370[2][3]))) , l_528) && l_229) & (*g_157)) < p_66) , (void*)0)) > g_103) <= 0xEE2FA31D04D463EBLL) <= p_66) , p_68) <= 0L), (*l_511))), l_529)) > g_356)), 0xD94CL)) , 255UL), p_67));
                    }
                }
                else
                { /* block id: 211 */
                    for (g_398 = (-24); (g_398 > 25); g_398 = safe_add_func_int64_t_s_s(g_398, 1))
                    { /* block id: 214 */
                        (*l_467) = (*g_145);
                        return &g_39;
                    }
                    if ((**g_145))
                        break;
                    for (l_401 = (-13); (l_401 != (-13)); l_401 = safe_add_func_int8_t_s_s(l_401, 3))
                    { /* block id: 221 */
                        int32_t *l_536 = &l_400;
                        return &g_39;
                    }
                    if ((**l_467))
                        break;
                }
                (*g_125) = (-1L);
                if (p_68)
                    continue;
                (*g_125) &= (((*g_376) &= 0x87L) , (safe_lshift_func_uint16_t_u_s((safe_rshift_func_uint8_t_u_s(p_67, l_226[8])), (((((l_224[2] , ((*g_97) < l_224[0])) | ((((*g_376) = (safe_sub_func_int8_t_s_s(0xF0L, ((-7L) >= (safe_mod_func_uint16_t_u_u(0xC564L, p_68)))))) || 0xACL) != 1L)) & (*g_157)) < 0x6BL) >= l_150.f1))));
            }
        }
    }
    else
    { /* block id: 233 */
        int32_t *l_545 = &l_104[1];
        int32_t **l_546 = &g_125;
        uint8_t l_568 = 8UL;
lbl_571:
        (*l_546) = l_545;
        for (g_356 = 0; (g_356 <= 4); g_356 += 1)
        { /* block id: 237 */
            int16_t ***l_557 = &g_269[3][2][0];
            const int64_t ***l_565 = &l_564;
            int32_t l_566[3][10][6] = {{{0xF4BC9DBFL,(-1L),0L,0x65FFEF23L,0xA8A2FFE7L,0x271B03E5L},{0x2F20CABAL,0x8A5B444AL,(-1L),1L,0L,4L},{0xA8A2FFE7L,0L,0xEE181A45L,(-2L),1L,1L},{0xF037F553L,(-1L),(-1L),0xF037F553L,4L,0L},{(-1L),0x38DC69F4L,(-1L),0L,0x271B03E5L,0xA8A2FFE7L},{0x2DF8C72EL,(-9L),0x2F20CABAL,0L,0x271B03E5L,(-10L)},{(-10L),0x38DC69F4L,(-2L),0x8A5B444AL,4L,(-1L)},{(-3L),(-1L),0xD65106DEL,0xF4BC9DBFL,1L,0xF4BC9DBFL},{0x38DC69F4L,0L,0x38DC69F4L,(-3L),0L,0x67524BDFL},{6L,0x8A5B444AL,1L,(-1L),0xA8A2FFE7L,0xD65106DEL}},{{0x67524BDFL,(-1L),(-1L),(-1L),(-10L),(-3L)},{6L,0x65FFEF23L,(-9L),(-3L),(-1L),0xEE181A45L},{0x38DC69F4L,0x2F20CABAL,0x9A4101C2L,0xF4BC9DBFL,0xF4BC9DBFL,0x9A4101C2L},{(-3L),(-3L),0xA84487C8L,0x8A5B444AL,0x67524BDFL,0x2F20CABAL},{(-10L),0x9A4101C2L,0xF037F553L,0L,0xD65106DEL,0xA84487C8L},{0x2DF8C72EL,(-10L),0x9A4101C2L,(-1L),0x271B03E5L,0x67524BDFL},{0xF4BC9DBFL,(-1L),(-1L),0x9A4101C2L,0L,(-9L)},{0x9A4101C2L,0L,(-9L),(-1L),(-9L),0L},{0L,0x38DC69F4L,(-3L),0L,0x67524BDFL,0x271B03E5L},{0x67524BDFL,0xEE181A45L,4L,(-10L),(-1L),0x96DB09CDL}},{{0x8A5B444AL,0xEE181A45L,0L,(-1L),0x67524BDFL,0xA8A2FFE7L},{(-1L),0x38DC69F4L,0x65FFEF23L,0x67524BDFL,(-9L),0x8A5B444AL},{(-2L),0L,0x96DB09CDL,0x96DB09CDL,0L,(-2L)},{6L,(-1L),(-1L),1L,0x271B03E5L,0xA84487C8L},{(-1L),0xA84487C8L,0x67524BDFL,0xF037F553L,0x96DB09CDL,0L},{(-1L),(-9L),0xF037F553L,1L,0xA8A2FFE7L,0x38DC69F4L},{6L,0x271B03E5L,0xF4BC9DBFL,0x96DB09CDL,0x8A5B444AL,0L},{(-2L),0x67524BDFL,0L,0x67524BDFL,(-2L),0x2F20CABAL},{(-1L),(-10L),(-2L),(-1L),0xA84487C8L,1L},{0x8A5B444AL,(-2L),0x38DC69F4L,(-10L),0L,1L}}};
            int i, j, k;
            (*l_545) = 9L;
            if (p_67)
                break;
            if ((safe_div_func_uint16_t_u_u((*g_157), (safe_div_func_int32_t_s_s((safe_lshift_func_uint8_t_u_s(p_66, 0)), (safe_sub_func_int32_t_s_s((safe_sub_func_int16_t_s_s((1L || p_66), ((l_557 == l_557) != (((((((*l_102) = ((((*l_105) = ((safe_mod_func_int32_t_s_s(0L, ((safe_mul_func_uint16_t_u_u((safe_div_func_int16_t_s_s((((((*l_565) = l_564) != &l_102) < 0UL) | l_150.f0), l_566[2][2][1])), (*g_270))) , (-10L)))) < g_139)) < g_103) , l_566[2][2][1])) && (*g_97)) && 1L) | l_567) , g_303) == l_336[5])))), p_66)))))))
            { /* block id: 243 */
                (*l_546) = (*g_145);
            }
            else
            { /* block id: 245 */
                l_568++;
            }
            for (g_106 = 5; (g_106 >= 1); g_106 -= 1)
            { /* block id: 250 */
                int32_t *l_572 = (void*)0;
                int i, j;
                if (l_370[g_356][g_106])
                { /* block id: 251 */
                    (*l_545) = (**l_546);
                    if (l_218)
                        goto lbl_571;
                }
                else
                { /* block id: 254 */
                    g_374 = &g_375[1];
                    return l_572;
                }
                (*l_546) = (*g_145);
            }
        }
        (*g_125) &= p_66;
        (*g_125) &= (&g_360 != (void*)0);
    }
    return &g_39;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_39, "g_39", print_hash_value);
    transparent_crc(g_44, "g_44", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_81[i][j], "g_81[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_98.f0, "g_98.f0", print_hash_value);
    transparent_crc(g_98.f1, "g_98.f1", print_hash_value);
    transparent_crc(g_103, "g_103", print_hash_value);
    transparent_crc(g_106, "g_106", print_hash_value);
    transparent_crc(g_126, "g_126", print_hash_value);
    transparent_crc(g_139, "g_139", print_hash_value);
    transparent_crc(g_162, "g_162", print_hash_value);
    transparent_crc(g_214, "g_214", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_217[i][j], "g_217[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_303, "g_303", print_hash_value);
    transparent_crc(g_320, "g_320", print_hash_value);
    transparent_crc(g_356, "g_356", print_hash_value);
    transparent_crc(g_398, "g_398", print_hash_value);
    transparent_crc(g_469, "g_469", print_hash_value);
    transparent_crc(g_506, "g_506", print_hash_value);
    transparent_crc(g_577, "g_577", print_hash_value);
    transparent_crc(g_592, "g_592", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_681[i][j], "g_681[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_684, "g_684", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_688[i][j][k], "g_688[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_690, "g_690", print_hash_value);
    transparent_crc(g_720, "g_720", print_hash_value);
    transparent_crc(g_721, "g_721", print_hash_value);
    transparent_crc(g_828, "g_828", print_hash_value);
    transparent_crc(g_920, "g_920", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_922[i][j].f0, "g_922[i][j].f0", print_hash_value);
            transparent_crc(g_922[i][j].f1, "g_922[i][j].f1", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1014, "g_1014", print_hash_value);
    transparent_crc(g_1280, "g_1280", print_hash_value);
    transparent_crc(g_1285, "g_1285", print_hash_value);
    transparent_crc(g_1360, "g_1360", print_hash_value);
    transparent_crc(g_1626, "g_1626", print_hash_value);
    transparent_crc(g_1641, "g_1641", print_hash_value);
    transparent_crc(g_1703, "g_1703", print_hash_value);
    transparent_crc(g_2129, "g_2129", print_hash_value);
    transparent_crc(g_2259, "g_2259", print_hash_value);
    transparent_crc(g_2422, "g_2422", print_hash_value);
    transparent_crc(g_2423, "g_2423", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 605
XXX total union variables: 13

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 49
breakdown:
   depth: 1, occurrence: 170
   depth: 2, occurrence: 49
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1
   depth: 14, occurrence: 3
   depth: 17, occurrence: 3
   depth: 19, occurrence: 1
   depth: 20, occurrence: 1
   depth: 21, occurrence: 3
   depth: 22, occurrence: 2
   depth: 23, occurrence: 2
   depth: 25, occurrence: 1
   depth: 27, occurrence: 2
   depth: 28, occurrence: 1
   depth: 29, occurrence: 1
   depth: 30, occurrence: 1
   depth: 31, occurrence: 3
   depth: 32, occurrence: 1
   depth: 34, occurrence: 1
   depth: 35, occurrence: 1
   depth: 37, occurrence: 1
   depth: 43, occurrence: 1
   depth: 46, occurrence: 1
   depth: 49, occurrence: 1

XXX total number of pointers: 526

XXX times a variable address is taken: 1275
XXX times a pointer is dereferenced on RHS: 325
breakdown:
   depth: 1, occurrence: 225
   depth: 2, occurrence: 74
   depth: 3, occurrence: 22
   depth: 4, occurrence: 3
   depth: 5, occurrence: 1
XXX times a pointer is dereferenced on LHS: 272
breakdown:
   depth: 1, occurrence: 242
   depth: 2, occurrence: 19
   depth: 3, occurrence: 7
   depth: 4, occurrence: 3
   depth: 5, occurrence: 1
XXX times a pointer is compared with null: 37
XXX times a pointer is compared with address of another variable: 9
XXX times a pointer is compared with another pointer: 4
XXX times a pointer is qualified to be dereferenced: 8518

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1286
   level: 2, occurrence: 264
   level: 3, occurrence: 109
   level: 4, occurrence: 31
   level: 5, occurrence: 7
XXX number of pointers point to pointers: 255
XXX number of pointers point to scalars: 266
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 28.3
XXX average alias set size: 1.47

XXX times a non-volatile is read: 1921
XXX times a non-volatile is write: 868
XXX times a volatile is read: 112
XXX    times read thru a pointer: 54
XXX times a volatile is write: 46
XXX    times written thru a pointer: 16
XXX times a volatile is available for access: 2.32e+03
XXX percentage of non-volatile access: 94.6

XXX forward jumps: 1
XXX backward jumps: 7

XXX stmts: 174
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 22
   depth: 1, occurrence: 20
   depth: 2, occurrence: 15
   depth: 3, occurrence: 27
   depth: 4, occurrence: 52
   depth: 5, occurrence: 38

XXX percentage a fresh-made variable is used: 16.7
XXX percentage an existing variable is used: 83.3
********************* end of statistics **********************/

