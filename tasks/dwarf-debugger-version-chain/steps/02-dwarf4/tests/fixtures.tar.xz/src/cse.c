/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --seed 100505 --max-funcs 8
 * Seed:      100505
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint16_t g_2 = 0UL;
static int32_t g_4 = (-1L);
static int32_t g_5[7][1][4] = {{{0xFC2285FAL,(-4L),(-4L),0xFC2285FAL}},{{(-4L),0xFC2285FAL,0xB34E6D4FL,1L}},{{(-4L),0xB34E6D4FL,(-4L),0x664DC9EDL}},{{0xFC2285FAL,1L,0x664DC9EDL,0x664DC9EDL}},{{0xB34E6D4FL,0xB34E6D4FL,8L,1L}},{{1L,0xFC2285FAL,8L,0xFC2285FAL}},{{0xB34E6D4FL,(-4L),0x664DC9EDL,8L}}};
static volatile int32_t g_57 = 0x642D9490L;/* VOLATILE GLOBAL g_57 */
static volatile int32_t * volatile g_56[3] = {&g_57,&g_57,&g_57};
static int32_t g_59 = 0xE4F9F010L;
static int32_t *g_58 = &g_59;
static uint64_t g_71[8] = {18446744073709551612UL,0xD90DC6CE91E412D4LL,18446744073709551612UL,0xD90DC6CE91E412D4LL,18446744073709551612UL,0xD90DC6CE91E412D4LL,18446744073709551612UL,0xD90DC6CE91E412D4LL};
static uint16_t g_95[7] = {0x0E53L,0x0E53L,0x0E53L,0x0E53L,0x0E53L,0x0E53L,0x0E53L};
static uint16_t g_98 = 65527UL;
static int64_t g_113 = 0x7480E96666BE2F81LL;
static int64_t *g_112 = &g_113;
static uint8_t g_117[3][1] = {{0x45L},{0x45L},{0x45L}};
static volatile uint8_t g_126 = 0x90L;/* VOLATILE GLOBAL g_126 */
static volatile uint8_t *g_125 = &g_126;
static int8_t g_144 = 0xDFL;
static int32_t g_149 = 0xFA558AB6L;
static int32_t ** volatile g_151 = &g_58;/* VOLATILE GLOBAL g_151 */
static uint32_t g_155 = 0x60842E3BL;
static int16_t g_158 = 0xD43BL;
static uint32_t g_172 = 0xA09A699AL;
static uint8_t g_233 = 8UL;
static int64_t g_235[9][4][2] = {{{0xDB1092C0A3A697CBLL,0xDB1092C0A3A697CBLL},{0L,0xDB1092C0A3A697CBLL},{0xDB1092C0A3A697CBLL,0L},{0xDB1092C0A3A697CBLL,0xDB1092C0A3A697CBLL}},{{0L,0xDB1092C0A3A697CBLL},{0xDB1092C0A3A697CBLL,0L},{0xDB1092C0A3A697CBLL,0xDB1092C0A3A697CBLL},{0L,0xDB1092C0A3A697CBLL}},{{0xDB1092C0A3A697CBLL,0L},{0xDB1092C0A3A697CBLL,0xDB1092C0A3A697CBLL},{0L,0xDB1092C0A3A697CBLL},{0xDB1092C0A3A697CBLL,0L}},{{0xDB1092C0A3A697CBLL,0xDB1092C0A3A697CBLL},{0L,0xDB1092C0A3A697CBLL},{0xDB1092C0A3A697CBLL,0L},{0xDB1092C0A3A697CBLL,0xDB1092C0A3A697CBLL}},{{0L,0xDB1092C0A3A697CBLL},{0xDB1092C0A3A697CBLL,0L},{0xDB1092C0A3A697CBLL,0xDB1092C0A3A697CBLL},{0L,0xDB1092C0A3A697CBLL}},{{0xDB1092C0A3A697CBLL,0L},{0xDB1092C0A3A697CBLL,0xDB1092C0A3A697CBLL},{0L,0xDB1092C0A3A697CBLL},{0xDB1092C0A3A697CBLL,0L}},{{0xDB1092C0A3A697CBLL,0xDB1092C0A3A697CBLL},{0L,0xDB1092C0A3A697CBLL},{0xDB1092C0A3A697CBLL,0L},{0xDB1092C0A3A697CBLL,0xDB1092C0A3A697CBLL}},{{0L,0xDB1092C0A3A697CBLL},{0xDB1092C0A3A697CBLL,0L},{0xDB1092C0A3A697CBLL,0xDB1092C0A3A697CBLL},{0L,0xDB1092C0A3A697CBLL}},{{0xDB1092C0A3A697CBLL,0L},{0xDB1092C0A3A697CBLL,0xDB1092C0A3A697CBLL},{0L,0xDB1092C0A3A697CBLL},{0xDB1092C0A3A697CBLL,0L}}};
static uint32_t g_270 = 0x3579EFBFL;
static int8_t g_305 = 0x7FL;
static uint32_t *g_390 = &g_155;
static uint32_t **g_389 = &g_390;
static int32_t * volatile g_411 = &g_59;/* VOLATILE GLOBAL g_411 */
static volatile uint8_t **g_416 = (void*)0;
static volatile uint8_t *** volatile g_415 = &g_416;/* VOLATILE GLOBAL g_415 */
static uint32_t *g_444 = &g_270;
static uint32_t * volatile *g_443 = &g_444;
static uint32_t * volatile * volatile * const g_442 = &g_443;
static int32_t ** volatile g_453 = &g_58;/* VOLATILE GLOBAL g_453 */
static uint32_t g_473 = 2UL;
static uint32_t g_510 = 0xCAB5B0D8L;
static int32_t ** volatile g_513 = &g_58;/* VOLATILE GLOBAL g_513 */
static const uint32_t *g_532[8][5][2] = {{{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172}},{{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172}},{{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172}},{{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172}},{{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172}},{{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172}},{{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172}},{{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172},{&g_172,&g_172}}};
static const uint32_t **g_531 = &g_532[7][2][1];
static const uint32_t ***g_530 = &g_531;
static uint8_t g_534 = 0x8BL;
static int32_t g_536[7][9][2] = {{{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L}},{{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L}},{{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L}},{{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L}},{{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L}},{{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L}},{{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L},{0L,0xEF3BAEC6L}}};
static int32_t * const  volatile g_535 = &g_536[6][7][1];/* VOLATILE GLOBAL g_535 */
static uint32_t **g_547 = &g_444;
static uint32_t g_619 = 4294967295UL;
static uint32_t ***g_640 = &g_547;
static uint32_t **** volatile g_639 = &g_640;/* VOLATILE GLOBAL g_639 */
static int32_t *g_650 = &g_4;
static int32_t ** volatile g_649 = &g_650;/* VOLATILE GLOBAL g_649 */
static uint64_t g_680[7] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL};
static int32_t ** volatile g_701 = &g_58;/* VOLATILE GLOBAL g_701 */
static volatile int8_t g_754 = 0x31L;/* VOLATILE GLOBAL g_754 */
static int16_t g_805 = 1L;
static int32_t ** volatile *g_809 = &g_701;
static int32_t ** volatile ** volatile g_808 = &g_809;/* VOLATILE GLOBAL g_808 */
static int64_t **g_826[4][5][9] = {{{&g_112,&g_112,&g_112,&g_112,(void*)0,&g_112,&g_112,&g_112,&g_112},{&g_112,&g_112,(void*)0,(void*)0,&g_112,&g_112,&g_112,&g_112,(void*)0},{(void*)0,&g_112,&g_112,(void*)0,(void*)0,&g_112,(void*)0,&g_112,&g_112},{&g_112,&g_112,&g_112,&g_112,&g_112,&g_112,&g_112,&g_112,&g_112},{&g_112,&g_112,&g_112,&g_112,&g_112,&g_112,&g_112,&g_112,&g_112}},{{&g_112,&g_112,(void*)0,(void*)0,&g_112,&g_112,(void*)0,&g_112,(void*)0},{(void*)0,&g_112,&g_112,(void*)0,&g_112,(void*)0,&g_112,&g_112,(void*)0},{&g_112,&g_112,(void*)0,&g_112,(void*)0,(void*)0,&g_112,&g_112,(void*)0},{&g_112,(void*)0,&g_112,&g_112,&g_112,&g_112,&g_112,&g_112,&g_112},{&g_112,(void*)0,&g_112,&g_112,&g_112,&g_112,&g_112,(void*)0,&g_112}},{{&g_112,&g_112,&g_112,&g_112,(void*)0,(void*)0,&g_112,(void*)0,&g_112},{(void*)0,&g_112,&g_112,(void*)0,&g_112,(void*)0,(void*)0,&g_112,&g_112},{&g_112,(void*)0,&g_112,(void*)0,&g_112,(void*)0,&g_112,&g_112,&g_112},{&g_112,&g_112,&g_112,&g_112,(void*)0,&g_112,&g_112,&g_112,&g_112},{(void*)0,(void*)0,(void*)0,&g_112,(void*)0,(void*)0,(void*)0,(void*)0,&g_112}},{{&g_112,&g_112,&g_112,&g_112,&g_112,(void*)0,&g_112,&g_112,&g_112},{&g_112,&g_112,&g_112,&g_112,&g_112,&g_112,&g_112,(void*)0,&g_112},{(void*)0,&g_112,(void*)0,&g_112,(void*)0,&g_112,&g_112,&g_112,&g_112},{&g_112,&g_112,(void*)0,&g_112,(void*)0,&g_112,&g_112,&g_112,&g_112},{&g_112,(void*)0,&g_112,(void*)0,&g_112,(void*)0,&g_112,&g_112,&g_112}}};
static int64_t ***g_825[9][6] = {{&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7]},{&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7]},{&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7]},{&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7]},{&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7]},{&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7]},{&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7]},{&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7]},{&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7],&g_826[0][3][7]}};
static uint32_t ***g_845 = &g_389;
static uint32_t ****g_844 = &g_845;
static int32_t g_855 = 0xD3FD7585L;
static uint32_t ** const *g_864 = &g_547;
static uint32_t ** const **g_863 = &g_864;
static volatile uint64_t * volatile * volatile g_878 = (void*)0;/* VOLATILE GLOBAL g_878 */
static uint64_t **g_886 = (void*)0;
static uint64_t ***g_922 = (void*)0;
static uint64_t *g_935 = &g_71[4];
static uint64_t **g_934 = &g_935;
static uint64_t *** const g_933 = &g_934;
static uint64_t *** const *g_932 = &g_933;
static int16_t g_1026 = 0x6225L;
static int8_t *g_1109 = &g_305;
static int8_t **g_1108 = &g_1109;
static uint16_t g_1136 = 0xD04AL;
static int32_t **g_1159 = &g_650;
static int32_t ***g_1158[9] = {&g_1159,&g_1159,&g_1159,&g_1159,&g_1159,&g_1159,&g_1159,&g_1159,&g_1159};
static int32_t g_1200 = 3L;
static int32_t * const *g_1276[9][9] = {{(void*)0,&g_650,(void*)0,(void*)0,(void*)0,&g_650,&g_650,&g_650,&g_650},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_58,&g_58,(void*)0},{&g_58,&g_650,&g_58,&g_650,(void*)0,&g_58,(void*)0,&g_650,(void*)0},{(void*)0,&g_650,&g_650,&g_58,&g_58,(void*)0,&g_58,&g_650,&g_650},{&g_58,&g_650,&g_58,&g_650,(void*)0,&g_650,(void*)0,&g_650,(void*)0},{&g_650,(void*)0,&g_650,&g_58,&g_58,(void*)0,&g_650,&g_58,(void*)0},{&g_650,&g_650,(void*)0,(void*)0,&g_650,&g_58,(void*)0,(void*)0,&g_58},{&g_650,&g_58,&g_650,(void*)0,(void*)0,&g_650,&g_58,&g_650,(void*)0},{(void*)0,&g_650,&g_650,(void*)0,&g_650,&g_650,&g_650,(void*)0,&g_58}};
static int32_t * const **g_1275 = &g_1276[6][0];
static uint32_t *****g_1368 = &g_844;
static uint64_t ** const *g_1382 = &g_886;
static uint64_t ** const **g_1381 = &g_1382;
static volatile uint32_t g_1395 = 0x4F9DD97CL;/* VOLATILE GLOBAL g_1395 */
static const int8_t g_1432 = 1L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t * func_6(uint32_t  p_7, const int32_t  p_8, int32_t * p_9, int32_t * p_10);
static uint64_t  func_12(int32_t  p_13, uint32_t  p_14, const int32_t * p_15);
static int32_t  func_16(uint8_t  p_17, uint16_t  p_18, uint16_t  p_19, uint32_t  p_20, int32_t * p_21);
static uint8_t  func_23(int8_t  p_24);
static int8_t  func_25(uint8_t  p_26, uint8_t  p_27, uint32_t  p_28, int32_t * p_29, const uint32_t  p_30);
static int32_t * func_45(uint16_t  p_46, int32_t * p_47);
static int32_t * func_50(int64_t  p_51, uint16_t  p_52);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_5 g_444 g_270
 * writes: g_4 g_5
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t *l_3[8] = {&g_4,&g_4,&g_4,&g_4,&g_4,&g_4,&g_4,&g_4};
    int32_t l_11 = 0x959310C1L;
    uint8_t l_514[4];
    const int32_t *l_537 = (void*)0;
    int32_t **l_732 = &l_3[1];
    uint32_t l_752 = 0x9B3BDCE4L;
    uint64_t l_779[1][2];
    int8_t l_816 = 0x6FL;
    int32_t *l_854 = &g_855;
    uint64_t ***l_920[7][3] = {{&g_886,&g_886,&g_886},{&g_886,&g_886,&g_886},{&g_886,(void*)0,(void*)0},{&g_886,&g_886,&g_886},{&g_886,&g_886,&g_886},{&g_886,(void*)0,(void*)0},{&g_886,&g_886,&g_886}};
    uint64_t l_963 = 18446744073709551615UL;
    uint16_t l_1024 = 65535UL;
    uint8_t ***l_1064 = (void*)0;
    int32_t *l_1071 = &g_536[5][0][0];
    int32_t l_1110 = 1L;
    const uint8_t **l_1135 = (void*)0;
    uint8_t l_1225[7] = {6UL,0x85L,6UL,6UL,0x85L,6UL,6UL};
    uint64_t l_1251 = 0UL;
    uint8_t l_1292 = 1UL;
    int64_t **l_1300[4][3] = {{&g_112,&g_112,&g_112},{&g_112,&g_112,&g_112},{&g_112,&g_112,&g_112},{&g_112,&g_112,&g_112}};
    uint16_t l_1323 = 0xE1DBL;
    uint32_t ****l_1324[8][1] = {{&g_845},{&g_845},{&g_845},{&g_845},{&g_845},{&g_845},{&g_845},{&g_845}};
    uint32_t l_1388 = 18446744073709551613UL;
    const int8_t *l_1431 = &g_1432;
    uint8_t ****l_1441 = &l_1064;
    int i, j;
    for (i = 0; i < 4; i++)
        l_514[i] = 1UL;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 2; j++)
            l_779[i][j] = 0xABA52601DE88B6E6LL;
    }
    g_5[4][0][3] |= (g_4 = g_2);
    return (*g_444);
}


/* ------------------------------------------ */
/* 
 * reads : g_536 g_443 g_444 g_71 g_389 g_390 g_155 g_473 g_98 g_112 g_58 g_4 g_59 g_95 g_513 g_113 g_117 g_125 g_57 g_2 g_149 g_126 g_619 g_235 g_639 g_151 g_649 g_640 g_510 g_650 g_701 g_305 g_270 g_158 g_5
 * writes: g_547 g_270 g_71 g_155 g_113 g_95 g_59 g_117 g_2 g_98 g_4 g_5 g_144 g_149 g_619 g_536 g_58 g_640 g_650 g_680 g_389 g_390 g_158 g_473
 */
static int32_t * func_6(uint32_t  p_7, const int32_t  p_8, int32_t * p_9, int32_t * p_10)
{ /* block id: 227 */
    int32_t *l_538 = &g_536[6][7][1];
    int32_t *l_539[2][1];
    int64_t l_540 = (-1L);
    int8_t l_541 = 0L;
    uint32_t l_542[5][9][5] = {{{1UL,0x6712442DL,18446744073709551615UL,6UL,0xD14B63FBL},{9UL,0x818E0C24L,0x585A8239L,0xE0789349L,0UL},{7UL,0xEE1213E0L,0x50F3650FL,0xD1A8234CL,1UL},{6UL,1UL,18446744073709551615UL,0x1E7CAB86L,0xEE1213E0L},{1UL,18446744073709551615UL,4UL,0x544DF1C6L,0x6CE2C103L},{0xD14B63FBL,18446744073709551615UL,0x67D29A99L,0x544DF1C6L,0x01E8BBB8L},{0x6C857163L,0x6C5379EFL,18446744073709551609UL,0x1E7CAB86L,0x544DF1C6L},{1UL,18446744073709551615UL,0xEABFF752L,0xD1A8234CL,1UL},{0x0614EBECL,0x544DF1C6L,18446744073709551611UL,0xE0789349L,0x21CEBDC7L}},{{18446744073709551613UL,0x9F4CAC0AL,18446744073709551615UL,6UL,1UL},{1UL,0x6C857163L,0x267BE156L,0xD49C7E69L,18446744073709551615UL},{0x4931B5D4L,18446744073709551615UL,18446744073709551615UL,0x469960FCL,0x469960FCL},{0x1BDBFAF8L,0x67E4E26EL,0x1BDBFAF8L,0xC9AF4CA2L,1UL},{0x67E4E26EL,0xC9AF4CA2L,1UL,0x01E8BBB8L,0x37433650L},{18446744073709551607UL,0xEE1213E0L,7UL,0xD14B63FBL,1UL},{0x1E7CAB86L,18446744073709551608UL,1UL,0x37433650L,0x544DF1C6L},{0xC4E54378L,0x1E7CAB86L,0x1BDBFAF8L,18446744073709551607UL,18446744073709551615UL},{0x3055E7B1L,7UL,18446744073709551615UL,0x9F4CAC0AL,0x4F2E8340L}},{{0x9C647753L,0x4931B5D4L,0x267BE156L,0x9C647753L,0xEE1213E0L},{0xEABFF752L,18446744073709551614UL,18446744073709551611UL,0x6C857163L,0x290934B9L},{0xE84E1E6BL,0x53BEECCEL,0x4931B5D4L,0x5639610EL,18446744073709551615UL},{1UL,0xC9AF4CA2L,18446744073709551614UL,0x22BADCB8L,0UL},{0x9C647753L,18446744073709551609UL,0x22BADCB8L,0x267BE156L,0x28D48069L},{18446744073709551613UL,18446744073709551615UL,1UL,0x1223EB6AL,1UL},{0xC6301EECL,18446744073709551615UL,0xAEBECDA8L,1UL,0x818E0C24L},{18446744073709551615UL,18446744073709551609UL,0x28D48069L,0xB1BBBB05L,0x44B29415L},{0x37433650L,0xC9AF4CA2L,0x4F2E8340L,0UL,0x69B1801EL}},{{0x22BADCB8L,0x53BEECCEL,1UL,18446744073709551609UL,18446744073709551606UL},{18446744073709551609UL,18446744073709551614UL,7UL,0x585A8239L,0xC6301EECL},{18446744073709551606UL,0x818E0C24L,0x01E8BBB8L,0x6CE2C103L,1UL},{18446744073709551614UL,3UL,0x67D29A99L,0x67D29A99L,3UL},{0x5639610EL,0x3ED17237L,7UL,0x53BEECCEL,18446744073709551614UL},{0x53BEECCEL,4UL,0x67E4E26EL,1UL,18446744073709551615UL},{0x28D48069L,18446744073709551615UL,7UL,0xC77AE5BBL,18446744073709551615UL},{0x53BEECCEL,0xA0DD0116L,0x28D48069L,0xE84E1E6BL,1UL},{0x5639610EL,0x9C647753L,18446744073709551615UL,18446744073709551615UL,0x1E7CAB86L}},{{18446744073709551614UL,6UL,18446744073709551609UL,0x50F3650FL,0x9283492CL},{18446744073709551606UL,0x44B29415L,0x22BADCB8L,0xE84E1E6BL,0x50F3650FL},{18446744073709551609UL,0x1223EB6AL,9UL,0x37433650L,0x5639610EL},{0x22BADCB8L,18446744073709551615UL,18446744073709551615UL,0UL,0xB1BBBB05L},{0x37433650L,7UL,18446744073709551611UL,0x53BEECCEL,0UL},{18446744073709551615UL,18446744073709551606UL,18446744073709551608UL,18446744073709551615UL,0x6CE2C103L},{0xC6301EECL,6UL,0x50F3650FL,7UL,0x6CE2C103L},{18446744073709551613UL,18446744073709551611UL,18446744073709551607UL,0x585A8239L,0UL},{0x9C647753L,0x585A8239L,0x27B3B866L,0x9283492CL,0xB1BBBB05L}}};
    const uint32_t *l_549 = &g_510;
    const uint32_t **l_548 = &l_549;
    int32_t * const *l_569 = (void*)0;
    int32_t * const **l_568 = &l_569;
    uint64_t *l_570 = &g_71[3];
    uint32_t *l_697 = &g_473;
    const uint32_t ***l_698 = &g_531;
    int64_t **l_707 = &g_112;
    int64_t ***l_706 = &l_707;
    int16_t *l_722 = &g_158;
    int16_t **l_721 = &l_722;
    const int16_t l_731 = 0x0D4CL;
    int i, j, k;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
            l_539[i][j] = &g_536[6][7][1];
    }
    --l_542[2][5][4];
    if ((((*p_9) = (safe_sub_func_uint16_t_u_u((((g_547 = (void*)0) != l_548) ^ (safe_mod_func_int16_t_s_s((((safe_rshift_func_uint16_t_u_s(((safe_mod_func_int32_t_s_s((safe_mul_func_uint16_t_u_u((0L || (*l_538)), ((safe_mul_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_s((0xB15FF7BCL < (*l_538)), (((*l_570) &= (safe_mul_func_int8_t_s_s(p_8, (safe_rshift_func_uint8_t_u_s(0x5EL, (((**g_443) = ((safe_lshift_func_uint16_t_u_s((((*l_568) = &g_58) == &p_10), 14)) , p_7)) , 0x0AL)))))) & 7UL))), p_8)) ^ (*l_538)))), (**g_389))) >= p_8), p_7)) <= 0xFFL) , (-8L)), 1L))), g_473))) ^ 4294967293UL))
    { /* block id: 234 */
        uint16_t *l_578 = &g_95[3];
        int32_t l_579 = 0xA78D67CBL;
        int32_t **l_580 = &l_539[1][0];
        (*l_580) = func_45((((safe_sub_func_int8_t_s_s(0x6EL, (safe_rshift_func_uint16_t_u_s(7UL, ((!(g_98 <= ((*l_578) |= (((*g_112) = 0xDF34194118A9ADBDLL) ^ (((((void*)0 != &g_158) ^ (***l_568)) > 0L) | (safe_mod_func_uint8_t_u_u((0xB3L > p_8), 1UL))))))) > g_71[0]))))) | g_71[1]) , l_579), (*g_513));
        return p_10;
    }
    else
    { /* block id: 239 */
        int64_t l_591 = 7L;
        int32_t l_598 = 0xC537C6F0L;
        int32_t l_604 = 0xA04CF7FDL;
        int32_t l_607 = 0x692C4DB9L;
        int32_t l_608 = 0x9552A4F7L;
        int32_t l_610[4][4] = {{0x9177336EL,0L,0x9177336EL,0L},{0x9177336EL,0L,0x9177336EL,0L},{0x9177336EL,0L,0x9177336EL,0L},{0x9177336EL,0L,0x9177336EL,0L}};
        uint32_t ***l_628 = &g_389;
        uint32_t ****l_627 = &l_628;
        int i, j;
        (*p_9) &= (safe_rshift_func_int8_t_s_u((*l_538), 5));
        for (g_4 = 1; (g_4 >= 0); g_4 = safe_sub_func_int8_t_s_s(g_4, 1))
        { /* block id: 243 */
            uint8_t l_588[9] = {0xC4L,0x0CL,0xC4L,0x0CL,0xC4L,0x0CL,0xC4L,0x0CL,0xC4L};
            int32_t l_595 = 1L;
            int32_t l_597 = 0xD0982AC1L;
            int32_t l_600 = 6L;
            int32_t l_612 = 0x1F12D1B3L;
            int32_t l_613 = 1L;
            int32_t l_614 = 6L;
            int32_t l_615 = 0xAB515D10L;
            int32_t l_616 = (-10L);
            int32_t l_617 = 9L;
            int32_t l_618 = 0L;
            uint32_t ***l_622 = &g_547;
            int8_t *l_632 = &l_541;
            int i;
            for (l_540 = 0; (l_540 <= 2); l_540 += 1)
            { /* block id: 246 */
                uint64_t *l_587 = &g_71[0];
                int32_t l_589 = 0x1CBD9329L;
                int32_t l_593 = 8L;
                int32_t l_594 = 0L;
                int32_t l_596 = 0x046FDC1EL;
                int32_t l_602[5];
                int32_t **l_638 = &g_58;
                int i;
                for (i = 0; i < 5; i++)
                    l_602[i] = 0x1E349C15L;
                for (g_270 = 0; (g_270 <= 2); g_270 += 1)
                { /* block id: 249 */
                    int8_t l_590 = 0x6CL;
                    int32_t l_592 = 0xD5ACA135L;
                    int32_t l_601[7][9][4] = {{{(-5L),0x21F11F1EL,0xC3A22140L,0x683F8B51L},{0x290864DEL,0x00895DDEL,(-5L),(-5L)},{0x9FB9E715L,0x9FB9E715L,1L,(-1L)},{0x21F11F1EL,(-1L),0x00895DDEL,3L},{(-7L),1L,0xD9E19127L,0x00895DDEL},{0x7FA78B1AL,1L,3L,3L},{1L,(-1L),0x57D1B49EL,(-1L)},{0x9B4DE922L,0x9FB9E715L,0xA0925FF7L,(-5L)},{1L,0x00895DDEL,0x9FB9E715L,0x683F8B51L}},{{0x124F1BF0L,0L,(-5L),(-1L)},{0x19C30B11L,0xA0925FF7L,3L,(-7L)},{0xDD214105L,0x9F53F0A1L,0xDD214105L,0x00895DDEL},{(-1L),0xDD214105L,0x582085DFL,0x2CE4ADD6L},{(-7L),0x124F1BF0L,1L,0xDD214105L},{(-1L),0x26E06D45L,1L,0xC03A411DL},{(-7L),0x941A1719L,0x582085DFL,0xC3A22140L},{(-1L),1L,0xDD214105L,0xA1FC02D5L},{0xDD214105L,0xA1FC02D5L,3L,(-5L)}},{{0x19C30B11L,0x9B4DE922L,(-5L),3L},{0x124F1BF0L,3L,0x290864DEL,0x582085DFL},{1L,0x9FB9E715L,0x9FB9E715L,1L},{0xC3A22140L,1L,0x21F11F1EL,0x9F53F0A1L},{(-1L),(-1L),(-7L),0x683F8B51L},{(-1L),1L,0x7FA78B1AL,0x683F8B51L},{0x941A1719L,(-1L),1L,0x9F53F0A1L},{0L,1L,0x9B4DE922L,1L},{0x290864DEL,0x9FB9E715L,1L,0x582085DFL}},{{0x7AF04BF9L,3L,(-1L),3L},{1L,0x9B4DE922L,0xC03A411DL,(-5L)},{1L,0xA1FC02D5L,0x7AF04BF9L,0xA1FC02D5L},{0x57D1B49EL,1L,0x19C30B11L,0xC3A22140L},{0x683F8B51L,0x941A1719L,3L,0xC03A411DL},{0xC03A411DL,0x26E06D45L,0xC3A22140L,0xDD214105L},{0xC03A411DL,0x124F1BF0L,3L,0x2CE4ADD6L},{0x683F8B51L,0xDD214105L,0x19C30B11L,0x00895DDEL},{0x57D1B49EL,0x9F53F0A1L,0x7AF04BF9L,(-7L)}},{{1L,0xA0925FF7L,0xC03A411DL,(-1L)},{1L,0L,(-1L),(-1L)},{0x7AF04BF9L,1L,1L,1L},{0x290864DEL,0x290864DEL,0x9B4DE922L,0x26E06D45L},{0L,0x2CE4ADD6L,1L,1L},{0x941A1719L,(-1L),0x7FA78B1AL,1L},{(-1L),(-1L),(-7L),1L},{(-1L),0x2CE4ADD6L,0x21F11F1EL,0x26E06D45L},{0xC3A22140L,0x290864DEL,0x9FB9E715L,1L}},{{1L,1L,0x290864DEL,(-1L)},{0x124F1BF0L,0L,(-5L),(-1L)},{0x19C30B11L,0xA0925FF7L,3L,(-7L)},{0xDD214105L,0x9F53F0A1L,0xDD214105L,0x00895DDEL},{(-1L),0xDD214105L,0x582085DFL,0x2CE4ADD6L},{(-7L),0x124F1BF0L,1L,0xDD214105L},{(-1L),0x26E06D45L,1L,0xC03A411DL},{(-7L),0x941A1719L,0x582085DFL,0xC3A22140L},{(-1L),1L,0xDD214105L,0xA1FC02D5L}},{{0xDD214105L,0xA1FC02D5L,3L,(-5L)},{0x19C30B11L,0x9B4DE922L,(-5L),3L},{0x124F1BF0L,3L,0x7AF04BF9L,0x683F8B51L},{0x9B4DE922L,0x290864DEL,0x290864DEL,0x9B4DE922L},{(-1L),0xC03A411DL,0L,0xA0925FF7L},{3L,0x124F1BF0L,0x941A1719L,(-1L)},{0x9F53F0A1L,0x9B4DE922L,(-1L),(-1L)},{0x00895DDEL,0x124F1BF0L,(-1L),0xA0925FF7L},{0xA1FC02D5L,0xC03A411DL,0xC3A22140L,0x9B4DE922L}}};
                    int32_t l_611 = 1L;
                    int i, j, k;
                    if ((((safe_add_func_uint8_t_u_u(((&g_71[6] == l_587) != l_588[5]), l_589)) >= ((*g_112) = p_7)) || ((p_7 <= p_7) , ((((l_588[5] & ((**g_389) |= p_7)) || (*g_125)) | l_588[2]) , g_149))))
                    { /* block id: 252 */
                        int32_t l_599 = (-1L);
                        int32_t l_603 = 0L;
                        int32_t l_605 = 0x4BBEBD12L;
                        int32_t l_606 = 0xCC6D0255L;
                        int32_t l_609[10] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
                        int i;
                        g_619--;
                    }
                    else
                    { /* block id: 254 */
                        uint64_t **l_624[1][6] = {{&l_587,&l_587,&l_587,&l_587,&l_587,&l_587}};
                        uint64_t ***l_623 = &l_624[0][2];
                        uint32_t *****l_629 = &l_627;
                        uint16_t *l_633 = &g_95[4];
                        int i, j;
                        (*l_623) = ((l_622 != (void*)0) , &l_570);
                        (*l_538) = ((safe_lshift_func_int16_t_s_u((((*l_632) = ((((*l_629) = l_627) != &l_628) >= ((safe_rshift_func_int8_t_s_s(((0xB3EE1B4FL == (((0x791654AD9ECFBB32LL ^ (*g_112)) >= (((void*)0 != l_632) ^ ((++(*l_633)) ^ (safe_add_func_uint8_t_u_u(p_8, (0xE0L == p_8)))))) != g_235[3][0][1])) != 0xDEL), p_7)) > p_7))) && 1L), 0)) || 0xAB969DB850869115LL);
                    }
                }
                (*l_638) = (*l_569);
            }
            (*g_639) = &g_547;
            for (g_144 = 3; (g_144 != 5); ++g_144)
            { /* block id: 267 */
                uint8_t l_663 = 0x99L;
                int32_t l_670[3];
                uint32_t **l_682 = (void*)0;
                uint64_t l_705 = 0x350959DFD9E39221LL;
                int i;
                for (i = 0; i < 3; i++)
                    l_670[i] = 0xEC09AACEL;
                for (g_149 = (-14); (g_149 != (-2)); g_149++)
                { /* block id: 270 */
                    uint16_t l_673 = 65527UL;
                    uint32_t ***l_678 = &g_547;
                    int32_t l_681 = 1L;
                    for (l_595 = 26; (l_595 < 7); l_595--)
                    { /* block id: 273 */
                        int32_t **l_647 = (void*)0;
                        int32_t **l_648 = &l_539[0][0];
                        uint16_t *l_671 = (void*)0;
                        uint16_t *l_672[3][2][7] = {{{(void*)0,(void*)0,(void*)0,(void*)0,&g_95[3],&g_98,&g_95[3]},{&g_95[2],&g_95[3],&g_95[3],&g_95[2],&g_95[5],&g_98,&g_95[5]}},{{(void*)0,(void*)0,(void*)0,(void*)0,&g_95[3],&g_98,&g_95[3]},{&g_95[2],&g_95[3],&g_95[3],&g_95[2],&g_95[5],&g_98,&g_95[5]}},{{(void*)0,(void*)0,(void*)0,(void*)0,&g_95[3],&g_98,&g_95[3]},{&g_95[2],&g_95[3],&g_95[3],&g_95[2],&g_95[5],&g_98,&g_95[5]}}};
                        uint64_t *l_679 = &g_680[3];
                        int i, j, k;
                        (*g_649) = ((*l_648) = ((*g_151) = p_9));
                        (*g_650) ^= ((safe_rshift_func_uint16_t_u_s(0UL, (safe_lshift_func_uint16_t_u_u((safe_sub_func_int16_t_s_s(0x102DL, ((safe_add_func_uint16_t_u_u(p_7, (~((!(7L != (((((safe_add_func_int32_t_s_s(l_663, 0x73C8E110L)) , (safe_mod_func_uint64_t_u_u(18446744073709551615UL, (safe_add_func_uint8_t_u_u((((*l_679) = ((*l_570) = (safe_add_func_int8_t_s_s((((l_673++) && (safe_mul_func_int16_t_s_s(((l_678 != (*g_639)) & 0xECF5L), 0xB215L))) | p_8), 1UL)))) , p_7), g_619))))) , &g_113) == (void*)0) , p_8))) & l_681)))) , p_7))), g_510)))) < 4294967290UL);
                    }
                    for (l_617 = 1; (l_617 >= 0); l_617 -= 1)
                    { /* block id: 284 */
                        int32_t **l_683 = &g_58;
                        int i, j, k;
                        l_682 = ((**l_627) = (**l_627));
                        if (l_670[(l_617 + 1)])
                            continue;
                        (*l_683) = &g_536[(l_617 + 4)][(l_617 + 6)][l_617];
                    }
                }
                for (l_615 = 3; (l_615 <= 8); l_615 += 1)
                { /* block id: 293 */
                    for (l_591 = 0; (l_591 <= 8); l_591 += 1)
                    { /* block id: 296 */
                        uint32_t *l_696 = &g_619;
                        uint32_t **l_695[7] = {&l_696,&l_696,&l_696,&l_696,&l_696,&l_696,&l_696};
                        int i;
                        (*p_9) = (safe_div_func_int8_t_s_s((((((safe_div_func_uint64_t_u_u((safe_mod_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u((safe_add_func_uint64_t_u_u((!(l_588[l_591] < ((*g_112) = l_588[l_591]))), (((1UL || (p_8 , (((*g_389) = (*g_389)) != (l_697 = &p_7)))) >= ((((void*)0 == l_698) , (safe_rshift_func_int16_t_s_s(5L, 14))) , 0x6AFE5E99L)) , g_95[3]))), 6)), 0x5C5CL)), (-8L))) , g_59) , 6L) > p_7) >= 0x53D2BFFC8C4E3135LL), p_7));
                        return p_10;
                    }
                    for (l_663 = 0; (l_663 <= 8); l_663 += 1)
                    { /* block id: 305 */
                        uint32_t l_702[5][7] = {{0x6B711CB1L,1UL,1UL,1UL,0x6B711CB1L,0x6B711CB1L,1UL},{0UL,0x4BF0F230L,0UL,0xC3919441L,0xC3919441L,0UL,0x4BF0F230L},{1UL,4294967295UL,1UL,1UL,4294967295UL,1UL,4294967295UL},{0UL,0xC3919441L,0xC3919441L,0UL,0x4BF0F230L,0UL,0xC3919441L},{0x6B711CB1L,0x6B711CB1L,1UL,1UL,1UL,0x6B711CB1L,0x6B711CB1L}};
                        int i, j;
                        (*g_701) = (**l_568);
                        l_702[0][5]++;
                    }
                    return p_10;
                }
                l_705 ^= 0x2B5953E0L;
            }
        }
    }
    (*l_706) = &g_112;
    (*l_538) = (g_305 == ((safe_lshift_func_int16_t_s_s(((((*g_112) = (safe_add_func_uint32_t_u_u((safe_mod_func_uint8_t_u_u(((safe_unary_minus_func_uint32_t_u(((safe_div_func_int32_t_s_s((safe_add_func_uint16_t_u_u(((((((*g_390) = ((*l_697) ^= ((safe_mul_func_int8_t_s_s(((void*)0 != l_721), (safe_add_func_int16_t_s_s((safe_add_func_int8_t_s_s((((((**l_721) |= (safe_mod_func_uint8_t_u_u(2UL, ((safe_mul_func_int16_t_s_s(p_7, p_7)) , g_270)))) & g_5[0][0][3]) | (0x8DL ^ 0x4DL)) != (**g_513)), 0x1DL)), (*l_538))))) < (-1L)))) ^ (-1L)) ^ p_7) | 1L) | p_8), l_731)), p_8)) > p_7))) & 0x3422L), 0x02L)), (*p_10)))) & p_7) || (*g_112)), p_7)) , g_270));
    return p_10;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint64_t  func_12(int32_t  p_13, uint32_t  p_14, const int32_t * p_15)
{ /* block id: 225 */
    return p_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_117 g_233 g_71 g_530 g_112 g_113 g_58 g_4 g_59 g_535 g_536 g_172
 * writes: g_117 g_233 g_158 g_530 g_534 g_536
 */
static int32_t  func_16(uint8_t  p_17, uint16_t  p_18, uint16_t  p_19, uint32_t  p_20, int32_t * p_21)
{ /* block id: 217 */
    int64_t *l_519 = &g_113;
    uint8_t *l_520 = &g_117[0][0];
    uint8_t *l_521[5][8][6] = {{{&g_233,&g_233,&g_233,(void*)0,&g_233,&g_233},{&g_233,&g_233,(void*)0,(void*)0,&g_233,&g_233},{&g_233,&g_233,&g_233,&g_233,&g_233,&g_233},{&g_233,(void*)0,&g_233,&g_233,(void*)0,&g_233},{(void*)0,&g_233,&g_233,&g_233,&g_233,&g_233},{(void*)0,&g_233,&g_233,&g_233,&g_233,&g_233},{&g_233,&g_233,&g_233,(void*)0,&g_233,(void*)0},{&g_233,(void*)0,&g_233,&g_233,&g_233,&g_233}},{{&g_233,&g_233,&g_233,&g_233,&g_233,(void*)0},{&g_233,(void*)0,&g_233,&g_233,&g_233,&g_233},{&g_233,&g_233,&g_233,&g_233,&g_233,&g_233},{(void*)0,&g_233,&g_233,&g_233,&g_233,&g_233},{&g_233,&g_233,&g_233,&g_233,&g_233,&g_233},{&g_233,&g_233,&g_233,(void*)0,&g_233,&g_233},{&g_233,(void*)0,&g_233,&g_233,&g_233,&g_233},{&g_233,&g_233,&g_233,&g_233,&g_233,&g_233}},{{&g_233,&g_233,&g_233,&g_233,&g_233,&g_233},{&g_233,&g_233,&g_233,&g_233,&g_233,&g_233},{(void*)0,&g_233,&g_233,&g_233,&g_233,&g_233},{&g_233,&g_233,&g_233,&g_233,&g_233,(void*)0},{(void*)0,&g_233,(void*)0,&g_233,&g_233,&g_233},{(void*)0,&g_233,&g_233,&g_233,&g_233,&g_233},{&g_233,&g_233,&g_233,&g_233,&g_233,(void*)0},{&g_233,(void*)0,&g_233,&g_233,&g_233,&g_233}},{{&g_233,&g_233,&g_233,&g_233,&g_233,&g_233},{(void*)0,(void*)0,&g_233,&g_233,&g_233,&g_233},{(void*)0,&g_233,(void*)0,&g_233,&g_233,&g_233},{(void*)0,&g_233,&g_233,&g_233,&g_233,&g_233},{&g_233,&g_233,&g_233,&g_233,(void*)0,&g_233},{(void*)0,&g_233,&g_233,&g_233,&g_233,&g_233},{(void*)0,&g_233,(void*)0,&g_233,&g_233,&g_233},{(void*)0,&g_233,(void*)0,&g_233,&g_233,&g_233}},{{&g_233,&g_233,(void*)0,&g_233,&g_233,&g_233},{&g_233,&g_233,&g_233,&g_233,(void*)0,&g_233},{&g_233,&g_233,&g_233,&g_233,(void*)0,(void*)0},{(void*)0,&g_233,&g_233,&g_233,&g_233,&g_233},{(void*)0,&g_233,&g_233,&g_233,(void*)0,(void*)0},{&g_233,&g_233,&g_233,&g_233,&g_233,&g_233},{(void*)0,(void*)0,&g_233,&g_233,&g_233,&g_233},{&g_233,&g_233,&g_233,&g_233,&g_233,&g_233}}};
    uint32_t *l_524 = (void*)0;
    int16_t *l_525 = &g_158;
    int32_t l_526[4][8][1] = {{{0x282B2FB7L},{0xB5ED9690L},{9L},{0x282B2FB7L},{0x0B16AB54L},{0x282B2FB7L},{9L},{0xB5ED9690L}},{{0x282B2FB7L},{9L},{(-3L)},{9L},{9L},{(-3L)},{9L},{0x282B2FB7L}},{{1L},{6L},{0x0B16AB54L},{0x1D11B0D2L},{0x0B16AB54L},{6L},{1L},{0x0B16AB54L}},{{0xB5ED9690L},{0L},{6L},{6L},{0L},{0xB5ED9690L},{0x0B16AB54L},{1L}}};
    uint32_t *l_527[1][9][8] = {{{&g_510,&g_510,&g_510,&g_510,&g_510,&g_510,&g_510,&g_510},{&g_510,(void*)0,(void*)0,&g_510,(void*)0,&g_510,(void*)0,&g_510},{(void*)0,(void*)0,(void*)0,&g_510,&g_510,&g_510,&g_510,(void*)0},{(void*)0,(void*)0,&g_510,&g_510,&g_270,&g_510,&g_510,(void*)0},{(void*)0,(void*)0,&g_510,&g_510,&g_510,&g_510,(void*)0,(void*)0},{(void*)0,&g_510,(void*)0,&g_510,(void*)0,&g_510,(void*)0,(void*)0},{&g_510,&g_510,&g_510,&g_510,&g_510,&g_510,&g_510,&g_510},{&g_510,&g_510,&g_510,&g_510,&g_510,&g_510,&g_510,&g_510},{&g_510,(void*)0,(void*)0,&g_510,(void*)0,&g_510,(void*)0,&g_510}}};
    const uint32_t ****l_533 = &g_530;
    int i, j, k;
    (*g_535) &= (((safe_div_func_uint8_t_u_u(p_19, ((safe_lshift_func_uint8_t_u_u(((*l_520) |= ((void*)0 == l_519)), 4)) ^ (g_534 = (((g_233--) , p_18) && ((l_524 != ((((*l_525) = g_71[1]) <= l_526[0][5][0]) , l_527[0][3][5])) < (safe_lshift_func_uint16_t_u_u((((*l_533) = g_530) == &g_389), l_526[3][4][0])))))))) <= (*g_112)) == (*g_58));
    return g_172;
}


/* ------------------------------------------ */
/* 
 * reads : g_155 g_473 g_233 g_4 g_389 g_390 g_151 g_58 g_510 g_444 g_270 g_117 g_172 g_2 g_59 g_57 g_71 g_513
 * writes: g_155 g_473 g_233 g_71 g_4 g_59 g_305 g_510 g_270 g_2 g_95 g_98 g_5 g_58
 */
static uint8_t  func_23(int8_t  p_24)
{ /* block id: 201 */
    int32_t l_469 = 0x1AA018A7L;
    int32_t l_470 = (-1L);
    int32_t l_471 = 0xFE719F67L;
    int32_t l_472[3][9] = {{(-9L),1L,0L,0L,1L,(-9L),1L,0L,0L},{(-5L),(-5L),(-10L),0xFD63D6A0L,(-10L),(-5L),(-5L),(-10L),0xFD63D6A0L},{0x0F89E9E9L,1L,0x0F89E9E9L,(-9L),(-9L),0x0F89E9E9L,1L,0x0F89E9E9L,(-9L)}};
    int i, j;
    for (g_155 = (-15); (g_155 < 34); g_155 = safe_add_func_int64_t_s_s(g_155, 8))
    { /* block id: 204 */
        int32_t *l_468[4] = {&g_4,&g_4,&g_4,&g_4};
        uint32_t * const *l_486 = &g_444;
        uint8_t *l_491 = (void*)0;
        uint8_t *l_492[10] = {&g_233,&g_233,&g_233,&g_233,&g_233,&g_233,&g_233,&g_233,&g_233,&g_233};
        uint16_t *l_497[8][1] = {{&g_95[3]},{&g_95[3]},{&g_95[3]},{&g_95[3]},{&g_95[3]},{&g_95[3]},{&g_95[3]},{&g_95[3]}};
        int64_t l_498 = 0L;
        uint64_t *l_508[8][3] = {{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_71[2]},{&g_71[1],(void*)0,&g_71[4]},{(void*)0,(void*)0,&g_71[4]},{(void*)0,&g_71[1],&g_71[2]},{(void*)0,(void*)0,(void*)0}};
        int8_t *l_509 = &g_305;
        int32_t **l_511 = (void*)0;
        int32_t **l_512 = (void*)0;
        int i, j;
        ++g_473;
        (*g_513) = func_50((safe_lshift_func_int16_t_s_u((((safe_sub_func_uint64_t_u_u((((*g_444) |= (safe_div_func_int16_t_s_s(0L, (safe_div_func_int64_t_s_s(((g_510 |= ((safe_lshift_func_uint8_t_u_s((l_486 != l_486), 1)) , (p_24 >= ((*l_509) = ((safe_mod_func_uint32_t_u_u(((safe_mul_func_uint8_t_u_u((g_233++), p_24)) || (l_498 &= (safe_rshift_func_uint16_t_u_s(((void*)0 != &g_158), 15)))), ((**g_151) = (l_472[1][1] |= ((safe_rshift_func_uint8_t_u_u((safe_mul_func_int16_t_s_s(((safe_rshift_func_uint8_t_u_s(p_24, (safe_rshift_func_int8_t_s_s((~(g_71[0] = g_4)), 0)))) & (**g_389)), p_24)), 1)) , p_24))))) ^ 0x24CAA2BFL))))) , p_24), 6L))))) , l_472[1][1]), p_24)) != g_117[0][0]) != g_172), p_24)), g_2);
    }
    return p_24;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_56 g_58 g_57 g_59 g_5 g_71 g_112 g_113 g_95 g_117 g_125 g_4 g_149 g_536 g_155
 * writes: g_4 g_2 g_71 g_95 g_98 g_59 g_5 g_117 g_144 g_113 g_149 g_58 g_536 g_155
 */
static int8_t  func_25(uint8_t  p_26, uint8_t  p_27, uint32_t  p_28, int32_t * p_29, const uint32_t  p_30)
{ /* block id: 3 */
    int16_t l_62 = 0x93A3L;
    int32_t *l_101 = (void*)0;
    int32_t l_184 = 0x09638302L;
    int32_t l_185 = 0x9901C464L;
    uint8_t *l_259 = &g_117[0][0];
    uint64_t l_266 = 0x184E1CEA7703A369LL;
    uint32_t *l_313 = &g_172;
    int32_t l_368 = 0x659F9DB1L;
    int32_t l_376[1];
    uint32_t *l_430[10] = {&g_270,(void*)0,(void*)0,&g_270,(void*)0,(void*)0,&g_270,(void*)0,(void*)0,&g_270};
    uint32_t **l_429 = &l_430[6];
    uint16_t l_434[3];
    uint16_t l_448 = 0UL;
    int i;
    for (i = 0; i < 1; i++)
        l_376[i] = 0x1525A970L;
    for (i = 0; i < 3; i++)
        l_434[i] = 65535UL;
    for (p_28 = 0; (p_28 >= 24); ++p_28)
    { /* block id: 6 */
        const uint16_t l_53[4] = {0UL,0UL,0UL,0UL};
        uint32_t l_63[8] = {0UL,0UL,0xEF2D6A39L,0UL,0UL,0xEF2D6A39L,0UL,0UL};
        int32_t **l_150 = &g_58;
        int i;
        (*l_150) = func_45((safe_mul_func_uint8_t_u_u((p_29 != (p_27 , func_50(g_2, (((((l_53[1] < ((*p_29) = ((void*)0 == p_29))) > ((safe_rshift_func_uint16_t_u_u((((g_56[2] == g_58) && (((safe_div_func_int16_t_s_s(0x2FC3L, 0x19C8L)) > 0xA8F9E1C21029358DLL) ^ g_57)) , 0xD0BCL), g_59)) > 0x8AFC007DL)) < l_62) , l_63[2]) < g_5[5][0][1])))), 250UL)), l_101);
        return p_30;
    }
    return p_27;
}


/* ------------------------------------------ */
/* 
 * reads : g_59 g_58 g_112 g_113 g_95 g_71 g_117 g_125 g_57 g_2 g_98 g_4 g_149 g_536 g_155
 * writes: g_59 g_117 g_2 g_71 g_95 g_98 g_4 g_5 g_144 g_113 g_149 g_536 g_155
 */
static int32_t * func_45(uint16_t  p_46, int32_t * p_47)
{ /* block id: 23 */
    int64_t l_102 = 0xA14429F1C2FFF440LL;
    int32_t *l_103 = &g_59;
    int32_t *l_104 = &g_4;
    int32_t *l_105 = &g_59;
    int32_t *l_106 = &g_59;
    int32_t *l_107 = &g_59;
    int32_t *l_108[9][4][3] = {{{(void*)0,&g_4,&g_4},{&g_4,&g_4,&g_4},{(void*)0,&g_59,&g_59},{&g_59,&g_4,&g_4}},{{&g_4,&g_59,&g_59},{&g_4,&g_59,&g_59},{&g_59,&g_59,&g_4},{(void*)0,&g_4,&g_4}},{{&g_59,&g_59,(void*)0},{&g_4,&g_4,&g_4},{(void*)0,&g_59,(void*)0},{(void*)0,(void*)0,&g_4}},{{&g_59,&g_4,&g_4},{&g_4,(void*)0,&g_59},{&g_59,&g_59,&g_59},{&g_4,&g_4,&g_4}},{{&g_59,(void*)0,&g_59},{(void*)0,&g_4,&g_4},{(void*)0,&g_4,&g_59},{&g_4,&g_4,&g_59}},{{&g_59,(void*)0,&g_4},{(void*)0,&g_4,&g_4},{&g_59,&g_59,(void*)0},{&g_4,(void*)0,&g_4}},{{&g_4,&g_4,&g_4},{&g_59,(void*)0,&g_59},{&g_59,&g_59,&g_59},{(void*)0,&g_4,&g_4}},{{&g_59,&g_59,&g_59},{&g_59,&g_4,&g_4},{&g_4,&g_59,&g_59},{&g_4,&g_59,&g_59}},{{&g_59,&g_59,&g_4},{(void*)0,&g_4,&g_4},{&g_59,&g_59,(void*)0},{&g_4,&g_4,&g_4}}};
    uint64_t l_109 = 0xF864726A7E7D7187LL;
    int32_t *l_127 = &g_4;
    uint8_t *l_137 = &g_117[0][0];
    int32_t **l_142 = &l_107;
    int8_t *l_143 = &g_144;
    uint16_t *l_147 = (void*)0;
    uint16_t *l_148 = &g_95[3];
    int i, j, k;
    --l_109;
    (*l_107) = (*l_106);
    if ((*g_58))
    { /* block id: 26 */
        int64_t *l_114 = &l_102;
        int64_t *l_115[8] = {&l_102,&l_102,&l_102,&l_102,&l_102,&l_102,&l_102,&l_102};
        uint8_t *l_116 = &g_117[0][0];
        int32_t l_120 = 0xF8350F04L;
        uint64_t *l_124 = &l_109;
        int32_t **l_128 = &l_103;
        int32_t *l_129 = &g_4;
        int i;
        (*l_107) = ((l_114 = g_112) != (g_113 , l_115[5]));
        l_129 = ((*l_128) = (l_127 = func_50(((g_95[3] & 0xA8C46F03L) , ((g_71[7] , ((*l_116)--)) , (*l_105))), (l_120 & (l_116 != (((*l_124) ^= (+(safe_add_func_uint16_t_u_u((*l_105), (p_46 >= 0x39L))))) , g_125))))));
        for (g_98 = 0; (g_98 == 21); ++g_98)
        { /* block id: 36 */
            (*l_128) = &g_4;
        }
    }
    else
    { /* block id: 39 */
        int64_t l_132 = 0x7EEAFC450F0C8DF0LL;
        (*l_107) |= ((*l_127) ^= (&p_47 != (l_132 , &g_58)));
    }
    g_149 &= (safe_mod_func_int64_t_s_s(((*g_112) = ((safe_add_func_int16_t_s_s((((*g_58) = (l_137 != (((((*l_148) = (((safe_lshift_func_int8_t_s_u(((*l_143) = (p_46 | (safe_mod_func_int32_t_s_s((g_117[0][0] , (l_142 == &g_56[2])), p_46)))), 4)) == (&l_102 == (void*)0)) < ((safe_add_func_uint32_t_u_u(0UL, p_46)) | (*l_104)))) , (-1L)) <= (-7L)) , l_137))) == g_57), g_2)) & (*g_112))), p_46));
    return &g_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_59 g_57 g_71 g_58
 * writes: g_2 g_71 g_95 g_98 g_59 g_4 g_5 g_536 g_155 l_1220
 */
static int32_t * func_50(int64_t  p_51, uint16_t  p_52)
{ /* block id: 8 */
    int64_t l_66 = 6L;
    int32_t *l_67 = &g_59;
    uint64_t *l_70 = &g_71[0];
    int64_t *l_87 = &l_66;
    uint16_t *l_93 = &g_2;
    int64_t l_94[9][9] = {{0xFA13A89CE68EBBCFLL,0x88D378B361F16875LL,(-1L),0x88D378B361F16875LL,0xFA13A89CE68EBBCFLL,0xFA13A89CE68EBBCFLL,0x88D378B361F16875LL,(-1L),0x88D378B361F16875LL},{(-7L),0x4373440B9FCDB2BFLL,0x6624E94FA9F1E568LL,0x6624E94FA9F1E568LL,0x4373440B9FCDB2BFLL,(-7L),0x4373440B9FCDB2BFLL,0x6624E94FA9F1E568LL,0x6624E94FA9F1E568LL},{0xFA13A89CE68EBBCFLL,0xFA13A89CE68EBBCFLL,0x88D378B361F16875LL,(-1L),0x88D378B361F16875LL,0xFA13A89CE68EBBCFLL,0xFA13A89CE68EBBCFLL,0x88D378B361F16875LL,(-1L)},{(-7L),0x4373440B9FCDB2BFLL,(-7L),(-7L),(-7L),(-7L),0x4373440B9FCDB2BFLL,(-7L),(-7L)},{0x6A2B7F3A40B10513LL,0x88D378B361F16875LL,0x88D378B361F16875LL,0x6A2B7F3A40B10513LL,(-1L),0x6A2B7F3A40B10513LL,0x88D378B361F16875LL,0x88D378B361F16875LL,0x6A2B7F3A40B10513LL},{0x2010857B2633072FLL,(-7L),0x6624E94FA9F1E568LL,(-7L),0x2010857B2633072FLL,0x2010857B2633072FLL,(-7L),0x6624E94FA9F1E568LL,(-7L)},{0x88D378B361F16875LL,(-1L),(-1L),(-1L),(-1L),0x88D378B361F16875LL,(-1L),(-1L),(-1L)},{0x2010857B2633072FLL,0x2010857B2633072FLL,(-7L),0x6624E94FA9F1E568LL,(-7L),0x2010857B2633072FLL,0x2010857B2633072FLL,(-7L),0x6624E94FA9F1E568LL},{0x6A2B7F3A40B10513LL,(-1L),0x6A2B7F3A40B10513LL,0x88D378B361F16875LL,0x88D378B361F16875LL,0x6A2B7F3A40B10513LL,(-1L),0x6A2B7F3A40B10513LL,0x88D378B361F16875LL}};
    uint32_t l_96 = 0xA09BBF73L;
    uint16_t *l_97[10][6][2] = {{{(void*)0,(void*)0},{&g_98,(void*)0},{&g_98,&g_98},{&g_98,&g_98},{&g_98,&g_98},{&g_98,(void*)0}},{{&g_98,(void*)0},{(void*)0,&g_98},{(void*)0,&g_98},{&g_98,&g_98},{&g_98,(void*)0},{&g_98,&g_98}},{{&g_98,&g_98},{&g_98,&g_98},{&g_98,(void*)0},{(void*)0,&g_98},{&g_98,&g_98},{&g_98,&g_98}},{{&g_98,&g_98},{&g_98,(void*)0},{&g_98,&g_98},{&g_98,&g_98},{&g_98,&g_98},{(void*)0,&g_98}},{{(void*)0,(void*)0},{&g_98,(void*)0},{&g_98,&g_98},{(void*)0,&g_98},{(void*)0,&g_98},{(void*)0,&g_98}},{{&g_98,&g_98},{(void*)0,&g_98},{(void*)0,&g_98},{(void*)0,&g_98},{&g_98,(void*)0},{&g_98,(void*)0}},{{(void*)0,&g_98},{(void*)0,&g_98},{&g_98,&g_98},{&g_98,&g_98},{&g_98,(void*)0},{&g_98,&g_98}},{{&g_98,&g_98},{&g_98,&g_98},{&g_98,&g_98},{(void*)0,(void*)0},{&g_98,&g_98},{&g_98,&g_98}},{{&g_98,&g_98},{&g_98,(void*)0},{&g_98,&g_98},{&g_98,&g_98},{(void*)0,&g_98},{(void*)0,(void*)0}},{{&g_98,(void*)0},{&g_98,&g_98},{&g_98,&g_98},{&g_98,&g_98},{&g_98,(void*)0},{&g_98,(void*)0}}};
    volatile int32_t *l_100 = &g_57;
    volatile int32_t **l_99 = &l_100;
    int i, j, k;
    for (g_2 = (-7); (g_2 == 41); g_2 = safe_add_func_uint8_t_u_u(g_2, 9))
    { /* block id: 11 */
        l_66 |= ((void*)0 == &g_57);
    }
    (*g_58) = ((g_98 = ((l_67 != (void*)0) , ((((*l_70) = 4UL) && ((safe_sub_func_uint8_t_u_u((safe_mul_func_int16_t_s_s((g_95[3] = (safe_div_func_uint8_t_u_u(((safe_mul_func_uint16_t_u_u(((*l_93) &= (1L || (safe_mod_func_int16_t_s_s((safe_mul_func_uint16_t_u_u((p_51 != (((~((*l_87) |= 0x779CF818A8DC8D62LL)) >= ((safe_div_func_int64_t_s_s((safe_div_func_int32_t_s_s((!((*l_67) < 0xEBL)), p_51)), g_57)) <= 0x400C683D18CDA475LL)) || 0x4BFA3C5BL)), p_51)), (*l_67))))), p_51)) || l_94[2][4]), (*l_67)))), (*l_67))), g_71[4])) == l_96)) > 0UL))) && p_52);
    for (l_66 = 0; l_66 < 7; l_66 += 1)
    {
        for (g_4 = 0; g_4 < 1; g_4 += 1)
        {
            for (p_52 = 0; p_52 < 4; p_52 += 1)
            {
                g_5[l_66][g_4][p_52] = 0x7072EE8FL;
            }
        }
    }
    (*l_99) = &g_57;
    return l_67;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_5[i][j][k], "g_5[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_57, "g_57", print_hash_value);
    transparent_crc(g_59, "g_59", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_71[i], "g_71[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_95[i], "g_95[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_98, "g_98", print_hash_value);
    transparent_crc(g_113, "g_113", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_117[i][j], "g_117[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_126, "g_126", print_hash_value);
    transparent_crc(g_144, "g_144", print_hash_value);
    transparent_crc(g_149, "g_149", print_hash_value);
    transparent_crc(g_155, "g_155", print_hash_value);
    transparent_crc(g_158, "g_158", print_hash_value);
    transparent_crc(g_172, "g_172", print_hash_value);
    transparent_crc(g_233, "g_233", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_235[i][j][k], "g_235[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_270, "g_270", print_hash_value);
    transparent_crc(g_305, "g_305", print_hash_value);
    transparent_crc(g_473, "g_473", print_hash_value);
    transparent_crc(g_510, "g_510", print_hash_value);
    transparent_crc(g_534, "g_534", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_536[i][j][k], "g_536[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_619, "g_619", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_680[i], "g_680[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_754, "g_754", print_hash_value);
    transparent_crc(g_805, "g_805", print_hash_value);
    transparent_crc(g_855, "g_855", print_hash_value);
    transparent_crc(g_1026, "g_1026", print_hash_value);
    transparent_crc(g_1136, "g_1136", print_hash_value);
    transparent_crc(g_1200, "g_1200", print_hash_value);
    transparent_crc(g_1395, "g_1395", print_hash_value);
    transparent_crc(g_1432, "g_1432", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 342
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 35
breakdown:
   depth: 1, occurrence: 62
   depth: 2, occurrence: 18
   depth: 3, occurrence: 2
   depth: 4, occurrence: 2
   depth: 14, occurrence: 1
   depth: 16, occurrence: 1
   depth: 18, occurrence: 1
   depth: 20, occurrence: 1
   depth: 21, occurrence: 1
   depth: 23, occurrence: 3
   depth: 26, occurrence: 1
   depth: 27, occurrence: 1
   depth: 29, occurrence: 1
   depth: 32, occurrence: 1
   depth: 35, occurrence: 1

XXX total number of pointers: 324

XXX times a variable address is taken: 788
XXX times a pointer is dereferenced on RHS: 217
breakdown:
   depth: 1, occurrence: 152
   depth: 2, occurrence: 49
   depth: 3, occurrence: 7
   depth: 4, occurrence: 9
XXX times a pointer is dereferenced on LHS: 230
breakdown:
   depth: 1, occurrence: 199
   depth: 2, occurrence: 25
   depth: 3, occurrence: 5
   depth: 4, occurrence: 1
XXX times a pointer is compared with null: 34
XXX times a pointer is compared with address of another variable: 10
XXX times a pointer is compared with another pointer: 10
XXX times a pointer is qualified to be dereferenced: 4215

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1337
   level: 2, occurrence: 203
   level: 3, occurrence: 71
   level: 4, occurrence: 27
XXX number of pointers point to pointers: 143
XXX number of pointers point to scalars: 181
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 25.3
XXX average alias set size: 1.31

XXX times a non-volatile is read: 1151
XXX times a non-volatile is write: 637
XXX times a volatile is read: 80
XXX    times read thru a pointer: 33
XXX times a volatile is write: 25
XXX    times written thru a pointer: 7
XXX times a volatile is available for access: 1.04e+03
XXX percentage of non-volatile access: 94.5

XXX forward jumps: 0
XXX backward jumps: 5

XXX stmts: 64
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 24
   depth: 1, occurrence: 13
   depth: 2, occurrence: 4
   depth: 3, occurrence: 5
   depth: 4, occurrence: 6
   depth: 5, occurrence: 12

XXX percentage a fresh-made variable is used: 17.9
XXX percentage an existing variable is used: 82.1
********************* end of statistics **********************/

