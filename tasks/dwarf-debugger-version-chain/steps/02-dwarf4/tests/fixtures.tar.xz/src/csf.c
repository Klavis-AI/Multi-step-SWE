/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --seed 100606 --max-funcs 8
 * Seed:      100606
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint64_t  f0;
   volatile unsigned f1 : 10;
   int32_t  f2;
   uint16_t  f3;
   uint8_t  f4;
   int32_t  f5;
};

struct S1 {
   const signed f0 : 20;
   volatile signed f1 : 25;
   volatile signed f2 : 25;
   const unsigned f3 : 3;
   volatile unsigned f4 : 19;
   signed f5 : 21;
   const unsigned f6 : 24;
   signed f7 : 13;
   volatile unsigned f8 : 8;
   const unsigned f9 : 19;
};

struct S2 {
   const uint8_t  f0;
   unsigned f1 : 6;
   int32_t  f2;
   int8_t  f3;
   int8_t  f4;
   uint16_t  f5;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0x1BC7DCD6L;
static volatile int32_t g_5[2][10][1] = {{{0x2B4746A1L},{1L},{0x2B4746A1L},{1L},{0x2B4746A1L},{1L},{0x2B4746A1L},{1L},{0x2B4746A1L},{1L}},{{0x2B4746A1L},{1L},{0x2B4746A1L},{1L},{0x2B4746A1L},{1L},{0x2B4746A1L},{1L},{0x2B4746A1L},{1L}}};
static volatile int32_t g_6 = 0x1B583DC0L;/* VOLATILE GLOBAL g_6 */
static int32_t g_7 = 0x7631615EL;
static int32_t *g_12 = (void*)0;
static int32_t ** volatile g_11 = &g_12;/* VOLATILE GLOBAL g_11 */
static int32_t g_17 = 0L;
static int32_t g_20 = 1L;
static int32_t g_21 = (-8L);
static uint16_t g_22[9] = {7UL,7UL,7UL,7UL,7UL,7UL,7UL,7UL,7UL};
static int64_t g_77[10] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
static uint8_t g_81 = 0x33L;
static uint64_t g_87 = 0x940354EEA3775ED1LL;
static const struct S2 g_93 = {0x48L,0,-1L,-8L,0x6FL,1UL};
static int32_t g_97 = 0x799F9A51L;
static int32_t g_98[1] = {(-8L)};
static int32_t g_99[10][6] = {{0x7F253ABCL,0x9A883271L,0x432499CBL,0x432499CBL,0x9A883271L,0x7F253ABCL},{0x7F253ABCL,1L,0x9A883271L,1L,0x7F253ABCL,0x7F253ABCL},{0x432499CBL,1L,1L,0x432499CBL,5L,0x432499CBL},{0x432499CBL,5L,0x432499CBL,1L,1L,0x432499CBL},{0x7F253ABCL,0x7F253ABCL,1L,0x9A883271L,1L,0x7F253ABCL},{1L,5L,0x9A883271L,0x9A883271L,5L,1L},{0x7F253ABCL,1L,0x9A883271L,1L,0x7F253ABCL,0x7F253ABCL},{0x432499CBL,1L,1L,0x432499CBL,5L,0x432499CBL},{0x432499CBL,5L,0x432499CBL,1L,1L,0x432499CBL},{0x7F253ABCL,0x7F253ABCL,1L,0x9A883271L,1L,0x7F253ABCL}};
static int32_t g_100 = 3L;
static int32_t g_101 = 4L;
static int32_t g_102 = 3L;
static int32_t g_103 = 0xEF25AD8BL;
static int32_t g_104 = 6L;
static int32_t g_105 = 0x52D756AAL;
static int32_t g_106 = 0xD5FB3F51L;
static int32_t g_107 = 1L;
static int32_t g_108 = 0x42294EC2L;
static int32_t g_109 = 0L;
static int32_t g_110[4] = {0xCD7C5103L,0xCD7C5103L,0xCD7C5103L,0xCD7C5103L};
static const volatile int32_t ** volatile *g_124 = (void*)0;
static uint8_t g_128 = 0xD8L;
static uint8_t g_130 = 0xD2L;
static int16_t g_139 = 0x2FD5L;
static int16_t g_142 = (-8L);
static int16_t g_145 = 0x29DAL;
static int8_t g_150 = 0x6DL;
static const int32_t g_168 = (-7L);
static const int32_t *g_171 = &g_20;
static uint32_t g_192 = 0x5695F44CL;
static int64_t *g_208[5][4][10] = {{{&g_77[9],&g_77[9],&g_77[9],&g_77[9],&g_77[5],&g_77[6],&g_77[9],(void*)0,(void*)0,&g_77[9]},{&g_77[5],&g_77[1],&g_77[9],(void*)0,&g_77[9],&g_77[9],&g_77[9],(void*)0,&g_77[9],&g_77[9]},{&g_77[5],&g_77[9],&g_77[7],&g_77[4],&g_77[9],&g_77[1],&g_77[6],(void*)0,(void*)0,&g_77[5]},{&g_77[9],&g_77[7],&g_77[9],&g_77[9],&g_77[8],&g_77[9],&g_77[9],(void*)0,(void*)0,&g_77[7]}},{{&g_77[9],&g_77[9],&g_77[9],&g_77[4],(void*)0,&g_77[9],(void*)0,&g_77[7],&g_77[9],&g_77[7]},{&g_77[7],&g_77[5],&g_77[8],(void*)0,&g_77[8],&g_77[5],&g_77[7],&g_77[9],(void*)0,&g_77[5]},{&g_77[7],&g_77[1],(void*)0,&g_77[9],&g_77[9],&g_77[9],&g_77[1],&g_77[9],&g_77[9],&g_77[9]},{&g_77[9],&g_77[1],&g_77[9],&g_77[9],&g_77[9],&g_77[9],&g_77[7],&g_77[5],&g_77[9],&g_77[9]}},{{&g_77[9],&g_77[5],&g_77[9],&g_77[9],&g_77[5],&g_77[1],(void*)0,&g_77[9],&g_77[4],&g_77[8]},{&g_77[5],&g_77[9],(void*)0,&g_77[9],&g_77[7],&g_77[9],&g_77[9],&g_77[9],&g_77[9],(void*)0},{&g_77[5],&g_77[7],&g_77[8],&g_77[9],&g_77[7],&g_77[6],&g_77[6],&g_77[7],&g_77[9],&g_77[8]},{&g_77[9],&g_77[9],&g_77[9],&g_77[9],&g_77[5],&g_77[6],&g_77[9],(void*)0,(void*)0,&g_77[9]}},{{&g_77[5],&g_77[1],&g_77[9],(void*)0,&g_77[9],&g_77[9],&g_77[9],(void*)0,&g_77[9],&g_77[9]},{&g_77[5],&g_77[9],&g_77[7],&g_77[9],&g_77[4],&g_77[8],&g_77[9],&g_77[3],&g_77[9],&g_77[9]},{(void*)0,&g_77[4],&g_77[4],&g_77[8],&g_77[9],&g_77[9],(void*)0,&g_77[2],&g_77[9],(void*)0},{&g_77[9],&g_77[9],&g_77[9],&g_77[9],(void*)0,&g_77[9],&g_77[5],(void*)0,&g_77[9],(void*)0}},{{&g_77[4],&g_77[7],&g_77[9],&g_77[9],&g_77[9],&g_77[7],&g_77[4],&g_77[5],(void*)0,&g_77[9]},{&g_77[4],&g_77[8],&g_77[3],&g_77[9],&g_77[4],&g_77[9],&g_77[8],&g_77[4],&g_77[7],&g_77[5]},{&g_77[9],&g_77[8],&g_77[4],&g_77[7],&g_77[5],&g_77[9],&g_77[4],&g_77[9],(void*)0,&g_77[4]},{(void*)0,&g_77[7],&g_77[4],(void*)0,&g_77[9],&g_77[8],&g_77[5],&g_77[4],&g_77[9],&g_77[9]}}};
static uint8_t g_223[1][7][10] = {{{0x2AL,0x71L,0x4DL,255UL,249UL,0x62L,0UL,0x39L,0x39L,0UL},{0UL,0x71L,0UL,0UL,0x71L,0UL,0x66L,0UL,255UL,0x62L},{0UL,9UL,8UL,0UL,255UL,0x57L,249UL,0x4DL,249UL,0x57L},{0UL,0x39L,0x2AL,0x39L,0UL,0UL,0x57L,0x6FL,3UL,255UL},{0UL,0x57L,0x6FL,3UL,255UL,0x62L,0x71L,0x71L,0x62L,255UL},{0x2AL,3UL,3UL,0x2AL,0UL,9UL,8UL,0UL,255UL,0x57L},{0x66L,0UL,255UL,0x62L,255UL,8UL,3UL,8UL,255UL,0x62L}}};
static struct S1 g_226 = {-627,-853,2292,0,666,-477,2239,43,6,573};/* VOLATILE GLOBAL g_226 */
static int32_t g_231 = 2L;
static uint32_t g_238[3][9][1] = {{{0x764E4655L},{18446744073709551615UL},{0x764E4655L},{18446744073709551615UL},{0x764E4655L},{18446744073709551615UL},{0x764E4655L},{18446744073709551615UL},{0x764E4655L}},{{18446744073709551615UL},{0x764E4655L},{18446744073709551615UL},{0x764E4655L},{18446744073709551615UL},{0x764E4655L},{18446744073709551615UL},{0x764E4655L},{18446744073709551615UL}},{{0x764E4655L},{18446744073709551615UL},{0x764E4655L},{18446744073709551615UL},{0x764E4655L},{18446744073709551615UL},{0x764E4655L},{18446744073709551615UL},{0x764E4655L}}};
static uint16_t g_285 = 65533UL;
static uint64_t *g_316 = &g_87;
static uint64_t *g_318 = &g_87;
static uint8_t g_347[9][10] = {{1UL,252UL,0x81L,0xE2L,8UL,0x07L,0x07L,8UL,0xE2L,0x81L},{0xE2L,0xE2L,0x46L,0x81L,0x29L,0x60L,8UL,0x62L,249UL,1UL},{0x62L,0x5CL,8UL,0x25L,0xA4L,0x25L,1UL,0xA4L,0xC9L,0x62L},{249UL,0x62L,8UL,0x60L,0x29L,0x81L,0x46L,0xE2L,0xE2L,0x46L},{0xA4L,249UL,0x60L,0x60L,249UL,0xA4L,246UL,0x81L,0xC9L,0x07L},{0x07L,0xE2L,0x62L,0x5CL,8UL,0x25L,0xA4L,0x25L,8UL,0x5CL},{0x07L,0x25L,0x07L,252UL,0x46L,0xA4L,0x5CL,0x29L,0x62L,0x81L},{0xA4L,0x5CL,0x29L,0x62L,0x81L,0x81L,0x62L,0x29L,0x5CL,0xA4L},{249UL,1UL,0x07L,0xE2L,0x62L,0x5CL,8UL,0x25L,0xA4L,0x25L}};
static struct S0 g_366 = {2UL,3,0x6A922429L,0x26A8L,1UL,0xA07FC568L};/* VOLATILE GLOBAL g_366 */
static struct S0 g_369 = {18446744073709551615UL,22,0L,0x458CL,0x16L,0x9E664B73L};/* VOLATILE GLOBAL g_369 */
static struct S0 g_370 = {0x455895EBCA2F6090LL,21,1L,0xEC54L,255UL,0x234A3B4DL};/* VOLATILE GLOBAL g_370 */
static struct S0 g_371 = {18446744073709551615UL,1,0xA944D3AFL,2UL,255UL,0xBE9B0ED2L};/* VOLATILE GLOBAL g_371 */
static struct S0 g_372 = {0x48B3042CCA94956CLL,10,-6L,65535UL,0UL,0xA707527CL};/* VOLATILE GLOBAL g_372 */
static struct S0 g_373 = {0x314AC4CDE09AD145LL,4,0xA1721B7CL,0x0531L,255UL,0L};/* VOLATILE GLOBAL g_373 */
static struct S0 g_374 = {0x6EE5CF3DF36D3542LL,2,0xB2891171L,1UL,0x80L,0x69492F35L};/* VOLATILE GLOBAL g_374 */
static struct S0 g_375 = {0xEA8BA9689BADA433LL,19,-1L,0UL,1UL,6L};/* VOLATILE GLOBAL g_375 */
static struct S0 g_376 = {1UL,17,0xAF3AFFDFL,0x5F3AL,255UL,-6L};/* VOLATILE GLOBAL g_376 */
static struct S0 g_377[5] = {{0x0296D85F6880B504LL,14,0x1E79A155L,65535UL,0UL,7L},{0x0296D85F6880B504LL,14,0x1E79A155L,65535UL,0UL,7L},{0x0296D85F6880B504LL,14,0x1E79A155L,65535UL,0UL,7L},{0x0296D85F6880B504LL,14,0x1E79A155L,65535UL,0UL,7L},{0x0296D85F6880B504LL,14,0x1E79A155L,65535UL,0UL,7L}};
static struct S0 g_378 = {0x0E46948929C286E2LL,7,-3L,1UL,0xB3L,0x91D0F51EL};/* VOLATILE GLOBAL g_378 */
static struct S0 g_379 = {7UL,3,5L,5UL,0xE5L,0x2D71AA8BL};/* VOLATILE GLOBAL g_379 */
static struct S0 g_380 = {1UL,28,-1L,0x3FE8L,0xB8L,1L};/* VOLATILE GLOBAL g_380 */
static struct S0 g_381 = {18446744073709551614UL,16,-8L,65532UL,0UL,-3L};/* VOLATILE GLOBAL g_381 */
static struct S0 g_382 = {9UL,7,0x9507D3F3L,0x4E2AL,250UL,0xFC2743BCL};/* VOLATILE GLOBAL g_382 */
static struct S0 g_383 = {0x6BD1988AC1D18FE6LL,18,-2L,2UL,255UL,-1L};/* VOLATILE GLOBAL g_383 */
static struct S0 g_384 = {0x2D73AC75DE7FB35DLL,22,0x10110AAAL,0x90BDL,0x31L,-7L};/* VOLATILE GLOBAL g_384 */
static struct S0 g_385 = {6UL,9,0L,0x041AL,0x93L,-1L};/* VOLATILE GLOBAL g_385 */
static struct S0 g_386 = {0xCA481A4CEB56BE9BLL,4,1L,0xC449L,0x41L,0L};/* VOLATILE GLOBAL g_386 */
static struct S0 g_387 = {18446744073709551613UL,6,1L,8UL,0x36L,0x3DDD8BBFL};/* VOLATILE GLOBAL g_387 */
static struct S0 g_388 = {0x84CE56A27BF12A16LL,24,-1L,0xB51DL,0UL,0x202C7D74L};/* VOLATILE GLOBAL g_388 */
static struct S0 g_389 = {18446744073709551608UL,23,1L,0x943BL,255UL,0xD99856B3L};/* VOLATILE GLOBAL g_389 */
static struct S1 g_415[7] = {{906,1403,-265,1,524,606,390,-73,8,26},{906,1403,-265,1,524,606,390,-73,8,26},{906,1403,-265,1,524,606,390,-73,8,26},{906,1403,-265,1,524,606,390,-73,8,26},{906,1403,-265,1,524,606,390,-73,8,26},{906,1403,-265,1,524,606,390,-73,8,26},{906,1403,-265,1,524,606,390,-73,8,26}};
static uint16_t *g_426[4] = {&g_372.f3,&g_372.f3,&g_372.f3,&g_372.f3};
static volatile struct S0 g_431 = {1UL,20,0x65712B69L,0x4388L,0xDBL,0x4A2503CBL};/* VOLATILE GLOBAL g_431 */
static volatile struct S0 g_432 = {18446744073709551615UL,12,0xD4DCE4CCL,0xD88AL,246UL,0xF4F46E20L};/* VOLATILE GLOBAL g_432 */
static const volatile struct S0 g_433 = {0xB3F8F828CA77DAD8LL,8,0x88D064CDL,0x84ABL,253UL,6L};/* VOLATILE GLOBAL g_433 */
static volatile struct S0 g_434 = {18446744073709551614UL,25,-9L,65534UL,1UL,0x0D8CCECDL};/* VOLATILE GLOBAL g_434 */
static volatile struct S0 g_435 = {1UL,19,0xE696E447L,1UL,255UL,1L};/* VOLATILE GLOBAL g_435 */
static const volatile struct S0 g_436[3][3] = {{{18446744073709551615UL,31,4L,0UL,1UL,9L},{1UL,11,0x5442C60AL,1UL,250UL,-6L},{18446744073709551615UL,31,4L,0UL,1UL,9L}},{{18446744073709551615UL,31,4L,0UL,1UL,9L},{1UL,11,0x5442C60AL,1UL,250UL,-6L},{18446744073709551615UL,31,4L,0UL,1UL,9L}},{{18446744073709551615UL,31,4L,0UL,1UL,9L},{1UL,11,0x5442C60AL,1UL,250UL,-6L},{18446744073709551615UL,31,4L,0UL,1UL,9L}}};
static volatile struct S0 g_437 = {1UL,21,0L,0x337BL,255UL,0xF5017F1AL};/* VOLATILE GLOBAL g_437 */
static const volatile struct S0 *g_430[8][6] = {{&g_437,&g_431,&g_433,(void*)0,&g_431,(void*)0},{&g_437,(void*)0,&g_437,(void*)0,(void*)0,&g_433},{&g_437,&g_435,(void*)0,(void*)0,&g_435,&g_437},{&g_437,&g_431,&g_433,(void*)0,&g_431,(void*)0},{&g_437,(void*)0,&g_437,(void*)0,(void*)0,&g_433},{&g_437,&g_435,(void*)0,(void*)0,&g_435,&g_437},{&g_437,&g_431,&g_433,(void*)0,&g_431,(void*)0},{&g_437,(void*)0,&g_437,(void*)0,(void*)0,&g_433}};
static uint8_t *g_483 = &g_380.f4;
static struct S0 **g_505 = (void*)0;
static uint32_t g_532 = 0UL;
static uint8_t g_577 = 0UL;
static struct S0 g_586 = {0x2B78C73A3042DBF5LL,19,0x77104AA6L,3UL,255UL,-2L};/* VOLATILE GLOBAL g_586 */
static volatile int8_t g_688 = 3L;/* VOLATILE GLOBAL g_688 */
static volatile int8_t *g_687 = &g_688;
static volatile int8_t **g_686 = &g_687;
static uint8_t * volatile *g_707 = &g_483;
static uint8_t * volatile **g_706 = &g_707;
static struct S0 g_723 = {18446744073709551615UL,22,0x3C53C966L,0x21CCL,252UL,-8L};/* VOLATILE GLOBAL g_723 */
static int64_t * volatile *g_726[3] = {&g_208[1][1][7],&g_208[1][1][7],&g_208[1][1][7]};
static int64_t * volatile **g_725 = &g_726[1];
static int64_t g_754 = 0L;
static uint16_t **g_792 = &g_426[3];
static struct S1 g_794[10] = {{279,2441,1466,1,68,-1004,1636,44,12,639},{279,2441,1466,1,68,-1004,1636,44,12,639},{279,2441,1466,1,68,-1004,1636,44,12,639},{279,2441,1466,1,68,-1004,1636,44,12,639},{279,2441,1466,1,68,-1004,1636,44,12,639},{279,2441,1466,1,68,-1004,1636,44,12,639},{279,2441,1466,1,68,-1004,1636,44,12,639},{279,2441,1466,1,68,-1004,1636,44,12,639},{279,2441,1466,1,68,-1004,1636,44,12,639},{279,2441,1466,1,68,-1004,1636,44,12,639}};
static struct S1 g_795 = {92,3864,2108,0,151,-989,1874,58,3,77};/* VOLATILE GLOBAL g_795 */
static struct S1 g_796 = {-363,2430,5403,1,370,143,2828,-27,2,457};/* VOLATILE GLOBAL g_796 */
static struct S1 g_797[1][4] = {{{-463,5061,-4854,1,227,-87,3586,44,12,695},{-463,5061,-4854,1,227,-87,3586,44,12,695},{-463,5061,-4854,1,227,-87,3586,44,12,695},{-463,5061,-4854,1,227,-87,3586,44,12,695}}};
static struct S1 g_798 = {582,-4239,-5300,0,359,1157,1067,-83,14,278};/* VOLATILE GLOBAL g_798 */
static struct S1 *g_793[6][5] = {{&g_796,&g_795,&g_795,&g_796,&g_798},{&g_796,&g_794[8],(void*)0,(void*)0,&g_794[8]},{&g_798,&g_795,(void*)0,(void*)0,(void*)0},{&g_795,&g_798,&g_795,(void*)0,(void*)0},{&g_794[8],&g_796,(void*)0,&g_796,&g_794[8]},{&g_795,&g_796,&g_798,&g_794[8],&g_798}};
static struct S1 g_800 = {-301,2657,-4269,1,543,-1332,2311,63,8,249};/* VOLATILE GLOBAL g_800 */
static struct S1 g_802 = {493,-2819,-728,1,430,-65,1520,47,11,197};/* VOLATILE GLOBAL g_802 */
static struct S1 *g_801 = &g_802;
static uint64_t g_804 = 18446744073709551615UL;
static struct S2 g_859 = {0xB8L,4,0x5FEE33BBL,0xD1L,0x2DL,9UL};
static int32_t g_862 = 0xD8353AAAL;
static struct S2 *g_868 = &g_859;
static struct S2 **g_867[3] = {&g_868,&g_868,&g_868};
static int8_t *g_887[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static const uint32_t g_938 = 0UL;
static const int64_t *g_953[1][3][6] = {{{&g_754,&g_77[9],&g_77[9],&g_77[9],&g_77[9],&g_754},{&g_77[7],&g_754,&g_754,&g_77[9],&g_754,&g_754},{&g_754,&g_77[7],&g_77[9],&g_77[0],&g_77[0],&g_77[9]}}};
static const int64_t **g_952[9] = {&g_953[0][1][5],&g_953[0][1][5],&g_953[0][1][5],&g_953[0][1][5],&g_953[0][1][5],&g_953[0][1][5],&g_953[0][1][5],&g_953[0][1][5],&g_953[0][1][5]};
static uint16_t g_992 = 65526UL;
static uint16_t ***g_1006[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static struct S2 g_1013 = {0UL,1,-1L,0x80L,-7L,65535UL};
static struct S0 g_1098 = {18446744073709551614UL,11,0x8FB5EF9CL,0UL,0UL,5L};/* VOLATILE GLOBAL g_1098 */
static struct S0 g_1099 = {18446744073709551610UL,5,-1L,0x158AL,0x4CL,0x8C27F1F1L};/* VOLATILE GLOBAL g_1099 */
static struct S0 g_1100 = {0xA0570134CC79A386LL,15,0x4698C500L,0UL,0xE7L,0xBF05EEC1L};/* VOLATILE GLOBAL g_1100 */
static volatile int64_t g_1124 = 0x4035878448948503LL;/* VOLATILE GLOBAL g_1124 */
static volatile int64_t *g_1123 = &g_1124;
static volatile int64_t * const  volatile * volatile g_1122 = &g_1123;/* VOLATILE GLOBAL g_1122 */
static volatile int64_t * const  volatile * volatile *g_1121 = &g_1122;
static volatile int64_t * const  volatile * volatile ** volatile g_1120 = &g_1121;/* VOLATILE GLOBAL g_1120 */
static volatile int64_t * const  volatile * volatile ** volatile * const g_1119 = &g_1120;
static uint8_t * volatile ***g_1185[5] = {&g_706,&g_706,&g_706,&g_706,&g_706};
static int64_t g_1201 = (-1L);
static uint32_t *g_1258[2] = {&g_238[2][3][0],&g_238[2][3][0]};
static struct S1 g_1269 = {970,727,956,1,169,976,1531,69,0,85};/* VOLATILE GLOBAL g_1269 */
static struct S1 g_1270 = {596,1197,-3930,1,129,770,505,6,15,205};/* VOLATILE GLOBAL g_1270 */
static struct S1 g_1271 = {-637,1615,-37,1,323,998,3191,-29,4,278};/* VOLATILE GLOBAL g_1271 */
static int32_t *g_1282[4] = {&g_388.f2,&g_388.f2,&g_388.f2,&g_388.f2};
static uint16_t g_1301[3][2] = {{0x11DDL,0x11DDL},{0x11DDL,0x11DDL},{0x11DDL,0x11DDL}};
static int32_t *g_1356[9] = {&g_387.f2,&g_387.f2,&g_387.f2,&g_387.f2,&g_387.f2,&g_387.f2,&g_387.f2,&g_387.f2,&g_387.f2};
static struct S1 g_1411 = {-891,959,3776,1,337,-770,2582,31,14,334};/* VOLATILE GLOBAL g_1411 */
static const int8_t *g_1436 = &g_93.f3;
static const int8_t **g_1435 = &g_1436;
static const int8_t ***g_1434 = &g_1435;
static int16_t g_1470 = 7L;
static const struct S2 *****g_1472 = (void*)0;
static const uint8_t g_1492[5] = {255UL,255UL,255UL,255UL,255UL};
static uint32_t g_1498 = 0UL;
static int8_t g_1524 = 6L;
static int8_t g_1527[4][6] = {{(-9L),0xD0L,0xE3L,0x5EL,0x5EL,0xE3L},{0x5EL,0x5EL,0xE3L,0xD0L,(-9L),0xE3L},{0xD0L,(-9L),0xE3L,(-9L),0xD0L,0xE3L},{(-9L),0xD0L,0xE3L,0x5EL,0x5EL,0xE3L}};
static struct S1 g_1539[5][1] = {{{-127,-1888,1953,0,111,464,468,53,2,517}},{{-127,-1888,1953,0,111,464,468,53,2,517}},{{-127,-1888,1953,0,111,464,468,53,2,517}},{{-127,-1888,1953,0,111,464,468,53,2,517}},{{-127,-1888,1953,0,111,464,468,53,2,517}}};
static int32_t **g_1546 = &g_12;
static uint8_t g_1639 = 0x59L;
static int16_t g_1695[7][8] = {{(-7L),0L,(-1L),0L,(-7L),0xFA38L,0L,0L},{(-1L),(-2L),0L,0x17D8L,1L,1L,0x17D8L,0L},{0L,0L,0L,0x079BL,1L,0xE450L,0L,(-1L)},{1L,0L,(-1L),0L,(-1L),0L,1L,(-1L)},{0L,0xE450L,1L,0x079BL,0L,0L,0L,0L},{0x17D8L,1L,1L,0x17D8L,0L,(-2L),(-1L),0L},{0L,0xFA38L,(-7L),0L,(-1L),0L,(-7L),0xFA38L}};
static const int32_t **g_1703 = (void*)0;
static struct S2 g_1745 = {0xE8L,5,-1L,-3L,0L,0x02EDL};
static struct S1 **g_1752 = &g_801;
static uint8_t **g_1825 = &g_483;
static uint8_t ***g_1824 = &g_1825;
static struct S1 g_1866 = {-389,1973,-2939,0,35,-14,3899,67,7,691};/* VOLATILE GLOBAL g_1866 */
static int64_t g_1872 = 0L;
static uint64_t **g_2049 = &g_318;
static int32_t g_2058 = 0L;
static volatile uint32_t g_2103 = 4294967286UL;/* VOLATILE GLOBAL g_2103 */
static volatile uint32_t g_2104[6] = {0xC5787D19L,0xC5787D19L,0xC5787D19L,0xC5787D19L,0xC5787D19L,0xC5787D19L};
static volatile uint32_t g_2105 = 0x96B04FE8L;/* VOLATILE GLOBAL g_2105 */
static volatile uint32_t g_2106 = 0x846D6599L;/* VOLATILE GLOBAL g_2106 */
static volatile uint32_t * volatile g_2102[10][1][1] = {{{&g_2105}},{{&g_2106}},{{&g_2105}},{{(void*)0}},{{(void*)0}},{{&g_2105}},{{&g_2106}},{{&g_2105}},{{(void*)0}},{{(void*)0}}};
static volatile uint32_t * volatile * const g_2101 = &g_2102[3][0][0];
static uint32_t *g_2141 = &g_532;
static uint32_t **g_2140 = &g_2141;
static int8_t g_2153 = 0xECL;
static uint8_t g_2185 = 246UL;
static struct S0 g_2198 = {0x1F497E86DEE4095DLL,26,-1L,0x2EAAL,0xA0L,0L};/* VOLATILE GLOBAL g_2198 */
static struct S0 g_2207 = {0x537419BC72481C83LL,7,-4L,0xB360L,7UL,0xFA551982L};/* VOLATILE GLOBAL g_2207 */
static struct S0 ****g_2240 = (void*)0;
static uint32_t ***g_2260[2][6][10] = {{{&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140},{&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140},{&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140},{&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140},{&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140},{&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140}},{{&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140},{&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140},{&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140},{&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140},{&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140},{&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140}}};
static uint32_t g_2396 = 18446744073709551608UL;
static uint32_t * const g_2395 = &g_2396;
static uint32_t * const *g_2394 = &g_2395;
static struct S0 g_2422 = {0xB9E387D5A15B5CB2LL,9,6L,0x0305L,8UL,-7L};/* VOLATILE GLOBAL g_2422 */
static struct S0 g_2423 = {0x8935D499BF4135F3LL,26,0xB05E1E16L,0x4F40L,247UL,-7L};/* VOLATILE GLOBAL g_2423 */
static struct S0 g_2424 = {18446744073709551608UL,0,0x440106B7L,0x2C53L,0x9CL,5L};/* VOLATILE GLOBAL g_2424 */
static struct S0 g_2425 = {0xF18DE1EE176D6B95LL,2,0x142CD7CDL,65526UL,0x73L,1L};/* VOLATILE GLOBAL g_2425 */
static struct S0 g_2426 = {18446744073709551615UL,9,0x76513EDBL,65526UL,7UL,-1L};/* VOLATILE GLOBAL g_2426 */
static struct S0 g_2427 = {1UL,19,0L,65532UL,0x01L,-5L};/* VOLATILE GLOBAL g_2427 */
static struct S0 g_2428 = {0x9BB3AE07F9E03FE5LL,2,0xA10B2A22L,65535UL,0xD6L,2L};/* VOLATILE GLOBAL g_2428 */
static struct S0 g_2429 = {0xD3572653D7A3F9EBLL,23,0x334DCBC1L,0xC50EL,0x04L,0xE5B959E1L};/* VOLATILE GLOBAL g_2429 */
static struct S0 g_2430 = {18446744073709551606UL,11,0xF9324340L,0xDA17L,0x58L,0xC1E8B452L};/* VOLATILE GLOBAL g_2430 */
static struct S0 g_2431 = {4UL,12,0x4F6E9D70L,65535UL,1UL,0xE3BE8019L};/* VOLATILE GLOBAL g_2431 */
static struct S0 g_2432 = {18446744073709551610UL,4,0x99D9CE8BL,65533UL,0x96L,0x18A363AFL};/* VOLATILE GLOBAL g_2432 */
static struct S0 g_2433 = {18446744073709551606UL,24,0x1810BCDCL,3UL,0x6CL,0xC32C8251L};/* VOLATILE GLOBAL g_2433 */
static struct S1 g_2477[9][10] = {{{-568,-1534,-5523,0,507,-109,391,64,0,696},{169,2710,-3512,1,404,1149,3201,-66,5,593},{-600,-4245,-197,0,713,-187,843,-7,13,557},{165,-88,349,0,529,-1303,1317,73,0,329},{364,-1291,-264,1,285,-813,2069,84,14,443},{519,-437,5644,0,98,-277,1566,-50,15,370},{138,-3768,1430,1,712,791,3277,84,15,309},{969,4,2635,0,369,-1163,1712,51,10,433},{204,4156,3682,0,402,51,1366,74,8,242},{413,-2236,-94,0,686,-672,60,9,10,478}},{{311,-3294,4889,0,274,-1296,3364,-60,1,699},{-993,3285,5194,1,241,1166,2396,43,9,157},{-586,2823,2570,1,605,1196,2566,-49,15,99},{-840,-3493,1947,0,638,805,1404,6,1,660},{519,-437,5644,0,98,-277,1566,-50,15,370},{165,-88,349,0,529,-1303,1317,73,0,329},{750,-5201,-1176,1,499,-1104,3117,-75,15,157},{165,-88,349,0,529,-1303,1317,73,0,329},{519,-437,5644,0,98,-277,1566,-50,15,370},{-840,-3493,1947,0,638,805,1404,6,1,660}},{{262,866,2722,1,375,-935,58,-67,1,613},{-348,-404,5693,1,372,-1237,1218,70,14,461},{262,866,2722,1,375,-935,58,-67,1,613},{138,-3768,1430,1,712,791,3277,84,15,309},{-217,1687,3157,1,116,377,2955,32,0,625},{311,-3294,4889,0,274,-1296,3364,-60,1,699},{-445,758,-1698,1,1,-573,1590,53,12,288},{-993,3285,5194,1,241,1166,2396,43,9,157},{-312,3480,-2061,0,22,1377,720,-10,5,499},{-1021,5686,-3338,0,524,1324,3201,-86,11,240}},{{-877,-1938,-720,1,630,-40,535,59,9,6},{-1021,5686,-3338,0,524,1324,3201,-86,11,240},{-346,3927,-2881,1,413,-823,3247,17,5,594},{969,4,2635,0,369,-1163,1712,51,10,433},{-19,1893,1727,0,711,-759,2813,-61,12,108},{-586,2823,2570,1,605,1196,2566,-49,15,99},{519,-437,5644,0,98,-277,1566,-50,15,370},{-993,3285,5194,1,241,1166,2396,43,9,157},{364,-1291,-264,1,285,-813,2069,84,14,443},{-10,-3955,5672,1,415,1254,1246,-85,15,233}},{{-457,-1020,4029,0,519,1094,2658,47,9,491},{750,-5201,-1176,1,499,-1104,3117,-75,15,157},{262,866,2722,1,375,-935,58,-67,1,613},{-877,-1938,-720,1,630,-40,535,59,9,6},{-312,3480,-2061,0,22,1377,720,-10,5,499},{413,-2236,-94,0,686,-672,60,9,10,478},{165,-88,349,0,529,-1303,1317,73,0,329},{165,-88,349,0,529,-1303,1317,73,0,329},{413,-2236,-94,0,686,-672,60,9,10,478},{-312,3480,-2061,0,22,1377,720,-10,5,499}},{{-600,-4245,-197,0,713,-187,843,-7,13,557},{-586,2823,2570,1,605,1196,2566,-49,15,99},{-586,2823,2570,1,605,1196,2566,-49,15,99},{-600,-4245,-197,0,713,-187,843,-7,13,557},{-1021,5686,-3338,0,524,1324,3201,-86,11,240},{-973,-4187,-4565,1,183,485,3805,-32,5,202},{311,-3294,4889,0,274,-1296,3364,-60,1,699},{969,4,2635,0,369,-1163,1712,51,10,433},{-568,-1534,-5523,0,507,-109,391,64,0,696},{397,2000,-4080,1,93,-158,3191,-83,10,373}},{{750,-5201,-1176,1,499,-1104,3117,-75,15,157},{204,4156,3682,0,402,51,1366,74,8,242},{-600,-4245,-197,0,713,-187,843,-7,13,557},{-19,1893,1727,0,711,-759,2813,-61,12,108},{-877,-1938,-720,1,630,-40,535,59,9,6},{-217,1687,3157,1,116,377,2955,32,0,625},{-586,2823,2570,1,605,1196,2566,-49,15,99},{311,-3294,4889,0,274,-1296,3364,-60,1,699},{-568,-1534,-5523,0,507,-109,391,64,0,696},{-348,-404,5693,1,372,-1237,1218,70,14,461}},{{-348,-404,5693,1,372,-1237,1218,70,14,461},{-312,3480,-2061,0,22,1377,720,-10,5,499},{-568,-1534,-5523,0,507,-109,391,64,0,696},{-600,-4245,-197,0,713,-187,843,-7,13,557},{-10,-3955,5672,1,415,1254,1246,-85,15,233},{169,2710,-3512,1,404,1149,3201,-66,5,593},{413,-2236,-94,0,686,-672,60,9,10,478},{-346,3927,-2881,1,413,-823,3247,17,5,594},{413,-2236,-94,0,686,-672,60,9,10,478},{169,2710,-3512,1,404,1149,3201,-66,5,593}},{{-586,2823,2570,1,605,1196,2566,-49,15,99},{-877,-1938,-720,1,630,-40,535,59,9,6},{-457,-1020,4029,0,519,1094,2658,47,9,491},{-877,-1938,-720,1,630,-40,535,59,9,6},{-586,2823,2570,1,605,1196,2566,-49,15,99},{262,866,2722,1,375,-935,58,-67,1,613},{-973,-4187,-4565,1,183,485,3805,-32,5,202},{169,2710,-3512,1,404,1149,3201,-66,5,593},{364,-1291,-264,1,285,-813,2069,84,14,443},{-19,1893,1727,0,711,-759,2813,-61,12,108}}};
static struct S1 g_2479 = {371,-5033,-110,0,23,-378,2972,31,4,81};/* VOLATILE GLOBAL g_2479 */
static struct S2 g_2482 = {0x6EL,0,0xA623D3B3L,0x58L,0x7BL,0x7B12L};
static const struct S1 g_2488 = {-944,5434,1169,0,208,-1308,3779,67,15,255};/* VOLATILE GLOBAL g_2488 */
static const struct S1 g_2491 = {-590,-1142,-2302,0,505,140,1002,5,7,104};/* VOLATILE GLOBAL g_2491 */
static int16_t *g_2519 = &g_1470;
static int16_t * volatile *g_2518 = &g_2519;
static struct S0 g_2566 = {1UL,25,-10L,0x98EDL,0x94L,0L};/* VOLATILE GLOBAL g_2566 */
static const struct S1 g_2610 = {993,4866,-3160,0,290,774,2746,14,9,703};/* VOLATILE GLOBAL g_2610 */
static const struct S1 g_2611 = {-147,-5373,-5511,1,559,-101,1332,-70,2,226};/* VOLATILE GLOBAL g_2611 */
static volatile uint8_t **g_2678 = (void*)0;
static const uint32_t *g_2691 = &g_938;
static const uint32_t **g_2690 = &g_2691;
static const uint32_t ***g_2689 = &g_2690;
static struct S0 g_2716 = {0x8F41DE1C84E2AC11LL,15,0xE49716CAL,0x156BL,0x8AL,0x44309569L};/* VOLATILE GLOBAL g_2716 */
static struct S0 g_2750 = {0x6B5C05B47C0EB817LL,1,0xB833DC4EL,0x017CL,0UL,0x513C03DDL};/* VOLATILE GLOBAL g_2750 */
static struct S0 g_2751[1][2] = {{{0xEFA6D679383CD0A6LL,29,0xDBD87A4CL,65530UL,0x76L,0x3671A1D4L},{0xEFA6D679383CD0A6LL,29,0xDBD87A4CL,65530UL,0x76L,0x3671A1D4L}}};
static int16_t **g_2767 = &g_2519;
static int16_t ***g_2766 = &g_2767;
static volatile struct S2 * volatile * volatile **g_2819 = (void*)0;
static uint64_t *** volatile g_2834 = (void*)0;/* VOLATILE GLOBAL g_2834 */
static uint64_t *** volatile *g_2833 = &g_2834;
static struct S2 ***g_2849 = &g_867[2];
static struct S2 ****g_2848[7] = {&g_2849,&g_2849,&g_2849,&g_2849,&g_2849,&g_2849,&g_2849};
static volatile struct S0 g_2854[6][1] = {{{3UL,12,0x3E4CB927L,0x1A79L,0xE9L,-1L}},{{18446744073709551615UL,19,-1L,0UL,247UL,-9L}},{{3UL,12,0x3E4CB927L,0x1A79L,0xE9L,-1L}},{{18446744073709551615UL,19,-1L,0UL,247UL,-9L}},{{3UL,12,0x3E4CB927L,0x1A79L,0xE9L,-1L}},{{18446744073709551615UL,19,-1L,0UL,247UL,-9L}}};
static volatile struct S0 g_2855 = {18446744073709551608UL,16,0x3BDE1D98L,8UL,8UL,7L};/* VOLATILE GLOBAL g_2855 */
static uint64_t g_2875 = 0x9CC025FD0439A7F3LL;
static volatile struct S0 g_2879 = {0xBEEF9F349AEC53F1LL,23,1L,1UL,7UL,0x168DAC04L};/* VOLATILE GLOBAL g_2879 */
static volatile struct S0 g_2887 = {0x699497757D3C8849LL,12,0x56C26A0DL,0xAA81L,255UL,0x979FEA83L};/* VOLATILE GLOBAL g_2887 */
static struct S0 g_2925 = {1UL,8,7L,0UL,0x6DL,0xFC0C5F74L};/* VOLATILE GLOBAL g_2925 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int8_t  func_14(int32_t ** p_15);
static struct S2  func_25(int16_t  p_26, int32_t * p_27, uint32_t  p_28, const int32_t * p_29);
static const int64_t  func_34(int32_t * p_35, int32_t  p_36, int32_t * p_37, int32_t * p_38, const int32_t ** p_39);
static int32_t * func_40(int32_t ** const  p_41);
static int32_t ** const  func_42(uint64_t  p_43);
static int8_t  func_49(int8_t  p_50, int32_t  p_51, uint16_t  p_52, uint64_t  p_53);
static int8_t  func_56(int8_t  p_57, int32_t * p_58, int32_t  p_59, int32_t ** p_60, const int32_t * p_61);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_11 g_2925 g_2767 g_2519 g_1470 g_2518 g_318 g_87 g_1436 g_93.f3 g_382
 * writes: g_2 g_7 g_12 g_382 g_1470 g_1695
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t *l_10 = &g_2;
    int32_t l_2822 = 8L;
    int16_t * const **l_2843 = (void*)0;
    int16_t * const ***l_2842 = &l_2843;
    int32_t l_2901 = 0xD9E0B162L;
    int32_t l_2903 = 1L;
    int32_t l_2904 = 0L;
    int32_t l_2905 = 0x7956064FL;
    int32_t l_2906 = 0x824D6244L;
    int32_t l_2907 = 1L;
    int32_t l_2911 = (-9L);
    int32_t l_2920 = 0x2AABD0E3L;
    uint64_t l_2942[6];
    int i;
    for (i = 0; i < 6; i++)
        l_2942[i] = 18446744073709551615UL;
    for (g_2 = (-20); (g_2 >= 2); g_2++)
    { /* block id: 3 */
        uint8_t ****l_2817 = &g_1824;
        int32_t l_2818 = 0xE64056A1L;
        uint32_t l_2837 = 2UL;
        int64_t l_2878 = 0xBDA3BBF69285C116LL;
        int32_t l_2912 = 0L;
        int32_t l_2914 = 7L;
        int32_t l_2916 = (-7L);
        int32_t l_2918 = 8L;
        int32_t l_2921 = (-1L);
        struct S0 *l_2926 = &g_382;
        int16_t *l_2943 = &g_1695[1][7];
        int32_t *l_2944[3][3][5] = {{{&g_99[6][5],&l_2916,&l_2904,&l_2912,&l_2904},{&l_2912,&l_2912,&g_386.f2,(void*)0,&g_2431.f2},{&g_723.f2,&g_20,&g_386.f2,(void*)0,&g_99[6][5]}},{{&g_382.f2,&g_386.f2,&l_2904,&g_386.f2,&g_382.f2},{(void*)0,&g_20,&g_2431.f2,&g_382.f2,&l_2912},{(void*)0,&l_2912,&g_99[6][5],&g_369.f2,&g_369.f2}},{{&g_382.f2,&l_2916,&g_382.f2,&g_20,&l_2912},{&g_723.f2,&g_369.f2,&l_2912,&g_20,&g_382.f2},{&l_2912,&g_99[6][5],&g_369.f2,&g_369.f2,&g_99[6][5]}}};
        int i, j, k;
        for (g_7 = 20; (g_7 < (-28)); --g_7)
        { /* block id: 6 */
            int32_t *** const * const l_2820 = (void*)0;
            struct S0 ***l_2866[1];
            struct S0 ****l_2865 = &l_2866[0];
            int32_t **l_2895 = &g_1356[5];
            int32_t l_2908 = 0xF97FD7D5L;
            int32_t l_2909 = 0xD8ED10B7L;
            int32_t l_2910 = 0x1F44913BL;
            int32_t l_2913 = (-1L);
            int32_t l_2915 = (-9L);
            int16_t l_2917 = 0x479EL;
            int32_t l_2919[7];
            int i;
            for (i = 0; i < 1; i++)
                l_2866[i] = &g_505;
            for (i = 0; i < 7; i++)
                l_2919[i] = (-1L);
            (*g_11) = l_10;
        }
        (*l_2926) = g_2925;
        l_2920 &= (l_2818 = (0xF1DE6454L || ((safe_lshift_func_int16_t_s_s(((**g_2518) = (**g_2767)), (((*l_2943) = ((*l_10) | (l_2914 != ((((safe_unary_minus_func_uint8_t_u(((*g_318) > (safe_sub_func_int8_t_s_s((safe_mul_func_int8_t_s_s((safe_lshift_func_int8_t_s_s(((*g_1436) <= ((safe_mod_func_int32_t_s_s((safe_lshift_func_int8_t_s_s(((((&g_316 == &g_316) , (*l_2926)) , 0xAAL) , l_2878), (*g_1436))), l_2942[2])) == 0L)), (*l_10))), (*l_10))), 0UL))))) <= 0UL) , (void*)0) != &g_2819)))) , (*l_10)))) == l_2921)));
    }
    return (*l_10);
}


/* ------------------------------------------ */
/* 
 * reads : g_22 g_1435 g_1436 g_93.f3
 * writes: g_22
 */
static int8_t  func_14(int32_t ** p_15)
{ /* block id: 8 */
    int32_t *l_16 = &g_17;
    int32_t *l_18 = &g_17;
    int32_t *l_19[8] = {(void*)0,&g_17,(void*)0,(void*)0,&g_17,(void*)0,(void*)0,&g_17};
    const struct S2 l_1702 = {0x6AL,5,0xF1DD636AL,0xD7L,0xB0L,0UL};
    int32_t *l_2697 = &g_2429.f2;
    uint32_t **l_2700 = &g_2141;
    struct S0 * const **l_2710[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    struct S0 * const ***l_2709 = &l_2710[2];
    struct S0 * const ****l_2708[4][4][2] = {{{&l_2709,&l_2709},{&l_2709,&l_2709},{&l_2709,&l_2709},{&l_2709,&l_2709}},{{&l_2709,&l_2709},{&l_2709,&l_2709},{&l_2709,&l_2709},{&l_2709,&l_2709}},{{&l_2709,&l_2709},{&l_2709,&l_2709},{&l_2709,&l_2709},{&l_2709,&l_2709}},{{&l_2709,&l_2709},{&l_2709,&l_2709},{&l_2709,&l_2709},{&l_2709,&l_2709}}};
    uint32_t l_2719[2];
    uint8_t l_2720 = 0x3FL;
    const int64_t l_2794 = 0x65EEDB7E927C4F62LL;
    uint32_t l_2795 = 0x6E3F7EBCL;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_2719[i] = 0UL;
    --g_22[1];
    return (**g_1435);
}


/* ------------------------------------------ */
/* 
 * reads : g_2518 g_2 g_792 g_426 g_285 g_372.f3 g_2519 g_1470 g_1825 g_483 g_223 g_380.f4 g_382.f5 g_12 g_98 g_2422.f5 g_2141 g_1695 g_1099.f2 g_2678 g_2689 g_145 g_2207.f2
 * writes: g_2518 g_145 g_1470 g_12 g_98 g_532 g_385.f5 g_223 g_380.f4 g_381.f2 g_1099.f2 g_388.f2 g_2689 g_377.f0 g_110
 */
static struct S2  func_25(int16_t  p_26, int32_t * p_27, uint32_t  p_28, const int32_t * p_29)
{ /* block id: 1170 */
    uint8_t l_2531 = 0x90L;
    uint8_t l_2539 = 1UL;
    struct S2 l_2540[2][1][5] = {{{{1UL,1,-3L,-1L,-7L,7UL},{1UL,1,-3L,-1L,-7L,7UL},{1UL,1,-3L,-1L,-7L,7UL},{1UL,1,-3L,-1L,-7L,7UL},{1UL,1,-3L,-1L,-7L,7UL}}},{{{0x29L,3,-1L,0x14L,1L,0x7B0FL},{0xB8L,4,4L,0xE5L,-4L,0x3C9DL},{0x29L,3,-1L,0x14L,1L,0x7B0FL},{0xB8L,4,4L,0xE5L,-4L,0x3C9DL},{0x29L,3,-1L,0x14L,1L,0x7B0FL}}}};
    int32_t l_2545 = 0x0C993070L;
    uint32_t l_2561 = 4294967295UL;
    uint32_t l_2624 = 1UL;
    int32_t *l_2665 = (void*)0;
    uint64_t l_2671 = 0x779985CC2D098130LL;
    int32_t l_2675 = 0x6FD3EF85L;
    uint8_t **l_2679 = &g_483;
    uint64_t *l_2692 = (void*)0;
    uint64_t *l_2693 = &g_377[3].f0;
    uint8_t l_2695 = 251UL;
    int32_t *l_2696 = &g_110[0];
    int i, j, k;
lbl_2607:
    g_2518 = g_2518;
    for (g_145 = 0; (g_145 < 9); g_145++)
    { /* block id: 1174 */
        int64_t *l_2532[2];
        int32_t l_2533 = 6L;
        struct S1 **l_2538 = &g_793[3][0];
        int32_t l_2559[10] = {(-1L),(-1L),0xA36C9952L,6L,0xA36C9952L,(-1L),(-1L),0xA36C9952L,6L,0xA36C9952L};
        int64_t l_2560 = (-1L);
        struct S0 * const l_2565 = &g_2566;
        struct S0 * const *l_2564 = &l_2565;
        struct S0 * const **l_2563[10];
        struct S0 * const ***l_2562 = &l_2563[8];
        struct S0 *l_2585 = (void*)0;
        uint64_t l_2603 = 0UL;
        int i;
        for (i = 0; i < 2; i++)
            l_2532[i] = &g_754;
        for (i = 0; i < 10; i++)
            l_2563[i] = &l_2564;
        if ((~(safe_div_func_int16_t_s_s(0x6E40L, (safe_sub_func_int16_t_s_s(((0x81L < (0x2D8E4A41DF838516LL <= ((*p_27) | ((safe_div_func_uint32_t_u_u((safe_lshift_func_uint16_t_u_s((((l_2533 = l_2531) == p_28) && p_26), ((*g_2519) = (safe_sub_func_int64_t_s_s((safe_lshift_func_uint16_t_u_u(((-1L) == (((void*)0 == l_2538) > 18446744073709551609UL)), (**g_792))), l_2539))))), l_2539)) < p_26)))) <= l_2531), l_2539))))))
        { /* block id: 1177 */
            return l_2540[0][0][1];
        }
        else
        { /* block id: 1179 */
            uint64_t l_2546 = 0xBD0E4E4032D324CELL;
            int32_t l_2604 = (-1L);
            const struct S1 *l_2609[8] = {&g_2610,&g_2610,&g_2610,&g_2610,&g_2610,&g_2610,&g_2610,&g_2610};
            const uint16_t * const l_2614 = &l_2540[0][0][1].f5;
            int i;
            if ((safe_lshift_func_uint8_t_u_u(((safe_sub_func_int32_t_s_s(((l_2545 &= l_2533) || l_2546), ((p_28 > ((0xB14A0B1BL & ((safe_lshift_func_uint8_t_u_u((l_2560 ^= (((*g_2519) == (safe_add_func_int64_t_s_s((l_2559[1] = (safe_rshift_func_int8_t_s_u(((p_28 & (safe_sub_func_int64_t_s_s(p_26, ((0x6DEA2D11L ^ (((safe_rshift_func_uint16_t_u_u(((safe_lshift_func_int8_t_s_s((l_2540[0][0][1].f4 == 0x9DC2L), 5)) || (**g_2518)), p_26)) , p_28) || (**g_1825))) > p_28)))) <= 0x4351L), 2))), 1UL))) ^ 0x3D1DC410662D8ED4LL)), 0)) <= l_2561)) < p_28)) == 251UL))) , l_2546), l_2533)))
            { /* block id: 1183 */
                int16_t l_2578 = 0L;
                uint64_t l_2602[8] = {0xC85D777556B75C52LL,0xC85D777556B75C52LL,0xC85D777556B75C52LL,0xC85D777556B75C52LL,0xC85D777556B75C52LL,0xC85D777556B75C52LL,0xC85D777556B75C52LL,0xC85D777556B75C52LL};
                int i;
                if (((l_2562 != (void*)0) != ((safe_mod_func_uint64_t_u_u(((void*)0 != &p_27), 2L)) || (safe_unary_minus_func_uint64_t_u(((safe_mul_func_int8_t_s_s((safe_div_func_int16_t_s_s(((1L != (((safe_div_func_int32_t_s_s((safe_add_func_int16_t_s_s((*g_2519), (((g_382.f5 , l_2578) >= l_2578) >= 4L))), 4294967294UL)) < (*g_2519)) , 3L)) , p_26), (**g_2518))), l_2559[9])) > 0xEDL))))))
                { /* block id: 1184 */
                    int32_t *l_2590 = &g_98[0];
                    int32_t l_2600[6][8] = {{5L,0x61830DF2L,1L,0x61830DF2L,5L,0x324E9AE9L,0x324E9AE9L,5L},{0x61830DF2L,0x1615BC1CL,0x1615BC1CL,0x61830DF2L,(-9L),5L,(-9L),0x61830DF2L},{0x1615BC1CL,(-9L),0x1615BC1CL,0x324E9AE9L,1L,1L,0x324E9AE9L,0x1615BC1CL},{(-9L),(-9L),1L,5L,1L,5L,1L,(-9L)},{(-9L),0x1615BC1CL,0x324E9AE9L,1L,1L,0x324E9AE9L,0x1615BC1CL,(-9L)},{0x1615BC1CL,0x61830DF2L,(-9L),5L,(-9L),0x61830DF2L,0x1615BC1CL,0x1615BC1CL}};
                    int8_t *l_2601[8][7] = {{&g_1527[1][1],&l_2540[0][0][1].f4,&g_1745.f4,&g_1745.f4,(void*)0,&g_1013.f3,&g_1524},{&g_1013.f4,&l_2540[0][0][1].f3,(void*)0,(void*)0,&l_2540[0][0][1].f3,&g_1013.f4,&g_150},{&g_1013.f3,(void*)0,&g_1745.f4,&g_1745.f4,(void*)0,&g_1013.f3,&g_1524},{&g_1013.f4,&l_2540[0][0][1].f3,(void*)0,(void*)0,&l_2540[0][0][1].f3,&g_1013.f4,&g_150},{&g_1013.f3,(void*)0,&g_1745.f4,&g_1745.f4,(void*)0,&g_1013.f3,&g_1524},{&g_1013.f4,&l_2540[0][0][1].f3,(void*)0,(void*)0,&l_2540[0][0][1].f3,&g_1013.f4,&g_150},{&g_1013.f3,(void*)0,&g_1745.f4,&g_1745.f4,(void*)0,&g_1013.f3,&g_1524},{&g_1013.f4,&l_2540[0][0][1].f3,(void*)0,(void*)0,&l_2540[0][0][1].f3,&g_1013.f4,&g_150}};
                    int i, j;
                    g_12 = &l_2545;
                    (*g_12) ^= ((+5L) , 0x54F513D5L);
                    if ((safe_div_func_int64_t_s_s((safe_rshift_func_uint16_t_u_u((~((l_2585 = l_2585) != (void*)0)), (((((*g_2141) = (+((safe_unary_minus_func_int64_t_s((safe_mod_func_int64_t_s_s(((((*g_12) >= ((-1L) <= ((*l_2590) |= 0L))) && ((*g_2519) <= (0x3FFCL >= (((safe_mod_func_uint32_t_u_u(((g_2422.f5 , ((((safe_unary_minus_func_int8_t_s(((*l_2590) = (((safe_mul_func_int16_t_s_s((safe_lshift_func_int16_t_s_s(((((safe_rshift_func_uint16_t_u_u((p_28 <= 0x70L), p_26)) , l_2560) != l_2600[5][5]) >= 0x906271DFL), (**g_2518))), (*l_2590))) >= p_28) <= p_28)))) || p_26) >= 1L) == l_2602[1])) , 0UL), 0x15100DA6L)) , l_2603) | p_28)))) || (-8L)), p_28)))) && l_2604))) == 0x38E65F4AL) | (*p_27)) & p_28))), l_2602[4])))
                    { /* block id: 1191 */
                        const uint8_t l_2605 = 0UL;
                        p_29 = &l_2545;
                        if (l_2605)
                            break;
                        l_2590 = (void*)0;
                    }
                    else
                    { /* block id: 1195 */
                        struct S2 l_2606 = {0UL,2,0x44F4BF18L,0x0EL,0x2AL,2UL};
                        return l_2606;
                    }
                    if (p_26)
                        goto lbl_2607;
                }
                else
                { /* block id: 1199 */
                    int32_t *l_2608[5][1] = {{&g_7},{&g_109},{&g_7},{&g_109},{&g_7}};
                    int i, j;
                    l_2608[3][0] = l_2608[2][0];
                }
            }
            else
            { /* block id: 1202 */
                l_2609[1] = l_2609[4];
            }
            for (l_2603 = 0; (l_2603 <= 6); l_2603 += 1)
            { /* block id: 1207 */
                int16_t *l_2623[2];
                int32_t l_2648[10][4][5] = {{{(-4L),0x7D2086DEL,(-6L),(-6L),0x7D2086DEL},{0xDE0B344BL,0xBA2AB47AL,6L,1L,2L},{1L,0L,0x9D030717L,0x2078EF1CL,0x6E0F4D78L},{0x035692F8L,0x030F87A3L,0x0BDBF4C3L,(-2L),0x34C24D75L}},{{1L,9L,(-2L),(-4L),5L},{0xDE0B344BL,0xBD3AAB34L,0xBD3AAB34L,0xDE0B344BL,6L},{(-4L),(-2L),9L,1L,0x235ECB5FL},{(-2L),0x0BDBF4C3L,0x030F87A3L,0x035692F8L,0L}},{{0x2078EF1CL,0x9D030717L,0L,1L,0xB048DF69L},{1L,6L,0xBA2AB47AL,0xDE0B344BL,0xBA2AB47AL},{(-6L),(-6L),0x7D2086DEL,(-4L),0x9D030717L},{0x78FBFE21L,0x035692F8L,6L,(-2L),0xDE0B344BL}},{{(-2L),0xCB3B7873L,9L,0x2078EF1CL,0x15688DADL},{6L,0x035692F8L,(-10L),1L,0x030F87A3L},{0x9DB3EB97L,(-6L),0x2078EF1CL,(-6L),0x9DB3EB97L},{0x6F659CBDL,6L,0x99CE6E69L,0x78FBFE21L,0x6834A6A2L}},{{5L,0x9D030717L,1L,(-2L),0x2078EF1CL},{0x99CE6E69L,0x0BDBF4C3L,(-1L),6L,0x6834A6A2L},{0x15688DADL,(-2L),5L,0x9DB3EB97L,0x9DB3EB97L},{0x6834A6A2L,0xBD3AAB34L,0x6834A6A2L,0x6F659CBDL,0x030F87A3L}},{{0xFCC2F01AL,9L,(-1L),5L,0x15688DADL},{0xBD3AAB34L,0x030F87A3L,2L,0x99CE6E69L,0xDE0B344BL},{0xC6A03658L,0L,(-1L),0x15688DADL,0x9D030717L},{4L,0xBA2AB47AL,0x6834A6A2L,0x6834A6A2L,0xBA2AB47AL}},{{0x2D03FFE3L,0x7D2086DEL,5L,0xFCC2F01AL,0xB048DF69L},{0x0BDBF4C3L,6L,(-1L),0xBD3AAB34L,0L},{(-1L),9L,0x15688DADL,0x235ECB5FL,0x2D03FFE3L},{0x78FBFE21L,0x030F87A3L,0x6F659CBDL,0x6834A6A2L,0xBD3AAB34L}},{{0x2C8031CBL,0x2B7E47FCL,0x2B7E47FCL,0x2C8031CBL,0x2078EF1CL},{0x6834A6A2L,0x6F659CBDL,0x030F87A3L,0x78FBFE21L,0xDE0B344BL},{0x235ECB5FL,0x15688DADL,0x7D2086DEL,9L,5L},{(-1L),4L,0x0BDBF4C3L,0x78FBFE21L,0L}},{{0L,0x2078EF1CL,0xCB3B7873L,0x2C8031CBL,0xCB3B7873L},{2L,2L,2L,0x6834A6A2L,4L},{(-2L),9L,1L,0x235ECB5FL,0x2C8031CBL},{0x6F659CBDL,(-2L),0xBA2AB47AL,(-1L),0x99CE6E69L}},{{0x2078EF1CL,9L,9L,0L,0x7D2086DEL},{0x035692F8L,2L,(-1L),2L,0x035692F8L},{(-1L),0x2078EF1CL,0x9DB3EB97L,(-2L),0xB048DF69L},{0xBD3AAB34L,4L,0x78FBFE21L,0x6F659CBDL,(-1L)}}};
                int i, j, k;
                for (i = 0; i < 2; i++)
                    l_2623[i] = &g_142;
                if ((safe_rshift_func_int8_t_s_s((((((void*)0 != l_2614) < ((~g_1695[l_2603][(l_2603 + 1)]) >= (safe_sub_func_int64_t_s_s(((safe_div_func_int16_t_s_s((l_2624 = ((*g_2519) , (((*g_2519) |= ((!l_2546) , p_26)) & (((safe_sub_func_int8_t_s_s((((((-2L) && ((l_2604 = ((p_26 || (0x6FE4L > l_2559[1])) == p_26)) | 0x40C8L)) , p_28) <= l_2561) <= 9UL), (*g_483))) < l_2540[0][0][1].f0) != 0x01L)))), p_26)) & l_2540[0][0][1].f5), 1UL)))) || 255UL) <= 0x3CL), p_26)))
                { /* block id: 1211 */
                    uint16_t l_2654 = 0xA58EL;
                    uint32_t l_2655 = 8UL;
                    int32_t l_2656 = 0L;
                    int64_t ** const l_2659[7] = {&g_208[3][1][5],&g_208[3][1][5],&g_208[3][1][5],&g_208[3][1][5],&g_208[3][1][5],&g_208[3][1][5],&g_208[3][1][5]};
                    int64_t ** const *l_2658 = &l_2659[0];
                    int64_t ** const **l_2657[7];
                    int i;
                    for (i = 0; i < 7; i++)
                        l_2657[i] = &l_2658;
                    for (g_385.f5 = 0; (g_385.f5 > 1); g_385.f5 = safe_add_func_int32_t_s_s(g_385.f5, 7))
                    { /* block id: 1214 */
                        uint64_t l_2630 = 6UL;
                        int32_t l_2651 = (-6L);
                        uint16_t *l_2664 = &g_379.f3;
                        l_2656 |= (((+4294967295UL) <= (safe_mod_func_uint16_t_u_u((l_2630 , (18446744073709551609UL && ((safe_mul_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u((l_2651 = (((l_2559[1] = (((((~(safe_div_func_uint8_t_u_u(0xE6L, (safe_rshift_func_uint16_t_u_u((safe_lshift_func_int8_t_s_u((safe_lshift_func_int16_t_s_s(((*g_2519) = ((*p_27) < (safe_sub_func_uint32_t_u_u(((safe_rshift_func_uint8_t_u_s(((l_2648[9][0][0] = l_2630) && (safe_sub_func_uint32_t_u_u((((*g_483)++) >= ((p_26 || (l_2560 < ((p_28 , l_2546) != l_2651))) , 0xE1L)), (-3L)))), 2)) | p_26), 0x84E9EAA0L)))), 1)), l_2604)), 4))))) || 18446744073709551613UL) >= 0xC498A7C6BF5DFE2CLL) ^ 0x93638109L) || (*g_2519))) <= 0UL) & l_2654)), l_2603)), 0x7F98L)) == l_2655))), p_28))) , l_2539);
                        l_2559[8] |= (((((void*)0 == l_2657[3]) || l_2604) > (safe_div_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u(p_26, 5)), ((**g_2518) = ((2UL != ((l_2664 == (void*)0) , 1L)) , p_26))))) <= l_2655);
                        l_2665 = (void*)0;
                    }
                    for (g_381.f2 = (-19); (g_381.f2 == 28); ++g_381.f2)
                    { /* block id: 1227 */
                        if (g_380.f4)
                            goto lbl_2607;
                    }
                    l_2665 = p_27;
                }
                else
                { /* block id: 1231 */
                    int32_t l_2668 = 0xC4E2A013L;
                    if (l_2668)
                        break;
                }
                l_2604 = l_2604;
            }
        }
    }
    for (g_1099.f2 = 3; (g_1099.f2 >= 0); g_1099.f2 -= 1)
    { /* block id: 1240 */
        int32_t l_2669[5];
        int32_t *l_2674 = &g_388.f2;
        int i;
        for (i = 0; i < 5; i++)
            l_2669[i] = (-1L);
        if (l_2540[0][0][1].f1)
        { /* block id: 1241 */
            int16_t l_2670 = 0x1A89L;
            l_2670 ^= (l_2669[3] &= 0x432FF4B2L);
        }
        else
        { /* block id: 1244 */
            return l_2540[1][0][4];
        }
        l_2671--;
        (*l_2674) = (*p_27);
        if ((*p_27))
            continue;
    }
    l_2545 = ((l_2675 | 65535UL) , ((*l_2696) = (safe_rshift_func_int16_t_s_s((g_2678 == l_2679), ((*g_2519) = (safe_mul_func_uint16_t_u_u((l_2540[0][0][1].f5 && ((safe_add_func_uint32_t_u_u(((safe_add_func_int64_t_s_s((((((safe_sub_func_uint8_t_u_u(((p_28 >= ((((((safe_unary_minus_func_uint64_t_u(((*l_2693) = ((g_2689 = g_2689) == (void*)0)))) ^ (~(*p_27))) | l_2539) , (**g_792)) < l_2539) | 0L)) == 0x152CF7A2851D284ELL), p_28)) | p_26) & 0x764D0BADL) <= p_26) , p_28), l_2695)) < (-10L)), l_2539)) , 1UL)), p_26)))))));
    return l_2540[1][0][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_796.f3 g_109 g_792 g_426 g_707 g_483 g_371.f4 g_1745 g_223 g_380.f4 g_801 g_1099.f5 g_1119 g_1099.f4 g_389.f2 g_285 g_372.f3 g_380.f5 g_101 g_1825 g_1435 g_1436 g_93.f3 g_586.f2 g_385.f0 g_1013.f2 g_1539.f0 g_1411.f0 g_1824 g_369.f4 g_1695 g_377.f3 g_804 g_2101 g_374.f0 g_1271.f3 g_231 g_387.f3 g_387.f2 g_98 g_2185 g_2140 g_2141 g_532 g_2394 g_2395 g_2240 g_1752 g_386.f0 g_108 g_384.f4 g_371.f3 g_139 g_706 g_384.f3 g_1872 g_386.f5 g_375.f5 g_2428.f4
 * writes: g_285 g_372.f3 g_223 g_380.f4 g_371.f4 g_1752 g_859.f2 g_387.f3 g_388.f4 g_109 g_101 g_139 g_145 g_1695 g_1201 g_385.f0 g_1013.f2 g_1013.f4 g_2049 g_1470 g_366.f2 g_98 g_2140 g_387.f2 g_1356 g_1872 g_1098.f2 g_384.f0 g_385.f3 g_383.f4 g_386.f5 g_375.f5 g_2396 g_2240 g_801 g_2428.f4 g_386.f0 g_1745.f3 g_384.f4 g_384.f3
 */
static const int64_t  func_34(int32_t * p_35, int32_t  p_36, int32_t * p_37, int32_t * p_38, const int32_t ** p_39)
{ /* block id: 843 */
    int16_t l_1708 = 0x9E5DL;
    uint8_t ****l_1714 = (void*)0;
    uint8_t *****l_1713 = &l_1714;
    int32_t l_1730 = 0L;
    int32_t l_1731 = 1L;
    int32_t *l_1732 = &l_1730;
    uint32_t **l_1738 = &g_1258[0];
    struct S2 *** const l_1773 = &g_867[2];
    struct S2 *** const *l_1772[6] = {&l_1773,&l_1773,(void*)0,&l_1773,&l_1773,(void*)0};
    uint32_t l_1786[4];
    uint32_t **l_1878 = (void*)0;
    int32_t l_1891 = 0x9AF55F05L;
    int32_t l_1897 = 0x56E7F8B9L;
    uint16_t l_1899 = 0x0E7DL;
    int32_t l_1907 = 0xF64EA50DL;
    int32_t l_1908 = 0x24602D4CL;
    int32_t l_1910[5] = {3L,3L,3L,3L,3L};
    uint32_t l_1916 = 0UL;
    int32_t l_1945 = 0x1CBE96D9L;
    uint32_t l_1976[7] = {18446744073709551608UL,0xC64645C3L,18446744073709551608UL,18446744073709551608UL,0xC64645C3L,18446744073709551608UL,18446744073709551608UL};
    int32_t l_2001 = 0x8EED5B96L;
    uint16_t l_2034 = 0xCA62L;
    uint32_t *l_2038 = &l_1916;
    uint32_t l_2098[7] = {3UL,3UL,3UL,3UL,3UL,3UL,3UL};
    int64_t l_2107 = 0xCE0B6304EB5B08A4LL;
    uint32_t l_2162 = 1UL;
    struct S0 *l_2206 = &g_2207;
    struct S0 ***l_2244 = (void*)0;
    struct S0 ****l_2243 = &l_2244;
    uint8_t l_2255 = 0x64L;
    int64_t l_2256 = 0x26F37911B9C6FEC1LL;
    uint32_t ***l_2259[10] = {&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140,&g_2140};
    uint32_t l_2342 = 0UL;
    const uint64_t *l_2440 = &g_2424.f0;
    const uint64_t **l_2439 = &l_2440;
    const uint64_t ***l_2438 = &l_2439;
    int i;
    for (i = 0; i < 4; i++)
        l_1786[i] = 0xAE0D99C6L;
    if ((safe_mul_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_s(((l_1708 != (0UL ^ g_796.f3)) , (safe_mod_func_int64_t_s_s((safe_div_func_uint16_t_u_u((((l_1713 = l_1713) != ((safe_unary_minus_func_int64_t_s(((safe_mod_func_uint32_t_u_u((l_1708 < (((**g_792) = (safe_mul_func_uint8_t_u_u((safe_add_func_int32_t_s_s((safe_mul_func_int8_t_s_s((safe_mod_func_uint8_t_u_u(((l_1708 < l_1708) ^ (safe_add_func_int64_t_s_s((safe_add_func_int32_t_s_s((l_1730 = (*p_37)), (l_1731 = (l_1708 <= 0x27BC512EL)))), 0x2583F4E9C0543C2DLL))), p_36)), p_36)), l_1708)), 0x04L))) , 4L)), 0xEDB52593L)) ^ p_36))) , &g_1185[0])) && 0x800EL), 65534UL)), p_36))), 4)), p_36)))
    { /* block id: 848 */
        int32_t **l_1733 = &l_1732;
        uint32_t **l_1737 = &g_1258[1];
        uint32_t ***l_1736[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        const struct S2 l_1783[2][3] = {{{252UL,4,0x6D16364DL,-3L,0xFEL,0x7451L},{252UL,4,0x6D16364DL,-3L,0xFEL,0x7451L},{252UL,4,0x6D16364DL,-3L,0xFEL,0x7451L}},{{252UL,4,0x6D16364DL,-3L,0xFEL,0x7451L},{252UL,4,0x6D16364DL,-3L,0xFEL,0x7451L},{252UL,4,0x6D16364DL,-3L,0xFEL,0x7451L}}};
        int8_t **l_1848 = &g_887[4];
        int8_t ***l_1847 = &l_1848;
        uint16_t l_1862 = 65529UL;
        struct S1 *l_1865 = &g_1866;
        int32_t l_1887 = (-1L);
        int32_t l_1888 = 0x90AC433AL;
        int32_t l_1890 = 0x8C57B699L;
        int32_t l_1892 = 1L;
        int32_t l_1894 = 0xD25F7848L;
        int32_t l_1895 = 8L;
        int32_t l_1896 = 0xF047388FL;
        int32_t l_1913 = 0L;
        int32_t l_1914[8] = {0x444481FAL,0x444481FAL,0x92AB9E76L,0x444481FAL,0x444481FAL,0x92AB9E76L,0x444481FAL,0x444481FAL};
        uint32_t l_1956 = 0xEFF946FEL;
        uint32_t **l_1980 = (void*)0;
        uint16_t l_1996 = 0x3FADL;
        uint32_t l_2015[5];
        int32_t l_2110[2];
        const int32_t * const *l_2132 = &g_171;
        const int32_t * const **l_2131 = &l_2132;
        const int32_t * const ***l_2130 = &l_2131;
        uint64_t l_2154 = 0xE5EE75E94BE9D945LL;
        int32_t *l_2158 = &l_1897;
        int32_t *l_2159 = (void*)0;
        int32_t *l_2160 = (void*)0;
        int32_t *l_2161[6] = {&l_1910[0],&g_384.f2,&l_1910[0],&l_1910[0],&g_384.f2,&l_1910[0]};
        int i, j;
        for (i = 0; i < 5; i++)
            l_2015[i] = 0xB52E0787L;
        for (i = 0; i < 2; i++)
            l_2110[i] = 0x195DF58BL;
        (*l_1733) = l_1732;
        if (((safe_lshift_func_uint8_t_u_u(((**g_707) = (p_36 != (((l_1738 = &g_1258[0]) == (void*)0) && (-9L)))), 2)) & (safe_add_func_int8_t_s_s((safe_add_func_int64_t_s_s(0x3E253A8117115770LL, 0x1574119595D6B1C6LL)), 0x54L))))
        { /* block id: 852 */
            struct S1 **l_1750[10] = {(void*)0,&g_801,&g_793[3][0],&g_801,(void*)0,(void*)0,&g_801,&g_793[3][0],&g_801,(void*)0};
            int32_t l_1764 = 0x3FA195DAL;
            int32_t l_1765 = 4L;
            uint8_t ***l_1823 = (void*)0;
            int32_t *l_1836 = (void*)0;
            int64_t ***l_1849 = (void*)0;
            struct S1 ***l_1854[6][4] = {{&l_1750[0],(void*)0,&g_1752,(void*)0},{&l_1750[0],(void*)0,&l_1750[0],(void*)0},{&l_1750[0],(void*)0,&l_1750[0],(void*)0},{&l_1750[0],(void*)0,&g_1752,(void*)0},{&l_1750[0],(void*)0,&l_1750[0],(void*)0},{&l_1750[0],(void*)0,&l_1750[0],(void*)0}};
            int64_t l_1861 = 0x56DDC149E9FD9601LL;
            struct S2 **l_1863[6] = {&g_868,&g_868,&g_868,&g_868,&g_868,&g_868};
            int32_t l_1893 = (-1L);
            int32_t l_1898 = 9L;
            int32_t l_1905 = 0L;
            int32_t l_1906 = 0xA3ECF2D7L;
            int32_t l_1909 = 0x9D3B976FL;
            int32_t l_1911[9] = {0x88E68A06L,0x88E68A06L,(-9L),0x88E68A06L,0x88E68A06L,(-9L),0x88E68A06L,0x88E68A06L,(-9L)};
            int32_t l_1912 = (-1L);
            int i, j;
            for (g_371.f4 = 0; (g_371.f4 <= 52); g_371.f4 = safe_add_func_int32_t_s_s(g_371.f4, 8))
            { /* block id: 855 */
                struct S1 ***l_1751[5][4];
                int32_t *l_1761 = (void*)0;
                int32_t *l_1762 = &g_859.f2;
                int32_t l_1763 = 1L;
                int64_t *l_1766 = (void*)0;
                int8_t *l_1780[2][7] = {{&g_1527[1][5],&g_1527[1][5],&g_1527[1][5],&g_1745.f4,&g_1745.f4,&g_1527[1][5],&g_1745.f4},{&g_1745.f4,&g_1013.f4,&g_1013.f4,&g_1745.f4,&g_1013.f4,&g_1013.f4,&g_1745.f4}};
                int32_t ***l_1785 = (void*)0;
                int32_t ****l_1784 = &l_1785;
                struct S2 * const *l_1789[1];
                struct S2 * const **l_1788 = &l_1789[0];
                struct S2 * const ***l_1787 = &l_1788;
                uint64_t l_1807 = 5UL;
                int64_t **l_1827 = &l_1766;
                int64_t ***l_1826 = &l_1827;
                int i, j;
                for (i = 0; i < 5; i++)
                {
                    for (j = 0; j < 4; j++)
                        l_1751[i][j] = &l_1750[0];
                }
                for (i = 0; i < 1; i++)
                    l_1789[i] = &g_868;
                if (((((**l_1733) = (l_1765 |= ((g_1745 , 0x2754L) | (safe_div_func_uint8_t_u_u((safe_mul_func_int8_t_s_s(((g_1752 = l_1750[0]) == &g_793[3][0]), ((*g_483) && (safe_div_func_uint64_t_u_u((**l_1733), (((*l_1762) = (safe_mul_func_int8_t_s_s((1UL < (safe_add_func_uint64_t_u_u(((safe_mul_func_uint16_t_u_u((((0x0AB4D618L ^ (0x93L ^ (**g_707))) , (void*)0) != g_801), (**l_1733))) | p_36), (*l_1732)))), 1L))) , l_1763)))))), l_1764))))) | 18446744073709551610UL) || p_36))
                { /* block id: 860 */
                    for (g_387.f3 = 0; (g_387.f3 <= 0); g_387.f3 += 1)
                    { /* block id: 863 */
                        l_1765 ^= (*l_1732);
                    }
                }
                else
                { /* block id: 866 */
                    (*l_1732) |= (safe_unary_minus_func_int16_t_s(l_1763));
                }
            }
            if (((g_1099.f5 || (&g_868 == ((safe_sub_func_uint8_t_u_u((safe_mod_func_int8_t_s_s(((g_1752 = (void*)0) == &g_801), 0x69L)), ((safe_div_func_uint64_t_u_u(((**l_1733) , (safe_div_func_uint64_t_u_u((g_1119 != (void*)0), (safe_div_func_int16_t_s_s((((*l_1732) & l_1861) , g_1099.f4), l_1862))))), 0x17D3BAC5EC79E516LL)) & 0L))) , l_1863[5]))) >= 0x2DB5112E121A0455LL))
            { /* block id: 896 */
                struct S1 *l_1864 = (void*)0;
                int32_t l_1871[2];
                int32_t l_1889[10][5][5] = {{{0x3B353998L,1L,0xA06FC0AEL,8L,8L},{(-1L),0L,(-1L),(-1L),0xA5285DBAL},{0L,0x7DD57A43L,0xB3EB0077L,0x5284ED40L,0xF080468AL},{0xC63DA590L,0xA00EF1CAL,0xD8904CB7L,7L,(-1L)},{2L,0L,0xB3EB0077L,0xF080468AL,(-1L)}},{{3L,(-10L),(-1L),0xA06FC0AEL,(-3L)},{(-1L),0x1818257AL,0xA06FC0AEL,2L,0xB3EB0077L},{1L,(-1L),0L,0x1D9D665AL,4L},{(-8L),0xD8904CB7L,0L,(-1L),0x1776743BL},{3L,(-9L),4L,(-3L),(-1L)}},{{(-1L),(-1L),0L,0xA00EF1CAL,0xE010E9FCL},{0xA00EF1CAL,0x669A8E3EL,3L,0L,0xE010E9FCL},{0xA06FC0AEL,0x68F2F9DFL,0xB39659C4L,0x3B353998L,(-1L)},{0L,0x3B353998L,9L,0L,0x1776743BL},{0xD8904CB7L,(-1L),0xA84633A1L,0x1EA52D39L,4L}},{{0L,0xF080468AL,0xBEA844CAL,8L,0xB3EB0077L},{0xA99AEA43L,2L,(-3L),(-9L),(-3L)},{6L,6L,0L,1L,(-1L)},{0x1D9D665AL,0L,0x1D1278D2L,0x90061271L,(-1L)},{(-9L),(-1L),0x1EA52D39L,3L,0xF080468AL}},{{9L,0L,(-9L),0x0994E3E9L,0xA5285DBAL},{0xA5285DBAL,6L,0x93E93D22L,(-8L),8L},{0x3A19C4EDL,2L,0L,6L,0L},{0x1EA52D39L,0xF080468AL,(-1L),0x44F4716EL,(-9L)},{(-10L),(-1L),2L,1L,(-1L)}},{{7L,0x3B353998L,0x7DD57A43L,(-1L),0x44F4716EL},{0x90C44FFCL,0x68F2F9DFL,(-5L),9L,0x0994E3E9L},{0x5B51ACC3L,0x669A8E3EL,(-1L),9L,0L},{1L,(-1L),4L,(-1L),0L},{0L,(-9L),0x3A19C4EDL,1L,0x68F2F9DFL}},{{(-9L),0xD8904CB7L,0x5B51ACC3L,0x44F4716EL,0L},{0L,(-1L),0x3B353998L,6L,0x1D9D665AL},{0xA84633A1L,0x1818257AL,(-8L),(-8L),0x1818257AL},{(-1L),(-10L),(-8L),0x0994E3E9L,0xDEC60FCBL},{0L,0L,0xDEC60FCBL,3L,0x2BB57271L}},{{0x44F4716EL,0xA00EF1CAL,(-1L),8L,(-1L)},{1L,0x93E93D22L,0xE010E9FCL,0xC63DA590L,(-1L)},{0x90C44FFCL,0L,0x1818257AL,0L,0L},{0xDC4A168DL,0xB3EB0077L,0L,4L,0L},{(-1L),0xDC4A168DL,0xC63DA590L,0x49F5C25AL,0xB3EB0077L}},{{0xA00EF1CAL,0xB39659C4L,0L,0L,0x2BB57271L},{0x1D1278D2L,0L,7L,0xA5285DBAL,0xDC4A168DL},{0xB3EB0077L,(-3L),0x5B51ACC3L,0x669A8E3EL,(-1L)},{0L,(-9L),0x5B51ACC3L,7L,0x93E93D22L},{0x44F4716EL,0x3ACF485AL,7L,0xA06FC0AEL,8L}},{{(-9L),0xD8904CB7L,0L,0L,0x0994E3E9L},{0x3B353998L,0xF080468AL,0xC63DA590L,(-1L),7L},{0x49F5C25AL,0L,0L,0x3A19C4EDL,(-1L)},{0xA84633A1L,0x68F2F9DFL,0x1818257AL,0x68F2F9DFL,0xA84633A1L},{0L,0x1776743BL,0xE010E9FCL,(-8L),(-1L)}}};
                int i, j, k;
                for (i = 0; i < 2; i++)
                    l_1871[i] = 0L;
                l_1865 = l_1864;
                for (g_388.f4 = 0; g_388.f4 < 4; g_388.f4 += 1)
                {
                    l_1786[g_388.f4] = 4294967295UL;
                }
                if (((p_36 , ((safe_mul_func_int8_t_s_s(p_36, (2UL | g_389.f2))) >= ((((**g_792)--) >= ((((*p_37) = ((safe_add_func_int32_t_s_s((+(l_1878 == (void*)0)), (safe_rshift_func_uint16_t_u_u((safe_mul_func_int16_t_s_s((safe_mod_func_int64_t_s_s(((&g_725 != ((l_1783[0][0] , ((p_36 , (**l_1733)) ^ 0x6E54D0E3L)) , (void*)0)) , l_1871[0]), p_36)), (*l_1732))), (*l_1732))))) & g_380.f5)) != p_36) ^ (-7L))) < 0x763D62C6L))) , (*l_1732)))
                { /* block id: 901 */
                    int32_t *l_1885 = (void*)0;
                    int32_t *l_1886[3][1][3] = {{{&g_370.f2,&g_370.f2,&g_370.f2}},{{&g_586.f2,&g_586.f2,&g_586.f2}},{{&g_370.f2,&g_370.f2,&g_370.f2}}};
                    int i, j, k;
                    l_1899--;
                    (*p_37) = ((*l_1732) = (**l_1733));
                }
                else
                { /* block id: 905 */
                    int32_t l_1902[3];
                    int32_t l_1903[9] = {0x1FC1A801L,(-3L),0x1FC1A801L,(-3L),0x1FC1A801L,(-3L),0x1FC1A801L,(-3L),0x1FC1A801L};
                    int32_t *l_1904[3];
                    int16_t l_1915 = 0x02CFL;
                    int32_t ***l_1920[7] = {&g_1546,&g_1546,&g_1546,&g_1546,&g_1546,&g_1546,&g_1546};
                    int32_t ****l_1919 = &l_1920[0];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_1902[i] = 0xE22FA40AL;
                    for (i = 0; i < 3; i++)
                        l_1904[i] = &g_110[0];
                    l_1916--;
                    (*l_1919) = &g_1546;
                }
            }
            else
            { /* block id: 909 */
                uint64_t *l_1951 = (void*)0;
                uint64_t *l_1952[8];
                int32_t *l_1953 = &g_387.f2;
                int i;
                for (i = 0; i < 8; i++)
                    l_1952[i] = &g_384.f0;
                (*l_1733) = l_1953;
            }
        }
        else
        { /* block id: 913 */
            int64_t **l_1972 = &g_208[3][0][4];
            int32_t l_1975 = 0x08563098L;
            int32_t l_1990 = (-6L);
            int32_t l_1991 = 0x58340B69L;
            int32_t l_1992 = (-3L);
            const uint8_t l_2017 = 0xB5L;
            uint16_t l_2039 = 0xF0BFL;
            int32_t l_2060 = (-1L);
            int32_t l_2061 = 0xAFBB8E4CL;
            int16_t *l_2117[1][3][2] = {{{&g_1470,&g_1470},{&g_1470,&g_1470},{&g_1470,&g_1470}}};
            int32_t *l_2125 = (void*)0;
            int32_t *l_2126[7] = {&l_1890,&l_1890,&l_1890,&l_1890,&l_1890,&l_1890,&l_1890};
            int i, j, k;
            (**l_1733) = (*l_1732);
            if (((safe_lshift_func_int8_t_s_s(l_1956, 2)) >= 0x2479L))
            { /* block id: 915 */
                int8_t l_1961 = 0L;
                uint32_t *l_1978[9][1] = {{&l_1956},{&l_1786[3]},{&l_1786[3]},{&l_1956},{&l_1786[3]},{&l_1786[3]},{&l_1956},{&l_1786[3]},{&l_1786[3]}};
                uint32_t **l_1977 = &l_1978[8][0];
                int32_t l_1989 = (-1L);
                int32_t l_1993 = 0x75826A28L;
                int32_t l_1995 = 0xED1F6204L;
                struct S2 * const *l_2000 = (void*)0;
                struct S2 * const **l_1999 = &l_2000;
                int32_t **l_2032 = &g_12;
                int i, j;
                for (g_101 = 0; (g_101 > (-21)); g_101 = safe_sub_func_int16_t_s_s(g_101, 6))
                { /* block id: 918 */
                    int16_t *l_1964 = &g_139;
                    int32_t l_1967 = 1L;
                    int32_t l_1994 = 0x478B2AB9L;
                    int32_t l_2016 = 1L;
                    if (((safe_rshift_func_uint8_t_u_u((((l_1961 ^ (safe_mod_func_int64_t_s_s(((((*l_1964) = (-1L)) < (g_1695[6][0] = (g_145 = (((safe_rshift_func_uint8_t_u_u(p_36, 5)) & l_1967) == 7L)))) & (0xC3C84931A8AB5879LL == ((safe_lshift_func_uint8_t_u_u((safe_mul_func_int16_t_s_s(((l_1972 == (void*)0) || (safe_div_func_uint64_t_u_u(((((((((l_1975 <= 0xB97A7A8E802C1A7DLL) < p_36) <= l_1961) , 18446744073709551614UL) <= (**l_1733)) , (*g_792)) == l_1964) & 0L), (**l_1733)))), p_36)), 4)) < l_1976[5]))), p_36))) == (*l_1732)) || 0x1BL), (**g_1825))) >= p_36))
                    { /* block id: 922 */
                        uint32_t ***l_1979[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
                        int i;
                        l_1980 = l_1977;
                        if (l_1967)
                            continue;
                        return l_1961;
                    }
                    else
                    { /* block id: 926 */
                        struct S2 *** const l_2002 = &g_867[1];
                        int64_t *l_2007 = (void*)0;
                        int64_t *l_2008 = (void*)0;
                        int64_t *l_2009 = &g_1201;
                        uint64_t *l_2014 = &g_385.f0;
                        (*p_37) &= (safe_mul_func_int8_t_s_s((safe_mod_func_uint8_t_u_u((safe_sub_func_int16_t_s_s(((*l_1732) & (safe_rshift_func_uint8_t_u_s(((**l_1733) > (((void*)0 != &g_192) & (g_1745.f0 , (&g_868 == &g_868)))), 7))), ((((((--l_1996) , l_1999) != ((l_2001 ^ p_36) , l_2002)) > p_36) , (**l_1733)) == (*l_1732)))), p_36)), 1UL));
                        (**l_1733) |= 0x02A6B4FCL;
                        (*p_37) |= ((safe_mul_func_int8_t_s_s(p_36, (((**l_1733) || ((safe_add_func_int64_t_s_s(((*l_2009) = ((((**l_1733) ^= p_36) < (&l_1961 != (void*)0)) , (0xF4BDE013L || p_36))), (safe_div_func_uint16_t_u_u((((*l_2014) &= (safe_mod_func_uint16_t_u_u(((**g_1435) < ((((4294967293UL <= g_586.f2) | l_1992) < p_36) | 0x8582A2D25B2DCC68LL)), p_36))) | 0xC1F3DF917E0DE785LL), l_2015[3])))) <= l_1993)) > l_2016))) == l_2017);
                    }
                }
                for (g_1013.f2 = (-24); (g_1013.f2 == (-3)); ++g_1013.f2)
                { /* block id: 938 */
                    uint8_t l_2033 = 6UL;
                    uint64_t **l_2047[10][6][2] = {{{&g_318,(void*)0},{&g_318,&g_318},{&g_316,(void*)0},{&g_318,&g_316},{(void*)0,&g_318},{&g_316,&g_316}},{{(void*)0,&g_316},{&g_318,&g_318},{&g_316,&g_316},{&g_316,&g_316},{&g_316,&g_316},{&g_316,&g_318}},{{(void*)0,&g_316},{&g_316,(void*)0},{&g_316,&g_318},{&g_316,(void*)0},{&g_316,&g_316},{(void*)0,&g_318}},{{&g_316,&g_316},{&g_316,&g_316},{&g_316,&g_316},{&g_316,&g_318},{&g_318,&g_316},{(void*)0,&g_316}},{{&g_316,&g_318},{(void*)0,&g_316},{&g_318,(void*)0},{&g_316,&g_318},{&g_318,(void*)0},{&g_318,&g_318}},{{(void*)0,&g_318},{&g_318,&g_316},{(void*)0,&g_318},{&g_316,&g_318},{&g_316,&g_318},{&g_318,&g_316}},{{&g_316,&g_318},{(void*)0,&g_316},{&g_316,&g_318},{&g_318,&g_316},{&g_318,(void*)0},{&g_318,&g_318}},{{&g_318,&g_318},{&g_318,&g_316},{&g_318,(void*)0},{&g_316,&g_318},{&g_316,&g_318},{&g_318,(void*)0}},{{&g_318,&g_318},{(void*)0,&g_318},{&g_318,&g_316},{&g_316,&g_318},{(void*)0,&g_316},{&g_318,&g_318}},{{&g_318,&g_316},{(void*)0,&g_318},{&g_316,&g_316},{&g_318,&g_318},{(void*)0,&g_318},{&g_318,(void*)0}}};
                    int32_t l_2056 = 0xA49788C0L;
                    int32_t l_2057 = 9L;
                    int32_t l_2059[1];
                    uint64_t l_2062 = 0xCECD8430A8A6E39BLL;
                    int32_t l_2074[5][5][1] = {{{0L},{(-5L)},{0xCB2404F2L},{0xCB2404F2L},{(-5L)}},{{0L},{(-5L)},{0xCB2404F2L},{0xCB2404F2L},{(-5L)}},{{0L},{(-5L)},{0xCB2404F2L},{0xCB2404F2L},{(-5L)}},{{0L},{(-5L)},{0xCB2404F2L},{0xCB2404F2L},{(-5L)}},{{0L},{(-5L)},{0xCB2404F2L},{0xCB2404F2L},{(-5L)}}};
                    int i, j, k;
                    for (i = 0; i < 1; i++)
                        l_2059[i] = 0x44EF6805L;
                    if (((**l_1733) = 2L))
                    { /* block id: 940 */
                        int8_t *l_2027 = &g_1013.f4;
                        int32_t l_2035 = 0L;
                        int16_t *l_2045 = &g_1695[2][0];
                        uint64_t **l_2046 = &g_316;
                        uint64_t ***l_2048[2][8][4] = {{{&l_2046,&l_2046,&l_2046,&l_2046},{&l_2046,&l_2046,&l_2046,&l_2046},{&l_2046,&l_2046,&l_2046,&l_2046},{&l_2046,&l_2046,&l_2046,&l_2046},{&l_2046,&l_2046,&l_2046,&l_2046},{&l_2046,&l_2046,&l_2046,&l_2046},{&l_2046,&l_2046,&l_2046,&l_2046},{&l_2046,&l_2046,&l_2046,&l_2046}},{{&l_2046,&l_2046,&l_2046,&l_2046},{&l_2046,&l_2046,&l_2046,&l_2046},{&l_2046,&l_2046,&l_2046,&l_2046},{&l_2046,&l_2046,&l_2046,&l_2046},{&l_2046,&l_2046,&l_2046,&l_2046},{&l_2046,&l_2046,&l_2046,&l_2046},{&l_2046,&l_2046,&l_2046,&l_2046},{&l_2046,&l_2046,&l_2046,&l_2046}}};
                        int32_t *l_2050 = &g_374.f2;
                        int32_t *l_2051 = (void*)0;
                        int32_t *l_2052 = &g_107;
                        int32_t *l_2053 = (void*)0;
                        int32_t *l_2054 = &l_1731;
                        int32_t *l_2055[4][5][6] = {{{&l_1990,&l_1992,&g_100,(void*)0,&g_100,&l_1992},{&l_1895,(void*)0,&g_384.f2,&g_1098.f2,&g_109,&g_372.f2},{(void*)0,&g_104,(void*)0,&g_376.f2,&g_107,&l_1914[5]},{&l_2035,&g_104,&g_7,&l_1975,&g_109,&g_383.f2},{&g_372.f2,(void*)0,&g_366.f2,&g_103,&g_100,&l_1995}},{{(void*)0,&l_1992,(void*)0,&l_1895,&g_376.f2,&g_1099.f2},{&g_1099.f2,&g_1098.f2,&g_381.f2,&l_1989,&g_376.f2,&l_1896},{&l_1992,&l_1896,&l_1730,&l_1894,&l_1894,&l_1730},{&l_1908,&l_1908,(void*)0,&l_1992,&g_101,(void*)0},{(void*)0,&g_372.f2,&l_1888,&l_1895,&g_374.f2,(void*)0}},{{&g_1098.f2,(void*)0,&l_1888,&g_108,&l_1896,(void*)0},{&g_376.f2,&g_108,(void*)0,(void*)0,(void*)0,&g_374.f2},{(void*)0,(void*)0,&g_374.f2,&l_1975,&g_100,&g_109},{&g_379.f2,&g_103,&l_1989,&g_372.f2,&l_1894,&l_1914[5]},{&l_1894,&l_1995,&g_108,(void*)0,&g_103,(void*)0}},{{(void*)0,&l_1914[5],(void*)0,(void*)0,&g_366.f2,(void*)0},{(void*)0,&g_104,&g_379.f2,&l_1896,&l_1990,(void*)0},{&g_376.f2,&g_384.f2,&g_1098.f2,&l_1896,&g_107,(void*)0},{(void*)0,&l_1730,&g_384.f2,(void*)0,&l_1975,&g_366.f2},{(void*)0,&g_383.f2,(void*)0,(void*)0,&l_1908,&l_1730}}};
                        int i, j, k;
                        l_2034 |= (safe_mul_func_uint8_t_u_u(((*l_1732) >= (safe_div_func_uint32_t_u_u(p_36, (g_1539[1][0].f0 | (safe_mod_func_uint64_t_u_u(0x5A871EEE3B444EAFLL, ((((*l_2027) = (0UL == (~g_1411.f0))) && p_36) || (safe_lshift_func_int8_t_s_u(0x01L, (safe_sub_func_int32_t_s_s(((l_1990 = (l_1733 != l_2032)) && 0UL), (**l_1733)))))))))))), l_2033));
                        (**l_1733) ^= (((l_2033 && l_2035) != ((*p_37) = (((((***g_1824) < (l_2039 = ((*l_1977) == (l_2038 = p_37)))) | 0xD1D8E0D8L) , (!(**g_792))) >= (((safe_add_func_uint8_t_u_u((safe_rshift_func_int16_t_s_u((((*l_2045) ^= g_369.f4) <= ((g_2049 = (l_2047[1][3][1] = l_2046)) != (void*)0)), 11)), (-6L))) , 4294967295UL) | (*p_37))))) != g_377[3].f3);
                        --l_2062;
                        (*l_2054) &= 0L;
                    }
                    else
                    { /* block id: 953 */
                        int32_t *l_2065 = &l_1945;
                        int32_t *l_2066 = &l_1990;
                        int32_t *l_2067 = &g_374.f2;
                        int32_t *l_2068 = &l_1913;
                        int32_t *l_2069 = &l_1989;
                        int32_t *l_2070 = &g_370.f2;
                        int32_t *l_2071 = &l_1975;
                        int32_t *l_2072 = &l_1730;
                        int32_t *l_2073[3];
                        uint32_t l_2075 = 18446744073709551606UL;
                        int i;
                        for (i = 0; i < 3; i++)
                            l_2073[i] = &g_1099.f2;
                        --l_2075;
                        return l_1992;
                    }
                }
            }
            else
            { /* block id: 958 */
                int8_t l_2084[4] = {0x65L,0x65L,0x65L,0x65L};
                int16_t *l_2108 = &g_1470;
                int16_t *l_2109 = &g_1695[2][7];
                int i;
                l_2061 = (safe_div_func_uint64_t_u_u(((0x829E680B1D4369F1LL ^ (safe_sub_func_int16_t_s_s(((*l_2109) |= (safe_mod_func_int64_t_s_s((l_2084[3] && (((*l_1732) = l_2084[2]) >= ((((((safe_sub_func_int16_t_s_s((safe_sub_func_int16_t_s_s(((safe_div_func_uint16_t_u_u(((safe_div_func_int16_t_s_s(((((p_36 >= (safe_unary_minus_func_uint64_t_u((safe_sub_func_uint8_t_u_u((safe_add_func_uint16_t_u_u(((l_2098[0] <= (((*l_2108) = (0x1DL && (g_804 | ((**g_792) = ((l_1991 , (safe_mul_func_uint8_t_u_u((g_2101 != (void*)0), p_36))) != l_2107))))) > p_36)) ^ l_2017), 0x69D4L)), 0L))))) != l_2084[0]) <= 0x1DL) , p_36), p_36)) <= p_36), 8L)) | (**g_1435)), g_374.f0)), p_36)) < 0xB6AD9A5EL) & (*p_37)) , (-1L)) || p_36) & g_1271.f3))), l_1914[4]))), 0L))) , (*l_1732)), l_2110[1]));
            }
            l_1892 ^= ((safe_mul_func_uint8_t_u_u(p_36, p_36)) || ((safe_mod_func_int32_t_s_s(((safe_mul_func_uint16_t_u_u(((**g_792) = (*l_1732)), (g_145 = ((void*)0 != &g_793[3][1])))) >= ((*l_1732) ^ ((*p_37) = ((((*l_1732) > (0xF7L == (safe_lshift_func_uint8_t_u_s((~((safe_mul_func_int16_t_s_s(p_36, g_231)) | l_2017)), 5)))) != p_36) & (*l_1732))))), l_1990)) > p_36));
            for (g_387.f3 = 24; (g_387.f3 < 59); g_387.f3 = safe_add_func_uint8_t_u_u(g_387.f3, 4))
            { /* block id: 971 */
                const uint16_t l_2129[8] = {0x6C17L,0x6C17L,0x6C17L,0x6C17L,0x6C17L,0x6C17L,0x6C17L,0x6C17L};
                int i;
                return l_2129[3];
            }
        }
        if (((void*)0 != l_2130))
        { /* block id: 975 */
            uint8_t l_2142 = 0xD9L;
            int32_t * const l_2143[8] = {&l_1730,&l_1730,&l_1730,&l_1730,&l_1730,&l_1730,&l_1730,&l_1730};
            int i;
            for (l_1890 = 0; (l_1890 <= 0); l_1890 += 1)
            { /* block id: 978 */
                uint32_t l_2133 = 0UL;
                int32_t l_2147 = 0x16086DBCL;
                int32_t l_2148[3];
                int64_t l_2151 = 1L;
                int i;
                for (i = 0; i < 3; i++)
                    l_2148[i] = 1L;
                for (g_366.f2 = 0; (g_366.f2 <= 0); g_366.f2 += 1)
                { /* block id: 981 */
                    uint32_t ***l_2134 = &l_1980;
                    uint32_t ***l_2135 = &l_1980;
                    uint32_t ***l_2136 = &l_1980;
                    uint32_t ***l_2137 = (void*)0;
                    uint32_t ***l_2138 = &l_1980;
                    uint32_t ***l_2139[6] = {&l_1980,&l_1980,&l_1980,&l_1980,&l_1980,&l_1980};
                    int32_t l_2149 = 0x42EB8235L;
                    int32_t l_2150[7];
                    int16_t l_2152[6] = {0x311FL,0x311FL,0x311FL,0x311FL,0x311FL,0x311FL};
                    int i;
                    for (i = 0; i < 7; i++)
                        l_2150[i] = 0xC49E3913L;
                    g_98[l_1890] = l_2133;
                    if (((g_2140 = (void*)0) != (void*)0))
                    { /* block id: 984 */
                        (**l_1733) = l_2142;
                        if ((**l_1733))
                            break;
                        if ((*l_1732))
                            continue;
                    }
                    else
                    { /* block id: 988 */
                        int32_t **l_2144 = (void*)0;
                        int32_t **l_2145 = (void*)0;
                        int32_t **l_2146 = &g_1356[2];
                        (*l_2146) = l_2143[1];
                        return g_98[l_1890];
                    }
                    ++l_2154;
                    (*l_1732) &= l_2133;
                }
            }
        }
        else
        { /* block id: 996 */
            const uint8_t l_2157 = 0x52L;
            return l_2157;
        }
        l_2162--;
    }
    else
    { /* block id: 1000 */
        uint8_t l_2203 = 0x07L;
        int32_t *l_2212 = (void*)0;
        uint64_t l_2214 = 4UL;
        struct S0 ***l_2242 = &g_505;
        struct S0 ****l_2241[2][2][5] = {{{&l_2242,&l_2242,&l_2242,&l_2242,&l_2242},{&l_2242,&l_2242,&l_2242,&l_2242,&l_2242}},{{&l_2242,&l_2242,&l_2242,&l_2242,&l_2242},{&l_2242,&l_2242,&l_2242,&l_2242,&l_2242}}};
        uint64_t l_2276 = 0x6139440774242702LL;
        int16_t * const l_2311[10][1][2] = {{{&g_1695[5][1],&l_1708}},{{&g_139,&g_1695[5][1]}},{{&l_1708,(void*)0}},{{&l_1708,&g_1695[5][1]}},{{&g_139,&l_1708}},{{&g_1695[5][1],(void*)0}},{{&g_145,&g_145}},{{&g_139,&g_145}},{{&g_145,(void*)0}},{{&g_1695[5][1],&l_1708}}};
        int32_t l_2349 = (-1L);
        int32_t l_2352[8][1][6] = {{{0xFD8A59CAL,0xF277706BL,0xFD8A59CAL,0xFD8A59CAL,0xF277706BL,0xFD8A59CAL}},{{0xFD8A59CAL,0xF277706BL,0xFD8A59CAL,0xFD8A59CAL,0xF277706BL,0xFD8A59CAL}},{{0xFD8A59CAL,0xF277706BL,0xFD8A59CAL,0xFD8A59CAL,0xF277706BL,0xFD8A59CAL}},{{0xFD8A59CAL,0xF277706BL,0xFD8A59CAL,0xFD8A59CAL,0xF277706BL,0xFD8A59CAL}},{{0xFD8A59CAL,0xF277706BL,0xFD8A59CAL,0xFD8A59CAL,0xF277706BL,0xFD8A59CAL}},{{0xFD8A59CAL,0xF277706BL,0xFD8A59CAL,0xFD8A59CAL,0xF277706BL,0xFD8A59CAL}},{{0xFD8A59CAL,0xF277706BL,0xFD8A59CAL,0xFD8A59CAL,0xF277706BL,0xFD8A59CAL}},{{0xFD8A59CAL,0xF277706BL,0xFD8A59CAL,0xFD8A59CAL,0xF277706BL,0xFD8A59CAL}}};
        int32_t l_2398 = 0L;
        const uint64_t ***l_2442[2][6] = {{&l_2439,&l_2439,&l_2439,&l_2439,&l_2439,&l_2439},{&l_2439,&l_2439,&l_2439,&l_2439,&l_2439,&l_2439}};
        int32_t l_2446[9] = {0x86063F79L,0x86063F79L,0x86063F79L,0x86063F79L,0x86063F79L,0x86063F79L,0x86063F79L,0x86063F79L,0x86063F79L};
        struct S1 *l_2476 = &g_2477[8][1];
        struct S2 *l_2481 = &g_2482;
        int i, j, k;
lbl_2484:
        for (g_1872 = 0; (g_1872 <= (-15)); g_1872 = safe_sub_func_int8_t_s_s(g_1872, 3))
        { /* block id: 1003 */
            uint8_t l_2180 = 249UL;
            (*p_37) &= 1L;
            for (g_1098.f2 = (-26); (g_1098.f2 < 11); g_1098.f2++)
            { /* block id: 1007 */
                const struct S0 *l_2197 = &g_2198;
                const struct S0 **l_2196 = &l_2197;
                const struct S0 ***l_2195 = &l_2196;
                const struct S0 *** const *l_2194 = &l_2195;
                for (g_384.f0 = 0; (g_384.f0 >= 1); ++g_384.f0)
                { /* block id: 1010 */
                    int32_t l_2177 = 0L;
                    int32_t l_2201[2][7] = {{0x06372EFCL,(-1L),0x06372EFCL,0x06372EFCL,(-1L),0x06372EFCL,0x06372EFCL},{0x1EC7954FL,0x1EC7954FL,(-6L),0x1EC7954FL,0x1EC7954FL,(-6L),0x1EC7954FL}};
                    int i, j;
                    for (g_385.f3 = 0; (g_385.f3 <= 28); g_385.f3++)
                    { /* block id: 1013 */
                        uint64_t *l_2178 = (void*)0;
                        uint64_t *l_2179[9][2][4] = {{{&g_87,(void*)0,&g_378.f0,(void*)0},{&g_373.f0,&g_87,&g_804,(void*)0}},{{&g_376.f0,&g_366.f0,&g_804,(void*)0},{&g_373.f0,&g_378.f0,&g_378.f0,&g_373.f0}},{{&g_87,&g_376.f0,&g_373.f0,(void*)0},{&g_373.f0,(void*)0,(void*)0,&g_366.f0}},{{&g_1099.f0,&g_386.f0,(void*)0,&g_366.f0},{(void*)0,(void*)0,&g_1099.f0,(void*)0}},{{&g_723.f0,&g_376.f0,(void*)0,&g_373.f0},{(void*)0,&g_378.f0,(void*)0,(void*)0}},{{&g_386.f0,&g_366.f0,(void*)0,(void*)0},{&g_386.f0,&g_87,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,&g_804},{&g_723.f0,(void*)0,&g_1099.f0,&g_376.f0}},{{(void*)0,&g_373.f0,(void*)0,&g_1099.f0},{&g_1099.f0,&g_373.f0,(void*)0,&g_376.f0}},{{&g_373.f0,(void*)0,&g_373.f0,&g_804},{&g_87,(void*)0,&g_378.f0,(void*)0}}};
                        int32_t l_2183 = 0xF303C5F5L;
                        struct S0 ***l_2193 = (void*)0;
                        struct S0 ****l_2192 = &l_2193;
                        int i, j, k;
                        (*p_37) = (safe_lshift_func_int8_t_s_s(((safe_add_func_uint32_t_u_u((l_2177 && (l_2183 &= (--l_2180))), ((!g_2185) , ((*l_1732) || ((((safe_add_func_uint8_t_u_u((safe_div_func_int64_t_s_s(1L, l_2177)), (safe_mod_func_uint32_t_u_u((**g_2140), 0xDED40077L)))) && (*p_37)) , l_2192) != l_2194))))) | p_36), 4));
                    }
                    for (g_383.f4 = (-25); (g_383.f4 <= 17); g_383.f4 = safe_add_func_int16_t_s_s(g_383.f4, 1))
                    { /* block id: 1020 */
                        int32_t *l_2202[5];
                        int32_t **l_2208 = (void*)0;
                        int32_t **l_2209[3][9][6] = {{{(void*)0,(void*)0,&l_2202[3],&l_2202[2],&l_2202[3],(void*)0},{&g_1282[3],(void*)0,(void*)0,&g_1282[2],&l_2202[2],(void*)0},{(void*)0,&g_1356[4],&l_2202[3],&g_1282[2],&l_2202[3],&g_1356[4]},{&g_1282[3],&g_1356[4],(void*)0,&l_2202[2],&l_2202[2],&g_1356[4]},{(void*)0,(void*)0,&l_2202[3],&l_2202[2],&l_2202[3],(void*)0},{&g_1282[3],(void*)0,(void*)0,&g_1282[2],&l_2202[2],(void*)0},{(void*)0,&g_1356[4],&l_2202[3],&g_1282[2],&l_2202[3],&g_1356[4]},{&g_1282[3],&g_1356[4],(void*)0,&l_2202[2],&l_2202[2],&g_1356[4]},{(void*)0,(void*)0,&l_2202[3],&l_2202[2],&l_2202[3],(void*)0}},{{&g_1282[3],(void*)0,(void*)0,&g_1282[2],&l_2202[2],(void*)0},{(void*)0,&g_1356[4],&l_2202[3],&g_1282[2],&l_2202[3],&g_1356[4]},{&g_1282[3],&g_1356[4],(void*)0,&l_2202[2],&l_2202[2],&g_1356[4]},{(void*)0,(void*)0,&l_2202[3],&l_2202[2],&l_2202[3],(void*)0},{&g_1282[3],(void*)0,(void*)0,&g_1282[2],&l_2202[2],(void*)0},{&l_2202[3],(void*)0,&g_1356[5],(void*)0,&g_1356[5],(void*)0},{&l_2202[2],(void*)0,&g_1282[0],&g_1356[4],&g_1282[3],(void*)0},{&l_2202[3],&l_2202[4],&g_1356[5],&g_1356[4],&g_1356[5],&l_2202[4]},{&l_2202[2],&l_2202[4],&g_1282[0],(void*)0,&g_1282[3],&l_2202[4]}},{{&l_2202[3],(void*)0,&g_1356[5],(void*)0,&g_1356[5],(void*)0},{&l_2202[2],(void*)0,&g_1282[0],&g_1356[4],&g_1282[3],(void*)0},{&l_2202[3],&l_2202[4],&g_1356[5],&g_1356[4],&g_1356[5],&l_2202[4]},{&l_2202[2],&l_2202[4],&g_1282[0],(void*)0,&g_1282[3],&l_2202[4]},{&l_2202[3],(void*)0,&g_1356[5],(void*)0,&g_1356[5],(void*)0},{&l_2202[2],(void*)0,&g_1282[0],&g_1356[4],&g_1282[3],(void*)0},{&l_2202[3],&l_2202[4],&g_1356[5],&g_1356[4],&g_1356[5],&l_2202[4]},{&l_2202[2],&l_2202[4],&g_1282[0],(void*)0,&g_1282[3],&l_2202[4]},{&l_2202[3],(void*)0,&g_1356[5],(void*)0,&g_1356[5],(void*)0}}};
                        int i, j, k;
                        for (i = 0; i < 5; i++)
                            l_2202[i] = &g_384.f2;
                        l_2203--;
                        l_2206 = (void*)0;
                        (*l_1732) ^= l_2201[0][4];
                        p_38 = &l_1908;
                    }
                    if (l_2203)
                        continue;
                }
            }
            if ((*l_1732))
                break;
        }
        for (g_386.f5 = 0; (g_386.f5 <= (-9)); g_386.f5 = safe_sub_func_uint16_t_u_u(g_386.f5, 3))
        { /* block id: 1033 */
            int32_t **l_2213 = &l_2212;
            int64_t **l_2228[5][8] = {{&g_208[3][0][4],(void*)0,&g_208[3][0][4],(void*)0,&g_208[3][0][4],(void*)0,&g_208[3][0][4],(void*)0},{&g_208[3][0][4],(void*)0,&g_208[3][0][4],(void*)0,&g_208[3][0][4],(void*)0,&g_208[3][0][4],(void*)0},{&g_208[3][0][4],(void*)0,&g_208[3][0][4],(void*)0,&g_208[3][0][4],(void*)0,&g_208[3][0][4],(void*)0},{&g_208[3][0][4],(void*)0,&g_208[3][0][4],(void*)0,&g_208[3][0][4],(void*)0,&g_208[3][0][4],(void*)0},{&g_208[3][0][4],(void*)0,&g_208[3][0][4],(void*)0,&g_208[3][0][4],(void*)0,&g_208[3][0][4],(void*)0}};
            int64_t ***l_2227 = &l_2228[3][6];
            int64_t ****l_2226[5] = {&l_2227,&l_2227,&l_2227,&l_2227,&l_2227};
            uint8_t ****l_2274 = (void*)0;
            int32_t l_2275 = 0x5D8BAC8EL;
            uint16_t ***l_2290 = &g_792;
            int32_t l_2350 = 0xF404F4F1L;
            int32_t l_2351[2][9] = {{0x8D1BEA04L,0L,0L,0x8D1BEA04L,0L,0L,0x8D1BEA04L,0L,0L},{0x8D1BEA04L,0L,0L,0x8D1BEA04L,0L,0L,0x8D1BEA04L,0L,0L}};
            uint32_t l_2356 = 1UL;
            uint8_t **l_2374 = &g_483;
            uint32_t l_2415 = 0xDC8EBC3BL;
            struct S0 *l_2421[7][9] = {{(void*)0,&g_2426,&g_2423,&g_2433,&g_2433,&g_2423,&g_2426,(void*)0,&g_2424},{&g_2429,&g_2430,&g_2422,&g_2428,&g_2433,(void*)0,&g_2427,(void*)0,(void*)0},{&g_2425,&g_2432,&g_2430,(void*)0,&g_2430,&g_2432,&g_2425,(void*)0,&g_2424},{(void*)0,(void*)0,&g_2425,(void*)0,(void*)0,&g_2433,&g_2431,&g_2430,&g_2431},{&g_2431,&g_2429,&g_2428,&g_2428,&g_2429,&g_2431,&g_2424,(void*)0,&g_2425},{&g_2430,&g_2422,&g_2428,&g_2433,(void*)0,(void*)0,&g_2430,&g_2430,(void*)0},{&g_2432,&g_2430,(void*)0,&g_2430,&g_2432,&g_2425,(void*)0,&g_2424,&g_2431}};
            struct S0 *****l_2444 = &g_2240;
            uint32_t l_2513 = 0xEA580873L;
            int i, j;
            (*l_2213) = l_2212;
            (*l_2213) = (*l_2213);
            for (g_375.f5 = 3; (g_375.f5 >= 1); g_375.f5 -= 1)
            { /* block id: 1038 */
                int64_t *****l_2229 = &l_2226[2];
                int32_t l_2232 = 0x008F46FCL;
                struct S0 *****l_2245 = &l_2243;
                int16_t *l_2246 = &g_139;
                int8_t *l_2257 = &g_1527[2][3];
                int8_t *l_2258 = &g_1013.f3;
                int16_t l_2292 = 0x7033L;
                struct S1 **l_2319 = &g_801;
                uint8_t **l_2340 = &g_483;
                int32_t l_2353[9] = {0x109EAC81L,0x65D05681L,0x109EAC81L,0x65D05681L,0x109EAC81L,0x65D05681L,0x109EAC81L,0x65D05681L,0x109EAC81L};
                const uint64_t ****l_2441 = &l_2438;
                const uint64_t ***l_2443 = &l_2439;
                int i;
            }
            if ((((((**g_2394) = 4UL) , (void*)0) == ((*l_2444) = g_2240)) ^ ((*l_1732) = (-1L))))
            { /* block id: 1113 */
                uint32_t l_2447[9] = {0x4A09EE69L,0x4A09EE69L,0x4A09EE69L,0x4A09EE69L,0x4A09EE69L,0x4A09EE69L,0x4A09EE69L,0x4A09EE69L,0x4A09EE69L};
                int32_t l_2450[1];
                uint32_t l_2451 = 9UL;
                int16_t l_2474 = (-2L);
                struct S2 *l_2480 = &g_859;
                int i;
                for (i = 0; i < 1; i++)
                    l_2450[i] = 0x350B1FDFL;
                if ((*p_37))
                    break;
                (*g_1752) = (*g_1752);
                for (g_2428.f4 = 0; (g_2428.f4 <= 2); g_2428.f4 += 1)
                { /* block id: 1118 */
                    int32_t *l_2445[8][9] = {{&g_107,&l_2350,&g_2431.f2,(void*)0,&g_723.f2,(void*)0,(void*)0,&g_723.f2,(void*)0},{&g_110[0],&g_7,&g_110[0],&g_2431.f2,(void*)0,&g_2424.f2,&g_380.f2,&g_374.f2,(void*)0},{(void*)0,&g_110[0],&g_723.f2,(void*)0,&g_109,&g_374.f2,&g_109,(void*)0,&g_723.f2},{(void*)0,(void*)0,&g_7,&g_2431.f2,(void*)0,&g_110[0],&g_723.f2,(void*)0,&g_109},{&g_2424.f2,&g_380.f2,&g_374.f2,(void*)0,&g_375.f2,&g_375.f2,(void*)0,&g_374.f2,&g_380.f2},{&g_375.f2,&g_383.f2,&g_7,&g_107,&l_2350,&g_2431.f2,(void*)0,&g_723.f2,(void*)0},{(void*)0,&g_2424.f2,&g_723.f2,&g_380.f2,&g_2424.f2,&g_380.f2,&g_723.f2,&g_2424.f2,(void*)0},{&l_2350,&g_383.f2,&g_110[0],&g_2424.f2,(void*)0,&g_380.f2,&g_109,&g_7,&g_2424.f2}};
                    int i, j;
                    --l_2447[2];
                    ++l_2451;
                }
                for (g_386.f0 = 0; (g_386.f0 <= 4); g_386.f0 += 1)
                { /* block id: 1124 */
                    int8_t *l_2475 = &g_1745.f3;
                    int i, j;
                    l_1910[g_386.f0] = (l_1910[g_386.f0] | (0xF7D35495EADD2016LL | ((safe_sub_func_int32_t_s_s((safe_mul_func_uint8_t_u_u(((safe_div_func_uint8_t_u_u((safe_mod_func_int16_t_s_s(l_1910[g_386.f0], (p_36 && (safe_sub_func_int8_t_s_s(((*l_1732) | p_36), (safe_add_func_uint64_t_u_u((safe_sub_func_int32_t_s_s(((safe_div_func_int16_t_s_s((safe_add_func_uint32_t_u_u((l_2450[0] = (255UL < ((**g_1825) = ((((((***l_2290) = (((*l_2475) = (safe_div_func_int32_t_s_s(l_2474, (*l_1732)))) <= 0xDCL)) < p_36) , g_108) && l_1910[g_386.f0]) || 1UL)))), 4294967295UL)), p_36)) && 2UL), (*l_1732))), p_36))))))), 0x49L)) >= p_36), p_36)), (*p_37))) != (*l_1732))));
                    if (l_1910[g_386.f0])
                        break;
                    if (((*l_1732) || p_36))
                    { /* block id: 1131 */
                        struct S1 *l_2478 = &g_2479;
                        (*g_1752) = (l_2478 = l_2476);
                        (*l_1732) = (p_36 , 0x19382AD2L);
                        l_2481 = l_2480;
                    }
                    else
                    { /* block id: 1136 */
                        uint32_t l_2483[4][9] = {{4294967293UL,4294967289UL,1UL,4294967293UL,0x6E25D9C9L,0x6E25D9C9L,4294967293UL,1UL,4294967289UL},{0x5408F6A8L,4294967292UL,3UL,0x5408F6A8L,0x6E4C45B6L,0x6E4C45B6L,0x5408F6A8L,3UL,4294967292UL},{4294967293UL,4294967289UL,1UL,4294967293UL,0x6E25D9C9L,0x6E25D9C9L,4294967293UL,1UL,4294967289UL},{0x5408F6A8L,4294967292UL,3UL,0x5408F6A8L,0x6E4C45B6L,0x6E4C45B6L,0x5408F6A8L,3UL,4294967292UL}};
                        int i, j;
                        (*p_37) = (*l_1732);
                        if (l_2483[0][1])
                            continue;
                        return p_36;
                    }
                    if (g_93.f3)
                        goto lbl_2484;
                    for (g_384.f4 = 0; (g_384.f4 <= 1); g_384.f4 += 1)
                    { /* block id: 1144 */
                        const struct S1 **l_2485 = (void*)0;
                        const struct S1 *l_2487 = &g_2488;
                        const struct S1 **l_2486 = &l_2487;
                        const struct S1 *l_2490 = &g_2491;
                        const struct S1 **l_2489 = &l_2490;
                        (*l_2489) = ((*l_2486) = (*g_1752));
                        return p_36;
                    }
                }
            }
            else
            { /* block id: 1150 */
                uint64_t l_2493 = 0x2286A3204EFEECC2LL;
                int8_t *l_2496[7];
                int32_t l_2511 = 9L;
                struct S0 *****l_2512 = &g_2240;
                int i;
                for (i = 0; i < 7; i++)
                    l_2496[i] = &g_859.f3;
                if ((*l_1732))
                    break;
                (*l_1732) = (!(((*l_1732) ^ (g_1695[0][6] = ((l_2493 < ((((safe_mod_func_uint8_t_u_u(((l_2351[1][7] = p_36) <= (***g_1824)), ((safe_rshift_func_int16_t_s_u(((((safe_rshift_func_uint16_t_u_s(((***l_2290) &= (safe_add_func_int64_t_s_s((((((l_2275 = p_36) , (((safe_sub_func_int8_t_s_s(((safe_sub_func_uint8_t_u_u(p_36, (p_36 < ((((safe_mod_func_int32_t_s_s(((g_371.f3 <= (safe_mod_func_int16_t_s_s(0x9D32L, (*l_1732)))) < p_36), l_2203)) || 0x7AB0E018L) <= 0x04L) , (-3L))))) , p_36), p_36)) , 0xB3L) , l_2511)) <= 0xAF774C98L) <= p_36) , 0x33F18DFF73FE5DD4LL), (*l_1732)))), g_139)) , l_2512) != &g_2240) > p_36), p_36)) || l_2513))) && 255UL) || (***g_706)) > (*l_1732))) == p_36))) & 0xEBL));
            }
        }
        for (p_36 = (-7); (p_36 != 10); ++p_36)
        { /* block id: 1161 */
            for (g_384.f3 = (-12); (g_384.f3 >= 48); g_384.f3++)
            { /* block id: 1164 */
                if (l_2001)
                    goto lbl_2484;
            }
        }
    }
    return p_36;
}


/* ------------------------------------------ */
/* 
 * reads : g_723.f2 g_706 g_707 g_483 g_223 g_380.f4 g_97 g_387.f3 g_1119 g_792 g_426 g_285 g_372.f3 g_226.f9 g_142 g_171 g_108 g_107 g_102 g_20 g_586.f2 g_1013.f4 g_389.f5 g_868 g_77 g_802.f0 g_801 g_793 g_794.f7 g_381.f5 g_109 g_389.f0 g_1282 g_12 g_388.f2 g_1301 g_794.f6 g_381.f3 g_586.f3 g_532 g_1356 g_369.f5 g_798.f5 g_1436 g_93.f3 g_93.f1 g_802.f7 g_859.f0 g_124 g_387.f2 g_1470 g_1472 g_1492 g_366.f5 g_1498 g_796.f6 g_371.f4 g_794.f5 g_859.f3 g_375.f5 g_505 g_1435 g_387.f5 g_1434 g_1546 g_389.f2 g_369.f2 g_380.f0 g_859.f5 g_7 g_1639 g_797.f3 g_374.f3 g_1411.f6 g_686 g_687 g_1695 g_797.f7 g_384.f2 g_145
 * writes: g_384.f2 g_12 g_723.f2 g_380.f5 g_372.f5 g_382.f3 g_208 g_145 g_586.f2 g_285 g_372.f3 g_142 g_97 g_859.f3 g_1099.f0 g_1185 g_794.f7 g_381.f5 g_1258 g_389.f0 g_223 g_380.f4 g_388.f2 g_1301 g_139 g_532 g_20 g_1434 g_387.f2 g_171 g_366.f5 g_505 g_793 g_1546 g_389.f2 g_318 g_369.f2 g_380.f0 g_859.f5 g_384.f5 g_1527 g_374.f3 g_370.f3 g_102
 */
static int32_t * func_40(int32_t ** const  p_41)
{ /* block id: 583 */
    struct S0 *l_1097[2][3] = {{&g_1098,&g_1100,&g_1100},{&g_1098,&g_1100,&g_1100}};
    const struct S2 l_1101 = {0x75L,7,-1L,0x3CL,-1L,1UL};
    int32_t *l_1104 = &g_97;
    int32_t l_1106 = (-1L);
    int32_t l_1110[7] = {0x357A1ACDL,0L,0L,0x357A1ACDL,0L,0L,0x357A1ACDL};
    int8_t l_1111 = (-9L);
    uint32_t l_1236 = 0UL;
    int8_t l_1297 = (-10L);
    int16_t l_1299[9][5] = {{1L,0L,0x2428L,0L,9L},{0x81F4L,1L,0x7F7BL,0x82EFL,0x7F7BL},{0x82EFL,0x82EFL,9L,0L,0x2428L},{0L,0xB344L,9L,0xC3F5L,0x81F4L},{0xBE95L,9L,0x7F7BL,9L,0xBE95L},{0L,0xB344L,0x2428L,0xBE95L,0x82EFL},{0L,0x82EFL,0x81F4L,0L,0L},{0xBE95L,1L,0xBE95L,0xB344L,9L},{0xBE95L,0x81F4L,9L,1L,0L}};
    int8_t l_1322 = 1L;
    uint16_t l_1374 = 65528UL;
    int8_t * const l_1526 = &g_1527[1][1];
    int8_t * const *l_1525 = &l_1526;
    int8_t * const *l_1528 = &l_1526;
    const int32_t *l_1683 = (void*)0;
    uint16_t **l_1689 = (void*)0;
    uint16_t ***l_1690 = (void*)0;
    uint16_t ***l_1691 = &l_1689;
    uint16_t **l_1692 = &g_426[2];
    struct S2 * const *l_1696[4][6][5] = {{{(void*)0,&g_868,(void*)0,&g_868,(void*)0},{&g_868,&g_868,(void*)0,(void*)0,&g_868},{&g_868,&g_868,(void*)0,(void*)0,&g_868},{(void*)0,&g_868,(void*)0,&g_868,(void*)0},{&g_868,&g_868,(void*)0,&g_868,&g_868},{&g_868,(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,&g_868,&g_868},{(void*)0,&g_868,(void*)0,(void*)0,&g_868},{(void*)0,&g_868,(void*)0,&g_868,(void*)0},{(void*)0,&g_868,(void*)0,&g_868,(void*)0},{&g_868,&g_868,(void*)0,(void*)0,&g_868},{&g_868,&g_868,(void*)0,(void*)0,&g_868}},{{(void*)0,&g_868,(void*)0,&g_868,(void*)0},{&g_868,&g_868,(void*)0,&g_868,&g_868},{&g_868,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_868,&g_868},{(void*)0,&g_868,(void*)0,(void*)0,&g_868},{(void*)0,&g_868,(void*)0,&g_868,(void*)0}},{{(void*)0,&g_868,(void*)0,&g_868,(void*)0},{&g_868,&g_868,(void*)0,(void*)0,&g_868},{&g_868,&g_868,(void*)0,(void*)0,&g_868},{(void*)0,&g_868,(void*)0,&g_868,(void*)0},{&g_868,&g_868,(void*)0,&g_868,&g_868},{&g_868,(void*)0,(void*)0,(void*)0,(void*)0}}};
    int32_t *l_1697 = &g_102;
    uint64_t *l_1700[7] = {&g_385.f0,&g_385.f0,&g_385.f0,&g_385.f0,&g_385.f0,&g_385.f0,&g_385.f0};
    int32_t *l_1701 = &g_386.f2;
    int i, j, k;
    if ((l_1097[1][2] == (l_1101 , l_1097[1][2])))
    { /* block id: 584 */
        int32_t *l_1107 = (void*)0;
        int32_t *l_1108 = &g_723.f2;
        int32_t *l_1109[4];
        uint8_t l_1112 = 4UL;
        int8_t *l_1117 = &g_859.f3;
        volatile int64_t * const  volatile * volatile ** volatile *l_1125 = (void*)0;
        int64_t **l_1157[1][3][5];
        int64_t ***l_1156 = &l_1157[0][2][1];
        int64_t ****l_1155 = &l_1156;
        int32_t l_1280[7] = {0x95E3746DL,0x95E3746DL,(-1L),0x95E3746DL,0x95E3746DL,(-1L),0x95E3746DL};
        int64_t l_1291 = 0xACAD0F26CB16ECD9LL;
        struct S0 **l_1337 = &l_1097[1][0];
        uint32_t l_1378 = 0xAB113812L;
        const int32_t l_1402 = 1L;
        uint8_t **l_1419 = &g_483;
        uint8_t ***l_1418 = &l_1419;
        uint8_t ****l_1417 = &l_1418;
        int8_t l_1469 = 0x58L;
        uint16_t l_1588 = 0xF9A5L;
        int16_t l_1607 = 0L;
        uint32_t l_1608 = 0x128C9EDEL;
        uint64_t l_1615 = 0x2B6808F7543ADA2BLL;
        int i, j, k;
        for (i = 0; i < 4; i++)
            l_1109[i] = &g_369.f2;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 3; j++)
            {
                for (k = 0; k < 5; k++)
                    l_1157[i][j][k] = &g_208[3][3][9];
            }
        }
lbl_1220:
        for (g_384.f2 = 0; (g_384.f2 == (-10)); --g_384.f2)
        { /* block id: 587 */
            int32_t **l_1105 = &g_12;
            (*l_1105) = l_1104;
        }
        l_1112--;
        if ((*l_1108))
        { /* block id: 591 */
            int8_t *l_1118 = &g_150;
            int64_t * const ***l_1128 = (void*)0;
            (*l_1108) |= (((***g_706) > 0xEBL) | ((safe_mod_func_int16_t_s_s(1L, (*l_1104))) | ((g_387.f3 , 65533UL) ^ (l_1117 != l_1118))));
            l_1125 = g_1119;
            if ((safe_lshift_func_uint16_t_u_s(((void*)0 == l_1128), 2)))
            { /* block id: 594 */
                for (g_380.f5 = 0; g_380.f5 < 5; g_380.f5 += 1)
                {
                    for (g_372.f5 = 0; g_372.f5 < 4; g_372.f5 += 1)
                    {
                        for (g_382.f3 = 0; g_382.f3 < 10; g_382.f3 += 1)
                        {
                            g_208[g_380.f5][g_372.f5][g_382.f3] = &g_754;
                        }
                    }
                }
            }
            else
            { /* block id: 596 */
                return &g_104;
            }
        }
        else
        { /* block id: 599 */
            uint8_t l_1159 = 7UL;
            int32_t l_1163[10][9] = {{0x3E81E429L,(-4L),0x98DFE927L,0x3E81E429L,0x98DFE927L,(-4L),0x3E81E429L,0L,0L},{0x3E81E429L,(-4L),0x98DFE927L,0x3E81E429L,0x98DFE927L,(-4L),0x3E81E429L,0L,0L},{0x3E81E429L,(-4L),0x98DFE927L,0x3E81E429L,0x98DFE927L,(-4L),0x3E81E429L,0L,0L},{0x3E81E429L,(-4L),0x98DFE927L,0x3E81E429L,0x98DFE927L,(-4L),0x3E81E429L,0L,0L},{0x3E81E429L,(-4L),0x98DFE927L,0x3E81E429L,0x98DFE927L,(-4L),0x3E81E429L,0L,0L},{0x3E81E429L,(-4L),0x98DFE927L,0x3E81E429L,0x98DFE927L,0x6F0F7570L,0L,0L,0L},{0L,0x6F0F7570L,0xA881236AL,0L,0xA881236AL,0x6F0F7570L,0L,0L,0L},{0L,0x6F0F7570L,0xA881236AL,0L,0xA881236AL,0x6F0F7570L,0L,0L,0L},{0L,0x6F0F7570L,0xA881236AL,0L,0xA881236AL,0x6F0F7570L,0L,0L,0L},{0L,0x6F0F7570L,0xA881236AL,0L,0xA881236AL,0x6F0F7570L,0L,0L,0L}};
            uint64_t l_1180 = 0xBB42FF84D128D700LL;
            uint32_t *l_1257 = (void*)0;
            uint16_t l_1278 = 1UL;
            const int32_t l_1279 = 5L;
            int32_t l_1300 = 0L;
            struct S2 *l_1312[6][7] = {{&g_859,(void*)0,&g_859,&g_1013,&g_1013,&g_1013,&g_859},{&g_859,&g_859,&g_1013,&g_1013,&g_1013,&g_859,&g_859},{&g_859,(void*)0,&g_859,(void*)0,&g_859,&g_859,&g_859},{&g_1013,&g_1013,&g_1013,&g_1013,&g_1013,&g_1013,&g_1013},{&g_859,&g_1013,&g_859,&g_859,&g_1013,(void*)0,&g_1013},{&g_1013,&g_1013,&g_1013,&g_1013,&g_1013,&g_1013,&g_1013}};
            int32_t l_1320 = 1L;
            int16_t l_1368[5];
            uint32_t l_1369[1];
            uint16_t l_1425 = 65535UL;
            const uint32_t l_1428 = 0x8524FCAEL;
            int64_t l_1451 = 0x86B82B02BF4951FCLL;
            int32_t l_1468 = (-4L);
            const struct S2 *****l_1473 = (void*)0;
            struct S2 ** const **l_1475 = (void*)0;
            struct S2 ** const ***l_1474 = &l_1475;
            struct S0 **l_1533 = &l_1097[1][0];
            int32_t *l_1547 = &g_389.f2;
            uint32_t l_1566[1];
            uint16_t l_1603 = 65535UL;
            struct S0 ***l_1637[5];
            uint32_t l_1648 = 0xC9593710L;
            uint8_t **l_1671 = &g_483;
            int i, j;
            for (i = 0; i < 5; i++)
                l_1368[i] = (-9L);
            for (i = 0; i < 1; i++)
                l_1369[i] = 0xF9F23B8CL;
            for (i = 0; i < 1; i++)
                l_1566[i] = 0xEB98ED59L;
            for (i = 0; i < 5; i++)
                l_1637[i] = &l_1533;
            for (g_145 = 0; (g_145 <= (-8)); --g_145)
            { /* block id: 602 */
                uint32_t l_1148 = 18446744073709551607UL;
                int32_t l_1164 = 1L;
                int32_t l_1168 = 0xEFBBF9A7L;
                int32_t l_1169 = (-3L);
                int32_t l_1171 = 0x44957B87L;
                int32_t l_1172 = 0xF4754032L;
                int32_t l_1173 = 0xA6C4FF87L;
                int32_t l_1174[4] = {0L,0L,0L,0L};
                int32_t l_1196 = 0x3E887A92L;
                struct S2 * const *l_1205 = &g_868;
                uint32_t l_1215[7][8][4] = {{{1UL,1UL,6UL,7UL},{1UL,0x504FF749L,18446744073709551615UL,0x14709D1EL},{18446744073709551615UL,7UL,1UL,0UL},{0UL,0x2DFAA12BL,0UL,0UL},{0x46EF9104L,0x553DFA41L,18446744073709551606UL,0UL},{0UL,0xDF4A4AA1L,0UL,0xC38DF09AL},{8UL,0xF2F4435BL,0xC45BFD26L,0xE7DB8E5AL},{0x553DFA41L,0x430CB204L,8UL,1UL}},{{18446744073709551614UL,18446744073709551615UL,18446744073709551615UL,18446744073709551614UL},{0xDF4A4AA1L,18446744073709551606UL,1UL,0x430CB204L},{0x5C2656D4L,0xC38DF09AL,18446744073709551615UL,0x504FF749L},{6UL,0UL,18446744073709551615UL,0x504FF749L},{0x28A3C549L,0xC38DF09AL,0xF1C0F9EFL,0x430CB204L},{0xE7DB8E5AL,18446744073709551606UL,0x623942F4L,18446744073709551614UL},{9UL,18446744073709551615UL,0UL,1UL},{18446744073709551615UL,0x430CB204L,0xFC2A2BA9L,0xE7DB8E5AL}},{{18446744073709551615UL,0xF2F4435BL,0x491B2AADL,0xC38DF09AL},{0x2DFAA12BL,0xDF4A4AA1L,0x46EF9104L,0UL},{0UL,0x553DFA41L,0x5C2656D4L,0UL},{4UL,0x2DFAA12BL,4UL,0UL},{0UL,7UL,0xC38DF09AL,0x14709D1EL},{0UL,0x504FF749L,1UL,7UL},{0UL,1UL,1UL,9UL},{0UL,8UL,0xC38DF09AL,0xFC2A2BA9L}},{{0UL,0UL,4UL,0xC45BFD26L},{4UL,0xC45BFD26L,0x5C2656D4L,18446744073709551615UL},{0UL,18446744073709551615UL,0x14709D1EL,7UL},{18446744073709551614UL,0UL,0x623942F4L,0UL},{6UL,0xC160B740L,0UL,0x14709D1EL},{0xC38DF09AL,0x3260ED5CL,0x5C2656D4L,0x5C2656D4L},{0x430CB204L,0x430CB204L,0UL,0x553DFA41L},{18446744073709551613UL,0UL,18446744073709551615UL,0xF1C0F9EFL}},{{18446744073709551615UL,0x28A3C549L,0x3260ED5CL,18446744073709551615UL},{0xC160B740L,0x28A3C549L,0xC38DF09AL,0xF1C0F9EFL},{0x28A3C549L,0UL,0xF2F4435BL,0x553DFA41L},{1UL,0x430CB204L,0UL,0x5C2656D4L},{0x46EF9104L,0x3260ED5CL,0xDF4A4AA1L,0x14709D1EL},{4UL,0xC160B740L,18446744073709551615UL,0UL},{0xDF4A4AA1L,0UL,0UL,7UL},{1UL,18446744073709551615UL,0xF1C0F9EFL,0UL}},{{0x14709D1EL,18446744073709551615UL,0UL,18446744073709551615UL},{0UL,0UL,0xE7DB8E5AL,0UL},{0UL,0x504FF749L,6UL,0x430CB204L},{0x553DFA41L,0xE7DB8E5AL,0xC160B740L,8UL},{0x553DFA41L,0UL,6UL,9UL},{0UL,8UL,0xE7DB8E5AL,1UL},{0UL,18446744073709551614UL,0UL,1UL},{0x14709D1EL,4UL,0xF1C0F9EFL,0UL}},{{1UL,1UL,0UL,0UL},{0xDF4A4AA1L,0xC45BFD26L,18446744073709551615UL,18446744073709551613UL},{4UL,8UL,0xDF4A4AA1L,0xF2F4435BL},{0x46EF9104L,0UL,0UL,0x46EF9104L},{1UL,0xF1C0F9EFL,0xF2F4435BL,8UL},{0x28A3C549L,0UL,0xC38DF09AL,0UL},{0xC160B740L,1UL,0x3260ED5CL,0UL},{18446744073709551615UL,0UL,18446744073709551615UL,8UL}}};
                const int16_t l_1218 = (-1L);
                int i, j, k;
                for (g_586.f2 = 3; (g_586.f2 >= 0); g_586.f2 -= 1)
                { /* block id: 605 */
                    int16_t *l_1135 = &g_142;
                    const struct S2 l_1161 = {0xE0L,3,1L,0xB9L,0x1DL,2UL};
                    int32_t l_1165 = 1L;
                    int32_t l_1167 = 0x7FB2657EL;
                    int32_t l_1170 = 0L;
                    int32_t l_1175 = 1L;
                    int32_t l_1176 = 5L;
                    int32_t l_1178 = (-1L);
                    int32_t l_1179 = 0x1E86F5E1L;
                    int32_t l_1191 = 0xD983CF35L;
                    int32_t l_1192 = 4L;
                    int32_t l_1193 = (-5L);
                    int32_t l_1194 = (-1L);
                    int32_t l_1197 = 1L;
                    int32_t l_1199 = 0x30376CB5L;
                    int32_t l_1200 = (-1L);
                    int32_t l_1235[2];
                    int i;
                    for (i = 0; i < 2; i++)
                        l_1235[i] = 8L;
                    (*l_1104) ^= (safe_mod_func_uint16_t_u_u(((**g_792)--), ((*l_1135) &= g_226.f9)));
                    if ((*g_171))
                    { /* block id: 609 */
                        const struct S2 *l_1137 = (void*)0;
                        const struct S2 **l_1136 = &l_1137;
                        uint64_t *l_1160 = &g_1099.f0;
                        int32_t l_1162 = 1L;
                        int32_t l_1166 = (-1L);
                        int32_t l_1177 = 0x97C4FFC4L;
                        int i;
                        (*l_1136) = &l_1101;
                        l_1109[g_586.f2] = &g_20;
                        (*l_1108) = ((safe_lshift_func_uint16_t_u_u((+(*l_1104)), 9)) , (g_1013.f4 > (0xFB757B79E7033EDDLL > (safe_div_func_uint16_t_u_u(0xDCFEL, (((+4294967290UL) && (l_1162 = ((safe_mod_func_int8_t_s_s((-6L), (((safe_add_func_uint64_t_u_u(l_1148, ((*l_1160) = ((safe_add_func_int8_t_s_s((((safe_add_func_int64_t_s_s((((((safe_mul_func_uint16_t_u_u((l_1155 != (((**g_792) = (((*l_1117) = ((((safe_unary_minus_func_uint16_t_u((**g_792))) != (-4L)) , l_1159) > 0xB4E844F01DDC3C0DLL)) >= 0x14L)) , &g_725)), (*l_1104))) != 0xBAC32266L) && (*g_171)) , 0x9CL) > l_1159), l_1148)) != 4L) , (*l_1104)), (*g_483))) <= (*l_1108))))) , l_1161) , 253UL))) < (-7L)))) & 1L))))));
                        ++l_1180;
                    }
                    else
                    { /* block id: 618 */
                        uint8_t * volatile ***l_1184[7][2] = {{&g_706,&g_706},{&g_706,&g_706},{&g_706,&g_706},{&g_706,&g_706},{&g_706,&g_706},{&g_706,&g_706},{&g_706,&g_706}};
                        uint8_t * volatile ****l_1183[3];
                        int32_t l_1186 = (-1L);
                        int32_t l_1187 = 1L;
                        int32_t l_1188 = 0xED1596D3L;
                        int32_t l_1189 = 0x9E9CC67AL;
                        int32_t l_1190 = 0x78AE32E6L;
                        int32_t l_1195 = 0x07B3B537L;
                        int32_t l_1198[1][2];
                        uint16_t l_1202 = 0x5E98L;
                        int i, j;
                        for (i = 0; i < 3; i++)
                            l_1183[i] = &l_1184[2][1];
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 2; j++)
                                l_1198[i][j] = 1L;
                        }
                        g_1185[0] = &g_706;
                        l_1202--;
                    }
                    if (((*l_1104) = (((l_1205 == (void*)0) >= (((+(safe_sub_func_uint32_t_u_u(l_1174[0], (l_1161 , 0x95D6193EL)))) , ((safe_mul_func_uint8_t_u_u((*l_1104), (!((*l_1108) , l_1168)))) & l_1168)) >= g_389.f5)) > (*g_171))))
                    { /* block id: 623 */
                        int16_t l_1214 = 0x0A5BL;
                        const struct S0 **l_1219 = (void*)0;
                        l_1164 |= (safe_lshift_func_int16_t_s_u((l_1214 != (***g_706)), (l_1215[2][7][0] || ((((safe_rshift_func_int16_t_s_s(((((*l_1104) , (*l_1205)) != &l_1161) == (l_1214 , l_1218)), ((l_1180 , (void*)0) == l_1219))) , g_77[9]) || 65530UL) | 9UL))));
                        (*l_1108) &= 0x278902DDL;
                    }
                    else
                    { /* block id: 626 */
                        int64_t ****l_1221 = (void*)0;
                        int64_t *****l_1222 = &l_1221;
                        int32_t l_1225[5][9] = {{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{9L,9L,9L,9L,9L,9L,9L,9L,9L},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{9L,9L,9L,9L,9L,9L,9L,9L,9L},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}};
                        int i, j;
                        if (l_1161.f2)
                            goto lbl_1220;
                        (*l_1222) = l_1221;
                        (*l_1108) ^= ((&g_316 == (void*)0) >= (safe_sub_func_int64_t_s_s(l_1225[2][1], ((((g_802.f0 || (safe_unary_minus_func_int16_t_s((g_801 != g_793[3][0])))) , (safe_mul_func_uint16_t_u_u((safe_sub_func_uint64_t_u_u(9UL, (*l_1104))), (safe_mul_func_int8_t_s_s((safe_add_func_int64_t_s_s(l_1225[4][0], (*l_1104))), l_1225[1][5]))))) & (*g_483)) != l_1165))));
                        ++l_1236;
                    }
                    (*l_1104) |= (0x0FL != l_1169);
                }
            }
            if (((*l_1104) = (g_794[8].f7 &= ((*l_1104) || (((safe_unary_minus_func_uint16_t_u((*l_1104))) < (*l_1104)) , (safe_rshift_func_int8_t_s_u((safe_lshift_func_uint8_t_u_s((*l_1104), (safe_sub_func_uint64_t_u_u(l_1163[4][4], (safe_add_func_uint64_t_u_u(l_1163[4][4], (*l_1108))))))), 1)))))))
            { /* block id: 637 */
                const uint32_t l_1281 = 18446744073709551615UL;
                int32_t l_1286 = (-1L);
                int32_t l_1287 = (-7L);
                int32_t l_1288 = 0x3713BAE3L;
                int32_t l_1289 = 1L;
                int32_t l_1290 = 0x3557E23FL;
                int32_t l_1292 = 1L;
                int32_t l_1293[6][10][4] = {{{0xA0649053L,0x4DC94B85L,0xD1AC25EEL,(-1L)},{0x2F517EBCL,0x3429BC3BL,0x19D4C9FEL,0xA0649053L},{(-2L),(-1L),(-2L),0L},{1L,0L,0x4DC94B85L,0x2ADD500AL},{0L,0L,0x8CE70544L,0L},{(-10L),(-8L),0x8CE70544L,(-1L)},{0L,0x19D4C9FEL,0x4DC94B85L,0L},{0L,0x8CE70544L,0xEC643213L,0xD4D54CB7L},{0xEC643213L,0xD4D54CB7L,(-1L),(-1L)},{0x2ADD500AL,0x2ADD500AL,0xA0649053L,0x3429BC3BL}},{{(-8L),0L,1L,(-2L)},{0xEC643213L,0x3429BC3BL,0x8572A073L,1L},{0xD4D54CB7L,0x3429BC3BL,0x4DC94B85L,(-2L)},{0x3429BC3BL,0L,0xD1AC25EEL,0x3429BC3BL},{(-10L),0x2ADD500AL,0L,(-1L)},{4L,0xD4D54CB7L,0x4DC94B85L,0xD4D54CB7L},{0x19D4C9FEL,0x8CE70544L,(-10L),0L},{0xEC643213L,0x19D4C9FEL,(-6L),(-1L)},{(-2L),(-8L),0xA0649053L,0L},{(-2L),0L,(-6L),0x2ADD500AL}},{{0xEC643213L,0L,(-10L),1L},{0x19D4C9FEL,4L,0x4DC94B85L,(-8L)},{4L,0L,0L,4L},{(-10L),(-2L),0xD1AC25EEL,(-1L)},{0x3429BC3BL,0L,0x4DC94B85L,0x19D4C9FEL},{0xD4D54CB7L,0x8CE70544L,0x8572A073L,0x19D4C9FEL},{0xEC643213L,0L,1L,(-1L)},{(-8L),(-2L),0xA0649053L,4L},{0x2ADD500AL,0L,(-1L),(-8L)},{0xEC643213L,4L,0xEC643213L,1L}},{{0L,0L,0x4DC94B85L,0x2ADD500AL},{0L,0L,0x8CE70544L,0L},{(-10L),(-8L),0x8CE70544L,(-1L)},{0L,0x19D4C9FEL,0x4DC94B85L,0L},{0L,0x8CE70544L,0xEC643213L,0xD4D54CB7L},{0xEC643213L,0xD4D54CB7L,(-1L),(-1L)},{0x2ADD500AL,0x2ADD500AL,0xA0649053L,0x3429BC3BL},{(-8L),0L,1L,(-2L)},{0xEC643213L,0x3429BC3BL,0x8572A073L,1L},{0xD4D54CB7L,0x3429BC3BL,0x4DC94B85L,(-2L)}},{{0x3429BC3BL,0L,0xD1AC25EEL,0x3429BC3BL},{(-10L),0x2ADD500AL,0L,(-1L)},{4L,0xD4D54CB7L,0x4DC94B85L,0xD4D54CB7L},{0x19D4C9FEL,0x8CE70544L,(-10L),0L},{0xEC643213L,0x19D4C9FEL,(-6L),(-1L)},{(-2L),(-8L),0xA0649053L,0L},{(-2L),0L,(-6L),0x2ADD500AL},{0xEC643213L,0L,(-10L),1L},{0x19D4C9FEL,4L,0x4DC94B85L,(-8L)},{4L,0L,0L,4L}},{{(-10L),(-2L),0xD1AC25EEL,(-1L)},{0L,1L,(-2L),(-1L)},{(-6L),0x4DC94B85L,0x35A5FA0EL,(-1L)},{0xD38BB50DL,1L,0L,(-1L)},{(-10L),0xEC643213L,(-8L),0xD1AC25EEL},{0x8572A073L,0x2F517EBCL,(-1L),(-10L)},{0xD38BB50DL,0xD1AC25EEL,0xD38BB50DL,0L},{1L,0x8CE70544L,(-2L),0x8572A073L},{0x8CE70544L,0x2F517EBCL,0x4DC94B85L,0x8CE70544L},{1L,(-10L),0x4DC94B85L,(-1L)}}};
                int8_t l_1294 = 1L;
                int32_t l_1295 = 0x33AE15F0L;
                int64_t l_1296 = (-10L);
                int8_t l_1298[6] = {1L,1L,1L,1L,1L,1L};
                int16_t *l_1318 = &g_139;
                uint16_t *l_1319[1];
                uint64_t **l_1321 = &g_318;
                struct S2 l_1323 = {0xA7L,2,0x17FDED2CL,0xA5L,0x94L,5UL};
                struct S0 **l_1336 = &l_1097[1][1];
                int32_t l_1366 = 0xBDAC09CBL;
                int8_t **l_1440 = &g_887[3];
                const int32_t **l_1467 = &g_171;
                const int32_t *** const l_1466 = &l_1467;
                const int32_t *** const *l_1465 = &l_1466;
                int8_t l_1509 = 0x38L;
                int i, j, k;
                for (i = 0; i < 1; i++)
                    l_1319[i] = &g_385.f3;
                for (g_381.f5 = 2; (g_381.f5 <= 23); g_381.f5++)
                { /* block id: 640 */
                    int16_t *l_1252[1];
                    uint32_t *l_1256 = &g_238[2][3][0];
                    uint32_t **l_1255 = &l_1256;
                    uint64_t *l_1263[8] = {&g_376.f0,&g_376.f0,&g_376.f0,&g_376.f0,&g_376.f0,&g_376.f0,&g_376.f0,&g_376.f0};
                    struct S1 *l_1268[3][4] = {{(void*)0,&g_1270,(void*)0,(void*)0},{&g_1270,&g_1270,&g_1269,&g_1270},{&g_1270,(void*)0,(void*)0,&g_1270}};
                    int32_t l_1275[6][4][3] = {{{1L,0xB9F845FFL,0xCAC15D95L},{0xCAC15D95L,0x8BA0C306L,0x77B1E740L},{0x323075DAL,0x8BA0C306L,0x323075DAL},{7L,0xB9F845FFL,2L}},{{0x788CDBD1L,(-3L),0xB9F845FFL},{(-7L),0xCAC15D95L,2L},{0xCAC15D95L,0x94FA40BCL,(-4L)},{(-7L),0L,0x323075DAL}},{{0x788CDBD1L,2L,0x5B56BC46L},{7L,(-3L),5L},{0x323075DAL,5L,5L},{0xCAC15D95L,(-1L),0x5B56BC46L}},{{1L,0L,0x323075DAL},{0xAFE9847CL,0x98243D8CL,(-4L)},{(-8L),(-3L),2L},{0x2F595361L,0x98243D8CL,0xB9F845FFL}},{{0xCAC15D95L,0L,2L},{(-2L),(-1L),0x323075DAL},{(-3L),5L,0x77B1E740L},{(-3L),(-3L),0xCAC15D95L}},{{(-2L),2L,0x98243D8CL},{0xCAC15D95L,0L,0x70EB00FDL},{0x2F595361L,0x94FA40BCL,0x323075DAL},{(-8L),0xCAC15D95L,0x70EB00FDL}}};
                    uint8_t *l_1276 = (void*)0;
                    uint8_t *l_1277[4];
                    int i, j, k;
                    for (i = 0; i < 1; i++)
                        l_1252[i] = &g_142;
                    for (i = 0; i < 4; i++)
                        l_1277[i] = (void*)0;
                    if ((safe_div_func_int32_t_s_s((((l_1163[7][4] = (*l_1104)) , (safe_lshift_func_int8_t_s_u((((((*l_1255) = &g_192) == (g_1258[1] = l_1257)) <= (safe_mod_func_uint64_t_u_u(g_109, 18446744073709551610UL))) | ((safe_mod_func_int64_t_s_s(((--g_389.f0) , (((safe_mod_func_uint16_t_u_u((l_1268[2][0] != (void*)0), (((+18446744073709551615UL) != (l_1278 = ((*g_483) = ((safe_rshift_func_int16_t_s_u((9UL | 65528UL), l_1275[2][1][2])) ^ (*g_171))))) || l_1275[2][1][2]))) >= (*l_1104)) | l_1279)), l_1280[2])) && l_1281)), 7))) , (*l_1108)), (*g_171))))
                    { /* block id: 647 */
                        int32_t **l_1283 = &g_12;
                        (*l_1104) &= ((*l_1108) = (*g_171));
                        (*l_1283) = g_1282[0];
                        (**l_1283) ^= ((safe_rshift_func_int8_t_s_u((*l_1108), ((*l_1104) > l_1159))) >= (1UL && 0UL));
                    }
                    else
                    { /* block id: 652 */
                        if ((*l_1104))
                            break;
                        return l_1107;
                    }
                    return &g_103;
                }
                --g_1301[0][1];
                if ((safe_sub_func_uint16_t_u_u((safe_mul_func_int16_t_s_s((((((*g_483) ^= (((1UL && ((safe_rshift_func_uint8_t_u_s(((l_1163[4][4] ^= (((**g_792) != g_794[8].f6) < (*l_1104))) , ((void*)0 == l_1312[2][3])), 0)) >= (l_1289 = (l_1322 = (l_1286 &= (((((l_1320 |= (l_1288 >= (!(((*l_1318) = (safe_sub_func_uint16_t_u_u(((0xAAL || ((safe_mul_func_uint8_t_u_u(l_1293[1][7][1], l_1279)) | 1UL)) , (*l_1108)), (*l_1104)))) & 65535UL)))) , l_1321) != &g_316) | (*l_1108)) , 0x5DE3L)))))) | l_1159) <= (**g_792))) , l_1180) != l_1292) ^ l_1298[0]), 0xA372L)), (-1L))))
                { /* block id: 666 */
                    int64_t l_1331 = 3L;
                    int32_t l_1338 = 0x581E936FL;
                    int32_t l_1360 = 1L;
                    int32_t l_1361 = 0xCBA5ADC2L;
                    int32_t l_1365[9][5] = {{0x81FC3C10L,0xDCCBB1C8L,0xC7C8CB00L,0x8B3F1A36L,0xAAC1FCB5L},{0x20C822EFL,(-3L),(-3L),0x20C822EFL,0xEF08549DL},{1L,0x20C822EFL,0xC7C8CB00L,0xAAC1FCB5L,0xDCCBB1C8L},{1L,0xC7C8CB00L,0xEF08549DL,0xC7C8CB00L,1L},{0x20C822EFL,0x8B3F1A36L,0x81FC3C10L,0xAAC1FCB5L,(-3L)},{0x81FC3C10L,0x8B3F1A36L,0x20C822EFL,0x20C822EFL,0x8B3F1A36L},{0xEF08549DL,0xC7C8CB00L,1L,0x8B3F1A36L,(-3L)},{0xC7C8CB00L,0x20C822EFL,1L,0x1FC496F8L,1L},{(-3L),(-3L),0x20C822EFL,0xEF08549DL,0xDCCBB1C8L}};
                    int32_t *l_1373 = &g_104;
                    int i, j;
                    if (((l_1323 , (((*g_483) <= (safe_add_func_int16_t_s_s((((((l_1338 = ((l_1278 ^ (~(safe_mul_func_uint16_t_u_u(0xFFF3L, 0x9FC0L)))) || (((((**g_792) = l_1331) ^ ((safe_mod_func_uint16_t_u_u((safe_sub_func_int16_t_s_s((*l_1104), (l_1336 != l_1337))), l_1278)) != l_1331)) , 5UL) < g_381.f3))) | g_586.f3) , &l_1338) != &l_1292) != l_1292), l_1278))) <= l_1163[4][4])) & l_1294))
                    { /* block id: 669 */
                        int32_t l_1341[4];
                        uint32_t *l_1349 = &g_532;
                        int i;
                        for (i = 0; i < 4; i++)
                            l_1341[i] = 4L;
                        (*l_1108) = ((l_1163[8][4] | l_1159) , (l_1331 , ((*l_1104) = (safe_add_func_int32_t_s_s(l_1341[1], ((safe_rshift_func_uint8_t_u_s((4294967295UL > (safe_unary_minus_func_uint32_t_u(((0x4AFEL & ((safe_rshift_func_uint8_t_u_u((safe_add_func_int32_t_s_s((l_1159 >= ((*l_1349)--)), ((safe_mul_func_int16_t_s_s((((safe_add_func_int16_t_s_s(l_1298[4], (((0x3210F35CB10833BCLL != l_1331) , l_1294) | l_1331))) <= l_1320) != l_1163[4][4]), l_1293[2][4][0])) < l_1331))), 4)) >= (-8L))) ^ l_1341[1])))), l_1331)) | l_1338))))));
                        return g_1356[4];
                    }
                    else
                    { /* block id: 674 */
                        int8_t l_1357 = 0x63L;
                        int32_t l_1358 = 0x0D8A83DFL;
                        int32_t l_1359 = 0x48872657L;
                        int32_t l_1362 = 0xEC00CC8FL;
                        int32_t l_1363 = (-1L);
                        int32_t l_1364 = 3L;
                        int32_t l_1367 = 2L;
                        int32_t **l_1372[7][9][4] = {{{&l_1108,&l_1109[1],&g_12,&g_1282[1]},{&l_1109[1],&l_1109[0],&g_1356[4],&g_1282[0]},{&l_1109[1],(void*)0,&g_12,(void*)0},{&l_1109[2],(void*)0,&g_1356[7],&l_1104},{&l_1104,&g_12,&l_1109[0],&l_1107},{(void*)0,(void*)0,&g_1356[4],&l_1109[1]},{&g_1282[0],&l_1108,&g_1356[4],&l_1104},{(void*)0,&l_1104,&l_1109[1],&g_1282[1]},{&g_12,&g_1356[4],&g_1356[7],&l_1104}},{{&g_12,(void*)0,&g_1356[3],&g_1356[3]},{&g_12,&g_12,&l_1109[1],&l_1109[1]},{(void*)0,&l_1104,&g_12,&g_1282[3]},{&g_1282[0],(void*)0,&g_12,&g_12},{&g_12,(void*)0,&l_1109[0],&g_1282[3]},{(void*)0,&l_1104,(void*)0,&l_1109[1]},{&l_1109[2],&g_12,&g_1356[4],&g_1356[3]},{(void*)0,(void*)0,(void*)0,&l_1104},{&g_1282[1],&g_1356[4],&g_12,&g_1282[1]}},{{&l_1109[2],&l_1104,&g_1356[3],&l_1104},{&g_1282[3],&l_1108,&l_1109[0],&l_1109[1]},{&g_12,(void*)0,&l_1104,&l_1107},{&g_1282[0],&g_12,&g_1282[0],&l_1104},{&g_1282[1],(void*)0,&l_1109[1],(void*)0},{(void*)0,&g_1356[4],(void*)0,(void*)0},{&g_12,&l_1108,(void*)0,&g_1356[3]},{(void*)0,&g_12,&l_1109[1],&l_1107},{&g_1282[1],&l_1104,&g_1282[0],&l_1104}},{{&g_1282[0],&l_1104,&l_1104,&g_12},{&g_12,&g_1282[3],&l_1109[0],(void*)0},{&g_1282[3],&l_1104,&g_1356[3],&l_1107},{&l_1109[2],(void*)0,&g_12,&g_1356[3]},{&g_1282[1],&g_12,(void*)0,&g_1282[3]},{(void*)0,&g_1356[4],&g_1356[4],(void*)0},{&l_1109[2],&g_1282[3],(void*)0,&l_1104},{(void*)0,(void*)0,&l_1109[0],&l_1107},{&g_12,(void*)0,&g_12,&l_1107}},{{&g_1282[0],(void*)0,&g_12,&l_1104},{(void*)0,&g_1282[3],&l_1109[1],(void*)0},{&g_12,&g_1356[4],&g_1356[3],&g_1282[3]},{&g_12,&g_12,&g_1356[7],&g_1356[3]},{&g_12,(void*)0,&l_1109[1],&l_1107},{(void*)0,&l_1104,&g_1356[4],(void*)0},{&g_1282[0],&g_1282[3],&g_1356[4],&g_12},{(void*)0,&l_1104,&l_1109[0],&l_1104},{&l_1104,&l_1104,&g_1356[7],&l_1107}},{{&l_1109[2],&g_12,&l_1104,&g_1356[3]},{(void*)0,&l_1108,(void*)0,(void*)0},{(void*)0,&g_1356[4],&l_1104,(void*)0},{&l_1109[2],(void*)0,&g_1356[7],&l_1104},{&l_1104,&g_12,&l_1109[0],&l_1107},{(void*)0,(void*)0,(void*)0,&l_1104},{&l_1109[1],&l_1109[2],&l_1109[0],&l_1109[1]},{(void*)0,&g_12,(void*)0,&g_1356[3]},{&l_1104,(void*)0,&l_1109[1],&g_12}},{{&g_1356[4],&l_1104,&l_1107,&l_1107},{&g_12,&g_12,(void*)0,&l_1104},{&g_1356[7],&g_1356[7],&g_1282[0],&g_1282[0]},{&l_1109[1],&g_1356[4],&g_1356[4],&g_1282[0]},{&l_1104,&g_1356[4],&l_1108,&g_1282[0]},{&g_1356[4],&g_1356[7],&l_1107,&l_1104},{&l_1104,&g_12,(void*)0,&l_1107},{(void*)0,&l_1104,&l_1107,&g_12},{&g_1356[3],(void*)0,&g_1356[4],&g_1356[3]}}};
                        int i, j, k;
                        l_1369[0]--;
                        l_1373 = &l_1364;
                        (*l_1108) ^= (*l_1104);
                    }
                    l_1374++;
                    for (g_20 = 0; (g_20 <= 0); g_20 += 1)
                    { /* block id: 682 */
                        int64_t l_1377 = (-1L);
                        l_1378--;
                    }
                    if (((*l_1108) = (*l_1108)))
                    { /* block id: 686 */
                        struct S2 *****l_1381 = (void*)0;
                        struct S2 ***l_1384[10][5] = {{&g_867[2],(void*)0,&g_867[2],(void*)0,&g_867[2]},{&g_867[2],&g_867[2],&g_867[2],&g_867[2],&g_867[2]},{&g_867[2],(void*)0,&g_867[2],(void*)0,&g_867[2]},{&g_867[2],&g_867[2],&g_867[2],&g_867[2],&g_867[2]},{&g_867[2],(void*)0,&g_867[2],(void*)0,&g_867[2]},{&g_867[2],&g_867[2],&g_867[2],&g_867[2],&g_867[2]},{&g_867[2],(void*)0,&g_867[2],(void*)0,&g_867[2]},{&g_867[2],&g_867[2],&g_867[2],&g_867[2],&g_867[2]},{&g_867[2],(void*)0,&g_867[2],(void*)0,&g_867[2]},{&g_867[2],&g_867[2],&g_867[2],&g_867[2],&g_867[2]}};
                        struct S2 *** const *l_1383 = &l_1384[7][4];
                        struct S2 *** const **l_1382 = &l_1383;
                        int i, j;
                        (*l_1382) = (void*)0;
                    }
                    else
                    { /* block id: 688 */
                        return &g_17;
                    }
                }
                else
                { /* block id: 691 */
                    uint16_t **l_1397 = &l_1319[0];
                    int8_t ***l_1401 = (void*)0;
                    int32_t l_1437 = 0x771E2AC7L;
                    int32_t *l_1438 = &l_1288;
                    if ((l_1110[1] ^= (((((safe_div_func_int64_t_s_s((0L || g_369.f5), (safe_add_func_uint8_t_u_u((~(l_1298[1] | (((((safe_mul_func_int8_t_s_s((safe_mul_func_int16_t_s_s(((((!l_1298[2]) , &l_1319[0]) == l_1397) & (!((safe_rshift_func_uint16_t_u_u((*l_1104), (((&g_686 == l_1401) ^ 0x25FAL) > (*l_1108)))) >= l_1296))), l_1402)), (***g_706))) > 0L) > l_1298[4]) | (*l_1108)) == 5L))), l_1296)))) | 5L) & 246UL) > 1UL) == 1UL)))
                    { /* block id: 693 */
                        struct S1 *l_1410 = &g_1411;
                        uint8_t **l_1416 = &g_483;
                        uint8_t ***l_1415 = &l_1416;
                        uint8_t ****l_1414 = &l_1415;
                        int32_t l_1422 = 1L;
                        volatile int64_t * const  volatile * volatile **l_1424[7] = {&g_1121,&g_1121,&g_1121,&g_1121,&g_1121,&g_1121,&g_1121};
                        volatile int64_t * const  volatile * volatile ***l_1423 = &l_1424[2];
                        int i;
                        (*l_1108) |= (~(((((**l_1416) = (safe_mod_func_int8_t_s_s((-6L), ((safe_div_func_int32_t_s_s(((safe_mod_func_int16_t_s_s(((((void*)0 != &l_1101) || l_1290) || (l_1410 == g_793[3][0])), (safe_mul_func_int8_t_s_s((l_1414 != l_1417), (safe_rshift_func_int8_t_s_s(0xB7L, 3)))))) < 1L), (*l_1104))) && l_1422)))) , (*l_1155)) == (void*)0) > (*l_1104)));
                        (*l_1423) = &g_1121;
                        l_1425--;
                    }
                    else
                    { /* block id: 698 */
                        uint64_t l_1429 = 1UL;
                        uint16_t l_1430[3];
                        struct S2 l_1431 = {0UL,0,3L,0L,0x70L,0xE1FCL};
                        const int8_t **l_1433 = (void*)0;
                        const int8_t ***l_1432[5];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_1430[i] = 4UL;
                        for (i = 0; i < 5; i++)
                            l_1432[i] = &l_1433;
                        l_1429 = l_1428;
                        (*l_1104) ^= l_1430[2];
                        (*l_1104) = (((l_1431 , l_1401) == (g_1434 = l_1432[4])) && l_1437);
                        l_1438 = (void*)0;
                    }
                }
                if ((~(((l_1368[0] > (l_1440 == &g_887[3])) , (*l_1104)) | (0UL | (safe_add_func_int8_t_s_s(((*g_171) , (safe_div_func_uint32_t_u_u((safe_div_func_uint32_t_u_u(l_1368[4], (safe_div_func_int16_t_s_s(((safe_mod_func_uint32_t_u_u(0xFD240CE1L, g_798.f5)) ^ (*g_1436)), g_93.f1)))), g_20))), 0x7CL))))))
                { /* block id: 706 */
                    uint32_t *l_1460[6];
                    int32_t l_1461 = 3L;
                    int32_t **l_1464 = &g_1356[4];
                    int32_t ***l_1463 = &l_1464;
                    const int32_t *l_1471 = &l_1293[1][9][1];
                    int i;
                    for (i = 0; i < 6; i++)
                        l_1460[i] = &g_532;
                    if ((l_1451 && (((safe_add_func_uint64_t_u_u((safe_mul_func_int8_t_s_s(((l_1288 = (l_1461 |= (safe_mul_func_uint16_t_u_u(((**g_792)--), g_802.f7)))) == ((!(((((((g_859.f0 , l_1463) == g_124) && 5UL) != ((l_1465 != (((l_1468 , ((*l_1104) , (**l_1464))) , 9L) , &l_1463)) , (*l_1104))) == (***l_1466)) , (***l_1463)) && (**l_1467))) & l_1469)), (*g_483))), (***l_1463))) == 0xC519L) != g_1470)))
                    { /* block id: 710 */
                        l_1471 = (l_1451 , &l_1402);
                        (***l_1463) |= l_1451;
                        (***l_1463) = ((l_1473 = g_1472) == l_1474);
                    }
                    else
                    { /* block id: 715 */
                        (*l_1467) = &l_1279;
                        return &g_105;
                    }
                }
                else
                { /* block id: 719 */
                    uint64_t l_1489 = 18446744073709551615UL;
                    l_1163[3][2] = ((safe_add_func_uint64_t_u_u((safe_sub_func_uint8_t_u_u((((+((*l_1104) | ((safe_mul_func_uint8_t_u_u(((((((**l_1467) || ((***l_1466) ^ ((((*l_1318) = (safe_lshift_func_int16_t_s_u((0xCCL > ((l_1489 , g_388.f2) > 0UL)), ((safe_mul_func_int16_t_s_s((l_1489 | 0xDF94466CL), (**g_792))) == (-7L))))) && 0L) != l_1489))) , 8UL) <= 0L) < l_1300) >= g_1492[1]), 5UL)) , 0x4DFB9DD7L))) || (*l_1108)) , (**l_1467)), l_1489)), 1L)) != (*l_1104));
                    for (g_366.f5 = 0; (g_366.f5 <= 4); g_366.f5 += 1)
                    { /* block id: 724 */
                        uint16_t l_1493 = 2UL;
                        uint32_t *l_1499 = &l_1378;
                        int32_t l_1506 = 4L;
                        l_1292 ^= ((l_1493 <= (0x6FL | ((*l_1117) ^= ((-4L) || (safe_sub_func_uint16_t_u_u((((--(**g_707)) , g_1498) > ((*l_1499) ^= g_796.f6)), (((l_1506 = ((safe_mod_func_int16_t_s_s((****l_1465), l_1489)) > ((safe_mul_func_int8_t_s_s((safe_rshift_func_uint16_t_u_s((g_371.f4 , ((6L && l_1369[0]) , 0xAF52L)), 15)), (*l_1104))) > (****l_1465)))) && l_1493) , g_794[8].f5))))))) ^ l_1489);
                        l_1509 |= (safe_div_func_int16_t_s_s(l_1451, (*l_1104)));
                    }
                }
            }
            else
            { /* block id: 733 */
                uint64_t l_1512 = 18446744073709551615UL;
                int16_t *l_1513 = &l_1299[3][1];
                int64_t ***** const l_1516 = &l_1155;
                struct S1 *l_1538 = &g_1539[1][0];
                int32_t *l_1548 = (void*)0;
                int32_t l_1549 = 0xC0EC0F39L;
                uint64_t **l_1557 = &g_318;
                if ((safe_mod_func_uint64_t_u_u((((g_223[0][5][8] & (((*l_1513) = (((l_1512 > ((g_375.f5 == ((*l_1108) = (*l_1104))) <= (*l_1104))) | 0xF4E8F55DL) , l_1368[1])) <= ((0L ^ (safe_rshift_func_uint16_t_u_s((**g_792), l_1369[0]))) != 0x25L))) , (void*)0) == l_1516), (*l_1104))))
                { /* block id: 736 */
                    int8_t * const l_1523 = &g_1524;
                    int8_t * const *l_1522 = &l_1523;
                    int8_t * const **l_1521[5][9][3] = {{{&l_1522,&l_1522,(void*)0},{&l_1522,&l_1522,&l_1522},{&l_1522,&l_1522,(void*)0},{&l_1522,(void*)0,&l_1522},{&l_1522,&l_1522,&l_1522},{(void*)0,&l_1522,(void*)0},{&l_1522,&l_1522,&l_1522},{&l_1522,(void*)0,&l_1522},{(void*)0,&l_1522,&l_1522}},{{&l_1522,&l_1522,&l_1522},{(void*)0,&l_1522,&l_1522},{&l_1522,&l_1522,(void*)0},{&l_1522,&l_1522,&l_1522},{(void*)0,&l_1522,(void*)0},{&l_1522,&l_1522,&l_1522},{&l_1522,&l_1522,&l_1522},{&l_1522,&l_1522,&l_1522},{&l_1522,&l_1522,&l_1522}},{{&l_1522,&l_1522,&l_1522},{(void*)0,&l_1522,(void*)0},{&l_1522,&l_1522,&l_1522},{(void*)0,&l_1522,&l_1522},{&l_1522,&l_1522,(void*)0},{&l_1522,&l_1522,&l_1522},{&l_1522,&l_1522,(void*)0},{&l_1522,(void*)0,&l_1522},{&l_1522,&l_1522,&l_1522}},{{(void*)0,&l_1522,&l_1522},{&l_1522,&l_1522,&l_1522},{&l_1522,&l_1522,(void*)0},{&l_1522,&l_1522,&l_1522},{&l_1522,&l_1522,&l_1522},{&l_1522,&l_1522,&l_1522},{&l_1522,&l_1522,&l_1522},{&l_1522,&l_1522,&l_1522},{&l_1522,&l_1522,&l_1522}},{{&l_1522,(void*)0,&l_1522},{(void*)0,&l_1522,&l_1522},{&l_1522,&l_1522,&l_1522},{&l_1522,&l_1522,(void*)0},{&l_1522,(void*)0,&l_1522},{&l_1522,&l_1522,&l_1522},{&l_1522,&l_1522,&l_1522},{&l_1522,&l_1522,&l_1522},{&l_1522,&l_1522,&l_1522}}};
                    struct S1 **l_1540 = &g_793[3][0];
                    int32_t l_1543 = 0xA2A47955L;
                    int32_t **l_1544 = &l_1109[3];
                    int32_t l_1550 = (-3L);
                    uint16_t l_1551 = 0x5A67L;
                    int i, j, k;
                    if ((((safe_mod_func_int64_t_s_s((safe_mul_func_int8_t_s_s(((l_1525 = &g_887[3]) == (l_1528 = l_1528)), (++(*g_483)))), (safe_rshift_func_int16_t_s_s(((*l_1513) ^= (l_1533 != (g_505 = g_505))), 15)))) == ((**g_1435) || (*l_1104))) , ((((*g_483) = 0xAFL) <= (*l_1104)) > (((safe_sub_func_uint64_t_u_u((safe_mul_func_int16_t_s_s((((*l_1540) = l_1538) == (void*)0), (*l_1104))), l_1512)) == g_387.f5) > l_1512))))
                    { /* block id: 744 */
                        (*l_1108) &= ((***g_1434) , 0L);
                    }
                    else
                    { /* block id: 746 */
                        int32_t **l_1542 = &g_1356[6];
                        int32_t ***l_1541 = &l_1542;
                        int32_t ***l_1545[8] = {&l_1544,(void*)0,&l_1544,(void*)0,&l_1544,(void*)0,&l_1544,(void*)0};
                        int i;
                        (*l_1104) = (((*l_1541) = &g_1282[0]) == (g_1546 = ((l_1543 &= (l_1320 ^= l_1159)) , l_1544)));
                        l_1547 = (*g_1546);
                        l_1548 = (*g_1546);
                    }
                    l_1551--;
                }
                else
                { /* block id: 756 */
                    uint16_t l_1554 = 65535UL;
                    (*l_1547) &= l_1554;
                }
                if (((*g_483) , (safe_div_func_uint32_t_u_u((*l_1547), ((((&g_804 != ((*l_1557) = &l_1180)) != (safe_rshift_func_int8_t_s_s((safe_add_func_int32_t_s_s(0x2EE01025L, (*l_1547))), 2))) ^ 4294967295UL) && ((safe_sub_func_uint8_t_u_u((*l_1104), (safe_mod_func_int8_t_s_s((-9L), (*l_1547))))) <= (*l_1108)))))))
                { /* block id: 760 */
                    --l_1566[0];
                }
                else
                { /* block id: 762 */
                    (*l_1547) = (-6L);
                }
                (*g_1546) = (void*)0;
            }
            if (((*l_1104) < (safe_mod_func_uint32_t_u_u((safe_lshift_func_uint8_t_u_s((*l_1104), 4)), (-1L)))))
            { /* block id: 767 */
                int32_t l_1584 = 3L;
                int32_t l_1589 = 0x9ADA1855L;
                int32_t l_1590 = 0x11B1FC70L;
                int32_t l_1591 = 1L;
                int32_t l_1592 = 0x19F0D126L;
                int32_t l_1593 = 0L;
                int32_t l_1595 = 1L;
                int32_t l_1596 = 0x51C84D30L;
                int32_t l_1598 = 1L;
                int32_t l_1601[3];
                int32_t l_1614 = (-7L);
                int i;
                for (i = 0; i < 3; i++)
                    l_1601[i] = (-1L);
                for (l_1451 = 0; (l_1451 <= 0); l_1451 += 1)
                { /* block id: 770 */
                    uint8_t l_1573 = 0x2AL;
                    uint32_t *l_1578 = (void*)0;
                    uint32_t *l_1579 = &g_532;
                    int32_t l_1594 = 0x41E9E769L;
                    int32_t l_1597 = (-3L);
                    int32_t l_1599 = (-1L);
                    int32_t l_1600 = 1L;
                    int32_t l_1602 = 0x1DAC962DL;
                    int32_t *l_1613 = &g_366.f2;
                    int i;
                }
                l_1615--;
            }
            else
            { /* block id: 792 */
                uint32_t l_1634 = 0UL;
                int32_t ***l_1656 = &g_1546;
                int32_t l_1676 = 1L;
                int32_t l_1679 = 2L;
                for (g_380.f0 = 0; (g_380.f0 != 7); g_380.f0 = safe_add_func_int16_t_s_s(g_380.f0, 1))
                { /* block id: 795 */
                    int32_t l_1620 = 0L;
                    int32_t *l_1622 = &g_108;
                    if (l_1620)
                    { /* block id: 796 */
                        int32_t l_1621 = (-3L);
                        if (l_1621)
                            break;
                        (*g_1546) = l_1622;
                    }
                    else
                    { /* block id: 799 */
                        int32_t *l_1623 = &l_1110[3];
                        return l_1109[1];
                    }
                }
                for (g_859.f5 = 0; (g_859.f5 != 13); ++g_859.f5)
                { /* block id: 805 */
                    uint16_t l_1628 = 65535UL;
                    uint32_t l_1638 = 0x3E8E2E39L;
                    int32_t ***l_1655[7];
                    uint16_t *l_1677 = &g_374.f3;
                    uint16_t *l_1678 = &g_370.f3;
                    int i;
                    for (i = 0; i < 7; i++)
                        l_1655[i] = &g_1546;
                    for (g_384.f5 = (-27); (g_384.f5 != (-10)); ++g_384.f5)
                    { /* block id: 808 */
                        uint32_t *l_1631 = &g_532;
                        uint8_t * const l_1632 = &g_379.f4;
                        int32_t l_1633 = 0x1E574AF7L;
                        struct S0 ***l_1636 = &g_505;
                        struct S0 ****l_1635[7][5] = {{&l_1636,&l_1636,&l_1636,(void*)0,&l_1636},{&l_1636,(void*)0,&l_1636,(void*)0,&l_1636},{&l_1636,(void*)0,&l_1636,&l_1636,&l_1636},{&l_1636,&l_1636,&l_1636,(void*)0,&l_1636},{&l_1636,(void*)0,&l_1636,(void*)0,&l_1636},{&l_1636,(void*)0,&l_1636,&l_1636,&l_1636},{&l_1636,&l_1636,&l_1636,(void*)0,&l_1636}};
                        int32_t ****l_1657 = &l_1656;
                        int32_t *l_1660 = &g_374.f2;
                        int i, j;
                        (*l_1104) = (((***g_706) = l_1628) & (safe_add_func_int64_t_s_s((*l_1104), ((((*l_1631) = g_7) <= ((l_1632 == (((l_1633 <= ((l_1634 < (&g_505 == (l_1637[3] = &l_1533))) >= (((*l_1547) || 0x725545325ED48B1DLL) < l_1638))) > (*l_1547)) , (void*)0)) == g_1639)) == l_1638))));
                        (*l_1547) = (safe_rshift_func_int16_t_s_u(l_1633, 3));
                        l_1163[3][3] &= ((l_1628 >= (safe_mul_func_uint8_t_u_u(((((**l_1528) = ((safe_div_func_uint8_t_u_u((l_1638 , l_1638), (safe_sub_func_uint64_t_u_u(((l_1648 &= l_1628) , (((safe_mod_func_uint32_t_u_u((l_1634 || (((safe_mul_func_uint8_t_u_u(((((((*l_1547) = (((safe_lshift_func_int16_t_s_s(l_1633, 8)) , l_1655[2]) == ((*l_1657) = l_1656))) == (safe_mod_func_int8_t_s_s(l_1634, l_1634))) & 0x1C89D6A98016E6AFLL) == 1UL) , (*l_1104)), l_1634)) == 0UL) ^ g_797[0][2].f3)), (-1L))) >= l_1634) != 0L)), (*l_1108))))) != (***g_706))) <= (*l_1104)) < 1UL), (**g_1435)))) == 1UL);
                        l_1660 = ((*g_1546) = l_1109[0]);
                    }
                    l_1679 &= ((**g_792) && ((*l_1104) = (safe_sub_func_int16_t_s_s((*l_1104), (safe_div_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(((safe_lshift_func_uint8_t_u_s((*l_1547), 5)) ^ (g_77[9] & ((**g_792) |= (*l_1547)))), ((*l_1547) , ((*l_1678) = (safe_rshift_func_uint16_t_u_s(((((l_1671 == (((safe_rshift_func_int16_t_s_u((*l_1547), ((*l_1677) ^= (safe_add_func_int64_t_s_s(((*l_1108) = ((*l_1104) != l_1676)), 6L))))) && 4294967288UL) , (*g_706))) , (*l_1547)) , (*l_1108)) < (***g_706)), g_1411.f6)))))), 0xA61BL))))));
                }
            }
        }
    }
    else
    { /* block id: 831 */
        const int32_t *l_1680 = &g_98[0];
        const int32_t **l_1681 = (void*)0;
        const int32_t **l_1682[1];
        int32_t *l_1684[7][7];
        int i, j;
        for (i = 0; i < 1; i++)
            l_1682[i] = &l_1680;
        for (i = 0; i < 7; i++)
        {
            for (j = 0; j < 7; j++)
                l_1684[i][j] = &g_374.f2;
        }
        l_1683 = l_1680;
        l_1684[5][3] = &l_1106;
    }
    (*l_1697) &= (safe_sub_func_int8_t_s_s((safe_mul_func_int8_t_s_s(((*g_686) == (void*)0), ((**l_1528) = ((*l_1104) = (((*l_1691) = l_1689) == (l_1692 = l_1692)))))), (((((((safe_mul_func_int8_t_s_s(0xC6L, g_1695[1][7])) <= (**g_1435)) && ((l_1696[0][1][2] == (void*)0) ^ (-1L))) != 4294967293UL) ^ 0xB56AL) ^ g_797[0][2].f7) ^ 0x57C0L)));
    l_1110[1] ^= (safe_div_func_uint64_t_u_u(((*l_1104) , (*l_1104)), ((*l_1697) = 18446744073709551614UL)));
    return l_1701;
}


/* ------------------------------------------ */
/* 
 * reads : g_21 g_12 g_2 g_106 g_22 g_81 g_93 g_17 g_124 g_100 g_110 g_102 g_98 g_145 g_142 g_20 g_103 g_101 g_77 g_7 g_99 g_87 g_107 g_171 g_128 g_238 g_226.f6 g_226.f0 g_208 g_285 g_130 g_108 g_347 g_226.f7 g_192 g_369.f2 g_382.f3 g_369.f3 g_380.f0 g_430 g_384.f3 g_226.f3 g_387.f3 g_374.f2 g_377.f4 g_388.f2 g_366.f3 g_483 g_223 g_380.f4 g_505 g_150 g_369.f0 g_377.f2 g_375.f3 g_382.f0 g_577 g_532 g_376.f2 g_380.f5 g_104 g_384.f5 g_379.f0 g_378.f5 g_369.f4 g_381.f2 g_379.f3 g_139 g_415.f6 g_386.f2 g_725 g_371.f3 g_378.f0 g_706 g_707 g_384.f4 g_754 g_389.f0 g_366.f5 g_686 g_687 g_385.f5 g_387.f4 g_793 g_366.f4 g_370.f3 g_726 g_385.f3 g_226.f5 g_426 g_415.f0 g_586.f3 g_97 g_797.f3 g_859.f2 g_386.f5 g_723.f5 g_231 g_952 g_859.f0 g_792 g_372.f3 g_383.f2 g_370.f0 g_375.f2 g_797.f0 g_383.f0 g_366.f2 g_375.f5
 * writes: g_21 g_77 g_81 g_87 g_128 g_130 g_110 g_139 g_142 g_145 g_150 g_108 g_171 g_107 g_192 g_208 g_98 g_102 g_223 g_238 g_285 g_316 g_318 g_347 g_104 g_384.f0 g_373.f4 g_372.f0 g_426 g_483 g_380.f4 g_505 g_377.f2 g_382.f0 g_373.f5 g_380.f3 g_366.f5 g_532 g_382.f2 g_97 g_376.f3 g_376.f2 g_383.f5 g_385.f3 g_378.f4 g_12 g_99 g_387.f0 g_383.f2 g_386.f2 g_388.f2 g_371.f3 g_754 g_382.f3 g_385.f5 g_792 g_801 g_804 g_103 g_375.f2 g_378.f0 g_862 g_867 g_372.f3 g_887 g_586.f3 g_100 g_371.f0 g_859.f2 g_386.f5 g_723.f5 g_231 g_952 g_106 g_370.f0 g_383.f0 g_389.f2
 */
static int32_t ** const  func_42(uint64_t  p_43)
{ /* block id: 10 */
    const int32_t l_48 = 0xB4AD293DL;
    int32_t **l_54 = (void*)0;
    int8_t l_313[2][5][9] = {{{0xE1L,0x5AL,(-6L),0x24L,0x24L,(-6L),0x5AL,0xE1L,0x5AL},{0xC2L,0x3BL,(-8L),(-7L),(-7L),0xB3L,0xA8L,0xB3L,(-7L)},{1L,0x5AL,0x5AL,1L,0xE1L,7L,0xE1L,1L,0x5AL},{0x67L,0x7EL,0xA8L,0x3BL,0L,0x3BL,0xA8L,0x7EL,0x67L},{0x5AL,1L,0xE1L,7L,0xE1L,1L,0x5AL,0x5AL,1L}},{{(-7L),0xB3L,0xA8L,0xB3L,(-7L),(-7L),(-8L),0x3BL,0xC2L},{0x5AL,0xE1L,0x5AL,(-6L),0x24L,0x24L,(-6L),0x5AL,0xE1L},{0x67L,0xF2L,(-8L),1L,0xA8L,(-7L),0x02L,0x7EL,0x02L},{1L,7L,(-6L),(-6L),7L,1L,0x24L,1L,7L},{0xC2L,0xF2L,0x02L,0xB3L,0x67L,0x3BL,0x67L,0xB3L,0x02L}}};
    int32_t l_717 = 8L;
    struct S0 *l_722 = &g_723;
    struct S0 **l_721 = &l_722;
    int32_t l_727 = 0xF3209318L;
    int64_t * const * const l_773 = &g_208[3][0][4];
    uint16_t **l_791 = &g_426[2];
    int32_t l_817 = 0xFA20E0EFL;
    int32_t l_823 = 0x5D5F6843L;
    int32_t l_824[8] = {5L,5L,5L,5L,5L,5L,5L,5L};
    int8_t **l_903 = &g_887[0];
    uint32_t l_912 = 0xEDBE8F29L;
    uint8_t l_947 = 0xA1L;
    struct S2 l_962 = {0xEAL,0,0x2757DB0CL,0xBBL,-5L,65533UL};
    const uint8_t l_966[2] = {0xA8L,0xA8L};
    uint8_t **l_1038 = (void*)0;
    int16_t *l_1056 = &g_142;
    uint16_t l_1091 = 9UL;
    int8_t l_1092 = 4L;
    int i, j, k;
    for (g_21 = 0; (g_21 >= (-29)); --g_21)
    { /* block id: 13 */
        int8_t l_62 = 0x2CL;
        int32_t *l_63 = &g_17;
        int32_t *l_718 = &g_386.f2;
        struct S0 **l_724[1];
        int32_t *l_728 = &g_388.f2;
        int i;
        for (i = 0; i < 1; i++)
            l_724[i] = &l_722;
        (*l_718) ^= (l_717 = (safe_div_func_int8_t_s_s(l_48, func_49((((void*)0 == l_54) , ((!0x66A3L) | (*g_12))), (func_56(l_62, l_63, (safe_unary_minus_func_uint32_t_u(p_43)), &g_12, &g_20) , g_93.f0), l_313[1][2][8], g_93.f3))));
        (*l_728) ^= ((safe_sub_func_int64_t_s_s(((p_43 && 0UL) | (((((*l_63) , ((g_93 , (*l_718)) == ((((l_721 != l_724[0]) & ((void*)0 == &l_54)) , g_725) != (void*)0))) , (*l_63)) && 0x8AL) && p_43)), (*l_718))) != l_727);
    }
    if (p_43)
    { /* block id: 360 */
        int64_t l_748[10] = {0x8996628BD0BF4BEALL,0x8996628BD0BF4BEALL,0x8996628BD0BF4BEALL,0x8996628BD0BF4BEALL,0x8996628BD0BF4BEALL,0x8996628BD0BF4BEALL,0x8996628BD0BF4BEALL,0x8996628BD0BF4BEALL,0x8996628BD0BF4BEALL,0x8996628BD0BF4BEALL};
        int32_t l_756[8][1][1] = {{{0x798A0117L}},{{0x536E70F0L}},{{0x798A0117L}},{{0x536E70F0L}},{{0x798A0117L}},{{0x536E70F0L}},{{0x798A0117L}},{{0x536E70F0L}}};
        uint32_t l_805[7] = {4294967289UL,4294967289UL,4294967289UL,4294967289UL,4294967289UL,4294967289UL,4294967289UL};
        uint16_t l_810 = 0xE044L;
        int8_t * const l_845 = &l_313[1][2][6];
        int64_t **l_853 = &g_208[3][0][4];
        int64_t ***l_852[10][10] = {{&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853},{&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853},{&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,(void*)0},{&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853},{&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853},{&l_853,&l_853,&l_853,&l_853,(void*)0,&l_853,&l_853,&l_853,&l_853,&l_853},{&l_853,&l_853,(void*)0,&l_853,&l_853,&l_853,&l_853,(void*)0,&l_853,&l_853},{(void*)0,(void*)0,(void*)0,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853},{&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,(void*)0,&l_853,&l_853,&l_853},{(void*)0,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853,&l_853}};
        const struct S2 * const l_872 = &g_93;
        const struct S2 * const * const l_871 = &l_872;
        int32_t ** const l_891 = &g_12;
        uint16_t l_939 = 0x1243L;
        const int64_t ***l_954 = &g_952[2];
        int32_t *l_977 = &g_106;
        int i, j, k;
        for (g_371.f3 = 3; (g_371.f3 >= 29); g_371.f3 = safe_add_func_uint8_t_u_u(g_371.f3, 3))
        { /* block id: 363 */
            int64_t l_744 = 0x2BEF3EC1FFF75394LL;
            int32_t *l_749 = &g_108;
            uint32_t *l_750 = &g_532;
            int16_t *l_751 = &g_139;
            uint32_t l_752[4];
            int64_t *l_753 = &g_754;
            int8_t *l_755 = &l_313[1][2][8];
            int32_t l_757[6][3] = {{0L,0x7FE8DFD7L,(-1L)},{0x2DD6CA48L,0x2DD6CA48L,(-1L)},{0x7FE8DFD7L,0L,(-1L)},{0L,0x7FE8DFD7L,(-1L)},{0x2DD6CA48L,0x2DD6CA48L,(-1L)},{0x7FE8DFD7L,0L,(-1L)}};
            int i, j;
            for (i = 0; i < 4; i++)
                l_752[i] = 0xB39F3703L;
            l_757[0][0] ^= (l_756[3][0][0] = (~((safe_sub_func_int8_t_s_s((safe_rshift_func_uint8_t_u_s(p_43, ((*l_755) = (safe_div_func_int64_t_s_s(((safe_mod_func_int64_t_s_s(p_43, ((*l_753) &= (safe_lshift_func_int16_t_s_s(((safe_sub_func_int16_t_s_s(((*l_751) = ((l_744 = p_43) , ((((p_43 || (safe_unary_minus_func_int32_t_s(((g_77[4] >= (((safe_mul_func_int8_t_s_s(g_378.f0, (((*l_749) |= l_748[8]) ^ ((*l_750) = p_43)))) >= (p_43 & 0UL)) >= (***g_706))) & 0xDE67A447L)))) , p_43) == 255UL) , (-9L)))), l_752[3])) & (*g_171)), g_384.f4))))) > g_389.f0), p_43))))), (*g_483))) ^ g_366.f5)));
            if (p_43)
                break;
        }
        for (g_382.f3 = (-22); (g_382.f3 > 12); g_382.f3 = safe_add_func_int16_t_s_s(g_382.f3, 8))
        { /* block id: 376 */
            int64_t l_775 = 1L;
            int16_t *l_776 = (void*)0;
            int16_t *l_777 = (void*)0;
            int32_t l_803 = 4L;
            int32_t l_807[10] = {0x5B17B05FL,0x5B17B05FL,1L,0x5B17B05FL,0x5B17B05FL,1L,0x5B17B05FL,0x5B17B05FL,1L,0x5B17B05FL};
            uint16_t l_826 = 6UL;
            struct S2 *l_858 = &g_859;
            struct S2 **l_857[8] = {&l_858,&l_858,&l_858,&l_858,&l_858,&l_858,&l_858,&l_858};
            uint64_t **l_901[2][10] = {{&g_316,&g_318,&g_316,&g_316,&g_318,&g_316,&g_316,&g_316,&g_318,&g_316},{(void*)0,&g_316,(void*)0,&g_316,&g_316,&g_316,&g_316,(void*)0,&g_316,(void*)0}};
            int32_t *l_943 = &g_376.f2;
            int32_t *l_944 = &g_372.f2;
            int32_t *l_945 = (void*)0;
            int32_t *l_946[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_106,(void*)0};
            int i, j;
            if (((safe_lshift_func_int16_t_s_s((g_145 = ((((safe_unary_minus_func_int8_t_s(((safe_add_func_int8_t_s_s(p_43, (safe_rshift_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u(1UL, (((safe_mul_func_int8_t_s_s((((-3L) ^ (((void*)0 != (*g_686)) < ((18446744073709551615UL & (l_773 == l_773)) != ((~((0xDB15487FL == 4294967295UL) == p_43)) , p_43)))) , p_43), 250UL)) , l_775) ^ p_43))), l_756[4][0][0])))) < l_717))) && 0UL) == 1UL) , l_748[8])), 7)) > g_385.f5))
            { /* block id: 378 */
                int16_t l_811 = 0x2714L;
                int32_t l_812 = 0xDF12378FL;
                int32_t l_813 = 5L;
                int32_t l_816 = 0xA3FEA63CL;
                int32_t l_820 = 0x488F648DL;
                int32_t l_821 = (-1L);
                int32_t l_822 = 0x78F81857L;
                int32_t l_825 = 0x4249079DL;
                int8_t *l_848 = &g_150;
                struct S2 **l_870 = &g_868;
                struct S2 ***l_869 = &l_870;
                int8_t *l_873[8] = {&g_859.f4,(void*)0,(void*)0,&g_859.f4,(void*)0,(void*)0,&g_859.f4,(void*)0};
                const uint8_t *l_876 = &g_347[7][3];
                const uint8_t **l_875 = &l_876;
                const uint8_t ***l_874 = &l_875;
                const uint8_t ****l_877 = &l_874;
                int i;
                for (g_87 = (-28); (g_87 >= 16); g_87 = safe_add_func_uint16_t_u_u(g_87, 8))
                { /* block id: 381 */
                    uint8_t l_790 = 0xE2L;
                    struct S1 *l_799 = &g_800;
                    int32_t l_814 = 0xFCBE4D2CL;
                    int64_t l_815 = 0L;
                    int32_t l_818 = 7L;
                    int32_t l_819[5];
                    int i;
                    for (i = 0; i < 5; i++)
                        l_819[i] = 0xA2C39CEFL;
                    for (g_385.f5 = 0; (g_385.f5 < (-2)); g_385.f5--)
                    { /* block id: 384 */
                        int8_t *l_785[9] = {(void*)0,&g_150,(void*)0,&g_150,(void*)0,&g_150,(void*)0,&g_150,(void*)0};
                        int32_t *l_806[4][8] = {{&g_107,&g_107,&g_106,&g_106,&g_107,&g_107,&g_106,&g_106},{&g_107,&g_107,&g_106,&g_106,&g_107,&g_107,&g_106,&g_106},{&g_107,&g_107,&g_106,&g_106,&g_107,&g_107,&g_106,&g_106},{&g_107,&g_107,&g_106,&g_106,&g_107,&g_107,&g_106,&g_106}};
                        int i, j;
                        l_807[6] |= (((g_804 = (g_150 &= ((safe_lshift_func_int16_t_s_u((0x55CF8635489AA6CBLL <= 0xA3A3CD1AD4FF8ADDLL), 1)) <= ((l_756[3][0][0] |= (!1UL)) , (((g_387.f4 & (l_803 &= (safe_sub_func_int64_t_s_s(((((safe_sub_func_uint32_t_u_u((l_790 > ((((g_792 = l_791) != (void*)0) , g_793[3][0]) == (g_801 = l_799))), p_43)) <= g_382.f3) , p_43) != 0x193D2D735342368FLL), p_43)))) , 65530UL) <= 0xC038L))))) , l_805[6]) , p_43);
                        g_103 &= (safe_mul_func_uint8_t_u_u((**g_707), (p_43 , (l_810 && 0x52L))));
                        if (p_43)
                            continue;
                        l_826++;
                    }
                    if ((*g_171))
                        continue;
                }
                for (g_375.f2 = 0; (g_375.f2 > (-16)); --g_375.f2)
                { /* block id: 400 */
                    int32_t l_840[9] = {8L,8L,8L,8L,8L,8L,8L,8L,8L};
                    int8_t *l_847[8];
                    int8_t **l_846[7][3][7] = {{{(void*)0,&l_847[3],(void*)0,&l_847[3],(void*)0,&l_847[6],&l_847[2]},{&l_847[3],&l_847[7],&l_847[4],&l_847[4],&l_847[7],&l_847[3],&l_847[7]},{(void*)0,&l_847[3],(void*)0,&l_847[6],&l_847[2],&l_847[6],(void*)0}},{{&l_847[6],&l_847[6],&l_847[3],&l_847[4],&l_847[3],&l_847[6],&l_847[6]},{&l_847[4],&l_847[3],&l_847[3],&l_847[3],&l_847[4],&l_847[3],(void*)0},{(void*)0,&l_847[7],(void*)0,&l_847[3],&l_847[3],(void*)0,&l_847[7]}},{{(void*)0,&l_847[3],&l_847[3],&l_847[3],&l_847[2],&l_847[3],&l_847[2]},{(void*)0,&l_847[3],&l_847[3],(void*)0,&l_847[7],(void*)0,&l_847[3]},{&l_847[4],&l_847[3],(void*)0,&l_847[3],(void*)0,&l_847[3],&l_847[4]}},{{&l_847[6],&l_847[3],&l_847[4],&l_847[3],&l_847[6],&l_847[6],&l_847[3]},{(void*)0,&l_847[3],(void*)0,&l_847[3],(void*)0,&l_847[6],&l_847[2]},{&l_847[3],&l_847[7],&l_847[4],&l_847[4],&l_847[7],&l_847[3],&l_847[7]}},{{(void*)0,&l_847[3],(void*)0,&l_847[6],&l_847[2],&l_847[6],(void*)0},{&l_847[6],&l_847[6],&l_847[3],&l_847[4],&l_847[3],&l_847[6],&l_847[6]},{&l_847[4],&l_847[3],&l_847[3],&l_847[3],&l_847[4],&l_847[3],(void*)0}},{{(void*)0,&l_847[7],(void*)0,&l_847[3],&l_847[3],(void*)0,&l_847[7]},{(void*)0,&l_847[3],&l_847[3],&l_847[3],&l_847[2],&l_847[3],&l_847[2]},{(void*)0,&l_847[3],&l_847[3],(void*)0,&l_847[7],(void*)0,&l_847[3]}},{{&l_847[4],&l_847[3],(void*)0,&l_847[3],(void*)0,&l_847[3],(void*)0},{&l_847[3],(void*)0,&l_847[7],(void*)0,&l_847[3],&l_847[3],(void*)0},{&l_847[3],&l_847[3],&l_847[3],&l_847[6],(void*)0,&l_847[3],&l_847[4]}}};
                    int32_t l_849 = (-1L);
                    int i, j, k;
                    for (i = 0; i < 8; i++)
                        l_847[i] = &g_150;
                    l_849 |= (safe_rshift_func_uint16_t_u_u((l_775 == (((((safe_mul_func_int16_t_s_s((((safe_mul_func_int8_t_s_s((((+((safe_mul_func_uint8_t_u_u(8UL, l_840[5])) == g_366.f4)) == (p_43 | g_370.f3)) <= (safe_mul_func_int16_t_s_s((safe_rshift_func_uint8_t_u_u((**g_707), ((l_845 == (l_848 = &l_313[1][2][8])) >= g_285))), 0xC7E7L))), 0x4BL)) , (*g_725)) == l_773), p_43)) > p_43) , p_43) >= g_385.f3) | p_43)), p_43));
                    for (g_378.f0 = 0; (g_378.f0 == 3); g_378.f0++)
                    { /* block id: 405 */
                        int64_t ****l_854[7][7] = {{&l_852[5][8],&l_852[4][3],&l_852[5][8],&l_852[5][8],&l_852[4][3],&l_852[5][8],&l_852[5][8]},{&l_852[4][3],&l_852[4][3],&l_852[8][9],&l_852[4][3],&l_852[4][3],&l_852[8][9],&l_852[4][3]},{&l_852[4][3],&l_852[5][8],&l_852[5][8],&l_852[4][3],&l_852[5][8],&l_852[5][8],&l_852[4][3]},{&l_852[5][8],&l_852[4][3],&l_852[5][8],&l_852[5][8],&l_852[4][3],&l_852[5][8],&l_852[5][8]},{&l_852[4][3],&l_852[4][3],&l_852[8][9],&l_852[4][3],&l_852[4][3],&l_852[8][9],&l_852[4][3]},{&l_852[4][3],&l_852[5][8],&l_852[5][8],&l_852[4][3],&l_852[5][8],&l_852[5][8],&l_852[4][3]},{&l_852[5][8],&l_852[4][3],&l_852[5][8],&l_852[5][8],&l_852[4][3],&l_852[5][8],&l_852[5][8]}};
                        int i, j;
                        l_852[7][7] = l_852[5][8];
                    }
                }
                if ((l_803 = (safe_div_func_int32_t_s_s((((void*)0 != l_857[1]) <= (((l_807[6] = ((void*)0 == &g_532)) == p_43) , ((safe_rshift_func_int16_t_s_u((g_862 = p_43), ((safe_sub_func_uint64_t_u_u((safe_mul_func_int16_t_s_s(((g_150 &= ((*l_845) = (((*l_869) = (g_867[2] = &l_858)) != l_871))) ^ (((*l_877) = l_874) != (void*)0)), l_807[6])), 0x74FFFC1FBAA2024CLL)) , p_43))) , l_807[2]))), 0x698A677CL))))
                { /* block id: 417 */
                    uint16_t *l_888 = &g_586.f3;
                    int32_t l_889 = 0L;
                    int32_t *l_890 = &g_108;
                    (*l_890) ^= (safe_div_func_int8_t_s_s(g_226.f5, ((((*l_888) &= (safe_lshift_func_int8_t_s_u(((p_43 != (safe_add_func_uint64_t_u_u((((((**l_791) = (p_43 < l_811)) && p_43) | (~(safe_add_func_int8_t_s_s(0xA0L, (((g_2 , &l_313[1][2][8]) != (g_887[3] = &g_150)) != p_43))))) && g_415[1].f0), l_816))) <= p_43), 0))) & l_889) & l_822)));
                    return l_891;
                }
                else
                { /* block id: 423 */
                    int32_t *l_892 = &g_100;
                    (*l_892) = p_43;
                }
                return &g_12;
            }
            else
            { /* block id: 427 */
                int16_t l_902 = 0L;
                int32_t ** const l_928 = (void*)0;
                uint32_t *l_935 = (void*)0;
                (*l_891) = &g_102;
                if (p_43)
                { /* block id: 429 */
                    int16_t *l_904 = &g_139;
                    struct S2 l_911 = {0x96L,7,0x37DCD7ECL,0x2FL,-3L,65535UL};
                    int32_t l_922[6];
                    int i;
                    for (i = 0; i < 6; i++)
                        l_922[i] = 0x57BB8F74L;
                    if ((safe_mod_func_uint8_t_u_u((*g_483), (safe_lshift_func_int8_t_s_u(((p_43 <= (safe_mul_func_uint8_t_u_u((***g_706), (((safe_div_func_int8_t_s_s(((l_901[0][0] != ((p_43 > ((*l_904) &= (((l_902 , l_903) == ((((void*)0 == &g_426[2]) , (**l_891)) , l_903)) | p_43))) , (void*)0)) && (-7L)), 3UL)) <= p_43) | (*g_483))))) , l_902), (*g_483))))))
                    { /* block id: 431 */
                        int32_t *l_905 = &g_97;
                        int16_t l_913 = 0xA8C2L;
                        int32_t *l_920 = (void*)0;
                        int32_t *l_921 = &l_817;
                        (*l_905) = ((**l_891) = (*g_12));
                        l_922[4] |= ((*l_921) &= ((safe_rshift_func_int16_t_s_s((((0UL >= (~((safe_rshift_func_uint8_t_u_s((l_911 , l_912), l_913)) , l_911.f2))) >= (0xE4D86BE2054E2FEFLL || ((g_371.f0 = (safe_mul_func_int8_t_s_s(0x5CL, p_43))) != ((safe_sub_func_int64_t_s_s((safe_lshift_func_uint8_t_u_u(0x17L, 2)), (*l_905))) < g_797[0][2].f3)))) && (**l_891)), 1)) <= (-1L)));
                        (*g_12) = (safe_rshift_func_int8_t_s_u(0xFFL, 1));
                    }
                    else
                    { /* block id: 438 */
                        (*l_891) = (void*)0;
                        (*l_891) = &l_807[6];
                        (**l_891) |= 0x15832596L;
                    }
                    (*g_12) = (*g_171);
                    (*l_891) = (*l_891);
                }
                else
                { /* block id: 445 */
                    int32_t ** const l_927 = &g_12;
                    (*l_891) = &l_803;
                    (*g_12) = l_826;
                    for (g_859.f2 = 2; (g_859.f2 <= (-5)); g_859.f2--)
                    { /* block id: 450 */
                        return l_928;
                    }
                    return l_54;
                }
                for (g_386.f5 = 0; (g_386.f5 == (-9)); g_386.f5 = safe_sub_func_int8_t_s_s(g_386.f5, 2))
                { /* block id: 457 */
                    for (g_723.f5 = (-23); (g_723.f5 == 11); g_723.f5++)
                    { /* block id: 460 */
                        const uint32_t *l_937 = &g_938;
                        const uint32_t **l_936 = &l_937;
                        if ((*g_12))
                            break;
                        (**l_891) |= (safe_lshift_func_int16_t_s_s(0x704FL, (p_43 <= p_43)));
                        if (p_43)
                            break;
                        l_939 ^= ((**l_891) = (l_935 != ((*l_936) = &l_805[0])));
                    }
                }
            }
            for (g_231 = 0; (g_231 != (-19)); g_231--)
            { /* block id: 472 */
                int32_t ** const l_942 = (void*)0;
                return l_942;
            }
            l_947--;
        }
        (*l_977) |= ((p_43 , (safe_mod_func_uint64_t_u_u(((((*l_954) = g_952[2]) == l_773) | (safe_mod_func_int64_t_s_s(((((safe_mul_func_uint8_t_u_u((~(safe_mod_func_int8_t_s_s((l_962 , (safe_mod_func_int32_t_s_s(((((!(-1L)) , l_966[1]) , ((safe_div_func_int64_t_s_s(((p_43 | (safe_mul_func_int16_t_s_s((safe_rshift_func_uint8_t_u_s((safe_lshift_func_int8_t_s_u((safe_add_func_uint32_t_u_u(g_859.f0, p_43)), (*g_483))), 4)), (-9L)))) >= p_43), 0x9AAF0FB73CBEFBF9LL)) <= p_43)) || (*g_483)), 0xB9C1732BL))), 3UL))), p_43)) && 0x742298FEB6FA84F6LL) , p_43) != p_43), 0xB24A07ADA3C814DBLL))), p_43))) == (**g_792));
    }
    else
    { /* block id: 479 */
        int32_t *l_979 = &g_375.f2;
        int32_t l_989 = 1L;
        int32_t l_990 = 6L;
        struct S2 *l_1010 = &g_859;
        uint16_t **l_1019 = &g_426[2];
        uint64_t * const *l_1051 = &g_318;
        for (g_383.f2 = 0; (g_383.f2 <= 3); g_383.f2 += 1)
        { /* block id: 482 */
            int64_t l_988[10] = {0xE57C6F85E2844C23LL,0x8443D9CA32644F73LL,0xE57C6F85E2844C23LL,0x8443D9CA32644F73LL,0xE57C6F85E2844C23LL,0x8443D9CA32644F73LL,0xE57C6F85E2844C23LL,0x8443D9CA32644F73LL,0xE57C6F85E2844C23LL,0x8443D9CA32644F73LL};
            int32_t l_997 = (-5L);
            int32_t l_1018[6] = {0xFCE797D8L,1L,1L,0xFCE797D8L,1L,1L};
            struct S2 *l_1039 = (void*)0;
            int16_t *l_1054[7] = {&g_142,&g_145,&g_145,&g_142,&g_145,&g_145,&g_142};
            int i;
            for (g_370.f0 = 0; (g_370.f0 <= 3); g_370.f0 += 1)
            { /* block id: 485 */
                int16_t l_978[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};
                int32_t l_986 = 0x59770168L;
                struct S2 l_995 = {0x4BL,7,3L,8L,9L,0x6827L};
                int i;
            }
            for (l_823 = 0; (l_823 <= 3); l_823 += 1)
            { /* block id: 538 */
                int16_t l_1028 = (-4L);
                int32_t l_1034 = 0x35F93BA2L;
                for (g_108 = 0; (g_108 <= 0); g_108 += 1)
                { /* block id: 541 */
                    uint16_t l_1031 = 0xFF0DL;
                    int32_t ** const l_1033 = (void*)0;
                    int i;
                    if (l_824[(g_108 + 4)])
                    { /* block id: 542 */
                        struct S2 * const *l_1030 = (void*)0;
                        struct S2 * const **l_1029 = &l_1030;
                        const int32_t l_1032 = 1L;
                        (*l_979) = ((((++(**l_1019)) == ((((((safe_mod_func_uint32_t_u_u(((*l_979) , l_1028), g_797[0][2].f0)) || (*l_979)) && (((((void*)0 != l_1029) , &l_1010) != (void*)0) , (((l_1031 = (*g_12)) , 0UL) == (-1L)))) >= (*l_979)) || (*l_979)) >= 0xEEF0A4D6L)) ^ l_1032) == 0xAA4A1D22CBFE4D5ALL);
                    }
                    else
                    { /* block id: 546 */
                        l_824[(g_108 + 4)] &= (*g_12);
                        return l_1033;
                    }
                }
                for (g_102 = 0; (g_102 <= 3); g_102 += 1)
                { /* block id: 553 */
                    uint8_t **l_1037 = &g_483;
                    uint8_t *l_1048 = (void*)0;
                    uint8_t *l_1049[7][7] = {{&g_385.f4,&g_130,&g_374.f4,&g_375.f4,&g_378.f4,&g_378.f4,&g_375.f4},{&g_383.f4,&g_373.f4,&g_383.f4,&g_130,(void*)0,&g_371.f4,&g_385.f4},{&g_373.f4,&g_379.f4,&g_383.f4,&g_374.f4,&g_223[0][2][6],&g_374.f4,&g_383.f4},{(void*)0,(void*)0,&g_374.f4,&g_384.f4,&g_389.f4,&g_371.f4,&g_373.f4},{&g_384.f4,(void*)0,&g_378.f4,&g_371.f4,&g_371.f4,&g_378.f4,(void*)0},{&g_378.f4,&g_379.f4,(void*)0,&g_383.f4,&g_389.f4,&g_130,&g_384.f4},{&g_378.f4,&g_373.f4,&g_223[0][2][6],(void*)0,&g_223[0][2][6],&g_373.f4,&g_378.f4}};
                    int32_t l_1050 = 0L;
                    uint32_t *l_1052 = &g_192;
                    struct S2 **l_1053 = &l_1010;
                    int16_t **l_1055 = &l_1054[1];
                    int32_t *l_1057[1];
                    int i, j;
                    for (i = 0; i < 1; i++)
                        l_1057[i] = (void*)0;
                    (*l_1053) = (((*l_1052) = ((((--g_383.f0) ^ (l_1037 != l_1038)) == ((*l_979) = (l_1010 == l_1039))) | ((((*g_12) || (safe_mod_func_int64_t_s_s((((((safe_mul_func_uint16_t_u_u(p_43, 0x0F96L)) >= ((**g_707) <= (l_1050 = ((l_997 = (((safe_lshift_func_uint8_t_u_s(((safe_sub_func_uint64_t_u_u(p_43, 0x4CE5E326626CF141LL)) || p_43), 5)) && p_43) == p_43)) > 0UL)))) , (**g_792)) , (void*)0) == l_1051), l_988[1]))) ^ (***g_706)) & p_43))) , l_1010);
                    l_1018[2] &= ((*l_979) ^= (((*l_1055) = l_1054[3]) != l_1056));
                }
            }
        }
    }
    for (g_383.f0 = 0; (g_383.f0 != 37); g_383.f0++)
    { /* block id: 569 */
        int32_t *l_1095 = &g_108;
        int32_t **l_1096 = &l_1095;
        if (((p_43 , p_43) & p_43))
        { /* block id: 570 */
            uint16_t l_1063 = 4UL;
            int64_t *l_1089 = &g_77[9];
            uint16_t **l_1090 = &g_426[1];
            int32_t *l_1093 = &g_389.f2;
            int32_t **l_1094 = &l_1093;
            (*l_1093) = (l_962 , (((((((safe_lshift_func_uint16_t_u_s((safe_unary_minus_func_int64_t_s(p_43)), 6)) <= ((l_1063 = (*g_171)) , (safe_lshift_func_uint16_t_u_s((safe_rshift_func_int8_t_s_s((safe_div_func_uint16_t_u_u(((safe_sub_func_uint16_t_u_u(((safe_div_func_uint32_t_u_u(((p_43 && (safe_sub_func_int32_t_s_s((!((safe_lshift_func_uint16_t_u_s((((safe_mod_func_int64_t_s_s((safe_sub_func_uint8_t_u_u(((safe_add_func_uint8_t_u_u((((((*l_1089) |= (safe_div_func_uint64_t_u_u((((safe_mod_func_int8_t_s_s((((((((p_43 , l_1063) , g_124) != (void*)0) | (p_43 , 0xE88ED528L)) , g_139) , (void*)0) == (void*)0), l_1063)) <= p_43) | (*g_171)), l_1063))) , l_1090) != (void*)0) != 0xF611L), p_43)) || (**g_707)), 0x98L)), l_1063)) , p_43) <= g_366.f2), 5)) , 0x72B51C85L)), 7L))) < g_859.f2), (*g_171))) <= p_43), l_1091)) , 0x6B55L), l_1092)), 4)), g_375.f5)))) != p_43) > p_43) , 0xA4L) == l_962.f2) ^ 0x377E57AA562D7E2CLL));
            (*l_1094) = l_1093;
        }
        else
        { /* block id: 575 */
            g_171 = l_1095;
        }
        (*l_1096) = (g_12 = l_1095);
        return &g_12;
    }
    return l_54;
}


/* ------------------------------------------ */
/* 
 * reads : g_238 g_226.f0 g_285 g_130 g_77 g_106 g_108 g_124 g_347 g_100 g_142 g_98 g_128 g_107 g_12 g_2 g_93 g_226.f7 g_192 g_145 g_369.f2 g_102 g_171 g_20 g_382.f3 g_369.f3 g_380.f0 g_430 g_384.f3 g_226.f3 g_387.f3 g_374.f2 g_377.f4 g_388.f2 g_366.f3 g_483 g_223 g_380.f4 g_505 g_150 g_369.f0 g_377.f2 g_375.f3 g_382.f0 g_373.f5 g_380.f3 g_366.f5 g_372.f0 g_577 g_532 g_376.f3 g_376.f2 g_380.f5 g_104 g_384.f5 g_379.f0 g_378.f5 g_369.f4 g_381.f2 g_110 g_379.f3 g_139 g_99 g_387.f0 g_383.f2 g_415.f6
 * writes: g_316 g_318 g_150 g_285 g_77 g_347 g_104 g_192 g_128 g_145 g_384.f0 g_373.f4 g_98 g_372.f0 g_142 g_426 g_483 g_223 g_380.f4 g_505 g_139 g_377.f2 g_382.f0 g_373.f5 g_380.f3 g_366.f5 g_532 g_382.f2 g_97 g_376.f3 g_376.f2 g_110 g_383.f5 g_385.f3 g_378.f4 g_12 g_99 g_387.f0 g_383.f2
 */
static int8_t  func_49(int8_t  p_50, int32_t  p_51, uint16_t  p_52, uint64_t  p_53)
{ /* block id: 125 */
    int32_t * const l_314[2][10][4] = {{{&g_104,&g_109,&g_99[1][5],&g_98[0]},{&g_108,&g_110[3],&g_98[0],&g_98[0]},{&g_98[0],&g_98[0],&g_102,&g_98[0]},{&g_109,&g_110[3],&g_7,&g_98[0]},{&g_99[1][5],&g_109,&g_98[0],(void*)0},{&g_7,&g_109,&g_104,&g_104},{&g_7,&g_7,&g_98[0],&g_104},{&g_99[1][5],&g_104,&g_7,&g_109},{&g_109,&g_108,&g_102,&g_7},{&g_98[0],&g_108,&g_98[0],&g_109}},{{&g_108,&g_104,&g_99[1][5],&g_104},{&g_109,&g_98[0],(void*)0,&g_109},{&g_7,(void*)0,(void*)0,&g_7},{&g_109,&g_110[3],&g_102,&g_104},{&g_104,&g_99[1][5],&g_104,&g_108},{&g_104,&g_108,&g_99[1][5],&g_108},{(void*)0,&g_99[1][5],&g_98[0],&g_104},{&g_98[0],&g_110[3],&g_108,&g_7},{&g_98[0],(void*)0,&g_109,&g_109},{&g_98[0],&g_98[0],&g_108,&g_109}}};
    uint64_t *l_315[8][6][4] = {{{&g_87,&g_87,(void*)0,&g_87},{&g_87,&g_87,&g_87,&g_87},{&g_87,&g_87,(void*)0,&g_87},{&g_87,&g_87,&g_87,&g_87},{&g_87,&g_87,&g_87,&g_87},{&g_87,&g_87,(void*)0,&g_87}},{{&g_87,&g_87,&g_87,(void*)0},{&g_87,&g_87,&g_87,&g_87},{&g_87,&g_87,&g_87,&g_87},{(void*)0,&g_87,(void*)0,&g_87},{&g_87,&g_87,&g_87,&g_87},{&g_87,&g_87,(void*)0,&g_87}},{{&g_87,&g_87,(void*)0,&g_87},{&g_87,&g_87,&g_87,&g_87},{&g_87,(void*)0,(void*)0,&g_87},{(void*)0,&g_87,&g_87,&g_87},{&g_87,&g_87,&g_87,&g_87},{&g_87,&g_87,&g_87,&g_87}},{{&g_87,&g_87,(void*)0,&g_87},{&g_87,&g_87,&g_87,&g_87},{&g_87,(void*)0,&g_87,&g_87},{&g_87,&g_87,(void*)0,&g_87},{&g_87,&g_87,&g_87,&g_87},{&g_87,&g_87,(void*)0,&g_87}},{{&g_87,&g_87,&g_87,&g_87},{&g_87,&g_87,&g_87,&g_87},{&g_87,&g_87,(void*)0,&g_87},{&g_87,&g_87,&g_87,(void*)0},{&g_87,&g_87,&g_87,&g_87},{&g_87,&g_87,&g_87,&g_87}},{{(void*)0,&g_87,(void*)0,&g_87},{&g_87,&g_87,&g_87,&g_87},{&g_87,&g_87,(void*)0,&g_87},{&g_87,&g_87,(void*)0,&g_87},{&g_87,&g_87,&g_87,&g_87},{&g_87,(void*)0,(void*)0,&g_87}},{{(void*)0,&g_87,&g_87,&g_87},{&g_87,&g_87,&g_87,&g_87},{&g_87,&g_87,&g_87,(void*)0},{&g_87,&g_87,&g_87,&g_87},{&g_87,(void*)0,&g_87,(void*)0},{&g_87,&g_87,&g_87,&g_87}},{{&g_87,&g_87,&g_87,&g_87},{&g_87,(void*)0,&g_87,&g_87},{&g_87,&g_87,&g_87,(void*)0},{&g_87,&g_87,&g_87,&g_87},{&g_87,&g_87,&g_87,&g_87},{&g_87,&g_87,&g_87,(void*)0}}};
    uint64_t **l_317[8][5] = {{&l_315[2][3][1],(void*)0,&l_315[2][3][1],&l_315[5][4][1],&l_315[3][3][0]},{&l_315[2][3][1],(void*)0,(void*)0,&l_315[2][3][1],(void*)0},{&l_315[3][3][0],(void*)0,&l_315[6][0][0],&l_315[2][3][1],&l_315[2][3][1]},{&l_315[5][4][1],(void*)0,&l_315[3][3][0],&l_315[2][3][1],(void*)0},{&l_315[6][0][0],&l_315[1][5][2],&l_315[2][3][1],&l_315[2][3][1],&l_315[2][3][1]},{&l_315[1][5][2],&l_315[5][4][1],&l_315[1][5][2],&l_315[2][3][1],&l_315[2][3][1]},{&l_315[1][5][2],&l_315[2][3][1],&l_315[2][3][1],&l_315[5][4][1],&l_315[2][3][1]},{&l_315[6][0][0],&l_315[2][3][1],(void*)0,(void*)0,&l_315[4][0][1]}};
    int8_t *l_326 = &g_150;
    uint16_t *l_332 = &g_285;
    int64_t *l_335 = &g_77[9];
    struct S0 *l_368[9][7][4] = {{{&g_385,&g_388,&g_371,&g_375},{&g_383,&g_388,&g_372,&g_379},{&g_388,&g_373,&g_381,(void*)0},{&g_378,&g_387,&g_374,(void*)0},{&g_375,&g_386,&g_375,&g_388},{&g_380,&g_371,&g_384,&g_375},{&g_370,&g_384,&g_376,&g_371}},{{&g_388,&g_382,&g_376,&g_372},{&g_370,&g_387,&g_384,&g_381},{&g_380,&g_377[3],&g_375,&g_374},{&g_375,&g_374,&g_374,&g_375},{&g_378,&g_379,&g_381,&g_384},{&g_388,&g_369,&g_372,&g_376},{&g_383,&g_387,&g_371,&g_376}},{{&g_385,&g_369,&g_375,&g_384},{(void*)0,&g_379,&g_388,&g_375},{&g_387,&g_374,(void*)0,&g_374},{&g_388,&g_377[3],(void*)0,&g_381},{(void*)0,&g_387,&g_379,&g_372},{&g_389,&g_382,&g_375,&g_371},{&g_389,&g_384,&g_379,&g_375}},{{(void*)0,&g_371,(void*)0,&g_388},{&g_388,&g_386,(void*)0,(void*)0},{&g_387,&g_387,&g_388,(void*)0},{(void*)0,&g_373,&g_375,&g_379},{&g_385,&g_388,&g_371,&g_375},{&g_383,&g_388,&g_372,&g_379},{&g_388,&g_373,&g_381,(void*)0}},{{&g_378,&g_388,&g_375,&g_386},{&g_376,&g_387,&g_376,&g_389},{&g_381,(void*)0,&g_385,&g_376},{&g_371,&g_385,&g_377[3],(void*)0},{&g_389,&g_383,&g_377[3],&g_373},{&g_371,&g_388,&g_385,&g_382},{&g_381,&g_378,&g_376,&g_375}},{{&g_376,&g_375,&g_375,&g_376},{&g_379,&g_380,&g_382,&g_385},{&g_389,&g_370,&g_373,&g_377[3]},{&g_384,&g_388,(void*)0,&g_377[3]},{(void*)0,&g_370,&g_376,&g_385},{&g_372,&g_380,&g_389,&g_376},{&g_388,&g_375,&g_386,&g_375}},{{&g_389,&g_378,&g_369,&g_382},{&g_374,&g_388,&g_380,&g_373},{(void*)0,&g_383,&g_376,(void*)0},{(void*)0,&g_385,&g_380,&g_376},{&g_374,(void*)0,&g_369,&g_389},{&g_389,&g_387,&g_386,&g_386},{&g_388,&g_388,&g_389,&g_369}},{{&g_372,(void*)0,&g_376,&g_380},{(void*)0,&g_389,(void*)0,&g_376},{&g_384,&g_389,&g_373,&g_380},{&g_389,(void*)0,&g_382,&g_369},{&g_379,&g_388,&g_375,&g_386},{&g_376,&g_387,&g_376,&g_389},{&g_381,(void*)0,&g_385,&g_376}},{{&g_371,&g_385,&g_377[3],(void*)0},{&g_389,&g_383,&g_377[3],&g_373},{&g_371,&g_388,&g_385,&g_382},{&g_381,&g_378,&g_376,&g_375},{&g_376,&g_375,&g_375,&g_376},{&g_379,&g_380,&g_382,&g_385},{&g_389,&g_370,&g_373,&g_377[3]}}};
    struct S2 *l_442 = (void*)0;
    int32_t l_489[4][1] = {{0x6672B9D6L},{0x44C6BAE8L},{0x6672B9D6L},{0x44C6BAE8L}};
    int32_t l_496 = 5L;
    struct S0 ***l_506 = &g_505;
    int16_t *l_507 = &g_139;
    const int32_t l_516 = 0x878C925CL;
    struct S2 l_578[5] = {{0x10L,4,-6L,0x6EL,1L,0x97F5L},{0x10L,4,-6L,0x6EL,1L,0x97F5L},{0x10L,4,-6L,0x6EL,1L,0x97F5L},{0x10L,4,-6L,0x6EL,1L,0x97F5L},{0x10L,4,-6L,0x6EL,1L,0x97F5L}};
    int32_t **l_584 = &g_12;
    int32_t ***l_583 = &l_584;
    uint8_t l_629 = 248UL;
    int i, j, k;
lbl_517:
    if ((((g_318 = (((void*)0 != l_314[1][1][0]) , (g_316 = l_315[2][3][1]))) != &g_87) || (safe_lshift_func_uint16_t_u_u((g_238[2][3][0] ^ (~(0L != (((safe_sub_func_uint64_t_u_u(((safe_mul_func_int8_t_s_s(((*l_326) = g_226.f0), (((*l_335) |= (safe_mul_func_uint16_t_u_u((!(safe_lshift_func_uint16_t_u_u((++(*l_332)), 13))), (g_130 <= p_50)))) || 18446744073709551615UL))) >= g_106), p_51)) >= g_108) >= p_51)))), 6))))
    { /* block id: 131 */
        uint32_t l_343 = 7UL;
        uint32_t *l_346 = (void*)0;
        uint8_t *l_354[8][9] = {{&g_128,&g_130,&g_223[0][4][3],&g_223[0][3][1],&g_223[0][2][9],&g_223[0][3][0],&g_128,(void*)0,&g_223[0][2][6]},{&g_130,&g_130,(void*)0,&g_81,(void*)0,&g_130,&g_128,&g_130,&g_223[0][2][6]},{&g_130,&g_81,&g_223[0][2][6],(void*)0,&g_130,&g_223[0][4][3],&g_130,(void*)0,&g_223[0][2][6]},{&g_130,&g_130,&g_223[0][3][0],&g_130,&g_130,&g_223[0][2][6],&g_130,&g_223[0][3][1],&g_223[0][2][6]},{&g_130,&g_130,(void*)0,&g_130,&g_130,&g_223[0][2][6],&g_223[0][3][1],&g_128,&g_128},{&g_128,&g_128,&g_130,&g_223[0][2][6],&g_128,&g_130,(void*)0,&g_128,&g_130},{&g_128,&g_81,&g_130,(void*)0,(void*)0,&g_130,&g_81,&g_128,&g_130},{&g_81,&g_223[0][2][6],&g_128,(void*)0,&g_81,&g_223[0][2][9],(void*)0,&g_128,&g_130}};
        int32_t l_355 = 0x0CA74BF8L;
        int32_t l_356 = 0x600A8832L;
        struct S2 l_410 = {255UL,3,0xC7D884C1L,0x80L,0xCDL,1UL};
        uint64_t l_427 = 0xAB5186185353FDE5LL;
        const int32_t l_460[7] = {0x24780B85L,0x24780B85L,0x24780B85L,0x24780B85L,0x24780B85L,0x24780B85L,0x24780B85L};
        int i, j;
        l_356 ^= (((safe_lshift_func_uint8_t_u_s(((safe_mul_func_int16_t_s_s((safe_unary_minus_func_int64_t_s(((safe_rshift_func_uint16_t_u_u(l_343, 9)) < ((((safe_mod_func_uint32_t_u_u((g_347[7][3] |= (g_124 == (void*)0)), p_50)) | ((l_355 ^= (((safe_rshift_func_int16_t_s_u((safe_rshift_func_uint8_t_u_u((((*l_335) = 1L) < (p_53 = (g_100 , (8L != g_142)))), ((0x067A72BEL != p_52) > 1UL))), 8)) , g_142) | g_98[0])) > p_50)) , p_50) >= p_50)))), g_128)) ^ g_107), 7)) <= (*g_12)) != 0xDAL);
        for (g_104 = 0; (g_104 == (-17)); g_104 = safe_sub_func_uint8_t_u_u(g_104, 3))
        { /* block id: 139 */
            const int8_t l_412 = 1L;
            uint64_t l_439 = 1UL;
            const int32_t *l_440 = &l_356;
            int32_t l_463[8] = {6L,6L,6L,6L,6L,6L,6L,6L};
            int i;
            for (p_53 = (-26); (p_53 == 29); p_53 = safe_add_func_int32_t_s_s(p_53, 7))
            { /* block id: 142 */
                int32_t l_411[6][7] = {{0xB6E0478CL,(-1L),0xB6E0478CL,2L,0x6E20DDF8L,(-1L),0x1481EF6CL},{(-1L),0L,0xB6E0478CL,(-2L),0xD6BB534FL,(-2L),0xB6E0478CL},{0x6E20DDF8L,0x6E20DDF8L,(-2L),0x02E7B641L,0xAAE05D80L,(-1L),(-1L)},{0x02E7B641L,0x6E20DDF8L,0xF5BE769DL,(-1L),(-1L),0xF5BE769DL,0x6E20DDF8L},{0xF5BE769DL,0L,0x6E20DDF8L,0xB6E0478CL,0xAAE05D80L,2L,0x02E7B641L},{0xF5BE769DL,(-1L),0xD6BB534FL,0x6E20DDF8L,0xD6BB534FL,(-1L),0xF5BE769DL}};
                int i, j;
                for (g_192 = 0; (g_192 <= 3); g_192 += 1)
                { /* block id: 145 */
                    int32_t *l_363 = &g_102;
                    struct S0 *l_365 = &g_366;
                    int32_t l_398 = 0xB53279B8L;
                    for (g_128 = 0; (g_128 <= 4); g_128 += 1)
                    { /* block id: 148 */
                        int32_t **l_364 = &l_363;
                        struct S0 **l_367 = (void*)0;
                        l_355 ^= (g_93 , ((safe_mul_func_uint16_t_u_u(p_50, (-1L))) != g_226.f7));
                        (*l_364) = l_363;
                        l_368[8][3][0] = l_365;
                    }
                    for (g_145 = 3; (g_145 >= 0); g_145 -= 1)
                    { /* block id: 155 */
                        int32_t l_413 = 2L;
                        struct S1 *l_414 = &g_415[1];
                        int i, j, k;
                        g_98[0] &= (safe_sub_func_uint32_t_u_u((safe_mul_func_uint8_t_u_u((((safe_mul_func_uint8_t_u_u((safe_sub_func_uint8_t_u_u(l_398, 255UL)), ((((((((safe_div_func_uint8_t_u_u((g_373.f4 = (safe_lshift_func_uint8_t_u_u((safe_mod_func_uint64_t_u_u((g_384.f0 = ((l_317[(g_192 + 1)][(g_145 + 1)] = l_317[g_192][g_192]) == &l_315[g_145][(g_192 + 2)][g_192])), 6UL)), 3))), ((safe_add_func_int64_t_s_s(((!(4294967295UL < ((((safe_add_func_uint8_t_u_u(((0x76L == (l_410 , (g_150 = (-1L)))) == (*g_12)), p_50)) && l_411[2][6]) | p_53) == 0x582BA67BA996522ALL))) ^ p_51), p_50)) , l_412))) >= l_413) >= l_412) , (void*)0) == l_414) < g_369.f2) , p_52) != (*l_363)))) == (*g_171)) | 0x3467350298685D49LL), g_382.f3)), p_53));
                    }
                }
            }
            if ((p_51 & g_369.f3))
            { /* block id: 164 */
                return l_412;
            }
            else
            { /* block id: 166 */
                struct S2 l_421 = {0x21L,5,0x78BF05DAL,0x6DL,-1L,0x8A6AL};
                const int32_t **l_445 = &l_440;
                if ((*g_12))
                    break;
                for (g_372.f0 = 0; (g_372.f0 <= 52); g_372.f0 = safe_add_func_uint16_t_u_u(g_372.f0, 9))
                { /* block id: 170 */
                    int16_t *l_424 = &g_145;
                    uint16_t **l_425[4];
                    struct S2 *l_444 = (void*)0;
                    int i;
                    for (i = 0; i < 4; i++)
                        l_425[i] = &l_332;
                    l_355 |= (safe_rshift_func_int8_t_s_u(((0xCAD40BC0L && ((~((l_421 , ((safe_add_func_int16_t_s_s((g_142 = p_50), ((*l_424) ^= ((p_53 , (void*)0) != &g_139)))) , (void*)0)) == (p_50 , (g_426[2] = &g_285)))) > l_421.f0)) < g_380.f0), 0));
                    if (l_427)
                        continue;
                    if ((((safe_unary_minus_func_int8_t_s((p_50 > (((5UL ^ (!((-1L) <= ((g_430[4][1] != g_430[3][3]) != ((+l_412) == (l_439 >= (0xDB6749C9L | 0x5CBE0D11L))))))) ^ l_410.f4) >= (*g_12))))) == l_410.f2) != 0x454FA5633EEFDE23LL))
                    { /* block id: 176 */
                        int8_t l_441 = 7L;
                        l_440 = (void*)0;
                        if ((*g_12))
                            continue;
                        if (l_441)
                            break;
                    }
                    else
                    { /* block id: 180 */
                        struct S2 **l_443[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                        int i;
                        l_444 = l_442;
                    }
                }
                (*l_445) = l_440;
            }
            if ((*g_171))
                break;
            for (l_410.f5 = (-23); (l_410.f5 <= 55); l_410.f5 = safe_add_func_uint64_t_u_u(l_410.f5, 8))
            { /* block id: 189 */
                uint64_t l_448 = 18446744073709551608UL;
                uint16_t **l_453 = &g_426[2];
                if (l_448)
                    break;
                if (p_50)
                    break;
                if ((safe_div_func_int32_t_s_s((((safe_add_func_int64_t_s_s(((((*l_453) = &g_285) != (void*)0) , ((((((safe_mod_func_uint8_t_u_u(((((p_50 >= ((safe_mod_func_int32_t_s_s((((g_384.f3 != (6L && p_52)) ^ (safe_sub_func_int16_t_s_s((l_460[6] <= g_226.f3), ((safe_rshift_func_int16_t_s_s(((((l_463[3] = 251UL) == p_53) && 4294967295UL) <= p_52), 2)) > l_448)))) | g_387.f3), g_374.f2)) || l_448)) > p_52) < g_377[3].f4) == 0x16E4CA60F462A030LL), p_51)) & l_448) ^ 0xAE6E3A79080C145BLL) , 0x7605L) , 0x8A63L) , (-5L))), 0x03FA2C9563871B06LL)) , 6L) ^ (-7L)), 0x2B9F7136L)))
                { /* block id: 194 */
                    int32_t *l_470[2][2][8] = {{{&g_370.f2,&g_102,&g_370.f2,&g_386.f2,(void*)0,&g_386.f2,&g_370.f2,&g_102},{(void*)0,&g_386.f2,&g_370.f2,&g_102,&g_370.f2,&g_386.f2,(void*)0,&g_386.f2}},{{(void*)0,&g_102,(void*)0,&g_102,(void*)0,&g_387.f2,(void*)0,&g_102},{&g_370.f2,&g_102,&g_370.f2,&g_386.f2,(void*)0,&g_386.f2,&g_370.f2,&g_102}}};
                    int32_t **l_471 = &l_470[1][0][5];
                    int i, j, k;
                    l_355 = (p_50 , (((safe_add_func_uint64_t_u_u(((l_448 & (safe_lshift_func_int16_t_s_s((safe_add_func_uint8_t_u_u((((p_51 >= p_50) ^ (((*l_471) = l_470[1][0][5]) == &l_355)) , ((((p_50 | p_50) > (safe_rshift_func_int16_t_s_s(0xBB0BL, g_93.f4))) > (-7L)) < l_448)), p_52)), 5))) != 1UL), p_53)) , (*g_12)) , (*g_12)));
                    l_356 = 0L;
                }
                else
                { /* block id: 198 */
                    return l_355;
                }
            }
        }
    }
    else
    { /* block id: 203 */
        int16_t l_477 = 6L;
        uint8_t **l_482 = (void*)0;
        uint8_t *l_485 = &g_379.f4;
        uint8_t **l_484 = &l_485;
        uint8_t *l_487 = &g_369.f4;
        uint8_t **l_486 = &l_487;
        int16_t *l_488 = &g_142;
        l_489[2][0] ^= ((*g_171) >= ((!(((void*)0 == &p_53) > ((p_52 , (safe_add_func_uint16_t_u_u(((l_477 = p_51) , 0x880BL), (((safe_mul_func_int16_t_s_s(((*l_488) = ((safe_div_func_int8_t_s_s(((((*l_484) = (g_483 = &g_223[0][6][8])) != ((*l_486) = &g_81)) != p_52), 1UL)) != g_388.f2)), g_366.f3)) | 4L) < p_51)))) >= 0x48DF726125C4F4C3LL))) , 0xBF514B13L));
    }
    if ((safe_sub_func_uint64_t_u_u(0x648D43D2CF794A44LL, (g_382.f0 ^= (safe_mod_func_int8_t_s_s((0x69C082741DBB1BC9LL > (safe_div_func_uint32_t_u_u((l_496 && (((((safe_rshift_func_uint8_t_u_s(((*g_483)--), (+(safe_div_func_uint16_t_u_u((~((*l_507) = (((*l_506) = g_505) == (void*)0))), (safe_sub_func_int8_t_s_s(((*l_326) &= 0L), (safe_rshift_func_int8_t_s_s((((*g_171) <= (g_377[3].f2 = (safe_lshift_func_int8_t_s_u((((safe_sub_func_uint16_t_u_u((((7UL != ((p_50 || p_50) | p_53)) , &l_315[6][4][1]) == &l_315[2][3][1]), g_142)) , g_369.f0) , p_50), p_51)))) , g_377[3].f2), 1))))))))) < p_50) > l_516) ^ 0x45L) & 0xDBF40DD8B76CBBDBLL)), g_375.f3))), 0xB7L))))))
    { /* block id: 217 */
lbl_556:
        if (g_285)
            goto lbl_517;
    }
    else
    { /* block id: 219 */
        uint64_t l_521 = 0x17378FAE77A61D2CLL;
        int32_t *l_530 = &g_381.f2;
        struct S0 ***l_536 = (void*)0;
        int32_t l_548 = 0L;
        int32_t **l_550[3];
        int32_t ***l_549 = &l_550[2];
        uint64_t l_553 = 0x5F85B3631E309BDFLL;
        int i;
        for (i = 0; i < 3; i++)
            l_550[i] = (void*)0;
        for (g_145 = (-9); (g_145 != 12); g_145++)
        { /* block id: 222 */
            int16_t l_520[3][8][9] = {{{0x713FL,(-6L),0x13C3L,0x87CCL,0xA431L,(-3L),0xB491L,0xD751L,0L},{(-1L),(-7L),0xB2F2L,0xF941L,(-6L),0x0DCFL,(-10L),(-7L),0x2BDDL},{0xA9E2L,(-6L),1L,0x7A6FL,0x3AE5L,0x0DF3L,(-8L),0x13C3L,(-1L)},{0x6409L,0x0DCFL,6L,0xB7AFL,0xBE30L,6L,0xF941L,0x7F15L,0x8982L},{0xA9E2L,0x3AE5L,0L,0xEBCEL,1L,0xFF15L,0x8A58L,0x4719L,0x4719L},{(-1L),0xDB5CL,5L,0x6409L,5L,0xDB5CL,(-1L),0xA514L,0x8982L},{0x713FL,0x13C3L,0xB773L,(-8L),0x4719L,1L,8L,0x3AE5L,(-1L)},{0x2163L,(-1L),5L,0L,0x8E2AL,0x5E79L,0xA514L,0L,(-9L)}},{{0xB773L,0x4A31L,(-1L),(-10L),0x9E39L,1L,0x3AE5L,5L,1L},{0xDB5CL,1L,(-9L),5L,(-1L),0xE374L,0xA514L,8L,0L},{0L,5L,0xE2E6L,(-1L),0x4A31L,6L,0x4719L,6L,0x4A31L},{0xA514L,0xCE6DL,0xCE6DL,0xA514L,0xD44AL,0xE374L,0x7F15L,0x5E79L,7L},{0xFF15L,(-1L),0xD362L,0xB773L,(-1L),1L,0x13C3L,(-1L),0xE2E6L},{(-5L),0xF836L,0xE1FAL,(-1L),0xD44AL,0x5E79L,(-7L),0xE863L,0xE374L},{1L,0x57BFL,(-1L),(-6L),0x4A31L,0x52E3L,0xD751L,0x3E66L,(-1L)},{0x2BDDL,0xE374L,0xF836L,(-1L),(-1L),0xE1FAL,0xBE30L,(-9L),0xCE6DL}},{{0x4719L,(-8L),0x52E3L,0xB773L,0x9E39L,0x9E39L,0xB773L,0x52E3L,(-8L)},{6L,8L,0xF836L,0xA514L,0x8E2AL,0x6F19L,0x2BDDL,7L,0xD44AL},{(-6L),0xD422L,(-1L),(-1L),5L,(-8L),1L,0xD422L,0x3E66L},{0L,8L,0xE1FAL,5L,0xE374L,0L,0xB2F2L,0xF836L,0x5E79L},{0x1F9DL,(-8L),0xD362L,(-10L),0x52E3L,0xD362L,(-1L),0xE18DL,(-1L)},{0L,0xE374L,0xCE6DL,0xDB5CL,0xE863L,0L,0L,1L,1L},{(-6L),0x57BFL,0xE2E6L,0x1F9DL,0xE2E6L,0x57BFL,(-6L),0x9E39L,(-1L)},{6L,0xF836L,(-9L),0x8982L,1L,0xE863L,(-6L),0xE374L,0x5E79L}}};
            struct S0 ***l_540 = &g_505;
            int32_t l_551 = 0x71C15C1CL;
            int32_t l_552 = 3L;
            int i, j, k;
            for (g_373.f5 = 1; (g_373.f5 <= 4); g_373.f5 += 1)
            { /* block id: 225 */
                uint32_t l_533 = 5UL;
                int32_t l_547[6] = {0x3A14D9B1L,0x3A14D9B1L,0x3A14D9B1L,0x3A14D9B1L,0x3A14D9B1L,0x3A14D9B1L};
                int i;
                for (g_380.f3 = 0; (g_380.f3 <= 4); g_380.f3 += 1)
                { /* block id: 228 */
                    uint32_t *l_531 = &g_532;
                    struct S0 ***l_539 = &g_505;
                    for (g_366.f5 = 0; (g_366.f5 <= 3); g_366.f5 += 1)
                    { /* block id: 231 */
                        l_521--;
                    }
                    g_382.f2 = (safe_sub_func_uint16_t_u_u(p_50, ((safe_add_func_uint8_t_u_u((((*g_483) = (0xFBCA9A83493F199DLL & (safe_mod_func_int32_t_s_s(((void*)0 == l_530), ((*l_531) = 0xA96D1137L))))) , ((--l_533) ^ ((void*)0 != l_536))), (safe_sub_func_int32_t_s_s(((l_540 = l_539) != ((safe_add_func_uint16_t_u_u(((((safe_sub_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u(250UL, 4)), l_547[0])) != p_51) , p_52) <= l_548), l_520[0][3][4])) , (void*)0)), l_547[0])))) != p_53)));
                    g_97 = (l_549 != (void*)0);
                    if (l_520[0][3][4])
                        continue;
                }
            }
            --l_553;
        }
        if (l_516)
            goto lbl_556;
    }
    for (g_372.f0 = 5; (g_372.f0 > 36); ++g_372.f0)
    { /* block id: 249 */
        uint32_t l_567 = 0x7FB6E91EL;
        int32_t l_568 = 0L;
        int16_t l_579 = 4L;
        uint32_t *l_580 = &g_532;
        int32_t l_581 = (-8L);
        l_581 ^= (((*l_580) ^= (safe_mul_func_uint16_t_u_u(((*l_332) = ((safe_add_func_int16_t_s_s((0xE6CE5293A0FC3BDALL && ((safe_lshift_func_int8_t_s_s((safe_rshift_func_uint8_t_u_s(p_53, (((l_568 = l_567) == (safe_lshift_func_int16_t_s_u(g_20, (safe_mod_func_int64_t_s_s((+((safe_mod_func_int8_t_s_s((~p_53), g_577)) != ((9L > (l_578[4] , ((*g_171) != 0x95FC30B4L))) | 0xA7L))), p_50))))) , l_579))), p_50)) ^ p_52)), 8L)) != (-1L))), 0x7F2AL))) | 0L);
    }
    for (g_376.f3 = 0; (g_376.f3 <= 3); g_376.f3 += 1)
    { /* block id: 257 */
        uint16_t l_582[10][7][1] = {{{65530UL},{65530UL},{65531UL},{0x99D3L},{0x11D9L},{0xD0A8L},{0xCC4CL}},{{65530UL},{0x3586L},{0x3BDBL},{0x985AL},{0xF118L},{0xD54EL},{0x1B5FL}},{{0x28CAL},{1UL},{0x28CAL},{0x1B5FL},{0xD54EL},{0xF118L},{0x985AL}},{{0x3BDBL},{0x3586L},{65530UL},{0xCC4CL},{0xD0A8L},{0x11D9L},{0x99D3L}},{{65531UL},{65530UL},{65530UL},{65531UL},{0x99D3L},{0x11D9L},{0xD0A8L}},{{0xCC4CL},{0UL},{0x1B5FL},{0x3586L},{0xD54EL},{1UL},{65530UL}},{{65527UL},{65532UL},{0xD0A8L},{65532UL},{65527UL},{65530UL},{1UL}},{{0xD54EL},{0x3586L},{0x1B5FL},{0UL},{0x3BDBL},{0x566AL},{65535UL}},{{0UL},{65530UL},{65530UL},{65530UL},{65530UL},{0UL},{65535UL}},{{0x566AL},{0x3BDBL},{0UL},{0x1B5FL},{0x3586L},{0xD54EL},{1UL}}};
        struct S0 * const l_585 = &g_586;
        int32_t l_588 = 1L;
        struct S2 *l_602[10] = {&l_578[4],&l_578[0],&l_578[2],&l_578[0],&l_578[4],&l_578[4],&l_578[0],&l_578[2],&l_578[0],&l_578[4]};
        struct S2 **l_633 = &l_602[0];
        int32_t l_663[8];
        uint8_t * const *l_682[2][5][5] = {{{&g_483,&g_483,(void*)0,&g_483,&g_483},{&g_483,&g_483,&g_483,&g_483,&g_483},{(void*)0,&g_483,(void*)0,&g_483,&g_483},{(void*)0,&g_483,&g_483,&g_483,&g_483},{&g_483,&g_483,&g_483,(void*)0,&g_483}},{{&g_483,(void*)0,&g_483,&g_483,&g_483},{(void*)0,&g_483,&g_483,&g_483,&g_483},{(void*)0,(void*)0,(void*)0,(void*)0,&g_483},{&g_483,&g_483,(void*)0,&g_483,&g_483},{&g_483,&g_483,&g_483,(void*)0,(void*)0}}};
        int i, j, k;
        for (i = 0; i < 8; i++)
            l_663[i] = 0x432E30CCL;
        for (g_376.f2 = 3; (g_376.f2 >= 0); g_376.f2 -= 1)
        { /* block id: 260 */
            struct S2 l_592 = {255UL,4,0xAF7E29DEL,1L,-1L,0xB337L};
            int64_t **l_623[5];
            int16_t l_666 = 0xB8A4L;
            int32_t l_667 = 0x6647AD31L;
            int i;
            for (i = 0; i < 5; i++)
                l_623[i] = &l_335;
            g_110[g_376.f2] = (((*g_483) && (g_384.f3 | ((l_582[5][2][0] , l_583) != &l_584))) <= (l_585 != (void*)0));
            for (g_383.f5 = 0; (g_383.f5 <= 3); g_383.f5 += 1)
            { /* block id: 264 */
                int32_t l_591[8] = {1L,(-1L),1L,(-1L),1L,(-1L),1L,(-1L)};
                struct S2 *l_600 = &l_578[1];
                struct S2 **l_601 = &l_442;
                int64_t **l_622 = &l_335;
                int64_t ***l_621 = &l_622;
                int32_t l_628 = 1L;
                int32_t **l_640[4][1];
                uint64_t *l_657 = &g_388.f0;
                int i, j;
                for (i = 0; i < 4; i++)
                {
                    for (j = 0; j < 1; j++)
                        l_640[i][j] = &g_12;
                }
                for (g_385.f3 = 0; (g_385.f3 <= 3); g_385.f3 += 1)
                { /* block id: 267 */
                    return g_380.f5;
                }
                g_110[g_376.f2] = (l_588 = (!p_50));
                l_588 &= (((safe_add_func_uint64_t_u_u((p_53 & ((l_591[4] = p_53) <= ((g_104 <= (l_592 , (((!(-4L)) > (safe_mul_func_uint16_t_u_u((((safe_div_func_uint16_t_u_u((((void*)0 == &g_87) & (((g_384.f5 || (0xF6L || (*g_483))) > (***l_583)) , p_52)), p_50)) | 0x2E2588C1339E6DC1LL) > l_582[5][2][0]), p_50))) < p_50))) && (-2L)))), p_50)) , 0x932966C4L) != p_53);
                l_588 |= (((safe_add_func_int16_t_s_s(((((*l_601) = l_600) != ((***l_583) , l_602[0])) <= ((((((*l_335) |= (safe_mul_func_int8_t_s_s(((safe_mul_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u((safe_mul_func_int8_t_s_s((safe_sub_func_int16_t_s_s(0x5133L, (safe_rshift_func_uint8_t_u_u(l_582[8][1][0], 3)))), ((safe_add_func_int16_t_s_s(((p_50 = ((l_591[6] = (((safe_div_func_uint32_t_u_u((safe_mul_func_int16_t_s_s(((((*l_621) = &g_208[3][1][8]) != l_623[4]) | ((safe_sub_func_uint32_t_u_u((safe_sub_func_int8_t_s_s(((*l_326) = (0xC8EC0FBE5C13308FLL <= 2L)), 0x61L)), 0x3838DF57L)) , l_592.f1)), l_592.f3)), 5UL)) < l_591[6]) <= g_379.f0)) < l_592.f0)) | g_378.f5), 0x670EL)) < 1L))), 0xB99EL)), 1UL)) && g_369.f4), (*g_483)))) , &g_150) != g_483) ^ (*g_483)) | l_628)), l_629)) & l_582[5][2][0]) > 18446744073709551615UL);
                for (g_378.f4 = 0; (g_378.f4 <= 3); g_378.f4 += 1)
                { /* block id: 283 */
                    struct S2 ***l_632[6][7] = {{(void*)0,&l_601,&l_601,&l_601,&l_601,(void*)0,&l_601},{(void*)0,&l_601,(void*)0,(void*)0,&l_601,&l_601,&l_601},{&l_601,&l_601,&l_601,&l_601,&l_601,&l_601,&l_601},{&l_601,&l_601,(void*)0,&l_601,&l_601,&l_601,&l_601},{(void*)0,&l_601,&l_601,&l_601,(void*)0,&l_601,&l_601},{(void*)0,(void*)0,(void*)0,(void*)0,&l_601,&l_601,&l_601}};
                    int32_t l_664 = 0L;
                    int32_t l_665 = 0x7856E9D2L;
                    int i, j;
                    if (((safe_mul_func_int16_t_s_s(g_381.f2, (((*l_507) |= (((&l_602[1] != (l_633 = &l_442)) > 0x2160BC1BL) ^ (safe_add_func_int64_t_s_s((((safe_lshift_func_uint16_t_u_s((safe_mul_func_uint16_t_u_u((p_53 , (&g_171 != ((*l_583) = l_640[3][0]))), ((safe_rshift_func_uint8_t_u_s(p_53, 3)) != ((safe_mod_func_uint8_t_u_u(((*g_483) = ((safe_sub_func_int64_t_s_s((safe_sub_func_int64_t_s_s((((+g_110[g_376.f2]) > 0x9556L) < 0x5D81L), p_50)), 0UL)) ^ 3L)), l_582[9][1][0])) >= 0x6BB1L)))), 4)) <= g_379.f3) && 4UL), l_588)))) ^ p_51))) , l_582[6][5][0]))
                    { /* block id: 288 */
                        int64_t l_650 = 0x86A636E1EA6563A2LL;
                        if (l_650)
                            break;
                        (**l_583) = &g_106;
                    }
                    else
                    { /* block id: 291 */
                        uint64_t l_651 = 18446744073709551615UL;
                        if ((*g_12))
                            break;
                        if ((*g_171))
                            break;
                        g_99[0][4] ^= p_53;
                        ++l_651;
                    }
                    l_667 &= ((+((safe_mul_func_int8_t_s_s(l_582[4][4][0], ((void*)0 != l_657))) && (safe_mod_func_int16_t_s_s((((+(((l_592 , (void*)0) != l_632[0][4]) <= (((p_52 = p_51) <= (safe_rshift_func_int8_t_s_s((((l_588 |= ((l_663[5] | 0xCAL) , l_664)) < l_665) <= (*g_483)), 0))) >= (-4L)))) || 2L) , 0xC001L), l_666)))) <= 0x84A1C42F66282526LL);
                }
            }
        }
        for (g_387.f0 = 0; (g_387.f0 <= 3); g_387.f0 += 1)
        { /* block id: 305 */
            uint64_t l_668 = 0x47E0EC75A82F64E6LL;
            struct S2 ** const *l_701 = &l_633;
            int32_t l_715 = 0L;
            uint8_t *l_716 = &g_384.f4;
            l_668 = (*g_12);
            for (g_383.f2 = 3; (g_383.f2 >= 0); g_383.f2 -= 1)
            { /* block id: 309 */
                uint16_t l_671 = 0x6A37L;
                int32_t l_676 = 0xACE615C6L;
                int32_t l_681 = (-2L);
                uint8_t * const **l_705 = &l_682[1][1][2];
            }
        }
    }
    return g_415[1].f6;
}


/* ------------------------------------------ */
/* 
 * reads : g_22 g_81 g_93 g_12 g_2 g_17 g_98 g_102 g_124 g_100 g_106 g_110 g_145 g_142 g_20 g_103 g_101 g_77 g_7 g_99 g_87 g_107 g_171 g_128 g_21 g_238 g_130 g_226.f6 g_226.f0 g_208
 * writes: g_77 g_81 g_87 g_128 g_130 g_110 g_139 g_142 g_145 g_150 g_108 g_171 g_107 g_192 g_208 g_98 g_102 g_223 g_238 g_285
 */
static int8_t  func_56(int8_t  p_57, int32_t * p_58, int32_t  p_59, int32_t ** p_60, const int32_t * p_61)
{ /* block id: 14 */
    uint32_t l_65 = 0x0C7F43A4L;
    int64_t *l_76 = &g_77[9];
    uint8_t *l_80 = &g_81;
    int32_t **l_85 = &g_12;
    int32_t ***l_84 = &l_85;
    int32_t **l_86 = &g_12;
    uint8_t *l_136 = (void*)0;
    uint8_t *l_137 = &g_130;
    int16_t *l_138 = &g_139;
    int16_t *l_140 = (void*)0;
    int16_t *l_141 = &g_142;
    int16_t *l_143 = (void*)0;
    int16_t *l_144 = &g_145;
    int32_t l_148 = 1L;
    int8_t *l_149 = &g_150;
    uint32_t *l_154 = (void*)0;
    int32_t l_164 = (-5L);
    int32_t l_219 = (-1L);
    int64_t *l_224 = &g_77[2];
    int32_t l_230 = 9L;
    int32_t l_233 = 1L;
    int32_t l_234 = 3L;
    int32_t l_235 = 0x230FADCDL;
    int32_t l_237 = 8L;
    int64_t l_284[10] = {1L,(-10L),0xC3C3130D0C7FC063LL,(-10L),1L,1L,(-10L),0xC3C3130D0C7FC063LL,(-10L),1L};
    uint16_t l_287 = 3UL;
    int32_t l_302 = 0L;
    int32_t l_303 = 0x4B2485EEL;
    int32_t l_305 = 0x9598FA45L;
    int32_t l_306 = 0xC49F85F0L;
    uint32_t l_307 = 5UL;
    int i;
lbl_228:
    ++l_65;
    if ((safe_lshift_func_uint8_t_u_s((g_22[1] != (safe_add_func_int16_t_s_s(0x3EE7L, ((safe_lshift_func_int16_t_s_u((((safe_sub_func_int64_t_s_s((-1L), ((*l_76) = 0x59DFF04C396C7BFBLL))) || g_22[7]) <= (l_76 != l_76)), (((l_65 < (g_87 = (safe_mul_func_uint8_t_u_u(((((*l_80)++) , ((*l_84) = &p_58)) == l_86), (-1L))))) , p_59) ^ 0x652606BDE5E333ABLL))) <= 0xDF13F3F2C75BC628LL)))), g_22[1])))
    { /* block id: 20 */
        uint8_t l_88 = 1UL;
        return l_88;
    }
    else
    { /* block id: 22 */
        int32_t * const l_96[6][9] = {{&g_102,&g_103,&g_105,&g_108,&g_98[0],&g_102,&g_108,&g_100,&g_108},{&g_108,&g_106,&g_105,&g_105,&g_106,&g_108,&g_97,&g_100,&g_105},{&g_102,&g_98[0],&g_108,&g_105,&g_103,&g_102,&g_102,&g_103,&g_105},{&g_99[1][5],&g_106,&g_99[1][5],&g_108,&g_103,&g_99[1][5],&g_97,&g_109,&g_108},{&g_99[1][5],&g_99[1][5],&g_104,&g_110[3],&g_102,&g_110[3],&g_104,&g_99[1][5],&g_110[3]},{(void*)0,&g_99[1][5],&g_101,&g_104,&g_108,(void*)0,&g_104,&g_97,&g_104}};
        int32_t * const *l_95 = &l_96[2][7];
        int32_t * const **l_94 = &l_95;
        const int32_t l_125 = 1L;
        uint32_t *l_126 = &l_65;
        uint8_t *l_127 = &g_128;
        uint8_t *l_129 = &g_130;
        int32_t *l_132 = &g_101;
        int32_t **l_131 = &l_132;
        int i, j;
        g_110[1] ^= ((((safe_add_func_int32_t_s_s(((((*l_129) = ((*l_127) = (safe_add_func_uint32_t_u_u((((*l_94) = (g_93 , &p_58)) != &p_61), ((~(safe_lshift_func_uint16_t_u_u(((+(safe_mod_func_int32_t_s_s(((**l_86) == (((*l_126) = ((((((*l_80) ^= (**l_85)) | ((safe_sub_func_uint32_t_u_u((safe_lshift_func_uint8_t_u_s((+(safe_add_func_uint16_t_u_u(0x532EL, (1UL ^ (((&l_85 != (p_57 , g_124)) && p_57) > (***l_84)))))), l_125)), 0xD3E15E87L)) == p_57)) , p_57) <= 8L) < 1UL)) , (**l_86))), 1UL))) || (***l_84)), g_100))) == p_59))))) <= 251UL) == p_59), 4294967288UL)) >= g_106) > (***l_84)) , (*g_12));
        (*l_131) = (*l_95);
    }
    g_108 = (safe_add_func_uint8_t_u_u((((*l_137) = ((g_77[6] = (g_102 | (safe_unary_minus_func_uint16_t_u(p_59)))) , ((*l_80) = (l_76 == (void*)0)))) || ((*l_149) = (0xC20BL ^ (((((*l_144) = ((*l_141) = ((*l_138) = 0x53C8L))) , (+g_17)) && ((((+g_110[3]) != 0xCA97L) >= (***l_84)) <= g_98[0])) != l_148)))), 0L));
    for (l_148 = 14; (l_148 != (-4)); l_148 = safe_sub_func_uint64_t_u_u(l_148, 9))
    { /* block id: 41 */
        int8_t l_159[5];
        int32_t l_165[4][3] = {{7L,6L,7L},{0xFD6875ADL,0x2FC83918L,0xFD6875ADL},{7L,6L,7L},{0xFD6875ADL,0x2FC83918L,0xFD6875ADL}};
        const int32_t *l_167 = &g_168;
        const int32_t **l_166 = &l_167;
        const int32_t *l_170 = &g_99[7][5];
        const int32_t **l_169[2][7] = {{&l_170,&l_170,&l_170,&l_170,&l_170,&l_170,&l_170},{&l_170,&l_170,&l_170,&l_170,&l_170,&l_170,&l_170}};
        struct S1 *l_225 = &g_226;
        uint64_t l_244[3];
        const int32_t * const **l_257 = (void*)0;
        int i, j;
        for (i = 0; i < 5; i++)
            l_159[i] = 0x22L;
        for (i = 0; i < 3; i++)
            l_244[i] = 0UL;
        l_165[3][1] = (((*l_149) = (+((((l_154 = g_12) != (void*)0) , p_57) , p_59))) > (safe_mul_func_uint8_t_u_u((((*l_144) ^= 1L) , ((safe_add_func_int32_t_s_s(l_159[4], (*p_58))) , ((g_142 || (safe_mod_func_uint16_t_u_u((((safe_mul_func_int16_t_s_s((0x4393L >= g_93.f3), l_164)) | g_20) & g_93.f2), p_59))) < g_103))), 0x85L)));
        g_171 = ((p_57 & p_59) , ((*l_166) = &g_107));
        for (g_107 = 0; (g_107 <= 0); g_107 += 1)
        { /* block id: 50 */
            int32_t ***l_174 = &l_85;
            int32_t ****l_175 = &l_174;
            int64_t *l_206 = &g_77[6];
            int32_t l_213 = (-3L);
            struct S2 l_214 = {0xA6L,2,0xFC2D246EL,0xFCL,8L,2UL};
            int32_t l_232[9] = {(-9L),0xB5CE67DDL,0xB5CE67DDL,(-9L),0xB5CE67DDL,0xB5CE67DDL,(-9L),0xB5CE67DDL,0xB5CE67DDL};
            int8_t l_293 = (-1L);
            int32_t l_296 = 0x25CE069EL;
            uint32_t l_310 = 0UL;
            int i;
            if ((safe_lshift_func_uint8_t_u_u(((((*l_175) = l_174) == ((safe_rshift_func_uint8_t_u_u(g_101, ((-6L) && ((safe_rshift_func_int16_t_s_s((safe_rshift_func_uint16_t_u_u((0x70L != (safe_add_func_int8_t_s_s(p_57, ((safe_lshift_func_int8_t_s_s((-3L), (safe_add_func_int8_t_s_s(((safe_rshift_func_int8_t_s_u(g_93.f3, 4)) != (safe_lshift_func_uint16_t_u_s((g_192 = 0x7AA7L), (((safe_mul_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u(((((***l_84) != 0x52D2L) <= 0xA1L) , g_98[0]), g_110[3])), g_77[9])) != g_2) & g_7)))), (**l_85))))) == 0x12B3B569L)))), (*l_170))), g_7)) != g_87)))) , &p_60)) <= g_110[3]), (*l_170))))
            { /* block id: 53 */
                uint16_t l_197 = 0UL;
                uint16_t *l_201 = &l_197;
                int32_t l_202 = 0x7EC679D4L;
                int64_t *l_203[4];
                int i;
                for (i = 0; i < 4; i++)
                    l_203[i] = &g_77[9];
                if ((g_107 && ((((*g_171) || ((&l_84 == &l_84) != ((((*l_201) = ((((((g_103 | l_197) , g_7) >= p_57) || (safe_add_func_int8_t_s_s(((safe_unary_minus_func_int64_t_s(l_197)) > (***l_84)), g_101))) && 255UL) ^ p_57)) || (****l_175)) , (**l_85)))) | l_202) & (-9L))))
                { /* block id: 55 */
                    return l_197;
                }
                else
                { /* block id: 57 */
                    int64_t **l_204 = (void*)0;
                    int64_t **l_205 = &l_203[2];
                    int64_t **l_207[7][7] = {{(void*)0,&l_206,&l_76,(void*)0,&l_206,(void*)0,&l_206},{&l_206,&l_206,(void*)0,&l_76,&l_206,&l_206,&l_76},{(void*)0,&l_76,&l_76,&l_206,&l_206,&l_206,&l_76},{&l_206,&l_206,&l_206,&l_206,&l_206,&l_206,&l_206},{&l_206,&l_206,(void*)0,&l_76,&l_206,&l_76,&l_206},{(void*)0,&l_76,&l_206,(void*)0,&l_206,&l_76,&l_206},{&l_206,&l_206,&l_206,&l_206,&l_206,&l_76,(void*)0}};
                    int i, j;
                    (*l_166) = (void*)0;
                    g_98[g_107] = (((l_202 &= (((*l_205) = l_203[2]) != (g_208[3][0][4] = l_206))) , ((p_57 || (((p_59 | (safe_rshift_func_uint8_t_u_s(p_57, (safe_mul_func_uint16_t_u_u((**l_86), ((*l_144) = (g_93.f4 <= (&p_58 == &l_167)))))))) != 1UL) >= l_213)) == p_57)) == 0x1F79D74AL);
                    g_171 = ((**l_174) = &g_102);
                    for (l_197 = 0; (l_197 <= 0); l_197 += 1)
                    { /* block id: 68 */
                        int i;
                        (**l_174) = &g_98[l_197];
                    }
                }
                (**l_85) = (((l_214 , 0xD986L) >= p_57) | (safe_div_func_uint32_t_u_u((((safe_mul_func_uint16_t_u_u((g_128 <= g_21), (**l_85))) < (l_219 , 1UL)) >= ((255UL & p_59) <= 3L)), p_57)));
            }
            else
            { /* block id: 73 */
                struct S1 **l_227 = &l_225;
                for (l_214.f4 = 8; (l_214.f4 >= 2); l_214.f4 -= 1)
                { /* block id: 76 */
                    return p_59;
                }
                (*l_227) = ((safe_add_func_int64_t_s_s(((-9L) < (g_110[1] < (+p_57))), g_93.f1)) , (p_57 , ((((g_223[0][2][6] = 4294967295UL) , l_224) == (void*)0) , l_225)));
                if (g_103)
                    goto lbl_228;
            }
            l_165[3][1] = (**p_60);
            for (p_57 = 0; (p_57 <= 9); p_57 += 1)
            { /* block id: 86 */
                int32_t *l_229[8][3] = {{&g_103,&g_103,&g_100},{&g_101,&g_110[3],&g_110[3]},{&g_100,&g_97,&g_103},{&g_101,&g_107,&g_101},{&g_103,&g_100,&g_103},{&l_165[3][0],&l_165[3][0],&g_110[3]},{&g_103,&g_100,&g_100},{&g_110[3],&g_107,&g_109}};
                int8_t l_236 = 0x45L;
                int i, j;
                if ((*g_12))
                    break;
                g_238[2][3][0]--;
                return (**l_86);
            }
            for (l_235 = 9; (l_235 >= 0); l_235 -= 1)
            { /* block id: 93 */
                uint32_t *l_241 = (void*)0;
                int32_t l_251 = (-1L);
                int64_t **l_264 = &g_208[3][0][4];
                int32_t l_267 = 0L;
                int32_t l_297 = 0x2C762218L;
                int32_t l_298 = 0xBB819E39L;
                int32_t l_304 = 0x7DB3398EL;
                for (g_81 = 0; (g_81 <= 3); g_81 += 1)
                { /* block id: 96 */
                    int i;
                    if (g_110[g_107])
                        break;
                }
                for (g_130 = 0; (g_130 <= 9); g_130 += 1)
                { /* block id: 101 */
                    uint64_t *l_252[5][6] = {{&g_87,&g_87,&g_87,&g_87,(void*)0,(void*)0},{&g_87,&g_87,&g_87,&g_87,&g_87,&g_87},{&g_87,&g_87,(void*)0,&g_87,&g_87,&g_87},{&g_87,&g_87,&g_87,&g_87,&g_87,&g_87},{&g_87,&g_87,&g_87,&g_87,&g_87,&g_87}};
                    const int32_t * const ***l_258 = (void*)0;
                    const int32_t * const ***l_259 = &l_257;
                    int32_t l_291 = 0xDF456CFBL;
                    int32_t l_294 = (-6L);
                    int32_t l_295 = 0xD5484670L;
                    int32_t l_299 = 0x50456AD2L;
                    int32_t l_300 = 0x518A418FL;
                    int32_t l_301[8][1] = {{(-1L)},{1L},{1L},{(-1L)},{1L},{1L},{(-1L)},{1L}};
                    int i, j;
                    l_232[1] = (((void*)0 != l_241) > (safe_mul_func_uint8_t_u_u((++l_244[0]), (safe_div_func_int16_t_s_s(((((*l_149) = ((l_251 , (++g_87)) <= (g_226.f6 >= (((safe_lshift_func_int16_t_s_u((&l_85 == ((*l_259) = l_257)), ((safe_sub_func_uint32_t_u_u((((l_267 &= (((safe_add_func_int16_t_s_s((l_264 == (void*)0), (safe_div_func_uint64_t_u_u(g_107, (***l_174))))) <= p_59) ^ 0x3A281A0AL)) != p_57) != g_93.f0), (*g_12))) , g_226.f0))) || p_59) && g_226.f6)))) & p_57) < p_57), p_59)))));
                    for (g_87 = 0; (g_87 <= 9); g_87 += 1)
                    { /* block id: 110 */
                        uint8_t l_286 = 4UL;
                        int32_t *l_288 = (void*)0;
                        int32_t *l_289 = (void*)0;
                        int32_t *l_290 = &l_233;
                        int32_t *l_292[3][9] = {{&l_165[2][0],&g_106,(void*)0,&l_165[2][0],&g_99[2][1],&g_99[2][1],&l_165[2][0],(void*)0,&g_106},{&l_165[2][0],&g_106,(void*)0,&l_165[2][0],&g_99[2][1],&g_99[2][1],&l_165[2][0],(void*)0,&g_106},{&l_165[2][0],&g_106,(void*)0,&l_165[2][0],&g_99[2][1],&g_99[2][1],&l_165[2][0],(void*)0,&g_106}};
                        int i, j;
                        if ((*g_171))
                            break;
                        (*l_290) = (safe_rshift_func_int16_t_s_s((safe_lshift_func_int16_t_s_u((safe_lshift_func_int8_t_s_u((((safe_lshift_func_int16_t_s_u((safe_div_func_uint8_t_u_u((0x1A32069CL || ((void*)0 != l_76)), (safe_mul_func_int16_t_s_s((p_59 != (***l_84)), 0x2846L)))), ((g_98[0] == (safe_lshift_func_int8_t_s_u(p_57, (safe_mul_func_uint8_t_u_u(((l_286 = (g_285 = ((((*l_264) = (*l_264)) != l_206) < l_284[9]))) , (***l_84)), l_287))))) <= p_57))) < (***l_84)) || 1L), 2)), 2)), 0));
                        l_307--;
                        ++l_310;
                    }
                }
                if ((*g_12))
                    break;
            }
        }
    }
    return (**l_86);
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_5[i][j][k], "g_5[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_17, "g_17", print_hash_value);
    transparent_crc(g_20, "g_20", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_22[i], "g_22[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_77[i], "g_77[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_81, "g_81", print_hash_value);
    transparent_crc(g_87, "g_87", print_hash_value);
    transparent_crc(g_93.f0, "g_93.f0", print_hash_value);
    transparent_crc(g_93.f1, "g_93.f1", print_hash_value);
    transparent_crc(g_93.f2, "g_93.f2", print_hash_value);
    transparent_crc(g_93.f3, "g_93.f3", print_hash_value);
    transparent_crc(g_93.f4, "g_93.f4", print_hash_value);
    transparent_crc(g_93.f5, "g_93.f5", print_hash_value);
    transparent_crc(g_97, "g_97", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_98[i], "g_98[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_99[i][j], "g_99[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_100, "g_100", print_hash_value);
    transparent_crc(g_101, "g_101", print_hash_value);
    transparent_crc(g_102, "g_102", print_hash_value);
    transparent_crc(g_103, "g_103", print_hash_value);
    transparent_crc(g_104, "g_104", print_hash_value);
    transparent_crc(g_105, "g_105", print_hash_value);
    transparent_crc(g_106, "g_106", print_hash_value);
    transparent_crc(g_107, "g_107", print_hash_value);
    transparent_crc(g_108, "g_108", print_hash_value);
    transparent_crc(g_109, "g_109", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_110[i], "g_110[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_128, "g_128", print_hash_value);
    transparent_crc(g_130, "g_130", print_hash_value);
    transparent_crc(g_139, "g_139", print_hash_value);
    transparent_crc(g_142, "g_142", print_hash_value);
    transparent_crc(g_145, "g_145", print_hash_value);
    transparent_crc(g_150, "g_150", print_hash_value);
    transparent_crc(g_168, "g_168", print_hash_value);
    transparent_crc(g_192, "g_192", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_223[i][j][k], "g_223[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_226.f0, "g_226.f0", print_hash_value);
    transparent_crc(g_226.f1, "g_226.f1", print_hash_value);
    transparent_crc(g_226.f2, "g_226.f2", print_hash_value);
    transparent_crc(g_226.f3, "g_226.f3", print_hash_value);
    transparent_crc(g_226.f4, "g_226.f4", print_hash_value);
    transparent_crc(g_226.f5, "g_226.f5", print_hash_value);
    transparent_crc(g_226.f6, "g_226.f6", print_hash_value);
    transparent_crc(g_226.f7, "g_226.f7", print_hash_value);
    transparent_crc(g_226.f8, "g_226.f8", print_hash_value);
    transparent_crc(g_226.f9, "g_226.f9", print_hash_value);
    transparent_crc(g_231, "g_231", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_238[i][j][k], "g_238[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_285, "g_285", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_347[i][j], "g_347[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_366.f0, "g_366.f0", print_hash_value);
    transparent_crc(g_366.f1, "g_366.f1", print_hash_value);
    transparent_crc(g_366.f2, "g_366.f2", print_hash_value);
    transparent_crc(g_366.f3, "g_366.f3", print_hash_value);
    transparent_crc(g_366.f4, "g_366.f4", print_hash_value);
    transparent_crc(g_366.f5, "g_366.f5", print_hash_value);
    transparent_crc(g_369.f0, "g_369.f0", print_hash_value);
    transparent_crc(g_369.f1, "g_369.f1", print_hash_value);
    transparent_crc(g_369.f2, "g_369.f2", print_hash_value);
    transparent_crc(g_369.f3, "g_369.f3", print_hash_value);
    transparent_crc(g_369.f4, "g_369.f4", print_hash_value);
    transparent_crc(g_369.f5, "g_369.f5", print_hash_value);
    transparent_crc(g_370.f0, "g_370.f0", print_hash_value);
    transparent_crc(g_370.f1, "g_370.f1", print_hash_value);
    transparent_crc(g_370.f2, "g_370.f2", print_hash_value);
    transparent_crc(g_370.f3, "g_370.f3", print_hash_value);
    transparent_crc(g_370.f4, "g_370.f4", print_hash_value);
    transparent_crc(g_370.f5, "g_370.f5", print_hash_value);
    transparent_crc(g_371.f0, "g_371.f0", print_hash_value);
    transparent_crc(g_371.f1, "g_371.f1", print_hash_value);
    transparent_crc(g_371.f2, "g_371.f2", print_hash_value);
    transparent_crc(g_371.f3, "g_371.f3", print_hash_value);
    transparent_crc(g_371.f4, "g_371.f4", print_hash_value);
    transparent_crc(g_371.f5, "g_371.f5", print_hash_value);
    transparent_crc(g_372.f0, "g_372.f0", print_hash_value);
    transparent_crc(g_372.f1, "g_372.f1", print_hash_value);
    transparent_crc(g_372.f2, "g_372.f2", print_hash_value);
    transparent_crc(g_372.f3, "g_372.f3", print_hash_value);
    transparent_crc(g_372.f4, "g_372.f4", print_hash_value);
    transparent_crc(g_372.f5, "g_372.f5", print_hash_value);
    transparent_crc(g_373.f0, "g_373.f0", print_hash_value);
    transparent_crc(g_373.f1, "g_373.f1", print_hash_value);
    transparent_crc(g_373.f2, "g_373.f2", print_hash_value);
    transparent_crc(g_373.f3, "g_373.f3", print_hash_value);
    transparent_crc(g_373.f4, "g_373.f4", print_hash_value);
    transparent_crc(g_373.f5, "g_373.f5", print_hash_value);
    transparent_crc(g_374.f0, "g_374.f0", print_hash_value);
    transparent_crc(g_374.f1, "g_374.f1", print_hash_value);
    transparent_crc(g_374.f2, "g_374.f2", print_hash_value);
    transparent_crc(g_374.f3, "g_374.f3", print_hash_value);
    transparent_crc(g_374.f4, "g_374.f4", print_hash_value);
    transparent_crc(g_374.f5, "g_374.f5", print_hash_value);
    transparent_crc(g_375.f0, "g_375.f0", print_hash_value);
    transparent_crc(g_375.f1, "g_375.f1", print_hash_value);
    transparent_crc(g_375.f2, "g_375.f2", print_hash_value);
    transparent_crc(g_375.f3, "g_375.f3", print_hash_value);
    transparent_crc(g_375.f4, "g_375.f4", print_hash_value);
    transparent_crc(g_375.f5, "g_375.f5", print_hash_value);
    transparent_crc(g_376.f0, "g_376.f0", print_hash_value);
    transparent_crc(g_376.f1, "g_376.f1", print_hash_value);
    transparent_crc(g_376.f2, "g_376.f2", print_hash_value);
    transparent_crc(g_376.f3, "g_376.f3", print_hash_value);
    transparent_crc(g_376.f4, "g_376.f4", print_hash_value);
    transparent_crc(g_376.f5, "g_376.f5", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_377[i].f0, "g_377[i].f0", print_hash_value);
        transparent_crc(g_377[i].f1, "g_377[i].f1", print_hash_value);
        transparent_crc(g_377[i].f2, "g_377[i].f2", print_hash_value);
        transparent_crc(g_377[i].f3, "g_377[i].f3", print_hash_value);
        transparent_crc(g_377[i].f4, "g_377[i].f4", print_hash_value);
        transparent_crc(g_377[i].f5, "g_377[i].f5", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_378.f0, "g_378.f0", print_hash_value);
    transparent_crc(g_378.f1, "g_378.f1", print_hash_value);
    transparent_crc(g_378.f2, "g_378.f2", print_hash_value);
    transparent_crc(g_378.f3, "g_378.f3", print_hash_value);
    transparent_crc(g_378.f4, "g_378.f4", print_hash_value);
    transparent_crc(g_378.f5, "g_378.f5", print_hash_value);
    transparent_crc(g_379.f0, "g_379.f0", print_hash_value);
    transparent_crc(g_379.f1, "g_379.f1", print_hash_value);
    transparent_crc(g_379.f2, "g_379.f2", print_hash_value);
    transparent_crc(g_379.f3, "g_379.f3", print_hash_value);
    transparent_crc(g_379.f4, "g_379.f4", print_hash_value);
    transparent_crc(g_379.f5, "g_379.f5", print_hash_value);
    transparent_crc(g_380.f0, "g_380.f0", print_hash_value);
    transparent_crc(g_380.f1, "g_380.f1", print_hash_value);
    transparent_crc(g_380.f2, "g_380.f2", print_hash_value);
    transparent_crc(g_380.f3, "g_380.f3", print_hash_value);
    transparent_crc(g_380.f4, "g_380.f4", print_hash_value);
    transparent_crc(g_380.f5, "g_380.f5", print_hash_value);
    transparent_crc(g_381.f0, "g_381.f0", print_hash_value);
    transparent_crc(g_381.f1, "g_381.f1", print_hash_value);
    transparent_crc(g_381.f2, "g_381.f2", print_hash_value);
    transparent_crc(g_381.f3, "g_381.f3", print_hash_value);
    transparent_crc(g_381.f4, "g_381.f4", print_hash_value);
    transparent_crc(g_381.f5, "g_381.f5", print_hash_value);
    transparent_crc(g_382.f0, "g_382.f0", print_hash_value);
    transparent_crc(g_382.f1, "g_382.f1", print_hash_value);
    transparent_crc(g_382.f2, "g_382.f2", print_hash_value);
    transparent_crc(g_382.f3, "g_382.f3", print_hash_value);
    transparent_crc(g_382.f4, "g_382.f4", print_hash_value);
    transparent_crc(g_382.f5, "g_382.f5", print_hash_value);
    transparent_crc(g_383.f0, "g_383.f0", print_hash_value);
    transparent_crc(g_383.f1, "g_383.f1", print_hash_value);
    transparent_crc(g_383.f2, "g_383.f2", print_hash_value);
    transparent_crc(g_383.f3, "g_383.f3", print_hash_value);
    transparent_crc(g_383.f4, "g_383.f4", print_hash_value);
    transparent_crc(g_383.f5, "g_383.f5", print_hash_value);
    transparent_crc(g_384.f0, "g_384.f0", print_hash_value);
    transparent_crc(g_384.f1, "g_384.f1", print_hash_value);
    transparent_crc(g_384.f2, "g_384.f2", print_hash_value);
    transparent_crc(g_384.f3, "g_384.f3", print_hash_value);
    transparent_crc(g_384.f4, "g_384.f4", print_hash_value);
    transparent_crc(g_384.f5, "g_384.f5", print_hash_value);
    transparent_crc(g_385.f0, "g_385.f0", print_hash_value);
    transparent_crc(g_385.f1, "g_385.f1", print_hash_value);
    transparent_crc(g_385.f2, "g_385.f2", print_hash_value);
    transparent_crc(g_385.f3, "g_385.f3", print_hash_value);
    transparent_crc(g_385.f4, "g_385.f4", print_hash_value);
    transparent_crc(g_385.f5, "g_385.f5", print_hash_value);
    transparent_crc(g_386.f0, "g_386.f0", print_hash_value);
    transparent_crc(g_386.f1, "g_386.f1", print_hash_value);
    transparent_crc(g_386.f2, "g_386.f2", print_hash_value);
    transparent_crc(g_386.f3, "g_386.f3", print_hash_value);
    transparent_crc(g_386.f4, "g_386.f4", print_hash_value);
    transparent_crc(g_386.f5, "g_386.f5", print_hash_value);
    transparent_crc(g_387.f0, "g_387.f0", print_hash_value);
    transparent_crc(g_387.f1, "g_387.f1", print_hash_value);
    transparent_crc(g_387.f2, "g_387.f2", print_hash_value);
    transparent_crc(g_387.f3, "g_387.f3", print_hash_value);
    transparent_crc(g_387.f4, "g_387.f4", print_hash_value);
    transparent_crc(g_387.f5, "g_387.f5", print_hash_value);
    transparent_crc(g_388.f0, "g_388.f0", print_hash_value);
    transparent_crc(g_388.f1, "g_388.f1", print_hash_value);
    transparent_crc(g_388.f2, "g_388.f2", print_hash_value);
    transparent_crc(g_388.f3, "g_388.f3", print_hash_value);
    transparent_crc(g_388.f4, "g_388.f4", print_hash_value);
    transparent_crc(g_388.f5, "g_388.f5", print_hash_value);
    transparent_crc(g_389.f0, "g_389.f0", print_hash_value);
    transparent_crc(g_389.f1, "g_389.f1", print_hash_value);
    transparent_crc(g_389.f2, "g_389.f2", print_hash_value);
    transparent_crc(g_389.f3, "g_389.f3", print_hash_value);
    transparent_crc(g_389.f4, "g_389.f4", print_hash_value);
    transparent_crc(g_389.f5, "g_389.f5", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_415[i].f0, "g_415[i].f0", print_hash_value);
        transparent_crc(g_415[i].f1, "g_415[i].f1", print_hash_value);
        transparent_crc(g_415[i].f2, "g_415[i].f2", print_hash_value);
        transparent_crc(g_415[i].f3, "g_415[i].f3", print_hash_value);
        transparent_crc(g_415[i].f4, "g_415[i].f4", print_hash_value);
        transparent_crc(g_415[i].f5, "g_415[i].f5", print_hash_value);
        transparent_crc(g_415[i].f6, "g_415[i].f6", print_hash_value);
        transparent_crc(g_415[i].f7, "g_415[i].f7", print_hash_value);
        transparent_crc(g_415[i].f8, "g_415[i].f8", print_hash_value);
        transparent_crc(g_415[i].f9, "g_415[i].f9", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_431.f0, "g_431.f0", print_hash_value);
    transparent_crc(g_431.f1, "g_431.f1", print_hash_value);
    transparent_crc(g_431.f2, "g_431.f2", print_hash_value);
    transparent_crc(g_431.f3, "g_431.f3", print_hash_value);
    transparent_crc(g_431.f4, "g_431.f4", print_hash_value);
    transparent_crc(g_431.f5, "g_431.f5", print_hash_value);
    transparent_crc(g_432.f0, "g_432.f0", print_hash_value);
    transparent_crc(g_432.f1, "g_432.f1", print_hash_value);
    transparent_crc(g_432.f2, "g_432.f2", print_hash_value);
    transparent_crc(g_432.f3, "g_432.f3", print_hash_value);
    transparent_crc(g_432.f4, "g_432.f4", print_hash_value);
    transparent_crc(g_432.f5, "g_432.f5", print_hash_value);
    transparent_crc(g_433.f0, "g_433.f0", print_hash_value);
    transparent_crc(g_433.f1, "g_433.f1", print_hash_value);
    transparent_crc(g_433.f2, "g_433.f2", print_hash_value);
    transparent_crc(g_433.f3, "g_433.f3", print_hash_value);
    transparent_crc(g_433.f4, "g_433.f4", print_hash_value);
    transparent_crc(g_433.f5, "g_433.f5", print_hash_value);
    transparent_crc(g_434.f0, "g_434.f0", print_hash_value);
    transparent_crc(g_434.f1, "g_434.f1", print_hash_value);
    transparent_crc(g_434.f2, "g_434.f2", print_hash_value);
    transparent_crc(g_434.f3, "g_434.f3", print_hash_value);
    transparent_crc(g_434.f4, "g_434.f4", print_hash_value);
    transparent_crc(g_434.f5, "g_434.f5", print_hash_value);
    transparent_crc(g_435.f0, "g_435.f0", print_hash_value);
    transparent_crc(g_435.f1, "g_435.f1", print_hash_value);
    transparent_crc(g_435.f2, "g_435.f2", print_hash_value);
    transparent_crc(g_435.f3, "g_435.f3", print_hash_value);
    transparent_crc(g_435.f4, "g_435.f4", print_hash_value);
    transparent_crc(g_435.f5, "g_435.f5", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_436[i][j].f0, "g_436[i][j].f0", print_hash_value);
            transparent_crc(g_436[i][j].f1, "g_436[i][j].f1", print_hash_value);
            transparent_crc(g_436[i][j].f2, "g_436[i][j].f2", print_hash_value);
            transparent_crc(g_436[i][j].f3, "g_436[i][j].f3", print_hash_value);
            transparent_crc(g_436[i][j].f4, "g_436[i][j].f4", print_hash_value);
            transparent_crc(g_436[i][j].f5, "g_436[i][j].f5", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_437.f0, "g_437.f0", print_hash_value);
    transparent_crc(g_437.f1, "g_437.f1", print_hash_value);
    transparent_crc(g_437.f2, "g_437.f2", print_hash_value);
    transparent_crc(g_437.f3, "g_437.f3", print_hash_value);
    transparent_crc(g_437.f4, "g_437.f4", print_hash_value);
    transparent_crc(g_437.f5, "g_437.f5", print_hash_value);
    transparent_crc(g_532, "g_532", print_hash_value);
    transparent_crc(g_577, "g_577", print_hash_value);
    transparent_crc(g_586.f0, "g_586.f0", print_hash_value);
    transparent_crc(g_586.f1, "g_586.f1", print_hash_value);
    transparent_crc(g_586.f2, "g_586.f2", print_hash_value);
    transparent_crc(g_586.f3, "g_586.f3", print_hash_value);
    transparent_crc(g_586.f4, "g_586.f4", print_hash_value);
    transparent_crc(g_586.f5, "g_586.f5", print_hash_value);
    transparent_crc(g_688, "g_688", print_hash_value);
    transparent_crc(g_723.f0, "g_723.f0", print_hash_value);
    transparent_crc(g_723.f1, "g_723.f1", print_hash_value);
    transparent_crc(g_723.f2, "g_723.f2", print_hash_value);
    transparent_crc(g_723.f3, "g_723.f3", print_hash_value);
    transparent_crc(g_723.f4, "g_723.f4", print_hash_value);
    transparent_crc(g_723.f5, "g_723.f5", print_hash_value);
    transparent_crc(g_754, "g_754", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_794[i].f0, "g_794[i].f0", print_hash_value);
        transparent_crc(g_794[i].f1, "g_794[i].f1", print_hash_value);
        transparent_crc(g_794[i].f2, "g_794[i].f2", print_hash_value);
        transparent_crc(g_794[i].f3, "g_794[i].f3", print_hash_value);
        transparent_crc(g_794[i].f4, "g_794[i].f4", print_hash_value);
        transparent_crc(g_794[i].f5, "g_794[i].f5", print_hash_value);
        transparent_crc(g_794[i].f6, "g_794[i].f6", print_hash_value);
        transparent_crc(g_794[i].f7, "g_794[i].f7", print_hash_value);
        transparent_crc(g_794[i].f8, "g_794[i].f8", print_hash_value);
        transparent_crc(g_794[i].f9, "g_794[i].f9", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_795.f0, "g_795.f0", print_hash_value);
    transparent_crc(g_795.f1, "g_795.f1", print_hash_value);
    transparent_crc(g_795.f2, "g_795.f2", print_hash_value);
    transparent_crc(g_795.f3, "g_795.f3", print_hash_value);
    transparent_crc(g_795.f4, "g_795.f4", print_hash_value);
    transparent_crc(g_795.f5, "g_795.f5", print_hash_value);
    transparent_crc(g_795.f6, "g_795.f6", print_hash_value);
    transparent_crc(g_795.f7, "g_795.f7", print_hash_value);
    transparent_crc(g_795.f8, "g_795.f8", print_hash_value);
    transparent_crc(g_795.f9, "g_795.f9", print_hash_value);
    transparent_crc(g_796.f0, "g_796.f0", print_hash_value);
    transparent_crc(g_796.f1, "g_796.f1", print_hash_value);
    transparent_crc(g_796.f2, "g_796.f2", print_hash_value);
    transparent_crc(g_796.f3, "g_796.f3", print_hash_value);
    transparent_crc(g_796.f4, "g_796.f4", print_hash_value);
    transparent_crc(g_796.f5, "g_796.f5", print_hash_value);
    transparent_crc(g_796.f6, "g_796.f6", print_hash_value);
    transparent_crc(g_796.f7, "g_796.f7", print_hash_value);
    transparent_crc(g_796.f8, "g_796.f8", print_hash_value);
    transparent_crc(g_796.f9, "g_796.f9", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_797[i][j].f0, "g_797[i][j].f0", print_hash_value);
            transparent_crc(g_797[i][j].f1, "g_797[i][j].f1", print_hash_value);
            transparent_crc(g_797[i][j].f2, "g_797[i][j].f2", print_hash_value);
            transparent_crc(g_797[i][j].f3, "g_797[i][j].f3", print_hash_value);
            transparent_crc(g_797[i][j].f4, "g_797[i][j].f4", print_hash_value);
            transparent_crc(g_797[i][j].f5, "g_797[i][j].f5", print_hash_value);
            transparent_crc(g_797[i][j].f6, "g_797[i][j].f6", print_hash_value);
            transparent_crc(g_797[i][j].f7, "g_797[i][j].f7", print_hash_value);
            transparent_crc(g_797[i][j].f8, "g_797[i][j].f8", print_hash_value);
            transparent_crc(g_797[i][j].f9, "g_797[i][j].f9", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_798.f0, "g_798.f0", print_hash_value);
    transparent_crc(g_798.f1, "g_798.f1", print_hash_value);
    transparent_crc(g_798.f2, "g_798.f2", print_hash_value);
    transparent_crc(g_798.f3, "g_798.f3", print_hash_value);
    transparent_crc(g_798.f4, "g_798.f4", print_hash_value);
    transparent_crc(g_798.f5, "g_798.f5", print_hash_value);
    transparent_crc(g_798.f6, "g_798.f6", print_hash_value);
    transparent_crc(g_798.f7, "g_798.f7", print_hash_value);
    transparent_crc(g_798.f8, "g_798.f8", print_hash_value);
    transparent_crc(g_798.f9, "g_798.f9", print_hash_value);
    transparent_crc(g_800.f0, "g_800.f0", print_hash_value);
    transparent_crc(g_800.f1, "g_800.f1", print_hash_value);
    transparent_crc(g_800.f2, "g_800.f2", print_hash_value);
    transparent_crc(g_800.f3, "g_800.f3", print_hash_value);
    transparent_crc(g_800.f4, "g_800.f4", print_hash_value);
    transparent_crc(g_800.f5, "g_800.f5", print_hash_value);
    transparent_crc(g_800.f6, "g_800.f6", print_hash_value);
    transparent_crc(g_800.f7, "g_800.f7", print_hash_value);
    transparent_crc(g_800.f8, "g_800.f8", print_hash_value);
    transparent_crc(g_800.f9, "g_800.f9", print_hash_value);
    transparent_crc(g_802.f0, "g_802.f0", print_hash_value);
    transparent_crc(g_802.f1, "g_802.f1", print_hash_value);
    transparent_crc(g_802.f2, "g_802.f2", print_hash_value);
    transparent_crc(g_802.f3, "g_802.f3", print_hash_value);
    transparent_crc(g_802.f4, "g_802.f4", print_hash_value);
    transparent_crc(g_802.f5, "g_802.f5", print_hash_value);
    transparent_crc(g_802.f6, "g_802.f6", print_hash_value);
    transparent_crc(g_802.f7, "g_802.f7", print_hash_value);
    transparent_crc(g_802.f8, "g_802.f8", print_hash_value);
    transparent_crc(g_802.f9, "g_802.f9", print_hash_value);
    transparent_crc(g_804, "g_804", print_hash_value);
    transparent_crc(g_859.f0, "g_859.f0", print_hash_value);
    transparent_crc(g_859.f1, "g_859.f1", print_hash_value);
    transparent_crc(g_859.f2, "g_859.f2", print_hash_value);
    transparent_crc(g_859.f3, "g_859.f3", print_hash_value);
    transparent_crc(g_859.f4, "g_859.f4", print_hash_value);
    transparent_crc(g_859.f5, "g_859.f5", print_hash_value);
    transparent_crc(g_862, "g_862", print_hash_value);
    transparent_crc(g_938, "g_938", print_hash_value);
    transparent_crc(g_992, "g_992", print_hash_value);
    transparent_crc(g_1013.f0, "g_1013.f0", print_hash_value);
    transparent_crc(g_1013.f1, "g_1013.f1", print_hash_value);
    transparent_crc(g_1013.f2, "g_1013.f2", print_hash_value);
    transparent_crc(g_1013.f3, "g_1013.f3", print_hash_value);
    transparent_crc(g_1013.f4, "g_1013.f4", print_hash_value);
    transparent_crc(g_1013.f5, "g_1013.f5", print_hash_value);
    transparent_crc(g_1098.f0, "g_1098.f0", print_hash_value);
    transparent_crc(g_1098.f1, "g_1098.f1", print_hash_value);
    transparent_crc(g_1098.f2, "g_1098.f2", print_hash_value);
    transparent_crc(g_1098.f3, "g_1098.f3", print_hash_value);
    transparent_crc(g_1098.f4, "g_1098.f4", print_hash_value);
    transparent_crc(g_1098.f5, "g_1098.f5", print_hash_value);
    transparent_crc(g_1099.f0, "g_1099.f0", print_hash_value);
    transparent_crc(g_1099.f1, "g_1099.f1", print_hash_value);
    transparent_crc(g_1099.f2, "g_1099.f2", print_hash_value);
    transparent_crc(g_1099.f3, "g_1099.f3", print_hash_value);
    transparent_crc(g_1099.f4, "g_1099.f4", print_hash_value);
    transparent_crc(g_1099.f5, "g_1099.f5", print_hash_value);
    transparent_crc(g_1100.f0, "g_1100.f0", print_hash_value);
    transparent_crc(g_1100.f1, "g_1100.f1", print_hash_value);
    transparent_crc(g_1100.f2, "g_1100.f2", print_hash_value);
    transparent_crc(g_1100.f3, "g_1100.f3", print_hash_value);
    transparent_crc(g_1100.f4, "g_1100.f4", print_hash_value);
    transparent_crc(g_1100.f5, "g_1100.f5", print_hash_value);
    transparent_crc(g_1124, "g_1124", print_hash_value);
    transparent_crc(g_1201, "g_1201", print_hash_value);
    transparent_crc(g_1269.f0, "g_1269.f0", print_hash_value);
    transparent_crc(g_1269.f1, "g_1269.f1", print_hash_value);
    transparent_crc(g_1269.f2, "g_1269.f2", print_hash_value);
    transparent_crc(g_1269.f3, "g_1269.f3", print_hash_value);
    transparent_crc(g_1269.f4, "g_1269.f4", print_hash_value);
    transparent_crc(g_1269.f5, "g_1269.f5", print_hash_value);
    transparent_crc(g_1269.f6, "g_1269.f6", print_hash_value);
    transparent_crc(g_1269.f7, "g_1269.f7", print_hash_value);
    transparent_crc(g_1269.f8, "g_1269.f8", print_hash_value);
    transparent_crc(g_1269.f9, "g_1269.f9", print_hash_value);
    transparent_crc(g_1270.f0, "g_1270.f0", print_hash_value);
    transparent_crc(g_1270.f1, "g_1270.f1", print_hash_value);
    transparent_crc(g_1270.f2, "g_1270.f2", print_hash_value);
    transparent_crc(g_1270.f3, "g_1270.f3", print_hash_value);
    transparent_crc(g_1270.f4, "g_1270.f4", print_hash_value);
    transparent_crc(g_1270.f5, "g_1270.f5", print_hash_value);
    transparent_crc(g_1270.f6, "g_1270.f6", print_hash_value);
    transparent_crc(g_1270.f7, "g_1270.f7", print_hash_value);
    transparent_crc(g_1270.f8, "g_1270.f8", print_hash_value);
    transparent_crc(g_1270.f9, "g_1270.f9", print_hash_value);
    transparent_crc(g_1271.f0, "g_1271.f0", print_hash_value);
    transparent_crc(g_1271.f1, "g_1271.f1", print_hash_value);
    transparent_crc(g_1271.f2, "g_1271.f2", print_hash_value);
    transparent_crc(g_1271.f3, "g_1271.f3", print_hash_value);
    transparent_crc(g_1271.f4, "g_1271.f4", print_hash_value);
    transparent_crc(g_1271.f5, "g_1271.f5", print_hash_value);
    transparent_crc(g_1271.f6, "g_1271.f6", print_hash_value);
    transparent_crc(g_1271.f7, "g_1271.f7", print_hash_value);
    transparent_crc(g_1271.f8, "g_1271.f8", print_hash_value);
    transparent_crc(g_1271.f9, "g_1271.f9", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_1301[i][j], "g_1301[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1411.f0, "g_1411.f0", print_hash_value);
    transparent_crc(g_1411.f1, "g_1411.f1", print_hash_value);
    transparent_crc(g_1411.f2, "g_1411.f2", print_hash_value);
    transparent_crc(g_1411.f3, "g_1411.f3", print_hash_value);
    transparent_crc(g_1411.f4, "g_1411.f4", print_hash_value);
    transparent_crc(g_1411.f5, "g_1411.f5", print_hash_value);
    transparent_crc(g_1411.f6, "g_1411.f6", print_hash_value);
    transparent_crc(g_1411.f7, "g_1411.f7", print_hash_value);
    transparent_crc(g_1411.f8, "g_1411.f8", print_hash_value);
    transparent_crc(g_1411.f9, "g_1411.f9", print_hash_value);
    transparent_crc(g_1470, "g_1470", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_1492[i], "g_1492[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1498, "g_1498", print_hash_value);
    transparent_crc(g_1524, "g_1524", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_1527[i][j], "g_1527[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_1539[i][j].f0, "g_1539[i][j].f0", print_hash_value);
            transparent_crc(g_1539[i][j].f1, "g_1539[i][j].f1", print_hash_value);
            transparent_crc(g_1539[i][j].f2, "g_1539[i][j].f2", print_hash_value);
            transparent_crc(g_1539[i][j].f3, "g_1539[i][j].f3", print_hash_value);
            transparent_crc(g_1539[i][j].f4, "g_1539[i][j].f4", print_hash_value);
            transparent_crc(g_1539[i][j].f5, "g_1539[i][j].f5", print_hash_value);
            transparent_crc(g_1539[i][j].f6, "g_1539[i][j].f6", print_hash_value);
            transparent_crc(g_1539[i][j].f7, "g_1539[i][j].f7", print_hash_value);
            transparent_crc(g_1539[i][j].f8, "g_1539[i][j].f8", print_hash_value);
            transparent_crc(g_1539[i][j].f9, "g_1539[i][j].f9", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1639, "g_1639", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_1695[i][j], "g_1695[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1745.f0, "g_1745.f0", print_hash_value);
    transparent_crc(g_1745.f1, "g_1745.f1", print_hash_value);
    transparent_crc(g_1745.f2, "g_1745.f2", print_hash_value);
    transparent_crc(g_1745.f3, "g_1745.f3", print_hash_value);
    transparent_crc(g_1745.f4, "g_1745.f4", print_hash_value);
    transparent_crc(g_1745.f5, "g_1745.f5", print_hash_value);
    transparent_crc(g_1866.f0, "g_1866.f0", print_hash_value);
    transparent_crc(g_1866.f1, "g_1866.f1", print_hash_value);
    transparent_crc(g_1866.f2, "g_1866.f2", print_hash_value);
    transparent_crc(g_1866.f3, "g_1866.f3", print_hash_value);
    transparent_crc(g_1866.f4, "g_1866.f4", print_hash_value);
    transparent_crc(g_1866.f5, "g_1866.f5", print_hash_value);
    transparent_crc(g_1866.f6, "g_1866.f6", print_hash_value);
    transparent_crc(g_1866.f7, "g_1866.f7", print_hash_value);
    transparent_crc(g_1866.f8, "g_1866.f8", print_hash_value);
    transparent_crc(g_1866.f9, "g_1866.f9", print_hash_value);
    transparent_crc(g_1872, "g_1872", print_hash_value);
    transparent_crc(g_2058, "g_2058", print_hash_value);
    transparent_crc(g_2103, "g_2103", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_2104[i], "g_2104[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2105, "g_2105", print_hash_value);
    transparent_crc(g_2106, "g_2106", print_hash_value);
    transparent_crc(g_2153, "g_2153", print_hash_value);
    transparent_crc(g_2185, "g_2185", print_hash_value);
    transparent_crc(g_2198.f0, "g_2198.f0", print_hash_value);
    transparent_crc(g_2198.f1, "g_2198.f1", print_hash_value);
    transparent_crc(g_2198.f2, "g_2198.f2", print_hash_value);
    transparent_crc(g_2198.f3, "g_2198.f3", print_hash_value);
    transparent_crc(g_2198.f4, "g_2198.f4", print_hash_value);
    transparent_crc(g_2198.f5, "g_2198.f5", print_hash_value);
    transparent_crc(g_2207.f0, "g_2207.f0", print_hash_value);
    transparent_crc(g_2207.f1, "g_2207.f1", print_hash_value);
    transparent_crc(g_2207.f2, "g_2207.f2", print_hash_value);
    transparent_crc(g_2207.f3, "g_2207.f3", print_hash_value);
    transparent_crc(g_2207.f4, "g_2207.f4", print_hash_value);
    transparent_crc(g_2207.f5, "g_2207.f5", print_hash_value);
    transparent_crc(g_2396, "g_2396", print_hash_value);
    transparent_crc(g_2422.f0, "g_2422.f0", print_hash_value);
    transparent_crc(g_2422.f1, "g_2422.f1", print_hash_value);
    transparent_crc(g_2422.f2, "g_2422.f2", print_hash_value);
    transparent_crc(g_2422.f3, "g_2422.f3", print_hash_value);
    transparent_crc(g_2422.f4, "g_2422.f4", print_hash_value);
    transparent_crc(g_2422.f5, "g_2422.f5", print_hash_value);
    transparent_crc(g_2423.f0, "g_2423.f0", print_hash_value);
    transparent_crc(g_2423.f1, "g_2423.f1", print_hash_value);
    transparent_crc(g_2423.f2, "g_2423.f2", print_hash_value);
    transparent_crc(g_2423.f3, "g_2423.f3", print_hash_value);
    transparent_crc(g_2423.f4, "g_2423.f4", print_hash_value);
    transparent_crc(g_2423.f5, "g_2423.f5", print_hash_value);
    transparent_crc(g_2424.f0, "g_2424.f0", print_hash_value);
    transparent_crc(g_2424.f1, "g_2424.f1", print_hash_value);
    transparent_crc(g_2424.f2, "g_2424.f2", print_hash_value);
    transparent_crc(g_2424.f3, "g_2424.f3", print_hash_value);
    transparent_crc(g_2424.f4, "g_2424.f4", print_hash_value);
    transparent_crc(g_2424.f5, "g_2424.f5", print_hash_value);
    transparent_crc(g_2425.f0, "g_2425.f0", print_hash_value);
    transparent_crc(g_2425.f1, "g_2425.f1", print_hash_value);
    transparent_crc(g_2425.f2, "g_2425.f2", print_hash_value);
    transparent_crc(g_2425.f3, "g_2425.f3", print_hash_value);
    transparent_crc(g_2425.f4, "g_2425.f4", print_hash_value);
    transparent_crc(g_2425.f5, "g_2425.f5", print_hash_value);
    transparent_crc(g_2426.f0, "g_2426.f0", print_hash_value);
    transparent_crc(g_2426.f1, "g_2426.f1", print_hash_value);
    transparent_crc(g_2426.f2, "g_2426.f2", print_hash_value);
    transparent_crc(g_2426.f3, "g_2426.f3", print_hash_value);
    transparent_crc(g_2426.f4, "g_2426.f4", print_hash_value);
    transparent_crc(g_2426.f5, "g_2426.f5", print_hash_value);
    transparent_crc(g_2427.f0, "g_2427.f0", print_hash_value);
    transparent_crc(g_2427.f1, "g_2427.f1", print_hash_value);
    transparent_crc(g_2427.f2, "g_2427.f2", print_hash_value);
    transparent_crc(g_2427.f3, "g_2427.f3", print_hash_value);
    transparent_crc(g_2427.f4, "g_2427.f4", print_hash_value);
    transparent_crc(g_2427.f5, "g_2427.f5", print_hash_value);
    transparent_crc(g_2428.f0, "g_2428.f0", print_hash_value);
    transparent_crc(g_2428.f1, "g_2428.f1", print_hash_value);
    transparent_crc(g_2428.f2, "g_2428.f2", print_hash_value);
    transparent_crc(g_2428.f3, "g_2428.f3", print_hash_value);
    transparent_crc(g_2428.f4, "g_2428.f4", print_hash_value);
    transparent_crc(g_2428.f5, "g_2428.f5", print_hash_value);
    transparent_crc(g_2429.f0, "g_2429.f0", print_hash_value);
    transparent_crc(g_2429.f1, "g_2429.f1", print_hash_value);
    transparent_crc(g_2429.f2, "g_2429.f2", print_hash_value);
    transparent_crc(g_2429.f3, "g_2429.f3", print_hash_value);
    transparent_crc(g_2429.f4, "g_2429.f4", print_hash_value);
    transparent_crc(g_2429.f5, "g_2429.f5", print_hash_value);
    transparent_crc(g_2430.f0, "g_2430.f0", print_hash_value);
    transparent_crc(g_2430.f1, "g_2430.f1", print_hash_value);
    transparent_crc(g_2430.f2, "g_2430.f2", print_hash_value);
    transparent_crc(g_2430.f3, "g_2430.f3", print_hash_value);
    transparent_crc(g_2430.f4, "g_2430.f4", print_hash_value);
    transparent_crc(g_2430.f5, "g_2430.f5", print_hash_value);
    transparent_crc(g_2431.f0, "g_2431.f0", print_hash_value);
    transparent_crc(g_2431.f1, "g_2431.f1", print_hash_value);
    transparent_crc(g_2431.f2, "g_2431.f2", print_hash_value);
    transparent_crc(g_2431.f3, "g_2431.f3", print_hash_value);
    transparent_crc(g_2431.f4, "g_2431.f4", print_hash_value);
    transparent_crc(g_2431.f5, "g_2431.f5", print_hash_value);
    transparent_crc(g_2432.f0, "g_2432.f0", print_hash_value);
    transparent_crc(g_2432.f1, "g_2432.f1", print_hash_value);
    transparent_crc(g_2432.f2, "g_2432.f2", print_hash_value);
    transparent_crc(g_2432.f3, "g_2432.f3", print_hash_value);
    transparent_crc(g_2432.f4, "g_2432.f4", print_hash_value);
    transparent_crc(g_2432.f5, "g_2432.f5", print_hash_value);
    transparent_crc(g_2433.f0, "g_2433.f0", print_hash_value);
    transparent_crc(g_2433.f1, "g_2433.f1", print_hash_value);
    transparent_crc(g_2433.f2, "g_2433.f2", print_hash_value);
    transparent_crc(g_2433.f3, "g_2433.f3", print_hash_value);
    transparent_crc(g_2433.f4, "g_2433.f4", print_hash_value);
    transparent_crc(g_2433.f5, "g_2433.f5", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_2477[i][j].f0, "g_2477[i][j].f0", print_hash_value);
            transparent_crc(g_2477[i][j].f1, "g_2477[i][j].f1", print_hash_value);
            transparent_crc(g_2477[i][j].f2, "g_2477[i][j].f2", print_hash_value);
            transparent_crc(g_2477[i][j].f3, "g_2477[i][j].f3", print_hash_value);
            transparent_crc(g_2477[i][j].f4, "g_2477[i][j].f4", print_hash_value);
            transparent_crc(g_2477[i][j].f5, "g_2477[i][j].f5", print_hash_value);
            transparent_crc(g_2477[i][j].f6, "g_2477[i][j].f6", print_hash_value);
            transparent_crc(g_2477[i][j].f7, "g_2477[i][j].f7", print_hash_value);
            transparent_crc(g_2477[i][j].f8, "g_2477[i][j].f8", print_hash_value);
            transparent_crc(g_2477[i][j].f9, "g_2477[i][j].f9", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2479.f0, "g_2479.f0", print_hash_value);
    transparent_crc(g_2479.f1, "g_2479.f1", print_hash_value);
    transparent_crc(g_2479.f2, "g_2479.f2", print_hash_value);
    transparent_crc(g_2479.f3, "g_2479.f3", print_hash_value);
    transparent_crc(g_2479.f4, "g_2479.f4", print_hash_value);
    transparent_crc(g_2479.f5, "g_2479.f5", print_hash_value);
    transparent_crc(g_2479.f6, "g_2479.f6", print_hash_value);
    transparent_crc(g_2479.f7, "g_2479.f7", print_hash_value);
    transparent_crc(g_2479.f8, "g_2479.f8", print_hash_value);
    transparent_crc(g_2479.f9, "g_2479.f9", print_hash_value);
    transparent_crc(g_2482.f0, "g_2482.f0", print_hash_value);
    transparent_crc(g_2482.f1, "g_2482.f1", print_hash_value);
    transparent_crc(g_2482.f2, "g_2482.f2", print_hash_value);
    transparent_crc(g_2482.f3, "g_2482.f3", print_hash_value);
    transparent_crc(g_2482.f4, "g_2482.f4", print_hash_value);
    transparent_crc(g_2482.f5, "g_2482.f5", print_hash_value);
    transparent_crc(g_2488.f0, "g_2488.f0", print_hash_value);
    transparent_crc(g_2488.f1, "g_2488.f1", print_hash_value);
    transparent_crc(g_2488.f2, "g_2488.f2", print_hash_value);
    transparent_crc(g_2488.f3, "g_2488.f3", print_hash_value);
    transparent_crc(g_2488.f4, "g_2488.f4", print_hash_value);
    transparent_crc(g_2488.f5, "g_2488.f5", print_hash_value);
    transparent_crc(g_2488.f6, "g_2488.f6", print_hash_value);
    transparent_crc(g_2488.f7, "g_2488.f7", print_hash_value);
    transparent_crc(g_2488.f8, "g_2488.f8", print_hash_value);
    transparent_crc(g_2488.f9, "g_2488.f9", print_hash_value);
    transparent_crc(g_2491.f0, "g_2491.f0", print_hash_value);
    transparent_crc(g_2491.f1, "g_2491.f1", print_hash_value);
    transparent_crc(g_2491.f2, "g_2491.f2", print_hash_value);
    transparent_crc(g_2491.f3, "g_2491.f3", print_hash_value);
    transparent_crc(g_2491.f4, "g_2491.f4", print_hash_value);
    transparent_crc(g_2491.f5, "g_2491.f5", print_hash_value);
    transparent_crc(g_2491.f6, "g_2491.f6", print_hash_value);
    transparent_crc(g_2491.f7, "g_2491.f7", print_hash_value);
    transparent_crc(g_2491.f8, "g_2491.f8", print_hash_value);
    transparent_crc(g_2491.f9, "g_2491.f9", print_hash_value);
    transparent_crc(g_2566.f0, "g_2566.f0", print_hash_value);
    transparent_crc(g_2566.f1, "g_2566.f1", print_hash_value);
    transparent_crc(g_2566.f2, "g_2566.f2", print_hash_value);
    transparent_crc(g_2566.f3, "g_2566.f3", print_hash_value);
    transparent_crc(g_2566.f4, "g_2566.f4", print_hash_value);
    transparent_crc(g_2566.f5, "g_2566.f5", print_hash_value);
    transparent_crc(g_2610.f0, "g_2610.f0", print_hash_value);
    transparent_crc(g_2610.f1, "g_2610.f1", print_hash_value);
    transparent_crc(g_2610.f2, "g_2610.f2", print_hash_value);
    transparent_crc(g_2610.f3, "g_2610.f3", print_hash_value);
    transparent_crc(g_2610.f4, "g_2610.f4", print_hash_value);
    transparent_crc(g_2610.f5, "g_2610.f5", print_hash_value);
    transparent_crc(g_2610.f6, "g_2610.f6", print_hash_value);
    transparent_crc(g_2610.f7, "g_2610.f7", print_hash_value);
    transparent_crc(g_2610.f8, "g_2610.f8", print_hash_value);
    transparent_crc(g_2610.f9, "g_2610.f9", print_hash_value);
    transparent_crc(g_2611.f0, "g_2611.f0", print_hash_value);
    transparent_crc(g_2611.f1, "g_2611.f1", print_hash_value);
    transparent_crc(g_2611.f2, "g_2611.f2", print_hash_value);
    transparent_crc(g_2611.f3, "g_2611.f3", print_hash_value);
    transparent_crc(g_2611.f4, "g_2611.f4", print_hash_value);
    transparent_crc(g_2611.f5, "g_2611.f5", print_hash_value);
    transparent_crc(g_2611.f6, "g_2611.f6", print_hash_value);
    transparent_crc(g_2611.f7, "g_2611.f7", print_hash_value);
    transparent_crc(g_2611.f8, "g_2611.f8", print_hash_value);
    transparent_crc(g_2611.f9, "g_2611.f9", print_hash_value);
    transparent_crc(g_2716.f0, "g_2716.f0", print_hash_value);
    transparent_crc(g_2716.f1, "g_2716.f1", print_hash_value);
    transparent_crc(g_2716.f2, "g_2716.f2", print_hash_value);
    transparent_crc(g_2716.f3, "g_2716.f3", print_hash_value);
    transparent_crc(g_2716.f4, "g_2716.f4", print_hash_value);
    transparent_crc(g_2716.f5, "g_2716.f5", print_hash_value);
    transparent_crc(g_2750.f0, "g_2750.f0", print_hash_value);
    transparent_crc(g_2750.f1, "g_2750.f1", print_hash_value);
    transparent_crc(g_2750.f2, "g_2750.f2", print_hash_value);
    transparent_crc(g_2750.f3, "g_2750.f3", print_hash_value);
    transparent_crc(g_2750.f4, "g_2750.f4", print_hash_value);
    transparent_crc(g_2750.f5, "g_2750.f5", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_2751[i][j].f0, "g_2751[i][j].f0", print_hash_value);
            transparent_crc(g_2751[i][j].f1, "g_2751[i][j].f1", print_hash_value);
            transparent_crc(g_2751[i][j].f2, "g_2751[i][j].f2", print_hash_value);
            transparent_crc(g_2751[i][j].f3, "g_2751[i][j].f3", print_hash_value);
            transparent_crc(g_2751[i][j].f4, "g_2751[i][j].f4", print_hash_value);
            transparent_crc(g_2751[i][j].f5, "g_2751[i][j].f5", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_2854[i][j].f0, "g_2854[i][j].f0", print_hash_value);
            transparent_crc(g_2854[i][j].f1, "g_2854[i][j].f1", print_hash_value);
            transparent_crc(g_2854[i][j].f2, "g_2854[i][j].f2", print_hash_value);
            transparent_crc(g_2854[i][j].f3, "g_2854[i][j].f3", print_hash_value);
            transparent_crc(g_2854[i][j].f4, "g_2854[i][j].f4", print_hash_value);
            transparent_crc(g_2854[i][j].f5, "g_2854[i][j].f5", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2855.f0, "g_2855.f0", print_hash_value);
    transparent_crc(g_2855.f1, "g_2855.f1", print_hash_value);
    transparent_crc(g_2855.f2, "g_2855.f2", print_hash_value);
    transparent_crc(g_2855.f3, "g_2855.f3", print_hash_value);
    transparent_crc(g_2855.f4, "g_2855.f4", print_hash_value);
    transparent_crc(g_2855.f5, "g_2855.f5", print_hash_value);
    transparent_crc(g_2875, "g_2875", print_hash_value);
    transparent_crc(g_2879.f0, "g_2879.f0", print_hash_value);
    transparent_crc(g_2879.f1, "g_2879.f1", print_hash_value);
    transparent_crc(g_2879.f2, "g_2879.f2", print_hash_value);
    transparent_crc(g_2879.f3, "g_2879.f3", print_hash_value);
    transparent_crc(g_2879.f4, "g_2879.f4", print_hash_value);
    transparent_crc(g_2879.f5, "g_2879.f5", print_hash_value);
    transparent_crc(g_2887.f0, "g_2887.f0", print_hash_value);
    transparent_crc(g_2887.f1, "g_2887.f1", print_hash_value);
    transparent_crc(g_2887.f2, "g_2887.f2", print_hash_value);
    transparent_crc(g_2887.f3, "g_2887.f3", print_hash_value);
    transparent_crc(g_2887.f4, "g_2887.f4", print_hash_value);
    transparent_crc(g_2887.f5, "g_2887.f5", print_hash_value);
    transparent_crc(g_2925.f0, "g_2925.f0", print_hash_value);
    transparent_crc(g_2925.f1, "g_2925.f1", print_hash_value);
    transparent_crc(g_2925.f2, "g_2925.f2", print_hash_value);
    transparent_crc(g_2925.f3, "g_2925.f3", print_hash_value);
    transparent_crc(g_2925.f4, "g_2925.f4", print_hash_value);
    transparent_crc(g_2925.f5, "g_2925.f5", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 785
   depth: 1, occurrence: 23
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 12
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 4
XXX volatile bitfields defined in structs: 5
XXX structs with bitfields in the program: 103
breakdown:
   indirect level: 0, occurrence: 23
   indirect level: 1, occurrence: 33
   indirect level: 2, occurrence: 20
   indirect level: 3, occurrence: 9
   indirect level: 4, occurrence: 12
   indirect level: 5, occurrence: 6
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 108
XXX times a bitfields struct on LHS: 1
XXX times a bitfields struct on RHS: 34
XXX times a single bitfield on LHS: 1
XXX times a single bitfield on RHS: 36

XXX max expression depth: 45
breakdown:
   depth: 1, occurrence: 412
   depth: 2, occurrence: 105
   depth: 3, occurrence: 7
   depth: 4, occurrence: 8
   depth: 5, occurrence: 2
   depth: 7, occurrence: 3
   depth: 8, occurrence: 1
   depth: 10, occurrence: 3
   depth: 12, occurrence: 3
   depth: 13, occurrence: 4
   depth: 14, occurrence: 1
   depth: 15, occurrence: 3
   depth: 16, occurrence: 3
   depth: 17, occurrence: 4
   depth: 18, occurrence: 4
   depth: 19, occurrence: 7
   depth: 20, occurrence: 4
   depth: 21, occurrence: 3
   depth: 22, occurrence: 7
   depth: 23, occurrence: 3
   depth: 24, occurrence: 6
   depth: 25, occurrence: 4
   depth: 26, occurrence: 1
   depth: 27, occurrence: 5
   depth: 28, occurrence: 5
   depth: 29, occurrence: 2
   depth: 30, occurrence: 2
   depth: 32, occurrence: 2
   depth: 33, occurrence: 3
   depth: 34, occurrence: 1
   depth: 36, occurrence: 2
   depth: 38, occurrence: 3
   depth: 45, occurrence: 1

XXX total number of pointers: 663

XXX times a variable address is taken: 1489
XXX times a pointer is dereferenced on RHS: 420
breakdown:
   depth: 1, occurrence: 299
   depth: 2, occurrence: 85
   depth: 3, occurrence: 32
   depth: 4, occurrence: 4
XXX times a pointer is dereferenced on LHS: 335
breakdown:
   depth: 1, occurrence: 279
   depth: 2, occurrence: 48
   depth: 3, occurrence: 7
   depth: 4, occurrence: 1
XXX times a pointer is compared with null: 56
XXX times a pointer is compared with address of another variable: 5
XXX times a pointer is compared with another pointer: 20
XXX times a pointer is qualified to be dereferenced: 11068

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1702
   level: 2, occurrence: 480
   level: 3, occurrence: 185
   level: 4, occurrence: 32
   level: 5, occurrence: 2
XXX number of pointers point to pointers: 343
XXX number of pointers point to scalars: 274
XXX number of pointers point to structs: 46
XXX percent of pointers has null in alias set: 30.3
XXX average alias set size: 1.67

XXX times a non-volatile is read: 2449
XXX times a non-volatile is write: 1135
XXX times a volatile is read: 33
XXX    times read thru a pointer: 27
XXX times a volatile is write: 12
XXX    times written thru a pointer: 10
XXX times a volatile is available for access: 422
XXX percentage of non-volatile access: 98.8

XXX forward jumps: 0
XXX backward jumps: 11

XXX stmts: 420
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 29
   depth: 1, occurrence: 44
   depth: 2, occurrence: 53
   depth: 3, occurrence: 71
   depth: 4, occurrence: 95
   depth: 5, occurrence: 128

XXX percentage a fresh-made variable is used: 16.8
XXX percentage an existing variable is used: 83.2
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

