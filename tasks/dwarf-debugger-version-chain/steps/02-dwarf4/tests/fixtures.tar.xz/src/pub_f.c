/* pub_f.c - public sample: fault inside a signal handler */
#include <signal.h>
#include <stdio.h>
#include <string.h>
static int inside(int v) { volatile int *p = (int *) 0; return *p + v; }
static void on_signal(int s) { printf("pub handler %d\n", s); fflush(stdout); inside(s); }
static int descend(int d) { if (d > 0) return descend(d - 1) + 1; raise(SIGUSR1); return 0; }
int main(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_signal;
    sigaction(SIGUSR1, &sa, 0);
    printf("pub sig\n");
    fflush(stdout);
    return descend(2);
}
