/* mixed_b.c - second translation unit of a mixed-DWARF-version executable */
int mixed_c_entry(int x);

static int b_helper(int x)
{
    int acc = 0;
    for (int i = 0; i < 4; i++) {
        acc += x ^ i;
    }
    return acc;
}

int mixed_b_entry(int x)
{
    return b_helper(x) + mixed_c_entry(x) - 1;
}
