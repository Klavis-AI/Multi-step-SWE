/* deep.c - a deep call chain that faults, for core files */
#include <stdio.h>
#include <string.h>

static int level_five(int d, const char *tag)
{
    char buf[32];
    strncpy(buf, tag, sizeof buf - 1);
    buf[sizeof buf - 1] = '\0';
    volatile int *p = (int *) 0;
    if (d > 0) {
        return *p;
    }
    return (int) strlen(buf);
}

static int level_four(int d, const char *tag) { return level_five(d + 1, tag) + 1; }
static int level_three(int d, const char *tag) { return level_four(d + 1, tag) + 2; }
static int level_two(int d, const char *tag) { return level_three(d + 1, tag) + 3; }
int level_one(int d, const char *tag) { return level_two(d + 1, tag) + 4; }

int main(int argc, char **argv)
{
    (void) argv;
    printf("deep start\n");
    fflush(stdout);
    return level_one(argc, "core-tag");
}
