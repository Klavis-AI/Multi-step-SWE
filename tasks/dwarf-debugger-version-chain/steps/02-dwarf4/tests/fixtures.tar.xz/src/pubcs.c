/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --seed 900901 --max-funcs 8
 * Seed:      900901
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = (-1L);/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3[10][1] = {{0xB96CA2CBL},{0x847DFA86L},{0x847DFA86L},{0xB96CA2CBL},{0x847DFA86L},{0x847DFA86L},{0xB96CA2CBL},{0x847DFA86L},{0x847DFA86L},{0xB96CA2CBL}};
static volatile int32_t g_4 = 0x33992443L;/* VOLATILE GLOBAL g_4 */
static int32_t g_5 = 0xE6DA5043L;
static uint8_t g_40 = 247UL;
static int16_t g_48[1][7] = {{0xD36FL,0xD36FL,0x87E9L,0xD36FL,0xD36FL,0x87E9L,0xD36FL}};
static int64_t g_49 = 0L;
static int32_t g_61[3] = {0xC525AC89L,0xC525AC89L,0xC525AC89L};
static uint16_t g_63[10] = {65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL};
static uint64_t g_89[7][7][5] = {{{0x691D145C15DC1C47LL,0UL,0x691D145C15DC1C47LL,0xB07C152A3E9F7A6BLL,0x0E9B23D7FF4CBEB0LL},{0x0C19ED05CE631D61LL,0x01B1C7CC60535321LL,7UL,0UL,0xAA3B2A51D28A62AFLL},{0x0E9B23D7FF4CBEB0LL,5UL,0xCF5FC6D38C14FD42LL,0xCF5FC6D38C14FD42LL,5UL},{0x23C0F0EF91DD11AFLL,0xE6AC69B762B02D37LL,18446744073709551611UL,0x01B1C7CC60535321LL,0UL},{0x05658C465D2E07F6LL,1UL,0xCF5FC6D38C14FD42LL,0UL,2UL},{7UL,0x592AE175A3989555LL,0x36D0B4E555501D2DLL,0UL,18446744073709551615UL},{0x05658C465D2E07F6LL,5UL,0x22F2C889DD98AE1FLL,0xB07C152A3E9F7A6BLL,0UL}},{{0x36D0B4E555501D2DLL,0x676063AEBC018302LL,0x0C19ED05CE631D61LL,18446744073709551613UL,0x0C19ED05CE631D61LL},{8UL,8UL,0UL,0xB07C152A3E9F7A6BLL,0x22F2C889DD98AE1FLL},{0xAA3B2A51D28A62AFLL,0x708938AD3921C45DLL,18446744073709551615UL,0UL,0x36D0B4E555501D2DLL},{0xCF5FC6D38C14FD42LL,0UL,2UL,0UL,0xCF5FC6D38C14FD42LL},{0UL,0x708938AD3921C45DLL,0UL,0x01B1C7CC60535321LL,18446744073709551611UL},{0xB07C152A3E9F7A6BLL,8UL,0x589AB98CFE46DA04LL,5UL,5UL},{18446744073709551608UL,0x676063AEBC018302LL,18446744073709551608UL,0x708938AD3921C45DLL,18446744073709551611UL}},{{0x691D145C15DC1C47LL,5UL,8UL,0x6279EA335EF5641ELL,0xCF5FC6D38C14FD42LL},{18446744073709551611UL,0x592AE175A3989555LL,0x23C0F0EF91DD11AFLL,18446744073709551612UL,0x36D0B4E555501D2DLL},{0x589AB98CFE46DA04LL,1UL,8UL,0xCF5FC6D38C14FD42LL,0x22F2C889DD98AE1FLL},{0x67D2F72762B6CB16LL,0xE6AC69B762B02D37LL,18446744073709551608UL,0xB519BE197FD74DCCLL,0x0C19ED05CE631D61LL},{0x0E9B23D7FF4CBEB0LL,0x589AB98CFE46DA04LL,0x589AB98CFE46DA04LL,0x0E9B23D7FF4CBEB0LL,0UL},{0x67D2F72762B6CB16LL,18446744073709551612UL,0UL,0UL,18446744073709551615UL},{0x589AB98CFE46DA04LL,0x05658C465D2E07F6LL,2UL,8UL,2UL}},{{18446744073709551611UL,18446744073709551613UL,18446744073709551615UL,0UL,0UL},{0x691D145C15DC1C47LL,0x6279EA335EF5641ELL,0UL,0x0E9B23D7FF4CBEB0LL,0x589AB98CFE46DA04LL},{18446744073709551608UL,0xB519BE197FD74DCCLL,0x0C19ED05CE631D61LL,0xB519BE197FD74DCCLL,18446744073709551608UL},{0xB07C152A3E9F7A6BLL,0x6279EA335EF5641ELL,0x22F2C889DD98AE1FLL,0xCF5FC6D38C14FD42LL,8UL},{0UL,18446744073709551613UL,0x36D0B4E555501D2DLL,18446744073709551612UL,0x23C0F0EF91DD11AFLL},{0xCF5FC6D38C14FD42LL,0x05658C465D2E07F6LL,0xCF5FC6D38C14FD42LL,0x6279EA335EF5641ELL,8UL},{0xAA3B2A51D28A62AFLL,18446744073709551612UL,18446744073709551611UL,0x708938AD3921C45DLL,18446744073709551608UL}},{{8UL,0x589AB98CFE46DA04LL,5UL,5UL,0x589AB98CFE46DA04LL},{0x36D0B4E555501D2DLL,0xE6AC69B762B02D37LL,18446744073709551611UL,0x01B1C7CC60535321LL,0UL},{0x05658C465D2E07F6LL,1UL,0xCF5FC6D38C14FD42LL,0UL,2UL},{7UL,0x592AE175A3989555LL,0x36D0B4E555501D2DLL,0UL,18446744073709551615UL},{0x05658C465D2E07F6LL,5UL,0x22F2C889DD98AE1FLL,0xB07C152A3E9F7A6BLL,0UL},{0x36D0B4E555501D2DLL,0x676063AEBC018302LL,0x0C19ED05CE631D61LL,18446744073709551613UL,0x0C19ED05CE631D61LL},{8UL,8UL,0UL,0xB07C152A3E9F7A6BLL,0x22F2C889DD98AE1FLL}},{{0xAA3B2A51D28A62AFLL,0x708938AD3921C45DLL,18446744073709551615UL,0UL,0x36D0B4E555501D2DLL},{0xCF5FC6D38C14FD42LL,0UL,2UL,0UL,0xCF5FC6D38C14FD42LL},{0UL,0x708938AD3921C45DLL,0UL,0x01B1C7CC60535321LL,18446744073709551611UL},{0xB07C152A3E9F7A6BLL,8UL,0x589AB98CFE46DA04LL,5UL,5UL},{18446744073709551608UL,0x676063AEBC018302LL,18446744073709551608UL,0x708938AD3921C45DLL,18446744073709551611UL},{0x691D145C15DC1C47LL,5UL,8UL,0x6279EA335EF5641ELL,0xCF5FC6D38C14FD42LL},{18446744073709551611UL,0x592AE175A3989555LL,0x36D0B4E555501D2DLL,0x592AE175A3989555LL,7UL}},{{0x0E9B23D7FF4CBEB0LL,0x22F2C889DD98AE1FLL,0UL,5UL,2UL},{0UL,9UL,0x23C0F0EF91DD11AFLL,0x676063AEBC018302LL,0xAA3B2A51D28A62AFLL},{8UL,0x0E9B23D7FF4CBEB0LL,0x0E9B23D7FF4CBEB0LL,8UL,0x05658C465D2E07F6LL},{0UL,0x592AE175A3989555LL,0x0C19ED05CE631D61LL,0x708938AD3921C45DLL,0x67D2F72762B6CB16LL},{0x0E9B23D7FF4CBEB0LL,0xB07C152A3E9F7A6BLL,0x691D145C15DC1C47LL,0UL,0x691D145C15DC1C47LL},{18446744073709551615UL,0xB519BE197FD74DCCLL,0x67D2F72762B6CB16LL,0x708938AD3921C45DLL,0x0C19ED05CE631D61LL},{0xCF5FC6D38C14FD42LL,1UL,0x05658C465D2E07F6LL,8UL,0x0E9B23D7FF4CBEB0LL}}};
static int32_t g_114 = 0x954D451FL;
static uint16_t g_127 = 65535UL;
static uint64_t g_137 = 0xDC5F9BFDDA3525E9LL;
static int32_t g_148 = 0xED989C8FL;
static int32_t *g_150 = &g_61[0];
static int32_t * volatile *g_149 = &g_150;
static uint8_t g_152 = 0x4CL;
static int64_t g_175 = 0x93BDCD76EB741D22LL;
static int32_t g_251 = (-2L);
static const uint8_t *g_325 = &g_40;
static const uint8_t **g_324[2][3][3] = {{{(void*)0,&g_325,&g_325},{(void*)0,&g_325,&g_325},{(void*)0,&g_325,&g_325}},{{(void*)0,&g_325,&g_325},{(void*)0,&g_325,&g_325},{(void*)0,&g_325,&g_325}}};
static int8_t g_382 = 0xD5L;
static int64_t g_406 = 0x6EA1B7AEE73A9112LL;
static uint64_t *g_445 = &g_137;
static uint32_t g_458 = 1UL;
static int32_t g_546 = 0xC05D758FL;
static uint32_t g_698 = 0x0E19FBEDL;
static const int32_t *g_720 = &g_61[2];
static const int32_t **g_719[8] = {&g_720,&g_720,&g_720,&g_720,&g_720,&g_720,&g_720,&g_720};
static const int32_t ***g_718[3] = {&g_719[5],&g_719[5],&g_719[5]};
static int32_t **g_777 = &g_150;
static int32_t ***g_776 = &g_777;
static uint8_t g_822[2] = {0xB2L,0xB2L};
static uint32_t *g_825 = &g_458;
static uint8_t g_828[9] = {248UL,0UL,248UL,248UL,0UL,248UL,248UL,0UL,248UL};
static uint16_t g_930 = 7UL;
static int32_t g_935 = 0x7139097FL;
static int8_t g_946[2][4][5] = {{{0x22L,0x0FL,0x22L,2L,0x0FL},{(-6L),0x93L,2L,(-6L),2L},{(-6L),(-6L),0x8FL,0x0FL,0xC8L},{0x22L,0xC8L,2L,2L,0xC8L}},{{0xC8L,0x93L,0x22L,0xC8L,2L},{0x0FL,0xC8L,0x8FL,0xC8L,0x0FL},{0x22L,(-6L),0x93L,2L,(-6L)},{0x0FL,0x93L,0x93L,0x0FL,2L}}};
static volatile int32_t g_949 = 4L;/* VOLATILE GLOBAL g_949 */
static int8_t g_951 = 0xAEL;
static volatile int32_t g_952[1][8][5] = {{{0xC6CFC571L,0L,3L,3L,0L},{4L,(-6L),3L,3L,(-6L)},{0xC6CFC571L,0L,3L,3L,0L},{4L,(-6L),3L,3L,(-6L)},{0xC6CFC571L,0L,3L,3L,0L},{4L,(-6L),3L,3L,(-6L)},{0xC6CFC571L,0L,3L,3L,0L},{4L,(-6L),3L,3L,(-6L)}}};
static uint8_t * const g_994 = &g_828[8];
static uint8_t * const *g_993 = &g_994;
static int32_t **** volatile g_1011 = (void*)0;/* VOLATILE GLOBAL g_1011 */
static int32_t **** volatile g_1012 = &g_776;/* VOLATILE GLOBAL g_1012 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_8(int8_t  p_9);
static uint32_t  func_10(int8_t  p_11);
static uint32_t  func_25(int16_t  p_26, uint32_t  p_27, uint32_t  p_28, int16_t  p_29, uint32_t  p_30);
static int16_t  func_31(uint32_t  p_32, int16_t  p_33, uint32_t  p_34, int32_t  p_35, int8_t  p_36);
static int32_t  func_68(uint8_t * p_69, int16_t * const  p_70, int32_t ** p_71, uint32_t  p_72);
static uint8_t  func_77(uint64_t  p_78, uint64_t  p_79, int32_t ** p_80, const uint8_t * p_81);
static uint64_t  func_91(uint64_t * p_92);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_3 g_149 g_150 g_61 g_251 g_994 g_828 g_63 g_1012 g_776 g_777
 * writes: g_5 g_2 g_828 g_150 g_776
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_1006 = 1UL;
    int32_t l_1007 = 0xBB6D618FL;
    uint32_t **l_1008 = (void*)0;
    int32_t l_1021 = 0x847AE79FL;
    int32_t l_1022[10][1] = {{1L},{0x9313A709L},{1L},{0x9313A709L},{1L},{0x9313A709L},{1L},{0x9313A709L},{1L},{0x9313A709L}};
    int16_t l_1023 = 1L;
    int i, j;
    for (g_5 = 18; (g_5 >= 28); g_5++)
    { /* block id: 3 */
        g_2 = g_3[9][0];
    }
    if (func_8(g_5))
    { /* block id: 453 */
        int8_t l_1009[3];
        int32_t *l_1010 = (void*)0;
        int i;
        for (i = 0; i < 3; i++)
            l_1009[i] = 0x0BL;
        if (((safe_mul_func_int16_t_s_s(g_251, (safe_mod_func_int16_t_s_s((((l_1006 = ((*g_994) = (*g_994))) <= (((l_1007 <= l_1007) | 0x584E1E71AEDF6DA4LL) <= (l_1007 || ((-1L) >= ((l_1007 , l_1008) == &g_825))))) == (-4L)), l_1009[1])))) <= 3L))
        { /* block id: 456 */
            (*g_149) = l_1010;
            return g_63[4];
        }
        else
        { /* block id: 459 */
            (*g_1012) = &g_777;
        }
    }
    else
    { /* block id: 462 */
        int32_t *l_1013 = &g_61[2];
        int32_t *l_1014 = &g_61[2];
        int16_t l_1015 = (-5L);
        int32_t *l_1016 = &g_61[1];
        int32_t *l_1017 = (void*)0;
        int32_t *l_1018 = &g_61[2];
        int32_t *l_1019 = (void*)0;
        int32_t *l_1020[2];
        uint32_t l_1024 = 0xCFC6EC2CL;
        int i;
        for (i = 0; i < 2; i++)
            l_1020[i] = &g_5;
        (*g_149) = (***g_1012);
        l_1024++;
    }
    return g_63[7];
}


/* ------------------------------------------ */
/* 
 * reads : g_149 g_150 g_61
 * writes:
 */
static int32_t  func_8(int8_t  p_9)
{ /* block id: 6 */
    int32_t l_977 = 0x4ECF26B7L;
    uint16_t *l_978[9] = {&g_127,&g_63[0],&g_127,&g_63[0],&g_127,&g_63[0],&g_127,&g_63[0],&g_127};
    int32_t l_979 = (-7L);
    int32_t *l_980 = (void*)0;
    int32_t *l_981 = (void*)0;
    int32_t l_982 = 0xB5CB2309L;
    uint8_t *l_992[1][10][2];
    uint8_t **l_991 = &l_992[0][9][1];
    uint8_t ***l_990 = &l_991;
    uint8_t * const **l_995 = &g_993;
    int16_t *l_998 = &g_48[0][0];
    int32_t l_999 = 4L;
    int32_t *l_1000 = &l_999;
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 2; k++)
                l_992[i][j][k] = &g_828[3];
        }
    }
    return (**g_149);
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_5 g_40 g_48 g_49 g_63 g_61 g_114 g_127 g_148 g_149 g_150 g_175 g_251 g_137 g_89 g_152 g_325 g_546 g_458 g_406 g_382 g_698 g_718 g_825 g_930 g_822 g_935
 * writes: g_40 g_48 g_63 g_89 g_5 g_61 g_49 g_127 g_251 g_114 g_137 g_546 g_152 g_148 g_149 g_382 g_718 g_175 g_930 g_935
 */
static uint32_t  func_10(int8_t  p_11)
{ /* block id: 7 */
    int32_t l_16 = 0x70512A30L;
    uint8_t *l_39 = &g_40;
    int16_t *l_47 = &g_48[0][3];
    int32_t l_933 = 0x1FC61B84L;
    int32_t *l_934 = &g_935;
    int32_t l_945 = 0xD23351C3L;
    int32_t l_947[4][2][6];
    int16_t l_950 = 6L;
    int32_t l_954 = 0x63152393L;
    int32_t *l_960 = (void*)0;
    int32_t *l_961 = &g_61[2];
    int32_t *l_962 = &g_61[1];
    int32_t *l_963 = &g_61[2];
    int32_t *l_964 = &l_933;
    int32_t *l_965 = &g_5;
    int32_t *l_966 = &g_5;
    int32_t *l_967 = &l_947[1][0][3];
    int32_t *l_968 = (void*)0;
    int32_t *l_969 = &l_933;
    int32_t *l_970[1][5][8] = {{{&l_947[0][1][2],&g_935,&l_947[0][1][2],&l_947[0][1][2],&g_935,&l_947[0][1][2],&l_947[0][1][2],&g_935},{&g_935,&l_947[0][1][2],&l_947[0][1][2],&g_935,&l_947[0][1][2],&l_947[1][0][3],&l_947[0][1][2],&l_947[1][0][3]},{&l_947[0][1][2],&l_947[0][1][2],&g_935,&l_947[0][1][2],&l_947[0][1][2],&g_935,&l_947[0][1][2],&l_947[0][1][2]},{&l_947[1][0][3],&l_947[0][1][2],&l_947[1][0][3],&l_947[1][0][3],&l_947[0][1][2],&l_947[1][0][3],&l_947[1][0][3],&l_947[0][1][2]},{&l_947[0][1][2],&l_947[1][0][3],&l_947[1][0][3],&l_947[0][1][2],&l_947[1][0][3],&l_947[1][0][3],&l_947[0][1][2],&l_947[1][0][3]}}};
    uint16_t l_971[6][9] = {{0UL,0UL,0x75D0L,0x8995L,1UL,1UL,0x8995L,0x75D0L,0UL},{0UL,2UL,65533UL,2UL,0UL,2UL,65533UL,2UL,0UL},{1UL,0x8995L,0x75D0L,0UL,0UL,0x75D0L,0x8995L,1UL,1UL},{0x9868L,2UL,0x9868L,1UL,0x9868L,2UL,0x9868L,1UL,0x9868L},{1UL,0UL,0x8995L,0x8995L,0UL,1UL,0x75D0L,0x75D0L,1UL},{0UL,1UL,65533UL,1UL,0UL,1UL,65533UL,1UL,0UL}};
    uint32_t l_974 = 0xDC6EF7E8L;
    int i, j, k;
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 6; k++)
                l_947[i][j][k] = 0xE1FDF05AL;
        }
    }
lbl_959:
    (*l_934) |= (safe_lshift_func_uint8_t_u_s(((0x3BFAL > (l_933 ^= ((l_16 = (safe_rshift_func_int8_t_s_u(l_16, (g_4 == (safe_mul_func_int16_t_s_s((safe_lshift_func_uint16_t_u_u(((safe_mul_func_int8_t_s_s((safe_add_func_uint32_t_u_u(func_25(l_16, (((func_31(l_16, (g_5 , ((*l_47) |= (safe_div_func_int32_t_s_s((((*l_39)++) , g_5), (safe_add_func_int16_t_s_s(((safe_div_func_int64_t_s_s(l_16, (((p_11 || p_11) < 0UL) | g_5))) & 1UL), g_5)))))), g_49, p_11, g_49) , l_16) | l_16) & g_175), g_546, p_11, p_11), 0x29D64D85L)), 0xBDL)) == l_16), 12)), p_11)))))) < g_822[1]))) != 0xE57571A9L), g_406));
    for (g_137 = (-7); (g_137 <= 50); ++g_137)
    { /* block id: 437 */
        int16_t l_938 = 0x205EL;
        int32_t l_939[2][2][2] = {{{1L,1L},{0x54CF8AB3L,1L}},{{1L,0x54CF8AB3L},{1L,1L}}};
        int32_t *l_940 = &l_939[1][1][0];
        int32_t *l_941 = &l_933;
        int32_t *l_942 = &g_61[0];
        int32_t *l_943[5][1][5] = {{{&l_933,&l_933,(void*)0,(void*)0,&l_933}},{{&g_5,(void*)0,(void*)0,&l_933,&l_933}},{{(void*)0,&g_5,(void*)0,(void*)0,&l_933}},{{&l_933,&l_933,&l_933,&l_933,&l_933}},{{(void*)0,&l_933,&g_5,&l_933,&g_5}}};
        int64_t l_944 = (-5L);
        int16_t l_948 = 0xB5A9L;
        int64_t l_953 = 1L;
        int8_t l_955[1];
        uint32_t l_956 = 18446744073709551615UL;
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_955[i] = 1L;
        l_956++;
        if (g_49)
            goto lbl_959;
    }
    --l_971[4][6];
    (*l_961) &= 0L;
    return l_974;
}


/* ------------------------------------------ */
/* 
 * reads : g_149 g_150 g_61 g_114 g_89 g_5 g_152 g_148 g_48 g_698 g_40 g_718 g_325 g_127 g_137 g_546 g_825 g_458 g_930
 * writes: g_546 g_61 g_5 g_152 g_148 g_149 g_114 g_382 g_48 g_718 g_63 g_175 g_137 g_40 g_930
 */
static uint32_t  func_25(int16_t  p_26, uint32_t  p_27, uint32_t  p_28, int16_t  p_29, uint32_t  p_30)
{ /* block id: 256 */
    uint16_t l_642 = 0x981CL;
    int32_t l_746 = 0x3727D8F5L;
    int32_t l_751 = 6L;
    int32_t l_808 = 0L;
    int32_t l_809 = 8L;
    uint64_t l_810 = 0x8931DD2DCE3C5355LL;
    int32_t l_853 = 0x781AE244L;
    int32_t *l_920 = &g_61[2];
    int32_t *l_921 = &g_61[2];
    int32_t *l_922 = &l_808;
    int32_t *l_923 = &g_114;
    int32_t *l_924 = &g_5;
    int32_t *l_925 = &l_751;
    int32_t *l_926 = &l_809;
    int32_t *l_927[9][5][5] = {{{&g_61[2],&g_5,&g_61[0],&g_5,&g_61[2]},{&l_809,&g_114,&g_61[2],&g_61[2],&g_114},{(void*)0,(void*)0,&g_61[2],&g_5,&g_61[2]},{&g_114,&l_808,&l_809,&g_114,&g_114},{&l_751,&g_5,&l_751,(void*)0,&g_61[2]}},{{&g_114,&l_809,&g_61[2],&l_808,&l_809},{(void*)0,&g_5,&g_114,&g_5,(void*)0},{&l_809,&l_808,&g_61[2],&l_809,&g_114},{&g_61[2],(void*)0,&l_751,&g_5,&l_751},{&g_114,&g_114,&l_809,&l_808,&g_114}},{{&g_61[2],&g_5,&g_61[2],(void*)0,(void*)0},{&g_114,&g_61[2],&g_61[2],&g_114,&l_809},{&g_61[2],&g_5,&g_61[0],&g_5,&g_61[2]},{&l_809,&g_114,&g_61[2],&g_61[2],&g_114},{(void*)0,(void*)0,&g_61[2],&g_5,&g_61[2]}},{{&g_114,&l_808,&l_808,&l_809,&l_809},{&g_61[0],(void*)0,&g_61[0],&l_809,&l_751},{&l_809,&g_5,&l_809,&g_61[2],&g_5},{&g_61[2],(void*)0,(void*)0,(void*)0,&g_61[2]},{&g_5,&g_61[2],&l_809,&g_5,&l_809}},{{&l_751,&l_809,&g_61[0],(void*)0,&g_61[0]},{&l_809,&l_809,&l_808,&g_61[2],&l_809},{&g_114,(void*)0,&g_114,&l_809,&g_61[2]},{&l_809,&l_809,&l_809,&l_809,&g_5},{&l_751,(void*)0,&g_61[2],(void*)0,&l_751}},{{&g_5,&l_809,&l_809,&l_809,&l_809},{&g_61[2],&l_809,&g_114,(void*)0,&g_114},{&l_809,&g_61[2],&l_808,&l_809,&l_809},{&g_61[0],(void*)0,&g_61[0],&l_809,&l_751},{&l_809,&g_5,&l_809,&g_61[2],&g_5}},{{&g_61[2],(void*)0,(void*)0,(void*)0,&g_61[2]},{&g_5,&g_61[2],&l_809,&g_5,&l_809},{&l_751,&l_809,&g_61[0],(void*)0,&g_61[0]},{&l_809,&l_809,&l_808,&g_61[2],&l_809},{&g_114,(void*)0,&g_114,&l_809,&g_61[2]}},{{&l_809,&l_809,&l_809,&l_809,&g_5},{&l_751,(void*)0,&g_61[2],(void*)0,&l_751},{&g_5,&l_809,&l_809,&l_809,&l_809},{&g_61[2],&l_809,&g_114,(void*)0,&g_114},{&l_809,&g_61[2],&l_808,&l_809,&l_809}},{{&g_61[0],(void*)0,&g_61[0],&l_809,&l_751},{&l_809,&g_5,&l_809,&g_61[2],&g_5},{&g_61[2],(void*)0,(void*)0,(void*)0,&g_61[2]},{&g_5,&g_61[2],&l_809,&g_5,&l_809},{&l_751,&l_809,&g_61[0],(void*)0,&g_61[0]}}};
    int16_t l_928 = (-1L);
    int8_t l_929 = 0x09L;
    int i, j, k;
    if ((**g_149))
    { /* block id: 257 */
        int32_t *l_638 = &g_114;
        for (p_29 = 2; (p_29 <= 3); ++p_29)
        { /* block id: 260 */
            int32_t **l_639 = &l_638;
            (*l_639) = l_638;
            if ((**l_639))
                break;
            if (p_28)
                break;
            if ((**g_149))
                break;
        }
    }
    else
    { /* block id: 266 */
        int32_t *l_640 = &g_61[2];
        int32_t *l_641 = &g_61[0];
        uint8_t *l_761[6] = {&g_152,&g_152,&g_152,&g_152,&g_152,&g_152};
        uint8_t **l_760 = &l_761[5];
        uint8_t ** const *l_759 = &l_760;
        int32_t l_800[6][7] = {{0x4E9DFCB3L,0x4E9DFCB3L,6L,0x419043CEL,1L,(-2L),1L},{0x419043CEL,0x4E9DFCB3L,(-5L),(-2L),(-2L),(-5L),0x4E9DFCB3L},{(-5L),0L,0x4E9DFCB3L,1L,1L,(-5L),0x419043CEL},{(-5L),1L,0xEBBFF8F0L,0x4E9DFCB3L,0xEBBFF8F0L,1L,(-5L)},{0x419043CEL,(-5L),1L,1L,0x4E9DFCB3L,0L,(-5L)},{0x4E9DFCB3L,(-5L),(-5L),(-5L),1L,6L,(-5L)}};
        int8_t l_833 = (-1L);
        int32_t * const *l_879 = (void*)0;
        int32_t * const **l_878 = &l_879;
        int32_t * const ***l_877 = &l_878;
        int16_t l_887[1];
        int i, j;
        for (i = 0; i < 1; i++)
            l_887[i] = 0x8106L;
lbl_664:
        l_642--;
lbl_763:
        for (g_546 = (-14); (g_546 <= 19); g_546 = safe_add_func_uint64_t_u_u(g_546, 1))
        { /* block id: 270 */
            int32_t **l_647[3];
            int32_t l_648[10] = {0x608C6897L,0x608C6897L,(-6L),0xD3F6F535L,(-6L),0x608C6897L,0x608C6897L,(-6L),0xD3F6F535L,(-6L)};
            int32_t *l_692 = (void*)0;
            uint8_t *l_696[6] = {&g_40,&g_40,&g_40,&g_40,&g_40,&g_40};
            uint8_t **l_695[9] = {&l_696[5],&l_696[5],&l_696[5],&l_696[5],&l_696[5],&l_696[5],&l_696[5],&l_696[5],&l_696[5]};
            uint8_t ** const *l_694[2][5][8] = {{{&l_695[3],&l_695[2],&l_695[2],(void*)0,(void*)0,&l_695[4],&l_695[4],&l_695[4]},{(void*)0,(void*)0,&l_695[6],&l_695[0],(void*)0,&l_695[4],&l_695[4],&l_695[6]},{&l_695[7],&l_695[2],(void*)0,&l_695[6],&l_695[2],(void*)0,&l_695[4],&l_695[4]},{&l_695[6],&l_695[1],&l_695[2],(void*)0,&l_695[2],&l_695[1],&l_695[6],&l_695[4]},{&l_695[6],&l_695[6],&l_695[7],(void*)0,&l_695[3],&l_695[4],&l_695[5],&l_695[4]}},{{&l_695[2],&l_695[4],&l_695[4],&l_695[8],&l_695[3],&l_695[4],&l_695[6],(void*)0},{&l_695[6],&l_695[6],&l_695[8],&l_695[4],&l_695[2],&l_695[4],&l_695[0],&l_695[0]},{&l_695[6],&l_695[2],(void*)0,(void*)0,&l_695[2],&l_695[6],&l_695[8],&l_695[5]},{&l_695[7],&l_695[4],&l_695[4],&l_695[2],(void*)0,&l_695[5],&l_695[6],&l_695[4]},{(void*)0,&l_695[4],&l_695[4],&l_695[2],(void*)0,&l_695[6],&l_695[3],&l_695[5]}}};
            int32_t *l_727 = &l_648[1];
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_647[i] = &g_150;
            if ((**g_149))
                break;
            l_640 = &g_5;
            l_648[3] = ((**g_149) |= 0x24ED6F1AL);
            if ((((**g_149) = p_26) || ((((safe_add_func_uint32_t_u_u((safe_rshift_func_int16_t_s_u((safe_mod_func_int32_t_s_s((g_89[3][0][1] ^ 0x0AF2E559130B0FC9LL), (safe_sub_func_int64_t_s_s((safe_div_func_uint16_t_u_u(65527UL, ((safe_mod_func_int64_t_s_s(((l_642 || p_27) == ((void*)0 == &p_26)), (safe_div_func_uint16_t_u_u(0x7F2EL, p_27)))) , 1UL))), 0x39E9D2C87BD04EE3LL)))), p_29)), p_27)) , p_26) >= 0x24BAL) | (*l_640))))
            { /* block id: 276 */
                uint32_t l_663 = 4294967288UL;
                for (g_5 = 2; (g_5 <= 9); g_5 += 1)
                { /* block id: 279 */
                    if (l_663)
                        break;
                    if (p_28)
                    { /* block id: 281 */
                        return (*l_641);
                    }
                    else
                    { /* block id: 283 */
                        uint32_t l_665 = 0xFB70EA21L;
                        if (p_29)
                            goto lbl_664;
                        if (l_665)
                            break;
                        l_640 = &g_61[2];
                        (*l_641) = 0L;
                    }
                }
                for (g_152 = (-15); (g_152 <= 49); g_152 = safe_add_func_uint32_t_u_u(g_152, 5))
                { /* block id: 292 */
                    int16_t l_675 = (-4L);
                    int32_t *l_691 = &g_251;
                    int32_t **l_690 = &l_691;
                    int32_t l_697 = (-1L);
                    int8_t *l_699 = (void*)0;
                    int8_t *l_700 = (void*)0;
                    int8_t *l_701 = (void*)0;
                    int8_t *l_702 = (void*)0;
                    int8_t *l_703[7][9] = {{&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382},{&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382},{&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382},{&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382},{&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382},{&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382},{&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382,&g_382}};
                    const int32_t *l_705 = (void*)0;
                    int i, j;
                    for (g_148 = 0; (g_148 != 12); g_148 = safe_add_func_uint32_t_u_u(g_148, 3))
                    { /* block id: 295 */
                        uint8_t *l_673 = (void*)0;
                        uint8_t *l_674[2][10][7] = {{{(void*)0,&g_40,(void*)0,&g_152,&g_152,&g_40,(void*)0},{&g_40,&g_152,&g_40,&g_152,(void*)0,(void*)0,&g_40},{&g_152,(void*)0,&g_40,&g_152,&g_40,&g_152,&g_40},{&g_152,&g_40,&g_40,&g_152,&g_40,(void*)0,&g_152},{&g_40,(void*)0,&g_40,&g_40,&g_40,&g_40,&g_40},{&g_152,(void*)0,&g_152,&g_152,(void*)0,&g_152,&g_40},{&g_40,&g_40,&g_152,&g_40,(void*)0,&g_152,(void*)0},{&g_152,&g_40,&g_40,&g_152,&g_152,(void*)0,&g_152},{(void*)0,&g_40,&g_40,(void*)0,(void*)0,&g_40,&g_40},{(void*)0,(void*)0,&g_152,&g_40,&g_152,&g_40,&g_152}},{{&g_152,(void*)0,&g_40,&g_40,&g_40,&g_40,&g_40},{&g_40,&g_40,&g_40,(void*)0,&g_40,&g_40,&g_152},{&g_152,&g_40,&g_152,&g_40,&g_152,&g_40,(void*)0},{&g_40,&g_40,&g_40,&g_152,&g_40,&g_40,&g_40},{&g_152,&g_40,(void*)0,&g_152,&g_40,(void*)0,&g_40},{&g_152,&g_152,(void*)0,&g_40,&g_152,&g_152,&g_152},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_152,&g_40},{&g_40,(void*)0,&g_40,&g_40,&g_152,&g_40,&g_152},{(void*)0,&g_152,&g_152,&g_40,(void*)0,(void*)0,&g_40},{&g_40,&g_40,&g_40,(void*)0,(void*)0,&g_152,&g_40}}};
                        int i, j, k;
                        l_675 &= (+(safe_lshift_func_uint8_t_u_u((((((*l_641) = p_30) != g_48[0][4]) ^ (0L <= (p_28 >= (0xA900L > l_642)))) | 0UL), p_29)));
                    }
                    for (p_30 = 2; (p_30 == 29); p_30 = safe_add_func_uint8_t_u_u(p_30, 7))
                    { /* block id: 301 */
                        int32_t ***l_678 = (void*)0;
                        int32_t ***l_679[8];
                        int i;
                        for (i = 0; i < 8; i++)
                            l_679[i] = &l_647[2];
                        if ((*g_150))
                            break;
                        g_149 = l_647[0];
                    }
                    (*l_640) = ((safe_sub_func_int16_t_s_s((g_48[0][2] = ((-3L) | ((g_5 && (g_382 = (safe_mod_func_int32_t_s_s(((((((void*)0 != l_640) , (safe_sub_func_int64_t_s_s(p_28, ((safe_add_func_int64_t_s_s((*l_640), ((((*l_690) = &g_546) != l_692) & (l_697 = (g_114 = (~((l_694[0][4][6] == (void*)0) || 0x05L))))))) , g_698)))) , (void*)0) == (void*)0) , 0x0F14A72CL), 8L)))) > p_26))), p_26)) , 0x5AFCE4DCL);
                    l_705 = ((+p_29) , (void*)0);
                }
            }
            else
            { /* block id: 313 */
                int8_t l_726 = 0x9AL;
                int32_t *l_728 = (void*)0;
                uint16_t *l_747 = &l_642;
                int16_t l_748 = 0x776CL;
                int64_t *l_749 = &g_175;
                const uint16_t l_750[3][3][7] = {{{0x1D50L,0UL,65535UL,0UL,0x1D50L,65526UL,65535UL},{0UL,0xA58BL,65535UL,0x4AF3L,0UL,65535UL,0x6080L},{0x4AF3L,0x3D33L,0xDDC9L,65535UL,65535UL,0xDDC9L,0x3D33L}},{{0UL,0x4AF3L,0xA58BL,65535UL,0x2EC4L,0xDDC9L,65526UL},{0x1D50L,0xA93FL,0UL,65535UL,0x4C9AL,65535UL,0x4C9AL},{65535UL,0x4C9AL,0x4C9AL,65535UL,7UL,65526UL,65535UL}},{{65526UL,0x4C9AL,0x1D50L,65535UL,0UL,7UL,0UL},{65535UL,0xA93FL,65526UL,0x4AF3L,65526UL,0xA93FL,65535UL},{0x2EC4L,0x4AF3L,0xA93FL,0UL,65526UL,0x3D33L,0x4C9AL}}};
                int i, j, k;
                for (l_642 = 0; (l_642 == 28); l_642++)
                { /* block id: 316 */
                    int16_t l_711 = 0x55B2L;
                    const int32_t ****l_721 = &g_718[2];
                    (**g_149) = (safe_unary_minus_func_int32_t_s(((safe_mul_func_uint16_t_u_u(l_711, (((-7L) & 0x81L) | ((l_726 = (((safe_sub_func_uint64_t_u_u(((safe_mod_func_int64_t_s_s((g_48[0][3] | (safe_lshift_func_uint16_t_u_u(0UL, 5))), g_40)) >= ((((*l_721) = g_718[2]) != &g_719[5]) | (safe_sub_func_int16_t_s_s(((safe_mul_func_int16_t_s_s(0x7F3CL, g_114)) >= p_29), 0x137FL)))), p_30)) < p_27) < 0UL)) < (*l_641))))) , 0x8BBD93E7L)));
                    l_728 = l_727;
                }
                l_751 &= (+((((*l_749) = (safe_mod_func_uint32_t_u_u(p_26, ((safe_lshift_func_uint8_t_u_u((*g_325), 5)) , ((((safe_add_func_int32_t_s_s(((0x9FCDFB52L | 0xB30727EBL) >= ((*l_747) = (g_148 , (g_63[9] = (safe_mul_func_uint16_t_u_u((safe_sub_func_uint32_t_u_u((((void*)0 != &l_642) || (safe_div_func_uint32_t_u_u(((((safe_mod_func_uint16_t_u_u(((((safe_lshift_func_int16_t_s_u(((g_5 && l_726) < 0x9212L), g_127)) == p_28) && l_746) || p_30), 0x2194L)) && 4294967291UL) | 1UL) ^ 0xAEL), (*l_640)))), 0x2B844C22L)), g_61[2])))))), 0x60B3A69CL)) , p_30) , l_748) ^ (*l_640)))))) >= l_750[0][2][6]) ^ 0x08AE4165L));
                (*l_641) |= ((*l_640) >= (*l_640));
            }
        }
        for (p_26 = 0; (p_26 > (-24)); p_26 = safe_sub_func_int16_t_s_s(p_26, 9))
        { /* block id: 331 */
            uint64_t l_754 = 0UL;
            (**g_149) ^= l_754;
            l_751 = 0x656A2B90L;
        }
        for (g_137 = 27; (g_137 == 51); g_137++)
        { /* block id: 337 */
            int32_t *l_765 = &g_61[2];
            int32_t l_799[8];
            int8_t l_829[5];
            const int32_t * const *l_872 = &g_720;
            const int32_t * const **l_871 = &l_872;
            uint64_t l_883 = 18446744073709551615UL;
            uint32_t l_889 = 0xC57CB7EEL;
            int i;
            for (i = 0; i < 8; i++)
                l_799[i] = 0L;
            for (i = 0; i < 5; i++)
                l_829[i] = 8L;
            if ((**g_149))
                break;
            for (l_751 = 0; (l_751 == (-15)); l_751--)
            { /* block id: 341 */
                uint8_t ** const **l_762 = &l_759;
                int32_t *l_764[5];
                int i;
                for (i = 0; i < 5; i++)
                    l_764[i] = &g_114;
                (*l_762) = l_759;
                if (g_546)
                    goto lbl_763;
                l_765 = l_764[4];
            }
            for (p_30 = 0; (p_30 < 3); p_30 = safe_add_func_uint64_t_u_u(p_30, 2))
            { /* block id: 348 */
                int32_t *l_768 = &g_61[2];
                int32_t l_802 = 0L;
                int32_t l_804 = 0x232A1A09L;
                int32_t l_806[8][6][2] = {{{(-1L),0L},{0L,(-1L)},{0L,(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)}},{{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)}},{{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)}},{{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)}},{{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)}},{{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)}},{{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)}},{{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)}}};
                uint32_t l_815 = 4294967295UL;
                int32_t *l_838 = &l_746;
                int32_t **l_837 = &l_838;
                int16_t l_888 = 0x4311L;
                int i, j, k;
            }
            for (g_40 = 0; (g_40 > 51); g_40 = safe_add_func_uint8_t_u_u(g_40, 8))
            { /* block id: 425 */
                return (*g_825);
            }
        }
    }
    --g_930;
    return p_29;
}


/* ------------------------------------------ */
/* 
 * reads : g_63 g_61 g_49 g_114 g_48 g_5 g_127 g_148 g_149 g_150 g_175 g_251 g_137 g_40 g_89 g_152 g_325 g_546 g_458 g_406 g_382
 * writes: g_63 g_89 g_5 g_61 g_49 g_127 g_251 g_114 g_137 g_40
 */
static int16_t  func_31(uint32_t  p_32, int16_t  p_33, uint32_t  p_34, int32_t  p_35, int8_t  p_36)
{ /* block id: 10 */
    int32_t *l_50 = (void*)0;
    int32_t *l_51 = &g_5;
    int32_t *l_52 = &g_5;
    int32_t *l_53 = &g_5;
    int32_t *l_54 = (void*)0;
    int32_t *l_55 = &g_5;
    int32_t l_56 = 0xD4DB1D70L;
    int32_t *l_57 = &g_5;
    int32_t *l_58 = &l_56;
    int32_t l_59 = (-1L);
    int32_t *l_60[9] = {&l_56,&l_56,&l_56,&l_56,&l_56,&l_56,&l_56,&l_56,&l_56};
    int32_t l_62[4][4][4] = {{{0xFAE38EDFL,1L,0x4AA7FCF6L,0x4AA7FCF6L},{(-1L),(-1L),0x05F459CAL,0xA41D407BL},{5L,0L,0xB69233C9L,1L},{0xB69233C9L,1L,0xFAE38EDFL,0xB69233C9L}},{{(-1L),1L,8L,1L},{1L,0L,0x4AA7FCF6L,0xA41D407BL},{1L,(-1L),0xFAE38EDFL,0x4AA7FCF6L},{5L,1L,0xC8D21259L,1L}},{{5L,0xFAE38EDFL,0xFAE38EDFL,5L},{1L,1L,0x4AA7FCF6L,0xFAE38EDFL},{1L,1L,8L,0xA41D407BL},{(-1L),1L,0xFAE38EDFL,0xA41D407BL}},{{0xB69233C9L,1L,0xB69233C9L,0xFAE38EDFL},{5L,1L,0x05F459CAL,5L},{(-1L),0xFAE38EDFL,0x4AA7FCF6L,1L},{0xFAE38EDFL,1L,0x4AA7FCF6L,0x4AA7FCF6L}}};
    int32_t **l_66 = (void*)0;
    int32_t **l_67 = &l_60[0];
    uint8_t *l_73 = &g_40;
    uint64_t *l_88 = &g_89[3][0][1];
    uint64_t *l_254 = &g_137;
    int16_t * const l_523 = &g_48[0][3];
    uint8_t l_618[4][3] = {{0UL,0UL,0x67L},{0UL,0UL,0x67L},{0UL,0UL,0x67L},{0UL,0UL,0x67L}};
    int64_t l_635 = 0x4E8F4DB8707F7793LL;
    int i, j, k;
    ++g_63[0];
    (*l_67) = (void*)0;
    (*l_58) ^= func_68(l_73, (((safe_unary_minus_func_int16_t_s((p_33 = (((((safe_mul_func_uint8_t_u_u(((*l_73) = func_77((safe_mod_func_uint64_t_u_u(((*l_254) |= (safe_lshift_func_int16_t_s_u((safe_mod_func_uint64_t_u_u(((*l_88) = 0x1BBA4BA9E7339AA8LL), ((g_61[2] && ((safe_unary_minus_func_uint64_t_u(func_91(l_88))) || p_32)) , ((-5L) && p_32)))), (&g_63[0] != (void*)0)))), 0x218EFC80D1E5C2C5LL)), p_33, &l_55, &g_40)), p_36)) != 254UL) , p_34) , g_89[3][0][1]) > g_152)))) | p_36) , l_523), &g_150, g_63[0]);
    for (p_36 = (-29); (p_36 >= 29); ++p_36)
    { /* block id: 221 */
        int32_t l_528 = 0L;
        uint16_t l_542 = 0UL;
        uint64_t l_567 = 0x45B956C92B84B651LL;
        (*l_55) = (((~l_528) < (p_35 ^ ((safe_sub_func_uint8_t_u_u((safe_mul_func_int16_t_s_s((&g_137 == (void*)0), ((safe_div_func_int32_t_s_s(0x32937B95L, (safe_mul_func_uint16_t_u_u((((safe_mul_func_uint8_t_u_u((*g_325), (g_48[0][5] == ((~(safe_mul_func_uint8_t_u_u(p_32, 0x2EL))) || g_61[1])))) != p_35) != (*l_57)), (-3L))))) , 0x31CFL))), 248UL)) < g_61[0]))) >= l_542);
        for (g_5 = 1; (g_5 >= 0); g_5 -= 1)
        { /* block id: 225 */
            int32_t *l_543[1][8][1] = {{{&g_61[2]},{&l_59},{&g_61[2]},{&l_59},{&g_61[2]},{&l_59},{&g_61[2]},{&l_59}}};
            uint16_t l_566 = 0UL;
            int8_t l_611[3];
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_611[i] = 0L;
            (*l_67) = l_543[0][2][0];
            if (p_32)
                continue;
            (*g_150) = (safe_rshift_func_uint8_t_u_s(l_528, 7));
            if (g_546)
                continue;
            for (g_251 = 0; (g_251 >= 0); g_251 -= 1)
            { /* block id: 232 */
                int32_t l_614 = (-7L);
                int i, j, k;
                if ((safe_add_func_int8_t_s_s((safe_add_func_uint16_t_u_u((((g_48[g_251][(g_251 + 1)] , (&p_33 != &g_48[0][3])) != ((safe_mul_func_int8_t_s_s((0xEA85B2AB40D87BF4LL >= (safe_div_func_uint64_t_u_u(p_33, (((safe_unary_minus_func_uint8_t_u((safe_rshift_func_uint8_t_u_s(((((((safe_mod_func_int16_t_s_s(0x6727L, (safe_rshift_func_uint16_t_u_s(g_152, (safe_add_func_uint8_t_u_u((safe_add_func_uint8_t_u_u(p_35, (((((*l_58) &= (**g_149)) , g_48[g_251][(g_251 + 1)]) <= p_32) ^ p_33))), 253UL)))))) >= l_542) , g_458) | p_35) && p_33) , p_34), 5)))) >= 0xBDL) || g_48[g_251][(g_251 + 1)])))), 1UL)) ^ l_566)) , 0UL), g_48[g_251][(g_251 + 1)])), p_36)))
                { /* block id: 234 */
                    ++l_567;
                }
                else
                { /* block id: 236 */
                    int32_t l_613[1][5] = {{(-10L),(-10L),(-10L),(-10L),(-10L)}};
                    int32_t **l_621 = (void*)0;
                    uint32_t *l_628[9][6] = {{&g_458,&g_458,&g_458,(void*)0,&g_458,&g_458},{&g_458,&g_458,(void*)0,&g_458,&g_458,&g_458},{(void*)0,&g_458,&g_458,&g_458,&g_458,&g_458},{&g_458,&g_458,(void*)0,(void*)0,&g_458,&g_458},{&g_458,(void*)0,&g_458,&g_458,&g_458,&g_458},{(void*)0,&g_458,&g_458,&g_458,&g_458,&g_458},{(void*)0,&g_458,&g_458,&g_458,&g_458,&g_458},{&g_458,&g_458,&g_458,(void*)0,&g_458,&g_458},{&g_458,&g_458,&g_458,&g_458,&g_458,&g_458}};
                    int i, j;
                    for (l_566 = 0; (l_566 <= 1); l_566 += 1)
                    { /* block id: 239 */
                        int32_t *l_570 = &g_61[2];
                        uint16_t *l_579 = &l_542;
                        int8_t l_612[9][5][5] = {{{0x31L,(-1L),0xB7L,(-1L),0x88L},{(-9L),0x47L,0xB9L,0x47L,(-9L)},{0xB7L,(-1L),0xB6L,(-4L),0xAFL},{(-9L),1L,1L,(-9L),0x80L},{0x31L,1L,(-1L),(-1L),0xAFL}},{{0x07L,(-9L),0x07L,0x80L,(-9L)},{0xAFL,(-1L),0x88L,(-1L),0x88L},{0x85L,0x85L,0xB9L,(-9L),0x47L},{0xB7L,(-1L),0x88L,(-4L),0x31L},{0x47L,1L,0x07L,0x47L,0x80L}},{{0x0AL,(-1L),(-1L),(-1L),0x0AL},{0x07L,0x85L,1L,0x80L,0x85L},{0x0AL,(-1L),0xB6L,1L,0x88L},{0x47L,(-9L),0xB9L,0x85L,0x85L},{0xB7L,1L,0xB7L,(-4L),0x0AL}},{{0x85L,1L,0x80L,0x85L,0x80L},{0xAFL,(-1L),(-1L),1L,0x31L},{0x07L,0x47L,0x80L,0x80L,0x47L},{0x31L,(-1L),0xB7L,(-1L),0x88L},{(-9L),0x47L,0xB9L,0x47L,(-9L)}},{{0xB7L,(-1L),0xB6L,(-4L),0xAFL},{(-9L),1L,1L,(-9L),0x80L},{0x31L,1L,(-1L),(-1L),0xAFL},{0x07L,(-9L),0x07L,0x80L,(-9L)},{0xAFL,(-1L),0x88L,(-1L),0x88L}},{{0x85L,0x85L,0xB9L,(-9L),0x47L},{0xB7L,(-1L),0x88L,(-4L),0x31L},{0x47L,1L,0x07L,0x47L,1L},{0xB6L,(-4L),0xAFL,(-4L),0xB6L},{(-1L),0x07L,0xB9L,1L,0x07L}},{{0xB6L,0x7EL,(-1L),(-1L),0x4FL},{0x80L,1L,0x85L,0x07L,0x07L},{0x66L,(-1L),0x66L,0L,0xB6L},{0x07L,0xB9L,1L,0x07L,1L},{0xB7L,0L,0xAFL,(-1L),0x88L}},{{(-1L),0x80L,1L,1L,0x80L},{0x88L,0x7EL,0x66L,(-4L),0x4FL},{1L,0x80L,0x85L,0x80L,1L},{0x66L,0L,(-1L),0L,0xB7L},{1L,0xB9L,0xB9L,1L,1L}},{{0x88L,(-1L),0xAFL,0L,0xB7L},{(-1L),1L,(-1L),1L,1L},{0xB7L,0x7EL,0x4FL,0L,0x4FL},{0x07L,0x07L,0x85L,1L,0x80L},{0x66L,(-4L),0x4FL,0L,0x88L}}};
                        int i, j, k;
                        if ((*l_57))
                            break;
                        l_570 = &g_61[2];
                        l_614 = (p_34 >= (((safe_lshift_func_int8_t_s_u((safe_add_func_uint64_t_u_u((g_48[0][4] > ((((safe_mul_func_uint8_t_u_u((safe_div_func_int16_t_s_s(g_49, (++(*l_579)))), (((((**g_149) , (((p_33 != (((safe_mul_func_uint16_t_u_u((((safe_mod_func_int8_t_s_s(((p_34 && ((safe_sub_func_uint32_t_u_u((safe_sub_func_uint64_t_u_u((safe_add_func_int64_t_s_s((safe_div_func_int8_t_s_s((0xBDFC492FL > ((safe_unary_minus_func_int8_t_s(((((~(!(safe_rshift_func_int8_t_s_u((safe_div_func_uint64_t_u_u((safe_sub_func_uint8_t_u_u(0x90L, (safe_sub_func_uint8_t_u_u((((g_89[(g_251 + 4)][(l_566 + 4)][(g_251 + 1)] = ((safe_div_func_uint16_t_u_u(((safe_lshift_func_int16_t_s_s(((*g_150) || p_35), g_48[0][3])) != g_48[0][5]), l_567)) >= p_35)) & p_36) , l_611[2]), 0x2BL)))), g_48[g_251][(g_251 + 1)])), (*g_325))))) ^ g_49) < p_33) >= 0x2F6525754A440FA3LL))) == 1L)), (*l_570))), g_546)), 8UL)), g_48[g_251][(g_251 + 1)])) , (*l_570))) , g_114), 0x10L)) || p_34) , p_35), (-7L))) , (void*)0) == &g_324[0][2][1])) == (*g_150)) >= g_48[g_251][(g_251 + 1)])) | (-1L)) >= g_114) <= p_33))) == l_612[1][4][3]) && g_251) < 0x49C1L)), g_406)), (*g_325))) > 0L) , l_613[0][0]));
                    }
                    (*l_67) = (((!(safe_sub_func_int8_t_s_s(l_618[3][1], (((safe_rshift_func_int8_t_s_u(g_152, 3)) >= (l_621 == (g_406 , &g_150))) ^ (((safe_lshift_func_uint8_t_u_s(((((!0xD1805E72L) < (((!(l_614 = (safe_div_func_uint32_t_u_u(((-7L) > (l_542 <= (-10L))), g_251)))) <= g_382) || 0UL)) , &g_61[2]) == (void*)0), g_5)) && (*g_325)) | p_33))))) || p_34) , (void*)0);
                    return p_34;
                }
                (**g_149) = ((safe_sub_func_int64_t_s_s(0xCC71FEE7CABA7254LL, ((safe_sub_func_uint16_t_u_u(p_32, g_382)) != (((g_61[2] == (&l_618[3][1] != &l_618[2][0])) , (safe_sub_func_uint32_t_u_u((&l_566 == (void*)0), (*l_58)))) <= 0L)))) | l_567);
                return p_32;
            }
        }
    }
    return l_635;
}


/* ------------------------------------------ */
/* 
 * reads : g_150
 * writes: g_61
 */
static int32_t  func_68(uint8_t * p_69, int16_t * const  p_70, int32_t ** p_71, uint32_t  p_72)
{ /* block id: 215 */
    uint16_t l_524[2][10][10];
    int i, j, k;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 10; k++)
                l_524[i][j][k] = 65526UL;
        }
    }
    (**p_71) = 0x6B91B026L;
    return l_524[1][2][7];
}


/* ------------------------------------------ */
/* 
 * reads : g_251 g_63 g_149 g_150 g_61 g_40
 * writes: g_251 g_61
 */
static uint8_t  func_77(uint64_t  p_78, uint64_t  p_79, int32_t ** p_80, const uint8_t * p_81)
{ /* block id: 89 */
    uint8_t *l_361 = (void*)0;
    int32_t l_384 = (-1L);
    int32_t l_398 = 0x7C3E73E6L;
    int32_t l_428[3];
    int16_t l_446[5] = {0x228BL,0x228BL,0x228BL,0x228BL,0x228BL};
    int i;
    for (i = 0; i < 3; i++)
        l_428[i] = 8L;
    for (g_251 = 0; (g_251 <= (-15)); g_251 = safe_sub_func_int64_t_s_s(g_251, 4))
    { /* block id: 92 */
        uint16_t l_275 = 0UL;
        uint8_t *l_352[7] = {(void*)0,(void*)0,&g_152,(void*)0,(void*)0,&g_152,(void*)0};
        uint8_t **l_351 = &l_352[2];
        int32_t l_422[8][10][3] = {{{0L,0xDB8DE8F2L,1L},{0x39624D61L,0L,(-9L)},{1L,0xFC9181AFL,(-6L)},{0x3BD8B655L,5L,3L},{5L,4L,5L},{(-1L),0xBBC01CAAL,0x6C84A840L},{4L,0L,1L},{9L,4L,0xFC9181AFL},{0xFFD0E33AL,0xD963F0B2L,0x5F232603L},{9L,(-1L),(-1L)}},{{4L,0x39624D61L,1L},{(-1L),(-1L),1L},{5L,0x131CA756L,(-1L)},{0x3BD8B655L,0x8FAD088CL,(-1L)},{1L,(-9L),0xDB8DE8F2L},{0x39624D61L,(-1L),0x379EFA2BL},{0L,0L,0x131CA756L},{0x6C84A840L,0L,(-1L)},{4L,(-1L),(-6L)},{0x2FF14C85L,(-9L),0L}},{{1L,0x8FAD088CL,0L},{(-1L),0x131CA756L,0x2FF14C85L},{(-1L),(-1L),0xEC926091L},{(-9L),0x39624D61L,(-1L)},{4L,(-1L),0xFFD0E33AL},{0L,0xD963F0B2L,0x71E0C317L},{3L,4L,0xFFD0E33AL},{(-1L),0L,(-1L)},{0x1F85479DL,0xBBC01CAAL,0xEC926091L},{0x264A9727L,4L,0x2FF14C85L}},{{0L,5L,(-1L)},{1L,0x14F4EB47L,(-6L)},{3L,(-6L),0xEC926091L},{0xC451F9FFL,0x131CA756L,0x5F232603L},{0xFFD0E33AL,0xEC926091L,0x1AD27171L},{0xFFD0E33AL,4L,3L},{0xC451F9FFL,0x1F85479DL,0x131CA756L},{3L,5L,0xD5020AAAL},{1L,0xFC9181AFL,(-5L)},{1L,0x39624D61L,0x39624D61L}},{{5L,1L,0x3BD8B655L},{1L,(-1L),(-1L)},{(-1L),0x7664853EL,1L},{0x8FAD088CL,0xBBC01CAAL,0x14F4EB47L},{(-1L),0x7664853EL,0xC451F9FFL},{4L,(-1L),1L},{0xD963F0B2L,1L,0x1F85479DL},{0xD5020AAAL,0x39624D61L,0x8FAD088CL},{0x5F232603L,0xFC9181AFL,0L},{(-6L),5L,0xFC9181AFL}},{{0x6C84A840L,0x1F85479DL,9L},{0L,4L,0x71E0C317L},{1L,0xEC926091L,0x71E0C317L},{0L,0x131CA756L,9L},{(-1L),(-6L),0xFC9181AFL},{0x39624D61L,0x14F4EB47L,0L},{1L,(-1L),0x8FAD088CL},{0x1F85479DL,0x264A9727L,0x1F85479DL},{(-5L),0x379EFA2BL,1L},{0x264A9727L,0L,0xC451F9FFL}},{{0xDB8DE8F2L,4L,0x14F4EB47L},{(-9L),(-7L),1L},{0xDB8DE8F2L,0x5F232603L,(-1L)},{0x264A9727L,(-1L),0x3BD8B655L},{(-5L),0xD5020AAAL,0x39624D61L},{0x1F85479DL,0x1AD27171L,(-5L)},{1L,0x78884F4CL,0xD5020AAAL},{0x39624D61L,0xD963F0B2L,0x131CA756L},{(-1L),(-5L),3L},{0L,1L,0x1AD27171L}},{{1L,1L,0x5F232603L},{0L,(-5L),0xEC926091L},{0x6C84A840L,0xD963F0B2L,(-6L)},{(-6L),0x78884F4CL,(-1L)},{0x5F232603L,0x1AD27171L,0x6C84A840L},{0xD5020AAAL,0xD5020AAAL,0x2810D348L},{0xD963F0B2L,(-1L),5L},{4L,0x5F232603L,(-9L)},{(-1L),(-7L),1L},{0x8FAD088CL,4L,(-9L)}}};
        int32_t l_453 = 0L;
        uint32_t *l_457[9] = {&g_458,&g_458,&g_458,&g_458,&g_458,&g_458,&g_458,&g_458,&g_458};
        int64_t l_479 = 0x68B5FCE34533ADC3LL;
        int i, j, k;
    }
    (**g_149) |= ((g_63[2] != 0x9F9CE9BEDAE6367DLL) | g_63[8]);
    return (*p_81);
}


/* ------------------------------------------ */
/* 
 * reads : g_49 g_61 g_114 g_48 g_5 g_127 g_148 g_63 g_149 g_150 g_175 g_251
 * writes: g_5 g_61 g_49 g_127 g_251 g_114
 */
static uint64_t  func_91(uint64_t * p_92)
{ /* block id: 14 */
    int32_t l_99 = 0x8206E4EEL;
    int32_t *l_105 = &l_99;
    int32_t **l_104 = &l_105;
    int16_t l_115[7][7][1] = {{{0xF2DAL},{0xF2DAL},{0x0699L},{0x5C4FL},{0x8B10L},{0x8212L},{(-1L)}},{{0x9C2BL},{0xFAF4L},{2L},{(-1L)},{0x87C3L},{7L},{0x87C3L}},{{(-1L)},{2L},{0xFAF4L},{0x9C2BL},{(-1L)},{0x8212L},{0x8B10L}},{{0x5C4FL},{0x0699L},{0xF2DAL},{0xF2DAL},{0x0699L},{0x5C4FL},{0x8B10L}},{{0x8212L},{(-1L)},{0x9C2BL},{0xFAF4L},{2L},{(-1L)},{0x5C4FL}},{{0x47AAL},{0x5C4FL},{9L},{4L},{(-1L)},{(-1L)},{0x87C3L}},{{0xF58FL},{0xF2DAL},{7L},{0x302DL},{0x479BL},{0x479BL},{0x302DL}}};
    int32_t *l_116 = &g_5;
    int32_t l_180[1];
    int64_t l_186 = 0L;
    int8_t l_188 = 0x76L;
    uint32_t l_196 = 0UL;
    uint16_t *l_223 = &g_127;
    uint8_t *l_245[2];
    uint8_t **l_244 = &l_245[1];
    uint8_t *l_246 = &g_40;
    uint64_t *l_249 = &g_137;
    int8_t *l_250 = &l_188;
    uint64_t l_252 = 0x01DBE71DB8A99B17LL;
    int32_t *l_253[1][2][3] = {{{&l_180[0],&g_61[2],&l_180[0]},{&l_180[0],&g_61[2],&l_180[0]}}};
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_180[i] = (-5L);
    for (i = 0; i < 2; i++)
        l_245[i] = &g_152;
    (*l_116) |= (safe_mod_func_uint64_t_u_u((((safe_mul_func_uint16_t_u_u((safe_sub_func_uint8_t_u_u(l_99, (safe_mod_func_int8_t_s_s(l_99, (((safe_mul_func_uint8_t_u_u((0xA0L <= ((l_99 , &l_99) == ((*l_104) = &g_61[2]))), (((((safe_mod_func_int16_t_s_s(((safe_mul_func_uint8_t_u_u((safe_div_func_int16_t_s_s((((void*)0 == &g_48[0][3]) ^ (safe_sub_func_int8_t_s_s((l_99 , g_49), l_99))), g_61[2])), l_99)) > g_114), l_115[4][5][0])) ^ l_115[0][1][0]) > g_49) , 0UL) && (-1L)))) ^ 0xF286226FL) | g_49))))), g_48[0][3])) == g_49) > 255UL), l_99));
    for (l_99 = 0; (l_99 <= 2); l_99 += 1)
    { /* block id: 19 */
        uint16_t *l_130[7] = {&g_63[6],&g_63[3],&g_63[6],&g_63[6],&g_63[3],&g_63[6],&g_63[6]};
        int32_t l_163[7][2] = {{0L,0L},{0x4B1B4561L,0L},{0L,0x4B1B4561L},{0L,0L},{0x4B1B4561L,0L},{0L,0x4B1B4561L},{0L,0L}};
        int32_t l_177 = 0xC960B144L;
        int i, j;
        (**l_104) = ((*l_116) |= g_61[l_99]);
        if (g_49)
            break;
        for (g_49 = 0; (g_49 >= 0); g_49 -= 1)
        { /* block id: 25 */
            uint32_t l_124 = 0xAB669172L;
            int32_t l_153 = 0xDD03B609L;
            int32_t *l_178[1];
            int8_t l_194 = 0x11L;
            int i;
            for (i = 0; i < 1; i++)
                l_178[i] = (void*)0;
        }
    }
    g_114 ^= ((safe_mul_func_uint16_t_u_u(((*l_223)++), (((((safe_sub_func_uint8_t_u_u(4UL, (((safe_lshift_func_uint16_t_u_s((safe_add_func_int32_t_s_s((safe_mul_func_uint8_t_u_u(7UL, (safe_add_func_int8_t_s_s((1UL != (((safe_sub_func_int8_t_s_s((g_251 ^= ((*l_250) = (((((((l_223 == ((safe_div_func_int32_t_s_s((safe_div_func_int64_t_s_s((safe_add_func_int32_t_s_s((((((*l_244) = (void*)0) != l_246) != (((g_48[0][3] != (((**l_104) & (safe_rshift_func_int16_t_s_s(7L, 9))) & g_148)) != 4294967295UL) < g_63[0])) || (*l_116)), (**g_149))), (*l_105))), (*l_116))) , (void*)0)) , 65535UL) <= g_175) < (*l_105)) >= (*l_105)) , l_249) != l_249))), (**l_104))) < l_252) >= g_148)), (*l_116))))), (-3L))), 2)) && (-1L)) && g_61[2]))) <= (*l_116)) , g_63[0]) , 0xA79FF928E1D70941LL) && (-3L)))) || 0x6CL);
    return g_127;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_3[i][j], "g_3[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_48[i][j], "g_48[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_49, "g_49", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_61[i], "g_61[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_63[i], "g_63[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_89[i][j][k], "g_89[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_114, "g_114", print_hash_value);
    transparent_crc(g_127, "g_127", print_hash_value);
    transparent_crc(g_137, "g_137", print_hash_value);
    transparent_crc(g_148, "g_148", print_hash_value);
    transparent_crc(g_152, "g_152", print_hash_value);
    transparent_crc(g_175, "g_175", print_hash_value);
    transparent_crc(g_251, "g_251", print_hash_value);
    transparent_crc(g_382, "g_382", print_hash_value);
    transparent_crc(g_406, "g_406", print_hash_value);
    transparent_crc(g_458, "g_458", print_hash_value);
    transparent_crc(g_546, "g_546", print_hash_value);
    transparent_crc(g_698, "g_698", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_822[i], "g_822[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_828[i], "g_828[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_930, "g_930", print_hash_value);
    transparent_crc(g_935, "g_935", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_946[i][j][k], "g_946[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_949, "g_949", print_hash_value);
    transparent_crc(g_951, "g_951", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_952[i][j][k], "g_952[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 207
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 50
breakdown:
   depth: 1, occurrence: 100
   depth: 2, occurrence: 27
   depth: 3, occurrence: 1
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1
   depth: 15, occurrence: 1
   depth: 17, occurrence: 1
   depth: 18, occurrence: 1
   depth: 20, occurrence: 1
   depth: 21, occurrence: 1
   depth: 24, occurrence: 1
   depth: 26, occurrence: 1
   depth: 27, occurrence: 1
   depth: 29, occurrence: 1
   depth: 31, occurrence: 1
   depth: 38, occurrence: 1
   depth: 42, occurrence: 1
   depth: 50, occurrence: 1

XXX total number of pointers: 221

XXX times a variable address is taken: 483
XXX times a pointer is dereferenced on RHS: 124
breakdown:
   depth: 1, occurrence: 82
   depth: 2, occurrence: 39
   depth: 3, occurrence: 3
XXX times a pointer is dereferenced on LHS: 116
breakdown:
   depth: 1, occurrence: 83
   depth: 2, occurrence: 29
   depth: 3, occurrence: 4
XXX times a pointer is compared with null: 15
XXX times a pointer is compared with address of another variable: 3
XXX times a pointer is compared with another pointer: 3
XXX times a pointer is qualified to be dereferenced: 4740

XXX max dereference level: 3
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 332
   level: 2, occurrence: 171
   level: 3, occurrence: 19
XXX number of pointers point to pointers: 56
XXX number of pointers point to scalars: 165
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 28.1
XXX average alias set size: 1.34

XXX times a non-volatile is read: 805
XXX times a non-volatile is write: 370
XXX times a volatile is read: 23
XXX    times read thru a pointer: 18
XXX times a volatile is write: 18
XXX    times written thru a pointer: 16
XXX times a volatile is available for access: 162
XXX percentage of non-volatile access: 96.6

XXX forward jumps: 0
XXX backward jumps: 6

XXX stmts: 99
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 26
   depth: 1, occurrence: 16
   depth: 2, occurrence: 22
   depth: 3, occurrence: 12
   depth: 4, occurrence: 12
   depth: 5, occurrence: 11

XXX percentage a fresh-made variable is used: 13
XXX percentage an existing variable is used: 87
********************* end of statistics **********************/

