/* ranges.c - hot/cold splitting produces DW_AT_ranges subprograms */
#include <stdio.h>
#include <string.h>

__attribute__((noinline, cold)) static int rarely(int x)
{
    char pad[64];
    memset(pad, x, sizeof pad);
    return pad[11] + x * 7;
}

__attribute__((noinline)) static int often(int x)
{
    if (__builtin_expect(x > 1000000, 0)) {
        return rarely(x);
    }
    return x * 2 + 1;
}

int spread(int x)
{
    int t = 0;
    for (int i = 0; i < 8; i++) {
        t += often(x + i);
        if (__builtin_expect(t > 1000000, 0)) {
            t += rarely(t);
        }
    }
    return t;
}

int main(int argc, char **argv)
{
    (void) argv;
    printf("%d\n", spread(argc));
    return 0;
}
