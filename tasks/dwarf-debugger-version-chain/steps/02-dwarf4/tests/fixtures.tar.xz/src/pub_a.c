/* pub_a.c - public sample: globals, statics, calls, switch */
#include <stdio.h>

int pub_counter = 11;
static long pub_static_long = 77L;
char pub_name[32] = "public sample";
static short pub_bss_table[12];

static int scale_value(int v, int by) { return v * by - 1; }

int tally(const int *xs, int n)
{
    int acc = 0;
    for (int i = 0; i < n; i++) {
        acc += scale_value(xs[i], 3);
    }
    return acc;
}

int pick(int v)
{
    switch (v % 5) {
    case 0: return pub_counter;
    case 1: return (int) pub_static_long;
    case 2: return pub_name[2];
    case 3: return pub_bss_table[v % 12];
    default: return -7;
    }
}

int chain(int depth)
{
    if (depth <= 0) {
        return 0;
    }
    return pick(depth) + chain(depth - 1);
}

int main(int argc, char **argv)
{
    (void) argv;
    int xs[5] = { 2, 4, 6, 8, 10 };
    printf("%d\n", tally(xs, 5) + chain(4) + argc);
    return 0;
}
