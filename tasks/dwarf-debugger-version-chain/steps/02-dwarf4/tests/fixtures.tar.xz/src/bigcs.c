/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --seed 700701 --max-funcs 40
 * Seed:      700701
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
#pragma pack(push)
#pragma pack(1)
struct S0 {
   volatile uint8_t  f0;
   uint32_t  f1;
   signed f2 : 16;
   const volatile int16_t  f3;
   volatile uint64_t  f4;
   volatile int16_t  f5;
};
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
struct S1 {
   volatile signed f0 : 7;
   volatile signed f1 : 30;
   unsigned f2 : 9;
   unsigned f3 : 21;
   unsigned f4 : 31;
   const unsigned f5 : 18;
};
#pragma pack(pop)

union U2 {
   signed f0 : 22;
   const int32_t  f1;
   volatile int16_t  f2;
   int64_t  f3;
   volatile uint32_t  f4;
};

union U3 {
   const volatile int8_t * volatile  f0;
};

union U4 {
   int8_t * volatile  f0;
   const uint32_t  f1;
   volatile int8_t  f2;
};

union U5 {
   int64_t  f0;
   volatile int32_t  f1;
   const int8_t  f2;
   const volatile uint32_t  f3;
};

/* --- GLOBAL VARIABLES --- */
static int16_t g_2[8][6][5] = {{{(-9L),(-1L),(-1L),0L,0xD3AEL},{0xB922L,0x968CL,0x0CD9L,(-1L),0L},{0x6DF7L,0x060DL,0x0643L,(-1L),(-1L)},{5L,0L,5L,0L,0L},{0x667FL,0L,(-9L),0x9AB5L,1L},{(-1L),0xB922L,0L,(-1L),(-1L)}},{{(-1L),(-1L),(-9L),1L,0x060DL},{0xD3AEL,(-9L),5L,0x6DF7L,(-1L)},{(-1L),0x9AB5L,0x0643L,0L,0xB922L},{0xD39CL,0x0CD9L,0L,0L,0x0CD9L},{6L,(-8L),0x0643L,0x0CD9L,0xF38DL},{(-8L),0x968CL,0x667FL,(-9L),0xD39CL}},{{0xF38DL,0L,0L,0x4414L,(-1L)},{(-8L),0xBD00L,0xE6FCL,6L,0x4414L},{6L,1L,0x9AB5L,(-9L),0L},{0xE6FCL,(-1L),(-8L),0x1FDBL,0L},{0x968CL,0xF38DL,0xF38DL,0x968CL,0x4414L},{0xD39CL,0x968CL,0L,0L,(-1L)}},{{0x0643L,(-8L),0x4414L,(-8L),0xD39CL},{0x968CL,0x1FDBL,0xE6FCL,0L,0xF38DL},{5L,0x0CD9L,0xB922L,0x968CL,0x0CD9L},{0x4414L,(-8L),0x0643L,0x1FDBL,0L},{(-8L),0L,0x0643L,(-9L),0x0643L},{0L,0L,0xB922L,6L,(-1L)}},{{(-8L),(-1L),0xE6FCL,0x4414L,6L},{6L,0xE584L,0x4414L,(-9L),0x2947L},{5L,(-1L),0L,0x0CD9L,0L},{0L,0L,0xF38DL,0L,6L},{0xD39CL,0L,(-8L),0L,0xBD00L},{0xD39CL,(-8L),0x9AB5L,(-8L),0xD39CL}},{{0L,0x0CD9L,0xE6FCL,0x2947L,0L},{5L,0x1FDBL,0L,0x968CL,0x1FDBL},{6L,(-8L),0x667FL,0x0CD9L,0L},{(-8L),0x968CL,0x0643L,(-3L),0xD39CL},{0L,0xF38DL,0L,6L,0xBD00L},{(-8L),(-1L),(-1L),6L,6L}},{{0x4414L,1L,0x4414L,(-3L),0L},{5L,0xBD00L,(-8L),0x0CD9L,0x2947L},{0x968CL,0L,0x93C1L,0x968CL,6L},{0x0643L,0x968CL,(-8L),0x2947L,(-1L)},{0xD39CL,(-8L),0x4414L,(-8L),0x0643L},{0x968CL,0x0CD9L,(-1L),0L,0L}},{{0xE6FCL,0x0CD9L,0L,0L,0x0CD9L},{6L,(-8L),0x0643L,0x0CD9L,0xF38DL},{(-8L),0x968CL,0x667FL,(-9L),0xD39CL},{0xF38DL,0L,0L,0x4414L,(-1L)},{(-8L),0xBD00L,0xE6FCL,6L,0x4414L},{6L,1L,0x0CD9L,(-8L),0xBD00L}}};
static int32_t g_3 = 0xB5978573L;
static volatile int32_t g_4 = 0x969B42C5L;/* VOLATILE GLOBAL g_4 */
static volatile int32_t g_5 = (-8L);/* VOLATILE GLOBAL g_5 */
static volatile int32_t g_6 = 0x065F4B3FL;/* VOLATILE GLOBAL g_6 */
static int32_t g_7[9][8][3] = {{{0x11C1B015L,0x1C2A9118L,0x0E69CD17L},{0x4108FA7AL,0x81E21435L,0x92B2C22BL},{(-1L),0x5925F8A4L,(-1L)},{(-1L),3L,0x11C1B015L},{0L,0L,(-1L)},{0L,0x0C37C508L,0xB5C4CE10L},{0x2F67AB6CL,1L,0x98FE831EL},{0L,0x7587697AL,0x0E69CD17L}},{{0L,(-3L),1L},{(-1L),0x7AA29676L,0x243A5D8DL},{(-1L),0L,0L},{0x4108FA7AL,0L,0x0C37C508L},{0x11C1B015L,0x5C25CCEBL,0x92B2C22BL},{0x264F89C8L,0x12C005D9L,(-1L)},{0x7587697AL,0xB81FDF20L,0L},{0L,0L,(-3L)}},{{(-10L),0x7F0D3066L,(-1L)},{0x243A5D8DL,1L,0x7587697AL},{(-10L),(-1L),0x0C37C508L},{0x7F0D3066L,(-1L),1L},{(-3L),1L,(-7L)},{0xD05B3B6AL,0x7F0D3066L,0x83DE37D6L},{0x4108FA7AL,0L,1L},{(-1L),0xB81FDF20L,(-1L)}},{{(-1L),0x12C005D9L,0xD05B3B6AL},{0x9E46ED4DL,0x5C25CCEBL,(-1L)},{0x7F0D3066L,0L,(-3L)},{(-9L),0L,(-1L)},{0x7AA29676L,0x7AA29676L,0x98FE831EL},{(-10L),(-3L),1L},{0x0C37C508L,0x7587697AL,(-10L)},{(-1L),1L,0x7AA29676L}},{{(-6L),0x0C37C508L,(-10L)},{0x11C1B015L,0L,1L},{1L,3L,0x98FE831EL},{0xD05B3B6AL,0x5925F8A4L,(-1L)},{0x9E46ED4DL,0x81E21435L,(-3L)},{0x0C37C508L,0x1C2A9118L,(-1L)},{(-10L),0L,0xD05B3B6AL},{1L,0x243A5D8DL,(-1L)}},{{0L,(-1L),1L},{0x56A6D983L,0x9E46ED4DL,0x83DE37D6L},{0x7587697AL,0x7AA29676L,(-7L)},{(-6L),0x56A6D983L,1L},{(-1L),0x1C2A9118L,0x0C37C508L},{(-1L),3L,0x7587697AL},{(-6L),0x3EBEF277L,(-1L)},{0x7587697AL,0x5C25CCEBL,(-3L)}},{{0x56A6D983L,(-1L),0L},{0L,0x7F0D3066L,(-1L)},{1L,0x2F67AB6CL,0x92B2C22BL},{(-10L),0x7587697AL,0x0C37C508L},{0x0C37C508L,0x9E46ED4DL,0L},{0x9E46ED4DL,0x243A5D8DL,0x243A5D8DL},{0xD05B3B6AL,0x0C37C508L,1L},{1L,(-1L),0x0E69CD17L}},{{0x11C1B015L,0xB81FDF20L,0x98FE831EL},{(-6L),(-7L),0xB5C4CE10L},{(-1L),0xB81FDF20L,(-1L)},{0x0C37C508L,(-1L),0x11C1B015L},{(-10L),0x0C37C508L,(-1L)},{0x7AA29676L,0x243A5D8DL,0x92B2C22BL},{(-9L),0x243A5D8DL,0x5925F8A4L},{(-1L),0xBEBA6E32L,0x11C1B015L}},{{0x243A5D8DL,1L,1L},{0x81E21435L,(-1L),1L},{0x264F89C8L,(-10L),(-1L)},{(-1L),(-3L),0x2F67AB6CL},{6L,0x49F2B782L,2L},{0xD6240C41L,(-1L),0xD05B3B6AL},{(-1L),0L,0xD05B3B6AL},{(-1L),0xF0A64418L,2L}}};
static int32_t g_8 = 0x364B2CBDL;
static volatile int32_t g_9 = 0x85A0455DL;/* VOLATILE GLOBAL g_9 */
static volatile int32_t g_10 = 0L;/* VOLATILE GLOBAL g_10 */
static int32_t g_11 = 0L;
static int8_t g_29 = (-8L);
static int8_t *g_28 = &g_29;
static int32_t g_38 = (-6L);
static uint32_t g_66 = 0UL;
static int16_t g_78 = 0xE431L;
static int32_t g_163 = 0L;
static uint8_t g_188 = 0x0CL;
static int64_t g_196 = 0L;
static int16_t g_232 = 0x258EL;
static int32_t g_255 = 0x1D41C1D6L;
static uint32_t g_260 = 1UL;
static uint16_t g_306 = 0x749CL;
static volatile union U3 g_329 = {0};/* VOLATILE GLOBAL g_329 */
static volatile union U3 g_330[2] = {{0},{0}};
static volatile union U3 g_331[5][3][6] = {{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}}};
static volatile union U3 g_332 = {0};/* VOLATILE GLOBAL g_332 */
static volatile union U3 g_333[1][7] = {{{0},{0},{0},{0},{0},{0},{0}}};
static volatile union U3 g_334 = {0};/* VOLATILE GLOBAL g_334 */
static volatile union U3 g_335 = {0};/* VOLATILE GLOBAL g_335 */
static volatile union U3 g_336 = {0};/* VOLATILE GLOBAL g_336 */
static volatile union U3 g_337 = {0};/* VOLATILE GLOBAL g_337 */
static volatile union U3 g_338[8][5][6] = {{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}}};
static volatile union U3 g_339 = {0};/* VOLATILE GLOBAL g_339 */
static volatile union U3 g_340[8] = {{0},{0},{0},{0},{0},{0},{0},{0}};
static volatile union U3 g_341 = {0};/* VOLATILE GLOBAL g_341 */
static volatile union U3 g_342[8] = {{0},{0},{0},{0},{0},{0},{0},{0}};
static volatile union U3 g_343 = {0};/* VOLATILE GLOBAL g_343 */
static volatile union U3 g_344 = {0};/* VOLATILE GLOBAL g_344 */
static volatile union U3 g_345 = {0};/* VOLATILE GLOBAL g_345 */
static volatile union U3 g_346 = {0};/* VOLATILE GLOBAL g_346 */
static volatile union U3 g_347 = {0};/* VOLATILE GLOBAL g_347 */
static volatile union U3 g_348 = {0};/* VOLATILE GLOBAL g_348 */
static volatile union U3 g_349[9] = {{0},{0},{0},{0},{0},{0},{0},{0},{0}};
static volatile union U3 g_350 = {0};/* VOLATILE GLOBAL g_350 */
static volatile union U3 g_351[7][2] = {{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}};
static volatile union U3 g_352[10][7][2] = {{{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}},{{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}},{{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}},{{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}},{{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}},{{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}},{{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}},{{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}},{{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}},{{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}}};
static volatile union U3 g_353[4][8] = {{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}}};
static volatile union U3 g_354 = {0};/* VOLATILE GLOBAL g_354 */
static volatile union U3 g_355[7][3] = {{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}}};
static volatile union U3 g_356[6][10][3] = {{{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}}},{{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}}},{{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}}},{{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}}},{{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}}},{{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}}}};
static volatile union U3 g_357 = {0};/* VOLATILE GLOBAL g_357 */
static volatile union U3 g_358 = {0};/* VOLATILE GLOBAL g_358 */
static volatile union U3 g_359 = {0};/* VOLATILE GLOBAL g_359 */
static volatile union U3 g_360[7] = {{0},{0},{0},{0},{0},{0},{0}};
static volatile union U3 g_361[3][6][5] = {{{{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0}}}};
static volatile union U3 g_362 = {0};/* VOLATILE GLOBAL g_362 */
static volatile union U3 g_363[5] = {{0},{0},{0},{0},{0}};
static volatile union U3 g_364 = {0};/* VOLATILE GLOBAL g_364 */
static volatile union U3 g_365 = {0};/* VOLATILE GLOBAL g_365 */
static volatile union U3 g_366 = {0};/* VOLATILE GLOBAL g_366 */
static volatile union U3 g_367 = {0};/* VOLATILE GLOBAL g_367 */
static volatile union U3 g_368 = {0};/* VOLATILE GLOBAL g_368 */
static volatile union U3 g_369[5][4][8] = {{{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}}}};
static volatile union U3 g_370 = {0};/* VOLATILE GLOBAL g_370 */
static volatile union U3 g_371 = {0};/* VOLATILE GLOBAL g_371 */
static volatile union U3 g_372[7] = {{0},{0},{0},{0},{0},{0},{0}};
static volatile union U3 g_373 = {0};/* VOLATILE GLOBAL g_373 */
static volatile union U3 g_374 = {0};/* VOLATILE GLOBAL g_374 */
static volatile union U3 g_375 = {0};/* VOLATILE GLOBAL g_375 */
static volatile union U3 g_376 = {0};/* VOLATILE GLOBAL g_376 */
static volatile union U3 g_377 = {0};/* VOLATILE GLOBAL g_377 */
static volatile union U3 g_378 = {0};/* VOLATILE GLOBAL g_378 */
static volatile union U3 g_379 = {0};/* VOLATILE GLOBAL g_379 */
static volatile union U3 g_380 = {0};/* VOLATILE GLOBAL g_380 */
static volatile union U3 g_381 = {0};/* VOLATILE GLOBAL g_381 */
static volatile union U3 g_382 = {0};/* VOLATILE GLOBAL g_382 */
static volatile union U3 g_383 = {0};/* VOLATILE GLOBAL g_383 */
static volatile union U3 g_384 = {0};/* VOLATILE GLOBAL g_384 */
static volatile union U3 g_385 = {0};/* VOLATILE GLOBAL g_385 */
static volatile union U3 g_386 = {0};/* VOLATILE GLOBAL g_386 */
static volatile union U3 g_387 = {0};/* VOLATILE GLOBAL g_387 */
static volatile union U3 g_388 = {0};/* VOLATILE GLOBAL g_388 */
static volatile union U3 g_389 = {0};/* VOLATILE GLOBAL g_389 */
static volatile union U3 g_390 = {0};/* VOLATILE GLOBAL g_390 */
static volatile union U3 g_391[1] = {{0}};
static volatile union U3 g_392[3] = {{0},{0},{0}};
static volatile union U3 g_393 = {0};/* VOLATILE GLOBAL g_393 */
static volatile union U3 g_394 = {0};/* VOLATILE GLOBAL g_394 */
static volatile union U3 g_395 = {0};/* VOLATILE GLOBAL g_395 */
static volatile union U3 g_396 = {0};/* VOLATILE GLOBAL g_396 */
static volatile union U3 g_397 = {0};/* VOLATILE GLOBAL g_397 */
static volatile union U3 g_398 = {0};/* VOLATILE GLOBAL g_398 */
static volatile union U3 g_399 = {0};/* VOLATILE GLOBAL g_399 */
static volatile union U3 g_400 = {0};/* VOLATILE GLOBAL g_400 */
static volatile union U3 g_401 = {0};/* VOLATILE GLOBAL g_401 */
static volatile union U3 g_402[9][10] = {{{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}}};
static volatile union U3 g_403 = {0};/* VOLATILE GLOBAL g_403 */
static volatile union U3 g_404 = {0};/* VOLATILE GLOBAL g_404 */
static volatile union U3 g_405 = {0};/* VOLATILE GLOBAL g_405 */
static volatile union U3 g_406 = {0};/* VOLATILE GLOBAL g_406 */
static volatile union U3 g_407 = {0};/* VOLATILE GLOBAL g_407 */
static volatile union U3 g_408 = {0};/* VOLATILE GLOBAL g_408 */
static volatile union U3 g_409 = {0};/* VOLATILE GLOBAL g_409 */
static volatile union U3 g_410 = {0};/* VOLATILE GLOBAL g_410 */
static volatile union U3 g_411[5][6][7] = {{{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}}}};
static volatile union U3 g_412 = {0};/* VOLATILE GLOBAL g_412 */
static volatile union U3 g_413 = {0};/* VOLATILE GLOBAL g_413 */
static volatile union U3 *g_328[7][7][5] = {{{(void*)0,&g_335,(void*)0,&g_368,(void*)0},{(void*)0,(void*)0,&g_411[4][3][6],(void*)0,&g_370},{(void*)0,&g_332,&g_364,(void*)0,&g_401},{(void*)0,&g_365,&g_392[0],(void*)0,&g_338[1][1][3]},{&g_408,&g_386,&g_408,&g_401,(void*)0},{&g_338[1][1][3],(void*)0,&g_334,&g_409,&g_367},{&g_347,&g_403,&g_339,(void*)0,&g_368}},{{&g_346,(void*)0,&g_334,(void*)0,&g_360[4]},{&g_335,&g_393,&g_408,(void*)0,&g_343},{&g_405,&g_374,&g_392[0],&g_374,&g_405},{&g_383,&g_347,&g_364,&g_343,&g_377},{(void*)0,(void*)0,&g_411[4][3][6],&g_394,&g_334},{(void*)0,(void*)0,(void*)0,&g_347,&g_377},{&g_346,&g_394,(void*)0,&g_381,&g_405}},{{&g_377,&g_332,&g_343,&g_403,&g_343},{&g_398,&g_355[0][2],&g_363[0],(void*)0,&g_360[4]},{&g_408,&g_368,&g_373,&g_343,&g_368},{&g_413,(void*)0,&g_376,&g_344,&g_367},{(void*)0,&g_368,(void*)0,&g_335,(void*)0},{(void*)0,&g_355[0][2],&g_357,(void*)0,&g_338[1][1][3]},{&g_386,&g_332,&g_332,&g_386,&g_401}},{{&g_360[4],&g_394,&g_392[0],&g_355[0][2],&g_370},{&g_408,(void*)0,&g_354,&g_401,(void*)0},{&g_370,(void*)0,&g_396,&g_355[0][2],&g_367},{&g_403,&g_347,&g_339,&g_386,(void*)0},{&g_346,&g_374,&g_367,(void*)0,&g_413},{&g_368,&g_393,&g_383,&g_335,&g_343},{(void*)0,(void*)0,&g_392[0],&g_344,(void*)0}},{{&g_383,&g_403,&g_393,&g_343,&g_347},{(void*)0,(void*)0,&g_385,(void*)0,&g_334},{&g_368,&g_386,(void*)0,&g_403,&g_403},{&g_346,&g_365,&g_346,&g_381,(void*)0},{&g_403,&g_332,&g_401,&g_347,&g_343},{&g_370,(void*)0,&g_363[0],&g_394,(void*)0},{&g_408,&g_335,&g_401,&g_406,&g_401}},{{&g_334,&g_348,(void*)0,&g_351[0][1],&g_342[5]},{&g_364,&g_373,&g_347,&g_373,&g_364},{(void*)0,&g_390,&g_363[0],&g_387,&g_376},{&g_393,(void*)0,(void*)0,&g_393,&g_380},{&g_396,(void*)0,&g_370,&g_390,&g_376},{&g_389,&g_393,&g_361[1][4][1],&g_380,&g_364},{&g_376,&g_378,&g_342[5],&g_362,&g_342[5]}},{{&g_354,&g_354,&g_403,&g_332,&g_401},{(void*)0,(void*)0,&g_372[6],&g_387,&g_367},{&g_373,(void*)0,&g_329,&g_343,&g_406},{&g_411[4][3][6],(void*)0,&g_370,&g_381,&g_357},{&g_361[1][4][1],&g_354,(void*)0,&g_406,&g_383},{&g_385,&g_378,&g_331[4][2][0],&g_340[0],&g_400},{&g_401,&g_393,&g_347,&g_354,&g_408}}};
static int8_t g_431 = 0x09L;
static union U3 g_437 = {0};/* VOLATILE GLOBAL g_437 */
static uint32_t g_446 = 0x48007DB2L;
static uint16_t g_466 = 65533UL;
static uint8_t g_495 = 0xE3L;
static int32_t g_499[3][1] = {{(-7L)},{(-7L)},{(-7L)}};
static union U3 g_508 = {0};/* VOLATILE GLOBAL g_508 */
static int64_t g_539[3] = {1L,1L,1L};
static int64_t *g_538[3] = {&g_539[1],&g_539[1],&g_539[1]};
static const int64_t g_558 = 0x98CBA87672026A9ALL;
static const int64_t g_560 = (-1L);
static uint32_t g_604 = 0x141FB62CL;
static int32_t *g_653 = &g_499[0][0];
static uint8_t g_657 = 254UL;
static uint8_t *g_656 = &g_657;
static uint16_t *g_715 = &g_466;
static uint16_t **g_714 = &g_715;
static int16_t g_723 = 0xC211L;
static union U3 g_745 = {0};/* VOLATILE GLOBAL g_745 */
static union U3 *g_746 = (void*)0;
static uint16_t g_748 = 65535UL;
static const volatile uint8_t *g_777 = (void*)0;
static const volatile uint8_t ** volatile g_776[9][2] = {{&g_777,&g_777},{&g_777,&g_777},{&g_777,&g_777},{&g_777,&g_777},{&g_777,&g_777},{&g_777,&g_777},{&g_777,&g_777},{&g_777,&g_777},{&g_777,&g_777}};
static const volatile uint8_t ** volatile *g_775 = &g_776[6][0];
static const volatile uint8_t ** volatile **g_774 = &g_775;
static volatile uint32_t *g_837 = (void*)0;
static volatile uint32_t **g_836 = &g_837;
static int64_t g_845 = 0x5D5DA75E51037803LL;
static uint64_t g_857 = 1UL;
static const union U3 g_884 = {0};/* VOLATILE GLOBAL g_884 */
static struct S0 g_922 = {0x62L,0x19537A4DL,-97,1L,0xAAA88FCF6FEA3625LL,0xABE8L};/* VOLATILE GLOBAL g_922 */
static struct S0 g_924 = {0UL,4UL,198,0xCB6CL,0xD5B7A9E55D5EEFFDLL,-5L};/* VOLATILE GLOBAL g_924 */
static uint32_t *g_930[6][9] = {{&g_66,&g_446,&g_446,&g_66,&g_66,&g_66,&g_446,&g_446,&g_66},{&g_66,&g_446,&g_66,&g_446,&g_66,&g_66,&g_446,&g_66,&g_446},{&g_446,&g_66,&g_66,&g_66,&g_66,&g_446,&g_66,&g_66,&g_66},{&g_66,&g_66,&g_446,&g_66,&g_446,&g_66,&g_66,&g_446,&g_66},{&g_66,&g_66,&g_66,&g_446,&g_446,&g_66,&g_66,&g_66,&g_446},{&g_66,&g_446,&g_446,&g_66,&g_66,&g_66,&g_446,&g_446,&g_66}};
static uint32_t **g_929 = &g_930[1][2];
static union U3 g_944 = {0};/* VOLATILE GLOBAL g_944 */
static int32_t g_951 = (-1L);
static union U3 ** volatile g_981 = (void*)0;/* VOLATILE GLOBAL g_981 */
static union U3 ** volatile *g_980 = &g_981;
static union U3 ** volatile * volatile * volatile g_979[8][8] = {{&g_980,(void*)0,&g_980,&g_980,&g_980,(void*)0,&g_980,&g_980},{&g_980,&g_980,(void*)0,&g_980,&g_980,&g_980,(void*)0,&g_980},{&g_980,&g_980,(void*)0,&g_980,&g_980,(void*)0,&g_980,&g_980},{&g_980,&g_980,(void*)0,&g_980,&g_980,&g_980,(void*)0,(void*)0},{&g_980,&g_980,(void*)0,&g_980,&g_980,&g_980,&g_980,&g_980},{(void*)0,&g_980,&g_980,&g_980,(void*)0,&g_980,&g_980,&g_980},{&g_980,&g_980,&g_980,&g_980,(void*)0,(void*)0,&g_980,&g_980},{&g_980,&g_980,&g_980,&g_980,(void*)0,(void*)0,&g_980,&g_980}};
static union U3 ** volatile * volatile * volatile *g_978 = &g_979[6][5];
static uint64_t g_998 = 0UL;
static uint32_t g_1020 = 0x8586A7E2L;
static int16_t **g_1030[1][7] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
static int16_t ***g_1029 = &g_1030[0][0];
static union U5 g_1071 = {0x402BF8A2D000BCD1LL};/* VOLATILE GLOBAL g_1071 */
static union U5 *g_1070 = &g_1071;
static union U4 g_1166 = {0};/* VOLATILE GLOBAL g_1166 */
static union U4 g_1169 = {0};/* VOLATILE GLOBAL g_1169 */
static union U4 g_1170 = {0};/* VOLATILE GLOBAL g_1170 */
static union U4 g_1171 = {0};/* VOLATILE GLOBAL g_1171 */
static union U4 g_1172 = {0};/* VOLATILE GLOBAL g_1172 */
static union U4 g_1173[7] = {{0},{0},{0},{0},{0},{0},{0}};
static union U4 *g_1168[10] = {&g_1170,&g_1170,&g_1171,&g_1173[5],&g_1171,&g_1170,&g_1170,&g_1171,&g_1173[5],&g_1171};
static uint32_t g_1181 = 0x5FF8ED9CL;
static int32_t **g_1207 = &g_653;
static uint16_t g_1216[1] = {0xC967L};
static uint16_t g_1217 = 0xF908L;
static uint16_t g_1218[10][9] = {{0x307DL,0xC586L,0x307DL,0xC586L,0x307DL,0xC586L,0x307DL,0xC586L,0x307DL},{0x153BL,0x5D37L,0x5D37L,0x153BL,0x153BL,0x5D37L,0x5D37L,0x153BL,0x153BL},{0xEBC8L,0xC586L,0xEBC8L,0xC586L,0xEBC8L,0xC586L,0xEBC8L,0xC586L,0xEBC8L},{0x153BL,0x153BL,0x5D37L,0x5D37L,0x153BL,0x153BL,0x5D37L,0x5D37L,0x153BL},{0x307DL,0xC586L,0x307DL,0xC586L,0x307DL,0xC586L,0x307DL,0xC586L,0x307DL},{0x153BL,0x5D37L,0x5D37L,0x153BL,0x153BL,0x5D37L,0x5D37L,0x153BL,0x153BL},{0xEBC8L,0xC586L,0xEBC8L,0xC586L,0xEBC8L,0xC586L,0xEBC8L,0xC586L,0xEBC8L},{0x153BL,0x153BL,0x5D37L,0x5D37L,0x153BL,0x153BL,0x5D37L,0x5D37L,0x153BL},{0x307DL,0xC586L,0x307DL,0xC586L,0x307DL,0xC586L,0x307DL,0xC586L,0x307DL},{0x153BL,0x5D37L,0x5D37L,0x153BL,0x153BL,0x5D37L,0x5D37L,0x153BL,0x153BL}};
static uint16_t g_1219 = 0x672BL;
static uint16_t g_1220 = 0xA032L;
static uint16_t g_1221 = 0x85ECL;
static uint16_t g_1224 = 65531UL;
static int64_t g_1273 = (-2L);
static uint8_t g_1351 = 0x17L;
static int32_t g_1396 = 0xD5E6E538L;
static volatile uint16_t *g_1409 = (void*)0;
static volatile uint16_t **g_1408 = &g_1409;
static volatile uint16_t ** volatile * volatile g_1407[4] = {&g_1408,&g_1408,&g_1408,&g_1408};
static volatile uint16_t ** volatile * const  volatile *g_1406 = &g_1407[3];
static const uint16_t g_1419 = 0xEC66L;
static uint8_t g_1446[3] = {0UL,0UL,0UL};
static union U3 g_1448[9] = {{0},{0},{0},{0},{0},{0},{0},{0},{0}};
static int16_t g_1470 = 0x3D9EL;
static union U3 ****g_1503 = (void*)0;
static uint64_t g_1509 = 6UL;
static uint64_t *g_1541 = &g_998;
static uint64_t **g_1540 = &g_1541;
static uint32_t g_1550 = 4294967295UL;
static int8_t g_1621[6] = {0x87L,0xB7L,0x87L,0x87L,0xB7L,0x87L};
static uint8_t g_1636 = 0xB9L;
static union U3 g_1641 = {0};/* VOLATILE GLOBAL g_1641 */
static const int16_t *g_1678 = &g_232;
static const int16_t **g_1677[2][7] = {{&g_1678,&g_1678,&g_1678,&g_1678,&g_1678,&g_1678,&g_1678},{&g_1678,&g_1678,&g_1678,&g_1678,&g_1678,&g_1678,&g_1678}};
static const int16_t ***g_1676 = &g_1677[0][1];
static const int16_t ****g_1675 = &g_1676;
static const int16_t *****g_1674 = &g_1675;
static uint8_t g_1727 = 0xF2L;
static union U3 g_1759 = {0};/* VOLATILE GLOBAL g_1759 */
static int64_t g_1847 = (-1L);
static const struct S0 g_1918[4][4][3] = {{{{0x4EL,0x31E3BF1FL,-145,-8L,0x11690146B658A184LL,0x55C5L},{1UL,0UL,-232,0xD75DL,18446744073709551615UL,0x3BF6L},{1UL,0UL,86,-1L,0UL,0x944FL}},{{0x4EL,0x31E3BF1FL,-145,-8L,0x11690146B658A184LL,0x55C5L},{0x4EL,0x31E3BF1FL,-145,-8L,0x11690146B658A184LL,0x55C5L},{1UL,0UL,-232,0xD75DL,18446744073709551615UL,0x3BF6L}},{{0x3AL,0xDB788EEEL,-82,1L,0x73CAF6622E6890D3LL,4L},{1UL,0UL,-232,0xD75DL,18446744073709551615UL,0x3BF6L},{1UL,0UL,-232,0xD75DL,18446744073709551615UL,0x3BF6L}},{{1UL,0UL,-232,0xD75DL,18446744073709551615UL,0x3BF6L},{0xB5L,0xCF439231L,203,-4L,18446744073709551612UL,0x1F83L},{1UL,0UL,86,-1L,0UL,0x944FL}}},{{{0x3AL,0xDB788EEEL,-82,1L,0x73CAF6622E6890D3LL,4L},{0x4EL,0x31E3BF1FL,-145,-8L,0x11690146B658A184LL,0x55C5L},{1UL,0UL,86,-1L,0UL,0x944FL}},{{1UL,0UL,-232,0xD75DL,18446744073709551615UL,0x3BF6L},{0x3AL,0xDB788EEEL,-82,1L,0x73CAF6622E6890D3LL,4L},{0xB5L,0xCF439231L,203,-4L,18446744073709551612UL,0x1F83L}},{{1UL,0UL,-232,0xD75DL,18446744073709551615UL,0x3BF6L},{1UL,0UL,-232,0xD75DL,18446744073709551615UL,0x3BF6L},{0x3AL,0xDB788EEEL,-82,1L,0x73CAF6622E6890D3LL,4L}},{{1UL,0UL,86,-1L,0UL,0x944FL},{0x3AL,0xDB788EEEL,-82,1L,0x73CAF6622E6890D3LL,4L},{0x3AL,0xDB788EEEL,-82,1L,0x73CAF6622E6890D3LL,4L}}},{{{0x3AL,0xDB788EEEL,-82,1L,0x73CAF6622E6890D3LL,4L},{0x4EL,0x31E3BF1FL,-145,-8L,0x11690146B658A184LL,0x55C5L},{0xB5L,0xCF439231L,203,-4L,18446744073709551612UL,0x1F83L}},{{1UL,0UL,86,-1L,0UL,0x944FL},{0x4EL,0x31E3BF1FL,-145,-8L,0x11690146B658A184LL,0x55C5L},{1UL,0UL,86,-1L,0UL,0x944FL}},{{1UL,0UL,-232,0xD75DL,18446744073709551615UL,0x3BF6L},{0x3AL,0xDB788EEEL,-82,1L,0x73CAF6622E6890D3LL,4L},{0xB5L,0xCF439231L,203,-4L,18446744073709551612UL,0x1F83L}},{{1UL,0UL,-232,0xD75DL,18446744073709551615UL,0x3BF6L},{1UL,0UL,-232,0xD75DL,18446744073709551615UL,0x3BF6L},{0x3AL,0xDB788EEEL,-82,1L,0x73CAF6622E6890D3LL,4L}}},{{{1UL,0UL,86,-1L,0UL,0x944FL},{0x3AL,0xDB788EEEL,-82,1L,0x73CAF6622E6890D3LL,4L},{0x3AL,0xDB788EEEL,-82,1L,0x73CAF6622E6890D3LL,4L}},{{0x3AL,0xDB788EEEL,-82,1L,0x73CAF6622E6890D3LL,4L},{0x4EL,0x31E3BF1FL,-145,-8L,0x11690146B658A184LL,0x55C5L},{0xB5L,0xCF439231L,203,-4L,18446744073709551612UL,0x1F83L}},{{1UL,0UL,86,-1L,0UL,0x944FL},{0x4EL,0x31E3BF1FL,-145,-8L,0x11690146B658A184LL,0x55C5L},{1UL,0UL,86,-1L,0UL,0x944FL}},{{1UL,0UL,-232,0xD75DL,18446744073709551615UL,0x3BF6L},{0x3AL,0xDB788EEEL,-82,1L,0x73CAF6622E6890D3LL,4L},{0xB5L,0xCF439231L,203,-4L,18446744073709551612UL,0x1F83L}}}};
static struct S0 g_1920 = {0x17L,0x008CDB45L,164,0x43E3L,0xDF1AC30E1AE3CF7FLL,-1L};/* VOLATILE GLOBAL g_1920 */
static struct S0 g_1995 = {0x8CL,0x9D82E83FL,13,0L,0xAAFD62E74611981CLL,-1L};/* VOLATILE GLOBAL g_1995 */
static int32_t g_2004 = 0x79AEBDFBL;
static int32_t * volatile *g_2039 = (void*)0;
static int32_t * volatile ** volatile g_2038 = &g_2039;/* VOLATILE GLOBAL g_2038 */
static int32_t * volatile ** volatile * const g_2037 = &g_2038;
static uint8_t g_2045 = 1UL;
static uint8_t g_2170 = 1UL;
static union U4 **g_2302 = &g_1168[7];
static uint8_t g_2355 = 249UL;
static union U5 g_2386 = {9L};/* VOLATILE GLOBAL g_2386 */
static int8_t * volatile * const g_2388 = (void*)0;
static union U3 g_2428 = {0};/* VOLATILE GLOBAL g_2428 */
static union U3 g_2430 = {0};/* VOLATILE GLOBAL g_2430 */
static union U3 *****g_2433[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static const uint8_t ***g_2452 = (void*)0;
static const uint8_t ****g_2451[2][10][3] = {{{&g_2452,&g_2452,&g_2452},{&g_2452,&g_2452,&g_2452},{&g_2452,&g_2452,&g_2452},{(void*)0,&g_2452,&g_2452},{&g_2452,&g_2452,&g_2452},{&g_2452,(void*)0,&g_2452},{&g_2452,&g_2452,&g_2452},{&g_2452,&g_2452,&g_2452},{&g_2452,&g_2452,&g_2452},{&g_2452,&g_2452,&g_2452}},{{(void*)0,&g_2452,&g_2452},{&g_2452,&g_2452,&g_2452},{&g_2452,(void*)0,&g_2452},{&g_2452,&g_2452,&g_2452},{&g_2452,&g_2452,&g_2452},{&g_2452,&g_2452,&g_2452},{&g_2452,&g_2452,&g_2452},{(void*)0,&g_2452,&g_2452},{&g_2452,&g_2452,&g_2452},{&g_2452,(void*)0,&g_2452}}};
static const uint8_t *****g_2450[5][3] = {{(void*)0,&g_2451[1][0][0],&g_2451[1][0][0]},{&g_2451[1][0][0],&g_2451[0][6][1],(void*)0},{(void*)0,&g_2451[0][6][1],(void*)0},{&g_2451[0][6][1],&g_2451[1][0][0],(void*)0},{&g_2451[0][6][1],&g_2451[0][6][1],&g_2451[1][0][0]}};
static const int32_t *g_2482[2][3][7] = {{{(void*)0,&g_499[0][0],&g_499[0][0],(void*)0,(void*)0,(void*)0,&g_499[0][0]},{(void*)0,&g_255,&g_38,(void*)0,&g_38,&g_255,(void*)0},{&g_163,&g_499[0][0],&g_255,&g_499[0][0],&g_163,&g_163,&g_499[0][0]}},{{&g_8,&g_255,&g_8,&g_255,&g_38,&g_7[3][5][1],&g_255},{&g_499[0][0],(void*)0,&g_255,&g_255,(void*)0,&g_499[0][0],(void*)0},{&g_8,&g_255,&g_38,&g_7[3][5][1],&g_255,&g_7[3][5][1],&g_38}}};
static uint8_t g_2606 = 0xD4L;
static union U4 g_2713 = {0};/* VOLATILE GLOBAL g_2713 */
static int32_t ***g_2719[3][6] = {{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207}};
static int32_t ****g_2718 = &g_2719[0][1];
static int32_t *****g_2717 = &g_2718;
static int32_t * const *** const *g_2720 = (void*)0;
static uint8_t g_2725 = 0xDEL;
static const uint32_t g_2791 = 7UL;
static union U5 g_2857 = {0x6A1B49479A416FBCLL};/* VOLATILE GLOBAL g_2857 */
static int8_t g_2886 = (-1L);
static uint16_t ****g_3054 = (void*)0;
static uint16_t *****g_3053 = &g_3054;
static uint64_t g_3070 = 18446744073709551614UL;
static int32_t g_3071 = 0L;
static struct S0 g_3142 = {1UL,0x127B5CDCL,23,0L,8UL,0x56ABL};/* VOLATILE GLOBAL g_3142 */
static union U3 g_3164 = {0};/* VOLATILE GLOBAL g_3164 */
static volatile struct S1 *g_3197 = (void*)0;
static union U3 g_3204 = {0};/* VOLATILE GLOBAL g_3204 */
static union U3 g_3223 = {0};/* VOLATILE GLOBAL g_3223 */
static uint32_t ***g_3250[10] = {&g_929,&g_929,&g_929,&g_929,&g_929,&g_929,&g_929,&g_929,&g_929,&g_929};
static const int32_t *g_3261 = &g_3071;
static const int32_t **g_3260 = &g_3261;
static uint32_t g_3302 = 0x49BB807AL;
static int32_t g_3307 = 0xA50CA8DEL;
static volatile int32_t **g_3346[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static volatile int32_t ** const *g_3345 = &g_3346[0];
static volatile int32_t ** const **g_3344 = &g_3345;
static int32_t g_3420[4] = {0x32DFBEECL,0x32DFBEECL,0x32DFBEECL,0x32DFBEECL};
static const int8_t * volatile * volatile * const  volatile *g_3463 = (void*)0;
static int32_t ****g_3477 = (void*)0;
static union U5 g_3529 = {0xB5E721C9EA516AD7LL};/* VOLATILE GLOBAL g_3529 */
static volatile union U5 g_3568 = {2L};/* VOLATILE GLOBAL g_3568 */
static volatile union U5 g_3569 = {4L};/* VOLATILE GLOBAL g_3569 */
static volatile union U5 g_3570 = {7L};/* VOLATILE GLOBAL g_3570 */
static volatile union U5 g_3571 = {3L};/* VOLATILE GLOBAL g_3571 */
static volatile union U5 g_3572 = {0x2E4E3B53EE083EA8LL};/* VOLATILE GLOBAL g_3572 */
static volatile union U5 *g_3567[10][3] = {{&g_3570,&g_3568,&g_3568},{(void*)0,(void*)0,(void*)0},{&g_3570,&g_3570,&g_3568},{&g_3569,(void*)0,&g_3569},{&g_3570,&g_3568,&g_3568},{(void*)0,(void*)0,(void*)0},{&g_3570,&g_3570,&g_3568},{&g_3569,(void*)0,&g_3569},{&g_3570,&g_3568,&g_3568},{(void*)0,(void*)0,(void*)0}};
static volatile union U5 **g_3566 = &g_3567[1][1];
static volatile union U5 ** volatile *g_3565 = &g_3566;
static struct S1 g_3642 = {-1,-12201,2,1304,3860,510};/* VOLATILE GLOBAL g_3642 */
static uint32_t g_3643 = 0x7908D828L;
static uint64_t ***g_3682 = (void*)0;
static union U5 g_3792 = {-8L};/* VOLATILE GLOBAL g_3792 */
static const union U5 g_3794 = {-1L};/* VOLATILE GLOBAL g_3794 */
static uint8_t g_3870[3] = {0x67L,0x67L,0x67L};
static union U4 g_3913[7][9][4] = {{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}},{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}},{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}},{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}},{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}},{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}},{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}}};
static union U3 g_3954 = {0};/* VOLATILE GLOBAL g_3954 */
static struct S1 g_3961 = {-3,-22226,13,708,6442,14};/* VOLATILE GLOBAL g_3961 */
static struct S1 g_3963 = {4,-196,21,275,45849,483};/* VOLATILE GLOBAL g_3963 */
static struct S1 g_3964[9][1] = {{{3,-964,7,563,13984,468}},{{3,-964,7,563,13984,468}},{{-7,-1252,16,898,36419,61}},{{3,-964,7,563,13984,468}},{{3,-964,7,563,13984,468}},{{-7,-1252,16,898,36419,61}},{{3,-964,7,563,13984,468}},{{3,-964,7,563,13984,468}},{{-7,-1252,16,898,36419,61}}};
static union U4 g_4043 = {0};/* VOLATILE GLOBAL g_4043 */
static union U4 g_4044 = {0};/* VOLATILE GLOBAL g_4044 */
static uint32_t *g_4088[1] = {&g_604};
static uint32_t **g_4087 = &g_4088[0];
static int32_t *g_4097 = &g_1396;
static int32_t **g_4096 = &g_4097;
static int32_t ***g_4095 = &g_4096;
static int8_t g_4118[8] = {(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)};
static uint8_t **g_4139 = &g_656;
static uint32_t g_4151 = 9UL;
static union U3 g_4212 = {0};/* VOLATILE GLOBAL g_4212 */
static struct S1 g_4267 = {-0,25120,12,524,8481,427};/* VOLATILE GLOBAL g_4267 */
static uint32_t g_4294 = 18446744073709551609UL;
static int16_t ****g_4296 = &g_1029;
static int16_t g_4302 = 0xA386L;
static uint64_t g_4338 = 0UL;
static struct S1 g_4358[5] = {{-7,-4063,10,577,41511,277},{-7,-4063,10,577,41511,277},{-7,-4063,10,577,41511,277},{-7,-4063,10,577,41511,277},{-7,-4063,10,577,41511,277}};
static union U4 g_4396 = {0};/* VOLATILE GLOBAL g_4396 */
static int8_t **g_4423 = &g_28;
static int8_t ***g_4422 = &g_4423;
static struct S1 g_4437 = {4,-32063,7,806,29904,104};/* VOLATILE GLOBAL g_4437 */
static struct S1 g_4439 = {0,-30527,12,364,32655,290};/* VOLATILE GLOBAL g_4439 */
static int16_t g_4493 = 0x3A54L;
static uint32_t g_4502 = 0x3900A079L;
static int16_t *g_4510 = (void*)0;
static union U3 g_4565[6][6][6] = {{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}}};
static uint64_t *g_4583[5] = {&g_3070,&g_3070,&g_3070,&g_3070,&g_3070};
static int8_t * const *g_4661 = (void*)0;
static int8_t * const **g_4660 = &g_4661;
static int32_t ****g_4720 = (void*)0;
static union U3 g_4791 = {0};/* VOLATILE GLOBAL g_4791 */
static int16_t * const ****g_4798 = (void*)0;
static int16_t *****g_4801 = &g_4296;
static const struct S1 g_4843 = {-10,-8234,10,484,6393,260};/* VOLATILE GLOBAL g_4843 */
static int32_t g_4882 = 0x22AA7298L;
static union U4 * const g_4905 = (void*)0;
static union U4 * const *g_4904[5][5] = {{&g_4905,&g_4905,&g_4905,&g_4905,&g_4905},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_4905,&g_4905,&g_4905,&g_4905,&g_4905},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_4905,&g_4905,&g_4905,&g_4905,&g_4905}};
static union U3 g_4909 = {0};/* VOLATILE GLOBAL g_4909 */
static union U5 g_5044 = {0xF21E4FC129B602FELL};/* VOLATILE GLOBAL g_5044 */
static union U5 g_5048 = {0xFE86576A61F87432LL};/* VOLATILE GLOBAL g_5048 */
static int32_t ** const *g_5057 = (void*)0;
static int32_t ** const **g_5056 = &g_5057;
static int32_t ** const ***g_5055[6] = {&g_5056,&g_5056,&g_5056,&g_5056,&g_5056,&g_5056};
static const union U4 g_5060 = {0};/* VOLATILE GLOBAL g_5060 */
static uint64_t g_5084[9] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
static union U5 g_5100 = {0xAD22D40535E3B69ALL};/* VOLATILE GLOBAL g_5100 */
static union U4 g_5107[8][5][2] = {{{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}},{{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}},{{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}},{{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}},{{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}},{{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}},{{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}},{{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}}};
static uint64_t *** volatile *g_5128 = (void*)0;
static uint64_t *** volatile **g_5127 = &g_5128;
static const volatile int16_t g_5194 = 0x2F34L;/* VOLATILE GLOBAL g_5194 */
static const volatile int16_t * const g_5193 = &g_5194;
static uint32_t g_5213 = 18446744073709551614UL;
static int32_t g_5271 = 0L;
static uint8_t *g_5411 = &g_3870[1];
static uint8_t ** const g_5410 = &g_5411;
static uint8_t ** const *g_5409[6] = {&g_5410,&g_5410,&g_5410,&g_5410,&g_5410,&g_5410};
static uint8_t ** const **g_5408 = &g_5409[1];
static uint8_t ** const ***g_5407 = &g_5408;
static int16_t g_5420 = 0L;
static int16_t g_5422 = (-1L);
static struct S1 g_5483 = {-2,14974,10,812,33167,491};/* VOLATILE GLOBAL g_5483 */
static uint32_t g_5485 = 6UL;
static int8_t g_5490 = 9L;
static uint16_t g_5546[7][3][10] = {{{0xD57EL,1UL,0xADEFL,0xD57EL,0xADEFL,1UL,0xD57EL,8UL,8UL,0xD57EL},{8UL,0x6B17L,0xADEFL,0xADEFL,0x6B17L,8UL,1UL,0x6B17L,1UL,8UL},{65535UL,0x6B17L,65529UL,0x6B17L,65535UL,65529UL,0xD57EL,0xD57EL,65529UL,65535UL}},{{65535UL,1UL,1UL,65535UL,0xADEFL,8UL,65535UL,8UL,0xADEFL,65535UL},{8UL,65535UL,8UL,0xADEFL,65535UL,1UL,1UL,65535UL,0xADEFL,8UL},{0xD57EL,0xD57EL,65529UL,65535UL,0x6B17L,65529UL,0x6B17L,65535UL,65529UL,0xD57EL}},{{0x6B17L,1UL,8UL,0x6B17L,0xADEFL,0xADEFL,0x6B17L,8UL,1UL,0x6B17L},{8UL,0xD57EL,1UL,0xADEFL,0xD57EL,0xADEFL,1UL,0xD57EL,8UL,8UL},{0x6B17L,65535UL,65529UL,0xD57EL,0xD57EL,65529UL,65535UL,0x6B17L,65529UL,0x6B17L}},{{0xD57EL,1UL,0xADEFL,0xD57EL,0xADEFL,1UL,0xD57EL,0x71DBL,0x71DBL,8UL},{0x71DBL,0xADEFL,0xE088L,0xE088L,0xADEFL,0x71DBL,65529UL,0xADEFL,65529UL,0x71DBL},{1UL,0xADEFL,0xD57EL,0xADEFL,1UL,0xD57EL,8UL,8UL,0xD57EL,1UL}},{{1UL,65529UL,65529UL,1UL,0xE088L,0x71DBL,1UL,0x71DBL,0xE088L,1UL},{0x71DBL,1UL,0x71DBL,0xE088L,1UL,65529UL,65529UL,1UL,0xE088L,0x71DBL},{8UL,8UL,0xD57EL,1UL,0xADEFL,0xD57EL,0xADEFL,1UL,0xD57EL,8UL}},{{0xADEFL,65529UL,0x71DBL,0xADEFL,0xE088L,0xE088L,0xADEFL,0x71DBL,65529UL,0xADEFL},{0x71DBL,8UL,65529UL,0xE088L,8UL,0xE088L,65529UL,8UL,0x71DBL,0x71DBL},{0xADEFL,1UL,0xD57EL,8UL,8UL,0xD57EL,1UL,0xADEFL,0xD57EL,0xADEFL}},{{8UL,65529UL,0xE088L,8UL,0xE088L,65529UL,8UL,0x71DBL,0x71DBL,8UL},{0x71DBL,0xADEFL,0xE088L,0xE088L,0xADEFL,0x71DBL,65529UL,0xADEFL,65529UL,0x71DBL},{1UL,0xADEFL,0xD57EL,0xADEFL,1UL,0xD57EL,8UL,8UL,0xD57EL,1UL}}};
static union U4 g_5654 = {0};/* VOLATILE GLOBAL g_5654 */
static union U4 g_5655[1] = {{0}};
static union U4 g_5656[6] = {{0},{0},{0},{0},{0},{0}};
static union U4 g_5657 = {0};/* VOLATILE GLOBAL g_5657 */
static union U4 g_5658 = {0};/* VOLATILE GLOBAL g_5658 */
static union U4 g_5659 = {0};/* VOLATILE GLOBAL g_5659 */
static union U4 g_5660 = {0};/* VOLATILE GLOBAL g_5660 */
static union U4 g_5661 = {0};/* VOLATILE GLOBAL g_5661 */
static union U4 g_5662 = {0};/* VOLATILE GLOBAL g_5662 */
static union U4 g_5663[10][10] = {{{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}}};
static union U4 g_5664 = {0};/* VOLATILE GLOBAL g_5664 */
static union U4 g_5665 = {0};/* VOLATILE GLOBAL g_5665 */
static union U4 g_5666 = {0};/* VOLATILE GLOBAL g_5666 */
static int32_t ** volatile *g_5684[7][3] = {{&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207}};
static int32_t ** volatile **g_5683 = &g_5684[5][2];
static int32_t ** volatile ** const *g_5682 = &g_5683;
static const uint16_t *g_5749 = &g_1419;
static const uint16_t **g_5748[5][8] = {{&g_5749,(void*)0,&g_5749,&g_5749,&g_5749,(void*)0,&g_5749,&g_5749},{&g_5749,(void*)0,&g_5749,&g_5749,&g_5749,(void*)0,&g_5749,&g_5749},{&g_5749,(void*)0,&g_5749,&g_5749,&g_5749,(void*)0,&g_5749,&g_5749},{&g_5749,(void*)0,&g_5749,&g_5749,&g_5749,(void*)0,&g_5749,&g_5749},{&g_5749,(void*)0,&g_5749,&g_5749,&g_5749,(void*)0,&g_5749,&g_5749}};
static const uint16_t ***g_5747 = &g_5748[1][2];
static const uint16_t ****g_5746 = &g_5747;
static const uint16_t *****g_5745 = &g_5746;
static int64_t g_5761 = 2L;
static struct S1 g_5779[5][3] = {{{-10,-22909,16,342,17041,298},{-8,18468,18,1329,3061,134},{-8,18468,18,1329,3061,134}},{{-10,-22909,16,342,17041,298},{-8,18468,18,1329,3061,134},{-8,18468,18,1329,3061,134}},{{-10,-22909,16,342,17041,298},{-8,18468,18,1329,3061,134},{-8,18468,18,1329,3061,134}},{{-10,-22909,16,342,17041,298},{-8,18468,18,1329,3061,134},{-8,18468,18,1329,3061,134}},{{-10,-22909,16,342,17041,298},{-8,18468,18,1329,3061,134},{-8,18468,18,1329,3061,134}}};
static union U4 * const  volatile * volatile g_6008 = &g_1168[9];/* VOLATILE GLOBAL g_6008 */
static union U4 * const  volatile *g_6009[2] = {&g_1168[1],&g_1168[1]};
static union U4 * const  volatile * volatile * volatile g_6007[1][9][6] = {{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}}};
static union U4 * const  volatile * volatile * volatile *g_6006 = &g_6007[0][6][5];
static struct S1 g_6028 = {2,2738,7,109,39417,479};/* VOLATILE GLOBAL g_6028 */
static int16_t g_6045 = 0x6031L;
static const union U3 g_6068 = {0};/* VOLATILE GLOBAL g_6068 */
static union U3 g_6069 = {0};/* VOLATILE GLOBAL g_6069 */
static const union U3 g_6070 = {0};/* VOLATILE GLOBAL g_6070 */
static const union U3 g_6071 = {0};/* VOLATILE GLOBAL g_6071 */
static union U3 g_6072 = {0};/* VOLATILE GLOBAL g_6072 */
static const union U3 g_6073 = {0};/* VOLATILE GLOBAL g_6073 */
static union U3 g_6074 = {0};/* VOLATILE GLOBAL g_6074 */
static union U3 g_6075 = {0};/* VOLATILE GLOBAL g_6075 */
static const union U3 g_6076 = {0};/* VOLATILE GLOBAL g_6076 */
static const union U3 g_6077 = {0};/* VOLATILE GLOBAL g_6077 */
static union U3 g_6078 = {0};/* VOLATILE GLOBAL g_6078 */
static union U3 g_6079 = {0};/* VOLATILE GLOBAL g_6079 */
static union U3 g_6080 = {0};/* VOLATILE GLOBAL g_6080 */
static union U3 g_6081 = {0};/* VOLATILE GLOBAL g_6081 */
static const union U3 g_6082 = {0};/* VOLATILE GLOBAL g_6082 */
static union U3 g_6083 = {0};/* VOLATILE GLOBAL g_6083 */
static union U3 g_6084 = {0};/* VOLATILE GLOBAL g_6084 */
static union U3 g_6085[1] = {{0}};
static union U3 g_6086 = {0};/* VOLATILE GLOBAL g_6086 */
static union U3 g_6087 = {0};/* VOLATILE GLOBAL g_6087 */
static union U3 g_6088[6] = {{0},{0},{0},{0},{0},{0}};
static const union U3 g_6089[1] = {{0}};
static const union U3 g_6090 = {0};/* VOLATILE GLOBAL g_6090 */
static const union U3 g_6091 = {0};/* VOLATILE GLOBAL g_6091 */
static union U3 g_6092 = {0};/* VOLATILE GLOBAL g_6092 */
static union U3 g_6093 = {0};/* VOLATILE GLOBAL g_6093 */
static union U3 g_6094 = {0};/* VOLATILE GLOBAL g_6094 */
static union U3 g_6095 = {0};/* VOLATILE GLOBAL g_6095 */
static union U3 g_6096[9][3] = {{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}}};
static union U3 g_6097 = {0};/* VOLATILE GLOBAL g_6097 */
static const union U3 g_6098 = {0};/* VOLATILE GLOBAL g_6098 */
static union U3 g_6099[4][7][6] = {{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}}};
static union U3 g_6100 = {0};/* VOLATILE GLOBAL g_6100 */
static const union U3 g_6101 = {0};/* VOLATILE GLOBAL g_6101 */
static const union U3 g_6102[7][2] = {{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}};
static union U3 g_6103 = {0};/* VOLATILE GLOBAL g_6103 */
static union U3 g_6104[5] = {{0},{0},{0},{0},{0}};
static const union U3 g_6105 = {0};/* VOLATILE GLOBAL g_6105 */
static const union U3 g_6106 = {0};/* VOLATILE GLOBAL g_6106 */
static const union U3 g_6107 = {0};/* VOLATILE GLOBAL g_6107 */
static const union U3 g_6108[4] = {{0},{0},{0},{0}};
static union U3 g_6109 = {0};/* VOLATILE GLOBAL g_6109 */
static const union U3 g_6110 = {0};/* VOLATILE GLOBAL g_6110 */
static union U3 g_6111 = {0};/* VOLATILE GLOBAL g_6111 */
static union U3 g_6112 = {0};/* VOLATILE GLOBAL g_6112 */
static const union U3 g_6113 = {0};/* VOLATILE GLOBAL g_6113 */
static union U3 g_6114 = {0};/* VOLATILE GLOBAL g_6114 */
static const union U3 g_6115 = {0};/* VOLATILE GLOBAL g_6115 */
static union U3 g_6116 = {0};/* VOLATILE GLOBAL g_6116 */
static int64_t *g_6119 = &g_845;
static int32_t g_6145 = 0x8024A1E0L;
static struct S1 **g_6230 = (void*)0;
static struct S1 ***g_6229 = &g_6230;
static uint32_t g_6233 = 0x41D6CB9DL;
static struct S0 *g_6240 = (void*)0;
static uint16_t g_6256 = 65533UL;
static uint32_t g_6270 = 4294967288UL;
static uint16_t * const **g_6281 = (void*)0;
static union U4 g_6322 = {0};/* VOLATILE GLOBAL g_6322 */
static uint32_t g_6348 = 18446744073709551615UL;
static const union U2 g_6355 = {0L};/* VOLATILE GLOBAL g_6355 */
static const union U2 *g_6354 = &g_6355;
static const union U2 **g_6353[4] = {&g_6354,&g_6354,&g_6354,&g_6354};
static int32_t *****g_6407 = &g_3477;
static int64_t **g_6440 = (void*)0;
static int64_t ***g_6439[10][4] = {{(void*)0,&g_6440,&g_6440,&g_6440},{(void*)0,(void*)0,(void*)0,&g_6440},{&g_6440,&g_6440,&g_6440,(void*)0},{&g_6440,(void*)0,(void*)0,&g_6440},{(void*)0,(void*)0,&g_6440,(void*)0},{(void*)0,&g_6440,&g_6440,&g_6440},{(void*)0,(void*)0,(void*)0,&g_6440},{&g_6440,&g_6440,&g_6440,(void*)0},{&g_6440,(void*)0,(void*)0,&g_6440},{(void*)0,(void*)0,&g_6440,(void*)0}};
static union U5 **g_6484 = &g_1070;
static union U5 ***g_6483 = &g_6484;
static union U4 ***g_6523 = &g_2302;
static struct S1 g_6544 = {6,26663,15,1145,7807,255};/* VOLATILE GLOBAL g_6544 */
static union U2 g_6566 = {7L};/* VOLATILE GLOBAL g_6566 */
static union U2 g_6567 = {0xC7F4AACFL};/* VOLATILE GLOBAL g_6567 */
static union U2 g_6568[3] = {{0x7E6719DDL},{0x7E6719DDL},{0x7E6719DDL}};
static union U2 g_6569 = {-5L};/* VOLATILE GLOBAL g_6569 */
static union U2 g_6570[3][2] = {{{1L},{1L}},{{1L},{1L}},{{1L},{1L}}};
static union U2 g_6571 = {0xBF74FF67L};/* VOLATILE GLOBAL g_6571 */
static union U2 g_6572 = {0x50DE9FDFL};/* VOLATILE GLOBAL g_6572 */
static union U2 g_6573 = {0x2D58F955L};/* VOLATILE GLOBAL g_6573 */
static union U2 g_6574[7] = {{1L},{1L},{0L},{1L},{1L},{0L},{1L}};
static union U2 g_6575 = {0xDF083650L};/* VOLATILE GLOBAL g_6575 */
static union U2 g_6576 = {0x2F9E19B7L};/* VOLATILE GLOBAL g_6576 */
static union U2 g_6577 = {-1L};/* VOLATILE GLOBAL g_6577 */
static union U2 g_6578 = {0x78B3DE19L};/* VOLATILE GLOBAL g_6578 */
static union U2 g_6579 = {1L};/* VOLATILE GLOBAL g_6579 */
static union U2 g_6580 = {0xEE8402F4L};/* VOLATILE GLOBAL g_6580 */
static union U2 g_6581 = {0xB1927CD5L};/* VOLATILE GLOBAL g_6581 */
static union U2 g_6582 = {0x437A3AB0L};/* VOLATILE GLOBAL g_6582 */
static union U2 g_6583 = {-1L};/* VOLATILE GLOBAL g_6583 */
static union U2 g_6584 = {0L};/* VOLATILE GLOBAL g_6584 */
static union U2 g_6585 = {0xE124E97BL};/* VOLATILE GLOBAL g_6585 */
static union U2 g_6586 = {0xBDAF0281L};/* VOLATILE GLOBAL g_6586 */
static union U2 g_6587 = {0x6B00F8CDL};/* VOLATILE GLOBAL g_6587 */
static union U5 g_6607 = {-1L};/* VOLATILE GLOBAL g_6607 */
static int32_t g_6833 = 0xC9574E35L;
static union U2 g_6877 = {0x312F4E53L};/* VOLATILE GLOBAL g_6877 */
static union U2 g_6878[2][6] = {{{0L},{-1L},{-1L},{0L},{-1L},{-1L}},{{0L},{-1L},{-1L},{0L},{-1L},{-1L}}};
static union U2 g_6879 = {0x6CD1B181L};/* VOLATILE GLOBAL g_6879 */
static union U2 g_6881 = {0x450CC0DBL};/* VOLATILE GLOBAL g_6881 */
static union U2 g_6882 = {2L};/* VOLATILE GLOBAL g_6882 */
static union U2 g_7024 = {5L};/* VOLATILE GLOBAL g_7024 */
static const int32_t g_7076 = 0x4B9B67A8L;
static int8_t g_7088 = (-1L);
static struct S1 g_7096 = {-8,-21434,19,950,42201,501};/* VOLATILE GLOBAL g_7096 */
static struct S1 *g_7095 = &g_7096;
static struct S1 g_7098[5] = {{6,-13665,7,1314,31067,8},{6,-13665,7,1314,31067,8},{6,-13665,7,1314,31067,8},{6,-13665,7,1314,31067,8},{6,-13665,7,1314,31067,8}};
static union U3 g_7104 = {0};/* VOLATILE GLOBAL g_7104 */
static uint32_t g_7160[1] = {0xD629A504L};
static union U2 g_7176 = {-1L};/* VOLATILE GLOBAL g_7176 */
static struct S1 g_7185 = {8,1699,5,714,7571,55};/* VOLATILE GLOBAL g_7185 */
static volatile union U4 g_7198 = {0};/* VOLATILE GLOBAL g_7198 */
static volatile union U4 *g_7197 = &g_7198;
static volatile union U4 ** volatile g_7196 = &g_7197;/* VOLATILE GLOBAL g_7196 */
static volatile union U4 ** volatile * const g_7195 = &g_7196;
static uint32_t g_7217[4][6] = {{0x290E42D0L,0x6008ADFBL,0x6008ADFBL,0x290E42D0L,0x6008ADFBL,0x6008ADFBL},{0x290E42D0L,0x6008ADFBL,0x6008ADFBL,0x290E42D0L,0x6008ADFBL,0x6008ADFBL},{0x290E42D0L,0x6008ADFBL,0x6008ADFBL,0x290E42D0L,0x6008ADFBL,0x6008ADFBL},{0x290E42D0L,0x6008ADFBL,0x6008ADFBL,0x290E42D0L,0x6008ADFBL,0x6008ADFBL}};
static union U2 g_7236 = {-1L};/* VOLATILE GLOBAL g_7236 */
static int32_t g_7254 = 0xB6A1CA1BL;
static int64_t g_7256 = 0L;
static int16_t g_7269 = 0x9B25L;
static int16_t g_7297[3][7][10] = {{{0xE81CL,0xFDD9L,0x9925L,0L,0xBA96L,0L,7L,0x9909L,5L,(-6L)},{(-1L),4L,0xA059L,0L,9L,1L,0xE81CL,0L,0xD4E9L,1L},{1L,0x6F11L,0xE856L,0xB370L,(-1L),0xB57AL,3L,0xD4E9L,9L,0xB6E9L},{0xBA96L,0x3494L,0x247AL,7L,7L,1L,(-6L),0x1C44L,0L,0xB57AL},{(-1L),1L,0x2FC2L,0xE856L,(-1L),1L,7L,(-1L),0x7DD8L,7L},{0x1CCBL,7L,0xBCE7L,0x5FC4L,0L,0x2FC2L,1L,0x1A62L,0xE856L,1L},{0xE856L,0xD37DL,(-1L),0xEFC2L,0xFDD9L,(-9L),0x4098L,(-9L),0xFDD9L,0xEFC2L}},{{0x3D65L,(-1L),0x3D65L,(-1L),0x1C44L,0x247AL,7L,0xB57AL,(-1L),0x46CDL},{(-5L),0x5712L,0x2AC0L,0x14FDL,0L,0x1A8CL,1L,4L,1L,2L},{0x80B7L,1L,0x3494L,0xB615L,1L,7L,0x3D65L,(-1L),0xEFC2L,(-1L)},{0x7DD8L,0x247AL,0xFAF4L,0x3D65L,0xB57AL,0x01FFL,0L,3L,(-6L),(-1L)},{2L,0x5712L,0xFDD9L,1L,1L,0xA201L,0x84F8L,7L,(-1L),1L},{0x01FFL,0L,0x80B7L,0x5FC4L,1L,0xD161L,0xD37DL,2L,0xFAF4L,0L},{1L,0x1C44L,0x9925L,0x4B60L,0x2FC2L,0x5084L,0x14FDL,(-5L),(-1L),(-1L)}},{{0xBCE7L,0x63EAL,(-1L),0L,(-9L),0x3494L,0x3494L,(-9L),0L,(-1L)},{(-1L),(-1L),0xBCE7L,(-5L),0x247AL,1L,1L,0x1CCBL,0xFDD9L,(-1L)},{7L,0L,0xB370L,2L,0x63EAL,5L,1L,0x4098L,0x3D65L,0L},{2L,(-1L),0L,0x1A8CL,(-1L),7L,0x3494L,1L,0xB6E9L,0xB615L},{0xB370L,0x63EAL,0x5084L,0x6F11L,0x5712L,(-9L),0x14FDL,0xFDD9L,7L,0x9909L},{0xB0AEL,0x1C44L,7L,0x247AL,0x6F11L,0xA059L,0xD37DL,0x4B60L,1L,0xBCE7L},{(-1L),0L,0x247AL,0x9925L,0xFAF4L,0L,0x84F8L,1L,0x4B60L,0x01ECL}}};
static volatile int32_t g_7349 = 0xBE7B4A2DL;/* VOLATILE GLOBAL g_7349 */
static volatile int32_t *g_7348 = &g_7349;
static struct S0 g_7392 = {0x76L,18446744073709551615UL,251,2L,4UL,0xBFD2L};/* VOLATILE GLOBAL g_7392 */
static const uint64_t g_7498 = 0x08A7CF5EE2CBD031LL;
static const uint32_t ***g_7504 = (void*)0;
static const uint32_t ****g_7503 = &g_7504;
static union U4 g_7517 = {0};/* VOLATILE GLOBAL g_7517 */
static const union U3 g_7566 = {0};/* VOLATILE GLOBAL g_7566 */
static uint32_t g_7618[7] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL};
static union U5 g_7622[7] = {{0x3A1E9C1B1B48E135LL},{0x3A1E9C1B1B48E135LL},{0x3A1E9C1B1B48E135LL},{0x3A1E9C1B1B48E135LL},{0x3A1E9C1B1B48E135LL},{0x3A1E9C1B1B48E135LL},{0x3A1E9C1B1B48E135LL}};
static union U5 g_7624 = {0x6B9EE8E041843AEALL};/* VOLATILE GLOBAL g_7624 */
static int8_t *g_7633 = &g_431;
static union U4 g_7727[6] = {{0},{0},{0},{0},{0},{0}};
static union U4 g_7729[7][9][4] = {{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}},{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}},{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}},{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}},{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}},{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}},{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}}};
static struct S1 * volatile * const g_7755 = &g_7095;
static struct S1 * volatile * const * volatile g_7754[2][10][6] = {{{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755},{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755},{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755},{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755},{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755},{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755},{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755},{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755},{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755},{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755}},{{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755},{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755},{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755},{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755},{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755},{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755},{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755},{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755},{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755},{&g_7755,&g_7755,&g_7755,&g_7755,&g_7755,&g_7755}}};
static struct S1 * volatile * const * volatile *g_7753 = &g_7754[0][5][1];
static struct S1 * volatile * const * volatile **g_7752 = &g_7753;
static union U5 g_7822[10] = {{-9L},{0x70FA912836B3A9FCLL},{0xE5A61A3907394197LL},{0xE5A61A3907394197LL},{0x70FA912836B3A9FCLL},{-9L},{0x70FA912836B3A9FCLL},{0xE5A61A3907394197LL},{0xE5A61A3907394197LL},{0x70FA912836B3A9FCLL}};
static union U5 g_7825 = {-1L};/* VOLATILE GLOBAL g_7825 */
static union U5 g_7826 = {1L};/* VOLATILE GLOBAL g_7826 */
static union U5 g_7828 = {0xBCCBFCE7E004E413LL};/* VOLATILE GLOBAL g_7828 */
static int64_t g_7870 = 0x46E431F0F9DEFF3DLL;
static uint32_t g_7933 = 2UL;
static struct S0 g_8037 = {0xE8L,0UL,-38,1L,0x6F22ECC8F2F15564LL,2L};/* VOLATILE GLOBAL g_8037 */
static uint32_t g_8062 = 0xDBE2B603L;
static struct S0 g_8076[1] = {{0xC9L,0x889DF03DL,231,0x0A49L,4UL,1L}};
static union U2 g_8082 = {-1L};/* VOLATILE GLOBAL g_8082 */
static union U2 g_8083 = {0L};/* VOLATILE GLOBAL g_8083 */
static union U2 g_8084 = {0xF4D53041L};/* VOLATILE GLOBAL g_8084 */
static union U2 g_8085 = {-3L};/* VOLATILE GLOBAL g_8085 */
static union U2 g_8086 = {0L};/* VOLATILE GLOBAL g_8086 */
static union U2 g_8087 = {0xDCB239EEL};/* VOLATILE GLOBAL g_8087 */
static union U2 g_8088[3] = {{0x45492FE4L},{0x45492FE4L},{0x45492FE4L}};
static union U2 g_8089 = {1L};/* VOLATILE GLOBAL g_8089 */
static union U2 g_8090 = {-2L};/* VOLATILE GLOBAL g_8090 */
static union U2 g_8091 = {0x04A18843L};/* VOLATILE GLOBAL g_8091 */
static union U2 g_8092 = {-1L};/* VOLATILE GLOBAL g_8092 */
static union U2 g_8093 = {1L};/* VOLATILE GLOBAL g_8093 */
static union U2 g_8094 = {0xF884ADC4L};/* VOLATILE GLOBAL g_8094 */
static union U2 g_8095 = {4L};/* VOLATILE GLOBAL g_8095 */
static union U2 g_8096[8][10][3] = {{{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}}},{{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}}},{{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}}},{{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}}},{{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}}},{{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}}},{{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}}},{{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}},{{-8L},{-8L},{-8L}}}};
static union U2 g_8098 = {7L};/* VOLATILE GLOBAL g_8098 */
static int32_t g_8117 = 0L;
static const union U5 g_8149[8] = {{0x7284CB379C12CCD6LL},{-8L},{0x7284CB379C12CCD6LL},{0x7284CB379C12CCD6LL},{-8L},{0x7284CB379C12CCD6LL},{0x7284CB379C12CCD6LL},{-8L}};
static uint64_t g_8228 = 1UL;
static union U3 g_8230 = {0};/* VOLATILE GLOBAL g_8230 */
static int8_t *g_8235 = &g_5490;
static uint16_t g_8242 = 1UL;
static struct S0 g_8351 = {0x49L,6UL,252,-7L,5UL,7L};/* VOLATILE GLOBAL g_8351 */
static union U3 g_8412[3][8] = {{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}}};
static uint64_t g_8491 = 18446744073709551606UL;
static union U5 * volatile * volatile g_8529[7] = {&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070};
static union U5 * volatile * volatile * volatile g_8528 = &g_8529[2];/* VOLATILE GLOBAL g_8528 */
static union U5 * volatile * volatile * volatile *g_8527 = &g_8528;
static union U5 * volatile * volatile * volatile **g_8526 = &g_8527;
static int16_t g_8558 = 0x5835L;
static uint8_t g_8562 = 0x3AL;
static uint16_t g_8583 = 65528UL;
static union U3 g_8656 = {0};/* VOLATILE GLOBAL g_8656 */
static union U5 g_8661 = {0x0B0744893B168571LL};/* VOLATILE GLOBAL g_8661 */
static union U3 g_8710 = {0};/* VOLATILE GLOBAL g_8710 */
static uint32_t g_8711 = 0xDB034166L;
static int32_t g_8779 = 0xFA9A1F8BL;
static union U2 g_8839 = {1L};/* VOLATILE GLOBAL g_8839 */
static uint16_t * volatile *g_8914[1] = {(void*)0};
static uint16_t * volatile ** const g_8913[2] = {&g_8914[0],&g_8914[0]};
static uint16_t * volatile ** const *g_8912 = &g_8913[0];
static uint16_t * volatile ** const ** const g_8911 = &g_8912;
static union U2 **g_8970 = (void*)0;
static union U2 g_8974 = {0xEA1CDAEBL};/* VOLATILE GLOBAL g_8974 */
static int64_t g_9112 = 9L;
static int64_t g_9115[9] = {0x65F37DCA2ED53DD1LL,0x65F37DCA2ED53DD1LL,0x65F37DCA2ED53DD1LL,0x65F37DCA2ED53DD1LL,0x65F37DCA2ED53DD1LL,0x65F37DCA2ED53DD1LL,0x65F37DCA2ED53DD1LL,0x65F37DCA2ED53DD1LL,0x65F37DCA2ED53DD1LL};
static int64_t g_9116[8] = {0xFA069AACAE899670LL,0xFA069AACAE899670LL,0xFA069AACAE899670LL,0xFA069AACAE899670LL,0xFA069AACAE899670LL,0xFA069AACAE899670LL,0xFA069AACAE899670LL,0xFA069AACAE899670LL};
static uint16_t g_9179[2] = {0UL,0UL};
static struct S0 g_9232 = {255UL,1UL,-206,1L,18446744073709551615UL,0xA016L};/* VOLATILE GLOBAL g_9232 */
static const union U5 g_9263 = {0x036635794731B4DELL};/* VOLATILE GLOBAL g_9263 */
static const union U5 *g_9262 = &g_9263;
static const union U5 **g_9261 = &g_9262;
static const union U5 ***g_9260 = &g_9261;
static const union U5 ****g_9259 = &g_9260;
static uint16_t g_9275 = 0x5C7CL;
static union U2 g_9279 = {0x0D8FA602L};/* VOLATILE GLOBAL g_9279 */
static union U2 g_9281 = {0x511FBD5DL};/* VOLATILE GLOBAL g_9281 */
static uint32_t g_9311 = 6UL;
static union U5 g_9376 = {0xBB7C31749E3AD056LL};/* VOLATILE GLOBAL g_9376 */
static int16_t g_9377[7][7][1] = {{{0x7E5AL},{0x1CB9L},{(-5L)},{1L},{1L},{(-5L)},{0x1CB9L}},{{0x7E5AL},{(-1L)},{0xE4F8L},{1L},{1L},{0xE4F8L},{0x1CB9L}},{{(-1L)},{0x1CB9L},{0xE4F8L},{1L},{1L},{0xE4F8L},{(-1L)}},{{0x7E5AL},{0x1CB9L},{(-5L)},{1L},{1L},{(-5L)},{0x1CB9L}},{{0x7E5AL},{(-1L)},{0xE4F8L},{1L},{1L},{0xE4F8L},{0x1CB9L}},{{(-1L)},{0x1CB9L},{0xE4F8L},{1L},{1L},{0xE4F8L},{(-1L)}},{{0x7E5AL},{0x1CB9L},{(-5L)},{1L},{1L},{(-5L)},{0x1CB9L}}};
static union U2 g_9425 = {0x0ECBDBF0L};/* VOLATILE GLOBAL g_9425 */
static const union U3 g_9432 = {0};/* VOLATILE GLOBAL g_9432 */
static int64_t g_9480 = 1L;
static union U2 g_9511 = {1L};/* VOLATILE GLOBAL g_9511 */
static union U5 g_9622 = {1L};/* VOLATILE GLOBAL g_9622 */
static union U5 g_9623[9][6] = {{{0x09DB2395865F6AFELL},{-1L},{-5L},{0xE093D4C4C1F69EC0LL},{0x7300ECD2067417FDLL},{2L}},{{-2L},{0xE093D4C4C1F69EC0LL},{0xFAA6547A9CCD33E9LL},{0xFAA6547A9CCD33E9LL},{0xE093D4C4C1F69EC0LL},{-2L}},{{0xFAA6547A9CCD33E9LL},{0xE093D4C4C1F69EC0LL},{-2L},{0L},{0x7300ECD2067417FDLL},{-5L}},{{-5L},{-1L},{0x09DB2395865F6AFELL},{-1L},{-5L},{0xE093D4C4C1F69EC0LL}},{{-5L},{0xFAA6547A9CCD33E9LL},{-1L},{0L},{-5L},{-5L}},{{0xFAA6547A9CCD33E9LL},{0x7300ECD2067417FDLL},{0x7300ECD2067417FDLL},{0xFAA6547A9CCD33E9LL},{0x09DB2395865F6AFELL},{-5L}},{{-2L},{-5L},{-1L},{0xE093D4C4C1F69EC0LL},{0L},{0xE093D4C4C1F69EC0LL}},{{0x09DB2395865F6AFELL},{0L},{0x09DB2395865F6AFELL},{2L},{0L},{-5L}},{{-1L},{-5L},{-2L},{0x09DB2395865F6AFELL},{0x09DB2395865F6AFELL},{-2L}}};
static struct S0 g_9689[5] = {{249UL,0x4BB2E2ECL,81,0x698AL,18446744073709551615UL,0L},{249UL,0x4BB2E2ECL,81,0x698AL,18446744073709551615UL,0L},{249UL,0x4BB2E2ECL,81,0x698AL,18446744073709551615UL,0L},{249UL,0x4BB2E2ECL,81,0x698AL,18446744073709551615UL,0L},{249UL,0x4BB2E2ECL,81,0x698AL,18446744073709551615UL,0L}};
static uint64_t g_9692 = 7UL;
static volatile uint32_t g_9697 = 2UL;/* VOLATILE GLOBAL g_9697 */
static volatile uint32_t *g_9696 = &g_9697;
static volatile uint32_t * volatile * volatile g_9695 = &g_9696;/* VOLATILE GLOBAL g_9695 */
static volatile uint32_t * volatile *g_9698[2] = {&g_9696,&g_9696};
static volatile uint32_t * volatile * volatile *g_9694[7] = {&g_9695,(void*)0,&g_9695,&g_9695,(void*)0,&g_9695,&g_9695};
static volatile uint32_t * volatile * volatile **g_9693[3] = {&g_9694[4],&g_9694[4],&g_9694[4]};
static struct S1 g_9759[10] = {{-1,-27147,9,634,19722,327},{3,-17669,14,119,41166,223},{-2,23522,8,807,43156,174},{-2,23522,8,807,43156,174},{3,-17669,14,119,41166,223},{-1,-27147,9,634,19722,327},{3,-17669,14,119,41166,223},{-2,23522,8,807,43156,174},{-2,23522,8,807,43156,174},{3,-17669,14,119,41166,223}};
static struct S1 g_9762 = {5,1054,1,229,29090,440};/* VOLATILE GLOBAL g_9762 */
static int64_t g_9806 = (-5L);
static union U2 ***g_9882 = (void*)0;
static union U2 ****g_9881 = &g_9882;
static union U2 *****g_9880[6] = {&g_9881,&g_9881,&g_9881,&g_9881,&g_9881,&g_9881};
static struct S1 g_9898 = {9,-14833,6,1228,29008,266};/* VOLATILE GLOBAL g_9898 */
static struct S1 g_9912 = {-0,12246,19,1157,34868,433};/* VOLATILE GLOBAL g_9912 */
static union U4 g_9915[3] = {{0},{0},{0}};
static union U4 g_9917 = {0};/* VOLATILE GLOBAL g_9917 */
static union U5 g_9921[5][4] = {{{0xEA926FAA81BD54BCLL},{0xEA926FAA81BD54BCLL},{0xEA926FAA81BD54BCLL},{0xEA926FAA81BD54BCLL}},{{0xEA926FAA81BD54BCLL},{0xEA926FAA81BD54BCLL},{0xEA926FAA81BD54BCLL},{0xEA926FAA81BD54BCLL}},{{0xEA926FAA81BD54BCLL},{0xEA926FAA81BD54BCLL},{0xEA926FAA81BD54BCLL},{0xEA926FAA81BD54BCLL}},{{0xEA926FAA81BD54BCLL},{0xEA926FAA81BD54BCLL},{0xEA926FAA81BD54BCLL},{0xEA926FAA81BD54BCLL}},{{0xEA926FAA81BD54BCLL},{0xEA926FAA81BD54BCLL},{0xEA926FAA81BD54BCLL},{0xEA926FAA81BD54BCLL}}};
static union U5 *g_9920 = &g_9921[4][2];
static union U5 g_9993 = {-3L};/* VOLATILE GLOBAL g_9993 */
static uint8_t ***g_10001[3] = {&g_4139,&g_4139,&g_4139};
static uint8_t ****g_10000 = &g_10001[1];
static uint64_t g_10163 = 0xF100AE58A2A1E620LL;
static uint64_t ****g_10194[3] = {&g_3682,&g_3682,&g_3682};
static uint64_t *****g_10193 = &g_10194[2];
static uint32_t g_10267 = 0x999A9983L;
static union U3 g_10293 = {0};/* VOLATILE GLOBAL g_10293 */
static union U2 g_10336 = {0xA1349F05L};/* VOLATILE GLOBAL g_10336 */
static uint32_t g_10366 = 4294967288UL;
static struct S1 g_10414 = {8,17770,15,300,24686,288};/* VOLATILE GLOBAL g_10414 */
static union U4 g_10443 = {0};/* VOLATILE GLOBAL g_10443 */
static union U4 g_10445 = {0};/* VOLATILE GLOBAL g_10445 */
static struct S0 g_10447 = {0x5CL,0xB628FF7AL,7,-5L,0xA11FE49B186CC868LL,0xFCB2L};/* VOLATILE GLOBAL g_10447 */
static struct S0 g_10449 = {0x79L,8UL,-120,3L,0UL,0xAE45L};/* VOLATILE GLOBAL g_10449 */
static uint32_t g_10461 = 0UL;
static union U2 g_10468[10] = {{-1L},{-1L},{0xE08EE8A5L},{-1L},{-1L},{0xE08EE8A5L},{-1L},{-1L},{0xE08EE8A5L},{-1L}};
static union U2 g_10583[2][1][7] = {{{{9L},{9L},{9L},{9L},{9L},{9L},{9L}}},{{{9L},{9L},{9L},{9L},{9L},{9L},{9L}}}};
static union U2 g_10585 = {-1L};/* VOLATILE GLOBAL g_10585 */
static int8_t * volatile * volatile * volatile * const  volatile *g_10694 = (void*)0;
static union U5 * const *g_10711 = &g_1070;
static union U5 * const **g_10710 = &g_10711;
static union U5 * const ***g_10709 = &g_10710;
static union U2 g_10729 = {0x53AEC975L};/* VOLATILE GLOBAL g_10729 */
static union U5 g_10739[2] = {{1L},{1L}};
static const union U4 g_10756 = {0};/* VOLATILE GLOBAL g_10756 */
static const union U4 *g_10755 = &g_10756;
static const union U4 **g_10754 = &g_10755;
static const union U4 ***g_10753 = &g_10754;
static union U2 g_10839 = {0xE250357DL};/* VOLATILE GLOBAL g_10839 */
static union U2 g_10840 = {0xEADACA5AL};/* VOLATILE GLOBAL g_10840 */
static union U2 g_10842 = {0xBBB12674L};/* VOLATILE GLOBAL g_10842 */
static int16_t g_10902 = 0x3087L;
static union U3 g_10956 = {0};/* VOLATILE GLOBAL g_10956 */
static int32_t g_10973 = 0xD9D54A26L;
static int32_t *g_10974 = &g_255;
static uint32_t g_10991 = 0x20627830L;
static union U3 g_10995 = {0};/* VOLATILE GLOBAL g_10995 */
static union U3 g_11004 = {0};/* VOLATILE GLOBAL g_11004 */
static union U2 ** const **g_11027[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static int32_t ** const *g_11090 = &g_1207;
static int32_t ** const **g_11089 = &g_11090;
static int32_t g_11124 = 0x80389C16L;
static struct S0 g_11144 = {0x73L,18446744073709551613UL,-156,0L,5UL,-1L};/* VOLATILE GLOBAL g_11144 */
static struct S0 g_11147 = {1UL,0x4532E928L,192,0x9AE3L,18446744073709551615UL,0xF32AL};/* VOLATILE GLOBAL g_11147 */
static union U2 g_11203 = {0x44CCE954L};/* VOLATILE GLOBAL g_11203 */
static struct S1 *****g_11240 = (void*)0;
static int32_t g_11302 = (-1L);
static uint16_t g_11314 = 65529UL;
static union U4 g_11322[3][8][7] = {{{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}}}};
static union U4 g_11323 = {0};/* VOLATILE GLOBAL g_11323 */
static union U4 g_11324[7][1][1] = {{{{0}}},{{{0}}},{{{0}}},{{{0}}},{{{0}}},{{{0}}},{{{0}}}};
static union U4 g_11325 = {0};/* VOLATILE GLOBAL g_11325 */
static union U4 g_11326[7][6][6] = {{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}}};
static union U4 g_11327[5][2] = {{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}};
static union U4 g_11328 = {0};/* VOLATILE GLOBAL g_11328 */
static union U4 g_11329[2][4] = {{{0},{0},{0},{0}},{{0},{0},{0},{0}}};
static union U4 g_11330 = {0};/* VOLATILE GLOBAL g_11330 */
static union U2 *g_11354 = (void*)0;
static union U2 g_11358 = {9L};/* VOLATILE GLOBAL g_11358 */
static int32_t *g_11360 = &g_499[0][0];
static const uint32_t g_11421 = 1UL;
static struct S0 g_11436[10][5] = {{{0x66L,0x3FE475D3L,-154,1L,0x5DAF3519770CBF05LL,0x63A8L},{0x66L,0x3FE475D3L,-154,1L,0x5DAF3519770CBF05LL,0x63A8L},{0xABL,0x2C624D39L,215,1L,0UL,0L},{0x66L,0x3FE475D3L,-154,1L,0x5DAF3519770CBF05LL,0x63A8L},{0x66L,0x3FE475D3L,-154,1L,0x5DAF3519770CBF05LL,0x63A8L}},{{255UL,0UL,222,0xA6B7L,0x34BEF1F54667E08DLL,0L},{0x23L,0x3AC0C925L,-73,-1L,0xD01E5F925412202ALL,5L},{255UL,0UL,222,0xA6B7L,0x34BEF1F54667E08DLL,0L},{255UL,0UL,222,0xA6B7L,0x34BEF1F54667E08DLL,0L},{0x23L,0x3AC0C925L,-73,-1L,0xD01E5F925412202ALL,5L}},{{0x66L,0x3FE475D3L,-154,1L,0x5DAF3519770CBF05LL,0x63A8L},{6UL,0xFA92BBBCL,-185,-1L,1UL,0L},{6UL,0xFA92BBBCL,-185,-1L,1UL,0L},{0x66L,0x3FE475D3L,-154,1L,0x5DAF3519770CBF05LL,0x63A8L},{6UL,0xFA92BBBCL,-185,-1L,1UL,0L}},{{0x23L,0x3AC0C925L,-73,-1L,0xD01E5F925412202ALL,5L},{0x23L,0x3AC0C925L,-73,-1L,0xD01E5F925412202ALL,5L},{0UL,0xC455D081L,-194,0x4F70L,0x08E5AE7BF03E183ELL,-3L},{0x23L,0x3AC0C925L,-73,-1L,0xD01E5F925412202ALL,5L},{0x23L,0x3AC0C925L,-73,-1L,0xD01E5F925412202ALL,5L}},{{6UL,0xFA92BBBCL,-185,-1L,1UL,0L},{0x66L,0x3FE475D3L,-154,1L,0x5DAF3519770CBF05LL,0x63A8L},{6UL,0xFA92BBBCL,-185,-1L,1UL,0L},{6UL,0xFA92BBBCL,-185,-1L,1UL,0L},{0x66L,0x3FE475D3L,-154,1L,0x5DAF3519770CBF05LL,0x63A8L}},{{0x23L,0x3AC0C925L,-73,-1L,0xD01E5F925412202ALL,5L},{255UL,0UL,222,0xA6B7L,0x34BEF1F54667E08DLL,0L},{255UL,0UL,222,0xA6B7L,0x34BEF1F54667E08DLL,0L},{0x23L,0x3AC0C925L,-73,-1L,0xD01E5F925412202ALL,5L},{255UL,0UL,222,0xA6B7L,0x34BEF1F54667E08DLL,0L}},{{0x66L,0x3FE475D3L,-154,1L,0x5DAF3519770CBF05LL,0x63A8L},{0x66L,0x3FE475D3L,-154,1L,0x5DAF3519770CBF05LL,0x63A8L},{0xABL,0x2C624D39L,215,1L,0UL,0L},{0x66L,0x3FE475D3L,-154,1L,0x5DAF3519770CBF05LL,0x63A8L},{0x66L,0x3FE475D3L,-154,1L,0x5DAF3519770CBF05LL,0x63A8L}},{{255UL,0UL,222,0xA6B7L,0x34BEF1F54667E08DLL,0L},{0x23L,0x3AC0C925L,-73,-1L,0xD01E5F925412202ALL,5L},{255UL,0UL,222,0xA6B7L,0x34BEF1F54667E08DLL,0L},{255UL,0UL,222,0xA6B7L,0x34BEF1F54667E08DLL,0L},{0x23L,0x3AC0C925L,-73,-1L,0xD01E5F925412202ALL,5L}},{{0x66L,0x3FE475D3L,-154,1L,0x5DAF3519770CBF05LL,0x63A8L},{6UL,0xFA92BBBCL,-185,-1L,1UL,0L},{6UL,0xFA92BBBCL,-185,-1L,1UL,0L},{0x66L,0x3FE475D3L,-154,1L,0x5DAF3519770CBF05LL,0x63A8L},{6UL,0xFA92BBBCL,-185,-1L,1UL,0L}},{{0x23L,0x3AC0C925L,-73,-1L,0xD01E5F925412202ALL,5L},{0x23L,0x3AC0C925L,-73,-1L,0xD01E5F925412202ALL,5L},{0UL,0xC455D081L,-194,0x4F70L,0x08E5AE7BF03E183ELL,-3L},{0x23L,0x3AC0C925L,-73,-1L,0xD01E5F925412202ALL,5L},{255UL,0UL,222,0xA6B7L,0x34BEF1F54667E08DLL,0L}}};
static const volatile struct S0 ***g_11437 = (void*)0;
static struct S0 g_11493 = {0xC7L,0x2505B464L,-255,1L,0UL,0L};/* VOLATILE GLOBAL g_11493 */
static uint8_t g_11542 = 1UL;
static int16_t ***g_11550[2][3] = {{&g_1030[0][0],&g_1030[0][0],&g_1030[0][0]},{&g_1030[0][0],&g_1030[0][0],&g_1030[0][0]}};
static uint64_t g_11569 = 18446744073709551612UL;
static union U2 g_11571 = {-1L};/* VOLATILE GLOBAL g_11571 */
static union U3 g_11735 = {0};/* VOLATILE GLOBAL g_11735 */
static const volatile union U3 *g_11742 = (void*)0;
static int64_t g_11743 = 0x5DACA700566D785CLL;
static uint32_t ****g_11807[10][2] = {{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0}};
static uint32_t *****g_11806 = &g_11807[2][0];
static int32_t g_11830 = 0x304E43CFL;
static union U5 g_11925 = {0x304EB355613BF25BLL};/* VOLATILE GLOBAL g_11925 */
static union U5 g_11927 = {9L};/* VOLATILE GLOBAL g_11927 */
static int32_t g_12051 = 0xF60222CEL;
static union U4 g_12055 = {0};/* VOLATILE GLOBAL g_12055 */
static int64_t g_12064 = 0xC458F25ED96B7AEBLL;
static uint32_t ****g_12076 = (void*)0;
static int64_t ****g_12176 = &g_6439[8][1];
static int32_t g_12187 = (-10L);
static union U3 g_12370 = {0};/* VOLATILE GLOBAL g_12370 */
static int64_t g_12383 = 0x34C6CB840C2ECAACLL;
static struct S1 g_12449 = {-9,5380,7,812,38122,299};/* VOLATILE GLOBAL g_12449 */
static union U3 g_12457[1][1][3] = {{{{0},{0},{0}}}};
static union U3 g_12459 = {0};/* VOLATILE GLOBAL g_12459 */
static union U5 g_12487 = {-4L};/* VOLATILE GLOBAL g_12487 */
static uint8_t * const *g_12504 = &g_5411;
static uint8_t * const **g_12503 = &g_12504;
static uint8_t * const ***g_12502 = &g_12503;
static uint8_t * const ****g_12501 = &g_12502;
static struct S0 g_12522 = {1UL,1UL,162,8L,18446744073709551608UL,0x15C4L};/* VOLATILE GLOBAL g_12522 */
static struct S0 g_12526 = {0xB4L,1UL,235,0xF4EDL,0xEFBB5AF0C8403D0FLL,9L};/* VOLATILE GLOBAL g_12526 */
static union U3 g_12590 = {0};/* VOLATILE GLOBAL g_12590 */
static struct S1 g_12820 = {5,26130,20,176,27708,121};/* VOLATILE GLOBAL g_12820 */
static uint64_t g_12831 = 0UL;
static int16_t *****g_12971[5][4][10] = {{{&g_4296,&g_4296,&g_4296,&g_4296,(void*)0,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296},{&g_4296,&g_4296,&g_4296,(void*)0,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296},{(void*)0,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296},{(void*)0,&g_4296,&g_4296,&g_4296,&g_4296,(void*)0,&g_4296,&g_4296,&g_4296,(void*)0}},{{&g_4296,(void*)0,&g_4296,&g_4296,&g_4296,(void*)0,&g_4296,(void*)0,&g_4296,&g_4296},{(void*)0,&g_4296,&g_4296,(void*)0,(void*)0,&g_4296,&g_4296,(void*)0,(void*)0,&g_4296},{(void*)0,&g_4296,(void*)0,&g_4296,&g_4296,&g_4296,(void*)0,&g_4296,&g_4296,(void*)0},{&g_4296,&g_4296,(void*)0,&g_4296,&g_4296,&g_4296,&g_4296,(void*)0,&g_4296,&g_4296}},{{&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,(void*)0,&g_4296,&g_4296},{&g_4296,&g_4296,&g_4296,&g_4296,(void*)0,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296},{&g_4296,&g_4296,&g_4296,(void*)0,&g_4296,&g_4296,&g_4296,&g_4296,(void*)0,&g_4296},{&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,(void*)0,&g_4296,&g_4296,(void*)0}},{{&g_4296,&g_4296,&g_4296,(void*)0,&g_4296,&g_4296,(void*)0,&g_4296,&g_4296,&g_4296},{&g_4296,&g_4296,&g_4296,&g_4296,(void*)0,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296},{&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,(void*)0,(void*)0},{&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296}},{{&g_4296,&g_4296,(void*)0,(void*)0,&g_4296,&g_4296,&g_4296,(void*)0,(void*)0,&g_4296},{&g_4296,(void*)0,&g_4296,&g_4296,&g_4296,(void*)0,&g_4296,&g_4296,(void*)0,&g_4296},{&g_4296,(void*)0,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296},{&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,&g_4296,(void*)0,&g_4296,(void*)0,&g_4296}}};
static union U3 g_12974 = {0};/* VOLATILE GLOBAL g_12974 */
static volatile union U5 g_13016[4] = {{0x2897837D3720AB66LL},{0x2897837D3720AB66LL},{0x2897837D3720AB66LL},{0x2897837D3720AB66LL}};
static union U5 g_13017 = {-1L};/* VOLATILE GLOBAL g_13017 */
static volatile union U4 g_13024 = {0};/* VOLATILE GLOBAL g_13024 */
static struct S1 ** volatile g_13026 = &g_7095;/* VOLATILE GLOBAL g_13026 */
static union U4 g_13028 = {0};/* VOLATILE GLOBAL g_13028 */
static int32_t g_13032 = 1L;
static volatile union U2 g_13049 = {0L};/* VOLATILE GLOBAL g_13049 */
static volatile struct S0 g_13124[5] = {{0xBFL,0xD9E871C0L,235,5L,8UL,0x1829L},{0xBFL,0xD9E871C0L,235,5L,8UL,0x1829L},{0xBFL,0xD9E871C0L,235,5L,8UL,0x1829L},{0xBFL,0xD9E871C0L,235,5L,8UL,0x1829L},{0xBFL,0xD9E871C0L,235,5L,8UL,0x1829L}};
static union U2 g_13141 = {-1L};/* VOLATILE GLOBAL g_13141 */
static int64_t ***g_13197[8][8][4] = {{{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{(void*)0,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440}},{{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{(void*)0,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440}},{{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{(void*)0,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440}},{{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{(void*)0,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440}},{{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{(void*)0,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440}},{{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,(void*)0,(void*)0},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,(void*)0}},{{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{(void*)0,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440}},{{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440},{&g_6440,&g_6440,(void*)0,&g_6440},{&g_6440,&g_6440,&g_6440,&g_6440}}};
static union U2 g_13221 = {6L};/* VOLATILE GLOBAL g_13221 */
static volatile int32_t g_13246[4] = {0x1F1D4B29L,0x1F1D4B29L,0x1F1D4B29L,0x1F1D4B29L};
static volatile int64_t g_13260 = 0x6A97ED899A2995C6LL;/* VOLATILE GLOBAL g_13260 */
static union U4 g_13276 = {0};/* VOLATILE GLOBAL g_13276 */
static volatile struct S0 g_13298[6][6] = {{{251UL,18446744073709551615UL,30,0x589CL,0xFE6A61827C8E6CDBLL,0x9A28L},{5UL,1UL,-174,0x6291L,0UL,-8L},{251UL,18446744073709551615UL,30,0x589CL,0xFE6A61827C8E6CDBLL,0x9A28L},{255UL,0x8EB948BAL,-116,0xBBEFL,18446744073709551606UL,0xF909L},{5UL,1UL,-174,0x6291L,0UL,-8L},{0xF4L,1UL,19,0x93AAL,18446744073709551606UL,0xDC92L}},{{251UL,18446744073709551615UL,30,0x589CL,0xFE6A61827C8E6CDBLL,0x9A28L},{0UL,0UL,150,8L,0UL,0x66E3L},{255UL,0x8EB948BAL,-116,0xBBEFL,18446744073709551606UL,0xF909L},{255UL,0x8EB948BAL,-116,0xBBEFL,18446744073709551606UL,0xF909L},{0UL,0UL,150,8L,0UL,0x66E3L},{251UL,18446744073709551615UL,30,0x589CL,0xFE6A61827C8E6CDBLL,0x9A28L}},{{251UL,18446744073709551615UL,30,0x589CL,0xFE6A61827C8E6CDBLL,0x9A28L},{251UL,18446744073709551613UL,32,0L,0xB03DAA65E9BFC2C9LL,0xC527L},{0xF4L,1UL,19,0x93AAL,18446744073709551606UL,0xDC92L},{255UL,0x8EB948BAL,-116,0xBBEFL,18446744073709551606UL,0xF909L},{251UL,18446744073709551613UL,32,0L,0xB03DAA65E9BFC2C9LL,0xC527L},{255UL,0x8EB948BAL,-116,0xBBEFL,18446744073709551606UL,0xF909L}},{{251UL,18446744073709551615UL,30,0x589CL,0xFE6A61827C8E6CDBLL,0x9A28L},{5UL,1UL,-174,0x6291L,0UL,-8L},{251UL,18446744073709551615UL,30,0x589CL,0xFE6A61827C8E6CDBLL,0x9A28L},{255UL,0x8EB948BAL,-116,0xBBEFL,18446744073709551606UL,0xF909L},{5UL,1UL,-174,0x6291L,0UL,-8L},{0xF4L,1UL,19,0x93AAL,18446744073709551606UL,0xDC92L}},{{251UL,18446744073709551615UL,30,0x589CL,0xFE6A61827C8E6CDBLL,0x9A28L},{0UL,0UL,150,8L,0UL,0x66E3L},{255UL,0x8EB948BAL,-116,0xBBEFL,18446744073709551606UL,0xF909L},{255UL,0x8EB948BAL,-116,0xBBEFL,18446744073709551606UL,0xF909L},{0UL,0UL,150,8L,0UL,0x66E3L},{251UL,18446744073709551615UL,30,0x589CL,0xFE6A61827C8E6CDBLL,0x9A28L}},{{251UL,18446744073709551615UL,30,0x589CL,0xFE6A61827C8E6CDBLL,0x9A28L},{251UL,18446744073709551613UL,32,0L,0xB03DAA65E9BFC2C9LL,0xC527L},{0xF4L,1UL,19,0x93AAL,18446744073709551606UL,0xDC92L},{255UL,0x8EB948BAL,-116,0xBBEFL,18446744073709551606UL,0xF909L},{251UL,18446744073709551613UL,32,0L,0xB03DAA65E9BFC2C9LL,0xC527L},{255UL,0x8EB948BAL,-116,0xBBEFL,18446744073709551606UL,0xF909L}}};
static volatile union U4 g_13312 = {0};/* VOLATILE GLOBAL g_13312 */
static const struct S0 g_13361 = {0x6BL,0xA3F7B334L,-182,0xE220L,9UL,-4L};/* VOLATILE GLOBAL g_13361 */
static volatile union U2 g_13364 = {0xA258A768L};/* VOLATILE GLOBAL g_13364 */
static volatile struct S1 g_13370 = {7,1568,19,1260,13361,458};/* VOLATILE GLOBAL g_13370 */
static union U4 g_13412 = {0};/* VOLATILE GLOBAL g_13412 */


/* --- FORWARD DECLARATIONS --- */
static union U4  func_1(void);
static int8_t * func_12(uint8_t  p_13, int32_t  p_14, int8_t * p_15);
static uint8_t  func_22(int64_t  p_23, int8_t * p_24, uint64_t  p_25, int8_t  p_26);
static const int32_t  func_30(uint64_t  p_31, int8_t * p_32, const int8_t * p_33);
static int32_t  func_39(int32_t  p_40, uint32_t  p_41);
static int16_t  func_44(int64_t  p_45, uint32_t  p_46, int8_t  p_47, int8_t * p_48);
static int32_t  func_50(int8_t * p_51, int32_t * p_52, const int8_t * p_53);
static int8_t * func_54(const int8_t * p_55, int32_t * const  p_56, const uint32_t  p_57, int32_t * p_58);
static int32_t * func_60(int16_t  p_61, uint8_t  p_62);
static int16_t  func_84(int8_t * p_85, int16_t  p_86);
static int8_t * func_87(int16_t * p_88, int32_t * p_89);
static uint64_t  func_101(int32_t * p_102, uint8_t  p_103, const uint32_t  p_104, const int8_t * p_105, int8_t * const  p_106);
static int32_t * func_107(const uint32_t * p_108, const int16_t * p_109, uint32_t  p_110, int8_t  p_111, int16_t  p_112);
static const int16_t * func_114(int32_t  p_115, uint8_t  p_116, uint32_t * p_117, int32_t * p_118, uint32_t * p_119);
static int32_t  func_125(int32_t * p_126, uint32_t  p_127, int8_t * p_128, int32_t  p_129);
static uint32_t * func_132(int8_t * p_133, const int16_t * p_134, uint32_t  p_135, int16_t * p_136);
static int8_t * func_137(uint32_t * p_138);
static uint32_t * func_139(const int32_t  p_140);
static uint32_t  func_141(int16_t  p_142, int8_t  p_143);
static uint32_t  func_182(uint8_t  p_183, uint64_t  p_184, uint8_t  p_185, const int16_t * const  p_186);
static int8_t  func_192(int64_t  p_193, int16_t  p_194);
static int8_t  func_197(uint32_t  p_198, int16_t * p_199, int32_t  p_200, const int32_t * p_201);
static int16_t  func_208(uint8_t * p_209, int32_t  p_210, const uint32_t * p_211, uint32_t ** p_212);
static int16_t * func_223(int16_t  p_224, uint64_t  p_225, int8_t * p_226, int64_t * p_227, int16_t  p_228);
static int8_t * func_235(int64_t * p_236, uint32_t * const * p_237);
static int64_t * func_238(const int32_t * p_239, uint32_t  p_240, uint8_t  p_241);
static uint8_t  func_249(int32_t  p_250);
static int8_t  func_251(int8_t  p_252);
static const int32_t  func_263(uint64_t  p_264, int8_t * p_265, const uint64_t  p_266);
static int8_t * func_267(uint8_t * p_268, uint8_t  p_269);
static uint8_t * func_270(int16_t  p_271, union U3 * p_272, uint16_t  p_273, uint32_t  p_274, uint32_t  p_275);
static int64_t  func_278(uint64_t  p_279, uint8_t * p_280, int32_t  p_281);
static uint64_t  func_282(uint32_t ** p_283);
static uint32_t ** func_284(uint32_t  p_285, int16_t  p_286, int64_t  p_287);
static int16_t  func_288(int8_t * p_289, uint16_t  p_290, const uint32_t * p_291);
static int8_t * func_292(const int8_t  p_293);
static int64_t  func_309(int64_t * p_310, int32_t  p_311, uint32_t ** p_312, uint16_t  p_313);
static int64_t * func_314(uint8_t  p_315, int32_t * p_316);
static const int64_t  func_317(uint16_t  p_318, int64_t * p_319, int32_t  p_320, const uint64_t  p_321, int32_t  p_322);
static uint8_t * func_420(uint64_t  p_421, uint32_t ** p_422, uint16_t  p_423, union U3 * p_424, int64_t  p_425);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_38 g_4095 g_4096 g_4097 g_1396 g_11090 g_1207 g_653 g_499 g_929 g_930 g_446 g_66 g_11360 g_11089 g_7 g_2 g_13016 g_13017 g_13024 g_1540 g_1541 g_998 g_13026 g_2302 g_10753 g_10754 g_7348 g_7349 g_13028 g_13260 g_6483 g_10755 g_1172 g_10756 g_13276 g_5411 g_6119 g_845 g_656 g_28 g_29 g_2717 g_2718 g_2719 g_10974 g_255 g_3302 g_13298 g_714 g_715 g_12504 g_3870 g_1678 g_232 g_13312 g_9695 g_9696 g_9697 g_466 g_857 g_340 g_13361 g_13364 g_13370 g_11 g_10366 g_5408 g_5409 g_5410 g_3345 g_3346 g_10000 g_10001 g_4139 g_188 g_163 g_1675 g_1676 g_1674 g_4422 g_4423 g_5407 g_657 g_538 g_539 g_1677 g_3477 g_6006 g_6045 g_328 g_748 g_3142.f1 g_6145 g_5749 g_1419 g_6229 g_6233 g_6256 g_6270 g_3566 g_3567 g_3420 g_3250 g_6240 g_6833 g_1920.f1 g_4088 g_5048.f0 g_7076 g_7095 g_8090.f3 g_13412
 * writes: g_3 g_7 g_8 g_11 g_1396 g_4801 g_7024.f3 g_499 g_998 g_1727 g_7095 g_1168 g_10755 g_6579.f3 g_7349 g_1351 g_3142.f1 g_7870 g_8242 g_6484 g_3870 g_657 g_29 g_255 g_3302 g_466 g_857 g_5422 g_11806 g_446 g_66 g_10366 g_3346 g_38 g_188 g_163 g_4118 g_2386.f0 g_653 g_539 g_746 g_748 g_232 g_538 g_196 g_6119 g_1470 g_1550 g_6229 g_6240 g_6256 g_2170 g_6270 g_1621 g_2302 g_3420 g_845 g_2482 g_4087 g_1273 g_4302 g_5044.f0 g_3529.f0 g_5490 g_260 g_6439 g_4338 g_6580.f3 g_6586.f3 g_1217 g_1920.f1 g_5048.f0 g_6587.f3 g_7088 g_8090.f3
 */
static union U4  func_1(void)
{ /* block id: 0 */
    uint64_t l_21 = 9UL;
    int32_t l_12985 = 0x8279A67FL;
    int32_t l_12990[1];
    uint64_t l_13010 = 0x88AC4B76917810A3LL;
    uint32_t **l_13023 = &g_4088[0];
    uint32_t l_13044[3];
    union U3 *l_13052 = &g_6086;
    uint16_t l_13065 = 0x984CL;
    uint16_t *l_13075 = &g_1218[2][5];
    union U5 ****l_13129 = (void*)0;
    union U2 ** const ***l_13135 = &g_11027[3];
    const uint32_t **** const * const l_13186 = &g_7503;
    uint8_t *****l_13256 = &g_10000;
    const union U3 *l_13259 = &g_6103;
    const union U3 **l_13258 = &l_13259;
    const union U3 *** const l_13257 = &l_13258;
    uint32_t l_13270 = 18446744073709551611UL;
    int32_t l_13284 = 8L;
    int64_t *l_13286 = (void*)0;
    uint16_t l_13350[4] = {1UL,1UL,1UL,1UL};
    uint16_t l_13381 = 65534UL;
    int i;
    for (i = 0; i < 1; i++)
        l_12990[i] = 0x5E48AF93L;
    for (i = 0; i < 3; i++)
        l_13044[i] = 0x50A1F7E6L;
    for (g_3 = 3; (g_3 >= 0); g_3 -= 1)
    { /* block id: 3 */
        uint8_t l_27[3][7][10] = {{{3UL,9UL,248UL,9UL,3UL,0x11L,3UL,9UL,248UL,9UL},{0x9EL,0UL,0x64L,9UL,0x64L,0UL,0x9EL,0UL,0x64L,9UL},{0x29L,9UL,0x29L,0UL,3UL,0UL,0x29L,9UL,0x29L,0UL},{0x9EL,9UL,0UL,0UL,0x64L,9UL,0x64L,0UL,0x9EL,0UL},{0x29L,0x11L,248UL,0UL,248UL,0x11L,0x29L,0x11L,248UL,0UL},{0UL,0UL,0UL,0x11L,0x64L,0x11L,0UL,0UL,0UL,0x11L},{0x29L,0UL,3UL,0UL,0x29L,9UL,0x29L,0UL,3UL,0UL}},{{0x64L,0x11L,0UL,0UL,0UL,0x11L,0x64L,0x11L,0UL,0UL},{248UL,0UL,248UL,0x11L,0x29L,0x11L,248UL,0UL,248UL,0x11L},{0x64L,0UL,0x9EL,0UL,0x64L,9UL,0x64L,0UL,0x9EL,0UL},{0x29L,0x11L,248UL,0UL,248UL,0x11L,0x29L,0x11L,248UL,0UL},{0UL,0UL,0UL,0x11L,0x64L,0x11L,0UL,0UL,0UL,0x11L},{0x29L,0UL,3UL,0UL,0x29L,9UL,0x29L,0UL,3UL,0UL},{0x64L,0x11L,0UL,0UL,0UL,0x11L,0x64L,0x11L,0UL,0UL}},{{248UL,0UL,248UL,0x11L,0x29L,0x11L,248UL,0UL,248UL,0x11L},{0x64L,0UL,0x9EL,0UL,0x64L,9UL,0x64L,0UL,0x9EL,0UL},{0x29L,0x11L,248UL,0UL,248UL,0x11L,0x29L,0x11L,248UL,0UL},{0UL,0UL,0UL,0x11L,0x64L,0x11L,0UL,0UL,0UL,0x11L},{0x29L,0UL,3UL,0UL,0x29L,9UL,0x29L,0UL,3UL,0UL},{0x64L,0x11L,0UL,0UL,0UL,0x11L,0x64L,0x11L,0UL,0UL},{248UL,0UL,248UL,0x11L,0x29L,0x11L,248UL,0UL,248UL,0x11L}}};
        int32_t l_12992 = 0xAB3E3B34L;
        int32_t l_12993 = 0xC5E31652L;
        int32_t l_12994 = 0x379E689EL;
        int32_t l_12995 = (-7L);
        const union U3 *l_12999 = &g_8412[2][5];
        int16_t *****l_13005 = &g_4296;
        uint32_t l_13034 = 9UL;
        int64_t l_13039[1][7][9] = {{{5L,(-1L),0x2A7D74AC1DB7A57FLL,(-1L),5L,(-4L),5L,(-1L),0x2A7D74AC1DB7A57FLL},{0x6763FFA58E5D45E6LL,0x6763FFA58E5D45E6LL,1L,0x1E028B8EF48E4BEALL,0x3A3EE557BB9E18B4LL,0x6763FFA58E5D45E6LL,(-1L),(-1L),0x6763FFA58E5D45E6LL},{1L,0x3B9DB2655ADEFB27LL,0x7B3464985490D9BDLL,0x3B9DB2655ADEFB27LL,1L,(-1L),1L,0x3B9DB2655ADEFB27LL,0x7B3464985490D9BDLL},{0x3A3EE557BB9E18B4LL,(-1L),0x1E028B8EF48E4BEALL,0x3A3EE557BB9E18B4LL,0x3A3EE557BB9E18B4LL,0x1E028B8EF48E4BEALL,(-1L),0x3A3EE557BB9E18B4LL,0x6763FFA58E5D45E6LL},{4L,0x3B9DB2655ADEFB27LL,5L,0x3B9DB2655ADEFB27LL,4L,(-1L),4L,0x3B9DB2655ADEFB27LL,5L},{0x3A3EE557BB9E18B4LL,0x3A3EE557BB9E18B4LL,0x1E028B8EF48E4BEALL,(-1L),0x3A3EE557BB9E18B4LL,0x6763FFA58E5D45E6LL,(-1L),(-1L),0x6763FFA58E5D45E6LL},{1L,0x3B9DB2655ADEFB27LL,0x7B3464985490D9BDLL,0x3B9DB2655ADEFB27LL,1L,(-1L),1L,0x3B9DB2655ADEFB27LL,0x7B3464985490D9BDLL}}};
        int32_t l_13042 = 0x4EDA799DL;
        int32_t l_13043 = (-1L);
        int32_t l_13074 = 0x996C0231L;
        const uint32_t *l_13084 = (void*)0;
        const uint32_t **l_13083[8] = {&l_13084,&l_13084,&l_13084,&l_13084,&l_13084,&l_13084,&l_13084,&l_13084};
        const uint32_t ** const *l_13082[3][5] = {{&l_13083[2],&l_13083[2],&l_13083[2],&l_13083[2],&l_13083[2]},{&l_13083[2],&l_13083[2],&l_13083[2],&l_13083[2],&l_13083[2]},{&l_13083[2],&l_13083[2],&l_13083[2],&l_13083[2],&l_13083[2]}};
        const uint32_t ** const **l_13081[7];
        const uint32_t ** const ***l_13080 = &l_13081[1];
        int64_t l_13086 = 0xB99C7608DBA0FC39LL;
        union U2 * const l_13140 = &g_13141;
        union U2 * const *l_13139[4][9] = {{&l_13140,&l_13140,(void*)0,(void*)0,&l_13140,(void*)0,(void*)0,&l_13140,&l_13140},{(void*)0,(void*)0,&l_13140,(void*)0,(void*)0,(void*)0,&l_13140,(void*)0,(void*)0},{&l_13140,&l_13140,(void*)0,(void*)0,&l_13140,(void*)0,(void*)0,&l_13140,&l_13140},{(void*)0,(void*)0,&l_13140,(void*)0,(void*)0,(void*)0,&l_13140,(void*)0,(void*)0}};
        union U2 * const **l_13138 = &l_13139[2][3];
        union U2 * const ***l_13137 = &l_13138;
        union U2 * const ****l_13136 = &l_13137;
        int16_t l_13237 = (-1L);
        uint32_t l_13247 = 0x08FBC6BDL;
        int i, j, k;
        for (i = 0; i < 7; i++)
            l_13081[i] = &l_13082[2][1];
        for (g_7[2][5][1] = 4; (g_7[2][5][1] >= 0); g_7[2][5][1] -= 1)
        { /* block id: 6 */
            const int8_t l_12958[9] = {0L,0L,0L,0L,0L,0L,0L,0L,0L};
            int32_t l_12991[10];
            int32_t **l_13004 = &g_11360;
            union U4 *l_13027 = &g_1172;
            union U5 **l_13123 = &g_9920;
            union U5 ****l_13130 = &g_6483;
            uint8_t l_13179 = 0xD0L;
            int64_t ** const l_13194 = (void*)0;
            int64_t ** const *l_13193 = &l_13194;
            uint8_t l_13214[2];
            uint64_t l_13235[6];
            int i;
            for (i = 0; i < 10; i++)
                l_12991[i] = (-1L);
            for (i = 0; i < 2; i++)
                l_13214[i] = 0x4EL;
            for (i = 0; i < 6; i++)
                l_13235[i] = 18446744073709551612UL;
            for (g_8 = 4; (g_8 >= 0); g_8 -= 1)
            { /* block id: 9 */
                uint8_t l_18[1][2];
                int32_t l_12957[8] = {0xECEF80FFL,0xECEF80FFL,0xECEF80FFL,0xECEF80FFL,0xECEF80FFL,0xECEF80FFL,0xECEF80FFL,0xECEF80FFL};
                int8_t *l_12959 = &g_1621[2];
                int32_t *l_12986 = &l_12957[5];
                int32_t *l_12987 = &g_38;
                int32_t *l_12988 = &g_38;
                int32_t *l_12989[7] = {&g_11,&g_11,&g_11,&g_11,&g_11,&g_11,&g_11};
                uint64_t l_12996 = 1UL;
                int16_t *****l_13011 = (void*)0;
                int i, j;
                for (i = 0; i < 1; i++)
                {
                    for (j = 0; j < 2; j++)
                        l_18[i][j] = 1UL;
                }
                for (g_11 = 4; (g_11 >= 0); g_11 -= 1)
                { /* block id: 12 */
                    int i, j, k;
                }
                ++l_12996;
                (*l_12986) |= ((*l_12988) <= (1L > (((***g_4095) &= ((void*)0 == l_12999)) , (((safe_mod_func_int32_t_s_s(l_12990[0], ((((((safe_add_func_uint16_t_u_u(((void*)0 == l_13004), ((g_4801 = l_13005) != (l_13011 = (((safe_rshift_func_int16_t_s_s(((safe_mul_func_uint16_t_u_u(l_12994, l_12990[0])) && l_13010), 13)) > l_12995) , l_13011))))) & (-2L)) == 4L) , (***g_11090)) & (**g_929)) , l_27[1][6][2]))) >= 0x0845L) && (**l_13004)))));
                if ((****g_11089))
                    continue;
            }
            for (g_7024.f3 = 1; (g_7024.f3 >= 0); g_7024.f3 -= 1)
            { /* block id: 5572 */
                struct S1 * const l_13025 = &g_6544;
                int i, j, k;
                (*g_653) = (safe_lshift_func_uint8_t_u_u(g_2[g_7[2][5][1]][g_3][g_3], 0));
                (**l_13004) = ((safe_add_func_int64_t_s_s(g_2[g_7[2][5][1]][g_3][g_3], ((**g_1540) ^= (g_13016[0] , ((g_13017 , (safe_rshift_func_int16_t_s_s((((safe_div_func_int32_t_s_s((((1L == (!((**l_13004) >= (l_13023 != (void*)0)))) ^ l_21) , (g_13024 , l_12985)), (**g_1207))) ^ 0x9428L) , g_2[g_7[2][5][1]][g_3][g_3]), 5))) <= g_2[g_7[2][5][1]][g_3][g_3]))))) != (*g_11360));
                for (g_1727 = 0; (g_1727 <= 4); g_1727 += 1)
                { /* block id: 5578 */
                    (*g_13026) = l_13025;
                    (**g_10753) = ((*g_2302) = l_13027);
                    for (g_6579.f3 = 6; (g_6579.f3 >= 0); g_6579.f3 -= 1)
                    { /* block id: 5584 */
                        (*g_7348) |= (*g_653);
                    }
                }
            }
            for (g_1351 = 0; (g_1351 <= 4); g_1351 += 1)
            { /* block id: 5591 */
                return g_13028;
            }
            for (g_3142.f1 = 0; (g_3142.f1 <= 4); g_3142.f1 += 1)
            { /* block id: 5596 */
                int32_t l_13033 = 0x98CDD00CL;
                int32_t l_13040[5][4] = {{0x7F99F888L,(-4L),0x7F99F888L,0x7F99F888L},{(-4L),(-4L),(-1L),(-4L)},{(-4L),0x7F99F888L,0x7F99F888L,(-4L)},{0x7F99F888L,(-4L),0x7F99F888L,0x7F99F888L},{(-4L),(-4L),(-1L),(-4L)}};
                int i, j, k;
                if (g_2[(g_7[2][5][1] + 2)][(g_3 + 1)][g_3])
                    break;
                for (g_7870 = 0; (g_7870 <= 4); g_7870 += 1)
                { /* block id: 5600 */
                    int32_t *l_13029 = &l_12985;
                    int32_t *l_13030 = (void*)0;
                    int32_t *l_13031[4] = {&g_255,&g_255,&g_255,&g_255};
                    int32_t l_13037[5][4][7] = {{{1L,0xCB6B3CB1L,0x4F3ADE95L,0x6C913FF5L,(-1L),0xBA707B52L,0x02888B39L},{0xB48716EBL,0xB1EC1A50L,0x2CE1A411L,3L,0x86BDD478L,0xA1F18958L,1L},{0x1CAA0A9DL,0x4D17C5FAL,0x2CE1A411L,1L,0x82242517L,0xE6147670L,5L},{0x9E930F95L,0x8A2C964DL,0x4F3ADE95L,1L,(-1L),0xE8871F3CL,0x86BDD478L}},{{0xE8871F3CL,0x6C913FF5L,0xF36D3FCBL,0x253A79F9L,(-1L),0x253A79F9L,0x9FD370C2L},{(-1L),(-1L),3L,0xDAF7EF3EL,(-3L),0x8A2C964DL,0x02888B39L},{0xE6147670L,0xBA707B52L,2L,0x4F3ADE95L,2L,0x253A79F9L,5L},{(-1L),0x8E510805L,0xCB6B3CB1L,0x60F8CCC0L,(-3L),0x9E930F95L,0x46C9D3E0L}},{{(-5L),0x6C913FF5L,(-1L),0x8E510805L,0xB1EC1A50L,5L,0x4D17C5FAL},{(-2L),0x4D17C5FAL,0x4F3ADE95L,(-3L),0x367DC8A2L,0x8EE243BFL,5L},{0L,0xFD89718AL,1L,5L,(-1L),0xBB00DE4BL,1L},{0x7C2FA56CL,0L,5L,9L,2L,0x86BDD478L,1L}},{{0x8E510805L,0x367DC8A2L,0x46C9D3E0L,0x6C913FF5L,1L,4L,5L},{5L,1L,0x82242517L,0xBB00DE4BL,0L,1L,0x4D17C5FAL},{0xB1EC1A50L,0xE6147670L,1L,1L,0xE6147670L,0xB1EC1A50L,0x46C9D3E0L},{0x8DFCD7ABL,0x4F3ADE95L,0xB48716EBL,0x8A2C964DL,0x866EBB01L,(-3L),5L}},{{0x367DC8A2L,(-2L),0x866EBB01L,0x8EE243BFL,0x60F8CCC0L,0x94DD5E3DL,0x02888B39L},{0x46C9D3E0L,0x4F3ADE95L,0xA1F18958L,0xE6147670L,0xA925EA1AL,0x866EBB01L,0x9FD370C2L},{(-1L),0xE6147670L,0x367DC8A2L,(-1L),1L,0x02888B39L,2L},{0xF36D3FCBL,1L,0x253A79F9L,0xA925EA1AL,0xCB6B3CB1L,0xB48716EBL,0xBB00DE4BL}}};
                    int32_t l_13038 = 0x56BC447BL;
                    int8_t l_13041 = 5L;
                    int i, j, k;
                    l_13034++;
                    l_13044[0]--;
                }
            }
            for (g_8242 = 1; (g_8242 <= 4); g_8242 += 1)
            { /* block id: 5607 */
                union U3 * const l_13050 = &g_6100;
                union U3 *l_13051 = &g_11735;
                int32_t l_13064 = 0x43077636L;
                int32_t l_13177 = 0x59DCAB48L;
                const int16_t *l_13236[9] = {&g_1470,&g_1470,&g_1470,&g_1470,&g_1470,&g_1470,&g_1470,&g_1470,&g_1470};
                int i, j, k;
            }
        }
    }
    if (((l_13044[0] && (safe_sub_func_uint64_t_u_u(((safe_mul_func_int8_t_s_s((0xB6L & (-1L)), (l_12990[0] |= (safe_rshift_func_int8_t_s_s((&g_10000 != l_13256), (l_13257 != (void*)0)))))) < 0xE266L), ((l_13065 , (void*)0) == (void*)0)))) & g_13260))
    { /* block id: 5679 */
        union U5 **l_13261 = &g_9920;
        uint64_t l_13262 = 0x26E21E4A338CD4D2LL;
        int32_t l_13265 = 0L;
        (*g_6483) = l_13261;
        (****g_11089) ^= l_13262;
        l_13265 |= (safe_lshift_func_uint16_t_u_s(l_13010, 14));
    }
    else
    { /* block id: 5683 */
        int32_t l_13283[1];
        const uint32_t l_13285[4] = {0x07CA1EEAL,0x07CA1EEAL,0x07CA1EEAL,0x07CA1EEAL};
        uint8_t l_13308 = 255UL;
        union U3 **l_13360 = &l_13052;
        union U3 ***l_13359 = &l_13360;
        union U2 ****l_13365[2][3];
        int16_t ** const **l_13383 = (void*)0;
        uint64_t ****l_13384 = &g_3682;
        uint32_t *****l_13388 = &g_11807[2][0];
        int32_t l_13399[3];
        int32_t l_13404 = 1L;
        int i, j;
        for (i = 0; i < 1; i++)
            l_13283[i] = 0x84E5E4ECL;
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 3; j++)
                l_13365[i][j] = &g_9882;
        }
        for (i = 0; i < 3; i++)
            l_13399[i] = 0x2B1BBC9AL;
        if (((*g_10755) , (safe_div_func_uint8_t_u_u((l_13284 &= (((safe_div_func_int8_t_s_s(((*g_28) ^= (((*g_656) = ((l_13270 >= l_13044[0]) < ((safe_lshift_func_int8_t_s_s(l_13044[2], 1)) >= ((safe_unary_minus_func_uint64_t_u((safe_add_func_uint8_t_u_u(((g_13276 , ((*g_5411) = l_12990[0])) & ((safe_mod_func_int8_t_s_s((0xEB4927E6ACE40BE7LL ^ 0x1D7E5358B22EF1D0LL), ((safe_mod_func_int8_t_s_s((safe_mod_func_int16_t_s_s((((*g_1541) && (*g_6119)) <= l_13283[0]), 65535UL)), l_13283[0])) , l_13270))) , l_12985)), 0L)))) , l_13283[0])))) <= 0x84L)), (-4L))) ^ l_13283[0]) & l_13270)), l_13285[2]))))
        { /* block id: 5688 */
            const int32_t l_13296[4] = {0x4AA407DFL,0x4AA407DFL,0x4AA407DFL,0x4AA407DFL};
            int8_t l_13324 = 0x92L;
            uint16_t ***l_13346 = (void*)0;
            int32_t *l_13362 = &g_11;
            uint8_t l_13382 = 0x34L;
            int i;
            (*****g_2717) &= l_12985;
            if (((void*)0 != l_13286))
            { /* block id: 5690 */
                (*g_10974) ^= l_21;
            }
            else
            { /* block id: 5692 */
                uint16_t l_13297 = 1UL;
                uint32_t l_13309 = 4294967289UL;
                union U5 ***l_13319 = &g_6484;
                int32_t l_13347[1];
                union U2 ****l_13366 = &g_9882;
                int8_t *****l_13371 = (void*)0;
                int16_t *l_13372 = &g_5422;
                uint16_t l_13377 = 65535UL;
                int i;
                for (i = 0; i < 1; i++)
                    l_13347[i] = (-5L);
                for (g_3302 = 20; (g_3302 == 24); g_3302 = safe_add_func_int16_t_s_s(g_3302, 8))
                { /* block id: 5695 */
                    int32_t l_13307 = 0x79E71F67L;
                    (**g_1207) = (~(safe_sub_func_int64_t_s_s(((((safe_mod_func_int32_t_s_s((safe_rshift_func_int8_t_s_s(l_13296[2], l_13297)), 0x4D759D42L)) == (((((g_13298[4][3] , (safe_lshift_func_int16_t_s_s(0xA1C9L, 6))) || l_13285[2]) > (((**g_714) = l_13297) , (((safe_mod_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u((safe_add_func_int32_t_s_s(l_13296[2], (l_13284 = l_13307))), 0x71L)), l_13010)) , 1L) >= (**g_12504)))) != (*g_1678)) || l_13308)) && (-1L)) <= l_13297), l_13296[0])));
                }
                if (g_255)
                    goto lbl_13367;
                l_13309 = 0xEA826C4BL;
lbl_13367:
                if (l_12985)
                { /* block id: 5701 */
                    uint8_t l_13311[7][4];
                    int i, j;
                    for (i = 0; i < 7; i++)
                    {
                        for (j = 0; j < 4; j++)
                            l_13311[i][j] = 247UL;
                    }
                    for (g_857 = 0; (g_857 <= 7); g_857 += 1)
                    { /* block id: 5704 */
                        int64_t ***** const l_13310 = &g_12176;
                        int32_t l_13320 = (-9L);
                        int32_t l_13321 = (-1L);
                        uint16_t ***l_13340 = &g_714;
                        uint16_t ****l_13341 = &l_13340;
                        uint16_t ***l_13343 = &g_714;
                        uint16_t ****l_13342 = &l_13343;
                        uint16_t ***l_13345 = (void*)0;
                        uint16_t ****l_13344 = &l_13345;
                        uint32_t l_13355 = 0x1B30A20BL;
                        uint16_t l_13358 = 0x833CL;
                        int i;
                        (*g_10974) &= ((((void*)0 == l_13310) < ((l_13321 ^= (l_13311[4][0] & (l_13296[0] , ((g_13312 , (safe_mul_func_int8_t_s_s(l_13296[3], (((safe_add_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_u(l_13308, 2)), ((((void*)0 != l_13319) != 4294967286UL) & 1UL))) | l_13308) == l_13320)))) , 0xCBE9L)))) , l_12990[0])) <= l_13270);
                        (*g_10974) ^= ((***g_11090) | (((safe_rshift_func_int8_t_s_u(l_13324, 4)) && (l_13347[0] = ((safe_div_func_int32_t_s_s((safe_mod_func_uint16_t_u_u((safe_add_func_int8_t_s_s((l_13320 , (l_13283[0] | (((&g_12176 != (void*)0) , (~(safe_lshift_func_int8_t_s_s((+(((((~(((safe_mod_func_int8_t_s_s((safe_add_func_int64_t_s_s((((*l_13344) = ((*l_13342) = ((*l_13341) = l_13340))) == l_13346), (0x03254E4ACC540CB9LL ^ l_13283[0]))), 0x0CL)) || 0x5AF160666FFD5F2BLL) > l_13044[0])) , l_13010) , (**g_9695)) , l_13321) & (*g_715))), 7)))) > l_13321))), 0x6BL)), 0x732CL)), 0xBCF1A759L)) , l_13296[2]))) || l_13308));
                        (*****g_2717) = ((safe_mul_func_int8_t_s_s(((0x4D21BF46B0A97FCBLL > l_13321) <= l_13350[0]), 0x3FL)) || (safe_mul_func_int16_t_s_s((safe_add_func_uint32_t_u_u((g_340[g_857] , l_13283[0]), l_13355)), ((-1L) | (safe_add_func_int64_t_s_s(l_13358, 0xE6D79AA9C8AF651ELL))))));
                    }
                    (****g_2718) |= (l_13359 != (g_13361 , &l_13258));
                }
                else
                { /* block id: 5715 */
                    (*g_7348) &= (***g_11090);
                    l_13362 = l_13362;
                    (****g_11089) &= (!(7UL == (((g_13364 , l_13365[1][0]) != l_13366) , 0xDFL)));
                    return (*g_10755);
                }
                (*g_10974) ^= (((((safe_mul_func_int16_t_s_s(((*l_13372) = ((g_13370 , &g_3463) != l_13371)), (safe_sub_func_uint16_t_u_u((safe_sub_func_uint64_t_u_u(l_13377, ((~(l_12985 = ((safe_add_func_int64_t_s_s(l_13381, (((((((*g_28) < l_13382) || ((((l_13283[0] = (l_13383 == (void*)0)) >= (*g_1541)) <= 0xFFL) & 0x27L)) , l_13384) == (void*)0) < l_13347[0]) || l_13347[0]))) & (*l_13362)))) >= l_13297))), l_13347[0])))) >= l_13044[2]) != 4294967289UL) < (-1L)) < l_13308);
            }
        }
        else
        { /* block id: 5727 */
            int8_t l_13387[4][10] = {{0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L},{0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L},{0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L},{0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L}};
            uint32_t l_13391 = 0x2C9FF421L;
            uint32_t *l_13394 = &g_10366;
            uint32_t *l_13395[7][10] = {{&g_7618[1],&g_7618[6],&g_7618[6],&g_7618[1],&g_7618[6],&g_7618[6],&g_7618[1],&g_7618[6],&g_7618[6],&g_7618[1]},{&g_7618[6],&g_7618[1],&g_7618[6],&g_7618[6],&g_7618[1],&g_7618[6],&g_7618[6],&g_7618[1],&g_7618[6],&g_7618[6]},{&g_7618[1],&g_7618[1],&g_4151,&g_7618[1],&g_7618[1],&g_4151,&g_7618[1],&g_7618[6],&g_7618[1],&g_7618[6]},{&g_7618[6],&g_4151,&g_4151,&g_7618[6],&g_4151,&g_4151,&g_7618[6],&g_4151,&g_4151,&g_7618[6]},{&g_4151,&g_7618[6],&g_4151,&g_4151,&g_7618[6],&g_4151,&g_4151,&g_7618[6],&g_4151,&g_4151},{&g_7618[6],&g_7618[6],&g_7618[1],&g_7618[6],&g_7618[6],&g_7618[1],&g_7618[6],&g_7618[6],&g_7618[1],&g_7618[6]},{&g_7618[6],&g_4151,&g_4151,&g_7618[6],&g_4151,&g_4151,&g_7618[6],&g_4151,&g_4151,&g_7618[6]}};
            uint8_t l_13398 = 0xD9L;
            volatile int32_t ***l_13405 = &g_3346[0];
            int i, j;
            (*g_10974) = (safe_div_func_int64_t_s_s(((((l_13387[1][2] , l_13388) != (g_11806 = &g_11807[2][0])) || (safe_sub_func_uint64_t_u_u(l_13381, l_13391))) ^ ((l_13283[0] = ((*l_13394) |= ((**g_929)++))) ^ ((0xBBL | (safe_sub_func_uint64_t_u_u((l_13399[1] |= l_13398), ((--(****g_5408)) != (safe_add_func_int8_t_s_s((l_13404 = (l_13285[2] ^ (l_13387[3][3] ^ l_13398))), l_12990[0])))))) ^ l_13285[2]))), 1L));
            (*l_13405) = (*g_3345);
            (****g_11089) = l_13391;
        }
        (**g_11090) = ((safe_add_func_uint8_t_u_u(l_13065, ((*****l_13256) = (safe_lshift_func_uint16_t_u_u(l_13404, l_13404))))) , func_139(((void*)0 != &g_7503)));
    }
    for (g_8090.f3 = 0; (g_8090.f3 > 8); g_8090.f3 = safe_add_func_int16_t_s_s(g_8090.f3, 7))
    { /* block id: 5744 */
        (*l_13258) = (l_13052 = l_13052);
    }
    return g_13412;
}


/* ------------------------------------------ */
/* 
 * reads : g_12974 g_714 g_715 g_5411 g_29 g_3870 g_1621 g_10974 g_255
 * writes: g_4801 g_12971 g_466 g_255
 */
static int8_t * func_12(uint8_t  p_13, int32_t  p_14, int8_t * p_15)
{ /* block id: 5551 */
    uint8_t l_12960 = 0x56L;
    int32_t l_12983 = 0xCA464039L;
    int32_t l_12984[1][6] = {{0x08684442L,0xD9DA2DA6L,0x08684442L,0x08684442L,0xD9DA2DA6L,0x08684442L}};
    int i, j;
    l_12960--;
    (*g_10974) ^= (safe_mul_func_int32_t_s_s(l_12960, ((safe_rshift_func_int8_t_s_u((l_12984[0][1] = (safe_mod_func_int64_t_s_s((safe_sub_func_int8_t_s_s((((((g_12971[2][3][4] = (g_4801 = &g_4296)) == ((safe_lshift_func_int8_t_s_u(l_12960, ((18446744073709551613UL == (l_12983 = ((g_12974 , (((safe_rshift_func_uint16_t_u_u(1UL, ((**g_714) = p_13))) , (((*g_5411) || ((safe_mul_func_uint16_t_u_u(((safe_div_func_int8_t_s_s(((safe_rshift_func_uint8_t_u_s(((void*)0 != &g_1406), (*p_15))) || l_12960), l_12960)) >= l_12960), l_12960)) > p_14)) & p_13)) != (*p_15))) | l_12960))) ^ p_14))) , &g_4296)) & l_12960) || 0UL) ^ (-9L)), 2UL)), p_13))), l_12960)) > p_13)));
    return p_15;
}


/* ------------------------------------------ */
/* 
 * reads : g_29 g_7 g_8 g_653 g_499 g_1207 g_929 g_930 g_715 g_466 g_5407 g_5408 g_5409 g_5410 g_5411 g_3870 g_1541 g_998 g_2717 g_2718 g_2719 g_10974 g_11360 g_11090 g_11089 g_1674 g_1675 g_1540 g_4493 g_6119 g_845 g_4423 g_28 g_9377 g_4422 g_10000 g_10001 g_4139 g_5749 g_1419 g_6483 g_431 g_8491 g_12504 g_656 g_657 g_12831 g_3142.f1 g_4087 g_4088 g_604 g_9881 g_9882 g_446 g_66 g_8235 g_5490 g_6407 g_3477 g_714 g_12502 g_12503 g_10729.f3 g_8095.f3 g_10585.f3 g_7828.f0 g_12383 g_2355
 * writes: g_38 g_499 g_4422 g_446 g_66 g_10729.f3 g_3870 g_8095.f3 g_10585.f3 g_255 g_466 g_431 g_653 g_78 g_951 g_4882 g_656 g_7828.f0 g_6484 g_12383 g_8092.f3 g_7095 g_8491 g_12831 g_845 g_3142.f1 g_29 g_3477 g_2355 g_10753 g_5411
 */
static uint8_t  func_22(int64_t  p_23, int8_t * p_24, uint64_t  p_25, int8_t  p_26)
{ /* block id: 13 */
    int8_t *l_34[7][7][5] = {{{&g_29,&g_29,(void*)0,(void*)0,(void*)0},{&g_29,&g_29,&g_29,&g_29,&g_29},{&g_29,&g_29,(void*)0,&g_29,(void*)0},{&g_29,&g_29,&g_29,(void*)0,&g_29},{(void*)0,&g_29,(void*)0,&g_29,(void*)0},{(void*)0,&g_29,&g_29,(void*)0,&g_29},{(void*)0,&g_29,&g_29,&g_29,&g_29}},{{&g_29,&g_29,&g_29,&g_29,(void*)0},{&g_29,&g_29,(void*)0,&g_29,&g_29},{&g_29,&g_29,&g_29,(void*)0,&g_29},{&g_29,&g_29,&g_29,&g_29,&g_29},{&g_29,&g_29,&g_29,(void*)0,&g_29},{&g_29,&g_29,&g_29,&g_29,(void*)0},{&g_29,&g_29,&g_29,&g_29,&g_29}},{{&g_29,&g_29,&g_29,(void*)0,&g_29},{(void*)0,&g_29,&g_29,&g_29,&g_29},{(void*)0,&g_29,&g_29,(void*)0,&g_29},{(void*)0,(void*)0,&g_29,(void*)0,&g_29},{&g_29,(void*)0,(void*)0,&g_29,&g_29},{&g_29,&g_29,&g_29,&g_29,(void*)0},{&g_29,(void*)0,&g_29,(void*)0,&g_29}},{{&g_29,(void*)0,&g_29,(void*)0,&g_29},{&g_29,&g_29,(void*)0,(void*)0,&g_29},{&g_29,&g_29,&g_29,(void*)0,&g_29},{&g_29,&g_29,(void*)0,&g_29,(void*)0},{&g_29,&g_29,&g_29,&g_29,&g_29},{&g_29,&g_29,(void*)0,(void*)0,&g_29},{&g_29,&g_29,&g_29,(void*)0,(void*)0}},{{&g_29,&g_29,&g_29,&g_29,(void*)0},{&g_29,&g_29,&g_29,(void*)0,(void*)0},{&g_29,&g_29,&g_29,&g_29,&g_29},{&g_29,&g_29,&g_29,&g_29,(void*)0},{&g_29,&g_29,(void*)0,(void*)0,(void*)0},{(void*)0,&g_29,&g_29,(void*)0,&g_29},{&g_29,&g_29,&g_29,&g_29,&g_29}},{{&g_29,&g_29,(void*)0,&g_29,&g_29},{&g_29,&g_29,&g_29,(void*)0,&g_29},{(void*)0,&g_29,&g_29,&g_29,&g_29},{&g_29,&g_29,&g_29,&g_29,&g_29},{&g_29,&g_29,&g_29,(void*)0,(void*)0},{&g_29,(void*)0,&g_29,(void*)0,&g_29},{&g_29,&g_29,(void*)0,&g_29,(void*)0}},{{(void*)0,(void*)0,&g_29,&g_29,&g_29},{&g_29,&g_29,(void*)0,(void*)0,&g_29},{&g_29,&g_29,&g_29,&g_29,&g_29},{&g_29,&g_29,&g_29,&g_29,&g_29},{(void*)0,(void*)0,&g_29,&g_29,&g_29},{&g_29,&g_29,&g_29,&g_29,&g_29},{&g_29,(void*)0,&g_29,&g_29,(void*)0}}};
    int64_t *****l_12708[6];
    int32_t l_12711 = 0x9F42F614L;
    uint16_t ***l_12723 = &g_714;
    const uint32_t *l_12741 = &g_8037.f1;
    const int16_t *l_12794[4] = {&g_10902,&g_10902,&g_10902,&g_10902};
    int32_t l_12803 = 0x443D8F79L;
    int32_t l_12804 = 0L;
    int32_t l_12805 = 0xE2430590L;
    int32_t l_12806 = 0x323AE330L;
    int32_t l_12808 = 8L;
    int32_t l_12810 = 0x1783D17DL;
    uint32_t l_12811[1];
    struct S1 *l_12818 = (void*)0;
    uint32_t l_12848 = 0x70E0DFA2L;
    uint64_t * const l_12931 = &g_998;
    int i, j, k;
    for (i = 0; i < 6; i++)
        l_12708[i] = &g_12176;
    for (i = 0; i < 1; i++)
        l_12811[i] = 0xC12578B0L;
    if (g_29)
    { /* block id: 14 */
        int8_t ***l_12687[6] = {&g_4423,&g_4423,&g_4423,&g_4423,&g_4423,&g_4423};
        int32_t l_12710 = 0xA8A45B09L;
        struct S1 **l_12713 = &g_7095;
        uint32_t *****l_12718 = &g_12076;
        uint16_t ***l_12724[10][1];
        int32_t l_12737[9];
        union U2 *****l_12791 = &g_9881;
        uint64_t ****l_12883 = &g_3682;
        const union U4 **l_12887 = &g_10755;
        int i, j;
        for (i = 0; i < 10; i++)
        {
            for (j = 0; j < 1; j++)
                l_12724[i][j] = (void*)0;
        }
        for (i = 0; i < 9; i++)
            l_12737[i] = 0xF9DF8728L;
lbl_12817:
        if (func_30(p_23, l_34[0][4][3], &g_29))
        { /* block id: 5410 */
lbl_12956:
            (**g_1207) = (*g_653);
        }
        else
        { /* block id: 5412 */
            const int64_t *****l_12709 = (void*)0;
            uint32_t l_12712 = 0xCDEAAFA5L;
            uint8_t l_12714 = 0x19L;
            if ((((g_4422 = l_12687[0]) == (void*)0) , (safe_add_func_uint32_t_u_u(((**g_929) = 0xF301D4DBL), (0xA42CD64B79A8C267LL | ((safe_lshift_func_int8_t_s_u((((((((safe_div_func_int8_t_s_s((((l_12711 &= (safe_sub_func_int16_t_s_s(((safe_div_func_uint16_t_u_u((safe_mul_func_int16_t_s_s((safe_sub_func_uint16_t_u_u((safe_sub_func_int16_t_s_s(((safe_lshift_func_uint8_t_u_s(((safe_lshift_func_uint16_t_u_u(((l_12708[1] = &g_12176) == l_12709), ((0xDFE5DE08L <= 0x6BBC63FDL) < p_26))) >= (*p_24)), (*p_24))) , l_12710), (*g_715))), p_23)), 65535UL)), p_25)) | 0xCBL), 0xD33FL))) ^ l_12710) != l_12712), 0xD8L)) , l_12713) != (void*)0) && l_12714) != p_26) , p_25) <= 0xD7EBA0EA5187B803LL), (*****g_5407))) && (*g_1541)))))))
            { /* block id: 5417 */
                uint32_t l_12715 = 4UL;
                ++l_12715;
            }
            else
            { /* block id: 5419 */
                for (g_10729.f3 = 5; (g_10729.f3 >= 0); g_10729.f3 -= 1)
                { /* block id: 5422 */
                    return (*****g_5407);
                }
            }
            l_12718 = l_12718;
        }
        if (((**g_1207) |= ((((safe_add_func_int32_t_s_s((safe_add_func_int32_t_s_s(((l_12724[7][0] = l_12723) != (void*)0), (safe_mod_func_uint32_t_u_u(l_12710, (safe_div_func_uint16_t_u_u(((safe_div_func_uint8_t_u_u(((*****g_5407) &= (safe_add_func_uint32_t_u_u((safe_sub_func_uint64_t_u_u(l_12710, ((safe_lshift_func_int16_t_s_u((l_12737[2] = 8L), (safe_sub_func_int16_t_s_s(((!l_12711) > (0x9BL >= (l_12741 != (void*)0))), l_12711)))) < p_26))), l_12710))), p_25)) , p_26), 0xC78DL)))))), l_12710)) == 0x485AL) ^ l_12710) | p_25)))
        { /* block id: 5432 */
            int32_t l_12767 = 0xED0D8146L;
            int32_t *l_12770 = &g_7[0][2][0];
            uint8_t *l_12775 = &g_1351;
            uint32_t l_12795 = 0UL;
            int32_t l_12801 = 0xB703DBFEL;
            int32_t l_12802 = 0x56E12069L;
            int32_t l_12807 = 0x0FF6B5A0L;
            int32_t l_12809[2][9] = {{0xF40CF786L,0xF40CF786L,0xF40CF786L,0xF40CF786L,0xF40CF786L,0xF40CF786L,0xF40CF786L,0xF40CF786L,0xF40CF786L},{0x56A27D6CL,0x56A27D6CL,0x56A27D6CL,0x56A27D6CL,0x56A27D6CL,0x56A27D6CL,0x56A27D6CL,0x56A27D6CL,0x56A27D6CL}};
            uint64_t ****l_12884 = &g_3682;
            uint8_t l_12910 = 253UL;
            int i, j;
            for (g_8095.f3 = 0; (g_8095.f3 != (-16)); g_8095.f3 = safe_sub_func_int8_t_s_s(g_8095.f3, 4))
            { /* block id: 5435 */
                uint8_t ****l_12746 = &g_10001[1];
                int32_t l_12758[10][2] = {{0x1922BDD8L,0x509CDB8CL},{1L,0x5C43F793L},{0x5C43F793L,1L},{0x509CDB8CL,0x1922BDD8L},{0x509CDB8CL,1L},{0x5C43F793L,0x5C43F793L},{1L,0x509CDB8CL},{0x1922BDD8L,0x509CDB8CL},{1L,0x5C43F793L},{0x5C43F793L,1L}};
                const uint32_t *l_12793 = &g_1550;
                int32_t *l_12800[1];
                int i, j;
                for (i = 0; i < 1; i++)
                    l_12800[i] = &g_3307;
                if ((p_25 && (safe_add_func_int16_t_s_s((-1L), ((void*)0 != l_12746)))))
                { /* block id: 5436 */
                    uint64_t l_12747 = 1UL;
                    l_12747--;
                    (*****g_2717) ^= 7L;
                    for (g_10585.f3 = 0; (g_10585.f3 <= 14); g_10585.f3 = safe_add_func_uint8_t_u_u(g_10585.f3, 4))
                    { /* block id: 5441 */
                        (*g_10974) = ((****g_2718) = (-8L));
                    }
                    if (((*g_11360) = (+p_23)))
                    { /* block id: 5446 */
                        int64_t **l_12757 = &g_538[2];
                        uint32_t l_12765 = 0x5EB60DEDL;
                        int32_t l_12766 = 0x7AB7ACCCL;
                        (***g_11090) = (((safe_mul_func_uint16_t_u_u((p_25 > ((safe_add_func_uint8_t_u_u(((l_12737[1] ^ ((((((*p_24) & ((void*)0 != l_12757)) <= (p_25 , (l_12711 = ((l_12758[5][1] || (((safe_div_func_uint32_t_u_u(p_25, (((safe_mul_func_uint16_t_u_u(((*g_715) = ((safe_lshift_func_uint16_t_u_s(p_25, l_12765)) >= 0x4E26L)), l_12758[5][1])) != l_12737[4]) || 255UL))) & p_23) || p_26)) && 0UL)))) , p_25) < l_12747) && l_12766)) && 0xD29CC282814DE116LL), l_12767)) , 0xFD81D559A1476BBCLL)), p_25)) == (-7L)) , p_23);
                    }
                    else
                    { /* block id: 5450 */
                        return p_26;
                    }
                }
                else
                { /* block id: 5453 */
                    int16_t *l_12776 = &g_4493;
                    int32_t l_12790 = 0x0AF4965EL;
                    union U2 *****l_12792 = &g_9881;
                    for (g_431 = 1; (g_431 == (-9)); g_431--)
                    { /* block id: 5456 */
                        (***g_11089) = l_12770;
                        (*g_10974) = (safe_div_func_int8_t_s_s(((safe_div_func_uint16_t_u_u(p_26, (((l_12775 == ((***g_10000) = func_87(l_12776, &l_12711))) > 65533UL) , p_25))) < l_12790), l_12737[6]));
                        return p_23;
                    }
                    l_12795--;
                    for (g_7828.f0 = 0; (g_7828.f0 <= 1); g_7828.f0 += 1)
                    { /* block id: 5467 */
                        union U5 **l_12799 = &g_1070;
                        int i, j;
                        (***g_11090) = (((p_26 != ((&p_23 == (void*)0) ^ p_23)) , (~(*g_5749))) >= (((*g_6483) = ((l_12741 != l_12741) , l_12799)) == (p_23 , (void*)0)));
                    }
                    (****g_11089) ^= l_12737[7];
                }
                l_12811[0]--;
            }
            if ((safe_rshift_func_int16_t_s_u((safe_unary_minus_func_uint32_t_u(p_25)), 2)))
            { /* block id: 5475 */
                int16_t l_12834 = 0x03EEL;
                int32_t l_12835 = (-2L);
                int32_t l_12841 = 1L;
                int32_t l_12842 = 0xB1DBE8CAL;
                int32_t l_12845 = 5L;
                int32_t l_12846[4];
                int16_t l_12847 = 0x9755L;
                int32_t l_12872 = 0x77CBA4AAL;
                uint64_t ** const *l_12906[9][2] = {{&g_1540,(void*)0},{&g_1540,&g_1540},{(void*)0,&g_1540},{&g_1540,(void*)0},{&g_1540,&g_1540},{&g_1540,(void*)0},{&g_1540,&g_1540},{(void*)0,&g_1540},{&g_1540,(void*)0}};
                uint64_t ** const **l_12905 = &l_12906[5][1];
                uint64_t ** const ***l_12904 = &l_12905;
                int32_t *l_12907 = (void*)0;
                int32_t *l_12908 = (void*)0;
                int32_t *l_12909 = &g_3307;
                int i, j;
                for (i = 0; i < 4; i++)
                    l_12846[i] = 0xB8A5FFDBL;
                for (g_12383 = 4; (g_12383 >= 1); g_12383 -= 1)
                { /* block id: 5478 */
                    if ((*l_12770))
                        break;
                    if (g_431)
                        goto lbl_12817;
                    for (g_8092.f3 = 1; (g_8092.f3 <= 4); g_8092.f3 += 1)
                    { /* block id: 5483 */
                        struct S1 *l_12819 = &g_12820;
                        (*l_12713) = (l_12819 = l_12818);
                    }
                }
                for (g_8491 = 0; (g_8491 != 26); g_8491++)
                { /* block id: 5490 */
                    int16_t l_12830 = 8L;
                    int32_t l_12843[10] = {0xC2A1944EL,0xC2A1944EL,0xC2A1944EL,0xC2A1944EL,0xC2A1944EL,0xC2A1944EL,0xC2A1944EL,0xC2A1944EL,0xC2A1944EL,0xC2A1944EL};
                    int32_t l_12844 = 4L;
                    int64_t l_12851 = 0xB6297B391DACCAB0LL;
                    int32_t l_12852 = 0xC6EE0B44L;
                    int32_t l_12855 = 0xD19624A3L;
                    int i;
                    if (p_23)
                    { /* block id: 5491 */
                        int8_t **l_12827 = &l_34[5][4][3];
                        int32_t *l_12836 = &l_12809[1][6];
                        int32_t *l_12837 = &l_12809[0][0];
                        int32_t *l_12838 = (void*)0;
                        int32_t *l_12839 = &l_12809[0][0];
                        int32_t *l_12840[2];
                        int64_t l_12853 = 1L;
                        int64_t l_12854 = 0xBCC5870FDE31ADEDLL;
                        uint8_t l_12856[10] = {0x4EL,0x4EL,0x4EL,0x4EL,0x4EL,0x4EL,0x4EL,0x4EL,0x4EL,0x4EL};
                        int i;
                        for (i = 0; i < 2; i++)
                            l_12840[i] = (void*)0;
                        (*g_653) |= (safe_lshift_func_uint8_t_u_u(((**g_12504) |= (safe_rshift_func_uint16_t_u_u((l_12806 , ((((void*)0 == l_12827) >= (((safe_add_func_int8_t_s_s(((p_24 != p_24) , (**g_4423)), l_12830)) == ((**g_1540) >= (0xBACFBB19L & 0xD4FB0656L))) ^ (*g_715))) ^ p_26)), p_26))), (****g_10000)));
                        g_12831--;
                        l_12848++;
                        l_12856[6]--;
                    }
                    else
                    { /* block id: 5497 */
                        int32_t l_12865 = 1L;
                        (*g_11360) = p_26;
                        (****g_2718) ^= (safe_add_func_uint64_t_u_u((safe_lshift_func_int8_t_s_s(0L, 0)), (safe_lshift_func_int16_t_s_u((((l_12737[8] ^ ((l_12806 &= ((*g_6119) = (l_12865 == ((p_25 , ((((((safe_mod_func_int8_t_s_s((p_26 != 0x90L), 1UL)) || (safe_mod_func_int32_t_s_s(l_12710, (safe_mul_func_int16_t_s_s((p_26 & l_12710), 0xD821L))))) <= l_12865) && (****g_5408)) || 0x7131L) >= p_23)) , 18446744073709551610UL)))) & l_12865)) & l_12872) , l_12855), p_26))));
                    }
                    if (p_25)
                        continue;
                }
                for (g_3142.f1 = 0; (g_3142.f1 <= 40); g_3142.f1++)
                { /* block id: 5507 */
                    int32_t l_12886[7];
                    int i;
                    for (i = 0; i < 7; i++)
                        l_12886[i] = 0xBFC7C857L;
                    if (g_8095.f3)
                        goto lbl_12817;
                    (***g_11090) = (l_12805 || (safe_rshift_func_uint16_t_u_u((safe_add_func_int16_t_s_s((safe_div_func_int32_t_s_s((safe_sub_func_uint16_t_u_u((((void*)0 == &g_4422) > (((**g_4087) , l_12883) == l_12884)), ((void*)0 == &g_4904[2][2]))), (safe_unary_minus_func_uint8_t_u((*****g_5407))))), l_12710)), l_12886[2])));
                    (*g_653) = (((l_12887 == (void*)0) , (safe_mod_func_uint8_t_u_u(((0xB49EC57B194120C7LL != ((*l_12770) , (safe_rshift_func_uint8_t_u_u(p_25, p_23)))) , 0x9DL), (*l_12770)))) || ((+((*g_6119) = ((void*)0 == &g_5128))) && p_23));
                    l_12806 = ((*g_653) |= ((((safe_mul_func_uint8_t_u_u((*l_12770), (safe_rshift_func_int8_t_s_u(((safe_mod_func_int32_t_s_s(((*p_24) && ((**g_4423) = ((!p_26) == ((safe_lshift_func_int8_t_s_s((safe_div_func_int8_t_s_s((l_12904 != &l_12884), ((((void*)0 == (**l_12791)) ^ 4UL) || 0L))), 4)) ^ (*l_12770))))), (**g_929))) > l_12803), 6)))) != p_25) > p_23) ^ (*g_8235)));
                }
                l_12910++;
            }
            else
            { /* block id: 5517 */
                uint32_t l_12918 = 0xBDBFB532L;
                const union U4 ****l_12933[3];
                const uint8_t *l_12955 = (void*)0;
                const uint8_t **l_12954 = &l_12955;
                const uint8_t *** const l_12953 = &l_12954;
                int i;
                for (i = 0; i < 3; i++)
                    l_12933[i] = &g_10753;
                for (l_12806 = 0; (l_12806 <= 8); l_12806++)
                { /* block id: 5520 */
                    int32_t l_12919[9][2] = {{0x929F1907L,1L},{0x929F1907L,1L},{0x929F1907L,1L},{0x929F1907L,1L},{0x929F1907L,1L},{0x929F1907L,1L},{0x929F1907L,1L},{0x929F1907L,1L},{0x929F1907L,1L}};
                    int32_t ****l_12920 = &g_4095;
                    int32_t l_12932 = 0x8A70E7F1L;
                    int i, j;
                    (*g_10974) = (safe_unary_minus_func_uint8_t_u((((-1L) ^ p_25) && (safe_add_func_int64_t_s_s((l_12919[7][1] = l_12918), ((((((***g_11090) = (l_12920 != ((*g_6407) = (*g_6407)))) != (safe_div_func_int16_t_s_s((((*g_4423) != &p_26) == (safe_rshift_func_uint16_t_u_s((l_12932 = ((((safe_mod_func_int8_t_s_s((((((***l_12723) = (safe_mod_func_uint8_t_u_u(p_25, (safe_div_func_int8_t_s_s((((((p_23 && 0x360F5DC6L) > (*p_24)) ^ 0x07D30BC29CC8E8D0LL) , (void*)0) == l_12931), 0x62L))))) && l_12808) == 0x7AL) , 0xB0L), (*p_24))) , 0xA246A247L) , 0x880FEEE5BA597F95LL) , (*l_12770))), 11))), p_23))) > p_26) , l_12933[2]) == &g_6523))))));
                    for (g_2355 = 0; (g_2355 <= 1); g_2355 += 1)
                    { /* block id: 5529 */
                        int32_t l_12943[9][9];
                        int i, j;
                        for (i = 0; i < 9; i++)
                        {
                            for (j = 0; j < 9; j++)
                                l_12943[i][j] = 0L;
                        }
                        (*g_10974) = (((safe_lshift_func_uint16_t_u_s((**g_714), l_12918)) | 0x315D0EE7L) > ((l_12803 < ((((safe_div_func_uint32_t_u_u(((safe_div_func_int8_t_s_s((-2L), (+((void*)0 != (***g_2718))))) <= l_12943[0][6]), ((safe_sub_func_int32_t_s_s(((*****g_2717) = 0L), 5UL)) | l_12919[7][1]))) | p_23) >= (*l_12770)) != 0UL)) , (****g_12502)));
                        (****g_2718) = ((g_10753 = &g_10754) != &g_4904[4][3]);
                    }
                }
                (*****g_2717) = (0xCF74167AL != (safe_mod_func_int16_t_s_s((+(l_12737[7] |= (((((((**g_714) |= (((((l_12806 = 0L) , 0L) < (*l_12770)) <= (p_26 | (((((safe_mul_func_int8_t_s_s((((((****g_5407) = p_24) != l_34[0][4][3]) < (-1L)) || (safe_lshift_func_int16_t_s_s((((-9L) == l_12918) | 0x14A8L), 4))), 255UL)) , (****g_5408)) , (*l_12770)) || 0x7FECC2EAA25AEC27LL) | l_12918))) & l_12810)) <= p_23) & l_12918) == 0xE3ABL) , l_12953) != &l_12954))), p_26)));
            }
        }
        else
        { /* block id: 5542 */
            if (g_66)
                goto lbl_12956;
            return (****g_12502);
        }
    }
    else
    { /* block id: 5546 */
        return (***g_12503);
    }
    return (****g_5408);
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_8
 * writes: g_38
 */
static const int32_t  func_30(uint64_t  p_31, int8_t * p_32, const int8_t * p_33)
{ /* block id: 15 */
    uint64_t l_73 = 1UL;
    int32_t *l_11158 = &g_8;
    int8_t *l_11226[2];
    int8_t *l_12198[7][1][1] = {{{&g_2886}},{{&g_2886}},{{&g_2886}},{{&g_2886}},{{&g_2886}},{{&g_2886}},{{&g_2886}}};
    int32_t l_12612 = 0x6E62507DL;
    int32_t l_12616 = 4L;
    int32_t l_12620 = 0xA4019C9EL;
    int32_t l_12622 = (-7L);
    int32_t l_12624 = 0x1C356833L;
    int32_t l_12625 = 0x80B18885L;
    int32_t l_12626 = 0x9A23BB4DL;
    int32_t l_12628[9] = {0xD09F462CL,0xD09F462CL,0xD09F462CL,0xD09F462CL,0xD09F462CL,0xD09F462CL,0xD09F462CL,0xD09F462CL,0xD09F462CL};
    int32_t l_12630 = 0x0729D914L;
    int32_t l_12636 = (-10L);
    uint64_t l_12637 = 1UL;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_11226[i] = &g_1621[0];
    for (p_31 = (-27); (p_31 > 19); p_31 = safe_add_func_int64_t_s_s(p_31, 4))
    { /* block id: 18 */
        int32_t *l_37 = &g_38;
        const int8_t *l_59 = (void*)0;
        uint32_t *l_65 = &g_66;
        int16_t *l_76 = (void*)0;
        int16_t *l_77[1];
        int8_t l_79 = (-10L);
        int32_t l_12610 = 0xE2C55E10L;
        const uint8_t l_12611 = 4UL;
        int32_t l_12617 = 0x28125726L;
        int32_t l_12618 = 0x057FA006L;
        int32_t l_12619 = (-10L);
        int32_t l_12621 = 0x1234E6ECL;
        int32_t l_12623 = (-2L);
        int32_t l_12627 = (-1L);
        int32_t l_12629 = 4L;
        int32_t l_12631 = 0xE4CFFA23L;
        int32_t l_12632 = 0x38B1DFE6L;
        int32_t l_12633 = 0x00AF7469L;
        int32_t l_12634 = 0x8AB4811EL;
        int32_t l_12635[5][8] = {{0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L},{0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L},{0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L},{0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L},{0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L,0xBAFBC961L}};
        int8_t l_12681 = 0x2FL;
        uint8_t l_12684[8][8][4] = {{{0UL,0x13L,0x31L,0xA4L},{0xFBL,0xE4L,0x2EL,253UL},{255UL,3UL,0x13L,3UL},{0xE4L,0xC1L,0x44L,0x13L},{2UL,246UL,8UL,0xEEL},{251UL,0x50L,0xFBL,0x76L},{251UL,0xE4L,8UL,0x31L},{2UL,0x76L,0x44L,0xA4L}},{{0xE4L,247UL,0x13L,0UL},{255UL,2UL,0x2EL,0xEEL},{0xFBL,0xC1L,0x31L,0x2EL},{0UL,8UL,8UL,0UL},{246UL,3UL,0xFDL,0x76L},{8UL,247UL,0UL,0x44L},{2UL,255UL,0xA4L,0x44L},{0xFBL,247UL,252UL,0x76L}},{{253UL,3UL,0x2EL,0UL},{1UL,8UL,0x44L,0x2EL},{3UL,0xC1L,0UL,0xEEL},{246UL,2UL,0xE4L,0UL},{251UL,247UL,251UL,0xA4L},{0UL,0x76L,0xA4L,0x31L},{1UL,0xE4L,0x13L,0x76L},{0x76L,0x50L,0x13L,0xEEL}},{{1UL,246UL,0xA4L,0x13L},{0UL,0xC1L,251UL,3UL},{251UL,3UL,0xE4L,253UL},{246UL,0xE4L,0UL,0xA4L},{3UL,0x13L,0x44L,0x44L},{1UL,1UL,0xFBL,249UL},{0x44L,246UL,0xFDL,251UL},{252UL,253UL,252UL,0xFDL}},{{8UL,253UL,0x13L,251UL},{253UL,246UL,0x74L,249UL},{0x76L,6UL,253UL,0x51L},{0UL,248UL,0x13L,252UL},{252UL,1UL,0xFBL,0x44L},{0xA4L,251UL,247UL,251UL},{1UL,255UL,0x51L,247UL},{8UL,0x76L,253UL,0xC1L}},{{0UL,246UL,252UL,0x31L},{0UL,1UL,253UL,0x13L},{8UL,0x31L,0x51L,252UL},{1UL,0xA2L,247UL,249UL},{0xA4L,8UL,0xFBL,0xC1L},{252UL,255UL,0x13L,0xFBL},{0UL,253UL,253UL,0UL},{0x76L,251UL,0x74L,0x31L}},{{253UL,0xA2L,0x13L,0x51L},{8UL,0xA4L,252UL,0x51L},{252UL,0xA2L,0xFDL,0x31L},{0x44L,251UL,0xFBL,0UL},{6UL,253UL,0x51L,0xFBL},{251UL,255UL,0x13L,0xC1L},{0x76L,8UL,1UL,249UL},{0UL,0xA2L,0UL,252UL}},{{0UL,0x31L,252UL,0x13L},{6UL,1UL,247UL,0x31L},{0x31L,246UL,247UL,0xC1L},{6UL,0x76L,252UL,247UL},{0UL,255UL,0UL,251UL},{0UL,251UL,1UL,0x44L},{0x76L,1UL,0x13L,252UL},{251UL,248UL,0x51L,0x51L}}};
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_77[i] = &g_78;
        (*l_37) = g_7[2][5][1];
    }
    return (*l_11158);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_39(int32_t  p_40, uint32_t  p_41)
{ /* block id: 5385 */
    int8_t l_12613 = 0xC1L;
    return l_12613;
}


/* ------------------------------------------ */
/* 
 * reads : g_714 g_715 g_466 g_5410 g_5411 g_3870 g_5408 g_5409 g_1675 g_1676 g_1677 g_1678 g_232 g_4423 g_28 g_29 g_4097 g_2886 g_11360 g_499 g_4882 g_1020 g_929 g_930 g_3643 g_446 g_66 g_4583 g_1674 g_7254 g_1847 g_8235 g_1541 g_998 g_6119 g_4422 g_10974 g_4294 g_7633 g_431 g_4139 g_656 g_657 g_12383 g_255 g_3420 g_8082.f3 g_5490 g_5407 g_12501 g_5749 g_1419 g_836 g_837 g_8526 g_8527 g_1446 g_4087 g_7825.f0 g_3307 g_4118 g_3260 g_3261 g_3071 g_4151 g_1540 g_3302 g_2717 g_2718 g_2719 g_1207 g_7 g_4493 g_4510 g_5127 g_5128 g_6240 g_4088 g_604 g_653 g_11090 g_78 g_12526.f1 g_8562 g_9480 g_7297 g_4502 g_7256 g_12187
 * writes: g_3870 g_1396 g_2886 g_499 g_4882 g_1020 g_466 g_4118 g_3643 g_446 g_66 g_7254 g_1847 g_5490 g_196 g_3529.f0 g_539 g_845 g_255 g_4294 g_8082.f3 g_431 g_998 g_657 g_9480 g_7825.f0 g_1995.f1 g_7297 g_6572.f3 g_8583 g_12501 g_232 g_3307 g_4095 g_3302 g_3070 g_4139 g_1446 g_653 g_951 g_6240 g_78 g_6586.f3 g_8089.f3 g_12526.f1 g_8562 g_11550 g_4502 g_7256 g_746
 */
static int16_t  func_44(int64_t  p_45, uint32_t  p_46, int8_t  p_47, int8_t * p_48)
{ /* block id: 5177 */
    const uint16_t l_12203 = 3UL;
    uint32_t **l_12247[6][4] = {{&g_930[1][2],&g_930[1][2],&g_930[1][7],&g_930[1][2]},{&g_930[1][2],(void*)0,&g_930[1][2],&g_930[1][7]},{&g_930[1][2],&g_930[1][7],&g_930[1][7],&g_930[1][2]},{&g_930[1][2],&g_930[1][7],&g_930[1][2],&g_930[1][7]},{&g_930[1][7],(void*)0,&g_930[1][2],&g_930[1][2]},{&g_930[1][2],&g_930[1][2],&g_930[1][7],&g_930[1][2]}};
    int32_t l_12258 = 0x8F5FBB26L;
    int32_t l_12277 = (-1L);
    int8_t l_12296 = 0x6DL;
    int32_t l_12326[9][3] = {{0x71850E58L,0x94DDA169L,0xF6CBB30CL},{0x66E87006L,0x66E87006L,(-1L)},{0x71850E58L,0x94DDA169L,0xF6CBB30CL},{0x66E87006L,0x66E87006L,(-1L)},{0x71850E58L,0x94DDA169L,0xF6CBB30CL},{0x66E87006L,0x66E87006L,(-1L)},{0x71850E58L,0x94DDA169L,0xF6CBB30CL},{0x66E87006L,0x66E87006L,(-1L)},{0x71850E58L,0x94DDA169L,0xF6CBB30CL}};
    uint64_t l_12334 = 8UL;
    union U3 ***l_12341 = (void*)0;
    uint32_t l_12388 = 0UL;
    int32_t *l_12400 = &g_499[0][0];
    int32_t l_12408 = 1L;
    union U5 *l_12486 = &g_12487;
    struct S0 *l_12525 = &g_12526;
    uint32_t l_12555 = 1UL;
    int16_t ***l_12565 = &g_1030[0][6];
    union U3 *l_12589 = &g_12590;
    union U3 **l_12591 = &g_746;
    int32_t *l_12592 = &g_11830;
    int32_t *l_12593 = &l_12326[1][0];
    int32_t *l_12594 = (void*)0;
    int32_t *l_12595 = &g_499[2][0];
    int32_t *l_12596 = &g_38;
    int32_t *l_12597 = &g_8779;
    int32_t *l_12598 = &l_12326[1][0];
    int32_t *l_12599 = &g_3307;
    int32_t *l_12600 = &g_4882;
    int32_t *l_12601 = &g_12187;
    int32_t *l_12602 = &l_12277;
    int32_t *l_12603 = &g_12187;
    int32_t *l_12604 = &l_12277;
    int32_t *l_12605 = &g_12187;
    int32_t *l_12606[5];
    uint16_t l_12607 = 0UL;
    int i, j;
    for (i = 0; i < 5; i++)
        l_12606[i] = &g_255;
    if ((((*g_4097) = (safe_div_func_int64_t_s_s((safe_mul_func_int16_t_s_s((l_12203 || (safe_mul_func_uint8_t_u_u((safe_lshift_func_int16_t_s_s(p_47, (safe_unary_minus_func_int16_t_s(0x93F1L)))), ((l_12203 == ((((**g_714) >= l_12203) , ((0L < ((safe_div_func_int16_t_s_s((safe_mul_func_int8_t_s_s((safe_div_func_uint16_t_u_u(((((safe_add_func_uint16_t_u_u(((((****g_5408) = (**g_5410)) | 0xA8L) < p_46), 8L)) != 255UL) || 0L) < 0x4356361B46B89D60LL), (****g_1675))), 2UL)), p_46)) <= l_12203)) < l_12203)) && (**g_4423))) | l_12203)))), l_12203)), l_12203))) , l_12203))
    { /* block id: 5180 */
        uint64_t *l_12250 = &g_11569;
        int32_t l_12257[9] = {0x4A074EB9L,0x4A074EB9L,0x4A074EB9L,0x4A074EB9L,0x4A074EB9L,0x4A074EB9L,0x4A074EB9L,0x4A074EB9L,0x4A074EB9L};
        uint16_t l_12354 = 0xFC26L;
        const union U3 *l_12369 = &g_12370;
        const union U3 **l_12368 = &l_12369;
        const union U3 ***l_12367 = &l_12368;
        const union U3 ****l_12366 = &l_12367;
        int8_t l_12378 = (-1L);
        int32_t *l_12399 = &g_3420[2];
        const int8_t *l_12402 = &g_1621[5];
        const int8_t **l_12401 = &l_12402;
        int i;
        for (g_2886 = 0; (g_2886 <= 9); g_2886 = safe_add_func_uint16_t_u_u(g_2886, 5))
        { /* block id: 5183 */
            uint32_t l_12236 = 0UL;
            int32_t l_12252 = (-5L);
            int32_t l_12253 = 0xE7B768CDL;
            const uint32_t ****l_12265 = &g_7504;
            uint8_t *** const *l_12285 = &g_10001[2];
            struct S0 **l_12293 = (void*)0;
            struct S0 ***l_12292 = &l_12293;
            struct S0 ****l_12291 = &l_12292;
            uint8_t l_12304[7][4][9] = {{{0UL,0x99L,0x6BL,0xC8L,4UL,0x27L,0xD3L,254UL,0xFEL},{0x0BL,0x95L,0xBAL,0UL,248UL,0xF6L,0x94L,0UL,0x27L},{0xE5L,254UL,0x2EL,255UL,0x60L,0x99L,0xE2L,1UL,8UL},{255UL,254UL,4UL,0UL,3UL,0x85L,0x95L,0x60L,8UL}},{{0xE2L,0x95L,0x11L,254UL,6UL,8UL,8UL,6UL,254UL},{0xD3L,0x99L,0xD3L,0xBAL,0x0BL,0xF9L,254UL,0x85L,0xE2L},{254UL,255UL,255UL,0xECL,1UL,0x95L,0xF6L,255UL,0x60L},{0UL,0x11L,0x68L,0xBAL,0x95L,255UL,252UL,0x4CL,0x5CL}},{{4UL,254UL,253UL,254UL,0x99L,247UL,0UL,0x11L,0xBAL},{0xF9L,0xBFL,6UL,0UL,254UL,0xB6L,1UL,0x80L,0x21L},{0UL,8UL,0x42L,255UL,254UL,0xB6L,0xECL,0xE5L,255UL},{248UL,0UL,0xC8L,0UL,0xAAL,247UL,0x60L,0x94L,0x94L}},{{0x99L,255UL,0xE2L,0xC8L,0xE2L,255UL,0x99L,0xECL,0x25L},{0UL,0xEEL,0xECL,0x5CL,8UL,0x95L,0x4CL,0x99L,4UL},{255UL,1UL,0xF7L,3UL,253UL,0xF9L,0x95L,0xECL,247UL},{0x6BL,0xF6L,0xFEL,1UL,0x2BL,8UL,0xBFL,0x94L,0UL}},{{253UL,0xF7L,0UL,0x95L,0xECL,0x85L,0xB6L,0xE5L,0x11L},{0xC8L,6UL,247UL,255UL,8UL,0x99L,0x68L,0x80L,0xDFL},{0xC8L,0xAAL,0UL,0x99L,1UL,0xF6L,0x27L,0x11L,0x95L},{253UL,0xE5L,0UL,0x4CL,0UL,0x27L,0UL,0x4CL,0UL}},{{0x6BL,0x6BL,254UL,0x4EL,255UL,0UL,0x3CL,8UL,0x4EL},{8UL,247UL,0x80L,0xC8L,247UL,0xE1L,0UL,0xE5L,0x0BL},{0xBAL,0xDFL,255UL,0xECL,6UL,3UL,4UL,0UL,0x3CL},{248UL,254UL,247UL,0x95L,0UL,1UL,255UL,0x27L,1UL}},{{247UL,0UL,0x11L,0xBAL,0UL,0x6BL,0xFEL,0x68L,1UL},{1UL,1UL,0xE1L,253UL,0UL,0UL,0x60L,0xB6L,0xFEL},{1UL,0x60L,0x0BL,0x99L,0UL,1UL,255UL,0xBFL,255UL},{254UL,6UL,8UL,8UL,6UL,254UL,0x11L,0x95L,0xE2L}}};
            int32_t l_12327 = 0L;
            int32_t l_12329 = (-1L);
            int32_t l_12330 = 0x65A1F3C9L;
            int32_t l_12333[2][4][10] = {{{1L,0x19E3A60CL,0xE8538CD7L,0x19E3A60CL,1L,9L,(-6L),1L,0x19E3A60CL,1L},{1L,0x2120971DL,0xE8538CD7L,0L,1L,1L,4L,(-8L),0x2120971DL,1L},{1L,0L,0x9B4AD366L,(-6L),1L,1L,4L,0x7B47BBFCL,0L,9L},{(-4L),0x2120971DL,(-1L),(-6L),1L,1L,(-6L),(-1L),0x2120971DL,(-4L)}},{{(-4L),0x19E3A60CL,(-8L),0L,1L,1L,0x74800EBDL,(-1L),0x19E3A60CL,1L},{1L,0x74800EBDL,(-1L),0x19E3A60CL,1L,1L,0x2120971DL,0x7B47BBFCL,0x74800EBDL,(-4L)},{1L,0x74800EBDL,0x9B4AD366L,4L,1L,9L,0x74800EBDL,(-8L),0x74800EBDL,9L},{1L,0x19E3A60CL,0xE8538CD7L,0x19E3A60CL,1L,9L,(-6L),1L,0x19E3A60CL,1L}}};
            int i, j, k;
            (*g_11360) |= l_12203;
            for (g_4882 = 0; (g_4882 >= 10); g_4882 = safe_add_func_uint16_t_u_u(g_4882, 3))
            { /* block id: 5187 */
                int16_t l_12223 = (-8L);
                int32_t l_12242 = 0xE06BF84EL;
                int32_t l_12246 = 0xE62A828AL;
                uint64_t * const l_12249 = &g_4338;
                int32_t l_12274 = 0x9747AEA9L;
                uint32_t l_12282 = 4294967295UL;
                (*g_11360) ^= l_12223;
                for (g_1020 = 0; (g_1020 <= 4); g_1020 += 1)
                { /* block id: 5191 */
                    const uint64_t l_12224 = 8UL;
                    int8_t *l_12241 = &g_4118[3];
                    uint32_t **l_12248 = &g_930[2][3];
                    uint32_t ****l_12266 = (void*)0;
                    int i;
                    if (l_12224)
                        break;
                    if (((1L > (l_12242 |= (safe_rshift_func_int16_t_s_s(((!0L) , ((safe_mul_func_int16_t_s_s((safe_sub_func_int8_t_s_s((safe_sub_func_uint16_t_u_u((safe_div_func_uint16_t_u_u(((**g_929) != p_45), l_12236)), 1L)), ((safe_div_func_int32_t_s_s((((((p_46 > (((0x88L == (safe_lshift_func_int8_t_s_s(((void*)0 != g_4583[g_1020]), 3))) , &p_47) == l_12241)) ^ p_47) && p_46) < 0x6C056FB5C466ADE7LL) , p_46), 4294967295UL)) & l_12223))), l_12223)) , 7L)), 5)))) != p_45))
                    { /* block id: 5194 */
                        int16_t l_12245 = 0L;
                        int32_t l_12251 = 4L;
                        if (p_46)
                            break;
                        if (p_45)
                            continue;
                        l_12253 ^= ((*****g_1674) ^ (l_12252 = (0xCBCBC71E50675B28LL ^ (safe_rshift_func_uint16_t_u_s((l_12246 ^= (l_12242 = (p_45 , ((**g_714) |= l_12245)))), (p_47 ^ ((l_12251 = ((*l_12241) = (0x0097L || ((l_12247[5][2] != l_12248) >= (l_12249 == l_12250))))) && p_45)))))));
                    }
                    else
                    { /* block id: 5204 */
                        uint64_t l_12254 = 7UL;
                        l_12254--;
                        l_12258 |= l_12257[4];
                    }
                    l_12246 |= (p_47 <= (safe_mod_func_uint32_t_u_u(0x87EB8CE4L, (safe_mod_func_int64_t_s_s(((l_12258 = (((0xB2FE3C27L < (safe_rshift_func_uint8_t_u_u(1UL, 4))) , l_12265) != l_12266)) < (((~(0xAAB1AC60L < ((**l_12248) = (((safe_mul_func_int16_t_s_s((((safe_sub_func_int16_t_s_s(((safe_lshift_func_int8_t_s_s((p_46 , (-1L)), (**g_4423))) , 0x262FL), l_12224)) , l_12224) || l_12236), l_12274)) , l_12242) >= (*p_48))))) >= (*p_48)) & l_12224)), p_47)))));
                }
                l_12242 = (p_45 , 9L);
                for (g_7254 = 0; (g_7254 < (-16)); g_7254 = safe_sub_func_uint16_t_u_u(g_7254, 7))
                { /* block id: 5215 */
                    int32_t *l_12278 = &g_11124;
                    int32_t *l_12279 = (void*)0;
                    int32_t *l_12280 = &l_12274;
                    int32_t *l_12281[7][7][5] = {{{&l_12274,(void*)0,(void*)0,&g_8,(void*)0},{(void*)0,(void*)0,&g_11302,&g_7[2][5][1],&g_8},{&g_11302,&g_11124,&l_12246,&g_3307,&g_7[2][5][1]},{&g_7[1][1][0],&l_12246,&g_7[2][5][1],&l_12258,(void*)0},{&g_11830,&g_11124,&l_12274,&l_12246,&g_163},{&g_8779,(void*)0,&l_12242,&g_11302,&g_7[1][1][0]},{(void*)0,(void*)0,&g_11302,(void*)0,(void*)0}},{{&g_38,(void*)0,&g_7[2][5][1],(void*)0,&g_38},{&l_12277,&l_12246,&g_11302,&g_11124,&l_12246},{&g_7[1][1][0],&g_8779,&l_12242,&l_12242,&g_8779},{&g_3307,&g_255,&l_12246,(void*)0,(void*)0},{&g_11,&l_12242,&g_255,(void*)0,&l_12277},{&l_12246,&g_8,&g_3420[2],&l_12246,(void*)0},{&g_11,&g_38,&g_7[2][5][1],&g_3307,&g_11124}},{{&g_3307,(void*)0,&g_3307,&g_3,(void*)0},{&g_7[1][1][0],(void*)0,&l_12246,&g_8779,&g_8},{&g_3420[2],&g_8,&l_12246,&g_3,&g_255},{&l_12277,(void*)0,&l_12246,(void*)0,&g_38},{&l_12246,&g_255,&g_3307,&g_255,&l_12246},{(void*)0,&g_11302,&g_7[2][5][1],&g_8,&l_12258},{&g_11302,(void*)0,&g_3420[2],&g_3,&l_12277}},{{&g_11124,&g_11,&g_255,&g_11302,&l_12258},{&g_499[0][0],&g_3,&l_12246,&g_3,&l_12246},{&l_12258,&l_12257[4],&l_12242,&g_11124,&g_38},{&g_11302,&g_11830,&g_11302,&l_12246,&g_255},{&g_11124,(void*)0,&g_3307,(void*)0,&g_8},{&g_7[2][5][1],&g_11830,&g_499[0][0],(void*)0,(void*)0},{(void*)0,&l_12257[4],&l_12257[4],(void*)0,&g_11124}},{{&g_11830,&g_3,&g_11302,&g_11124,(void*)0},{&l_12277,&g_11,&g_3307,&l_12246,&l_12277},{&g_4882,(void*)0,&g_7[2][5][1],&g_11124,(void*)0},{&g_7[1][1][0],&g_11302,&l_12242,(void*)0,&g_8779},{&g_255,&g_255,&g_11830,(void*)0,&l_12246},{&g_11,(void*)0,&g_255,(void*)0,&l_12277},{(void*)0,&g_8,&g_4882,&l_12246,(void*)0}},{{&g_11,(void*)0,&g_7[2][5][1],&g_11124,&g_11124},{&g_255,(void*)0,&g_255,&g_3,(void*)0},{&g_7[1][1][0],&g_38,&l_12246,&g_11302,&g_8},{&g_4882,&g_8,(void*)0,&g_3,&g_3307},{&l_12277,&l_12242,&l_12246,&g_8,&g_38},{&g_11830,&g_255,&g_255,&g_255,&g_11830},{(void*)0,&g_8779,&g_7[2][5][1],(void*)0,&l_12258}},{{&g_7[2][5][1],(void*)0,&g_4882,&g_3,&l_12257[4]},{&g_11124,&l_12246,&g_255,&g_8779,&l_12258},{&g_11302,&g_3,&g_11830,&g_3,&g_11830},{&l_12258,&l_12258,&l_12242,&g_3307,&g_38},{&g_499[0][0],&g_11830,&g_7[2][5][1],(void*)0,&l_12257[4]},{&g_8779,(void*)0,&g_11302,&g_11,&g_38},{&g_255,&g_11,&g_163,&g_3,(void*)0}}};
                    uint8_t *** const **l_12286 = &l_12285;
                    int i, j, k;
                    ++l_12282;
                    (*l_12286) = l_12285;
                    for (l_12246 = 0; (l_12246 == 14); l_12246 = safe_add_func_uint8_t_u_u(l_12246, 2))
                    { /* block id: 5220 */
                        return l_12223;
                    }
                }
            }
            if ((safe_sub_func_int16_t_s_s(((1UL && ((0xE364L == ((l_12253 == p_46) != ((p_47 , l_12291) != &g_11437))) != 0x02A6E8E867B30FE5LL)) >= (safe_mul_func_int8_t_s_s((l_12252 , (*p_48)), (*g_5411)))), l_12296)))
            { /* block id: 5225 */
                int8_t l_12314 = 0L;
                int32_t l_12318 = 0xDE085DB9L;
                int32_t l_12328 = 2L;
                int32_t l_12331 = 0x4407E7B2L;
                int32_t l_12332 = 0xE0F09425L;
                for (g_1847 = 7; (g_1847 >= 1); g_1847 -= 1)
                { /* block id: 5228 */
                    uint32_t *****l_12305[9][8][3] = {{{(void*)0,(void*)0,&g_11807[0][0]},{&g_11807[2][0],&g_11807[8][1],&g_11807[2][0]},{(void*)0,&g_11807[0][0],&g_11807[0][0]},{&g_11807[9][1],&g_11807[8][1],&g_11807[9][1]},{(void*)0,(void*)0,&g_11807[0][0]},{&g_11807[2][0],&g_11807[8][1],&g_11807[2][0]},{(void*)0,&g_11807[0][0],&g_11807[0][0]},{&g_11807[9][1],&g_11807[8][1],&g_11807[9][1]}},{{(void*)0,(void*)0,&g_11807[0][0]},{&g_11807[2][0],&g_11807[8][1],&g_11807[2][0]},{(void*)0,&g_11807[0][0],&g_11807[0][0]},{&g_11807[9][1],&g_11807[8][1],&g_11807[9][1]},{(void*)0,(void*)0,&g_11807[0][0]},{&g_11807[2][0],&g_11807[8][1],&g_11807[2][0]},{(void*)0,&g_11807[0][0],&g_11807[0][0]},{&g_11807[9][1],&g_11807[8][1],&g_11807[9][1]}},{{(void*)0,(void*)0,&g_11807[0][0]},{&g_11807[2][0],&g_11807[8][1],&g_11807[2][0]},{(void*)0,&g_11807[0][0],&g_11807[0][0]},{&g_11807[9][1],&g_11807[8][1],&g_11807[9][1]},{(void*)0,(void*)0,&g_11807[0][0]},{&g_11807[2][0],&g_11807[8][1],&g_11807[2][0]},{(void*)0,&g_11807[0][0],&g_11807[0][0]},{&g_11807[9][1],&g_11807[8][1],&g_11807[9][1]}},{{(void*)0,(void*)0,&g_11807[0][0]},{&g_11807[2][0],&g_11807[8][1],&g_11807[2][0]},{(void*)0,&g_11807[0][0],&g_11807[0][0]},{&g_11807[9][1],&g_11807[8][1],&g_11807[9][1]},{(void*)0,(void*)0,&g_11807[0][0]},{&g_11807[2][0],&g_11807[8][1],&g_11807[2][0]},{(void*)0,&g_11807[0][0],&g_11807[0][0]},{&g_11807[9][1],&g_11807[8][1],&g_11807[9][1]}},{{(void*)0,(void*)0,&g_11807[0][0]},{&g_11807[2][0],&g_11807[8][1],&g_11807[2][0]},{(void*)0,&g_11807[0][0],&g_11807[0][0]},{&g_11807[9][1],&g_11807[8][1],&g_11807[9][1]},{(void*)0,(void*)0,&g_11807[0][0]},{&g_11807[2][0],&g_11807[8][1],&g_11807[2][0]},{(void*)0,&g_11807[0][0],&g_11807[0][0]},{&g_11807[9][1],&g_11807[8][1],&g_11807[9][1]}},{{(void*)0,(void*)0,&g_11807[0][0]},{&g_11807[2][0],&g_11807[8][1],&g_11807[2][0]},{(void*)0,&g_11807[0][0],&g_11807[0][0]},{&g_11807[9][1],&g_11807[8][1],&g_11807[9][1]},{(void*)0,(void*)0,&g_11807[0][0]},{&g_11807[2][0],&g_11807[8][1],&g_11807[2][0]},{(void*)0,&g_11807[0][0],&g_11807[0][0]},{&g_11807[9][1],&g_11807[8][1],&g_11807[9][1]}},{{(void*)0,(void*)0,&g_11807[0][0]},{&g_11807[2][0],&g_11807[8][1],&g_11807[2][0]},{(void*)0,&g_11807[0][0],&g_11807[0][0]},{&g_11807[9][1],&g_11807[8][1],&g_11807[9][1]},{(void*)0,(void*)0,&g_11807[0][0]},{&g_11807[2][0],&g_11807[8][1],&g_11807[2][0]},{(void*)0,&g_11807[0][0],&g_11807[0][0]},{&g_11807[9][1],&g_11807[8][1],&g_11807[9][1]}},{{(void*)0,(void*)0,&g_11807[0][0]},{&g_11807[2][0],&g_11807[8][1],&g_11807[2][0]},{(void*)0,&g_11807[0][0],&g_11807[0][0]},{&g_11807[9][1],&g_11807[8][1],&g_11807[9][1]},{(void*)0,(void*)0,&g_11807[0][0]},{&g_11807[2][0],&g_11807[8][1],&g_11807[2][0]},{(void*)0,&g_11807[0][0],&g_11807[0][0]},{&g_11807[9][1],&g_11807[8][1],&g_11807[9][1]}},{{(void*)0,(void*)0,&g_11807[0][0]},{&g_11807[2][0],&g_11807[8][1],&g_11807[2][0]},{(void*)0,&g_11807[0][0],&g_11807[0][0]},{&g_11807[9][1],&g_11807[8][1],&g_11807[9][1]},{(void*)0,(void*)0,&g_11807[0][0]},{&g_11807[2][0],&g_11807[8][1],&g_11807[2][0]},{(void*)0,&g_11807[0][0],&g_11807[0][0]},{&g_11807[9][1],&g_11807[8][1],&g_11807[9][1]}}};
                    int32_t l_12308[2][4] = {{0xB20A8510L,0xB20A8510L,0xB20A8510L,0xB20A8510L},{0xB20A8510L,0xB20A8510L,0xB20A8510L,0xB20A8510L}};
                    int32_t l_12313 = (-1L);
                    uint16_t l_12319 = 1UL;
                    int i, j, k;
                    if ((((safe_rshift_func_uint16_t_u_u((((!(((safe_mod_func_uint64_t_u_u(((((*g_8235) = (((*p_48) | (((safe_sub_func_int32_t_s_s(5L, l_12304[6][0][8])) < p_45) <= (((l_12308[0][0] &= (((l_12252 = ((void*)0 != l_12305[1][0][2])) != l_12257[6]) , (safe_lshift_func_uint8_t_u_s(1UL, 4)))) | ((safe_rshift_func_int8_t_s_s((safe_add_func_int32_t_s_s((-1L), l_12203)), l_12257[4])) < 0xEDL)) , 0xEAL))) , l_12296)) <= 0xB8L) != p_47), (*g_1541))) == l_12313) | (*p_48))) < l_12314) && 0xD2L), p_45)) || p_46) && p_45))
                    { /* block id: 5232 */
                        uint32_t l_12315[2][6][4] = {{{18446744073709551615UL,0xF2272EF4L,0x7CC056BAL,0x7CC056BAL},{0x354F5FD8L,0x354F5FD8L,18446744073709551615UL,0x7CC056BAL},{0x676456B2L,0xF2272EF4L,0x676456B2L,18446744073709551615UL},{0x676456B2L,18446744073709551615UL,18446744073709551615UL,0x676456B2L},{0x354F5FD8L,18446744073709551615UL,0x7CC056BAL,18446744073709551615UL},{18446744073709551615UL,0xF2272EF4L,0x7CC056BAL,0x7CC056BAL}},{{0x354F5FD8L,0x354F5FD8L,18446744073709551615UL,0x7CC056BAL},{0x676456B2L,0xF2272EF4L,0x676456B2L,18446744073709551615UL},{0x676456B2L,18446744073709551615UL,18446744073709551615UL,0x676456B2L},{0x354F5FD8L,18446744073709551615UL,0x7CC056BAL,18446744073709551615UL},{18446744073709551615UL,0xF2272EF4L,0x7CC056BAL,0x7CC056BAL},{0x354F5FD8L,0x354F5FD8L,18446744073709551615UL,0x7CC056BAL}}};
                        int i, j, k;
                        if (l_12257[4])
                            break;
                        ++l_12315[0][0][3];
                        return p_45;
                    }
                    else
                    { /* block id: 5236 */
                        int32_t *l_12322 = (void*)0;
                        int32_t *l_12323 = &g_3420[2];
                        int32_t *l_12324 = (void*)0;
                        int32_t *l_12325[1][2][8];
                        int i, j, k;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 2; j++)
                            {
                                for (k = 0; k < 8; k++)
                                    l_12325[i][j][k] = &g_12187;
                            }
                        }
                        ++l_12319;
                        l_12334--;
                    }
                }
            }
            else
            { /* block id: 5241 */
                int8_t l_12355 = 0xD0L;
                (*g_10974) = (((safe_div_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(((void*)0 == l_12341), (safe_add_func_int16_t_s_s(((safe_add_func_int16_t_s_s((safe_rshift_func_uint8_t_u_u((((safe_mod_func_int16_t_s_s(l_12203, ((safe_add_func_int64_t_s_s((((*g_6119) = (safe_div_func_int32_t_s_s(p_47, 0x9293A919L))) && (l_12326[5][1] = l_12257[2])), 0x34BAC0EDAEEF2665LL)) & l_12296))) <= p_46) != l_12354), 7)), l_12236)) && (***g_4422)), l_12296)))), l_12334)) | l_12327) , l_12355);
            }
        }
        for (g_4294 = 17; (g_4294 >= 42); g_4294++)
        { /* block id: 5249 */
            uint32_t ** const *l_12386 = (void*)0;
            uint32_t ** const **l_12385[5][2][2] = {{{&l_12386,&l_12386},{&l_12386,&l_12386}},{{&l_12386,&l_12386},{&l_12386,&l_12386}},{{&l_12386,&l_12386},{&l_12386,&l_12386}},{{&l_12386,&l_12386},{&l_12386,&l_12386}},{{&l_12386,&l_12386},{&l_12386,&l_12386}}};
            uint32_t ** const ***l_12384 = &l_12385[3][1][0];
            int32_t l_12387 = (-4L);
            int32_t l_12389 = 6L;
            const int8_t **l_12403 = (void*)0;
            int i, j, k;
            (*g_10974) &= ((safe_lshift_func_uint8_t_u_u((((((safe_mul_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u((((safe_rshift_func_uint16_t_u_u((((0x3A2BE198L || ((l_12366 != ((safe_div_func_uint16_t_u_u(((((((safe_add_func_int64_t_s_s((((**g_1674) != (void*)0) | 250UL), ((safe_add_func_uint16_t_u_u(l_12257[1], (((!l_12378) != (((p_45 && ((safe_rshift_func_uint8_t_u_u((safe_lshift_func_int8_t_s_s((*g_7633), 0)), (**g_4139))) ^ g_12383)) , (void*)0) != l_12384)) >= (-1L)))) , l_12257[4]))) > l_12387) != 0xEBL) || 0x72EE3003L) && l_12326[1][0]) & (*g_1678)), p_47)) , &l_12367)) >= 0xE8AAL)) || l_12326[1][0]) || l_12387), p_46)) ^ p_46) <= 252UL), l_12296)), l_12387)) , 0x7E91L) , l_12388) >= p_45) > l_12378), l_12389)) , p_46);
            l_12387 ^= ((0xB8L ^ (p_47 < ((((*g_11360) = (((*p_48) < (safe_rshift_func_uint16_t_u_u((((*g_715) = ((safe_mod_func_uint64_t_u_u(((safe_add_func_int32_t_s_s(((((*g_1678) & (((+((safe_add_func_uint64_t_u_u((&l_12257[2] != (p_45 , (l_12400 = l_12399))), (l_12401 == l_12403))) > (*g_11360))) > l_12334) , (*l_12400))) || 0L) , (-1L)), 1UL)) , p_47), (*l_12399))) || (*p_48))) && (**g_714)), p_47))) <= (*l_12399))) || l_12389) || (*l_12399)))) && (***g_4422));
        }
    }
    else
    { /* block id: 5256 */
        uint8_t l_12417 = 0xEDL;
        int32_t l_12433 = 0L;
        int32_t l_12435[6] = {(-2L),0x6E07FE4EL,(-2L),(-2L),0x6E07FE4EL,(-2L)};
        uint32_t l_12441 = 18446744073709551615UL;
        struct S1 *l_12448 = &g_12449;
        uint32_t l_12467 = 0xCEF214C5L;
        const uint32_t *l_12494 = &g_1020;
        const int16_t *l_12495 = &g_232;
        uint32_t l_12509[1];
        int32_t *l_12512 = &l_12277;
        struct S0 *l_12521 = &g_12522;
        union U4 * const *l_12534 = (void*)0;
        int8_t ***l_12549[2];
        int16_t ***l_12564 = &g_1030[0][1];
        uint16_t l_12586[6][2][8] = {{{0x9EDFL,0x956CL,0UL,0x956CL,0x9EDFL,0UL,0UL,0x9EDFL},{0x956CL,0xDC26L,0xDC26L,0x956CL,0x332BL,0x9EDFL,0x332BL,0x956CL}},{{0xDC26L,0x332BL,0xDC26L,0UL,0UL,0UL,0UL,0xDC26L},{0x332BL,0x332BL,0UL,0x9EDFL,0UL,0x9EDFL,0UL,0x332BL}},{{0x332BL,0xDC26L,0UL,0UL,0UL,0UL,0xDC26L,0x332BL},{0xDC26L,0x956CL,0x332BL,0x9EDFL,0x332BL,0x956CL,0xDC26L,0xDC26L}},{{0x956CL,0x9EDFL,0UL,0UL,0x9EDFL,0x956CL,0UL,0x956CL},{0x9EDFL,0x956CL,0UL,0x956CL,0x9EDFL,0UL,0UL,0x9EDFL}},{{0x956CL,0xDC26L,0xDC26L,0x956CL,0x332BL,0x9EDFL,0x332BL,0xDC26L},{0x9EDFL,0UL,0x9EDFL,0UL,0x332BL,0x332BL,0UL,0x9EDFL}},{{0UL,0UL,0x332BL,0UL,0x956CL,0UL,0x332BL,0UL},{0UL,0x9EDFL,0UL,0x332BL,0x332BL,0UL,0x9EDFL,0UL}}};
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_12509[i] = 18446744073709551615UL;
        for (i = 0; i < 2; i++)
            l_12549[i] = &g_4423;
        for (g_8082.f3 = 12; (g_8082.f3 < 4); g_8082.f3 = safe_sub_func_int8_t_s_s(g_8082.f3, 7))
        { /* block id: 5259 */
            uint64_t *l_12406[1];
            int32_t l_12407 = 0x4E31191BL;
            int32_t l_12437 = 1L;
            int32_t l_12438 = 0x7AAC522FL;
            int32_t l_12440[4] = {0xD00A61A6L,0xD00A61A6L,0xD00A61A6L,0xD00A61A6L};
            union U3 *l_12458 = &g_12459;
            uint8_t *****l_12500 = &g_10000;
            int i;
            for (i = 0; i < 1; i++)
                l_12406[i] = &g_3070;
            if ((l_12408 |= (p_46 && (l_12407 |= ((*g_1541) = ((*l_12400) && (((*g_7633) = ((*g_8235) &= 0x22L)) , (*p_48))))))))
            { /* block id: 5265 */
                uint8_t l_12423 = 0UL;
                int32_t l_12424 = 2L;
                int32_t l_12439 = 0x466D1BCEL;
                for (g_657 = 0; (g_657 == 51); ++g_657)
                { /* block id: 5268 */
                    union U5 ***l_12421 = &g_6484;
                    int32_t l_12425 = 0xCEABCEE8L;
                    int32_t l_12432 = 0L;
                    int32_t l_12434 = 0x102660F8L;
                    int32_t l_12436[1][3];
                    union U3 * const l_12456 = &g_12457[0][0][2];
                    int32_t *l_12465 = &l_12326[1][0];
                    int32_t *l_12466[3];
                    int i, j;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 3; j++)
                            l_12436[i][j] = 0x1380E653L;
                    }
                    for (i = 0; i < 3; i++)
                        l_12466[i] = (void*)0;
                    if ((l_12407 ^= p_46))
                    { /* block id: 5270 */
                        union U5 ***l_12420 = (void*)0;
                        int32_t l_12422 = 0L;
                        int32_t *l_12426 = (void*)0;
                        int32_t *l_12427 = &g_12187;
                        int32_t *l_12428 = &g_499[1][0];
                        int32_t *l_12429 = &g_255;
                        int32_t *l_12430 = &l_12424;
                        int32_t *l_12431[3];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_12431[i] = &g_3420[2];
                        (*l_12400) ^= (((--(**g_929)) && ((safe_add_func_uint8_t_u_u((p_46 , ((((((0xF1L & (safe_rshift_func_uint8_t_u_u(l_12417, ((((((safe_div_func_int32_t_s_s(((l_12420 != l_12421) & p_45), (65534UL | ((p_45 ^ p_45) & p_47)))) != 0x54458521L) , p_45) && 0x85FBB2A4L) & 0x04A2A40AL) ^ p_45)))) ^ p_46) != l_12422) != l_12423) , 0xDD778A3A3B24C4F3LL) & 0x993C56AF30037DB4LL)), 0xFFL)) == p_46)) || 9L);
                        if (l_12423)
                            break;
                        --l_12441;
                        return (*l_12400);
                    }
                    else
                    { /* block id: 5276 */
                        int32_t *l_12460 = &g_499[2][0];
                        int32_t *l_12461[8][6] = {{&l_12432,&g_8779,(void*)0,&g_3420[2],&g_3420[2],(void*)0},{&g_3420[2],&g_3420[2],(void*)0,&g_8779,&l_12432,(void*)0},{&g_8779,&l_12432,(void*)0,&l_12432,&g_8779,(void*)0},{&l_12432,&g_8779,(void*)0,&g_3420[2],&g_3420[2],(void*)0},{&g_3420[2],&g_3420[2],(void*)0,&g_8779,&l_12432,(void*)0},{&g_8779,&l_12432,(void*)0,&l_12432,&g_8779,(void*)0},{&l_12432,&g_8779,(void*)0,&g_3420[2],&g_3420[2],(void*)0},{&g_3420[2],&g_3420[2],(void*)0,&g_8779,&l_12432,(void*)0}};
                        uint64_t l_12462 = 1UL;
                        int i, j;
                        (*g_10974) |= ((*l_12400) = ((safe_lshift_func_uint8_t_u_u(((*g_5411) = (safe_lshift_func_uint8_t_u_s((((l_12433 |= l_12438) >= ((l_12448 != (void*)0) ^ (safe_lshift_func_int16_t_s_s(((l_12424 >= (safe_sub_func_int16_t_s_s((safe_sub_func_uint32_t_u_u(p_47, (l_12456 == l_12458))), 65535UL))) , p_47), 12)))) | p_47), (*p_48)))), 5)) != l_12436[0][1]));
                        if (l_12434)
                            break;
                        --l_12462;
                        if (l_12423)
                            continue;
                    }
                    ++l_12467;
                }
            }
            else
            { /* block id: 5287 */
                (*l_12400) = p_47;
                (*l_12400) = l_12440[0];
            }
            for (g_9480 = 6; (g_9480 < (-9)); g_9480--)
            { /* block id: 5293 */
                uint32_t l_12485 = 1UL;
                int32_t l_12505 = 0xE2523B82L;
                int32_t l_12506 = 0xEB765BD6L;
                int32_t l_12507[4][8][3] = {{{(-8L),0x0EDBA351L,0x0EDBA351L},{0x263E7514L,0x91C5B6A7L,4L},{(-1L),0x201015F6L,(-8L)},{(-1L),0xCCA5A0DBL,(-4L)},{(-1L),0x88854932L,0x32D1446BL},{0x18A72FA4L,0xCCA5A0DBL,0x7DCD3ABDL},{0x263E7514L,0x201015F6L,0x1C26F647L},{0xB6E76D60L,0x91C5B6A7L,(-8L)}},{{0x88854932L,0x0EDBA351L,0xBBA4CB45L},{0x88854932L,0x88854932L,0x263E7514L},{0xB6E76D60L,0x32D1446BL,0xCCA5A0DBL},{0x263E7514L,0x1A48D71EL,1L},{0x18A72FA4L,0xD300EE48L,(-8L)},{(-1L),0x263E7514L,1L},{(-1L),0x88854932L,0xCCA5A0DBL},{(-1L),0x7DCD3ABDL,0x263E7514L}},{{0x263E7514L,4L,0xBBA4CB45L},{(-8L),4L,(-8L)},{(-7L),0x7DCD3ABDL,0x1C26F647L},{0L,0x88854932L,0x7DCD3ABDL},{0L,0x263E7514L,0x32D1446BL},{0x263E7514L,0xD300EE48L,(-4L)},{0L,0x1A48D71EL,(-8L)},{0L,0x32D1446BL,4L}},{{(-7L),0x88854932L,0x0EDBA351L},{(-8L),0x0EDBA351L,0x0EDBA351L},{0x263E7514L,0x91C5B6A7L,4L},{(-1L),0x201015F6L,(-8L)},{(-1L),0xCCA5A0DBL,(-4L)},{(-1L),0x88854932L,0x32D1446BL},{0x18A72FA4L,0xCCA5A0DBL,0x7DCD3ABDL},{0x263E7514L,0x201015F6L,0x1C26F647L}}};
                int32_t *l_12508 = &g_499[0][0];
                int i, j, k;
                for (g_7825.f0 = 8; (g_7825.f0 > (-19)); g_7825.f0 = safe_sub_func_int8_t_s_s(g_7825.f0, 1))
                { /* block id: 5296 */
                    uint64_t l_12476 = 4UL;
                    for (g_1995.f1 = 25; (g_1995.f1 >= 9); g_1995.f1 = safe_sub_func_int32_t_s_s(g_1995.f1, 8))
                    { /* block id: 5299 */
                        int16_t *l_12488 = (void*)0;
                        int16_t *l_12489 = &g_7297[2][6][3];
                        (*g_11360) ^= ((((*l_12489) = (l_12476 && (safe_div_func_int32_t_s_s((1UL > (l_12433 >= ((((safe_rshift_func_int8_t_s_u(((-6L) < (safe_lshift_func_uint16_t_u_u(l_12440[3], 2))), 3)) ^ (safe_add_func_uint64_t_u_u(l_12485, p_47))) <= ((0xDDCFA3B2L <= (l_12486 == (void*)0)) , p_47)) >= (*****g_5407)))), l_12435[3])))) == l_12485) | 0x7984L);
                    }
                }
                for (g_6572.f3 = (-28); (g_6572.f3 > 26); g_6572.f3 = safe_add_func_int64_t_s_s(g_6572.f3, 8))
                { /* block id: 5306 */
                    struct S0 **l_12497 = &g_6240;
                    struct S0 ***l_12496 = &l_12497;
                    l_12435[3] = p_47;
                    for (g_8583 = (-21); (g_8583 >= 46); g_8583 = safe_add_func_uint64_t_u_u(g_8583, 5))
                    { /* block id: 5310 */
                        (**g_11090) = func_107(l_12494, l_12495, (*l_12400), ((void*)0 != l_12496), (safe_lshift_func_uint16_t_u_s((((p_46 == p_47) > (l_12500 == (g_12501 = g_12501))) || (**g_4423)), p_46)));
                    }
                }
                --l_12509[0];
            }
            (*l_12400) = (1UL != l_12467);
        }
        l_12512 = &l_12435[3];
        (*g_10974) |= (*l_12400);
        if ((~0x2613255DL))
        { /* block id: 5321 */
            uint8_t **l_12514[8][4] = {{&g_656,&g_656,&g_5411,&g_656},{&g_656,&g_656,&g_656,&g_656},{&g_656,&g_656,&g_656,&g_656},{&g_656,&g_656,&g_5411,&g_656},{&g_656,&g_5411,&g_5411,&g_656},{&g_5411,&g_656,&g_5411,&g_5411},{&g_656,&g_656,&g_656,&g_656},{&g_656,&g_5411,&g_5411,&g_656}};
            int i, j;
            l_12514[3][1] = l_12514[7][1];
            for (g_78 = 0; (g_78 < (-3)); g_78 = safe_sub_func_int16_t_s_s(g_78, 7))
            { /* block id: 5325 */
                for (g_6586.f3 = (-18); (g_6586.f3 <= (-10)); g_6586.f3 = safe_add_func_uint64_t_u_u(g_6586.f3, 7))
                { /* block id: 5328 */
                    for (g_8089.f3 = 0; (g_8089.f3 <= 1); g_8089.f3++)
                    { /* block id: 5331 */
                        struct S0 **l_12523 = &g_6240;
                        (*l_12523) = l_12521;
                    }
                }
                (*l_12400) = (!p_47);
                g_6240 = l_12525;
                if (p_45)
                    continue;
            }
        }
        else
        { /* block id: 5339 */
            const union U4 **l_12533 = &g_10755;
            int64_t l_12543[7];
            int32_t *l_12544 = &g_7[2][5][1];
            int16_t l_12561 = 9L;
            int i;
            for (i = 0; i < 7; i++)
                l_12543[i] = 0x545062FE574611BELL;
            for (g_12526.f1 = 1; (g_12526.f1 <= 7); g_12526.f1 += 1)
            { /* block id: 5342 */
                union U4 * const **l_12535[6][2][10] = {{{&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0],&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0]},{&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0],&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0]}},{{&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0],&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0]},{&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0],&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0]}},{{&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0],&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0]},{&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0],&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0]}},{{&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0],&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0]},{&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0],&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0]}},{{&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0],&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0]},{&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0],&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0]}},{{&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0],&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0]},{&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0],&g_4904[0][0],&g_4904[0][0],&l_12534,&l_12534,&g_4904[0][0]}}};
                int32_t *l_12545 = (void*)0;
                int32_t *l_12546 = &g_163;
                uint64_t l_12554 = 0UL;
                const int16_t ***l_12567 = &g_1677[0][1];
                int32_t l_12587 = 0xF0C3056FL;
                int i, j, k;
                (***g_2718) = (l_12546 = (l_12545 = l_12544));
                (*g_10974) ^= ((((safe_lshift_func_int16_t_s_u(1L, 11)) , (((void*)0 == l_12549[0]) || (safe_mod_func_uint16_t_u_u(((((safe_sub_func_int32_t_s_s((l_12555 = (p_47 >= l_12554)), 2L)) | (*l_12512)) > (safe_sub_func_uint32_t_u_u((+(safe_mul_func_uint16_t_u_u(l_12561, (*l_12544)))), (-7L)))) , 0x8F13L), 0x728EL)))) , (*l_12400)) || p_47);
                for (g_8562 = 0; (g_8562 <= 2); g_8562 += 1)
                { /* block id: 5351 */
                    uint8_t l_12574[1];
                    int32_t l_12575 = (-1L);
                    int i;
                    for (i = 0; i < 1; i++)
                        l_12574[i] = 0xD6L;
                    (*g_10974) = 1L;
                    (*l_12400) = ((*l_12512) = (p_45 , ((-1L) < ((*l_12545) ^ (*l_12400)))));
                    for (g_9480 = 2; (g_9480 >= 0); g_9480 -= 1)
                    { /* block id: 5357 */
                        int16_t ****l_12566 = &g_11550[1][1];
                        int i, j, k;
                        if (g_7297[g_8562][g_9480][(g_8562 + 5)])
                            break;
                        l_12587 = ((safe_lshift_func_uint16_t_u_s((((((*l_12566) = (l_12565 = l_12564)) == l_12567) && ((safe_div_func_uint64_t_u_u(((safe_mod_func_uint64_t_u_u(((*l_12400) = (*l_12400)), 5UL)) > ((((l_12575 = (safe_sub_func_int32_t_s_s(((*g_10974) = (l_12574[0] , 1L)), 0x0050D2A1L))) ^ (*l_12544)) < ((~((safe_div_func_int64_t_s_s((safe_div_func_int16_t_s_s(((safe_mod_func_uint32_t_u_u((safe_sub_func_uint16_t_u_u(((!((*p_48) == 1L)) & p_46), p_45)), 4294967295UL)) | p_47), p_46)), 18446744073709551614UL)) && 0x62L)) >= (*l_12544))) ^ l_12586[5][0][0])), 18446744073709551606UL)) , (*l_12512))) == 0xCD7F29489E9AD882LL), p_45)) | (*p_48));
                    }
                    for (g_4502 = 2; (g_4502 <= 9); g_4502 += 1)
                    { /* block id: 5368 */
                        int i, j, k;
                        (*l_12400) = g_7297[g_8562][(g_8562 + 2)][(g_8562 + 6)];
                    }
                    for (g_7256 = 0; (g_7256 <= 2); g_7256 += 1)
                    { /* block id: 5373 */
                        int32_t l_12588 = 0L;
                        int i, j, k;
                        l_12588 = g_7297[g_8562][(g_7256 + 3)][(g_8562 + 1)];
                    }
                }
            }
        }
    }
    (****g_2717) = &l_12258;
    (*l_12591) = l_12589;
    ++l_12607;
    return (*l_12605);
}


/* ------------------------------------------ */
/* 
 * reads : g_8235 g_5490 g_10753 g_10754 g_5408 g_5409 g_5410 g_5411 g_10974 g_656 g_929 g_930 g_3643 g_446 g_66 g_1678 g_232 g_4139 g_657 g_1675 g_1676 g_1677 g_5745 g_5746 g_4422 g_4423 g_28 g_5407 g_255 g_1541 g_11302 g_7633 g_431 g_29 g_3870 g_11314 g_11806 g_1540 g_998 g_4118 g_6586.f3 g_11830 g_1221 g_7297 g_7217 g_11089 g_11090 g_1207 g_4882 g_714 g_715 g_466 g_538 g_2717 g_2718 g_2719 g_653 g_11360 g_499 g_8084.f3 g_1621 g_5749 g_1419 g_6484 g_1674 g_6256 g_11203.f3 g_1351 g_3420 g_1636 g_12051 g_6523 g_2302 g_1168 g_12076 g_6119 g_6882.f3 g_10839.f3 g_1920.f1 g_5213
 * writes: g_11240 g_3870 g_255 g_657 g_7826.f0 g_29 g_998 g_431 g_66 g_6440 g_11027 g_11314 g_6586.f3 g_1221 g_10974 g_653 g_466 g_196 g_3529.f0 g_539 g_4882 g_499 g_6882.f3 g_10839.f3 g_8084.f3 g_6256 g_1070 g_78 g_11203.f3 g_1920.f1 g_1636 g_746 g_1351 g_8242 g_12051 g_5213 g_12076 g_845 g_6575.f3 g_7236.f3 g_1181 g_5490 g_12176 g_3643 g_446
 */
static int32_t  func_50(int8_t * p_51, int32_t * p_52, const int8_t * p_53)
{ /* block id: 4679 */
    int32_t l_11229 = (-4L);
    uint8_t l_11245 = 254UL;
    int32_t l_11246 = (-1L);
    int32_t *****l_11257[10] = {&g_2718,&g_2718,&g_2718,&g_2718,&g_2718,&g_2718,&g_2718,&g_2718,&g_2718,&g_2718};
    uint32_t l_11258 = 0x89FEF026L;
    int32_t l_11264 = 0x316724BFL;
    uint32_t l_11265 = 0x8C714060L;
    int32_t l_11266 = (-5L);
    uint16_t l_11267 = 4UL;
    uint32_t l_11268 = 4294967295UL;
    const int32_t l_11284 = 0xBBDF51A3L;
    int64_t * const *l_11310 = &g_538[2];
    union U2 ** const *l_11312 = &g_8970;
    union U2 ** const **l_11311 = &l_11312;
    int64_t l_11331 = (-7L);
    struct S1 * const *l_11345 = (void*)0;
    const struct S1 **l_11347 = (void*)0;
    union U2 *l_11357 = &g_11358;
    uint8_t ***l_11373 = (void*)0;
    int32_t *****l_11382 = (void*)0;
    int16_t *****l_11426 = &g_4296;
    struct S1 ***l_11431 = (void*)0;
    int32_t l_11432 = (-8L);
    const struct S0 *l_11435 = &g_11436[8][0];
    const struct S0 **l_11434[4][10][3] = {{{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435}},{{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435}},{{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435}},{{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435},{&l_11435,&l_11435,&l_11435}}};
    const struct S0 *** const l_11433 = &l_11434[1][0][1];
    int16_t l_11452 = 0xCF62L;
    union U3 **l_11467 = &g_746;
    uint16_t l_11471 = 65527UL;
    struct S1 ****l_11507 = &l_11431;
    uint64_t l_11553[6][5][2] = {{{0x8B0564AEDDDA84A6LL,0x8B0564AEDDDA84A6LL},{0x6CA8FFB9C69FD7B7LL,0x8B0564AEDDDA84A6LL},{0x8B0564AEDDDA84A6LL,0x6CA8FFB9C69FD7B7LL},{0x8B0564AEDDDA84A6LL,0x8B0564AEDDDA84A6LL},{0x6CA8FFB9C69FD7B7LL,0x8B0564AEDDDA84A6LL}},{{0x8B0564AEDDDA84A6LL,0x6CA8FFB9C69FD7B7LL},{0x8B0564AEDDDA84A6LL,0x8B0564AEDDDA84A6LL},{0x6CA8FFB9C69FD7B7LL,0x8B0564AEDDDA84A6LL},{0x8B0564AEDDDA84A6LL,0x6CA8FFB9C69FD7B7LL},{0x8B0564AEDDDA84A6LL,0x8B0564AEDDDA84A6LL}},{{0x6CA8FFB9C69FD7B7LL,0x8B0564AEDDDA84A6LL},{0x8B0564AEDDDA84A6LL,0x6CA8FFB9C69FD7B7LL},{0x8B0564AEDDDA84A6LL,0x8B0564AEDDDA84A6LL},{0x6CA8FFB9C69FD7B7LL,0x8B0564AEDDDA84A6LL},{0x8B0564AEDDDA84A6LL,0x6CA8FFB9C69FD7B7LL}},{{0x8B0564AEDDDA84A6LL,0x8B0564AEDDDA84A6LL},{0x6CA8FFB9C69FD7B7LL,0x8B0564AEDDDA84A6LL},{0x8B0564AEDDDA84A6LL,0x6CA8FFB9C69FD7B7LL},{0x8B0564AEDDDA84A6LL,0x8B0564AEDDDA84A6LL},{0x6CA8FFB9C69FD7B7LL,0x8B0564AEDDDA84A6LL}},{{0x8B0564AEDDDA84A6LL,0x6CA8FFB9C69FD7B7LL},{0x8B0564AEDDDA84A6LL,0x8B0564AEDDDA84A6LL},{0x6CA8FFB9C69FD7B7LL,0x8B0564AEDDDA84A6LL},{0x8B0564AEDDDA84A6LL,0x6CA8FFB9C69FD7B7LL},{0x8B0564AEDDDA84A6LL,0x8B0564AEDDDA84A6LL}},{{0x6CA8FFB9C69FD7B7LL,0x8B0564AEDDDA84A6LL},{0x8B0564AEDDDA84A6LL,0x6CA8FFB9C69FD7B7LL},{0x8B0564AEDDDA84A6LL,0x8B0564AEDDDA84A6LL},{0x6CA8FFB9C69FD7B7LL,0x8B0564AEDDDA84A6LL},{0x8B0564AEDDDA84A6LL,0x6CA8FFB9C69FD7B7LL}}};
    int8_t ****l_11574 = &g_4422;
    int8_t *****l_11573 = &l_11574;
    uint32_t l_11579 = 0x212E8FB2L;
    int64_t **l_11585[4][8][6] = {{{(void*)0,(void*)0,&g_538[2],&g_6119,&g_538[2],&g_6119},{&g_6119,&g_538[2],&g_538[2],&g_6119,(void*)0,&g_6119},{&g_6119,&g_6119,(void*)0,(void*)0,&g_538[1],(void*)0},{(void*)0,&g_6119,&g_6119,&g_538[2],&g_538[1],(void*)0},{&g_538[2],&g_6119,&g_6119,&g_538[2],(void*)0,&g_6119},{&g_538[2],&g_538[2],(void*)0,&g_6119,&g_538[2],&g_6119},{&g_538[1],(void*)0,(void*)0,&g_6119,&g_6119,&g_538[2]},{(void*)0,&g_538[2],&g_538[2],&g_6119,(void*)0,(void*)0}},{{&g_538[1],(void*)0,&g_6119,&g_6119,&g_6119,&g_6119},{&g_538[2],&g_538[2],&g_6119,&g_6119,&g_6119,&g_6119},{&g_538[1],&g_538[1],&g_538[2],&g_6119,&g_6119,&g_6119},{&g_538[2],&g_538[1],&g_538[2],&g_538[2],&g_6119,&g_6119},{&g_538[0],&g_538[2],&g_6119,&g_538[2],&g_538[2],&g_538[2]},{&g_538[2],&g_538[2],&g_538[2],&g_538[0],&g_538[1],(void*)0},{&g_538[2],&g_6119,&g_538[1],&g_538[2],&g_6119,&g_538[2]},{&g_6119,&g_6119,&g_538[2],&g_538[1],&g_538[1],(void*)0}},{{&g_6119,&g_538[2],(void*)0,&g_6119,&g_538[2],&g_538[2]},{&g_6119,&g_538[2],&g_6119,(void*)0,&g_6119,&g_6119},{&g_6119,&g_538[1],&g_538[2],&g_538[1],&g_6119,&g_538[2]},{&g_6119,&g_538[1],&g_6119,(void*)0,&g_6119,(void*)0},{&g_6119,&g_6119,&g_538[2],&g_6119,&g_6119,&g_538[2]},{&g_6119,&g_538[2],&g_538[2],&g_538[1],&g_538[1],(void*)0},{&g_6119,&g_538[0],&g_6119,&g_538[2],&g_538[2],(void*)0},{&g_538[2],&g_538[1],&g_538[2],&g_538[0],&g_538[0],&g_538[2]}},{{&g_538[2],&g_6119,&g_538[2],&g_538[2],&g_538[2],(void*)0},{&g_538[0],(void*)0,&g_6119,&g_538[2],(void*)0,&g_538[2]},{&g_538[2],&g_6119,&g_538[2],&g_6119,(void*)0,&g_6119},{&g_538[1],(void*)0,&g_6119,&g_6119,&g_538[2],&g_538[2]},{&g_6119,&g_6119,(void*)0,&g_6119,&g_538[0],(void*)0},{(void*)0,&g_538[1],&g_538[2],&g_6119,&g_538[2],&g_538[2]},{&g_538[1],&g_538[0],&g_538[1],&g_6119,&g_538[1],(void*)0},{(void*)0,&g_538[2],&g_538[2],&g_6119,&g_6119,&g_538[2]}}};
    uint32_t * const *l_11587 = &g_930[3][2];
    uint32_t * const ** const l_11586 = &l_11587;
    uint64_t ****l_11591[8] = {&g_3682,&g_3682,&g_3682,&g_3682,&g_3682,&g_3682,&g_3682,&g_3682};
    uint16_t l_11600 = 0xF889L;
    int64_t l_11747[10];
    const union U2 **l_11820 = (void*)0;
    const union U2 *** const l_11819 = &l_11820;
    const union U2 *** const *l_11818 = &l_11819;
    int8_t l_11832 = 0x8CL;
    uint16_t ** const *l_11883 = (void*)0;
    union U2 ***l_11916[8];
    union U5 *l_11924 = &g_11925;
    int16_t l_11929 = (-1L);
    uint64_t l_11933 = 18446744073709551607UL;
    uint32_t **** const *l_12000 = (void*)0;
    uint8_t l_12009 = 0xCDL;
    uint32_t ***l_12079 = &g_4087;
    uint32_t ****l_12078 = &l_12079;
    int32_t l_12086 = 0L;
    int i, j, k;
    for (i = 0; i < 10; i++)
        l_11747[i] = 0xE054DB4BB7E47D55LL;
    for (i = 0; i < 8; i++)
        l_11916[i] = &g_8970;
    (*g_10974) = ((safe_lshift_func_uint16_t_u_s(0xA60DL, 11)) , (l_11229 <= (((safe_div_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u((safe_mul_func_int16_t_s_s((safe_mod_func_uint32_t_u_u((safe_mod_func_int8_t_s_s((&g_7753 != (g_11240 = (void*)0)), ((l_11229 != (0x4E78L && ((safe_rshift_func_uint8_t_u_s((safe_sub_func_int8_t_s_s((*g_8235), ((l_11245 | ((****g_5408) = ((void*)0 == (*g_10753)))) || l_11245))), 2)) && l_11229))) & 18446744073709551611UL))), 0x560EB3F6L)), l_11229)), l_11245)), l_11245)) < 0x1C52398EF6A0D52ALL) || l_11246)));
lbl_12016:
    if (((((safe_add_func_uint64_t_u_u(((safe_rshift_func_uint8_t_u_s((0x8D54L <= (safe_mod_func_uint32_t_u_u((safe_mul_func_int8_t_s_s(l_11245, ((safe_sub_func_uint64_t_u_u(6UL, l_11229)) == (((void*)0 == l_11257[6]) & (((*g_656) = ((*g_5411) = (l_11258 > 0xDAL))) || ((safe_mul_func_int16_t_s_s((l_11265 = (!((safe_mul_func_int16_t_s_s(((((**g_929) & (**g_929)) , (*g_1678)) == 0x88DCL), l_11264)) || (**g_4139)))), (****g_1675))) , 1UL)))))), 0x2DFCF175L))), l_11266)) & l_11267), 0x32B92D26434F6751LL)) , (*g_5745)) == (void*)0) || l_11268))
    { /* block id: 4686 */
        uint32_t l_11269 = 4UL;
        l_11269--;
    }
    else
    { /* block id: 4688 */
        int8_t l_11292 = 0x2EL;
        int32_t l_11293 = 0xA8B6261FL;
        union U2 *l_11297 = (void*)0;
        union U4 *l_11321[7][5] = {{&g_11330,&g_11328,&g_11322[0][3][5],&g_11322[0][3][5],&g_11328},{&g_11325,&g_11323,&g_11327[1][1],&g_11327[1][1],&g_11323},{&g_11330,&g_11328,&g_11322[0][3][5],&g_11322[0][3][5],&g_11328},{&g_11325,&g_11323,&g_11327[1][1],&g_11327[1][1],&g_11323},{&g_11330,&g_11328,&g_11322[0][3][5],&g_11322[0][3][5],&g_11328},{&g_11325,&g_11323,&g_11327[1][1],&g_11327[1][1],&g_11323},{&g_11330,&g_11328,&g_11322[0][3][5],&g_11322[0][3][5],&g_11328}};
        int32_t l_11342 = 8L;
        struct S1 * const **l_11346 = &l_11345;
        uint8_t l_11348 = 0x89L;
        union U2 * const ***l_11350 = (void*)0;
        union U2 * const **** const l_11349[7][4] = {{&l_11350,&l_11350,&l_11350,&l_11350},{&l_11350,&l_11350,&l_11350,&l_11350},{&l_11350,&l_11350,&l_11350,&l_11350},{&l_11350,(void*)0,&l_11350,&l_11350},{&l_11350,&l_11350,&l_11350,(void*)0},{&l_11350,&l_11350,&l_11350,&l_11350},{&l_11350,(void*)0,&l_11350,&l_11350}};
        const int16_t l_11351 = 0L;
        int32_t *l_11353 = &g_255;
        uint16_t l_11393 = 0x150AL;
        uint8_t l_11488 = 0x7CL;
        union U3 **l_11527 = (void*)0;
        uint16_t **l_11543[2];
        int16_t ***l_11551 = &g_1030[0][0];
        int8_t l_11552 = 0x33L;
        union U5 ****l_11558 = &g_6483;
        int64_t **l_11583 = (void*)0;
        uint32_t ** const *l_11588 = &g_929;
        uint64_t **l_11662 = &g_4583[4];
        int32_t l_11675 = 1L;
        int32_t l_11676 = 0xA0281F26L;
        int32_t l_11679[10][8] = {{1L,0xD1DE78A7L,0xBB3D8118L,(-1L),0x5442D233L,0x289D668BL,0xA2FC9135L,0xD1DE78A7L},{(-7L),(-8L),0xBB3D8118L,0xA89818C1L,0xBB3D8118L,(-8L),(-7L),0x289D668BL},{0x5442D233L,1L,9L,0xA89818C1L,(-7L),(-2L),0x2AA0D33CL,0xD1DE78A7L},{1L,0xA89818C1L,0xA2FC9135L,(-1L),(-7L),(-1L),0xA2FC9135L,0xA89818C1L},{0x5442D233L,(-8L),1L,0xD1DE78A7L,0xBB3D8118L,(-1L),0x5442D233L,0x289D668BL},{(-7L),0xA89818C1L,9L,1L,0x5442D233L,(-2L),0x5442D233L,1L},{1L,1L,1L,(-1L),0x2AA0D33CL,(-8L),0xA2FC9135L,1L},{0x2AA0D33CL,(-8L),0xA2FC9135L,1L,0xBB3D8118L,0x289D668BL,0x2AA0D33CL,0x289D668BL},{0x2AA0D33CL,0xD1DE78A7L,9L,0xD1DE78A7L,0x2AA0D33CL,(-2L),(-7L),0xA89818C1L},{1L,0xD1DE78A7L,0xBB3D8118L,(-1L),0x5442D233L,0x289D668BL,0xA2FC9135L,0xD1DE78A7L}};
        uint8_t l_11680[8] = {0xD4L,0x38L,0xD4L,0x38L,0xD4L,0x38L,0xD4L,0x38L};
        int64_t *l_11709[3];
        const uint8_t l_11746 = 0x11L;
        uint8_t l_11796 = 0xFCL;
        int i, j;
        for (i = 0; i < 2; i++)
            l_11543[i] = &g_715;
        for (i = 0; i < 3; i++)
            l_11709[i] = (void*)0;
        for (g_7826.f0 = (-21); (g_7826.f0 <= 1); ++g_7826.f0)
        { /* block id: 4691 */
            union U2 ****l_11280[10][2][6] = {{{&g_9882,&g_9882,&g_9882,&g_9882,&g_9882,&g_9882},{&g_9882,&g_9882,&g_9882,(void*)0,&g_9882,&g_9882}},{{&g_9882,(void*)0,&g_9882,&g_9882,&g_9882,(void*)0},{&g_9882,&g_9882,&g_9882,&g_9882,(void*)0,&g_9882}},{{&g_9882,&g_9882,&g_9882,(void*)0,(void*)0,(void*)0},{(void*)0,&g_9882,(void*)0,&g_9882,(void*)0,&g_9882}},{{&g_9882,(void*)0,&g_9882,(void*)0,&g_9882,(void*)0},{&g_9882,&g_9882,(void*)0,(void*)0,&g_9882,(void*)0}},{{(void*)0,(void*)0,&g_9882,&g_9882,&g_9882,&g_9882},{&g_9882,&g_9882,(void*)0,&g_9882,&g_9882,(void*)0}},{{(void*)0,&g_9882,&g_9882,&g_9882,&g_9882,&g_9882},{(void*)0,&g_9882,&g_9882,&g_9882,&g_9882,(void*)0}},{{&g_9882,(void*)0,&g_9882,(void*)0,&g_9882,&g_9882},{&g_9882,&g_9882,&g_9882,&g_9882,&g_9882,&g_9882}},{{&g_9882,&g_9882,&g_9882,(void*)0,(void*)0,(void*)0},{&g_9882,&g_9882,&g_9882,&g_9882,(void*)0,&g_9882}},{{&g_9882,&g_9882,&g_9882,(void*)0,&g_9882,(void*)0},{&g_9882,(void*)0,&g_9882,&g_9882,(void*)0,&g_9882}},{{(void*)0,(void*)0,&g_9882,&g_9882,(void*)0,&g_9882},{&g_9882,&g_9882,(void*)0,&g_9882,&g_9882,(void*)0}}};
            int32_t l_11287 = (-1L);
            union U2 ****l_11294[4][8] = {{&g_9882,&g_9882,(void*)0,&g_9882,&g_9882,&g_9882,&g_9882,&g_9882},{&g_9882,&g_9882,&g_9882,&g_9882,&g_9882,&g_9882,&g_9882,&g_9882},{&g_9882,&g_9882,&g_9882,&g_9882,&g_9882,&g_9882,&g_9882,&g_9882},{&g_9882,&g_9882,(void*)0,&g_9882,&g_9882,(void*)0,&g_9882,&g_9882}};
            int32_t l_11305 = (-6L);
            int64_t ***l_11308 = (void*)0;
            int64_t ***l_11309 = &g_6440;
            union U2 ** const ***l_11313 = &g_11027[4];
            int i, j, k;
            if (((safe_add_func_uint64_t_u_u((safe_mul_func_uint16_t_u_u(((safe_div_func_int16_t_s_s(0xE40CL, ((((l_11280[7][1][1] != ((~(l_11293 &= (safe_sub_func_int16_t_s_s(((l_11284 , ((safe_lshift_func_int8_t_s_s(((***g_4422) = l_11287), ((safe_rshift_func_int8_t_s_s((((***g_1676) , 65535UL) > (((safe_div_func_uint8_t_u_u(((*****g_5407) = l_11292), (l_11287 ^ (l_11292 || l_11292)))) != l_11287) && (-1L))), 7)) || l_11292))) <= 0x4AL)) | l_11287), 65530UL)))) , l_11294[0][1])) <= 0xF2L) , 5UL) && (*p_52)))) || 0UL), l_11292)), l_11287)) & l_11292))
            { /* block id: 4695 */
                return (*p_52);
            }
            else
            { /* block id: 4697 */
                if ((*g_10974))
                    break;
            }
            (*p_52) &= (((l_11287 ^ (safe_mul_func_int16_t_s_s((l_11305 ^= ((l_11297 != l_11297) , (((*g_1541) = l_11287) , (((*g_7633) &= (safe_div_func_int16_t_s_s(l_11293, (safe_lshift_func_uint16_t_u_s((0x4212L != g_11302), (safe_mul_func_uint16_t_u_u((0xD8341247L <= l_11293), (*g_1678)))))))) <= (***g_4422))))), (-1L)))) , l_11292) >= l_11287);
            l_11305 = ((((*l_11309) = (void*)0) == ((*****g_5407) , l_11310)) || (((*l_11313) = (l_11311 = l_11311)) == &l_11312));
            ++g_11314;
        }
    }
    for (g_6586.f3 = 6; (g_6586.f3 >= 0); g_6586.f3 -= 1)
    { /* block id: 4967 */
        const union U2 *** const *l_11817[10];
        int32_t l_11829 = 0xE8A346F4L;
        uint8_t l_11881 = 5UL;
        int32_t l_11903 = (-9L);
        union U2 ***l_11915 = (void*)0;
        union U5 * const l_11926 = &g_11927;
        union U3 ***l_11959 = (void*)0;
        union U3 ****l_11958 = &l_11959;
        int16_t *l_11967 = &g_6045;
        uint8_t l_11970 = 0xD3L;
        int32_t l_12003 = (-3L);
        union U4 *l_12054 = &g_12055;
        int32_t l_12062 = 0x0F86D1D7L;
        int32_t l_12063 = 0x60E8081FL;
        int32_t l_12065 = 0x2F0EFD90L;
        int32_t l_12067 = 0xEC9659D3L;
        int32_t l_12068[8] = {0xC48DBFCDL,0xC48DBFCDL,0xC48DBFCDL,0xC48DBFCDL,0xC48DBFCDL,0xC48DBFCDL,0xC48DBFCDL,0xC48DBFCDL};
        int32_t l_12115 = 0xCE452D41L;
        uint64_t l_12116 = 18446744073709551608UL;
        union U2 ***l_12135 = &g_8970;
        union U2 ***l_12136 = &g_8970;
        union U2 ***l_12137[10] = {&g_8970,&g_8970,&g_8970,&g_8970,&g_8970,&g_8970,&g_8970,&g_8970,&g_8970,&g_8970};
        union U2 ***l_12138 = &g_8970;
        union U2 ***l_12139 = &g_8970;
        union U2 ***l_12140 = &g_8970;
        union U2 ***l_12141[8];
        union U2 ***l_12142 = &g_8970;
        union U2 ***l_12143 = &g_8970;
        union U2 ***l_12144 = (void*)0;
        union U2 ***l_12145 = (void*)0;
        union U2 ***l_12146 = (void*)0;
        union U2 ***l_12147 = &g_8970;
        union U2 ***l_12148 = &g_8970;
        union U2 **** const l_12134[9][3][9] = {{{&l_12146,&l_12145,&l_12146,&l_12135,(void*)0,(void*)0,(void*)0,&l_12147,&l_12144},{&l_12139,&l_12146,&l_12140,&l_12137[4],&l_12148,&l_12147,&l_12148,&l_12137[4],&l_12140},{&l_12144,&l_12144,&l_12145,&l_12135,&l_12139,&l_12146,&l_12140,&l_12137[4],&l_12148}},{{(void*)0,(void*)0,&l_12147,&l_12144,&l_12142,&l_12142,&l_12144,&l_12147,(void*)0},{&l_12142,&l_12143,&l_12145,&l_12136,&l_12141[6],&l_12135,&l_12144,&l_12140,(void*)0},{&l_12137[4],(void*)0,&l_12140,(void*)0,&l_12138,(void*)0,&l_12140,(void*)0,&l_12137[4]}},{{&l_12141[6],&l_12143,&l_12146,&l_12138,&l_12144,(void*)0,&l_12148,&l_12145,(void*)0},{&l_12143,(void*)0,&l_12135,&l_12147,&l_12147,&l_12135,(void*)0,&l_12143,&l_12136},{&l_12141[6],&l_12144,&l_12148,&l_12139,&l_12147,&l_12142,(void*)0,&l_12138,&l_12138}},{{&l_12137[4],&l_12146,&l_12144,&l_12143,&l_12144,&l_12146,&l_12137[4],&l_12142,&l_12136},{&l_12142,&l_12145,&l_12137[4],&l_12143,&l_12138,&l_12147,(void*)0,&l_12144,(void*)0},{(void*)0,&l_12141[6],&l_12139,&l_12139,&l_12141[6],(void*)0,&l_12136,&l_12142,&l_12143}},{{&l_12137[4],&l_12140,&l_12146,&l_12139,&l_12135,&l_12145,&l_12144,&l_12144,&l_12145},{&l_12146,&l_12144,&l_12143,&l_12144,&l_12146,&l_12137[4],&l_12142,&l_12136,(void*)0},{(void*)0,&l_12144,&l_12137[4],(void*)0,&l_12140,(void*)0,&l_12138,(void*)0,&l_12140}},{{&l_12142,&l_12140,&l_12140,&l_12142,&l_12145,&l_12137[4],&l_12143,&l_12138,&l_12147},{&l_12142,&l_12148,&l_12141[6],&l_12137[4],&l_12147,&l_12145,&l_12145,&l_12147,&l_12137[4]},{(void*)0,(void*)0,(void*)0,&l_12141[6],&l_12145,&l_12138,(void*)0,&l_12139,&l_12137[4]}},{{&l_12146,(void*)0,&l_12147,&l_12143,&l_12140,&l_12139,&l_12140,&l_12143,&l_12147},{&l_12137[4],&l_12137[4],(void*)0,&l_12141[6],&l_12146,(void*)0,&l_12147,&l_12143,&l_12140},{&l_12138,(void*)0,&l_12139,&l_12137[4],&l_12135,&l_12135,&l_12137[4],&l_12139,(void*)0}},{{&l_12135,&l_12136,(void*)0,&l_12142,&l_12148,&l_12141[6],&l_12137[4],&l_12147,&l_12145},{&l_12143,&l_12138,&l_12147,(void*)0,&l_12144,(void*)0,&l_12147,&l_12138,&l_12143},{&l_12148,&l_12136,(void*)0,&l_12144,&l_12137[4],(void*)0,&l_12140,(void*)0,&l_12138}},{{&l_12136,(void*)0,&l_12141[6],&l_12139,&l_12139,&l_12141[6],(void*)0,&l_12136,&l_12142},{&l_12148,&l_12137[4],&l_12140,&l_12146,&l_12139,&l_12135,&l_12145,&l_12144,&l_12144},{&l_12143,(void*)0,&l_12137[4],&l_12136,&l_12137[4],(void*)0,&l_12143,&l_12135,&l_12142}}};
        union U2 **** const *l_12133 = &l_12134[5][0][4];
        int32_t ***l_12174 = &g_1207;
        int i, j, k;
        for (i = 0; i < 10; i++)
            l_11817[i] = (void*)0;
        for (i = 0; i < 8; i++)
            l_12141[i] = &g_8970;
        for (g_66 = 0; (g_66 <= 7); g_66 += 1)
        { /* block id: 4970 */
            uint32_t *****l_11808 = &g_11807[2][0];
            int32_t l_11831 = (-1L);
            int32_t l_11843 = 0x6E9813F2L;
            int32_t l_11844 = 0x4C53D08FL;
            int32_t l_11846[5][5] = {{0x3E28355AL,0x3E28355AL,0xBE9966B7L,0xBE9966B7L,0x3E28355AL},{(-7L),1L,(-7L),1L,(-7L)},{0x3E28355AL,0xBE9966B7L,0xBE9966B7L,0x3E28355AL,0x3E28355AL},{4L,1L,4L,1L,4L},{0x3E28355AL,0x3E28355AL,0xBE9966B7L,0xBE9966B7L,0x3E28355AL}};
            uint8_t l_11868[5];
            int16_t l_11870 = 1L;
            int64_t l_11902[9][2][8] = {{{0L,(-5L),(-4L),(-5L),0L,2L,(-4L),2L},{0L,2L,(-4L),2L,0L,(-5L),(-4L),(-5L)}},{{0L,(-5L),(-4L),(-5L),0L,2L,(-4L),2L},{0L,2L,(-4L),2L,0L,(-5L),(-4L),(-5L)}},{{0L,(-5L),(-4L),(-5L),0L,2L,(-4L),2L},{0L,2L,(-4L),2L,0L,(-5L),(-4L),(-5L)}},{{0L,(-5L),(-4L),(-5L),0L,2L,(-4L),2L},{0L,2L,(-4L),2L,0L,(-5L),(-4L),(-5L)}},{{0L,(-5L),(-4L),(-5L),0L,2L,(-4L),2L},{0L,2L,(-4L),2L,0L,(-5L),(-4L),(-5L)}},{{0L,(-5L),(-4L),(-5L),0L,2L,(-4L),2L},{0L,2L,(-4L),2L,0L,(-5L),(-4L),(-5L)}},{{0L,(-5L),(-4L),(-5L),0L,2L,(-4L),2L},{0L,2L,(-4L),2L,0L,(-5L),(-4L),(-5L)}},{{0L,(-5L),(-4L),(-5L),0L,2L,(-4L),2L},{0L,2L,(-4L),2L,0L,(-5L),(-4L),(-5L)}},{{0L,(-5L),(-4L),(-5L),0L,2L,(-4L),2L},{0L,2L,(-4L),2L,0L,(-5L),(-4L),(-5L)}}};
            int i, j, k;
            for (i = 0; i < 5; i++)
                l_11868[i] = 0x23L;
            if ((safe_mul_func_int16_t_s_s((safe_div_func_int32_t_s_s((l_11831 = ((((void*)0 == &g_6440) , (safe_lshift_func_int8_t_s_s((((!(((((l_11808 = g_11806) != (void*)0) == ((**g_1540)--)) ^ (0x1384AB8BL < ((safe_mul_func_int16_t_s_s((safe_sub_func_int16_t_s_s(g_4118[g_66], (&l_11312 != (l_11818 = l_11817[6])))), (safe_sub_func_uint32_t_u_u((((safe_mod_func_int32_t_s_s((safe_rshift_func_int8_t_s_s(((g_4118[g_66] || g_4118[g_6586.f3]) && g_4118[g_66]), 2)), l_11829)) != 0L) <= 1L), g_11830)))) < g_4118[g_66]))) || (-9L))) , 18446744073709551615UL) & 1UL), 3))) != 0x64L)), 1L)), l_11832)))
            { /* block id: 4975 */
                int32_t * const l_11833 = &g_4882;
                union U3 ***l_11840 = &l_11467;
                union U3 ****l_11839 = &l_11840;
                uint16_t l_11848 = 0xBBB6L;
                for (g_1221 = 0; (g_1221 <= 2); g_1221 += 1)
                { /* block id: 4978 */
                    int32_t **l_11834 = &g_10974;
                    int32_t l_11847 = (-1L);
                    int64_t l_11859 = 0x2F1621FD04B7D1BALL;
                    uint32_t l_11869[5] = {0x0FBFFC1CL,0x0FBFFC1CL,0x0FBFFC1CL,0x0FBFFC1CL,0x0FBFFC1CL};
                    int i, j, k;
                    (*l_11834) = l_11833;
                    if (((safe_mul_func_uint8_t_u_u((safe_mod_func_uint8_t_u_u(((void*)0 == l_11839), (g_7297[g_1221][(g_1221 + 2)][(g_1221 + 7)] ^ g_7297[g_1221][g_6586.f3][g_66]))), g_7217[(g_1221 + 1)][(g_1221 + 2)])) >= 0x8564L))
                    { /* block id: 4980 */
                        int32_t *l_11841 = (void*)0;
                        int32_t l_11842 = (-3L);
                        int32_t l_11845[6][5];
                        int i, j;
                        for (i = 0; i < 6; i++)
                        {
                            for (j = 0; j < 5; j++)
                                l_11845[i][j] = 0L;
                        }
                        p_52 = ((***g_11089) = l_11841);
                        l_11848--;
                        if (g_7217[g_1221][(g_1221 + 3)])
                            continue;
                        (*g_10974) = (l_11829 ^= (((safe_sub_func_int8_t_s_s(g_7217[g_1221][g_1221], (safe_sub_func_int64_t_s_s(g_7217[g_1221][(g_1221 + 2)], 18446744073709551606UL)))) <= ((((((--(*g_1541)) && (**g_1540)) | ((**l_11834) && ((*l_11833) != ((**g_714)++)))) || (safe_lshift_func_int8_t_s_s((((((**l_11834) != (safe_rshift_func_uint8_t_u_u((safe_add_func_int64_t_s_s(l_11868[0], ((**l_11310) = l_11846[3][3]))), g_4118[g_6586.f3]))) , l_11843) < (*l_11833)) || (**l_11834)), 6))) == g_4118[g_66]) & l_11843)) , l_11869[4]));
                    }
                    else
                    { /* block id: 4990 */
                        uint16_t l_11875 = 0x1CB1L;
                        int32_t l_11876 = (-9L);
                        (****g_2717) = &l_11829;
                        (**g_1207) = (((l_11870 && ((safe_add_func_uint64_t_u_u((safe_sub_func_uint64_t_u_u((l_11876 = l_11875), ((safe_sub_func_int8_t_s_s(0x09L, 1UL)) == (0xAB6EL <= (safe_add_func_int8_t_s_s(l_11868[4], (l_11868[0] != (((*l_11833) == ((**l_11834) && (***g_4422))) | (*l_11833))))))))), l_11875)) > l_11875)) <= l_11875) > (*l_11833));
                    }
                }
                return g_4118[g_6586.f3];
            }
            else
            { /* block id: 4997 */
                uint8_t l_11887 = 0UL;
                (*g_11360) &= (*p_52);
                for (g_6882.f3 = 6; (g_6882.f3 >= 0); g_6882.f3 -= 1)
                { /* block id: 5001 */
                    return l_11881;
                }
                for (g_10839.f3 = 4; (g_10839.f3 >= 0); g_10839.f3 -= 1)
                { /* block id: 5006 */
                    int8_t l_11885 = (-2L);
                    if (l_11829)
                        break;
                    for (g_8084.f3 = 0; (g_8084.f3 <= 5); g_8084.f3 += 1)
                    { /* block id: 5010 */
                        int32_t l_11882 = 0x586C5EF6L;
                        uint16_t ** const **l_11884 = &l_11883;
                        int i;
                        l_11882 ^= (0UL != g_1621[g_8084.f3]);
                        if ((*p_52))
                            continue;
                        if ((*p_52))
                            continue;
                        (*l_11884) = l_11883;
                    }
                    l_11903 ^= (((l_11885 |= (g_4118[g_6586.f3] & (**g_4423))) == l_11881) && (l_11829 , (+((**l_11310) = ((--l_11887) > (safe_div_func_uint16_t_u_u((((*g_5749) <= (safe_sub_func_int16_t_s_s((l_11885 == ((((safe_div_func_uint8_t_u_u((safe_add_func_uint64_t_u_u((((*g_8235) & (safe_mod_func_int16_t_s_s((5L | ((safe_rshift_func_int8_t_s_s(((***g_4422) = l_11885), 3)) < 0x8935F9D017491BA4LL)), l_11846[0][1]))) > 9L), 0x2415339E1F7ED837LL)), (*****g_5407))) & l_11885) , g_4118[g_66]) | l_11829)), 5L))) <= l_11902[4][0][0]), l_11844)))))));
                    (**g_11090) = p_52;
                }
            }
            return (*p_52);
        }
        for (g_6256 = 0; (g_6256 <= 2); g_6256 += 1)
        { /* block id: 5028 */
            int64_t l_11928 = 0x5A90F39822B79594LL;
            int32_t l_11931[5][8] = {{0L,0xC0F6CF9CL,(-2L),0xD1481052L,(-2L),0xC0F6CF9CL,0L,0L},{0xC0F6CF9CL,0xD1481052L,1L,1L,0xD1481052L,0xC0F6CF9CL,0x5D7DA034L,0xC0F6CF9CL},{0xD1481052L,0xC0F6CF9CL,0x5D7DA034L,0xC0F6CF9CL,0xD1481052L,1L,1L,0xD1481052L},{0xC0F6CF9CL,0L,0L,0xC0F6CF9CL,(-2L),0xD1481052L,(-2L),0xC0F6CF9CL},{0L,(-2L),0L,1L,0x5D7DA034L,0x5D7DA034L,1L,0L}};
            const int8_t l_11954 = 0x36L;
            int64_t ****l_11985 = (void*)0;
            uint32_t l_12001 = 1UL;
            union U4 ****l_12014 = &g_6523;
            union U4 *****l_12013 = &l_12014;
            int32_t *l_12057 = &l_11931[0][1];
            uint32_t l_12073 = 0x697253F2L;
            int8_t l_12162 = 0L;
            int32_t ***l_12175 = (void*)0;
            int64_t l_12194 = 0xA128F7613724E75DLL;
            int i, j;
            if ((g_4118[g_6586.f3] , (safe_mul_func_uint8_t_u_u((l_11829 , (0x676669F1L & ((((safe_lshift_func_int8_t_s_u((!(safe_div_func_int64_t_s_s(0L, 9L))), 1)) , (safe_mul_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u((((l_11916[2] = l_11915) != (*l_11311)) , (safe_sub_func_uint16_t_u_u((safe_mod_func_int16_t_s_s(((+(l_11903 , (safe_lshift_func_uint8_t_u_u((((*g_6484) = l_11924) != l_11926), 5)))) <= g_4118[g_6586.f3]), 0x5B69L)), l_11881))), l_11928)), l_11929))) & l_11928) > 0x4BL))), g_4118[g_6586.f3]))))
            { /* block id: 5031 */
                int16_t l_11930 = 0x214BL;
                int32_t l_11932[3];
                int i;
                for (i = 0; i < 3; i++)
                    l_11932[i] = 0L;
                if ((*g_11360))
                    break;
                l_11933++;
                (*g_10974) |= ((void*)0 == (**g_1676));
            }
            else
            { /* block id: 5035 */
                uint32_t l_11939 = 4294967295UL;
                int16_t *l_11955 = &g_78;
                int32_t l_11969 = 1L;
                int32_t l_12005 = (-1L);
                uint8_t l_12006 = 255UL;
                (*p_52) = (*p_52);
                if (((safe_unary_minus_func_int8_t_s(((0xE562L <= (safe_add_func_int32_t_s_s(l_11939, ((g_4118[g_6586.f3] && (l_11939 , (safe_mul_func_uint16_t_u_u((**g_714), ((*l_11955) = ((safe_add_func_uint32_t_u_u(((0x46L ^ ((((((l_11931[3][5] = ((void*)0 == &g_9693[2])) , (((safe_rshift_func_int8_t_s_u((safe_div_func_int8_t_s_s(((safe_sub_func_uint8_t_u_u(((safe_mod_func_int16_t_s_s((((safe_add_func_uint64_t_u_u(0xC3FB90A448C3B632LL, l_11939)) || l_11931[4][5]) || l_11931[3][5]), l_11903)) | (***g_4422)), (**g_4423))) > l_11954), l_11954)), 1)) ^ l_11928) , g_4118[g_6586.f3])) > l_11939) >= (*p_52)) | l_11939) ^ l_11881)) <= l_11881), l_11939)) >= l_11928)))))) && l_11939)))) <= 4294967291UL))) > 1L))
                { /* block id: 5039 */
                    uint64_t l_11962 = 0xF8070F5B32632682LL;
                    int16_t *l_11968 = (void*)0;
                    int32_t l_12002 = 0x3ED52C55L;
                    int32_t l_12004[8] = {(-1L),(-1L),0x6AEEC5F2L,(-1L),(-1L),0x6AEEC5F2L,(-1L),(-1L)};
                    int i;
                    if ((((safe_add_func_int16_t_s_s((((((0x9CF2L | (l_11958 == (void*)0)) && l_11939) <= ((*g_715) |= (safe_mul_func_int8_t_s_s((***g_4422), l_11962)))) , ((l_11969 = (safe_div_func_uint32_t_u_u((((((((((**g_714) = 1UL) < (l_11931[3][5] , (safe_sub_func_int8_t_s_s(((l_11967 == l_11968) | 1UL), 0xE3L)))) < (****g_1675)) >= (*****g_1674)) || 0xDC7C8D2BBDAAFA3DLL) >= (-1L)) & l_11903) >= l_11881), l_11962))) ^ l_11931[3][5])) | l_11903), l_11970)) , (void*)0) == p_51))
                    { /* block id: 5043 */
                        const int16_t *l_11971 = (void*)0;
                        uint32_t *l_11976 = &g_10267;
                        int i;
                        (***g_11089) = p_52;
                        if ((*p_52))
                            break;
                    }
                    else
                    { /* block id: 5046 */
                        int8_t l_11986 = 0x15L;
                        int32_t l_11987[7];
                        int i;
                        for (i = 0; i < 7; i++)
                            l_11987[i] = (-1L);
                        l_11987[1] = (((((safe_add_func_int64_t_s_s(((safe_mul_func_uint8_t_u_u((safe_sub_func_uint8_t_u_u(l_11962, 5L)), ((safe_lshift_func_uint16_t_u_s((((l_11985 != &g_6439[0][2]) != l_11931[1][3]) , (l_11969 >= l_11986)), 7)) >= l_11928))) ^ (0xB86EL != (-10L))), 0xF436AE7AE1F11B1CLL)) | l_11928) >= 1L) == l_11970) != l_11903);
                        (*g_11360) = ((*p_52) = (l_11962 <= ((safe_div_func_int8_t_s_s((safe_mul_func_uint16_t_u_u(((*p_52) , l_11931[3][5]), (safe_sub_func_uint64_t_u_u((safe_mod_func_int64_t_s_s(0x8E41F8D51401A3D2LL, l_11939)), (((-5L) != (safe_sub_func_int8_t_s_s(((safe_rshift_func_int8_t_s_s(l_11829, l_11954)) >= l_11962), l_11928))) && (*p_52)))))), 0x98L)) < 0x5731L)));
                    }
                    for (g_11203.f3 = 1; (g_11203.f3 <= 6); g_11203.f3 += 1)
                    { /* block id: 5053 */
                        int i, j, k;
                        l_12000 = l_12000;
                        l_12001 &= g_7297[g_6256][g_11203.f3][(g_6256 + 7)];
                        (*p_52) = (-6L);
                        return (*p_52);
                    }
                    --l_12006;
                }
                else
                { /* block id: 5060 */
                    uint64_t l_12010 = 0UL;
                    l_12009 ^= l_11829;
                    if ((*p_52))
                        continue;
                    for (g_1920.f1 = 0; (g_1920.f1 <= 0); g_1920.f1 += 1)
                    { /* block id: 5065 */
                        if ((*p_52))
                            break;
                        ++l_12010;
                        (*g_11360) = 0xDEF4F656L;
                    }
                }
                if (l_11931[0][3])
                    continue;
                l_12013 = (void*)0;
            }
            for (g_1636 = 0; (g_1636 <= 2); g_1636 += 1)
            { /* block id: 5076 */
                struct S1 *****l_12015 = &l_11507;
                int64_t l_12017[5] = {0xDA7BA17BAE760B89LL,0xDA7BA17BAE760B89LL,0xDA7BA17BAE760B89LL,0xDA7BA17BAE760B89LL,0xDA7BA17BAE760B89LL};
                int32_t *l_12043[8][10][3] = {{{&g_11302,&g_499[0][0],&g_255},{&l_11931[2][3],(void*)0,&l_11829},{&l_11931[0][3],&g_163,&l_11432},{&g_255,&l_11264,(void*)0},{&l_11829,&l_11264,&g_499[0][0]},{&l_11931[3][7],&g_163,&g_3},{&g_3,&g_3307,&l_11432},{&g_163,(void*)0,&l_11264},{&g_11124,&l_11229,&g_499[2][0]},{&g_11302,(void*)0,&g_11302}},{{&g_499[0][0],&g_3307,&l_11903},{&g_11124,&l_11229,&l_11931[2][4]},{(void*)0,&l_11264,&g_4882},{&g_3307,&l_11264,&l_11264},{&l_12003,&l_11229,(void*)0},{&g_3420[2],&g_3307,(void*)0},{(void*)0,(void*)0,(void*)0},{&g_255,&l_11229,&g_3420[0]},{&l_11432,(void*)0,&g_255},{(void*)0,&g_3307,&l_11931[2][5]}},{{(void*)0,&l_11229,&g_3420[3]},{&g_255,&l_11264,&g_499[0][0]},{&l_11829,&l_11264,&g_3307},{&g_499[1][0],&l_11229,&g_7[2][5][2]},{&g_11302,&g_3307,&g_7[0][3][2]},{&g_11830,(void*)0,&l_11229},{&g_7[2][5][1],&l_11229,&g_499[0][0]},{&l_12003,(void*)0,(void*)0},{&l_11264,&g_3307,&g_7[6][6][2]},{&g_3307,&l_11229,(void*)0}},{{&g_3420[2],&l_11264,&g_11124},{&g_255,&l_11264,(void*)0},{(void*)0,&l_11229,&l_11264},{&g_3,&g_3307,&l_11432},{&g_163,(void*)0,&l_11264},{&g_11124,&l_11229,&g_499[2][0]},{&g_11302,(void*)0,&g_11302},{&g_499[0][0],&g_3307,&l_11903},{&g_11124,&l_11229,&l_11931[2][4]},{(void*)0,&l_11264,&g_4882}},{{&g_3307,&l_11264,&l_11264},{&l_12003,&l_11229,(void*)0},{&g_3420[2],&g_3307,(void*)0},{(void*)0,(void*)0,(void*)0},{&g_255,&l_11229,&g_3420[0]},{&l_11432,(void*)0,&g_255},{(void*)0,&g_3307,&l_11931[2][5]},{(void*)0,&l_11229,&g_3420[3]},{&g_255,&l_11264,&g_499[0][0]},{&l_11829,&l_11264,&g_3307}},{{&g_499[1][0],&l_11229,&g_7[2][5][2]},{&g_11302,&g_3307,&g_7[0][3][2]},{&g_11830,(void*)0,&l_11229},{&g_7[2][5][1],&l_11229,&g_499[0][0]},{&l_12003,(void*)0,(void*)0},{&l_11264,&g_3307,&g_7[6][6][2]},{&g_3307,&l_11229,(void*)0},{&g_3420[2],&l_11264,&g_11124},{&g_255,&l_11264,(void*)0},{(void*)0,&l_11229,&l_11264}},{{&g_3,&g_3307,&l_11432},{&g_163,(void*)0,&l_11264},{&g_11124,&l_11229,&g_499[2][0]},{&g_11302,(void*)0,&g_11302},{&g_499[0][0],&g_3307,&l_11903},{&g_11124,&l_11229,&l_11931[2][4]},{(void*)0,&l_11264,&g_4882},{&g_3307,&l_11264,&l_11264},{&l_12003,&l_11229,(void*)0},{&g_3420[2],&g_3307,&l_11931[2][3]}},{{(void*)0,&g_7[2][5][1],&g_11302},{(void*)0,&g_8779,&l_11931[3][5]},{(void*)0,&g_7[2][5][1],&l_11931[3][5]},{&g_3307,&l_11903,&g_163},{&l_11432,&g_8779,&g_11302},{&g_499[2][0],&g_255,(void*)0},{&g_7[6][6][2],&g_255,&l_11903},{&g_4882,&g_8779,&g_7[3][3][2]},{(void*)0,&l_11903,&g_3},{&l_11264,&g_7[2][5][1],&g_8779}}};
                int i, j, k;
                (*l_11467) = (void*)0;
                (*g_11360) ^= (l_12015 != &g_7753);
                for (g_1351 = 0; (g_1351 <= 2); g_1351 += 1)
                { /* block id: 5081 */
                    uint32_t l_12026 = 18446744073709551614UL;
                    int32_t l_12039 = 0xE97B524FL;
                    int64_t * const l_12042[2][10][1] = {{{&g_9622.f0},{&l_11747[2]},{&g_9622.f0},{&g_5761},{(void*)0},{&g_5761},{&g_9622.f0},{&l_11747[2]},{&g_9622.f0},{&g_5761}},{{(void*)0},{&g_5761},{&g_9622.f0},{&l_11747[2]},{&g_9622.f0},{&g_5761},{(void*)0},{&g_5761},{&g_9622.f0},{&l_11747[2]}}};
                    int32_t l_12060[8][2];
                    uint32_t l_12070[10] = {0x8BFB88C5L,0x8BFB88C5L,0x8BFB88C5L,0x8BFB88C5L,0x8BFB88C5L,0x8BFB88C5L,0x8BFB88C5L,0x8BFB88C5L,0x8BFB88C5L,0x8BFB88C5L};
                    int i, j, k;
                    for (i = 0; i < 8; i++)
                    {
                        for (j = 0; j < 2; j++)
                            l_12060[i][j] = (-1L);
                    }
                    if (l_11829)
                        goto lbl_12016;
                    for (g_8242 = 0; (g_8242 <= 3); g_8242 += 1)
                    { /* block id: 5085 */
                        int i, j, k;
                        l_12017[0] = g_3420[g_1351];
                        (*g_10974) |= (0xBA008BEDL <= ((void*)0 == &g_5128));
                        l_12039 = (g_3420[g_1636] != (safe_div_func_int8_t_s_s((safe_add_func_uint32_t_u_u((((((safe_add_func_uint16_t_u_u(l_11931[3][5], ((**g_714) = l_11829))) != 65535UL) && (safe_sub_func_int64_t_s_s(l_12026, (safe_add_func_int16_t_s_s((safe_mod_func_int32_t_s_s((~((!(**g_929)) >= ((safe_rshift_func_uint8_t_u_s(((safe_lshift_func_int16_t_s_s((g_3420[g_1636] != (((****g_5408)++) , (g_3420[g_1351] > l_12026))), 8)) && l_11954), l_11829)) > l_12026))), g_3420[g_1351])), 0xE063L))))) < l_11881) > (*g_11360)), 0xEA82A7D2L)), g_3420[g_1351])));
                        return (*p_52);
                    }
                    (*g_10974) |= ((*p_52) = (safe_mod_func_uint64_t_u_u(((void*)0 == l_12042[0][7][0]), l_11931[4][5])));
                    if (((*g_10974) ^= (l_12039 = (-2L))))
                    { /* block id: 5097 */
                        union U4 *****l_12050 = &l_12014;
                        const int32_t l_12056[9][7] = {{0L,(-2L),0xF7E74F14L,1L,0x9E9B28DDL,(-1L),0x9E9B28DDL},{(-1L),0x9E9B28DDL,0x9E9B28DDL,(-1L),0x320EF315L,0xFB568FC2L,1L},{0xFB568FC2L,0x9E9B28DDL,0L,(-1L),(-1L),0x320EF315L,(-9L)},{1L,(-2L),0xFB568FC2L,2L,0xFB568FC2L,(-2L),1L},{0L,2L,(-2L),(-9L),0xFB568FC2L,0x99765C9CL,0x9E9B28DDL},{0L,0x99765C9CL,(-1L),0xFB568FC2L,(-1L),(-1L),0xFB568FC2L},{(-2L),0x76CB66F0L,(-2L),1L,0x320EF315L,0L,0x99765C9CL},{(-2L),(-9L),0xFB568FC2L,0x99765C9CL,0x9E9B28DDL,0x76CB66F0L,0L},{0L,0L,0L,0L,0L,0L,(-1L)}};
                        int i, j;
                        (***g_11089) = l_12043[5][2][0];
                        l_12057 = ((**g_11090) = (((*g_1541) ^= (((safe_div_func_int16_t_s_s(((safe_mod_func_int16_t_s_s(((l_11954 , ((-4L) | (l_11903 & ((safe_add_func_uint64_t_u_u(((void*)0 == l_12050), (g_12051 |= l_11881))) && (((safe_sub_func_uint16_t_u_u(((l_12054 == (***l_12014)) , 0xAFD4L), l_11970)) <= (*g_1678)) ^ 0x370E02E0L))))) >= l_12001), l_12056[5][0])) != 18446744073709551607UL), l_12003)) == l_12039) <= 0x3F2FBA74L)) , (void*)0));
                    }
                    else
                    { /* block id: 5103 */
                        int64_t l_12058 = 0x889DE6B4A0C40971LL;
                        int32_t l_12059 = 0x31B3315DL;
                        int32_t l_12061 = 7L;
                        int32_t l_12066 = 0L;
                        int32_t l_12069 = 0x76E460F1L;
                        --l_12070[6];
                        (***g_11089) = &l_12066;
                    }
                }
            }
            --l_12073;
            for (g_5213 = 0; (g_5213 <= 6); g_5213 += 1)
            { /* block id: 5112 */
                uint8_t l_12102 = 0x44L;
                int16_t *l_12117[3];
                int32_t l_12159[3];
                uint64_t l_12163 = 18446744073709551615UL;
                int8_t l_12168 = (-5L);
                int64_t l_12185 = 0xB0E2D30B1440D3F7LL;
                int32_t l_12189 = 1L;
                int i;
                for (i = 0; i < 3; i++)
                    l_12117[i] = &g_9377[4][3][0];
                for (i = 0; i < 3; i++)
                    l_12159[i] = 0x69035A60L;
                for (l_11929 = 0; (l_11929 <= 2); l_11929 += 1)
                { /* block id: 5115 */
                    uint32_t *****l_12077 = &g_12076;
                    uint32_t ****l_12080 = &l_12079;
                    int32_t l_12087[5][10] = {{0x3E325C4CL,0x3E325C4CL,(-1L),0x9C2480C3L,0L,2L,(-8L),0xF31DCBD3L,0L,0xFF852F60L},{(-1L),(-1L),0x3E325C4CL,(-5L),(-8L),0x6FF551B1L,(-8L),(-5L),0x3E325C4CL,(-1L)},{0L,0x3E325C4CL,0L,(-1L),0xFF852F60L,0x6526B658L,(-1L),0x6FF551B1L,0x9C2480C3L,0xF31DCBD3L},{0x9C2480C3L,0x49706015L,(-8L),(-1L),0x6526B658L,0x6526B658L,(-1L),(-8L),0x49706015L,0x9C2480C3L},{0L,2L,0x6526B658L,(-8L),0x3E325C4CL,0x6FF551B1L,0L,0x49706015L,(-5L),(-1L)}};
                    union U2 **l_12131[3];
                    union U2 **** const l_12150 = (void*)0;
                    union U2 **** const *l_12149 = &l_12150;
                    uint8_t **l_12157 = &g_5411;
                    int32_t l_12160 = 0x8E9D28BCL;
                    int i, j;
                    for (i = 0; i < 3; i++)
                        l_12131[i] = &g_11354;
                    if (((*g_11360) |= ((((((((*l_12077) = g_12076) == (l_12080 = l_12078)) , &g_1503) != (((*g_715) = 0xFA84L) , &g_1503)) ^ (**g_929)) != (252UL != ((safe_div_func_uint8_t_u_u((*g_656), (safe_div_func_uint64_t_u_u((~(l_12086 > l_12087[2][4])), 3UL)))) <= (**g_929)))) , (*p_52))))
                    { /* block id: 5120 */
                        int8_t l_12092[10] = {0x8AL,0x8AL,0L,0L,0L,0x8AL,0x8AL,0L,0L,0L};
                        int i;
                        (****g_2717) = (l_12057 = &l_12003);
                        (*l_12057) = (((safe_lshift_func_int16_t_s_u(((safe_add_func_uint16_t_u_u(l_12092[6], l_11903)) < (safe_lshift_func_uint8_t_u_u(((****g_5408) = (*l_12057)), 6))), (safe_lshift_func_uint8_t_u_s((safe_mod_func_uint32_t_u_u((l_12067 = (((!((safe_rshift_func_uint16_t_u_s(65535UL, (l_12065 | (((void*)0 != (*g_5407)) | (((void*)0 != (**g_6523)) | (*l_12057)))))) , 255UL)) || 4UL) == 65528UL)), l_12087[2][4])), 4)))) , l_12092[6]) , (*p_52));
                        (**g_11090) = (***g_11089);
                    }
                    else
                    { /* block id: 5131 */
                        uint64_t l_12118 = 1UL;
                        union U2 **l_12132 = (void*)0;
                        union U2 *****l_12158[10][1];
                        int32_t l_12161 = 0x465392FBL;
                        int i, j;
                        for (i = 0; i < 10; i++)
                        {
                            for (j = 0; j < 1; j++)
                                l_12158[i][j] = &g_9881;
                        }
                        if (l_12118)
                            break;
                        if (g_11302)
                            goto lbl_12016;
                        l_12161 &= (((safe_mod_func_int32_t_s_s((((safe_lshift_func_uint16_t_u_u((safe_mod_func_int16_t_s_s(((l_12087[4][0] = (((safe_add_func_int8_t_s_s(((l_12159[1] = ((safe_mul_func_uint8_t_u_u(((l_12118 , (***g_4422)) || (l_12131[0] == (l_12132 = l_12131[0]))), (((*p_52) , (l_12149 = (l_12133 = &g_9881))) != (l_12158[3][0] = ((((*g_6119) = (safe_sub_func_int8_t_s_s((safe_mod_func_int32_t_s_s((safe_add_func_int16_t_s_s((l_12118 || l_12102), ((void*)0 == l_12157))), l_11881)), 0x92L))) <= l_12087[2][4]) , &g_9881))))) == l_12102)) == (**g_714)), (-10L))) != 0xD3E8EA4716037280LL) | (**g_4423))) || (*g_5411)), (***g_1676))), 5)) , 0xE9F81A77L) <= l_12118), l_12102)) > l_12160) > (***g_1676));
                    }
                    for (g_6575.f3 = 0; (g_6575.f3 <= 2); g_6575.f3 += 1)
                    { /* block id: 5145 */
                        (**g_11090) = (void*)0;
                    }
                }
                if (l_12162)
                    break;
                l_12163--;
                for (g_7236.f3 = 6; (g_7236.f3 >= 0); g_7236.f3 -= 1)
                { /* block id: 5153 */
                    uint16_t l_12171 = 0x1E22L;
                    int32_t l_12177 = 7L;
                    int32_t ***l_12178 = &g_1207;
                    int32_t l_12179 = (-1L);
                    int32_t l_12180 = 1L;
                    int32_t l_12181 = 0x1AD2EC94L;
                    int32_t l_12182 = 0xEC616ADEL;
                    int32_t l_12183 = 8L;
                    int32_t l_12184 = 0x5EB5F4D7L;
                    int32_t l_12186 = 1L;
                    int32_t l_12188 = 0xB4EFB57AL;
                    int32_t l_12190 = 1L;
                    int32_t l_12191 = 0xB687184DL;
                    int32_t l_12192 = 0x57287C4FL;
                    int32_t l_12193[4] = {0xAA53E6A3L,0xAA53E6A3L,0xAA53E6A3L,0xAA53E6A3L};
                    uint64_t l_12195 = 6UL;
                    int i;
                    for (g_1181 = 0; (g_1181 <= 2); g_1181 += 1)
                    { /* block id: 5156 */
                        return (*p_52);
                    }
                    if ((safe_add_func_int8_t_s_s((**g_4423), ((****g_5408) = ((((l_11970 > ((l_12168 <= l_12159[1]) != (((((safe_mul_func_int8_t_s_s(((l_12171 ^ (l_12171 , ((((*g_8235) = l_12063) , l_12063) && (((((safe_sub_func_uint16_t_u_u((l_12174 == l_12175), 65535UL)) > l_12159[0]) ^ (*g_7633)) | l_12159[1]) & (*****g_5407))))) | l_12171), (**g_4423))) < 0x9A233967BE2D7E08LL) ^ l_12168) ^ l_12171) > (*g_1678)))) , l_12159[1]) || 2UL) >= 1UL)))))
                    { /* block id: 5161 */
                        return (*p_52);
                    }
                    else
                    { /* block id: 5163 */
                        if ((*g_11360))
                            break;
                        l_12177 = ((g_12176 = l_11985) == l_11985);
                    }
                    (*g_11360) ^= (((**l_11587) = 0x4AE9C241L) == ((l_12174 != l_12178) != 0L));
                    ++l_12195;
                }
            }
        }
    }
    (*g_10974) = (-1L);
    return (*g_11360);
}


/* ------------------------------------------ */
/* 
 * reads : g_715 g_466 g_8 g_1678 g_232 g_4139 g_656 g_5410 g_5411 g_38 g_8242 g_604 g_10974 g_255
 * writes: g_466 g_9377 g_657 g_3870 g_38 g_8242 g_604 g_746 g_255
 */
static int8_t * func_54(const int8_t * p_55, int32_t * const  p_56, const uint32_t  p_57, int32_t * p_58)
{ /* block id: 4653 */
    int32_t l_11165 = 0xC8395287L;
    int16_t *l_11181 = &g_9377[5][1][0];
    int32_t l_11184 = 0x678F29B9L;
    int32_t l_11185 = 0xDACF8A6BL;
    const union U2 *l_11193[9];
    int8_t *l_11225 = (void*)0;
    int i;
    for (i = 0; i < 9; i++)
        l_11193[i] = (void*)0;
    l_11185 |= (safe_mod_func_int16_t_s_s((safe_sub_func_uint64_t_u_u((safe_div_func_int64_t_s_s(l_11165, 0xAA9754C1A5B7C2CFLL)), ((((((p_57 <= ((safe_rshift_func_uint8_t_u_s((l_11184 = ((**g_5410) = ((safe_div_func_int32_t_s_s((safe_sub_func_int8_t_s_s((safe_mul_func_int16_t_s_s((safe_div_func_uint16_t_u_u(65526UL, (++(*g_715)))), 65535UL)), p_57)), (*p_58))) >= ((safe_mul_func_uint8_t_u_u(((**g_4139) = ((safe_unary_minus_func_int16_t_s(((*l_11181) = (*g_1678)))) & (safe_add_func_uint32_t_u_u(p_57, 4294967286UL)))), l_11165)) | (-5L))))), 7)) > 0xB43449D9L)) , (-1L)) , 0x5E52C77F19844402LL) ^ p_57) || l_11184) == 0x23D5L))), p_57));
    for (g_38 = 4; (g_38 > 15); g_38++)
    { /* block id: 4662 */
        const int64_t l_11192 = 0x3A9200F7D59ACF7DLL;
        union U4 *** const *l_11195 = &g_6523;
        const int64_t l_11201[5] = {0xD6D121A971FA655CLL,0xD6D121A971FA655CLL,0xD6D121A971FA655CLL,0xD6D121A971FA655CLL,0xD6D121A971FA655CLL};
        int32_t l_11223 = 0L;
        int i;
        for (g_8242 = 0; (g_8242 < 57); ++g_8242)
        { /* block id: 4665 */
            const union U2 *l_11194 = (void*)0;
            union U2 * const l_11202 = &g_11203;
            int32_t l_11224 = (-1L);
            for (g_604 = 0; (g_604 != 27); ++g_604)
            { /* block id: 4668 */
                int16_t *l_11200 = &g_78;
                int32_t l_11204 = 1L;
                union U3 **l_11205 = &g_746;
                (*l_11205) = (l_11192 , (((p_57 | ((l_11194 = l_11193[8]) != ((l_11192 > (((void*)0 == l_11195) <= ((safe_add_func_uint16_t_u_u((((safe_rshift_func_int16_t_s_u(((0xFEE1C355015D387ELL && p_57) >= (l_11192 || 0xEFE8539900CF58F3LL)), l_11165)) , (void*)0) == l_11200), l_11192)) ^ l_11201[2]))) , l_11202))) != l_11204) , (void*)0));
                (*g_10974) = (safe_sub_func_uint16_t_u_u(65529UL, (!((safe_rshift_func_uint16_t_u_s(l_11204, ((safe_lshift_func_int8_t_s_s((((l_11185 |= 0xA5CFL) <= 0UL) <= (safe_mod_func_int64_t_s_s((l_11223 = ((((((*p_58) && (safe_sub_func_uint64_t_u_u(((((((0x546D093BL >= (safe_rshift_func_int16_t_s_u(p_57, 2))) < p_57) , (safe_rshift_func_uint8_t_u_s((safe_sub_func_int32_t_s_s((l_11192 , (*g_10974)), 9UL)), 5))) <= 0xE29DL) , 0xF5L) , l_11165), 2UL))) < 0x99F6L) == 0xD027EC15L) >= 2L) > p_57)), l_11224))), l_11224)) , l_11184))) != 2L))));
            }
        }
    }
    return l_11225;
}


/* ------------------------------------------ */
/* 
 * reads : g_29 g_66 g_78 g_7 g_951 g_1674 g_1675 g_1540 g_1541 g_998 g_5410 g_5411 g_3870 g_715 g_466 g_2 g_4882 g_2717 g_2718 g_2719 g_1207 g_6119 g_845 g_4423 g_28 g_9377 g_653 g_4422 g_8562 g_7024.f3 g_1220 g_260 g_7160 g_8092.f3 g_7633 g_431 g_3071 g_4801 g_656 g_8235 g_929 g_930 g_446 g_5546 g_38 g_5407 g_5408 g_714 g_8082.f3 g_5409 g_4139 g_657 g_4087 g_4088 g_604 g_7825.f0 g_5271 g_9260 g_9261 g_746 g_6877.f3 g_8090.f3 g_9692 g_9693 g_1676 g_1677 g_1678 g_232 g_3197 g_5127 g_5128 g_9806 g_1470 g_5749 g_1419 g_2302 g_6484 g_6233 g_3643 g_9259 g_6483 g_6607.f0 g_4095 g_4096 g_4097 g_1219 g_6879.f3 g_5490 g_2725 g_10163 g_5746 g_5747 g_5748 g_10193 g_3420 g_10267 g_836 g_837 g_6523 g_1168 g_10366 g_1221 g_7503 g_7504 g_538 g_539 g_6584.f3 g_10461 g_10709 g_922.f1 g_10753 g_1070 g_10194 g_10754 g_10902 g_10973 g_10974 g_10991 g_11027 g_9881 g_9311 g_11 g_188 g_163 g_3477 g_6006 g_6045 g_328 g_748 g_3142.f1 g_6145 g_6229 g_6256 g_6270 g_3566 g_3567 g_3250 g_6240 g_6833 g_255 g_499 g_1920.f1 g_5048.f0 g_7076 g_7095 g_11089 g_9622.f0 g_4493 g_1273
 * writes: g_78 g_38 g_951 g_466 g_4882 g_653 g_8562 g_7024.f3 g_1220 g_260 g_8092.f3 g_3071 g_845 g_4296 g_657 g_5490 g_3870 g_5546 g_8082.f3 g_998 g_604 g_7825.f0 g_5271 g_9262 g_6877.f3 g_8090.f3 g_446 g_66 g_255 g_930 g_1470 g_9692 g_1503 g_431 g_9880 g_1168 g_1070 g_9920 g_6233 g_3643 g_6571.f3 g_232 g_10000 g_6607.f0 g_6483 g_1396 g_1219 g_6879.f3 g_2725 g_9622.f0 g_1217 g_3420 g_10193 g_3142.f1 g_10267 g_4493 g_1273 g_9425.f3 g_746 g_10366 g_1221 g_29 g_539 g_7095 g_6584.f3 g_6882.f3 g_1727 g_10709 g_4118 g_922.f1 g_10753 g_3682 g_10755 g_10973 g_9311 g_188 g_163 g_2386.f0 g_748 g_499 g_538 g_196 g_6119 g_1550 g_6229 g_6240 g_6256 g_2170 g_6270 g_857 g_1621 g_2302 g_2482 g_4087 g_4302 g_5044.f0 g_3529.f0 g_6439 g_4338 g_6580.f3 g_6586.f3 g_1920.f1 g_5048.f0 g_6587.f3 g_7088 g_11089
 */
static int32_t * func_60(int16_t  p_61, uint8_t  p_62)
{ /* block id: 23 */
    int16_t *l_90[7] = {&g_78,&g_78,&g_78,&g_78,&g_78,&g_78,&g_78};
    int32_t *l_95 = &g_7[1][5][1];
    int32_t l_10134 = 0L;
    uint64_t *****l_10220 = &g_10194[2];
    int64_t **l_10238 = &g_538[2];
    int32_t l_10243 = 0x1DF2DCF2L;
    int32_t l_10245 = (-1L);
    int32_t l_10249 = (-2L);
    int32_t l_10250[4];
    int32_t l_10271 = (-2L);
    const struct S0 *l_10301 = (void*)0;
    union U5 ** const * const l_10313 = (void*)0;
    union U5 ** const * const *l_10312[6];
    union U5 ** const * const **l_10311 = &l_10312[5];
    int32_t *l_10364 = (void*)0;
    uint32_t l_10372 = 18446744073709551614UL;
    uint32_t l_10382 = 0x09B02FB5L;
    uint8_t l_10388[3][4][9] = {{{0xC4L,250UL,0xC4L,0UL,250UL,0xFAL,0xFAL,250UL,0UL},{0x77L,6UL,0x77L,0x45L,6UL,0xE5L,0xE5L,6UL,0x45L},{0xC4L,250UL,0xC4L,0UL,250UL,0xFAL,0xFAL,250UL,0UL},{0x77L,6UL,0x77L,0x45L,6UL,0xE5L,0xE5L,6UL,0x45L}},{{0xC4L,250UL,0xC4L,0UL,250UL,0xFAL,0xFAL,250UL,0UL},{0x77L,6UL,0x77L,0x45L,6UL,0xE5L,0xE5L,6UL,0x45L},{0xC4L,250UL,0xC4L,0UL,250UL,0xFAL,0xFAL,250UL,0UL},{0x77L,6UL,0x77L,0x45L,6UL,0xE5L,0xE5L,6UL,0x45L}},{{0xC4L,250UL,0xC4L,0UL,250UL,0xFAL,0xFAL,250UL,0UL},{0x77L,6UL,0x77L,0x45L,6UL,0xE5L,0xE5L,6UL,0x45L},{0xC4L,250UL,0xC4L,0UL,250UL,0xFAL,0xFAL,250UL,0UL},{0x77L,6UL,0x77L,0x45L,6UL,0xE5L,0xE5L,6UL,0x45L}}};
    struct S1 *l_10413 = &g_10414;
    int32_t *****l_10421 = &g_3477;
    int32_t *****l_10422 = &g_3477;
    union U4 *l_10444 = &g_10445;
    int64_t ** const **l_10567 = (void*)0;
    int64_t ** const ***l_10566 = &l_10567;
    union U2 *l_10584 = &g_10585;
    int8_t *l_10647 = &g_4118[2];
    uint8_t l_10661[8] = {0x6FL,0x6FL,0x6FL,0x6FL,0x6FL,0x6FL,0x6FL,0x6FL};
    int32_t *l_10685[6];
    int8_t ****l_10693 = &g_4422;
    int8_t *****l_10692[7][4] = {{&l_10693,&l_10693,&l_10693,&l_10693},{&l_10693,&l_10693,&l_10693,&l_10693},{&l_10693,&l_10693,&l_10693,&l_10693},{&l_10693,&l_10693,&l_10693,&l_10693},{&l_10693,&l_10693,&l_10693,&l_10693},{&l_10693,&l_10693,&l_10693,&l_10693},{&l_10693,&l_10693,&l_10693,&l_10693}};
    int32_t *****l_10698 = &g_4720;
    int16_t *** const l_10700 = &g_1030[0][5];
    union U4 *** const l_10752 = &g_2302;
    int32_t l_10759 = 0x356A0040L;
    uint64_t *** const *l_10763[9][8][3] = {{{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,(void*)0},{&g_3682,(void*)0,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,(void*)0,&g_3682},{&g_3682,&g_3682,&g_3682}},{{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,(void*)0},{&g_3682,(void*)0,(void*)0},{&g_3682,&g_3682,&g_3682},{&g_3682,(void*)0,&g_3682},{&g_3682,(void*)0,&g_3682},{&g_3682,&g_3682,&g_3682}},{{&g_3682,&g_3682,(void*)0},{&g_3682,&g_3682,(void*)0},{&g_3682,&g_3682,&g_3682},{&g_3682,(void*)0,(void*)0},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682}},{{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,(void*)0,(void*)0},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682}},{{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,(void*)0},{&g_3682,&g_3682,&g_3682}},{{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,(void*)0},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,(void*)0,&g_3682},{&g_3682,(void*)0,&g_3682}},{{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,(void*)0},{&g_3682,&g_3682,(void*)0},{&g_3682,&g_3682,&g_3682},{&g_3682,(void*)0,(void*)0},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682}},{{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,(void*)0,(void*)0},{&g_3682,&g_3682,&g_3682}},{{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,&g_3682},{&g_3682,&g_3682,(void*)0}}};
    uint64_t *** const **l_10762 = &l_10763[4][2][0];
    uint16_t l_10784 = 65531UL;
    union U2 *****l_10810 = &g_9881;
    int32_t *l_10848 = (void*)0;
    uint8_t l_10867 = 0x0CL;
    uint32_t ****l_10906 = (void*)0;
    uint32_t l_10976[9][6][4] = {{{6UL,6UL,0UL,0x7754526FL},{0xEBF0F8A7L,1UL,6UL,0x0DB5DE33L},{0x2DECE1EDL,8UL,0x1569F9BAL,6UL},{4294967288UL,4294967292UL,0x65583B9BL,0x3127C721L},{4294967292UL,4294967295UL,0x1A6C8F32L,0x96D8D13EL},{5UL,1UL,0x5C8231E2L,0xB63315FAL}},{{1UL,0xECA48D03L,0x7754526FL,0x9F3AAB67L},{1UL,0x5D385141L,4UL,0UL},{0xDD7B0B42L,4294967295UL,0x2DECE1EDL,0xECA48D03L},{0x96B573B1L,0x7754526FL,0x5D385141L,4294967295UL},{1UL,0xE2691786L,7UL,4294967288UL},{0x3679BAC0L,0xA432C8F2L,1UL,5UL}},{{0x3127C721L,0x1569F9BAL,0x45D79E21L,0xE9B4953FL},{0xAFF7696CL,0x261B4907L,0x1569F9BAL,0x8998F200L},{6UL,4294967295UL,1UL,0x3679BAC0L},{0UL,0xD14C917AL,4294967295UL,6UL},{0x97CB8E13L,0xA87DD074L,0x261B4907L,6UL},{4UL,0x0C907888L,0xD7AA4D3DL,0x23D5D2EDL}},{{0UL,0xDD7B0B42L,8UL,6UL},{0UL,0x7A975ABFL,4UL,1UL},{0x65583B9BL,0xB63315FAL,4294967295UL,0xB11680C3L},{1UL,4294967287UL,0x0DABF3F2L,0x45D79E21L},{0xD9029580L,1UL,0x8998F200L,4294967294UL},{4294967295UL,0x9F3AAB67L,0x3127C721L,1UL}},{{4294967295UL,4294967295UL,0x1583B92DL,0xFA4F5BB1L},{0xECA48D03L,0x689139E5L,1UL,0x543A9ABBL},{4294967288UL,0UL,5UL,0UL},{4294967295UL,6UL,4294967288UL,1UL},{0xA71ECFCEL,0xBCDB0920L,0xD14C917AL,0xEBF0F8A7L},{0x9F3AAB67L,4294967294UL,0xD9029580L,0x8887DAABL}},{{0x9F3AAB67L,0x10680DE1L,0xD14C917AL,0x2AE313E7L},{0xA71ECFCEL,0x8887DAABL,4294967288UL,6UL},{4294967295UL,1UL,5UL,0x5D385141L},{4294967288UL,3UL,1UL,0x7D7C1829L},{0xECA48D03L,0xAAEECF7BL,0x1583B92DL,0xD5E9A6CBL},{4294967295UL,0x7032B1C9L,0x3127C721L,0UL}},{{4294967295UL,4294967288UL,0x8998F200L,8UL},{0xD9029580L,0x3679BAC0L,0x0DABF3F2L,4294967295UL},{1UL,0xB2884254L,4294967295UL,0UL},{0x65583B9BL,0xD9029580L,4UL,0x2DECE1EDL},{0UL,1UL,8UL,0xAAEECF7BL},{0UL,0x96B573B1L,0xD7AA4D3DL,0x8EB4AB75L}},{{4UL,8UL,0x261B4907L,0x689139E5L},{0x97CB8E13L,0x53249E59L,4294967295UL,4294967288UL},{0UL,0xEBF0F8A7L,1UL,4294967295UL},{6UL,0x23D5D2EDL,0x1569F9BAL,1UL},{0xAFF7696CL,0x1583B92DL,0x45D79E21L,0x7032B1C9L},{0x3127C721L,0x9A7F50C0L,1UL,0xA87DD074L}},{{0x3679BAC0L,0xD5E9A6CBL,7UL,1UL},{1UL,4294967295UL,0x5D385141L,0xC46254C7L},{0x96B573B1L,1UL,0x8EB4AB75L,0x689139E5L},{1UL,0xF2FC734FL,0x7754526FL,6UL},{0xBCDB0920L,4294967295UL,0x96D8D13EL,4294967294UL},{0x9A7F50C0L,0xCE44D259L,0xCE44D259L,0x9A7F50C0L}}};
    int32_t ***l_10990 = (void*)0;
    const uint64_t l_10992 = 18446744073709551615UL;
    const union U3 *l_11003 = &g_11004;
    const union U3 **l_11002 = &l_11003;
    const union U3 ***l_11001 = &l_11002;
    uint32_t *****l_11048 = (void*)0;
    int32_t l_11067[1];
    const int32_t l_11068 = 0L;
    int32_t l_11072 = (-1L);
    int32_t l_11116 = 2L;
    int32_t l_11127 = 0L;
    int32_t l_11149 = 0xDB1D61B7L;
    int32_t *l_11157 = &g_8;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_10250[i] = 0xB380E904L;
    for (i = 0; i < 6; i++)
        l_10312[i] = &l_10313;
    for (i = 0; i < 6; i++)
        l_10685[i] = &g_38;
    for (i = 0; i < 1; i++)
        l_11067[i] = 0x2DCD2E31L;
    if ((l_10134 = ((((safe_add_func_uint32_t_u_u(g_29, (safe_mod_func_uint16_t_u_u(0xD702L, func_84(func_87(l_90[1], (((safe_mul_func_uint8_t_u_u((((safe_mul_func_uint8_t_u_u(0x15L, ((void*)0 == l_95))) & (g_78 = (p_61 ^= (g_66 , (safe_mul_func_uint16_t_u_u(p_62, 0x4083L)))))) <= p_62), 0UL)) && 0xDE5BB510L) , (void*)0)), p_62))))) , (*l_95)) & p_62) ^ 0x122BL)))
    { /* block id: 4277 */
        uint16_t l_10139 = 0UL;
        int32_t l_10149 = 8L;
        int32_t l_10165 = 1L;
        for (g_2725 = 26; (g_2725 > 34); ++g_2725)
        { /* block id: 4280 */
            int32_t ****l_10140[5][5] = {{&g_4095,&g_4095,&g_4095,&g_4095,&g_4095},{&g_4095,&g_4095,&g_4095,&g_4095,&g_4095},{&g_4095,&g_4095,(void*)0,&g_4095,&g_4095},{&g_4095,&g_4095,&g_4095,&g_4095,&g_4095},{&g_4095,&g_4095,&g_4095,&g_4095,&g_4095}};
            int32_t l_10148 = 0x461F9DEBL;
            int32_t l_10150 = 0x9DAB7DA4L;
            int32_t l_10153 = 0x39188F1EL;
            int32_t l_10164 = (-3L);
            int i, j;
            l_10150 ^= (l_10149 = ((l_10134 = (((((safe_add_func_uint16_t_u_u((((l_10139 , l_10140[2][4]) != (void*)0) ^ ((((!p_61) | ((0xFCL && (*g_5411)) , (p_61 , (safe_mod_func_uint16_t_u_u((safe_rshift_func_int8_t_s_u((*l_95), 0)), ((**g_714) = (((*g_1541) = (((safe_mod_func_uint32_t_u_u((((p_61 > 0L) <= 0x6ED6EA5DL) , 4294967293UL), 8UL)) ^ (*g_7633)) == p_61)) , 1UL))))))) , (void*)0) == &g_6439[8][3])), l_10148)) , 4294967295UL) > (*l_95)) || 1L) | l_10139)) & (*l_95)));
            l_10165 |= ((((l_10150 , (*g_9259)) == (void*)0) <= ((p_62 && (safe_add_func_uint64_t_u_u((l_10153 , (((safe_add_func_uint8_t_u_u((****g_5408), 6L)) < (+((*g_715)--))) > (safe_mod_func_uint8_t_u_u((*g_656), (safe_sub_func_uint16_t_u_u(g_10163, p_61)))))), l_10164))) >= p_62)) && l_10149);
        }
    }
    else
    { /* block id: 4289 */
        const uint16_t **l_10170 = &g_5749;
        int8_t ***l_10173 = &g_4423;
        int32_t l_10177 = 0x3E16EAD4L;
        int64_t l_10216 = 6L;
        uint16_t l_10218 = 0xFF4CL;
        int32_t l_10241 = 0x366F986CL;
        int32_t l_10253 = 0x83A2FB17L;
        int32_t l_10255 = 0x31B0FFAEL;
        int32_t l_10257 = (-10L);
        int32_t l_10258 = 0x991232FCL;
        int32_t l_10260[7] = {0xA50E1917L,0xA50E1917L,0L,0xA50E1917L,0xA50E1917L,0L,0xA50E1917L};
        int64_t l_10275 = 0x3E6C1A802B07CDA9LL;
        uint64_t l_10358 = 18446744073709551607UL;
        struct S1 **l_10415 = &g_7095;
        int32_t *****l_10420 = &g_3477;
        int32_t *****l_10423[4][7][6] = {{{&g_3477,&g_3477,&g_3477,&g_3477,&g_3477,&g_3477},{&g_3477,&g_3477,&g_3477,&g_3477,&g_3477,&g_3477},{&g_3477,&g_3477,&g_3477,(void*)0,&g_3477,&g_3477},{&g_3477,&g_3477,&g_3477,&g_3477,&g_3477,&g_3477},{&g_3477,(void*)0,&g_3477,&g_3477,&g_3477,(void*)0},{&g_3477,&g_3477,&g_3477,&g_3477,&g_3477,&g_3477},{(void*)0,&g_3477,&g_3477,&g_3477,&g_3477,&g_3477}},{{&g_3477,&g_3477,&g_3477,&g_3477,&g_3477,&g_3477},{(void*)0,(void*)0,&g_3477,&g_3477,&g_3477,&g_3477},{&g_3477,&g_3477,&g_3477,&g_3477,&g_3477,&g_3477},{(void*)0,&g_3477,&g_3477,&g_3477,(void*)0,&g_3477},{&g_3477,&g_3477,&g_3477,(void*)0,&g_3477,&g_3477},{(void*)0,&g_3477,&g_3477,&g_3477,&g_3477,&g_3477},{&g_3477,&g_3477,&g_3477,&g_3477,&g_3477,&g_3477}},{{&g_3477,&g_3477,&g_3477,&g_3477,&g_3477,(void*)0},{&g_3477,&g_3477,&g_3477,&g_3477,&g_3477,&g_3477},{&g_3477,&g_3477,&g_3477,&g_3477,(void*)0,&g_3477},{&g_3477,&g_3477,&g_3477,&g_3477,&g_3477,&g_3477},{&g_3477,(void*)0,&g_3477,&g_3477,&g_3477,&g_3477},{&g_3477,&g_3477,&g_3477,&g_3477,&g_3477,(void*)0},{&g_3477,&g_3477,&g_3477,&g_3477,&g_3477,(void*)0}},{{&g_3477,(void*)0,&g_3477,&g_3477,(void*)0,&g_3477},{&g_3477,&g_3477,&g_3477,&g_3477,&g_3477,&g_3477},{&g_3477,&g_3477,(void*)0,&g_3477,&g_3477,&g_3477},{(void*)0,&g_3477,&g_3477,&g_3477,&g_3477,&g_3477},{&g_3477,&g_3477,&g_3477,&g_3477,&g_3477,(void*)0},{&g_3477,&g_3477,&g_3477,&g_3477,&g_3477,&g_3477},{&g_3477,&g_3477,(void*)0,(void*)0,&g_3477,(void*)0}}};
        int64_t *l_10441[4] = {&g_6607.f0,&g_6607.f0,&g_6607.f0,&g_6607.f0};
        union U4 *l_10442 = &g_10443;
        struct S0 *l_10448 = &g_10449;
        int32_t l_10478 = 0L;
        uint32_t ***l_10518 = (void*)0;
        union U5 ***l_10520 = &g_6484;
        uint32_t ****l_10525 = &l_10518;
        int32_t *l_10526[4] = {&g_5271,&g_5271,&g_5271,&g_5271};
        const uint32_t l_10587[7][4] = {{0x231FCD0DL,0x231FCD0DL,0x231FCD0DL,0x231FCD0DL},{0x231FCD0DL,0x231FCD0DL,0x231FCD0DL,0x231FCD0DL},{0x231FCD0DL,0x231FCD0DL,0x231FCD0DL,0x231FCD0DL},{0x231FCD0DL,0x231FCD0DL,0x231FCD0DL,0x231FCD0DL},{0x231FCD0DL,0x231FCD0DL,0x231FCD0DL,0x231FCD0DL},{0x231FCD0DL,0x231FCD0DL,0x231FCD0DL,0x231FCD0DL},{0x231FCD0DL,0x231FCD0DL,0x231FCD0DL,0x231FCD0DL}};
        uint64_t l_10592 = 1UL;
        uint32_t **l_10624 = &g_4088[0];
        int8_t l_10633 = 0L;
        int64_t * const *l_10638[9] = {&g_6119,&g_6119,&g_6119,&g_6119,&g_6119,&g_6119,&g_6119,&g_6119,&g_6119};
        int64_t * const ** const l_10637 = &l_10638[7];
        uint16_t l_10640 = 0x7D94L;
        int16_t *l_10684 = (void*)0;
        uint64_t **l_10760 = &g_4583[2];
        uint64_t *** const **l_10764 = &l_10763[4][2][0];
        int32_t l_10770 = 0xF5D5D450L;
        uint32_t **l_10777[2][10][5] = {{{&g_4088[0],&g_4088[0],&g_4088[0],(void*)0,(void*)0},{&g_4088[0],&g_4088[0],(void*)0,(void*)0,&g_4088[0]},{(void*)0,&g_4088[0],&g_4088[0],&g_4088[0],&g_4088[0]},{&g_4088[0],&g_4088[0],(void*)0,&g_4088[0],&g_4088[0]},{&g_4088[0],&g_4088[0],&g_4088[0],&g_4088[0],&g_4088[0]},{&g_4088[0],&g_4088[0],&g_4088[0],&g_4088[0],&g_4088[0]},{&g_4088[0],&g_4088[0],&g_4088[0],&g_4088[0],&g_4088[0]},{&g_4088[0],&g_4088[0],&g_4088[0],(void*)0,&g_4088[0]},{(void*)0,(void*)0,&g_4088[0],&g_4088[0],&g_4088[0]},{&g_4088[0],(void*)0,&g_4088[0],&g_4088[0],&g_4088[0]}},{{&g_4088[0],&g_4088[0],&g_4088[0],&g_4088[0],&g_4088[0]},{&g_4088[0],(void*)0,&g_4088[0],&g_4088[0],(void*)0},{&g_4088[0],(void*)0,&g_4088[0],&g_4088[0],&g_4088[0]},{&g_4088[0],&g_4088[0],&g_4088[0],(void*)0,(void*)0},{&g_4088[0],&g_4088[0],(void*)0,(void*)0,&g_4088[0]},{(void*)0,&g_4088[0],&g_4088[0],&g_4088[0],&g_4088[0]},{&g_4088[0],&g_4088[0],(void*)0,&g_4088[0],&g_4088[0]},{&g_4088[0],&g_4088[0],&g_4088[0],&g_4088[0],&g_4088[0]},{&g_4088[0],&g_4088[0],&g_4088[0],&g_4088[0],&g_4088[0]},{&g_4088[0],&g_4088[0],&g_4088[0],&g_4088[0],&g_4088[0]}}};
        uint32_t *** const l_10776 = &l_10777[0][0][1];
        uint32_t *** const *l_10775 = &l_10776;
        int32_t ***** const l_10832 = &g_4720;
        union U2 *l_10841 = &g_10842;
        int32_t *l_10847 = &l_10260[3];
        int32_t l_10937 = (-8L);
        int16_t l_10961 = 1L;
        uint64_t l_10962 = 0x2AB98CE89349FB09LL;
        int32_t l_10993[10][5] = {{0L,0L,0L,0L,0L},{0x0E0F0F87L,0xC964F30BL,0xC964F30BL,0x0E0F0F87L,0xC964F30BL},{0L,0L,0x13298167L,0L,0L},{0xC964F30BL,0x0E0F0F87L,0xC964F30BL,0xC964F30BL,0x0E0F0F87L},{0L,0L,0x13298167L,0L,0x13298167L},{0xC964F30BL,0xC964F30BL,0x0E0F0F87L,0xC964F30BL,0xC964F30BL},{0x13298167L,0L,0x13298167L,0x13298167L,0L},{0xC964F30BL,0xEDA88565L,0xEDA88565L,0xC964F30BL,0xEDA88565L},{0L,0L,0L,0L,0L},{0xEDA88565L,0xC964F30BL,0xEDA88565L,0xEDA88565L,0xC964F30BL}};
        const union U3 *l_10994 = &g_10995;
        union U2 ** const **l_11029 = (void*)0;
        int8_t l_11123 = 0xB2L;
        int i, j, k;
lbl_10365:
        for (g_9622.f0 = 2; (g_9622.f0 <= (-16)); g_9622.f0 = safe_sub_func_uint32_t_u_u(g_9622.f0, 8))
        { /* block id: 4292 */
            uint64_t *****l_10221 = &g_10194[0];
            const int32_t l_10239 = 0x0B192E7AL;
            int32_t l_10244 = 0x0310098DL;
            int32_t l_10252 = 0x9F11EC0AL;
            int32_t l_10254 = 0L;
            int32_t l_10259 = 0xE3B5AC53L;
            int32_t l_10261 = 0x14B7B7BFL;
            int32_t l_10262 = 0xFD13DD1CL;
            int32_t l_10263[5][10] = {{(-1L),(-8L),(-8L),(-1L),0x8A440149L,6L,(-1L),6L,0x8A440149L,(-1L)},{6L,(-1L),6L,0x8A440149L,(-1L),(-8L),(-8L),(-1L),0x8A440149L,6L},{(-1L),(-1L),5L,(-1L),0x37613B25L,5L,0x37613B25L,(-1L),5L,(-1L)},{0x37613B25L,(-8L),6L,0x37613B25L,0x8A440149L,0x8A440149L,0x37613B25L,6L,(-8L),0x37613B25L},{6L,(-1L),(-8L),0x8A440149L,(-1L),0x8A440149L,(-8L),(-1L),6L,6L}};
            int64_t l_10265 = 0x833E4819F47221CALL;
            int16_t l_10266 = 0x6548L;
            int i, j;
            for (g_1217 = 25; (g_1217 > 12); --g_1217)
            { /* block id: 4295 */
                int16_t l_10176 = 6L;
                int32_t *l_10190 = &g_3420[2];
                uint32_t l_10217 = 0x39D0464AL;
                int8_t l_10219 = 0x64L;
                int32_t l_10242[3][3][9] = {{{0L,2L,3L,0xCDEB4E6CL,(-1L),0xA573B29BL,0xCDEB4E6CL,(-1L),0x2E142DFAL},{0x92A8839DL,(-1L),0L,0x5684AA2DL,0x7CCF2080L,0xD1B1D076L,8L,0x7CCF2080L,0x35528518L},{0x92A8839DL,0x97C825F8L,0x75AA7433L,8L,0xCDEB4E6CL,0L,0xF1C2312CL,0xF1C2312CL,0L}},{{0L,(-1L),0x75AA7433L,(-1L),0L,0x35528518L,0x7CCF2080L,8L,0xD1B1D076L},{(-1L),2L,0L,8L,0L,0x2E142DFAL,(-1L),0xCDEB4E6CL,0xA573B29BL},{0xF1C2312CL,(-1L),3L,0x5684AA2DL,0xCDEB4E6CL,0x35528518L,(-1L),(-1L),2L}},{{2L,0x5684AA2DL,2L,0xCDEB4E6CL,0x7CCF2080L,0L,0x7CCF2080L,0xCDEB4E6CL,2L},{0x7CCF2080L,0x7CCF2080L,0x2E142DFAL,0x92A8839DL,(-1L),0xD1B1D076L,0xF1C2312CL,8L,0xA573B29BL},{2L,0x7CCF2080L,0L,2L,0x92A8839DL,0xA573B29BL,8L,0xF1C2312CL,0xD1B1D076L}}};
                int8_t l_10264 = 0x37L;
                int32_t l_10270 = (-1L);
                uint8_t l_10272 = 0x08L;
                int i, j, k;
                l_10170 = (**g_5746);
                (*l_10190) = (safe_mod_func_int8_t_s_s((l_10173 != (void*)0), (safe_lshift_func_int16_t_s_u(((((0xB5CAL != (((--(**g_929)) , (((safe_add_func_uint64_t_u_u((safe_sub_func_uint64_t_u_u((--(**g_1540)), (4294967295UL | (-5L)))), (safe_lshift_func_int8_t_s_u((safe_sub_func_uint8_t_u_u(l_10177, (p_61 > (*l_95)))), p_61)))) != p_61) ^ p_61)) | (*l_95))) == 5L) != p_62) < 0xDF23C8F3L), 5))));
                for (g_8090.f3 = (-15); (g_8090.f3 == (-13)); g_8090.f3++)
                { /* block id: 4302 */
                    int8_t l_10199 = 0x96L;
                    uint8_t l_10240 = 9UL;
                    int32_t l_10251 = 0L;
                    int32_t l_10256[6][7][3] = {{{0L,(-1L),0xF036555BL},{0xBCD9AEAAL,0x860EC221L,1L},{1L,(-1L),0x3A440DFBL},{4L,1L,5L},{0x0C82EBC4L,4L,0x4D643D6FL},{0x27CD85B9L,0L,0xD8B4E5DBL},{0x16F04C41L,5L,0L}},{{0x4DD3B51CL,5L,0L},{0x4D643D6FL,0L,0x4DD3B51CL},{0xD6F70A8BL,4L,0xD6F70A8BL},{0xF036555BL,1L,4L},{4L,0x23797B10L,1L},{0x23797B10L,0x4CD745D6L,0xBCD9AEAAL},{0xE0DE5307L,0xAB76CD81L,0L}},{{0x23797B10L,0xE0DE5307L,0x860EC221L},{4L,0x0C82EBC4L,0x5A911D0BL},{0x842FB3E7L,0x4D643D6FL,0xD8B4E5DBL},{0x0C82EBC4L,0L,1L},{0xD6F70A8BL,1L,0xE0DE5307L},{0x27CD85B9L,4L,0xE0DE5307L},{0x5A911D0BL,0x78E649C3L,1L}},{{5L,0xD8B4E5DBL,0xD8B4E5DBL},{1L,0x27CD85B9L,0x5A911D0BL},{4L,7L,0x860EC221L},{(-1L),(-7L),0L},{4L,5L,0xBCD9AEAAL},{0x16F04C41L,(-7L),1L},{0x4CD745D6L,7L,4L}},{{0xAFA81A0DL,0x27CD85B9L,0x0C82EBC4L},{0x4D643D6FL,0xD8B4E5DBL,0x27CD85B9L},{0L,0x78E649C3L,0x16F04C41L},{(-7L),4L,0x4DD3B51CL},{(-7L),1L,0x4D643D6FL},{0L,0L,0xD6F70A8BL},{0x4D643D6FL,0x4D643D6FL,0xF036555BL}},{{0xAFA81A0DL,0x0C82EBC4L,0x803C458CL},{0x4CD745D6L,0xE0DE5307L,(-1L)},{0x16F04C41L,0xAB76CD81L,0x842FB3E7L},{4L,0x4CD745D6L,(-1L)},{(-1L),0x23797B10L,0x803C458CL},{4L,0L,0xF036555BL},{1L,0x65C08A14L,0xD6F70A8BL}}};
                    int i, j, k;
                    l_10177 = ((g_10193 = g_10193) == (l_10221 = ((((safe_lshift_func_int8_t_s_u(p_61, (safe_mul_func_uint16_t_u_u(p_61, (l_10219 = (l_10199 || (1L == ((safe_add_func_int8_t_s_s((safe_lshift_func_uint16_t_u_s((--(**g_714)), (l_10218 = ((*l_10190) = (safe_div_func_int16_t_s_s((-1L), (safe_rshift_func_int16_t_s_s(p_61, ((safe_mod_func_int16_t_s_s(((((safe_add_func_uint64_t_u_u((safe_mod_func_uint64_t_u_u(l_10177, 0x40080C06B61277F7LL)), (*l_10190))) | 18446744073709551608UL) >= 0xAAL) == p_61), l_10216)) || l_10217))))))))), 0xA2L)) != p_62)))))))) ^ 0xEBL) , (*l_95)) , l_10220)));
                    l_10241 |= (((((safe_sub_func_int16_t_s_s(((((-1L) || p_62) || ((*g_6119) = ((((safe_lshift_func_uint16_t_u_s((safe_lshift_func_uint16_t_u_u((((p_61 | (safe_mod_func_uint32_t_u_u((safe_rshift_func_uint8_t_u_u(((((safe_mod_func_int16_t_s_s(((((**g_1540) != (((*l_10190) = (((((((0xE26A4AF0L ^ (safe_lshift_func_uint8_t_u_s(((((void*)0 != l_10238) | ((*l_10190) ^ l_10239)) ^ p_61), p_61))) < l_10239) , 3UL) == p_61) <= 0x6E6ADAA7D16AB611LL) , p_62) , 0xAFFEF0D657B7C47FLL)) | l_10199)) >= l_10199) , p_62), (***g_1676))) | l_10216) && 0UL) >= p_62), p_61)), (*l_95)))) , (void*)0) != &g_1503), (**g_714))), p_61)) == (-1L)) ^ 0x88L) , 0xC7EC2A867BA3A6B2LL))) > p_61), l_10199)) || 1L) | 0x335CC243L) || l_10240) > 0xEC1E0783L);
                    if ((*l_10190))
                        continue;
                    for (g_3142.f1 = 0; (g_3142.f1 <= 2); g_3142.f1 += 1)
                    { /* block id: 4316 */
                        int32_t *l_10246 = &l_10241;
                        int32_t *l_10247 = &l_10241;
                        int32_t *l_10248[4];
                        int i;
                        for (i = 0; i < 4; i++)
                            l_10248[i] = (void*)0;
                        g_10267++;
                        ++l_10272;
                        if (p_62)
                            break;
                        (****g_2717) = &l_10244;
                    }
                }
            }
        }
lbl_10393:
        l_10250[2] = l_10275;
        for (g_4493 = 6; (g_4493 >= 0); g_4493 -= 1)
        { /* block id: 4328 */
            uint32_t l_10276[8];
            const int32_t l_10281 = 0xE36D9520L;
            union U5 *****l_10304 = (void*)0;
            struct S0 *l_10315 = (void*)0;
            uint32_t ****l_10331[9] = {&g_3250[8],&g_3250[8],&g_3250[8],&g_3250[8],&g_3250[8],&g_3250[8],&g_3250[8],&g_3250[8],&g_3250[8]};
            uint32_t *****l_10330 = &l_10331[0];
            int32_t l_10337 = 0x9E602DDEL;
            int32_t l_10343 = (-1L);
            int32_t l_10346 = (-3L);
            int32_t l_10347 = (-7L);
            int32_t l_10349 = 0xB534EB98L;
            int32_t l_10351 = 1L;
            int32_t l_10352 = 0L;
            int32_t l_10353 = 0L;
            int32_t l_10355 = 0x624E7D38L;
            int32_t l_10357[4][7][3] = {{{0x30DC8A15L,0x3FF9E1E5L,0x4D879C9AL},{1L,0x30DC8A15L,1L},{0x0DB3BCA8L,0x8085648BL,9L},{1L,1L,1L},{1L,(-6L),1L},{0x92238218L,0xF367D61DL,0x35D4E02EL},{0L,0L,0x75074D43L}},{{0x8AF8430DL,0x92238218L,0x35D4E02EL},{0x8599801BL,0xBEB12BEFL,1L},{0xAA12F3E7L,0x75074D43L,1L},{0x946D383CL,0x59DE488FL,9L},{0xBEB12BEFL,0x35D4E02EL,1L},{0x456E3320L,1L,0x4D879C9AL},{1L,0xFB8AE51BL,5L}},{{1L,0xE3F64F35L,0xBEB12BEFL},{0x456E3320L,0xD5298DB4L,0L},{0xBEB12BEFL,0x8AF8430DL,0x8AF8430DL},{0x946D383CL,0x5F9B0753L,0x8085648BL},{0xAA12F3E7L,0x8599801BL,(-1L)},{0x8599801BL,0x811E0D8CL,0L},{0x8AF8430DL,0xEFAF5933L,0L}},{{0L,0x811E0D8CL,0x59DE488FL},{0x92238218L,0x8599801BL,0xFB8AE51BL},{1L,0x5F9B0753L,0xEFAF5933L},{1L,0x8AF8430DL,0xAA12F3E7L},{0x0DB3BCA8L,0xD5298DB4L,0x3FF9E1E5L},{1L,0xE3F64F35L,0x6366F5B7L},{0x30DC8A15L,0xFB8AE51BL,0x6366F5B7L}}};
            int32_t *l_10362 = &l_10134;
            int32_t *l_10363 = &l_10352;
            int32_t *l_10369 = (void*)0;
            int32_t *l_10370 = &l_10352;
            int32_t *l_10371[3];
            uint16_t *l_10396 = &g_1218[2][5];
            int i, j, k;
            for (i = 0; i < 8; i++)
                l_10276[i] = 0x26275EE1L;
            for (i = 0; i < 3; i++)
                l_10371[i] = &g_38;
            if ((((l_10275 | l_10276[3]) < 0xFA46150AF19D98F4LL) != (safe_div_func_int8_t_s_s(((((l_10276[0] > (safe_mul_func_uint8_t_u_u(l_10281, (((*****g_5407) |= (safe_rshift_func_int8_t_s_s((safe_lshift_func_int8_t_s_u((0x8486L <= 0x9C23L), 2)), ((safe_div_func_int16_t_s_s((p_61 |= (*l_95)), ((safe_mod_func_int8_t_s_s((safe_div_func_uint16_t_u_u(((*g_929) != (*g_836)), 0xD5B4L)), l_10275)) && (*l_95)))) ^ 65535UL)))) >= 1L)))) , 0xC733L) > 65533UL) , p_62), (*g_7633)))))
            { /* block id: 4331 */
                union U3 * const l_10292[1] = {&g_10293};
                union U5 ** const * const **l_10314 = (void*)0;
                int32_t l_10319 = (-1L);
                int32_t l_10342 = 0x3FEEBCD0L;
                int8_t l_10344 = 0x37L;
                int32_t l_10345 = 0xF5509DF5L;
                int32_t l_10348 = 0L;
                int32_t l_10350 = 1L;
                int32_t l_10354 = 1L;
                int32_t l_10356 = (-5L);
                int i;
                for (g_1273 = 2; (g_1273 >= 0); g_1273 -= 1)
                { /* block id: 4334 */
                    int16_t l_10310 = 0x3D08L;
                    int32_t l_10316 = (-1L);
                    union U2 *l_10335 = &g_10336;
                    union U2 **l_10334 = &l_10335;
                    int32_t *l_10338[1];
                    uint16_t l_10339 = 0x1135L;
                    int i;
                    for (i = 0; i < 1; i++)
                        l_10338[i] = &l_10271;
                    for (g_9425.f3 = 2; (g_9425.f3 >= 0); g_9425.f3 -= 1)
                    { /* block id: 4337 */
                        union U3 **l_10294 = &g_746;
                        int32_t *l_10309 = &l_10271;
                        int32_t *l_10317 = (void*)0;
                        int32_t *l_10318 = &l_10250[1];
                        (*l_10294) = l_10292[0];
                        (*l_10318) = (safe_rshift_func_int16_t_s_u((l_10258 && (safe_div_func_uint32_t_u_u((safe_div_func_uint64_t_u_u(((**g_1540) = ((l_10301 != (((safe_mod_func_int32_t_s_s((l_10304 == (l_10314 = ((p_61 ^ (((safe_div_func_int16_t_s_s((((((p_62 , (safe_div_func_int16_t_s_s(((*l_10309) = ((p_61 , (void*)0) != l_10309)), p_62))) , p_62) < (*l_95)) , p_62) , p_61), (*l_95))) & l_10310) & p_61)) , l_10311))), p_61)) > p_62) , l_10315)) != 1UL)), p_61)), 0xCF6A5772L))), l_10316));
                        (*l_10318) ^= (((*g_2302) = (**g_6523)) == (void*)0);
                        l_10249 &= l_10319;
                    }
                    (*l_10334) = (((safe_mul_func_uint8_t_u_u(1UL, (((safe_rshift_func_uint8_t_u_u((*g_656), 7)) < ((((safe_lshift_func_uint8_t_u_s((safe_sub_func_int8_t_s_s((safe_lshift_func_uint8_t_u_s((*l_95), 2)), ((*l_95) , (((void*)0 == l_10330) || 0xBEL)))), (safe_rshift_func_uint8_t_u_s(((void*)0 == &g_8527), p_61)))) >= l_10276[3]) != p_62) > p_61)) < p_62))) || 0xC8AE5680L) , (void*)0);
                    l_10339--;
                    ++l_10358;
                }
            }
            else
            { /* block id: 4351 */
                int32_t *l_10361 = &l_10258;
                return l_10364;
            }
            if (g_6607.f0)
                goto lbl_10365;
            g_10366--;
            l_10372++;
            for (g_1221 = 0; (g_1221 <= 2); g_1221 += 1)
            { /* block id: 4359 */
                uint8_t l_10385[10] = {0xCCL,0x34L,0xCCL,7UL,3UL,7UL,0xCCL,0xCCL,7UL,3UL};
                uint32_t **l_10403 = &g_4088[0];
                int i;
                if ((((safe_rshift_func_uint16_t_u_s(p_61, 1)) , ((!(safe_mod_func_uint64_t_u_u(((safe_lshift_func_int8_t_s_u(l_10382, 0)) != (((((*l_10362) = ((safe_mul_func_int8_t_s_s(((l_10385[1] , (*g_6483)) == (void*)0), ((**g_4423) &= (l_10275 , ((((4294967294UL ^ l_10255) == (safe_sub_func_uint16_t_u_u((l_10388[2][2][1]--), (safe_add_func_int32_t_s_s(((&l_10258 != &l_10258) < l_10385[1]), p_61))))) != p_62) < p_61))))) ^ 0UL)) <= p_61) | p_62) , 0L)), 0xFD727097B0A3448ALL))) && p_61)) <= l_10385[8]))
                { /* block id: 4363 */
                    (*l_10370) = p_61;
                    if (g_1219)
                        goto lbl_10393;
                }
                else
                { /* block id: 4366 */
                    uint32_t ***l_10402 = &g_929;
                    uint16_t ***l_10404 = &g_714;
                    if ((((safe_sub_func_int16_t_s_s(((void*)0 == l_10396), (safe_unary_minus_func_uint32_t_u(((***l_10402) = (safe_lshift_func_uint8_t_u_u((((**l_10238) = (((*g_1541) ^= (p_62 || p_62)) >= ((*g_7503) == ((0xB3L > (safe_mul_func_int16_t_s_s(1L, (****g_1675)))) , l_10402)))) , 1UL), l_10385[1]))))))) , l_10403) != (void*)0))
                    { /* block id: 4370 */
                        l_10255 ^= 0x8917E6D4L;
                    }
                    else
                    { /* block id: 4372 */
                        int32_t l_10405 = 0xBADE5812L;
                        l_10404 = (void*)0;
                        (****g_2717) = (void*)0;
                        if (l_10405)
                            break;
                    }
                }
            }
        }
        if ((safe_div_func_int64_t_s_s((l_10253 = ((*g_6119) |= (l_10257 , (+((safe_add_func_int32_t_s_s(((safe_lshift_func_uint16_t_u_s((((*l_10415) = l_10413) == l_10413), (safe_sub_func_int8_t_s_s((safe_unary_minus_func_uint64_t_u((!((((l_10421 = l_10420) == (l_10423[1][4][0] = l_10422)) && (l_10177 ^= (safe_rshift_func_uint8_t_u_s((~((+(safe_lshift_func_uint16_t_u_s((safe_sub_func_uint8_t_u_u((((l_10258 &= (*l_95)) < (*l_95)) <= (!((safe_div_func_int64_t_s_s((safe_sub_func_uint16_t_u_u((safe_div_func_uint64_t_u_u(((**g_1540) = (((**l_10238) &= (safe_sub_func_int8_t_s_s(((l_10218 <= 1UL) != p_62), p_62))) | p_61)), l_10260[1])), p_62)), p_61)) , 0x20D9L))), (*g_28))), p_62))) <= 0UL)), 4)))) ^ p_61)))), 0L)))) || (*l_95)), l_10260[2])) || (-10L)))))), 2L)))
        { /* block id: 4389 */
            struct S0 *l_10446 = &g_10447;
            int32_t l_10463 = 0x351EACD6L;
            union U2 *l_10467 = &g_10468[5];
            int32_t l_10474 = 0x0E708973L;
            int32_t l_10476 = 0xE5353FE9L;
            int32_t l_10479[1];
            uint32_t *** const l_10519 = &g_4087;
            int8_t *l_10573 = (void*)0;
            uint16_t *l_10599 = &g_5546[4][1][5];
            union U3 *l_10682 = (void*)0;
            int i;
            for (i = 0; i < 1; i++)
                l_10479[i] = (-1L);
            l_10444 = l_10442;
            l_10448 = l_10446;
            for (g_6584.f3 = 0; (g_6584.f3 <= 2); g_6584.f3 += 1)
            { /* block id: 4394 */
                int32_t l_10456 = 0xA64A1A8EL;
                int32_t l_10477 = 0x5835B124L;
                int32_t l_10480 = 0x81887867L;
                int32_t l_10482 = (-2L);
                int32_t l_10485 = 0xA8D0CBA4L;
                int32_t l_10486 = (-5L);
                int32_t l_10488 = 0L;
                int32_t l_10489 = 3L;
                int64_t l_10505 = 0x902197DBC3AA92B4LL;
                uint32_t l_10507[3][2];
                int32_t *l_10527[4];
                uint32_t l_10541[3];
                int32_t *l_10641 = &l_10249;
                int8_t *l_10646 = &g_431;
                uint8_t ***l_10659 = &g_4139;
                union U2 **l_10660 = &l_10584;
                struct S1 **l_10678 = (void*)0;
                int i, j;
                for (i = 0; i < 3; i++)
                {
                    for (j = 0; j < 2; j++)
                        l_10507[i][j] = 0x44336074L;
                }
                for (i = 0; i < 4; i++)
                    l_10527[i] = &g_1396;
                for (i = 0; i < 3; i++)
                    l_10541[i] = 0x73EB7AABL;
                if (((void*)0 != &p_61))
                { /* block id: 4395 */
                    int32_t *l_10462 = &g_7[2][5][1];
                    l_10456 = (safe_sub_func_int32_t_s_s((safe_add_func_int64_t_s_s((p_61 | ((-1L) || (safe_mul_func_int16_t_s_s((p_61 || l_10218), l_10177)))), (l_10456 ^ p_62))), ((safe_div_func_uint8_t_u_u((safe_add_func_int8_t_s_s(((g_10461 == 0x5F7B51EAL) == p_61), 0xD7L)), p_62)) || l_10456)));
                    (*g_1207) = l_10462;
                    for (g_6882.f3 = 1; (g_6882.f3 >= 0); g_6882.f3 -= 1)
                    { /* block id: 4400 */
                        uint64_t l_10464[7][1] = {{0x38C88BAF1ADEAB49LL},{0xFDEA37842A1149FALL},{0xFDEA37842A1149FALL},{0x38C88BAF1ADEAB49LL},{0xFDEA37842A1149FALL},{0xFDEA37842A1149FALL},{0x38C88BAF1ADEAB49LL}};
                        int i, j;
                        ++l_10464[4][0];
                    }
                    l_10241 &= (*****g_2717);
                }
                else
                { /* block id: 4404 */
                    int16_t l_10481 = 1L;
                    int32_t l_10483 = (-8L);
                    int32_t l_10484 = 0x3D6856E3L;
                    int32_t l_10487[3][3] = {{9L,9L,9L},{(-1L),(-1L),(-1L)},{9L,9L,9L}};
                    uint32_t l_10490 = 0xE01E515AL;
                    int32_t *l_10506[5] = {&l_10260[2],&l_10260[2],&l_10260[2],&l_10260[2],&l_10260[2]};
                    int i, j;
                    for (g_1727 = 0; (g_1727 <= 2); g_1727 += 1)
                    { /* block id: 4407 */
                        int32_t *l_10469 = &l_10250[1];
                        int32_t *l_10470 = &g_163;
                        int32_t *l_10471 = &l_10245;
                        int32_t *l_10472 = &g_3420[3];
                        int32_t *l_10473 = &g_3420[2];
                        int32_t *l_10475[3];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_10475[i] = &g_8779;
                        if (l_10456)
                            break;
                        l_10467 = (void*)0;
                        l_10490++;
                    }
                    l_10487[1][2] = (l_10486 ^= (safe_rshift_func_uint16_t_u_u(((safe_add_func_int16_t_s_s((((0xC9L | ((safe_lshift_func_uint8_t_u_u(((((void*)0 != &p_61) ^ ((**g_929) = p_61)) < (safe_rshift_func_int16_t_s_u(p_61, p_61))), ((safe_div_func_int16_t_s_s(l_10487[2][0], l_10260[2])) || (safe_sub_func_uint8_t_u_u((0L != p_61), p_62))))) == p_62)) , p_61) & l_10505), p_62)) == p_61), p_62)));
                    ++l_10507[2][1];
                }
            }
        }
        else
        { /* block id: 4488 */
            union U5 *l_10702[1];
            union U4 ****l_10706[7][1] = {{&g_6523},{&g_6523},{&g_6523},{&g_6523},{&g_6523},{&g_6523},{&g_6523}};
            union U4 *****l_10705[9] = {&l_10706[5][0],&l_10706[5][0],&l_10706[5][0],&l_10706[5][0],&l_10706[5][0],&l_10706[5][0],&l_10706[5][0],&l_10706[5][0],&l_10706[5][0]};
            union U5 * const ****l_10712[9];
            union U5 ****l_10714 = &l_10520;
            union U5 *****l_10713 = &l_10714;
            int32_t l_10715 = 1L;
            uint32_t l_10726[5];
            int64_t ** const *l_10740 = &l_10238;
            int32_t l_10805[6][9][4] = {{{0L,0x91F86276L,1L,0xC260A58CL},{0x5045D845L,0x788C636EL,0xA98EF45BL,0x3391763EL},{1L,0L,1L,1L},{1L,1L,0xA98EF45BL,1L},{0x5045D845L,1L,1L,0x788C636EL},{0L,5L,0L,1L},{0xC260A58CL,5L,0xC260A58CL,0x788C636EL},{5L,1L,(-1L),1L},{1L,1L,0L,1L}},{{0x3391763EL,0L,0L,0x3391763EL},{1L,0x788C636EL,(-1L),0xC260A58CL},{5L,0x91F86276L,0xC260A58CL,0xA98EF45BL},{0xC260A58CL,0xA98EF45BL,0L,0xA98EF45BL},{0L,0x91F86276L,1L,0xC260A58CL},{0x5045D845L,0x788C636EL,0xA98EF45BL,0x3391763EL},{1L,0L,1L,1L},{1L,1L,0xA98EF45BL,1L},{0x5045D845L,1L,1L,0x788C636EL}},{{0L,5L,0L,1L},{0xC260A58CL,5L,0xC260A58CL,0x788C636EL},{5L,1L,(-1L),1L},{1L,1L,0L,1L},{0x3391763EL,0L,0L,0x3391763EL},{1L,0x788C636EL,(-1L),0xC260A58CL},{5L,0x91F86276L,0xC260A58CL,0xA98EF45BL},{0xC260A58CL,0xA98EF45BL,0L,0xA98EF45BL},{0L,0x91F86276L,1L,0xC260A58CL}},{{0x5045D845L,0x788C636EL,0xA98EF45BL,0x3391763EL},{1L,0L,1L,1L},{1L,1L,0xA98EF45BL,1L},{0x5045D845L,1L,1L,0x788C636EL},{0L,5L,0L,1L},{0xC260A58CL,5L,0xC260A58CL,0x788C636EL},{5L,1L,(-1L),1L},{1L,1L,0L,1L},{0x3391763EL,0L,0L,0x3391763EL}},{{1L,0x788C636EL,0L,1L},{1L,(-1L),1L,5L},{1L,5L,0x5045D845L,5L},{0x3391763EL,(-1L),0xA98EF45BL,1L},{0xC260A58CL,0x91F86276L,5L,1L},{0xA98EF45BL,0x3391763EL,0L,0L},{0xA98EF45BL,0xA98EF45BL,5L,0x788C636EL},{0xC260A58CL,0L,0xA98EF45BL,0x91F86276L},{0x3391763EL,1L,0x5045D845L,0xA98EF45BL}},{{1L,1L,1L,0x91F86276L},{1L,0L,0L,0x788C636EL},{0x788C636EL,0xA98EF45BL,0x3391763EL,0L},{1L,0x3391763EL,0x3391763EL,1L},{0x788C636EL,0x91F86276L,0L,1L},{1L,(-1L),1L,5L},{1L,5L,0x5045D845L,5L},{0x3391763EL,(-1L),0xA98EF45BL,1L},{0xC260A58CL,0x91F86276L,5L,1L}}};
            uint64_t ***l_10811 = &l_10760;
            int32_t l_10836 = 4L;
            union U2 *l_10838[8] = {(void*)0,&g_10840,(void*)0,&g_10840,(void*)0,&g_10840,(void*)0,&g_10840};
            int32_t *l_10844 = (void*)0;
            uint32_t ****l_10890 = &l_10518;
            int32_t l_10891 = 6L;
            uint32_t **l_10892 = &g_930[1][8];
            uint64_t l_10909[2][5];
            int64_t l_10912 = 0L;
            union U3 ** const l_10917 = &g_746;
            union U3 ** const *l_10916 = &l_10917;
            union U3 ** const * const *l_10915[2][10][6] = {{{&l_10916,&l_10916,&l_10916,&l_10916,&l_10916,(void*)0},{&l_10916,&l_10916,&l_10916,&l_10916,&l_10916,&l_10916},{&l_10916,&l_10916,(void*)0,(void*)0,(void*)0,&l_10916},{(void*)0,&l_10916,&l_10916,&l_10916,&l_10916,&l_10916},{&l_10916,&l_10916,&l_10916,(void*)0,&l_10916,&l_10916},{&l_10916,&l_10916,&l_10916,&l_10916,&l_10916,&l_10916},{&l_10916,&l_10916,&l_10916,&l_10916,&l_10916,&l_10916},{&l_10916,&l_10916,&l_10916,&l_10916,&l_10916,&l_10916},{&l_10916,&l_10916,&l_10916,&l_10916,(void*)0,&l_10916},{(void*)0,&l_10916,&l_10916,&l_10916,&l_10916,&l_10916}},{{&l_10916,&l_10916,&l_10916,&l_10916,&l_10916,&l_10916},{&l_10916,&l_10916,&l_10916,&l_10916,&l_10916,&l_10916},{&l_10916,&l_10916,(void*)0,&l_10916,(void*)0,&l_10916},{&l_10916,&l_10916,&l_10916,&l_10916,&l_10916,&l_10916},{&l_10916,&l_10916,&l_10916,&l_10916,&l_10916,&l_10916},{&l_10916,(void*)0,(void*)0,&l_10916,&l_10916,&l_10916},{&l_10916,&l_10916,&l_10916,&l_10916,&l_10916,&l_10916},{&l_10916,&l_10916,&l_10916,&l_10916,&l_10916,&l_10916},{(void*)0,&l_10916,&l_10916,&l_10916,&l_10916,(void*)0},{&l_10916,(void*)0,&l_10916,(void*)0,&l_10916,&l_10916}}};
            union U3 *l_10955 = &g_10956;
            uint32_t * const *l_11022 = (void*)0;
            uint32_t * const **l_11021[9][6] = {{(void*)0,(void*)0,&l_11022,&l_11022,(void*)0,&l_11022},{&l_11022,(void*)0,&l_11022,(void*)0,&l_11022,&l_11022},{&l_11022,&l_11022,&l_11022,&l_11022,(void*)0,&l_11022},{&l_11022,&l_11022,&l_11022,&l_11022,&l_11022,(void*)0},{&l_11022,&l_11022,(void*)0,(void*)0,&l_11022,&l_11022},{&l_11022,&l_11022,(void*)0,&l_11022,(void*)0,&l_11022},{(void*)0,&l_11022,(void*)0,&l_11022,&l_11022,(void*)0},{(void*)0,(void*)0,&l_11022,&l_11022,(void*)0,&l_11022},{&l_11022,(void*)0,&l_11022,(void*)0,&l_11022,&l_11022}};
            uint32_t * const ***l_11020[9] = {&l_11021[4][5],&l_11021[4][5],&l_11021[4][5],&l_11021[4][5],&l_11021[4][5],&l_11021[4][5],&l_11021[4][5],&l_11021[4][5],&l_11021[4][5]};
            uint64_t l_11063 = 0xFE40677C5C021EF9LL;
            struct S0 *l_11146 = &g_11147;
            uint32_t l_11153 = 4294967287UL;
            int32_t *l_11156 = &g_7[2][5][1];
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_10702[i] = (void*)0;
            for (i = 0; i < 9; i++)
                l_10712[i] = &g_10709;
            for (i = 0; i < 5; i++)
                l_10726[i] = 0xCF0BC5FBL;
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 5; j++)
                    l_10909[i][j] = 18446744073709551613UL;
            }
            (**g_6483) = l_10702[0];
            if ((safe_mul_func_int16_t_s_s((((void*)0 != l_10705[6]) & 7UL), (((safe_rshift_func_uint16_t_u_u((((g_10709 = g_10709) == ((*l_10713) = (void*)0)) ^ 4294967289UL), 4)) & (((l_10715 = (*g_7633)) ^ (safe_sub_func_uint64_t_u_u((safe_sub_func_int64_t_s_s((safe_mul_func_uint16_t_u_u((((****l_10693) = (-1L)) >= (safe_div_func_uint64_t_u_u((safe_div_func_uint16_t_u_u(l_10726[3], l_10587[1][2])), 3UL))), 0x1B42L)), 18446744073709551611UL)), (-10L)))) | p_62)) <= 0x84C5B11CL))))
            { /* block id: 4494 */
                union U2 *l_10728 = &g_10729;
                const int32_t l_10734 = (-1L);
                union U4 ***l_10735 = &g_2302;
                union U4 ***l_10736 = &g_2302;
                int32_t l_10737 = 1L;
                union U5 *l_10738 = &g_10739[0];
                l_10715 = ((l_10587[1][0] >= p_61) == (safe_unary_minus_func_int8_t_s((l_10726[3] == (((*l_10647) = ((((l_10728 != l_10584) == (safe_lshift_func_uint16_t_u_s((safe_mul_func_uint16_t_u_u(l_10734, ((p_62 | ((((((((l_10735 != (p_61 , l_10736)) <= 1UL) ^ p_62) , l_10218) <= 0x60F5L) != (*l_95)) > 4294967295UL) , 0xD158B777168CA282LL)) , p_62))), 14))) && (*g_6119)) || 0L)) || (-1L))))));
                l_10257 ^= (l_10737 = (0xAF23L < p_61));
                (**g_6483) = l_10738;
                for (g_922.f1 = 3; (g_922.f1 <= 9); g_922.f1 += 1)
                { /* block id: 4502 */
                    int64_t ** const **l_10741 = &l_10740;
                    const union U4 ****l_10757 = &g_10753;
                    int32_t l_10758 = 0x7F8E6F89L;
                    uint64_t *****l_10761[10] = {&g_10194[2],&g_10194[0],&g_10194[2],&g_10194[0],&g_10194[2],&g_10194[2],&g_10194[0],&g_10194[2],&g_10194[0],&g_10194[2]};
                    int i;
                    if ((((0L ^ (((*l_10741) = l_10740) != (void*)0)) || ((((safe_sub_func_uint64_t_u_u(0x30DD02F0A7962A25LL, 0x9F4E104AA72BBFEFLL)) || ((~((safe_sub_func_int32_t_s_s((~((safe_div_func_uint16_t_u_u((safe_sub_func_uint32_t_u_u((l_10752 != ((*l_10757) = g_10753)), p_62)), l_10758)) & 0xD6L)), (*l_95))) , 0xDA2CL)) | 0x111204D1L)) , (*g_5411)) & l_10758)) <= l_10759))
                    { /* block id: 4505 */
                        int8_t l_10767 = 1L;
                        uint32_t **l_10774 = &g_4088[0];
                        uint32_t *** const l_10773[1] = {&l_10774};
                        uint32_t *** const *l_10772 = &l_10773[0];
                        uint32_t *** const **l_10771 = &l_10772;
                        int32_t l_10778 = 1L;
                        int i;
                        l_10715 &= (((void*)0 != l_10760) > ((l_10761[0] == (l_10764 = l_10762)) < (safe_sub_func_int64_t_s_s(((((((***g_4422) = l_10767) || (((p_61 <= (safe_lshift_func_int16_t_s_u(l_10770, l_10726[3]))) & (p_62 && (-1L))) , l_10758)) , p_61) >= (-3L)) , 0xC17086C046A99B0ALL), l_10767))));
                        l_10737 = p_61;
                        l_10778 |= ((l_10775 = (p_62 , ((*l_10771) = (void*)0))) != (void*)0);
                    }
                    else
                    { /* block id: 4513 */
                        int32_t *l_10779 = &g_255;
                        return l_10779;
                    }
                    l_10737 |= 0x54F83869L;
                }
            }
            else
            { /* block id: 4518 */
                union U4 *****l_10801[7][2];
                const int32_t l_10804[2] = {0xDD22EBE8L,0xDD22EBE8L};
                int32_t l_10835 = 0xD1AD5E9DL;
                int32_t l_10837 = 0L;
                int16_t * const ** const * const l_10850 = (void*)0;
                int16_t * const ** const * const *l_10849[7][8][4] = {{{(void*)0,&l_10850,&l_10850,&l_10850},{&l_10850,(void*)0,(void*)0,&l_10850},{&l_10850,&l_10850,(void*)0,&l_10850},{&l_10850,&l_10850,&l_10850,&l_10850},{(void*)0,&l_10850,&l_10850,&l_10850},{(void*)0,&l_10850,&l_10850,&l_10850},{&l_10850,&l_10850,&l_10850,&l_10850},{&l_10850,&l_10850,&l_10850,&l_10850}},{{(void*)0,&l_10850,&l_10850,&l_10850},{(void*)0,&l_10850,&l_10850,(void*)0},{&l_10850,&l_10850,(void*)0,&l_10850},{&l_10850,(void*)0,(void*)0,&l_10850},{&l_10850,&l_10850,&l_10850,(void*)0},{(void*)0,&l_10850,&l_10850,&l_10850},{&l_10850,&l_10850,&l_10850,&l_10850},{&l_10850,&l_10850,&l_10850,&l_10850}},{{&l_10850,&l_10850,&l_10850,&l_10850},{(void*)0,&l_10850,(void*)0,&l_10850},{&l_10850,(void*)0,&l_10850,&l_10850},{&l_10850,&l_10850,&l_10850,&l_10850},{&l_10850,&l_10850,&l_10850,&l_10850},{&l_10850,&l_10850,(void*)0,&l_10850},{&l_10850,&l_10850,&l_10850,&l_10850},{(void*)0,&l_10850,&l_10850,(void*)0}},{{&l_10850,&l_10850,&l_10850,&l_10850},{&l_10850,(void*)0,(void*)0,&l_10850},{(void*)0,&l_10850,&l_10850,&l_10850},{&l_10850,(void*)0,&l_10850,&l_10850},{&l_10850,&l_10850,&l_10850,&l_10850},{(void*)0,&l_10850,(void*)0,&l_10850},{&l_10850,&l_10850,(void*)0,(void*)0},{(void*)0,&l_10850,&l_10850,&l_10850}},{{&l_10850,&l_10850,&l_10850,&l_10850},{&l_10850,&l_10850,&l_10850,&l_10850},{&l_10850,&l_10850,&l_10850,&l_10850},{&l_10850,&l_10850,(void*)0,(void*)0},{&l_10850,&l_10850,&l_10850,&l_10850},{&l_10850,(void*)0,&l_10850,&l_10850},{&l_10850,&l_10850,&l_10850,&l_10850},{(void*)0,(void*)0,(void*)0,&l_10850}},{{&l_10850,&l_10850,&l_10850,(void*)0},{&l_10850,&l_10850,(void*)0,&l_10850},{(void*)0,&l_10850,&l_10850,(void*)0},{&l_10850,&l_10850,&l_10850,&l_10850},{(void*)0,(void*)0,&l_10850,&l_10850},{&l_10850,&l_10850,(void*)0,&l_10850},{&l_10850,(void*)0,&l_10850,&l_10850},{&l_10850,&l_10850,&l_10850,(void*)0}},{{(void*)0,&l_10850,&l_10850,&l_10850},{&l_10850,&l_10850,&l_10850,&l_10850},{&l_10850,&l_10850,&l_10850,&l_10850},{&l_10850,&l_10850,(void*)0,&l_10850},{&l_10850,&l_10850,(void*)0,(void*)0},{&l_10850,&l_10850,&l_10850,&l_10850},{&l_10850,&l_10850,(void*)0,&l_10850},{&l_10850,&l_10850,(void*)0,&l_10850}}};
                int16_t *** const **l_10934 = (void*)0;
                int16_t *** const *l_10936 = &l_10700;
                int16_t *** const **l_10935 = &l_10936;
                union U3 **l_10940 = &g_746;
                union U3 ***l_10939[8][3][3] = {{{&l_10940,&l_10940,&l_10940},{&l_10940,&l_10940,&l_10940},{&l_10940,&l_10940,&l_10940}},{{&l_10940,&l_10940,&l_10940},{&l_10940,&l_10940,(void*)0},{&l_10940,&l_10940,&l_10940}},{{&l_10940,&l_10940,&l_10940},{&l_10940,&l_10940,&l_10940},{&l_10940,&l_10940,&l_10940}},{{&l_10940,&l_10940,&l_10940},{&l_10940,&l_10940,&l_10940},{&l_10940,&l_10940,&l_10940}},{{&l_10940,&l_10940,(void*)0},{&l_10940,&l_10940,&l_10940},{&l_10940,&l_10940,&l_10940}},{{&l_10940,&l_10940,&l_10940},{&l_10940,&l_10940,&l_10940},{&l_10940,&l_10940,&l_10940}},{{&l_10940,&l_10940,(void*)0},{&l_10940,&l_10940,&l_10940},{&l_10940,&l_10940,&l_10940}},{{&l_10940,&l_10940,&l_10940},{&l_10940,&l_10940,&l_10940},{&l_10940,&l_10940,&l_10940}}};
                union U3 ****l_10938 = &l_10939[7][1][2];
                int i, j, k;
                for (i = 0; i < 7; i++)
                {
                    for (j = 0; j < 2; j++)
                        l_10801[i][j] = &l_10706[5][0];
                }
                (***g_9259) = ((**g_6483) = ((safe_lshift_func_int8_t_s_u(p_62, 5)) , (*g_6484)));
                if ((l_10177 | (l_10784 = ((**g_929)++))))
                { /* block id: 4523 */
                    uint32_t l_10802 = 0xD15AABFDL;
                    int32_t l_10803 = (-4L);
                    uint64_t ***l_10813 = (void*)0;
                    uint64_t ****l_10812 = &l_10813;
                    l_10805[2][5][0] = ((safe_lshift_func_int8_t_s_u(l_10255, ((((0xFBL != ((l_10803 |= ((((safe_add_func_uint16_t_u_u(0x22F2L, (safe_mod_func_uint64_t_u_u((l_10715 = ((((2UL <= (((**g_4139) &= p_61) != (((((safe_mul_func_int8_t_s_s(((l_10726[3] ^ l_10726[0]) , (safe_add_func_int32_t_s_s((((safe_mod_func_int16_t_s_s(((safe_sub_func_uint16_t_u_u((safe_rshift_func_int16_t_s_u((0x0EC855045A7C46DFLL != 0xDE1B43D32E68AD0CLL), 7)), p_62)) < p_62), 1UL)) , l_10801[6][1]) == (void*)0), p_62))), l_10802)) == p_62) < p_61) , (void*)0) == &g_8527))) == p_61) ^ 0xA9L) , 1UL)), p_62)))) , p_61) , p_61) , (*l_95))) > p_61)) >= l_10804[1]) == l_10802) , p_62))) | l_10726[3]);
                    if (((safe_sub_func_uint32_t_u_u(((safe_mul_func_int8_t_s_s((l_10810 == &g_9881), l_10715)) < l_10358), ((**g_929) <= (l_10803 = (((((**g_10193) = l_10811) != ((*l_10812) = l_10811)) > (safe_unary_minus_func_int64_t_s(((safe_rshift_func_int8_t_s_s((safe_div_func_int16_t_s_s((((safe_add_func_int64_t_s_s(((((((l_10805[2][5][0] = (((safe_sub_func_uint16_t_u_u(((**g_714)--), p_62)) , (safe_rshift_func_int16_t_s_u(((safe_sub_func_uint8_t_u_u(((safe_add_func_uint16_t_u_u(65530UL, 1UL)) || l_10358), 251UL)) , (-2L)), 6))) , 0x088BL)) , (void*)0) != &l_10700) || l_10726[3]) < (***g_4422)) > 1UL), p_61)) > l_10257) , (***g_1676)), (****g_1675))), 4)) > 0xF0L)))) & p_62))))) , p_62))
                    { /* block id: 4533 */
                        uint8_t l_10831 = 7UL;
                        (*g_10754) = (l_10831 , l_10442);
                        l_10805[2][5][0] = (0xDBL < 0x84L);
                        l_10698 = l_10832;
                        l_10837 = (l_10803 ^= (l_10836 = (((*g_715)--) && (0xBE38AA93L != (l_10835 = p_61)))));
                    }
                    else
                    { /* block id: 4542 */
                        int32_t *l_10843[5] = {&l_10258,&l_10258,&l_10258,&l_10258,&l_10258};
                        int i;
                        l_10841 = l_10838[7];
                        return l_10844;
                    }
                }
                else
                { /* block id: 4546 */
                    int32_t *l_10845 = &l_10250[1];
                    for (g_6607.f0 = 0; (g_6607.f0 <= 1); g_6607.f0 += 1)
                    { /* block id: 4549 */
                        int32_t *l_10846[7][1][2] = {{{&l_10835,&l_10835}},{{&l_10835,&l_10835}},{{&l_10835,&l_10835}},{{&l_10835,&l_10835}},{{&l_10835,&l_10835}},{{&l_10835,&l_10835}},{{&l_10835,&l_10835}}};
                        int i, j, k;
                        return l_10848;
                    }
                }
                if (((l_10849[1][6][0] != (((p_62 | (safe_lshift_func_int8_t_s_s(((safe_sub_func_int64_t_s_s(0xC97567405416ADDDLL, p_62)) , (safe_add_func_int16_t_s_s((l_10835 ^= (safe_div_func_uint16_t_u_u((p_62 & (safe_lshift_func_uint16_t_u_u((((**g_929) = (safe_div_func_int8_t_s_s(0x94L, (safe_mod_func_int8_t_s_s((safe_div_func_int64_t_s_s(((1UL || (*l_10847)) | p_61), p_61)), p_61))))) > p_61), p_61))), p_61))), l_10867))), 4))) ^ 0L) , (void*)0)) != p_61))
                { /* block id: 4555 */
                    uint16_t l_10901 = 0xA150L;
                    int32_t l_10910 = 0x171911DAL;
lbl_10911:
                    if ((*l_10847))
                    { /* block id: 4556 */
                        int32_t *l_10868 = &g_8779;
                        return l_10868;
                    }
                    else
                    { /* block id: 4558 */
                        int32_t l_10893 = (-4L);
                        l_10893 = (p_62 != ((safe_div_func_uint16_t_u_u(((safe_sub_func_int32_t_s_s((safe_mul_func_uint8_t_u_u(((****g_5408) = (safe_mul_func_uint16_t_u_u((safe_div_func_uint64_t_u_u(((safe_mul_func_int16_t_s_s(((safe_rshift_func_int16_t_s_s(((safe_rshift_func_int16_t_s_s(p_62, ((0xCCF768D8L == ((((4L >= (((**g_1540) |= ((safe_mod_func_uint16_t_u_u(0x5BDEL, p_61)) , (!p_61))) > (((((p_61 != ((safe_lshift_func_int8_t_s_s(((&g_9694[4] != l_10890) < 255UL), (*g_7633))) || p_61)) ^ (-1L)) <= l_10891) , (void*)0) != l_10892))) | 1UL) != 0x93593E24L) , l_10837)) , p_61))) , p_62), p_61)) > 9UL), 4L)) != l_10837), 3UL)), (*g_5749)))), p_61)), p_62)) , 0xC73AL), 0xFAF8L)) | p_62));
                    }
                    for (g_446 = (-14); (g_446 != 38); g_446++)
                    { /* block id: 4565 */
                        int8_t l_10905[3][6] = {{0xC1L,0xC1L,0xC1L,0xC1L,0xC1L,0xC1L},{0xC1L,0xC1L,0xC1L,0xC1L,0xC1L,0xC1L},{0xC1L,0xC1L,0xC1L,0xC1L,0xC1L,0xC1L}};
                        int i, j;
                        l_10910 &= (safe_div_func_uint8_t_u_u(((+((p_62 = ((0UL <= (safe_rshift_func_uint16_t_u_s(p_62, ((l_10901 , g_10902) , (((safe_mul_func_int16_t_s_s((p_62 & l_10905[0][3]), ((*l_10847) |= (l_10906 == &g_9694[2])))) , (safe_mul_func_uint16_t_u_u(((p_62 < 0x8385L) , 0x317AL), l_10909[0][1]))) > p_61))))) , p_62)) != (*l_95))) <= 255UL), (*g_7633)));
                        if (l_10910)
                            continue;
                        if (l_10216)
                            goto lbl_10911;
                        if (p_61)
                            break;
                    }
                }
                else
                { /* block id: 4573 */
                    (*l_10847) |= l_10835;
                }
                l_10257 &= ((**g_4423) , ((l_10912 < (safe_add_func_uint16_t_u_u(p_61, (p_62 ^ (l_10915[0][9][3] != ((l_10937 &= (l_10805[1][1][0] = (safe_add_func_int32_t_s_s((safe_add_func_int16_t_s_s((safe_mod_func_uint16_t_u_u((safe_div_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_u(l_10804[1], (safe_sub_func_int32_t_s_s((safe_lshift_func_int8_t_s_u(((l_10837 = ((*l_10847) = (safe_rshift_func_uint16_t_u_u(((p_61 , (*g_1674)) != ((*l_10935) = (void*)0)), 0)))) || p_62), 6)), p_61)))), (*g_6119))), 0xFA7BL)), (***g_1676))), (**g_929))))) , l_10938)))))) , l_10804[0]));
            }
            if (((safe_mod_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u(65531UL, (safe_mul_func_int8_t_s_s((safe_div_func_int16_t_s_s(((safe_mul_func_uint16_t_u_u((((*g_715) = (*l_10847)) <= (((*****g_5407) &= 255UL) | ((safe_add_func_int32_t_s_s((safe_rshift_func_uint16_t_u_u(p_62, (((**l_10916) == l_10955) <= ((safe_add_func_uint32_t_u_u(((**l_10892) ^= (0x4CL ^ p_61)), (safe_sub_func_uint64_t_u_u(((*g_1541) = (((*g_656) |= p_62) ^ (***g_4422))), l_10961)))) , 0xD8L)))), 4294967291UL)) | l_10962))), (*l_10847))) <= p_62), p_61)), 4L)))), (*l_10847))) == (-9L)))
            { /* block id: 4588 */
                const uint32_t l_10965 = 0xC66E5738L;
                int32_t l_10972[2][5][4] = {{{1L,0x950E79F5L,0x950E79F5L,1L},{5L,0x950E79F5L,0x249BD013L,0x950E79F5L},{0x950E79F5L,0x441BC5BFL,0x249BD013L,0x249BD013L},{5L,5L,0x950E79F5L,0x249BD013L},{1L,0x441BC5BFL,1L,0x950E79F5L}},{{1L,0x950E79F5L,0x950E79F5L,1L},{5L,0x950E79F5L,0x249BD013L,0x950E79F5L},{0x950E79F5L,0x441BC5BFL,0x249BD013L,0x249BD013L},{5L,5L,0x950E79F5L,0x249BD013L},{1L,0x441BC5BFL,1L,0x950E79F5L}}};
                int i, j, k;
                g_10973 |= (l_10972[0][4][0] = ((((*l_10847) | ((*g_5127) == (*g_5127))) || ((safe_sub_func_uint32_t_u_u(l_10965, 0x89600377L)) ^ (++(*g_656)))) > ((**l_10892) = ((safe_rshift_func_int16_t_s_u((****g_1675), l_10965)) , ((p_62 == ((**l_10238) = (safe_div_func_int8_t_s_s((p_62 > p_61), 0x2EL)))) || 1L)))));
                return g_10974;
            }
            else
            { /* block id: 4595 */
                const int32_t l_10987 = 0xA68DEF16L;
                union U3 **l_11006[6][8][4] = {{{&l_10955,&l_10955,&l_10955,&l_10955},{&g_746,&l_10955,&l_10955,&l_10955},{&l_10955,&g_746,&l_10955,(void*)0},{&g_746,&l_10955,&l_10955,(void*)0},{&l_10955,&g_746,&g_746,&l_10955},{&l_10955,&l_10955,&l_10955,&l_10955},{&g_746,&l_10955,&l_10955,&l_10955},{&l_10955,&g_746,&l_10955,(void*)0}},{{&g_746,&l_10955,&l_10955,(void*)0},{&l_10955,&g_746,&g_746,&l_10955},{&l_10955,&l_10955,&l_10955,&l_10955},{&g_746,&l_10955,&l_10955,&l_10955},{&l_10955,&g_746,&l_10955,(void*)0},{&g_746,&l_10955,&l_10955,(void*)0},{&l_10955,&g_746,&g_746,&l_10955},{&l_10955,&l_10955,&l_10955,&l_10955}},{{&g_746,&l_10955,&l_10955,&l_10955},{&l_10955,&g_746,&l_10955,(void*)0},{&g_746,&l_10955,&l_10955,(void*)0},{&l_10955,&g_746,&g_746,&l_10955},{&l_10955,&l_10955,&l_10955,&l_10955},{&g_746,&l_10955,&l_10955,&l_10955},{&l_10955,&g_746,&l_10955,(void*)0},{&g_746,&l_10955,&l_10955,(void*)0}},{{&l_10955,&g_746,&g_746,&l_10955},{&l_10955,&l_10955,&l_10955,&l_10955},{&g_746,&l_10955,&l_10955,&l_10955},{&l_10955,&g_746,&l_10955,(void*)0},{&g_746,&l_10955,&l_10955,&g_746},{(void*)0,&l_10955,&l_10955,&l_10955},{(void*)0,&g_746,&g_746,(void*)0},{&l_10955,&g_746,&g_746,&l_10955}},{{&l_10955,&l_10955,&g_746,&g_746},{&l_10955,&l_10955,&g_746,&g_746},{(void*)0,&l_10955,&l_10955,&l_10955},{(void*)0,&g_746,&g_746,(void*)0},{&l_10955,&g_746,&g_746,&l_10955},{&l_10955,&l_10955,&g_746,&g_746},{&l_10955,&l_10955,&g_746,&g_746},{(void*)0,&l_10955,&l_10955,&l_10955}},{{(void*)0,&g_746,&g_746,(void*)0},{&l_10955,&g_746,&g_746,&l_10955},{&l_10955,&l_10955,&g_746,&g_746},{&l_10955,&l_10955,&g_746,&g_746},{(void*)0,&l_10955,&l_10955,&l_10955},{(void*)0,&g_746,&g_746,(void*)0},{&l_10955,&g_746,&g_746,&l_10955},{&l_10955,&l_10955,&g_746,&g_746}}};
                union U3 ***l_11005 = &l_11006[0][3][1];
                int32_t l_11007[3];
                int32_t l_11011 = 0x082A5A48L;
                uint32_t l_11036[10] = {0xF1872A46L,0xF1872A46L,0xF1872A46L,0xF1872A46L,0xF1872A46L,0xF1872A46L,0xF1872A46L,0xF1872A46L,0xF1872A46L,0xF1872A46L};
                int32_t l_11037 = 0x723DCD0CL;
                uint8_t l_11045[8][8][2] = {{{0xD5L,0x6FL},{0x69L,252UL},{0x0FL,0xD7L},{0xD7L,1UL},{0x31L,6UL},{3UL,7UL},{252UL,0x40L},{0x25L,0xD5L}},{{251UL,0x31L},{0x2DL,0x8FL},{1UL,252UL},{0x70L,250UL},{0x6EL,1UL},{6UL,253UL},{0xD7L,0x0CL},{255UL,255UL}},{{0x4EL,255UL},{0xA8L,0x0FL},{0xEBL,0x2DL},{0xEEL,0xEBL},{0x0CL,252UL},{0x0CL,0xEBL},{0xEEL,0x2DL},{0xEBL,0x0FL}},{{0xA8L,255UL},{0x4EL,255UL},{255UL,0x0CL},{0xD7L,253UL},{6UL,1UL},{0x6EL,250UL},{0x70L,252UL},{1UL,0x8FL}},{{0x2DL,0x31L},{251UL,0xD5L},{0x25L,0x40L},{252UL,7UL},{3UL,6UL},{0x31L,1UL},{0xD7L,0xD7L},{0x0FL,252UL}},{{0x69L,0x6FL},{0xD5L,0x6FL},{0x69L,252UL},{0x0FL,0xD7L},{0xD7L,1UL},{0x31L,6UL},{3UL,7UL},{252UL,0x40L}},{{0x25L,0xD5L},{251UL,0x31L},{0x2DL,0x8FL},{1UL,0x07L},{0x2DL,252UL},{255UL,255UL},{0x2EL,0x0FL},{0xEEL,0xD7L}},{{0x6EL,0x6EL},{255UL,1UL},{253UL,6UL},{1UL,0xD5L},{0x8FL,1UL},{0xD7L,0xEBL},{0xD7L,1UL},{0x8FL,0xD5L}}};
                uint32_t l_11069 = 0x42128BEFL;
                union U4 * const **l_11119 = &g_4904[2][4];
                union U4 * const ***l_11118[8];
                union U4 * const **** const l_11117 = &l_11118[4];
                int32_t l_11129 = 1L;
                uint8_t l_11132 = 0UL;
                uint16_t **l_11136 = (void*)0;
                struct S0 *l_11143[3];
                uint32_t l_11148[6][5] = {{0x389C236AL,0xD7ABBB6CL,0xD7ABBB6CL,0x389C236AL,0xD7ABBB6CL},{0x389C236AL,0x389C236AL,0x33310549L,0x389C236AL,0x389C236AL},{0xD7ABBB6CL,0x389C236AL,0xD7ABBB6CL,0xD7ABBB6CL,0x389C236AL},{0x389C236AL,0xD7ABBB6CL,0xD7ABBB6CL,0x389C236AL,0xD7ABBB6CL},{0x389C236AL,0x389C236AL,0x33310549L,0x389C236AL,0x389C236AL},{0xD7ABBB6CL,0x389C236AL,0xD7ABBB6CL,0xD7ABBB6CL,0x389C236AL}};
                int i, j, k;
                for (i = 0; i < 3; i++)
                    l_11007[i] = 0x3456C660L;
                for (i = 0; i < 8; i++)
                    l_11118[i] = &l_11119;
                for (i = 0; i < 3; i++)
                    l_11143[i] = &g_11144;
                if ((((+(l_10976[2][5][2] | ((((((*g_715) = 0UL) , (((((p_62 ^ 0x651DL) >= (safe_mod_func_int64_t_s_s((-1L), (safe_sub_func_int32_t_s_s((((safe_sub_func_int64_t_s_s((safe_mod_func_int64_t_s_s(((***l_10637) = 0x9E7B855CCA06B273LL), (safe_sub_func_uint16_t_u_u((l_10987 | (((safe_add_func_uint16_t_u_u(((0x1D5BB6C040BBBF6CLL >= p_61) != p_62), 65535UL)) , 0xD393ACC5L) >= 0x6038E995L)), 0xF3D6L)))), (*l_10847))) , (*g_2718)) != l_10990), p_62))))) , l_10987) > g_10991) <= l_10992)) ^ l_10993[9][0]) , p_61) >= 0x22227880L))) <= (*g_8235)) && (****g_5408)))
                { /* block id: 4598 */
                    const union U3 **l_10996 = &l_10994;
                    (*l_10996) = l_10994;
                }
                else
                { /* block id: 4600 */
                    uint16_t ***l_11009 = &g_714;
                    uint16_t ****l_11008 = &l_11009;
                    uint32_t *l_11010[3];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_11010[i] = (void*)0;
                    (*l_10847) &= ((safe_lshift_func_uint8_t_u_u(p_61, 4)) == (l_11011 = ((**l_10892) = (safe_lshift_func_int16_t_s_s((l_11007[1] = (l_11001 == l_11005)), (l_11008 == (void*)0))))));
                }
                if (p_62)
                { /* block id: 4606 */
                    union U2 ** const ***l_11028[7] = {(void*)0,&g_11027[0],&g_11027[0],(void*)0,&g_11027[0],&g_11027[0],(void*)0};
                    int32_t l_11038 = 0xC6CB898AL;
                    int32_t l_11044 = 0xB1EFF9B2L;
                    int i;
                    (*g_1207) = ((safe_add_func_uint64_t_u_u((safe_unary_minus_func_int32_t_s((safe_div_func_int64_t_s_s((safe_unary_minus_func_int8_t_s((safe_lshift_func_uint8_t_u_u(((*g_656) &= ((((*g_6119) , l_11020[8]) == (((safe_div_func_uint16_t_u_u((safe_sub_func_int32_t_s_s((l_11007[1] == ((l_11029 = g_11027[0]) == ((l_11037 ^= (((safe_lshift_func_uint16_t_u_u((0xB564D32DL || (((((0x974E94775EBC43FCLL | ((((l_11011 & ((safe_lshift_func_int16_t_s_u(((*g_5411) <= ((safe_sub_func_uint16_t_u_u(((**g_714) = l_11036[3]), p_62)) ^ p_61)), (*g_5749))) > l_10987)) & p_62) && p_62) || p_61)) && p_62) | p_61) <= (-5L)) || p_61)), 12)) || 0x5002EB11745CAA11LL) , p_62)) , (*l_10810)))), l_11038)), 3L)) > 65529UL) , (void*)0)) , 0x64L)), p_61)))), 0x26A7B556F2A1F318LL)))), l_11038)) , &l_10805[2][5][0]);
                    for (g_9311 = 0; (g_9311 >= 31); g_9311 = safe_add_func_uint16_t_u_u(g_9311, 5))
                    { /* block id: 4614 */
                        int32_t l_11041 = (-1L);
                        int32_t l_11042 = 0xC43460ECL;
                        int32_t l_11043 = 0xDCC8BA0BL;
                        (*g_653) ^= p_62;
                        if (p_62)
                            break;
                        l_11045[6][1][1]--;
                    }
                    (*g_1207) = func_139((&g_7503 != l_11048));
                }
                else
                { /* block id: 4620 */
                    uint32_t l_11066 = 0x92E2A9CBL;
                    int32_t l_11081 = 0x14F9D0BFL;
                    int32_t ****l_11092 = (void*)0;
                    const union U4 **** const l_11121 = &g_10753;
                    const union U4 **** const *l_11120 = &l_11121;
                    int32_t l_11126 = (-3L);
                    int32_t l_11130 = 0L;
                    int32_t l_11131 = 0x518F3F35L;
                    struct S0 **l_11145 = &l_11143[1];
                    int8_t l_11150[5] = {0x72L,0x72L,0x72L,0x72L,0x72L};
                    int32_t l_11151 = 0xC7C08D71L;
                    int32_t l_11152 = 0xEB7CFB51L;
                    int i;
                    if ((l_11037 = ((safe_mul_func_int16_t_s_s(((*g_1678) , (safe_sub_func_int32_t_s_s(l_11007[2], ((safe_sub_func_int16_t_s_s((safe_rshift_func_int16_t_s_s((l_11007[1] <= ((safe_add_func_uint8_t_u_u(((safe_add_func_uint16_t_u_u(4UL, ((l_11063 | ((((**g_929) , &l_10413) != &l_10413) >= (safe_rshift_func_uint16_t_u_u(((p_62 & p_61) != 65535UL), l_11066)))) , p_62))) >= p_61), p_61)) == l_11067[0])), (*****g_1674))), l_11068)) , p_61)))), p_62)) & l_11069)))
                    { /* block id: 4622 */
                        int32_t ** const ***l_11091 = &g_11089;
                        l_11007[1] &= (safe_div_func_int64_t_s_s(((**l_10238) = l_11072), (safe_add_func_uint64_t_u_u((p_62 <= (safe_mul_func_uint16_t_u_u(l_11066, (safe_sub_func_uint32_t_u_u(p_62, ((l_11081 = (((***l_10173) = p_61) <= (safe_lshift_func_uint8_t_u_s((**g_4139), 4)))) ^ (safe_mod_func_uint8_t_u_u(0xA8L, (safe_div_func_int16_t_s_s((&g_6440 != &g_6440), (*g_5749))))))))))), l_11066))));
                        (*l_10847) &= (safe_add_func_int8_t_s_s(p_62, (~((****l_10693) = (((*l_11091) = g_11089) == l_11092)))));
                    }
                    else
                    { /* block id: 4630 */
                        int32_t l_11115 = 0L;
                        int32_t l_11122 = 1L;
                        int32_t l_11125 = 0L;
                        int32_t l_11128[7] = {0x3000FD40L,0x3000FD40L,0x3000FD40L,0x3000FD40L,0x3000FD40L,0x3000FD40L,0x3000FD40L};
                        union U3 *****l_11135 = &g_1503;
                        int i;
                        l_11122 = ((((**g_714) |= 65531UL) | (((*g_5408) != (void*)0) , (safe_add_func_int32_t_s_s((safe_div_func_uint8_t_u_u((((safe_sub_func_int8_t_s_s((6L == (((0x07BF9631L & (((safe_sub_func_int8_t_s_s((safe_rshift_func_uint8_t_u_s(((*g_5411) = (safe_rshift_func_int8_t_s_s((***g_4422), 0))), 6)), ((**g_4139) = (l_11069 == (safe_mul_func_int8_t_s_s((safe_mod_func_int8_t_s_s((((safe_add_func_uint16_t_u_u(((safe_div_func_int64_t_s_s(((***l_10740) = ((safe_add_func_int8_t_s_s((1L < ((p_62 < 1UL) & 0x7728F966E1807DC9LL)), p_62)) > 0x17DAL)), 0x6E79AFA88EA92FF1LL)) >= p_61), 0xA9F3L)) | 0xF0L) && l_11115), 3L)), 5UL)))))) , (void*)0) != (void*)0)) ^ l_11116) != p_62)), 0x0EL)) , l_11117) == l_11120), (**g_4423))), (*l_10847))))) | p_61);
                        (*l_10847) &= 0xA2C711C2L;
                        --l_11132;
                        (*l_11135) = &l_11005;
                    }
                    (*g_10974) = ((((((p_62 || l_11045[6][1][1]) , (((((void*)0 == (****g_1674)) , l_11136) != ((((**l_10238) &= (safe_rshift_func_uint8_t_u_s((((safe_lshift_func_uint16_t_u_u(((**g_714) = (((((safe_add_func_int8_t_s_s(((*g_715) < ((((*l_11145) = l_11143[1]) == (l_11146 = g_6240)) ^ l_11148[2][3])), 0x69L)) ^ (-10L)) , 8L) ^ p_61) , p_62)), 0)) , p_62) == 0x9B3A1082L), 4))) ^ p_61) , (void*)0)) == 0UL)) < (*g_6119)) , (*****g_1674)) < (-1L)) <= p_62);
                    l_10841 = l_10838[7];
                    l_11153--;
                }
                return l_11156;
            }
        }
    }
    return l_11157;
}


/* ------------------------------------------ */
/* 
 * reads : g_7160 g_1207 g_4882 g_7633 g_431 g_4423 g_28 g_29 g_6119 g_4801 g_656 g_1541 g_998 g_8235 g_5411 g_929 g_930 g_3643 g_446 g_66 g_715 g_466 g_5546 g_38 g_5407 g_5408 g_714 g_5409 g_5410 g_3870 g_4139 g_657 g_845 g_4087 g_4088 g_604 g_4422 g_9260 g_9261 g_746 g_2718 g_2719 g_1540 g_9692 g_9693 g_1675 g_1676 g_1677 g_1678 g_232 g_1674 g_7825.f0 g_3197 g_5127 g_5128 g_9806 g_2717 g_5749 g_1419 g_2302 g_6484 g_9259 g_6483 g_260 g_6607.f0 g_4095 g_4096 g_4097 g_1219 g_6879.f3 g_5490 g_8562 g_7024.f3 g_1220 g_8092.f3 g_3071 g_8082.f3 g_5271 g_6877.f3 g_8090.f3 g_1470 g_6233
 * writes: g_8562 g_7024.f3 g_1220 g_260 g_653 g_8092.f3 g_3071 g_845 g_4296 g_657 g_5490 g_3870 g_466 g_5546 g_8082.f3 g_998 g_604 g_7825.f0 g_5271 g_9262 g_6877.f3 g_8090.f3 g_3643 g_446 g_66 g_255 g_930 g_4882 g_1470 g_9692 g_1503 g_431 g_9880 g_1168 g_1070 g_9920 g_6233 g_6571.f3 g_232 g_10000 g_6607.f0 g_6483 g_1396 g_1219 g_6879.f3
 */
static int16_t  func_84(int8_t * p_85, int16_t  p_86)
{ /* block id: 3919 */
    int16_t l_9378 = (-8L);
    union U3 **l_9389 = &g_746;
    union U3 ***l_9388 = &l_9389;
    union U3 ***l_9390 = (void*)0;
    uint32_t **l_9391 = &g_930[1][2];
    const int32_t *l_9396 = &g_4882;
    int32_t l_9401[2][4] = {{(-3L),(-3L),(-3L),(-3L)},{(-3L),(-3L),(-3L),(-3L)}};
    int32_t ****l_9405 = &g_4095;
    union U2 *l_9424 = &g_9425;
    union U2 **l_9426 = &l_9424;
    const union U3 *l_9431 = &g_9432;
    const union U3 **l_9430 = &l_9431;
    const union U3 ***l_9429[10][7] = {{(void*)0,(void*)0,&l_9430,(void*)0,&l_9430,(void*)0,(void*)0},{&l_9430,&l_9430,(void*)0,(void*)0,&l_9430,&l_9430,(void*)0},{&l_9430,(void*)0,(void*)0,(void*)0,&l_9430,&l_9430,&l_9430},{&l_9430,(void*)0,(void*)0,&l_9430,&l_9430,(void*)0,&l_9430},{&l_9430,(void*)0,&l_9430,(void*)0,(void*)0,(void*)0,&l_9430},{&l_9430,&l_9430,&l_9430,&l_9430,&l_9430,&l_9430,&l_9430},{&l_9430,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&l_9430},{&l_9430,&l_9430,(void*)0,&l_9430,&l_9430,(void*)0,(void*)0},{(void*)0,(void*)0,&l_9430,(void*)0,(void*)0,&l_9430,(void*)0},{&l_9430,&l_9430,(void*)0,&l_9430,&l_9430,&l_9430,&l_9430}};
    const union U3 ****l_9428 = &l_9429[8][3];
    const union U3 *****l_9427 = &l_9428;
    union U3 *****l_9433 = (void*)0;
    uint8_t **l_9442 = &g_5411;
    int16_t **** const l_9445[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int8_t **l_9455[5][8] = {{(void*)0,(void*)0,&g_28,&g_28,(void*)0,(void*)0,&g_28,&g_28},{(void*)0,(void*)0,&g_28,&g_28,(void*)0,(void*)0,&g_28,&g_28},{(void*)0,(void*)0,&g_28,&g_28,(void*)0,(void*)0,&g_28,&g_28},{(void*)0,(void*)0,&g_28,&g_28,(void*)0,(void*)0,&g_28,&g_28},{(void*)0,(void*)0,&g_28,&g_28,(void*)0,(void*)0,&g_28,&g_28}};
    int8_t *** const l_9454 = &l_9455[4][1];
    int8_t *** const *l_9453 = &l_9454;
    uint32_t l_9481 = 0xB7420606L;
    uint16_t l_9484 = 2UL;
    const int64_t l_9487[5][5][6] = {{{0xADB53129057EC353LL,0xF09895B465DA4C6CLL,0x6D4F4DDE37272C15LL,0x5AAD00ED2D45EB2DLL,9L,0x1E9D31B41BAB62BDLL},{(-1L),(-1L),5L,(-1L),0x02A90859E909EBF0LL,1L},{0x2D6E801A9FCC7515LL,0xE529C91EBB8D63F9LL,0xE50F6F2AD1154E75LL,0x5521ED091AF8E0E6LL,0x5D6494989ABD2564LL,0xADB53129057EC353LL},{(-1L),0xAB58A3CDBD462E80LL,0xE628C2E078871026LL,0xE628C2E078871026LL,0xAB58A3CDBD462E80LL,(-1L)},{(-2L),0x4BFAB09C80A3706DLL,(-5L),0x9570B4475C2C674FLL,(-4L),(-1L)}},{{(-8L),0x5AAD00ED2D45EB2DLL,0x37406DB0B4FD0B98LL,0xF7AC4B34693B172DLL,1L,0xC4AF4FDBCE5AFB9BLL},{(-8L),0x83853C14F52DC1E5LL,0xF7AC4B34693B172DLL,0x9570B4475C2C674FLL,0xADB53129057EC353LL,1L},{(-2L),(-4L),6L,0xE628C2E078871026LL,0xD5AD84880043D908LL,0x4BFAB09C80A3706DLL},{(-1L),(-5L),1L,0x5521ED091AF8E0E6LL,0L,0xC4369BF0FA544C6ELL},{0x2D6E801A9FCC7515LL,0x91B6FA1418DBA33ALL,0xF09895B465DA4C6CLL,(-1L),0x419148DA2858B9BELL,(-5L)}},{{(-1L),1L,0x0042FAAE6990A368LL,0x5AAD00ED2D45EB2DLL,0x8254084654ECCE96LL,0x2D6E801A9FCC7515LL},{0xADB53129057EC353LL,1L,0x6D4B708CD9F0DD24LL,0xE529C91EBB8D63F9LL,0x522A8A2C366F1BADLL,0x02A90859E909EBF0LL},{0x9570B4475C2C674FLL,0x2D6E801A9FCC7515LL,0x2383469744355D1ALL,0xE0A8EFE4C5F2874ELL,0L,(-1L)},{1L,0x419148DA2858B9BELL,0xC4AF4FDBCE5AFB9BLL,0x419148DA2858B9BELL,1L,0xD5AD84880043D908LL},{0x19E7D725A159F7B3LL,0xC4AF4FDBCE5AFB9BLL,(-1L),0x02A90859E909EBF0LL,0xC4369BF0FA544C6ELL,0x8B8F9D0FA6E9F42FLL}},{{0xE0A8EFE4C5F2874ELL,(-2L),0L,0xC4AF4FDBCE5AFB9BLL,(-5L),0x8B8F9D0FA6E9F42FLL},{0x8B8F9D0FA6E9F42FLL,0x9570B4475C2C674FLL,(-1L),0x0042FAAE6990A368LL,0xF09895B465DA4C6CLL,0xD5AD84880043D908LL},{(-5L),0x1E9D31B41BAB62BDLL,0xC4AF4FDBCE5AFB9BLL,0x6D4F4DDE37272C15LL,1L,(-1L)},{5L,4L,0x2383469744355D1ALL,0x946682B141448EFALL,0x1E9D31B41BAB62BDLL,0x02A90859E909EBF0LL},{1L,1L,0x6D4B708CD9F0DD24LL,0x37406DB0B4FD0B98LL,0x19E7D725A159F7B3LL,0x2D6E801A9FCC7515LL}},{{0x946682B141448EFALL,0xE628C2E078871026LL,0x0042FAAE6990A368LL,0xADB53129057EC353LL,0L,(-5L)},{0x02A90859E909EBF0LL,(-2L),0xF09895B465DA4C6CLL,(-2L),0x48AB5D7FAC634E1CLL,0xC4369BF0FA544C6ELL},{(-2L),0L,1L,0x6D4B708CD9F0DD24LL,0x4BFAB09C80A3706DLL,0x4BFAB09C80A3706DLL},{0xE50F6F2AD1154E75LL,6L,6L,0xE50F6F2AD1154E75LL,0x0042FAAE6990A368LL,1L},{0x522A8A2C366F1BADLL,0L,0xF7AC4B34693B172DLL,0x4BFAB09C80A3706DLL,0x9570B4475C2C674FLL,0xC4AF4FDBCE5AFB9BLL}}};
    int32_t l_9503 = 1L;
    int32_t l_9504 = 0L;
    int64_t l_9610 = (-6L);
    int64_t l_9654 = 9L;
    struct S0 *l_9688 = &g_9689[2];
    uint8_t l_9691 = 0x4AL;
    uint32_t ***l_9700[9][9][3] = {{{&g_4087,&g_4087,&g_4087},{(void*)0,(void*)0,(void*)0},{&g_4087,&g_4087,&g_4087},{&g_4087,(void*)0,(void*)0},{&g_4087,&g_4087,(void*)0},{&g_4087,&g_4087,(void*)0},{(void*)0,&g_4087,&g_4087},{&g_4087,&g_4087,(void*)0},{&g_4087,&g_4087,&g_4087}},{{(void*)0,(void*)0,&g_4087},{&g_4087,&g_4087,&g_4087},{&g_4087,(void*)0,(void*)0},{&g_4087,&g_4087,&g_4087},{&g_4087,(void*)0,&g_4087},{&g_4087,&g_4087,&g_4087},{(void*)0,(void*)0,&g_4087},{&g_4087,&g_4087,&g_4087},{&g_4087,&g_4087,&g_4087}},{{&g_4087,&g_4087,(void*)0},{&g_4087,(void*)0,(void*)0},{&g_4087,&g_4087,&g_4087},{&g_4087,&g_4087,&g_4087},{&g_4087,&g_4087,&g_4087},{&g_4087,&g_4087,&g_4087},{&g_4087,&g_4087,(void*)0},{(void*)0,&g_4087,(void*)0},{&g_4087,(void*)0,&g_4087}},{{&g_4087,(void*)0,&g_4087},{&g_4087,&g_4087,&g_4087},{&g_4087,&g_4087,(void*)0},{&g_4087,&g_4087,(void*)0},{&g_4087,&g_4087,&g_4087},{&g_4087,(void*)0,&g_4087},{(void*)0,(void*)0,&g_4087},{&g_4087,&g_4087,&g_4087},{&g_4087,&g_4087,(void*)0}},{{&g_4087,&g_4087,(void*)0},{(void*)0,(void*)0,&g_4087},{&g_4087,(void*)0,&g_4087},{&g_4087,&g_4087,&g_4087},{&g_4087,&g_4087,&g_4087},{&g_4087,&g_4087,&g_4087},{&g_4087,&g_4087,&g_4087},{&g_4087,(void*)0,(void*)0},{&g_4087,(void*)0,&g_4087}},{{&g_4087,&g_4087,&g_4087},{&g_4087,&g_4087,&g_4087},{&g_4087,&g_4087,(void*)0},{&g_4087,&g_4087,&g_4087},{(void*)0,&g_4087,(void*)0},{&g_4087,&g_4087,&g_4087},{&g_4087,(void*)0,(void*)0},{&g_4087,&g_4087,&g_4087},{(void*)0,&g_4087,(void*)0}},{{&g_4087,&g_4087,&g_4087},{&g_4087,(void*)0,&g_4087},{&g_4087,&g_4087,&g_4087},{&g_4087,(void*)0,(void*)0},{&g_4087,&g_4087,&g_4087},{&g_4087,(void*)0,&g_4087},{&g_4087,&g_4087,&g_4087},{(void*)0,(void*)0,&g_4087},{&g_4087,&g_4087,&g_4087}},{{&g_4087,&g_4087,&g_4087},{&g_4087,&g_4087,(void*)0},{&g_4087,(void*)0,(void*)0},{&g_4087,&g_4087,&g_4087},{&g_4087,&g_4087,&g_4087},{&g_4087,&g_4087,&g_4087},{&g_4087,&g_4087,&g_4087},{&g_4087,&g_4087,(void*)0},{(void*)0,&g_4087,(void*)0}},{{&g_4087,(void*)0,&g_4087},{&g_4087,(void*)0,&g_4087},{&g_4087,&g_4087,&g_4087},{&g_4087,(void*)0,(void*)0},{(void*)0,&g_4087,&g_4087},{(void*)0,&g_4087,&g_4087},{&g_4087,&g_4087,&g_4087},{&g_4087,(void*)0,(void*)0},{&g_4087,&g_4087,&g_4087}}};
    uint32_t ****l_9699 = &l_9700[5][3][1];
    union U4 *****l_9713 = (void*)0;
    int16_t l_9730 = 0x9E7CL;
    const union U2 ***l_9734 = &g_6353[3];
    const union U2 ****l_9733 = &l_9734;
    struct S1 *l_9761 = &g_9762;
    int32_t *l_9770 = &g_4882;
    uint64_t l_9771 = 18446744073709551615UL;
    uint32_t ****l_9801 = &g_3250[8];
    const uint64_t ***l_9990[6][1];
    int32_t l_10088 = 0x19964F89L;
    int i, j, k;
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 1; j++)
            l_9990[i][j] = (void*)0;
    }
    l_9378 &= p_86;
lbl_9608:
    for (g_8562 = 0; (g_8562 != 36); g_8562 = safe_add_func_uint32_t_u_u(g_8562, 9))
    { /* block id: 3923 */
        int8_t l_9383[8][8] = {{0xE8L,(-9L),1L,1L,(-9L),0xE8L,0x67L,(-9L)},{1L,0x67L,1L,1L,1L,0x67L,1L,0xE8L},{(-9L),0x65L,(-1L),1L,1L,(-1L),0x65L,(-9L)},{0xE8L,1L,0x67L,1L,1L,1L,0x67L,1L},{(-9L),0x67L,0xE8L,(-9L),1L,1L,(-9L),0xE8L},{1L,1L,(-1L),0x65L,(-9L),(-1L),(-9L),0x65L},{0xE8L,0x65L,0xE8L,1L,0x65L,0x67L,0x67L,0x65L},{0x65L,0x67L,0x67L,0x65L,1L,0xE8L,0x65L,0xE8L}};
        uint32_t **l_9392 = &g_930[5][1];
        const int32_t *l_9397 = &g_3307;
        int32_t l_9398 = 0L;
        int32_t l_9400[2][4] = {{0x2E0DBBD4L,0xE807E847L,0x2E0DBBD4L,0xE807E847L},{0x2E0DBBD4L,0xE807E847L,0x2E0DBBD4L,0xE807E847L}};
        uint16_t l_9402 = 0x2027L;
        int i, j;
        l_9397 = ((safe_sub_func_uint64_t_u_u((l_9383[0][1] ^ ((((safe_div_func_uint32_t_u_u((&g_4087 != (void*)0), (safe_add_func_int8_t_s_s((l_9388 != l_9390), (l_9391 != l_9392))))) >= 0x0DL) && (((safe_unary_minus_func_int64_t_s((safe_mul_func_int16_t_s_s(((l_9378 , 2UL) == p_86), 0L)))) ^ p_86) || 0UL)) | p_86)), l_9383[0][1])) , l_9396);
        for (g_7024.f3 = 7; (g_7024.f3 >= 0); g_7024.f3 -= 1)
        { /* block id: 3927 */
            int32_t *l_9399[4][10] = {{&l_9398,&g_7[4][2][1],&g_255,&g_3420[2],&g_11,&l_9398,&l_9398,&g_11,&g_3420[2],&g_255},{&g_7[4][2][1],&g_7[4][2][1],&g_4882,(void*)0,&g_11,&g_3307,&g_7[4][2][1],&g_11,&g_163,&g_11},{&g_7[4][2][1],&l_9398,&g_255,(void*)0,&g_255,&l_9398,&g_7[4][2][1],&g_255,&g_3420[2],&g_11},{&l_9398,&g_7[4][2][1],&g_255,&g_3420[2],&g_11,&l_9398,&l_9398,&g_11,&g_3420[2],&g_255}};
            uint32_t **l_9414 = &g_4088[0];
            uint64_t l_9423 = 18446744073709551615UL;
            int i, j;
            ++l_9402;
            for (g_1220 = 0; (g_1220 <= 7); g_1220 += 1)
            { /* block id: 3931 */
                int32_t ****l_9406 = (void*)0;
                int32_t *l_9407 = (void*)0;
                l_9406 = l_9405;
                for (g_260 = 0; (g_260 <= 7); g_260 += 1)
                { /* block id: 3935 */
                    for (l_9398 = 0; (l_9398 >= 0); l_9398 -= 1)
                    { /* block id: 3938 */
                        int i;
                        if (g_7160[l_9398])
                            break;
                        (*g_1207) = l_9407;
                    }
                    if (p_86)
                        continue;
                    (*g_1207) = &l_9401[0][3];
                }
                for (g_8092.f3 = 7; (g_8092.f3 >= 0); g_8092.f3 -= 1)
                { /* block id: 3947 */
                    int8_t l_9419 = 0x36L;
                    int32_t l_9420 = 0xA24A5234L;
                    int64_t l_9421 = (-1L);
                    l_9400[1][1] ^= (l_9420 = (safe_mul_func_int8_t_s_s((0x8509L || ((&l_9401[1][1] == l_9399[0][7]) <= ((*l_9396) , (safe_div_func_uint32_t_u_u((0x0A22E923L ^ (l_9401[0][3] = (safe_mul_func_int16_t_s_s(((void*)0 != l_9414), (8L > (safe_mul_func_uint8_t_u_u(((safe_div_func_uint8_t_u_u(p_86, l_9419)) > p_86), p_86))))))), p_86))))), (*g_7633))));
                    if (l_9421)
                        break;
                    for (g_3071 = 7; (g_3071 >= 0); g_3071 -= 1)
                    { /* block id: 3954 */
                        uint8_t l_9422[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_9422[i] = 0UL;
                        return l_9422[1];
                    }
                }
                return l_9423;
            }
            return p_86;
        }
    }
    (*l_9426) = l_9424;
    if ((((l_9427 = l_9427) == (l_9433 = &g_1503)) , ((((((((*g_656) = (safe_div_func_int32_t_s_s((((((l_9401[0][3] = (safe_mul_func_int16_t_s_s((p_86 > ((*g_6119) = (safe_lshift_func_int8_t_s_u((**g_4423), 0)))), (((l_9442 == l_9442) ^ (((*g_4801) = (void*)0) == ((safe_mod_func_uint64_t_u_u(0x84779BAECDF187D3LL, 0x145CE8C0D3F221ABLL)) , l_9445[3]))) , (*l_9396))))) <= 1UL) < p_86) , 0L) , 0xF8FE1283L), (*l_9396)))) != (*p_85)) , 0UL) ^ 0x329A010FL) | p_86) >= (*l_9396)) , p_86)))
    { /* block id: 3970 */
        int8_t *** const *l_9452 = &g_4422;
        const int32_t l_9458 = 0xA26D506BL;
        int32_t l_9466 = 0xE3AF25D0L;
        int32_t l_9467 = 0xE768ED1AL;
        int32_t *l_9468 = &g_38;
        int32_t l_9469 = (-7L);
        int32_t *l_9470 = &l_9467;
        int32_t *l_9471 = &g_38;
        int32_t *l_9472 = &l_9401[0][3];
        int32_t *l_9473 = &l_9467;
        int32_t *l_9474[2];
        int16_t l_9475[6] = {0xF5D5L,0xF5D5L,0x86EDL,0xF5D5L,0xF5D5L,0x86EDL};
        int32_t l_9476 = 0x94C3E512L;
        int32_t l_9477 = 0xDAC0AB45L;
        int8_t l_9478[4][8] = {{(-10L),(-9L),(-10L),(-9L),(-10L),(-9L),(-10L),(-9L)},{(-10L),(-9L),(-10L),(-9L),(-10L),(-9L),(-10L),(-9L)},{(-10L),(-9L),(-10L),(-9L),(-10L),(-9L),(-10L),(-9L)},{(-10L),(-9L),(-10L),(-9L),(-10L),(-9L),(-10L),(-9L)}};
        int32_t l_9479 = 1L;
        uint16_t *l_9502 = &g_5546[5][0][8];
        int i, j;
        for (i = 0; i < 2; i++)
            l_9474[i] = &l_9467;
        l_9466 = ((((p_86 < (safe_add_func_int64_t_s_s((safe_rshift_func_int16_t_s_u(p_86, (safe_sub_func_uint64_t_u_u((*g_1541), (((l_9453 = l_9452) != &l_9454) ^ (safe_sub_func_uint32_t_u_u(l_9458, (safe_mul_func_int16_t_s_s((*l_9396), (~(((safe_mul_func_uint8_t_u_u((safe_div_func_int8_t_s_s(((*g_8235) = (*p_85)), ((*g_5411) = p_86))), (*p_85))) < 0xA8D4595B999A3DF8LL) & 1L))))))))))), p_86))) , (*l_9396)) ^ 3UL) && (*l_9396));
        --l_9481;
        l_9484++;
        (*l_9470) = (((l_9504 ^= (l_9503 ^= ((((p_86 == (p_86 & l_9487[1][1][5])) | ((safe_mod_func_int8_t_s_s((((1UL || (safe_mod_func_uint8_t_u_u((!(safe_rshift_func_uint16_t_u_s((safe_rshift_func_uint16_t_u_u(((*l_9502) |= ((*g_715) |= (((((*l_9396) == (safe_lshift_func_int16_t_s_s(((+0x4E3DL) <= p_86), 13))) , ((((0x003389B3L | (safe_add_func_int16_t_s_s(2L, p_86))) | (**g_929)) != 0x8CDFL) > (*l_9396))) && (*l_9472)) | (*l_9473)))), p_86)), p_86))), (*l_9468)))) || (*l_9471)) || 0UL), 0xF9L)) , p_86)) | (*l_9472)) != p_86))) == (*l_9472)) <= (*p_85));
    }
    else
    { /* block id: 3982 */
        int32_t l_9509 = 1L;
        int32_t l_9533[4][9] = {{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{0x504ED109L,0x504ED109L,0x504ED109L,0x504ED109L,0x504ED109L,0x504ED109L,0x504ED109L,0x504ED109L,0x504ED109L},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{0x504ED109L,0x504ED109L,0x504ED109L,0x504ED109L,0x504ED109L,0x504ED109L,0x504ED109L,0x504ED109L,0x504ED109L}};
        uint16_t l_9535 = 65535UL;
        uint16_t *** const l_9542 = &g_714;
        uint16_t ***l_9543[9][1][8] = {{{&g_714,&g_714,&g_714,&g_714,&g_714,&g_714,(void*)0,&g_714}},{{(void*)0,&g_714,&g_714,&g_714,&g_714,&g_714,&g_714,&g_714}},{{&g_714,&g_714,&g_714,&g_714,(void*)0,&g_714,&g_714,&g_714}},{{&g_714,&g_714,(void*)0,&g_714,&g_714,&g_714,(void*)0,&g_714}},{{&g_714,(void*)0,&g_714,&g_714,&g_714,(void*)0,(void*)0,&g_714}},{{&g_714,&g_714,&g_714,&g_714,&g_714,&g_714,(void*)0,&g_714}},{{(void*)0,&g_714,&g_714,(void*)0,&g_714,(void*)0,(void*)0,&g_714}},{{&g_714,(void*)0,(void*)0,&g_714,&g_714,&g_714,&g_714,&g_714}},{{&g_714,&g_714,&g_714,&g_714,&g_714,&g_714,&g_714,&g_714}}};
        union U4 *****l_9561[3];
        const int16_t *l_9659 = &g_4493;
        uint8_t l_9671 = 0x61L;
        int16_t l_9690 = 0x16B4L;
        uint32_t l_9703[9] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL};
        union U2 **l_9708 = (void*)0;
        uint64_t l_9716[1];
        uint64_t l_9721 = 5UL;
        int8_t l_9731 = 0x30L;
        uint8_t l_9737[6][4][7] = {{{0xBFL,4UL,255UL,0xC9L,0x34L,0x18L,255UL},{0UL,0xF8L,3UL,0xECL,0UL,255UL,4UL},{0x3BL,0UL,0x04L,0x34L,0xD4L,0x72L,255UL},{0x62L,0UL,255UL,7UL,0xD6L,3UL,3UL}},{{0UL,0xF8L,0UL,0xF8L,0UL,0x62L,0x3BL},{0xF8L,4UL,3UL,255UL,250UL,0x59L,1UL},{0UL,3UL,0x72L,1UL,0x62L,0xD6L,0UL},{0xF8L,255UL,1UL,9UL,255UL,255UL,0x72L}},{{0UL,250UL,0x62L,255UL,255UL,1UL,0xC9L},{0x62L,0x59L,0xD6L,255UL,1UL,0xF8L,0xC9L},{0x3BL,1UL,0UL,0x72L,0xC9L,0xC9L,0x72L},{0UL,0x72L,0UL,0xD6L,4UL,5UL,0UL}},{{0xBFL,0x18L,0xE8L,0UL,0UL,1UL,1UL},{0UL,0xCDL,255UL,0UL,255UL,255UL,0x18L},{0xC9L,0x3BL,255UL,0xCDL,0x59L,255UL,4UL},{0UL,5UL,255UL,0xECL,1UL,0xF8L,255UL}},{{7UL,255UL,1UL,0UL,1UL,0xA9L,0x04L},{0xECL,0UL,0xC9L,0x59L,0x59L,0xC9L,0UL},{250UL,255UL,4UL,255UL,0x72L,0xD4L,0x34L},{0xD4L,0xCDL,0UL,2UL,0UL,8UL,255UL}},{{0xA9L,0UL,255UL,255UL,0x65L,0UL,0UL},{0x3BL,255UL,0xCDL,0x59L,255UL,4UL,2UL},{0UL,250UL,0UL,0UL,0xA9L,0x72L,0x3BL},{4UL,255UL,0UL,0xECL,0xF8L,0x72L,0x95L}}};
        uint16_t l_9766 = 0UL;
        int16_t *l_9769 = &g_232;
        uint32_t *l_9778[5] = {&g_5485,&g_5485,&g_5485,&g_5485,&g_5485};
        uint8_t l_9787 = 0xAAL;
        uint32_t ****l_9799 = &g_3250[8];
        uint16_t l_9803 = 1UL;
        uint32_t *l_9804 = &g_8037.f1;
        int16_t l_9805 = 0x365BL;
        int8_t l_9832 = 5L;
        int32_t l_9835 = 7L;
        int32_t l_9840 = (-1L);
        uint8_t l_9843 = 0UL;
        union U3 ****l_9853 = &l_9388;
        uint16_t l_9874[3];
        union U2 ***l_9879 = &l_9708;
        union U2 ****l_9878 = &l_9879;
        union U2 *****l_9877 = &l_9878;
        int64_t l_9887 = 0xF7D1D410A02D5285LL;
        uint16_t l_9888 = 1UL;
        struct S1 *l_9897 = &g_9898;
        uint8_t l_9913 = 0xC0L;
        union U5 *l_9919 = (void*)0;
        int8_t l_9927[4];
        int32_t l_9931[8][9];
        int32_t l_9932 = 0x4BEF022BL;
        uint64_t l_9934 = 0x97A29FED1463E212LL;
        int32_t *l_9937[2][8] = {{&l_9835,&g_255,&g_255,&l_9835,&g_255,&g_255,&l_9835,&g_255},{&l_9835,&l_9835,&l_9533[1][1],&l_9835,&l_9835,&l_9533[1][1],&l_9835,&l_9835}};
        int64_t l_9941 = 0x15793E417FD6AEB3LL;
        uint32_t l_9949 = 18446744073709551606UL;
        uint32_t l_9950 = 0x784709BDL;
        uint32_t l_9951 = 18446744073709551612UL;
        uint64_t l_9969[7] = {0x2B4697688CC61388LL,0x2B4697688CC61388LL,0x2B4697688CC61388LL,0x2B4697688CC61388LL,0x2B4697688CC61388LL,0x2B4697688CC61388LL,0x2B4697688CC61388LL};
        uint16_t l_9971 = 65530UL;
        int16_t l_9972 = (-7L);
        int32_t l_9973[6];
        uint8_t l_9997 = 0x8DL;
        uint64_t l_9998[1];
        int32_t *l_10005 = &l_9401[1][2];
        uint8_t l_10007 = 251UL;
        int16_t l_10036[9] = {0x24B6L,0x24B6L,0L,0x24B6L,0x24B6L,0L,0x24B6L,0x24B6L,0L};
        int8_t l_10038 = 1L;
        int32_t l_10039 = 0x1811C08DL;
        int32_t *** const l_10056[8][7][4] = {{{&g_1207,(void*)0,&g_1207,&g_1207},{(void*)0,(void*)0,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,(void*)0,&g_1207,&g_1207},{&g_1207,(void*)0,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,(void*)0,&g_1207}},{{&g_1207,&g_1207,&g_1207,&g_1207},{(void*)0,&g_1207,&g_1207,(void*)0},{&g_1207,(void*)0,(void*)0,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,(void*)0,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,(void*)0}},{{&g_1207,&g_1207,&g_1207,&g_1207},{(void*)0,(void*)0,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,(void*)0},{&g_1207,&g_1207,&g_1207,(void*)0},{&g_1207,&g_1207,&g_1207,(void*)0},{&g_1207,&g_1207,&g_1207,&g_1207}},{{(void*)0,&g_1207,(void*)0,(void*)0},{&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,(void*)0},{&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,(void*)0},{&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,(void*)0}},{{&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,(void*)0,&g_1207,&g_1207},{&g_1207,&g_1207,(void*)0,(void*)0},{&g_1207,&g_1207,&g_1207,&g_1207},{(void*)0,(void*)0,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,(void*)0,&g_1207}},{{&g_1207,&g_1207,&g_1207,&g_1207},{(void*)0,&g_1207,(void*)0,(void*)0},{&g_1207,(void*)0,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207},{(void*)0,&g_1207,&g_1207,&g_1207},{&g_1207,(void*)0,&g_1207,(void*)0},{&g_1207,&g_1207,(void*)0,&g_1207}},{{&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207},{(void*)0,(void*)0,&g_1207,(void*)0},{&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,(void*)0,&g_1207},{(void*)0,&g_1207,&g_1207,(void*)0},{&g_1207,(void*)0,(void*)0,&g_1207}},{{&g_1207,(void*)0,&g_1207,&g_1207},{&g_1207,(void*)0,&g_1207,&g_1207},{(void*)0,&g_1207,&g_1207,(void*)0},{&g_1207,&g_1207,(void*)0,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207}}};
        uint32_t *** const l_10057 = &g_4087;
        uint64_t l_10058 = 18446744073709551607UL;
        int32_t l_10062 = 4L;
        uint64_t l_10068 = 0xE92178109C5ACBA4LL;
        uint32_t l_10090 = 0xF160161AL;
        const union U2 ****l_10095[8][7][4] = {{{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,&l_9734,&l_9734,(void*)0},{&l_9734,&l_9734,(void*)0,&l_9734},{(void*)0,&l_9734,(void*)0,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,(void*)0,(void*)0,&l_9734}},{{&l_9734,&l_9734,(void*)0,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,(void*)0,&l_9734,&l_9734},{&l_9734,(void*)0,&l_9734,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734}},{{&l_9734,&l_9734,&l_9734,(void*)0},{&l_9734,&l_9734,&l_9734,&l_9734},{(void*)0,&l_9734,&l_9734,(void*)0},{&l_9734,&l_9734,&l_9734,&l_9734},{(void*)0,&l_9734,&l_9734,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734}},{{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,(void*)0,&l_9734,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,&l_9734,&l_9734,(void*)0},{&l_9734,(void*)0,&l_9734,&l_9734},{(void*)0,&l_9734,&l_9734,&l_9734}},{{&l_9734,&l_9734,&l_9734,&l_9734},{(void*)0,&l_9734,&l_9734,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,&l_9734,&l_9734,(void*)0},{&l_9734,&l_9734,&l_9734,(void*)0},{&l_9734,&l_9734,&l_9734,&l_9734}},{{&l_9734,&l_9734,(void*)0,&l_9734},{&l_9734,&l_9734,(void*)0,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734},{(void*)0,(void*)0,&l_9734,(void*)0},{&l_9734,&l_9734,&l_9734,&l_9734}},{{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,(void*)0,(void*)0,&l_9734},{&l_9734,&l_9734,(void*)0,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734},{(void*)0,&l_9734,&l_9734,&l_9734}},{{&l_9734,&l_9734,&l_9734,(void*)0},{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,&l_9734,(void*)0,(void*)0},{&l_9734,&l_9734,(void*)0,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734},{&l_9734,&l_9734,&l_9734,&l_9734}}};
        int32_t l_10103 = 0x5C2909C2L;
        uint32_t l_10114 = 0x86D1AF15L;
        int64_t ****l_10119 = &g_6439[0][1];
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_9561[i] = (void*)0;
        for (i = 0; i < 1; i++)
            l_9716[i] = 18446744073709551615UL;
        for (i = 0; i < 3; i++)
            l_9874[i] = 65529UL;
        for (i = 0; i < 4; i++)
            l_9927[i] = (-1L);
        for (i = 0; i < 8; i++)
        {
            for (j = 0; j < 9; j++)
                l_9931[i][j] = 0xA140D658L;
        }
        for (i = 0; i < 6; i++)
            l_9973[i] = 0x0119A800L;
        for (i = 0; i < 1; i++)
            l_9998[i] = 0x861B12810C4A4D08LL;
lbl_9859:
        l_9401[1][1] ^= 0L;
        if (p_86)
        { /* block id: 3984 */
            union U2 *l_9510 = &g_9511;
            uint8_t ** const * const *l_9534 = (void*)0;
            uint16_t l_9538 = 0UL;
            uint16_t ***l_9544 = &g_714;
            int32_t l_9604 = 0xD14A61F2L;
            int32_t l_9605[6][1];
            int16_t l_9656 = 0x1A80L;
            uint16_t l_9657 = 0x7290L;
            int i, j;
            for (i = 0; i < 6; i++)
            {
                for (j = 0; j < 1; j++)
                    l_9605[i][j] = 1L;
            }
lbl_9541:
            l_9504 |= (safe_lshift_func_uint16_t_u_s(((safe_add_func_int16_t_s_s(((l_9509 != (l_9510 == ((safe_mod_func_uint32_t_u_u(p_86, l_9509)) , (*l_9426)))) , (l_9535 = (safe_mod_func_int16_t_s_s(((l_9503 &= ((safe_mul_func_uint8_t_u_u(((l_9401[0][0] = (((safe_lshift_func_uint16_t_u_u(((**g_714) = (safe_mul_func_uint8_t_u_u((((safe_div_func_uint32_t_u_u(l_9509, (l_9533[2][8] = (safe_unary_minus_func_int64_t_s((safe_mul_func_int8_t_s_s(((*g_8235) = (0x00CE3819D9995BCFLL ^ (safe_sub_func_int16_t_s_s((*l_9396), (safe_mul_func_int16_t_s_s(((safe_lshift_func_uint16_t_u_s(p_86, (*l_9396))) < p_86), (-7L))))))), l_9509))))))) , l_9534) == (*g_5407)), 1L))), 10)) | (*l_9396)) , 0x65B1EF76L)) >= p_86), (*g_28))) && p_86)) < 0x37FAL), p_86)))), (*l_9396))) >= p_86), (*l_9396)));
            if (g_4882)
                goto lbl_9666;
            for (g_8082.f3 = 0; (g_8082.f3 >= (-24)); g_8082.f3 = safe_sub_func_uint64_t_u_u(g_8082.f3, 3))
            { /* block id: 3994 */
                --l_9538;
                if (g_446)
                    goto lbl_9541;
            }
            if ((((l_9542 != (l_9544 = l_9543[5][0][5])) , (((*g_1541) = (safe_lshift_func_int16_t_s_s(7L, 8))) , (safe_sub_func_int8_t_s_s((l_9533[2][8] && ((safe_add_func_uint32_t_u_u(((safe_sub_func_uint64_t_u_u((+l_9538), ((*g_6119) ^= (l_9538 >= (((+(l_9533[2][2] , (*l_9396))) & ((((**g_4139) ^= ((****g_5408) ^= (safe_sub_func_uint8_t_u_u(((l_9538 != 0UL) ^ p_86), 251UL)))) , 1L) , p_86)) == p_86))))) & p_86), p_86)) < p_86)), 0UL)))) | (*g_28)))
            { /* block id: 4003 */
                int64_t l_9598 = 0x9159887CDD9E0D44LL;
                uint32_t **l_9606 = &g_930[1][2];
                for (g_1220 = 10; (g_1220 == 8); --g_1220)
                { /* block id: 4006 */
                    uint32_t l_9567[10] = {0x55A60D16L,0xB23247E9L,0x55A60D16L,0xB23247E9L,0x55A60D16L,0xB23247E9L,0x55A60D16L,0xB23247E9L,0x55A60D16L,0xB23247E9L};
                    int32_t l_9569 = 0xD63BBCB5L;
                    int32_t l_9607 = 0L;
                    int i;
                    l_9569 |= (((l_9533[3][4] = (safe_rshift_func_uint16_t_u_s((l_9561[2] == &g_6006), (!(safe_rshift_func_int16_t_s_u(((l_9509 = ((0x2A7448253FC78CE2LL > (((safe_mod_func_int8_t_s_s((l_9567[2] <= 0xC89A44A8E2475EB0LL), (~4L))) != p_86) , 18446744073709551607UL)) < 0x8DF3A2F4B60902D3LL)) < p_86), 5)))))) | 0xD496L) == p_86);
                    l_9607 |= ((~(safe_sub_func_int8_t_s_s((safe_lshift_func_int8_t_s_u((safe_add_func_uint16_t_u_u(((*g_715) = p_86), ((*p_85) ^ ((safe_add_func_int16_t_s_s(p_86, (p_86 <= (l_9504 = ((safe_add_func_int64_t_s_s((safe_sub_func_int64_t_s_s((safe_rshift_func_int8_t_s_s((safe_sub_func_uint32_t_u_u(((safe_sub_func_int16_t_s_s(((safe_lshift_func_int8_t_s_s((-1L), (safe_mul_func_uint8_t_u_u((((safe_mod_func_int64_t_s_s((!(((*g_8235) = (*p_85)) > ((safe_add_func_int16_t_s_s(((((l_9605[4][0] = ((((l_9535 != ((((l_9604 &= ((((**g_4087) &= l_9598) , (l_9509 |= (safe_div_func_int32_t_s_s(((safe_div_func_int16_t_s_s((safe_unary_minus_func_uint64_t_u(0UL)), (*l_9396))) >= 1UL), p_86)))) ^ p_86)) , (**g_5407)) == (void*)0) >= (*p_85))) != (*p_85)) > p_86) <= p_86)) & 0L) ^ p_86) <= p_86), 0x4579L)) , p_86))), 0x2E030A0AAD4CE4CDLL)) , l_9606) == l_9606), (***g_4422))))) > (*l_9396)), 0xBAC3L)) | (*g_28)), l_9567[7])), (*p_85))), p_86)), l_9567[2])) != l_9569))))) != 4294967291UL)))), (*l_9396))), l_9538))) & p_86);
                    if (g_431)
                        goto lbl_9608;
                }
                (*g_1207) = (void*)0;
                for (g_8082.f3 = 0; (g_8082.f3 <= 5); g_8082.f3 += 1)
                { /* block id: 4023 */
                    int64_t l_9609 = 0xCF3D6F75AD0DCFC5LL;
                    int32_t l_9617[1][2][3] = {{{0x99AEF502L,1L,0x99AEF502L},{0x99AEF502L,0x99AEF502L,0xCA06CEACL}}};
                    int32_t l_9618 = (-1L);
                    int i, j, k;
                    l_9604 = (((**g_714) = ((l_9609 = p_86) <= ((*g_6119) = ((l_9533[2][8] ^ p_86) <= (l_9610 != ((((safe_lshift_func_int8_t_s_u(l_9538, 7)) <= l_9605[4][0]) , (l_9617[0][0][1] |= ((p_86 <= (65527UL && (l_9605[4][0] = ((safe_lshift_func_int8_t_s_s(((safe_add_func_int8_t_s_s(0xC4L, p_86)) || l_9533[2][8]), l_9605[2][0])) , 0xA5A0L)))) == l_9535))) | l_9618)))))) , l_9535);
                    for (g_7825.f0 = 5; (g_7825.f0 >= 0); g_7825.f0 -= 1)
                    { /* block id: 4032 */
                        l_9605[4][0] = l_9604;
                    }
                }
                l_9605[1][0] = l_9535;
            }
            else
            { /* block id: 4037 */
                uint32_t l_9655[5] = {0x27445B87L,0x27445B87L,0x27445B87L,0x27445B87L,0x27445B87L};
                int32_t *l_9658[3];
                int i;
                for (i = 0; i < 3; i++)
                    l_9658[i] = (void*)0;
                for (g_5271 = 1; (g_5271 != 9); g_5271 = safe_add_func_uint32_t_u_u(g_5271, 1))
                { /* block id: 4040 */
                    union U5 *l_9621[2][5] = {{&g_9622,&g_9622,&g_9622,&g_9622,&g_9622},{&g_9623[0][4],&g_9623[0][4],&g_9623[0][4],&g_9623[0][4],&g_9623[0][4]}};
                    int i, j;
                    (**g_9260) = l_9621[0][3];
                    (*l_9430) = (*l_9389);
                }
                (***g_2718) = &l_9401[0][1];
            }
        }
        else
        { /* block id: 4048 */
lbl_9926:
            for (g_6877.f3 = 9; (g_6877.f3 != 21); g_6877.f3++)
            { /* block id: 4051 */
                int64_t l_9662[9][7][4] = {{{2L,(-1L),(-3L),0x2B5D67CF2905619ALL},{(-1L),0x5BEDC28EC21641CELL,0x92BDB4BB94FA676FLL,0x5061CADB51145D4ALL},{0x595213DE78E5AC26LL,9L,(-1L),0x5061CADB51145D4ALL},{0x9A4DB647D67DD265LL,0x5BEDC28EC21641CELL,2L,0x2B5D67CF2905619ALL},{(-3L),(-1L),2L,(-2L)},{0L,(-1L),0x2B5D67CF2905619ALL,(-3L)},{0x9A4DB647D67DD265LL,(-2L),0x9A4DB647D67DD265LL,2L}},{{0x5BEDC28EC21641CELL,0x05AD7FE64DC6A365LL,0x92BDB4BB94FA676FLL,0L},{0x05AD7FE64DC6A365LL,(-1L),9L,0x05AD7FE64DC6A365LL},{2L,(-3L),9L,0x2B5D67CF2905619ALL},{0x05AD7FE64DC6A365LL,0x5061CADB51145D4ALL,0x92BDB4BB94FA676FLL,0x5BEDC28EC21641CELL},{0x5BEDC28EC21641CELL,9L,0x9A4DB647D67DD265LL,0x595213DE78E5AC26LL},{0x9A4DB647D67DD265LL,0x595213DE78E5AC26LL,0x2B5D67CF2905619ALL,0x2B5D67CF2905619ALL},{0L,0L,2L,(-1L)}},{{(-3L),(-1L),2L,(-1L)},{0x9A4DB647D67DD265LL,(-1L),(-1L),2L},{0x595213DE78E5AC26LL,(-1L),0x92BDB4BB94FA676FLL,(-1L)},{(-1L),(-1L),(-3L),(-1L)},{2L,0L,(-1L),0x2B5D67CF2905619ALL},{(-2L),0x595213DE78E5AC26LL,0x92BDB4BB94FA676FLL,0x595213DE78E5AC26LL},{0x5061CADB51145D4ALL,9L,2L,0x5BEDC28EC21641CELL}},{{0x9A4DB647D67DD265LL,0x5061CADB51145D4ALL,0x71691A73A3F7F4F0LL,0x2B5D67CF2905619ALL},{(-1L),(-3L),2L,0x05AD7FE64DC6A365LL},{(-1L),(-1L),0x71691A73A3F7F4F0LL,0L},{0x9A4DB647D67DD265LL,0x05AD7FE64DC6A365LL,2L,2L},{0x5061CADB51145D4ALL,(-2L),0x92BDB4BB94FA676FLL,(-3L)},{(-2L),(-1L),(-1L),(-2L)},{2L,(-1L),(-3L),0x2B5D67CF2905619ALL}},{{(-1L),0x5BEDC28EC21641CELL,0x92BDB4BB94FA676FLL,0x5061CADB51145D4ALL},{0x595213DE78E5AC26LL,9L,(-1L),0x5061CADB51145D4ALL},{0x9A4DB647D67DD265LL,0x5BEDC28EC21641CELL,2L,0x2B5D67CF2905619ALL},{(-3L),(-1L),2L,(-2L)},{0L,(-1L),0x2B5D67CF2905619ALL,(-3L)},{0x9A4DB647D67DD265LL,(-2L),0x9A4DB647D67DD265LL,2L},{0x5BEDC28EC21641CELL,0x05AD7FE64DC6A365LL,0x92BDB4BB94FA676FLL,0L}},{{0x05AD7FE64DC6A365LL,(-1L),9L,0x05AD7FE64DC6A365LL},{2L,(-3L),9L,0x2B5D67CF2905619ALL},{0x05AD7FE64DC6A365LL,0x5061CADB51145D4ALL,0x92BDB4BB94FA676FLL,0x5BEDC28EC21641CELL},{0x5BEDC28EC21641CELL,9L,0x9A4DB647D67DD265LL,0x595213DE78E5AC26LL},{0x9A4DB647D67DD265LL,0x595213DE78E5AC26LL,0x2B5D67CF2905619ALL,0x2B5D67CF2905619ALL},{0L,0L,2L,(-1L)},{(-3L),(-1L),2L,(-1L)}},{{0x9A4DB647D67DD265LL,(-1L),(-1L),2L},{0x595213DE78E5AC26LL,(-1L),(-1L),0x9A4DB647D67DD265LL},{(-1L),0L,2L,(-1L)},{1L,(-1L),0L,0x24AEA7A0F7C189D7LL},{(-3L),0x71691A73A3F7F4F0LL,(-1L),0x71691A73A3F7F4F0LL},{0x2B5D67CF2905619ALL,0x92BDB4BB94FA676FLL,1L,2L},{0x1EC227D33183B5E0LL,0x2B5D67CF2905619ALL,(-1L),0x24AEA7A0F7C189D7LL}},{{0x9A4DB647D67DD265LL,2L,(-3L),9L},{0x9A4DB647D67DD265LL,0L,(-1L),(-1L)},{0x1EC227D33183B5E0LL,9L,1L,(-1L)},{0x2B5D67CF2905619ALL,(-3L),(-1L),2L},{(-3L),0L,0L,(-3L)},{1L,0x9A4DB647D67DD265LL,2L,0x24AEA7A0F7C189D7LL},{(-1L),2L,(-1L),0x2B5D67CF2905619ALL}},{{0x71691A73A3F7F4F0LL,0x92BDB4BB94FA676FLL,(-1L),0x2B5D67CF2905619ALL},{0x1EC227D33183B5E0LL,2L,(-1L),0x24AEA7A0F7C189D7LL},{2L,0x9A4DB647D67DD265LL,(-3L),(-3L)},{(-1L),0L,0x24AEA7A0F7C189D7LL,2L},{0x1EC227D33183B5E0LL,(-3L),0x1EC227D33183B5E0LL,(-1L)},{2L,9L,(-1L),(-1L)},{9L,0L,0x92BDB4BB94FA676FLL,9L}}};
                int i, j, k;
                l_9401[0][2] |= (l_9533[2][8] = (p_86 != l_9662[4][3][1]));
            }
lbl_9666:
            for (g_8090.f3 = 0; (g_8090.f3 < 26); ++g_8090.f3)
            { /* block id: 4057 */
                int32_t l_9665[4] = {3L,3L,3L,3L};
                int i;
                if (p_86)
                    break;
                if (l_9665[0])
                    break;
            }
            if (p_86)
            { /* block id: 4062 */
                uint32_t l_9701[9][2][10] = {{{0xE127366CL,0x5B6C7CC4L,18446744073709551615UL,0x5B6C7CC4L,0xE127366CL,1UL,0x06D322C3L,0x8B9B2D4CL,1UL,1UL},{0x7C460E13L,0x8B9B2D4CL,0UL,9UL,9UL,0UL,0x8B9B2D4CL,0x7C460E13L,18446744073709551615UL,1UL}},{{18446744073709551615UL,9UL,0x8B9B2D4CL,0UL,0xE127366CL,0x06D322C3L,0xE127366CL,0UL,0x8B9B2D4CL,9UL},{0UL,1UL,0x8B9B2D4CL,0xE127366CL,0xDFAF6CC2L,0UL,0x7C460E13L,0x7C460E13L,0UL,0xDFAF6CC2L}},{{1UL,0UL,0UL,1UL,0x5B6C7CC4L,0UL,18446744073709551615UL,0x8B9B2D4CL,0xDFAF6CC2L,0x8B9B2D4CL},{0UL,0x06D322C3L,18446744073709551615UL,0x8B9B2D4CL,18446744073709551615UL,0x06D322C3L,0UL,18446744073709551615UL,0xDFAF6CC2L,1UL}},{{18446744073709551615UL,0UL,0x5B6C7CC4L,1UL,0UL,0UL,1UL,0x5B6C7CC4L,0UL,18446744073709551615UL},{0x7C460E13L,0UL,0xDFAF6CC2L,0xE127366CL,0x8B9B2D4CL,1UL,0UL,1UL,0x8B9B2D4CL,0xE127366CL}},{{0xE127366CL,0x06D322C3L,0xE127366CL,0UL,0x8B9B2D4CL,9UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{0x8B9B2D4CL,0UL,9UL,9UL,0UL,0x8B9B2D4CL,0x7C460E13L,18446744073709551615UL,1UL,1UL}},{{0x06D322C3L,1UL,0xE127366CL,0x5B6C7CC4L,18446744073709551615UL,0x5B6C7CC4L,0xE127366CL,1UL,0x7C460E13L,0x5B6C7CC4L},{0x7C460E13L,0UL,18446744073709551615UL,0UL,0x06D322C3L,0x5B6C7CC4L,0x5B6C7CC4L,0x06D322C3L,0UL,18446744073709551615UL}},{{0x5B6C7CC4L,0x5B6C7CC4L,0x06D322C3L,0UL,18446744073709551615UL,0UL,0x7C460E13L,0xE127366CL,0x7C460E13L,0UL},{9UL,0x06D322C3L,18446744073709551615UL,0x06D322C3L,9UL,0xDFAF6CC2L,0x7C460E13L,0x5B6C7CC4L,0x8B9B2D4CL,0x8B9B2D4CL}},{{0UL,0x5B6C7CC4L,1UL,0UL,0UL,1UL,0x5B6C7CC4L,0UL,18446744073709551615UL,0x8B9B2D4CL},{0xE127366CL,0UL,0x5B6C7CC4L,1UL,9UL,0x7C460E13L,9UL,1UL,0x5B6C7CC4L,0UL}},{{1UL,0xDFAF6CC2L,0x5B6C7CC4L,9UL,18446744073709551615UL,1UL,0UL,0UL,1UL,18446744073709551615UL},{0x8B9B2D4CL,1UL,1UL,0x8B9B2D4CL,0x06D322C3L,1UL,0xE127366CL,0x5B6C7CC4L,18446744073709551615UL,0x5B6C7CC4L}}};
                int32_t l_9702 = 0x1789FC1FL;
                union U4 ****l_9715 = &g_6523;
                union U4 *****l_9714 = &l_9715;
                int8_t l_9732[5] = {0xB3L,0xB3L,0xB3L,0xB3L,0xB3L};
                int16_t ***l_9753 = &g_1030[0][6];
                const int16_t ***l_9754[5][4][4] = {{{&g_1677[1][1],&g_1677[1][4],(void*)0,&g_1677[0][1]},{(void*)0,&g_1677[1][3],&g_1677[0][6],&g_1677[0][1]},{&g_1677[1][5],&g_1677[1][4],(void*)0,&g_1677[1][4]},{&g_1677[0][1],&g_1677[1][3],&g_1677[1][4],&g_1677[0][1]}},{{(void*)0,&g_1677[0][4],&g_1677[1][5],&g_1677[0][1]},{&g_1677[1][3],&g_1677[0][1],&g_1677[0][1],(void*)0},{&g_1677[1][3],&g_1677[1][5],&g_1677[1][5],&g_1677[1][5]},{(void*)0,(void*)0,&g_1677[1][4],(void*)0}},{{&g_1677[0][1],&g_1677[1][4],(void*)0,&g_1677[1][3]},{&g_1677[1][5],&g_1677[1][1],&g_1677[0][6],(void*)0},{(void*)0,&g_1677[1][1],(void*)0,&g_1677[1][3]},{&g_1677[1][1],&g_1677[1][4],&g_1677[1][1],(void*)0}},{{&g_1677[1][5],(void*)0,&g_1677[0][4],&g_1677[1][5]},{&g_1677[0][1],&g_1677[1][5],(void*)0,(void*)0},{&g_1677[1][3],&g_1677[0][1],(void*)0,&g_1677[0][1]},{&g_1677[0][1],&g_1677[0][4],&g_1677[0][4],&g_1677[0][1]}},{{&g_1677[1][5],&g_1677[1][3],&g_1677[1][1],&g_1677[1][4]},{&g_1677[1][1],&g_1677[1][4],(void*)0,&g_1677[0][1]},{(void*)0,&g_1677[1][3],&g_1677[0][6],&g_1677[0][1]},{&g_1677[1][5],&g_1677[1][4],(void*)0,&g_1677[1][4]}}};
                int64_t ** const *l_9785 = (void*)0;
                int64_t l_9818 = 0x3E48BC65A127AE72LL;
                int32_t l_9819 = 0L;
                int32_t *l_9833 = &l_9533[0][5];
                int i, j, k;
                if (((****g_5408) == ((((((safe_rshift_func_uint16_t_u_s((((((l_9701[3][0][0] ^= (safe_mul_func_int8_t_s_s((l_9671 = ((**g_1540) | l_9509)), (l_9533[2][0] = ((safe_lshift_func_uint8_t_u_u((((safe_mod_func_uint16_t_u_u((((safe_mul_func_uint16_t_u_u(((safe_div_func_int8_t_s_s((((**g_4139) = (safe_add_func_int8_t_s_s((safe_mod_func_uint8_t_u_u((l_9533[1][2] , (((safe_mul_func_uint8_t_u_u((p_86 & (safe_rshift_func_int16_t_s_s(((void*)0 == l_9688), 4))), l_9690)) < p_86) || l_9691)), g_9692)), (*l_9396)))) == 0xF4L), 1L)) & (*l_9396)), (*g_715))) , g_9693[2]) == l_9699), p_86)) > l_9509) && (*l_9396)), 3)) > p_86))))) < 0x2BF72A38A652F7C7LL) < l_9702) <= p_86) && 1L), 13)) , 0x6755L) < (*l_9396)) & p_86) & l_9703[2]) , (*l_9396))))
                { /* block id: 4067 */
                    union U2 ***l_9709 = &l_9708;
                    if (((safe_lshift_func_uint8_t_u_s(p_86, (safe_mul_func_int32_t_s_s(p_86, (((*l_9709) = l_9708) != &l_9424))))) != p_86))
                    { /* block id: 4069 */
                        int32_t l_9710 = 0xD213EC7FL;
                        return l_9710;
                    }
                    else
                    { /* block id: 4071 */
                        return (****g_1675);
                    }
                }
                else
                { /* block id: 4074 */
                    for (l_9691 = 0; (l_9691 <= 2); l_9691 += 1)
                    { /* block id: 4077 */
                        return l_9702;
                    }
                }
                if ((safe_mul_func_int8_t_s_s((((l_9714 = l_9713) == &l_9715) , l_9716[0]), (safe_mod_func_int8_t_s_s((l_9671 , ((((((((safe_mod_func_int64_t_s_s(l_9721, (p_86 ^ (safe_mod_func_uint32_t_u_u(((safe_div_func_uint64_t_u_u((safe_mul_func_int8_t_s_s((l_9702 & (((((safe_mul_func_uint8_t_u_u(((void*)0 != (****g_1674)), (-1L))) , 1L) != l_9730) , (-1L)) >= p_86)), (**g_4139))), 18446744073709551609UL)) && 7UL), (*l_9396)))))) , l_9703[4]) < (*l_9396)) | p_86) <= l_9731) != 0xEDL) || l_9702) | l_9732[0])), (**g_4423))))))
                { /* block id: 4082 */
                    const union U2 *****l_9735 = &l_9733;
                    (*l_9735) = l_9733;
                    if (g_7825.f0)
                        goto lbl_9820;
                }
                else
                { /* block id: 4084 */
                    int64_t l_9736 = 0L;
                    uint64_t **l_9765 = &g_4583[4];
                    uint64_t l_9774 = 0x0FD4ADA441DC6A8FLL;
                    uint32_t *l_9777 = &g_3643;
                    l_9737[5][0][2]++;
                    if ((!(((**l_9391) = p_86) , p_86)))
                    { /* block id: 4087 */
                        const int16_t *l_9741 = &g_7297[1][0][4];
                        int16_t ***l_9752 = &g_1030[0][5];
                        struct S1 *l_9758 = &g_9759[1];
                        struct S1 **l_9760 = (void*)0;
                        int32_t *l_9767 = (void*)0;
                        int32_t *l_9768 = &g_255;
                        l_9770 = func_132(p_85, l_9741, (((safe_mul_func_uint8_t_u_u(((((*g_1541) = (safe_mul_func_uint32_t_u_u(1UL, (((((safe_sub_func_int8_t_s_s((**g_4423), ((*g_8235) = (safe_div_func_uint8_t_u_u(((safe_sub_func_uint8_t_u_u((((l_9753 = l_9752) != ((**g_929) , l_9754[4][2][1])) <= ((*l_9768) = (safe_mul_func_uint8_t_u_u(((safe_unary_minus_func_uint64_t_u((((***l_9542) &= ((((l_9761 = l_9758) == (((((safe_mul_func_int8_t_s_s(((void*)0 == l_9765), (**g_4423))) >= 0xE0EEL) , 0xB4L) >= (*g_7633)) , g_3197)) , p_86) == 0x5DL)) == l_9766))) < l_9703[2]), (*g_28))))), (*p_85))) , p_86), l_9736))))) , (****g_5408)) , 0UL) || p_86) != 0xD34CL)))) ^ p_86) , (*l_9396)), 0x05L)) , (*p_85)) & (*p_85)), l_9769);
                        return l_9771;
                    }
                    else
                    { /* block id: 4096 */
                        uint32_t *l_9779 = (void*)0;
                        uint32_t **l_9780 = (void*)0;
                        uint32_t **l_9781 = (void*)0;
                        uint32_t **l_9782 = &l_9779;
                        int64_t ** const **l_9786 = &l_9785;
                        int8_t *l_9798[5][2][1] = {{{&g_29},{&g_29}},{{&g_29},{&g_29}},{{&g_29},{&g_29}},{{&g_29},{&g_29}},{{&g_29},{&g_29}}};
                        int8_t ** const l_9797 = &l_9798[0][0][0];
                        int8_t ** const *l_9796 = &l_9797;
                        int8_t ** const **l_9795 = &l_9796;
                        int8_t ** const ***l_9794 = &l_9795;
                        uint32_t *****l_9800[3][6] = {{&l_9799,(void*)0,&l_9799,&l_9799,(void*)0,&l_9799},{&l_9799,&l_9799,&l_9799,&l_9799,&l_9799,&l_9799},{&l_9799,&l_9799,&l_9799,&l_9799,&l_9799,&l_9799}};
                        const int32_t l_9802 = 0x4218370AL;
                        int i, j, k;
                        (*g_1207) = (((safe_rshift_func_uint16_t_u_u(((**g_714) |= (l_9533[3][2] = ((4294967295UL && ((((p_86 && l_9774) && (-1L)) == (safe_mod_func_int8_t_s_s(((((*g_929) = (l_9778[4] = l_9777)) == ((*l_9782) = l_9779)) , 0xCCL), (safe_sub_func_uint32_t_u_u((*l_9770), (((*l_9786) = l_9785) != (void*)0)))))) , 0xBC91BC66L)) == (-1L)))), l_9787)) >= 4294967295UL) , (void*)0);
                        (*l_9770) = (((safe_sub_func_int32_t_s_s(((safe_add_func_uint32_t_u_u((((*g_715) = 65534UL) > l_9732[0]), (l_9504 ^= ((*l_9770) != (p_86 > ((**g_1540) = l_9535)))))) & ((((safe_lshift_func_uint8_t_u_u((((*l_9794) = (void*)0) == (void*)0), 5)) , &g_7504) != (l_9801 = l_9799)) && 5L)), 0xBEBBE4D7L)) ^ l_9802) | 2UL);
                        l_9702 ^= (l_9803 ^= (p_86 | p_86));
                    }
                }
                if ((((((void*)0 == l_9804) > 0x0CD7C50982C16BFDLL) & (l_9805 != l_9732[4])) > l_9509))
                { /* block id: 4114 */
                    (*l_9770) |= g_9806;
lbl_9820:
                    l_9509 = ((*l_9770) = (l_9819 ^= ((((((((+(((-2L) > ((p_86 & 0xB1AAA44DL) ^ (*g_7633))) | (--(**g_4139)))) > (+(+((safe_mul_func_uint16_t_u_u(p_86, ((void*)0 != &g_6240))) <= l_9701[3][0][0])))) ^ (l_9818 |= ((((((l_9533[2][1] = (safe_sub_func_int64_t_s_s((((((((safe_rshift_func_uint16_t_u_u(0xFDE4L, 6)) & 0xF558E349B3BF6571LL) , (void*)0) != (***g_2717)) > p_86) != (**g_4423)) | p_86), p_86))) && p_86) && l_9702) <= 0x6306L) , (void*)0) == (*g_5127)))) ^ 0xE0C4L) <= (*g_6119)) || 7UL) , (*g_28)) , p_86)));
                    (*l_9833) = ((*l_9770) = ((safe_mul_func_int16_t_s_s((*****g_1674), ((**g_714) = ((*g_1541) | ((*l_9396) <= (**g_4423)))))) < (safe_lshift_func_int16_t_s_u(((p_86 != (safe_rshift_func_int16_t_s_u((safe_div_func_int32_t_s_s((safe_sub_func_uint8_t_u_u((((!255UL) != (&g_1675 == (void*)0)) , ((*l_9396) , l_9702)), 1UL)), l_9832)), l_9701[3][0][0]))) <= p_86), 3))));
                }
                else
                { /* block id: 4126 */
                    uint8_t l_9834 = 247UL;
                    int32_t l_9841 = (-2L);
                    int32_t l_9842 = 0x57392715L;
                    union U3 ** const *l_9852 = &l_9389;
                    union U3 ** const **l_9851[5][10] = {{&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852},{&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852},{&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852},{&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852},{&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852,&l_9852}};
                    int i, j;
lbl_9846:
                    for (g_1470 = 0; (g_1470 <= 0); g_1470 += 1)
                    { /* block id: 4129 */
                        int32_t *l_9836 = &g_4882;
                        int32_t *l_9837 = &l_9533[2][8];
                        int32_t *l_9838 = &g_499[0][0];
                        int32_t *l_9839[5] = {&g_3420[1],&g_3420[1],&g_3420[1],&g_3420[1],&g_3420[1]};
                        int i;
                        (*l_9770) = l_9834;
                        if (p_86)
                            break;
                        l_9843--;
                        if (g_466)
                            goto lbl_9846;
                    }
                    (*l_9770) = p_86;
                    for (g_9692 = 0; (g_9692 <= 4); g_9692 += 1)
                    { /* block id: 4138 */
                        uint16_t l_9854 = 0UL;
                        int32_t *l_9860 = &l_9401[1][2];
                        int32_t *l_9861 = &g_499[1][0];
                        int32_t *l_9862 = &l_9503;
                        int32_t *l_9863 = &l_9841;
                        int32_t *l_9864 = (void*)0;
                        int32_t *l_9865 = &l_9533[2][8];
                        int32_t *l_9866 = &g_499[0][0];
                        int32_t *l_9867 = (void*)0;
                        int32_t *l_9868 = &g_4882;
                        int32_t *l_9869 = (void*)0;
                        int32_t *l_9870 = &g_3307;
                        int32_t *l_9871 = &g_3420[1];
                        int32_t *l_9872 = &l_9533[2][8];
                        int32_t *l_9873[7];
                        int i;
                        for (i = 0; i < 7; i++)
                            l_9873[i] = (void*)0;
                        (*l_9770) = ((*l_9833) ^ ((safe_div_func_uint64_t_u_u((((*g_7633) |= (((*l_9396) != 4294967294UL) > (l_9854 = ((***l_9542) = (safe_rshift_func_int8_t_s_u((l_9851[1][8] != ((*l_9433) = l_9853)), 0)))))) && ((*g_656) = p_86)), (safe_lshift_func_uint16_t_u_u(0x156BL, (safe_mod_func_int16_t_s_s(l_9533[3][2], 0x171CL)))))) , 0L));
                        if (l_9766)
                            goto lbl_9859;
                        --l_9874[0];
                    }
                }
                (*l_9770) = ((((l_9509 , ((l_9533[2][8] = ((l_9835 ^ (l_9805 <= (l_9887 &= (((g_9880[0] = l_9877) == ((*l_9833) , ((*l_9833) , ((safe_mul_func_uint16_t_u_u((safe_lshift_func_int8_t_s_u((((((4294967295UL != (((*g_1541) = l_9835) != (*l_9770))) == (*g_28)) , l_9805) , (*l_9770)) != (-1L)), 2)), p_86)) , &g_9881)))) , 0xB2L)))) , (*l_9396))) || p_86)) & (*****g_1674)) <= l_9888) ^ p_86);
            }
            else
            { /* block id: 4154 */
                int16_t *l_9901 = &l_9805;
                const int32_t l_9910[8][9][3] = {{{0xEB1B18FDL,(-4L),0x77089988L},{0xDA7D1F03L,(-4L),0xEF9B71F4L},{0L,0x0625CAFDL,(-8L)},{0L,0xB17FCB94L,(-1L)},{(-7L),0x388499A8L,6L},{0x488F66F9L,0xF30E8C00L,0xB17FCB94L},{0x916956DDL,(-1L),1L},{0L,0L,0xC195823BL},{1L,1L,0xEB1B18FDL}},{{3L,0x07F38625L,0x488F66F9L},{0xF2DD6158L,0xB0C79A42L,(-9L)},{0xFC9C227FL,3L,0x488F66F9L},{0L,(-7L),0xEB1B18FDL},{0xCEB4B622L,(-1L),0xC195823BL},{0xF30E8C00L,0x1E678B10L,1L},{(-1L),(-1L),0xB17FCB94L},{0xC35819B7L,0xDA7D1F03L,6L},{0xC195823BL,0xFCF0F435L,(-1L)}},{{(-8L),0x916956DDL,(-8L)},{(-1L),0x22AC55B1L,0xEF9B71F4L},{0x844380E0L,0x0B978F22L,0x77089988L},{0x844380E0L,0xFF19821BL,(-8L)},{(-1L),0xC195823BL,0xFF19821BL},{(-8L),0xCEB4B622L,0x3304EDDCL},{0xC195823BL,0xEC12BCECL,(-4L)},{0xC35819B7L,(-8L),0xF2DD6158L},{(-1L),0x5A6583FDL,0x5A6583FDL}},{{0xF30E8C00L,0L,0xCEB4B622L},{0xCEB4B622L,0L,(-8L)},{0L,(-8L),0x22AC55B1L},{0xFC9C227FL,0xEB1B18FDL,(-1L)},{0xF2DD6158L,(-8L),0xFC9C227FL},{3L,0L,0L},{1L,0L,(-1L)},{0L,0x5A6583FDL,0x0B978F22L},{0x916956DDL,(-8L),1L}},{{0x488F66F9L,0xEC12BCECL,(-1L)},{(-7L),0xCEB4B622L,0x0625CAFDL},{0L,0xC195823BL,0xC35819B7L},{0L,0xFF19821BL,8L},{0xDA7D1F03L,0x0B978F22L,8L},{0xEB1B18FDL,0x22AC55B1L,0xC35819B7L},{(-1L),0x916956DDL,0x0625CAFDL},{0x388499A8L,0xFCF0F435L,(-1L)},{(-9L),0xDA7D1F03L,1L}},{{0x22AC55B1L,(-1L),0x0B978F22L},{(-1L),0x1E678B10L,(-1L)},{(-8L),0L,0xFF19821BL},{(-9L),(-1L),2L},{0x844380E0L,0xB17FCB94L,0x488F66F9L},{0xFCF0F435L,(-8L),0x0625CAFDL},{0x844380E0L,(-1L),0L},{(-9L),0x916956DDL,0L},{(-8L),1L,0L}},{{0L,0xEB1B18FDL,(-8L)},{0x0625CAFDL,0xCEB4B622L,(-7L)},{0x07F38625L,0x0B978F22L,8L},{0x0B978F22L,0xF30E8C00L,0xEC12BCECL},{0x488F66F9L,1L,0xC35819B7L},{(-9L),(-7L),0xFCF0F435L},{0x659E5886L,(-7L),6L},{(-1L),1L,(-4L)},{0xEF9B71F4L,0xF30E8C00L,0xEB1B18FDL}},{{(-1L),0x0B978F22L,0xB0C79A42L},{8L,0xCEB4B622L,0xF30E8C00L},{0L,0xEB1B18FDL,0x916956DDL},{1L,1L,0xDA7D1F03L},{(-1L),0x916956DDL,(-9L)},{0xB17FCB94L,(-1L),8L},{(-8L),(-8L),6L},{2L,0xB17FCB94L,8L},{0x1E678B10L,(-1L),(-9L)}}};
                struct S1 *l_9911 = &g_9912;
                uint64_t l_9923 = 0UL;
                int32_t l_9930 = 6L;
                int32_t l_9933 = 0xF353F810L;
                int64_t *l_9944 = &g_6571.f3;
                int32_t *l_9953[4][1] = {{&l_9835},{(void*)0},{&l_9835},{(void*)0}};
                union U5 *l_9992 = &g_9993;
                uint32_t l_9999 = 0UL;
                int i, j, k;
                for (l_9610 = 0; (l_9610 >= 0); l_9610 -= 1)
                { /* block id: 4157 */
                    int16_t * const l_9902[3] = {(void*)0,(void*)0,(void*)0};
                    union U4 *l_9914 = &g_9915[2];
                    int32_t l_9922 = 0xFE85D9B2L;
                    int i;
                    if (l_9721)
                        goto lbl_9859;
                    if (((safe_mul_func_int8_t_s_s((((&l_9509 == ((safe_lshift_func_int8_t_s_s((((*g_715) = ((safe_rshift_func_int8_t_s_u((safe_lshift_func_int16_t_s_u((l_9897 == ((((safe_sub_func_uint64_t_u_u((((*g_6119) = ((l_9901 = &p_86) != l_9902[1])) , l_9716[l_9610]), 0xE57ECD02AC2FF03ELL)) <= (safe_div_func_uint16_t_u_u(((((((((((l_9716[l_9610] , ((-1L) >= ((*****g_5407) &= (~(safe_div_func_uint32_t_u_u(((safe_div_func_uint32_t_u_u((*l_9396), l_9910[7][2][1])) ^ 0xDFL), p_86)))))) || (*p_85)) || l_9910[7][2][1]) ^ p_86) || l_9766) , p_86) , 7L) , (void*)0) == (void*)0) , 0xF875L), p_86))) , (*g_5749)) , l_9911)), 13)), 6)) != p_86)) != (-8L)), l_9716[0])) , &l_9533[0][6])) | p_86) , (*l_9770)), l_9913)) , l_9716[l_9610]))
                    { /* block id: 4163 */
                        union U4 *l_9916 = &g_9917;
                        int32_t l_9918 = 0xBFA85FE0L;
                        (*g_2302) = (l_9916 = l_9914);
                        return l_9918;
                    }
                    else
                    { /* block id: 4167 */
                        (**g_9260) = (g_9920 = ((*g_6484) = l_9919));
                        l_9923++;
                    }
                    if (l_9874[0])
                        continue;
                    for (g_6233 = 0; (g_6233 <= 0); g_6233 += 1)
                    { /* block id: 4176 */
                        int32_t *l_9928 = &g_8779;
                        int32_t *l_9929[1];
                        int i, j;
                        for (i = 0; i < 1; i++)
                            l_9929[i] = &l_9503;
                        if (l_9690)
                            goto lbl_9926;
                        --l_9934;
                        l_9937[0][1] = &l_9933;
                    }
                }
                if ((((l_9950 = (safe_unary_minus_func_uint16_t_u(((safe_lshift_func_int8_t_s_u((p_86 & ((*g_6119) &= ((l_9941 >= ((void*)0 != l_9801)) >= 0x19L))), 7)) >= ((l_9949 = ((l_9933 ^= ((safe_lshift_func_uint8_t_u_s((((*l_9770) = ((*l_9944) = ((*g_9260) != (**g_9259)))) && (safe_div_func_uint32_t_u_u(((*l_9770) = ((**g_929)--)), p_86))), 3)) && p_86)) <= p_86)) >= p_86))))) ^ p_86) , l_9951))
                { /* block id: 4190 */
                    int32_t l_9952 = 0x979A3CF2L;
                    l_9952 = p_86;
                    l_9396 = l_9953[2][0];
                }
                else
                { /* block id: 4193 */
                    int8_t l_9983 = 0x32L;
                    int32_t l_9994[6][2] = {{0x7069160EL,0x7069160EL},{0x7069160EL,0x7069160EL},{0x7069160EL,0x7069160EL},{0x7069160EL,0x7069160EL},{0x7069160EL,0x7069160EL},{0x7069160EL,0x7069160EL}};
                    int32_t l_9995 = (-1L);
                    int i, j;
                    for (g_1470 = 8; (g_1470 != (-20)); g_1470 = safe_sub_func_uint64_t_u_u(g_1470, 7))
                    { /* block id: 4196 */
                        uint16_t l_9964 = 65526UL;
                        uint32_t l_9970 = 0x39273CA0L;
                        const uint64_t ****l_9991 = &l_9990[3][0];
                        int32_t l_9996 = 0x1AC3D227L;
                        uint8_t ****l_10002 = &g_10001[2];
                        l_9973[4] &= (0x403320DE5E23DD8FLL >= ((safe_sub_func_uint8_t_u_u((*****g_5407), (safe_sub_func_uint64_t_u_u((255UL || (p_86 < ((*l_9769) = ((((0xEA8707BADF9921E0LL == (p_86 >= ((safe_rshift_func_uint8_t_u_s((l_9964 , (*g_5411)), (((((safe_div_func_uint32_t_u_u((((safe_rshift_func_uint8_t_u_s(p_86, 0)) && p_86) || (*g_28)), p_86)) < l_9969[1]) & 0xACL) & 0x06E0L) , l_9970))) , l_9971))) , (***g_4422)) ^ 0L) || p_86)))), (*l_9396))))) != l_9972));
                        l_9937[1][0] = (((safe_mod_func_uint64_t_u_u((*l_9396), (l_9970 && (p_86 != ((g_10000 = (((((*l_9769) = (safe_add_func_uint32_t_u_u((((((void*)0 != &l_9964) , (!(--(**l_9442)))) != (l_9999 = (l_9998[0] = (((((safe_mod_func_int64_t_s_s(((l_9983 ^= l_9964) < (safe_div_func_int64_t_s_s((l_9995 = (((***l_9542) = (safe_div_func_int8_t_s_s((safe_mod_func_uint32_t_u_u(p_86, (l_9994[4][0] ^= (((*l_9991) = l_9990[5][0]) == ((((**g_6483) = l_9992) == (void*)0) , (void*)0))))), (*l_9396)))) >= p_86)), (*g_1541)))), p_86)) || p_86) , l_9996) ^ l_9997) && (*l_9770))))) || p_86), p_86))) & l_9970) < (*l_9396)) , (void*)0)) != l_10002))))) <= p_86) , (void*)0);
                        if (p_86)
                            continue;
                        l_9994[4][0] ^= l_9983;
                    }
                    for (g_6877.f3 = (-28); (g_6877.f3 > (-15)); g_6877.f3 = safe_add_func_int8_t_s_s(g_6877.f3, 1))
                    { /* block id: 4216 */
                        int32_t **l_10006 = &l_9953[0][0];
                        (*l_10006) = ((***g_2718) = l_10005);
                        --l_10007;
                        return (****g_1675);
                    }
                }
            }
            for (g_260 = 0; (g_260 > 13); g_260++)
            { /* block id: 4226 */
                union U5 ***l_10024[1][7][2] = {{{&g_6484,&g_6484},{&g_6484,&g_6484},{&g_6484,&g_6484},{&g_6484,&g_6484},{&g_6484,&g_6484},{&g_6484,&g_6484},{&g_6484,&g_6484}}};
                uint16_t l_10028[7];
                int32_t l_10060 = 0xA179A345L;
                int32_t l_10064[9][3] = {{0x35E5ED20L,0x35E5ED20L,0x8140AC22L},{0x700F5239L,0x1EFF7320L,0x8140AC22L},{0x1EFF7320L,0x700F5239L,0x8140AC22L},{0x35E5ED20L,0x35E5ED20L,0x8140AC22L},{0x700F5239L,0x1EFF7320L,0x8140AC22L},{0x1EFF7320L,0x700F5239L,0x8140AC22L},{0x35E5ED20L,0x35E5ED20L,0x8140AC22L},{0x700F5239L,0x1EFF7320L,0x8140AC22L},{0x1EFF7320L,0x700F5239L,0x8140AC22L}};
                int i, j, k;
                for (i = 0; i < 7; i++)
                    l_10028[i] = 0xA368L;
                for (l_9671 = (-10); (l_9671 == 16); l_9671 = safe_add_func_uint32_t_u_u(l_9671, 8))
                { /* block id: 4229 */
                    uint16_t l_10037 = 65529UL;
                    int32_t l_10059 = 0x0E9F5CC7L;
                    int32_t l_10061 = 0x4EE4472DL;
                    int32_t l_10063 = 0xA25291B7L;
                    int32_t l_10066 = 1L;
                    int32_t l_10067 = 0x2EB38789L;
                    uint32_t l_10089 = 0xA0674A3FL;
                    const union U2 *****l_10096 = (void*)0;
                    const union U2 *****l_10097 = (void*)0;
                    const union U2 *****l_10098 = &l_10095[2][2][3];
                    for (g_6607.f0 = (-29); (g_6607.f0 <= 1); g_6607.f0++)
                    { /* block id: 4232 */
                        union U5 ****l_10025 = &g_6483;
                        int32_t l_10035 = 0x33F460C0L;
                        int32_t l_10065 = 0x96986D46L;
                        (*l_9770) = (safe_div_func_int16_t_s_s(((l_10038 = (safe_rshift_func_uint8_t_u_s(((((*l_10005) = (l_10037 &= ((p_86 != (((((safe_rshift_func_int8_t_s_u((((**g_714) = ((((*p_85) ^ (safe_rshift_func_int16_t_s_s((((*l_10025) = l_10024[0][5][1]) == l_10024[0][3][0]), ((*l_9769) = (safe_mul_func_uint16_t_u_u((p_86 < (((*g_5411) |= 0xECL) < (l_10028[1] && (safe_div_func_int32_t_s_s(0xAFCC2CE9L, (safe_rshift_func_int8_t_s_u((safe_sub_func_uint8_t_u_u(1UL, l_10028[6])), p_86))))))), 0xD47BL)))))) , 18446744073709551613UL) , 65534UL)) | l_10035), p_86)) <= (**g_929)) , 0xA21F54D6L) , p_86) ^ l_10036[8])) , l_10028[0]))) , (*g_28)) <= (*p_85)), (*g_28)))) <= p_86), l_10039));
                        l_10058 = ((safe_mod_func_int8_t_s_s((((((safe_sub_func_uint32_t_u_u(l_10028[0], 0xF287FA17L)) || (safe_sub_func_uint32_t_u_u((safe_mod_func_uint16_t_u_u(((safe_add_func_int64_t_s_s(l_10035, (safe_sub_func_uint16_t_u_u(p_86, (safe_add_func_uint64_t_u_u((p_86 && p_86), ((*g_6119) < (p_86 < (safe_rshift_func_int8_t_s_u((((void*)0 != l_10056[0][6][3]) >= 0x89L), 5)))))))))) <= 1L), p_86)), 0x123A8C50L))) ^ p_86) , l_10057) != (void*)0), l_10035)) == 0x6632FA3D1015A7E6LL);
                        l_10068++;
                        (*l_9770) ^= (safe_div_func_int8_t_s_s(((safe_mod_func_uint64_t_u_u(0xC6CBC4111C8FBDD3LL, (-1L))) , (((safe_unary_minus_func_uint32_t_u((p_86 < (safe_sub_func_uint8_t_u_u((((safe_rshift_func_uint8_t_u_u(((-1L) >= ((*p_85) | (safe_rshift_func_uint8_t_u_s((((p_86 | ((p_86 < ((l_10061 = ((safe_div_func_int32_t_s_s((((safe_div_func_uint8_t_u_u((((void*)0 != (*g_4087)) , 255UL), 0x3EL)) <= p_86) , l_10064[4][1]), l_10088)) != 0x7B1607F975C51AC1LL)) <= l_10089)) < p_86)) , 18446744073709551611UL) > (**g_1540)), 5)))), p_86)) | 1UL) || 0x0DEAL), (*p_85)))))) & 0xE62A7034L) < p_86)), l_10089));
                    }
                    if (l_10090)
                        break;
                    (*l_10005) = (safe_add_func_uint8_t_u_u((safe_add_func_int8_t_s_s(((((*l_10098) = l_10095[5][6][1]) == (l_10059 , (*l_9877))) <= ((((safe_sub_func_int32_t_s_s(((*l_9770) , ((((****l_9405) = (p_86 < 0xCA2E75B7L)) , (safe_mul_func_uint8_t_u_u((&g_6006 == (void*)0), ((-1L) && 0x06L)))) == l_10103)), l_10064[1][0])) >= p_86) != 0x5AA0L) > 1UL)), 0xA7L)), (*p_85)));
                }
                for (g_1219 = 29; (g_1219 != 57); g_1219 = safe_add_func_int16_t_s_s(g_1219, 7))
                { /* block id: 4253 */
                    int16_t l_10108 = 0xFDFCL;
                    int16_t l_10109[7] = {0x7534L,0x7534L,0x269AL,0x7534L,0x7534L,0x269AL,0x7534L};
                    int32_t l_10111 = 0xA7A67877L;
                    int32_t l_10112 = 0xD6D12204L;
                    int i;
                    for (g_6879.f3 = 24; (g_6879.f3 > 20); --g_6879.f3)
                    { /* block id: 4256 */
                        int32_t l_10110 = 6L;
                        int32_t l_10113 = 0L;
                        l_10114--;
                    }
                }
            }
        }
        for (l_9535 = (-18); (l_9535 < 26); l_9535++)
        { /* block id: 4264 */
            return (*****g_1674);
        }
        (*l_10005) = (l_9503 = (l_10119 != ((((*g_1541) = ((p_86 < (safe_mul_func_int16_t_s_s(1L, ((((*l_9770) = (safe_sub_func_int32_t_s_s(((*l_9770) < (((4L < (safe_add_func_uint16_t_u_u((+((((*l_9769) = ((+(safe_add_func_uint64_t_u_u((safe_mod_func_int8_t_s_s(((*g_8235) ^= ((*g_7633) |= ((((safe_div_func_uint8_t_u_u((p_86 , (****g_5408)), (*p_85))) > (p_86 >= (*l_9770))) >= 0x05AA8DD26E86E7FBLL) ^ (*l_10005)))), 1L)), 18446744073709551615UL))) || p_86)) && p_86) , p_86)), 0L))) > 0x9DL) && p_86)), (-8L)))) ^ 0x6F12L) & 2L)))) ^ p_86)) & p_86) , (void*)0)));
    }
    return (*l_9770);
}


/* ------------------------------------------ */
/* 
 * reads : g_78 g_7 g_951 g_1674 g_1675 g_1540 g_1541 g_998 g_5410 g_5411 g_3870 g_715 g_466 g_2 g_4882 g_2717 g_2718 g_2719 g_1207 g_6119 g_845 g_4423 g_28 g_29 g_9377 g_653 g_4422 g_4493
 * writes: g_78 g_38 g_951 g_466 g_4882 g_653
 */
static int8_t * func_87(int16_t * p_88, int32_t * p_89)
{ /* block id: 26 */
    const uint32_t *l_113 = &g_66;
    int32_t l_149[10] = {0xEE848C45L,1L,0x99312A2FL,0x99312A2FL,1L,0xEE848C45L,1L,0x99312A2FL,0x99312A2FL,1L};
    int32_t l_7242 = 0xDEF4F8C1L;
    uint32_t *l_8589 = &g_1020;
    const int8_t *l_8900 = (void*)0;
    int8_t *l_8939[8][7][4] = {{{&g_4118[3],(void*)0,&g_2886,&g_29},{&g_4118[4],&g_7088,&g_4118[3],&g_29},{&g_1621[1],(void*)0,&g_1621[1],&g_4118[1]},{&g_1621[1],&g_4118[1],&g_4118[3],(void*)0},{&g_4118[4],&g_4118[1],&g_2886,&g_4118[1]},{&g_4118[3],(void*)0,&g_2886,&g_29},{&g_4118[4],&g_7088,&g_4118[3],&g_29}},{{&g_1621[1],(void*)0,&g_1621[1],&g_4118[1]},{&g_1621[1],&g_4118[1],&g_4118[3],(void*)0},{&g_4118[4],&g_4118[1],&g_2886,(void*)0},{&g_1621[1],&g_7088,(void*)0,(void*)0},{&g_4118[3],&g_4118[1],&g_1621[1],(void*)0},{&g_2886,&g_7088,&g_2886,(void*)0},{&g_2886,(void*)0,&g_1621[1],&g_29}},{{&g_4118[3],(void*)0,(void*)0,(void*)0},{&g_1621[1],&g_7088,(void*)0,(void*)0},{&g_4118[3],&g_4118[1],&g_1621[1],(void*)0},{&g_2886,&g_7088,&g_2886,(void*)0},{&g_2886,(void*)0,&g_1621[1],&g_29},{&g_4118[3],(void*)0,(void*)0,(void*)0},{&g_1621[1],&g_7088,(void*)0,(void*)0}},{{&g_4118[3],&g_4118[1],&g_1621[1],(void*)0},{&g_2886,&g_7088,&g_2886,(void*)0},{&g_2886,(void*)0,&g_1621[1],&g_29},{&g_4118[3],(void*)0,(void*)0,(void*)0},{&g_1621[1],&g_7088,(void*)0,(void*)0},{&g_4118[3],&g_4118[1],&g_1621[1],(void*)0},{&g_2886,&g_7088,&g_2886,(void*)0}},{{&g_2886,(void*)0,&g_1621[1],&g_29},{&g_4118[3],(void*)0,(void*)0,(void*)0},{&g_1621[1],&g_7088,(void*)0,(void*)0},{&g_4118[3],&g_4118[1],&g_1621[1],(void*)0},{&g_2886,&g_7088,&g_2886,(void*)0},{&g_2886,(void*)0,&g_1621[1],&g_29},{&g_4118[3],(void*)0,(void*)0,(void*)0}},{{&g_1621[1],&g_7088,(void*)0,(void*)0},{&g_4118[3],&g_4118[1],&g_1621[1],(void*)0},{&g_2886,&g_7088,&g_2886,(void*)0},{&g_2886,(void*)0,&g_1621[1],&g_29},{&g_4118[3],(void*)0,(void*)0,(void*)0},{&g_1621[1],&g_7088,(void*)0,(void*)0},{&g_4118[3],&g_4118[1],&g_1621[1],(void*)0}},{{&g_2886,&g_7088,&g_2886,(void*)0},{&g_2886,(void*)0,&g_1621[1],&g_29},{&g_4118[3],(void*)0,(void*)0,(void*)0},{&g_1621[1],&g_7088,(void*)0,(void*)0},{&g_4118[3],&g_4118[1],&g_1621[1],(void*)0},{&g_2886,&g_7088,&g_2886,(void*)0},{&g_2886,(void*)0,&g_1621[1],&g_29}},{{&g_4118[3],(void*)0,(void*)0,(void*)0},{&g_1621[1],&g_7088,(void*)0,(void*)0},{&g_4118[3],&g_4118[1],&g_1621[1],(void*)0},{&g_2886,&g_7088,&g_2886,(void*)0},{&g_2886,(void*)0,&g_1621[1],&g_29},{&g_4118[3],(void*)0,(void*)0,(void*)0},{&g_1621[1],&g_7088,(void*)0,(void*)0}}};
    uint8_t ***l_9021 = &g_4139;
    uint8_t ****l_9020 = &l_9021;
    uint8_t *****l_9019 = &l_9020;
    int32_t l_9027 = 0L;
    uint32_t *l_9028 = &g_1920.f1;
    int16_t ***l_9083 = &g_1030[0][2];
    int64_t **l_9099 = &g_538[2];
    uint16_t l_9108 = 0x2D05L;
    int16_t * const *l_9139 = &g_4510;
    int16_t * const **l_9138[7];
    union U3 **l_9147 = &g_746;
    union U3 ***l_9146[3][5][2] = {{{&l_9147,&l_9147},{&l_9147,&l_9147},{(void*)0,&l_9147},{(void*)0,&l_9147},{(void*)0,(void*)0}},{{&l_9147,&l_9147},{&l_9147,&l_9147},{(void*)0,&l_9147},{&l_9147,&l_9147},{(void*)0,&l_9147}},{{&l_9147,&l_9147},{&l_9147,(void*)0},{(void*)0,&l_9147},{(void*)0,&l_9147},{&l_9147,(void*)0}}};
    union U3 ****l_9145 = &l_9146[2][4][0];
    int64_t l_9172 = 0L;
    uint64_t * const *l_9178 = &g_4583[2];
    uint64_t * const **l_9177 = &l_9178;
    uint64_t * const ***l_9176 = &l_9177;
    uint64_t * const ****l_9175 = &l_9176;
    int16_t ** const ***l_9253 = (void*)0;
    union U2 *l_9280 = &g_9281;
    uint64_t l_9294 = 0xBE7937EE997A41B3LL;
    int16_t l_9343 = (-5L);
    uint8_t l_9350 = 0xBCL;
    int i, j, k;
    for (i = 0; i < 7; i++)
        l_9138[i] = &l_9139;
    for (g_78 = 0; (g_78 <= 13); g_78 = safe_add_func_int8_t_s_s(g_78, 3))
    { /* block id: 29 */
        int8_t l_100[8] = {0x9BL,1L,0x9BL,1L,0x9BL,1L,0x9BL,1L};
        uint32_t *l_157 = &g_66;
        int16_t *l_7221[2][3][10] = {{{&g_5422,&g_5422,&g_2[4][1][2],&g_5422,&g_2[5][0][2],&g_6045,&g_5422,&g_5422,&g_6045,&g_2[5][0][2]},{&g_5422,&g_723,&g_723,&g_5422,(void*)0,&g_4493,&g_5422,&g_723,&g_4493,&g_2[5][0][2]},{&g_4493,&g_5422,&g_723,&g_4493,&g_2[5][0][2],&g_4493,&g_723,&g_5422,&g_4493,(void*)0}},{{&g_5422,&g_5422,&g_2[4][1][2],&g_5422,&g_2[5][0][2],&g_6045,&g_5422,&g_5422,&g_6045,&g_2[5][0][2]},{&g_5422,&g_723,&g_723,&g_5422,(void*)0,&g_4493,&g_5422,&g_723,&g_4493,&g_2[5][0][2]},{&g_4493,&g_5422,&g_723,&g_4493,&g_2[5][0][2],&g_4493,&g_723,&g_5422,&g_4493,(void*)0}}};
        const uint32_t *l_7241 = &g_2791;
        const uint32_t **l_7240 = &l_7241;
        int8_t l_8588 = (-1L);
        int32_t l_8901 = (-1L);
        int i, j, k;
        if (g_7[4][4][0])
            break;
        for (g_38 = 0; g_38 < 8; g_38 += 1)
        {
            l_100[g_38] = 0x80L;
        }
    }
    for (g_951 = 0; (g_951 != (-19)); g_951--)
    { /* block id: 3758 */
        uint32_t l_8929[4] = {0x1AFB2433L,0x1AFB2433L,0x1AFB2433L,0x1AFB2433L};
        int8_t *l_8940[3][1];
        int16_t l_8965[10] = {5L,5L,5L,5L,5L,5L,5L,5L,5L,5L};
        int8_t l_8993 = 0xDAL;
        int32_t l_8994 = 0L;
        int32_t l_9056 = 0x92B9715DL;
        uint16_t l_9057[9] = {65535UL,0UL,65535UL,65535UL,0UL,65535UL,65535UL,0UL,65535UL};
        int32_t l_9063 = 0L;
        int32_t l_9064[9];
        int8_t l_9066 = 0xE0L;
        union U4 ****l_9088 = &g_6523;
        int64_t ** const *l_9105 = &g_6440;
        int64_t ** const **l_9104 = &l_9105;
        int16_t ***l_9137[8][2] = {{&g_1030[0][5],&g_1030[0][5]},{&g_1030[0][5],&g_1030[0][5]},{&g_1030[0][5],&g_1030[0][5]},{&g_1030[0][5],&g_1030[0][5]},{&g_1030[0][5],&g_1030[0][5]},{&g_1030[0][5],&g_1030[0][5]},{&g_1030[0][5],&g_1030[0][5]},{&g_1030[0][5],&g_1030[0][5]}};
        int16_t * const **l_9141[1];
        int64_t ****l_9190[3];
        int64_t *****l_9189 = &l_9190[0];
        uint64_t *** const *l_9191 = &g_3682;
        int32_t *l_9264 = &l_9063;
        union U2 *l_9278 = &g_9279;
        int16_t l_9292[2];
        int8_t l_9293[10][1] = {{(-1L)},{(-1L)},{0xF3L},{(-1L)},{(-1L)},{0xF3L},{(-1L)},{(-1L)},{0xF3L},{(-1L)}};
        int8_t l_9295 = 0xAEL;
        uint32_t * const l_9310 = &g_9311;
        uint32_t * const *l_9309 = &l_9310;
        uint32_t * const **l_9308 = &l_9309;
        uint8_t ***l_9313 = &g_4139;
        int32_t *l_9314[2];
        int i, j;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 1; j++)
                l_8940[i][j] = &g_4118[2];
        }
        for (i = 0; i < 9; i++)
            l_9064[i] = (-9L);
        for (i = 0; i < 1; i++)
            l_9141[i] = &l_9139;
        for (i = 0; i < 3; i++)
            l_9190[i] = (void*)0;
        for (i = 0; i < 2; i++)
            l_9292[i] = (-6L);
        for (i = 0; i < 2; i++)
            l_9314[i] = &l_9064[2];
    }
    l_7242 = (safe_lshift_func_int16_t_s_s((l_9172 , ((l_9172 ^ (l_9172 != ((*g_715) |= (safe_mod_func_int32_t_s_s((safe_lshift_func_uint16_t_u_s(0x93EFL, (safe_mul_func_uint8_t_u_u(((l_9172 & ((safe_sub_func_int16_t_s_s((l_149[2] | l_149[9]), (safe_rshift_func_int8_t_s_s(((safe_lshift_func_uint8_t_u_s((&l_9083 == (*g_1674)), l_9294)) && l_9027), 0)))) < (**g_1540))) && l_9108), (**g_5410))))), 4294967295UL))))) & 0x42L)), (*p_88)));
    for (g_4882 = (-26); (g_4882 <= 24); g_4882 = safe_add_func_int8_t_s_s(g_4882, 9))
    { /* block id: 3909 */
        int8_t *l_9333 = (void*)0;
        uint32_t *l_9336 = &g_7160[0];
        const int32_t l_9351 = 0x4C354E59L;
        int32_t l_9352 = 0x6EE6AF02L;
        int32_t l_9353 = 0x4022B762L;
        union U5 *l_9375 = &g_9376;
        (****g_2717) = &l_149[2];
        (****g_2718) |= ((safe_rshift_func_int16_t_s_s((safe_lshift_func_uint8_t_u_s(9UL, (safe_mod_func_int8_t_s_s((safe_rshift_func_int16_t_s_s(((((((l_9350 >= (safe_div_func_int16_t_s_s((safe_sub_func_uint8_t_u_u(((*g_6119) || ((!(+(safe_unary_minus_func_uint8_t_u((safe_mod_func_int32_t_s_s((safe_mul_func_uint8_t_u_u((safe_rshift_func_int8_t_s_s(((&g_5128 != (void*)0) >= ((void*)0 != l_9375)), (0x9DL || (l_9294 & l_9353)))), (**g_4423))), g_9377[5][1][0])))))) , l_9351)), l_9353)), l_9351))) , l_9352) || l_9294) == l_9350) <= l_9353) > l_9353), 3)), l_9351)))), 6)) > l_9108);
    }
    return (**g_4422);
}


/* ------------------------------------------ */
/* 
 * reads : g_1540 g_1541 g_998
 * writes:
 */
static uint64_t  func_101(int32_t * p_102, uint8_t  p_103, const uint32_t  p_104, const int8_t * p_105, int8_t * const  p_106)
{ /* block id: 3752 */
    return (**g_1540);
}


/* ------------------------------------------ */
/* 
 * reads : g_4423 g_28 g_5749 g_1419 g_656 g_657 g_8235 g_5490 g_836 g_837 g_8526 g_8527 g_66 g_232 g_1446 g_4087 g_7825.f0 g_3307 g_4118 g_3260 g_3261 g_3071 g_29 g_715 g_466 g_1541 g_998 g_4151 g_1540 g_3302 g_2717 g_2718 g_2719 g_1207 g_7 g_1675 g_1676 g_1677 g_1678 g_1674 g_4493 g_4422 g_4510 g_5127 g_5128 g_4139 g_5411 g_6240 g_4088 g_604 g_653 g_446 g_1020
 * writes: g_232 g_3307 g_4095 g_3302 g_1396 g_3070 g_4139 g_1446 g_7825.f0 g_653 g_951 g_657 g_3870 g_6240
 */
static int32_t * func_107(const uint32_t * p_108, const int16_t * p_109, uint32_t  p_110, int8_t  p_111, int16_t  p_112)
{ /* block id: 3742 */
    const int16_t *l_8858 = (void*)0;
    int32_t l_8863 = 0xCA386A91L;
    int8_t *l_8870 = &g_2886;
    int64_t *l_8871 = &g_7825.f0;
    struct S0 **l_8886 = &g_6240;
    int32_t l_8897 = 1L;
    int32_t l_8898 = 0x6A2D76BAL;
    uint32_t l_8899 = 0x7B95DD44L;
    (****g_2717) = func_132((*g_4423), l_8858, p_112, func_223(((((safe_sub_func_uint8_t_u_u(((((4294967292UL == (safe_mul_func_int8_t_s_s(((*g_5749) , (((l_8863 || (safe_lshift_func_uint8_t_u_s((((p_111 > l_8863) < ((safe_mod_func_uint8_t_u_u((*g_656), (*g_8235))) < l_8863)) , (*g_656)), (*g_8235)))) , p_108) == (*g_836))), 0xC0L))) , (*g_8526)) == (void*)0) <= (*p_108)), p_112)) <= l_8863) , l_8863) && l_8863), p_111, l_8870, l_8871, l_8863));
    l_8898 = (l_8897 |= (safe_mod_func_int16_t_s_s((l_8863 = (safe_lshift_func_uint8_t_u_u(((*g_5411) = ((**g_4139) = (safe_add_func_uint8_t_u_u((0xCEL || 0L), l_8863)))), (((safe_div_func_uint64_t_u_u((safe_mod_func_uint16_t_u_u((((((((safe_sub_func_int64_t_s_s(p_110, ((((*p_109) , ((*l_8886) = g_6240)) != ((safe_lshift_func_int16_t_s_u(((safe_mul_func_uint8_t_u_u(((0xA557C980L && (((((safe_div_func_int64_t_s_s(((safe_lshift_func_int16_t_s_u((l_8863 , (safe_mod_func_int64_t_s_s(0L, 18446744073709551607UL))), p_112)) && 18446744073709551606UL), l_8863)) <= 65535UL) < p_110) != 0L) <= l_8863)) >= p_112), p_111)) > 0xBE2026DCL), l_8863)) , (void*)0)) || (*p_108)))) | l_8863) , 0L) , (**g_4087)) , p_110) , p_111) | 0xF038L), 0x71A8L)), p_112)) & l_8863) , 0x06L)))), (*****g_1674))));
    l_8899 = (-6L);
    return (****g_2717);
}


/* ------------------------------------------ */
/* 
 * reads : g_1674 g_1675 g_1676 g_1677 g_1678
 * writes:
 */
static const int16_t * func_114(int32_t  p_115, uint8_t  p_116, uint32_t * p_117, int32_t * p_118, uint32_t * p_119)
{ /* block id: 3617 */
    int16_t l_8590 = 0x330CL;
    int32_t l_8591 = 0x9D7F89CEL;
    int32_t l_8592 = 0x7CC54D25L;
    int32_t l_8593[5] = {3L,3L,3L,3L,3L};
    int32_t *l_8594 = (void*)0;
    int32_t *l_8595 = &g_3307;
    int32_t *l_8596 = &g_499[0][0];
    int32_t *l_8597 = &g_3420[2];
    int32_t *l_8598 = (void*)0;
    int32_t *l_8599 = &l_8593[3];
    int32_t *l_8600 = &l_8592;
    int32_t *l_8601 = &l_8591;
    int32_t *l_8602 = &g_4882;
    int32_t *l_8603 = (void*)0;
    int32_t *l_8604 = (void*)0;
    int32_t *l_8605 = &g_499[0][0];
    int32_t *l_8606 = &l_8591;
    int32_t *l_8607 = &l_8592;
    int32_t *l_8608 = (void*)0;
    int32_t *l_8609 = &l_8591;
    int32_t *l_8610 = &l_8592;
    int32_t *l_8611 = &l_8593[2];
    int32_t *l_8612 = (void*)0;
    int32_t *l_8613[10] = {(void*)0,&g_3,&g_7[2][5][1],&g_3,(void*)0,(void*)0,&g_3,&g_7[2][5][1],&g_3,(void*)0};
    uint8_t l_8614 = 0x95L;
    int64_t ** const *l_8620 = &g_6440;
    uint32_t ****l_8652[5];
    uint32_t *****l_8651[4][2][4] = {{{&l_8652[2],&l_8652[0],&l_8652[2],&l_8652[0]},{&l_8652[2],&l_8652[0],&l_8652[2],&l_8652[0]}},{{&l_8652[2],&l_8652[0],&l_8652[2],&l_8652[0]},{&l_8652[2],&l_8652[0],&l_8652[2],&l_8652[0]}},{{&l_8652[2],&l_8652[0],&l_8652[2],&l_8652[0]},{&l_8652[2],&l_8652[0],&l_8652[2],&l_8652[0]}},{{&l_8652[2],&l_8652[0],&l_8652[2],&l_8652[0]},{&l_8652[2],&l_8652[0],&l_8652[2],&l_8652[0]}}};
    union U3 *l_8655 = &g_8656;
    union U5 *l_8660 = &g_8661;
    uint16_t l_8778 = 0xDEF0L;
    int32_t l_8814 = 0L;
    uint64_t ****l_8823 = &g_3682;
    int16_t l_8837 = 0x2972L;
    const union U2 *l_8838 = &g_8839;
    uint8_t **l_8850[5];
    const int16_t *l_8857 = &l_8837;
    int i, j, k;
    for (i = 0; i < 5; i++)
        l_8652[i] = &g_3250[3];
    for (i = 0; i < 5; i++)
        l_8850[i] = &g_5411;
    ++l_8614;
    return (****g_1674);
}


/* ------------------------------------------ */
/* 
 * reads : g_7254 g_7256 g_1678 g_232 g_28 g_29 g_4096 g_4097 g_1396
 * writes: g_7254 g_7269 g_1396
 */
static int32_t  func_125(int32_t * p_126, uint32_t  p_127, int8_t * p_128, int32_t  p_129)
{ /* block id: 3071 */
    int32_t l_7250 = 0L;
    uint64_t l_7253 = 0xBC9D055C8D2AFA0FLL;
    int32_t l_7255 = 1L;
    int32_t l_7257 = (-9L);
    uint16_t ***l_7258 = &g_714;
    uint32_t ***l_7259 = &g_929;
    int32_t ***** const l_7268[5] = {&g_2718,&g_2718,&g_2718,&g_2718,&g_2718};
    int64_t l_7270 = (-5L);
    uint32_t l_7271 = 0x538CE2DFL;
    int32_t l_7294 = (-1L);
    int64_t l_7295[4][1];
    int64_t l_7296 = (-1L);
    uint32_t l_7303[4];
    int16_t *l_7304 = (void*)0;
    int16_t l_7438 = 0x5D6AL;
    uint64_t l_7439[7][3] = {{0xAD65CFDD2B56DA94LL,0UL,0xAD65CFDD2B56DA94LL},{0x0D000B559D610FB5LL,18446744073709551615UL,0x0D000B559D610FB5LL},{0xAD65CFDD2B56DA94LL,0UL,0xAD65CFDD2B56DA94LL},{0x0D000B559D610FB5LL,18446744073709551615UL,0x0D000B559D610FB5LL},{0xAD65CFDD2B56DA94LL,0UL,0xAD65CFDD2B56DA94LL},{0x0D000B559D610FB5LL,18446744073709551615UL,0x0D000B559D610FB5LL},{0xAD65CFDD2B56DA94LL,0UL,0xAD65CFDD2B56DA94LL}};
    struct S1 **l_7458 = &g_7095;
    int32_t **l_7466 = &g_4097;
    union U4 ** const **l_7490 = (void*)0;
    const uint32_t *l_7502 = &g_66;
    const uint32_t **l_7501 = &l_7502;
    const uint32_t ***l_7500 = &l_7501;
    const uint32_t ****l_7499 = &l_7500;
    uint8_t ***l_7569 = &g_4139;
    uint8_t ****l_7568 = &l_7569;
    uint8_t *****l_7567[5];
    union U3 **l_7573 = &g_746;
    union U3 ***l_7572 = &l_7573;
    union U3 ****l_7571 = &l_7572;
    int8_t *l_7632 = &g_1621[5];
    uint64_t l_7657 = 0x3EFDE07D20D79F78LL;
    const uint8_t l_7691[6][8] = {{0x19L,7UL,255UL,7UL,0x19L,0x15L,250UL,0x4CL},{7UL,0x99L,0xF5L,255UL,255UL,0xF5L,0x99L,7UL},{0x5DL,0x15L,0xF5L,0x63L,250UL,0x19L,250UL,0x63L},{255UL,0x81L,255UL,0x4CL,0x63L,0x19L,0xF5L,0xF5L},{0xF5L,0x15L,0x5DL,0x5DL,0x15L,0xF5L,0x63L,250UL},{0xF5L,0x99L,7UL,0x15L,0x63L,0x15L,7UL,0x99L}};
    int16_t l_7787 = 1L;
    struct S1 ***l_7923 = (void*)0;
    uint64_t ** const l_7975[2] = {&g_4583[4],&g_4583[4]};
    const uint64_t *l_7977 = &g_4338;
    const uint64_t **l_7976 = &l_7977;
    int8_t l_7986 = 0xCCL;
    int32_t ****l_8023 = &g_2719[0][1];
    struct S0 * const * const l_8070 = &g_6240;
    union U2 *l_8097 = &g_8098;
    uint32_t l_8192 = 1UL;
    int64_t ***l_8218 = &g_6440;
    uint32_t *l_8239 = &g_8037.f1;
    int16_t l_8468[4] = {0x68E0L,0x68E0L,0x68E0L,0x68E0L};
    int32_t *l_8472 = (void*)0;
    uint64_t ****l_8511 = &g_3682;
    uint64_t *****l_8510[5] = {&l_8511,&l_8511,&l_8511,&l_8511,&l_8511};
    int32_t l_8516 = 0xE27C2453L;
    union U5 * volatile * volatile * volatile **l_8530 = &g_8527;
    int16_t *l_8556 = (void*)0;
    int i, j;
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 1; j++)
            l_7295[i][j] = 1L;
    }
    for (i = 0; i < 4; i++)
        l_7303[i] = 4294967295UL;
    for (i = 0; i < 5; i++)
        l_7567[i] = &l_7568;
    l_7257 = (safe_add_func_int16_t_s_s((safe_lshift_func_int8_t_s_u((((safe_mul_func_int16_t_s_s(0xE4F1L, ((((!l_7250) && (safe_lshift_func_uint8_t_u_u(l_7250, 4))) , (l_7253 >= ((g_7254 &= l_7250) <= ((l_7255 = (*p_128)) > 0x01L)))) >= (*p_128)))) == l_7253) != 0xCBL), g_7256)), 0x1DEBL));
    p_129 = (((**g_4096) |= ((l_7258 != ((((void*)0 != l_7259) < ((safe_add_func_int64_t_s_s((safe_add_func_uint16_t_u_u(((safe_lshift_func_int16_t_s_u((p_129 , l_7250), 2)) == ((((safe_div_func_uint16_t_u_u(0UL, l_7257)) == (g_7269 = (&g_2037 != l_7268[0]))) , l_7270) < (-3L))), (*g_1678))), p_127)) != (-7L))) , (void*)0)) | (*g_28))) , p_127);
    l_7271++;
    return p_127;
}


/* ------------------------------------------ */
/* 
 * reads : g_4118 g_7088 g_5127 g_5128 g_29 l_100 g_1621
 * writes:
 */
static uint32_t * func_132(int8_t * p_133, const int16_t * p_134, uint32_t  p_135, int16_t * p_136)
{ /* block id: 3067 */
    uint64_t * const *l_7230[6][5][2] = {{{&g_4583[4],(void*)0},{(void*)0,(void*)0},{&g_1541,&g_4583[2]},{&g_4583[4],(void*)0},{&g_4583[4],&g_1541}},{{&g_1541,&g_4583[4]},{&g_4583[1],(void*)0},{&g_4583[1],&g_4583[4]},{&g_1541,&g_1541},{&g_4583[4],(void*)0}},{{&g_4583[4],&g_4583[2]},{&g_1541,(void*)0},{(void*)0,(void*)0},{&g_4583[4],&g_4583[1]},{&g_1541,&g_4583[4]}},{{&g_1541,(void*)0},{&g_1541,&g_4583[4]},{&g_1541,&g_1541},{&g_4583[4],(void*)0},{&g_4583[2],&g_4583[4]}},{{&g_1541,&g_4583[4]},{&g_4583[2],(void*)0},{&g_4583[4],&g_1541},{&g_1541,&g_4583[4]},{&g_1541,(void*)0}},{{&g_1541,&g_4583[4]},{&g_1541,&g_4583[1]},{&g_4583[4],(void*)0},{(void*)0,(void*)0},{&g_1541,&g_4583[2]}}};
    uint64_t * const **l_7229 = &l_7230[2][3][0];
    uint64_t * const ***l_7228 = &l_7229;
    const int32_t l_7231 = 0x7ADA24BCL;
    union U2 *l_7235 = &g_7236;
    union U2 **l_7234 = &l_7235;
    const int64_t l_7237 = 3L;
    int32_t l_7238[8][7] = {{0x65D83876L,0x65D83876L,0xE89431DDL,0xE89431DDL,0x65D83876L,0x65D83876L,0xE89431DDL},{2L,0x33A0DBF0L,2L,0x33A0DBF0L,2L,0x33A0DBF0L,2L},{0x65D83876L,0xE89431DDL,0xE89431DDL,0x65D83876L,0x65D83876L,0xE89431DDL,0xE89431DDL},{1L,0x33A0DBF0L,1L,0x33A0DBF0L,1L,0x33A0DBF0L,1L},{0x65D83876L,0x65D83876L,0xE89431DDL,0xE89431DDL,0x65D83876L,0x65D83876L,0xE89431DDL},{2L,0x33A0DBF0L,2L,0x33A0DBF0L,2L,0x33A0DBF0L,2L},{0x65D83876L,0xE89431DDL,0xE89431DDL,0x65D83876L,0x65D83876L,0xE89431DDL,0xE89431DDL},{1L,0x33A0DBF0L,1L,0x33A0DBF0L,1L,0x33A0DBF0L,1L}};
    uint32_t *l_7239 = (void*)0;
    int i, j, k;
    l_7238[4][3] = ((safe_sub_func_int64_t_s_s(((safe_mul_func_uint8_t_u_u((safe_lshift_func_int8_t_s_s(0x7AL, 0)), (p_135 , (*p_133)))) <= (5L & (((*g_5127) == l_7228) > l_7231))), (safe_add_func_int32_t_s_s((((l_7231 , ((void*)0 != l_7234)) , 0x90L) <= 0xF5L), p_135)))) , l_7237);
    return l_7239;
}


/* ------------------------------------------ */
/* 
 * reads : g_2718 g_2719 g_1207 g_499 g_5749 g_1419 g_6348 g_28 g_29 g_7195 g_5746 g_5747 g_5407 g_5408 g_5409 g_5410 g_5411 g_929 g_930 g_446 g_66 g_6523 g_2302 g_7217 g_4882
 * writes: g_653 g_6348 g_4118 g_499 g_3870 g_4882
 */
static int8_t * func_137(uint32_t * p_138)
{ /* block id: 3012 */
    union U3 *l_7101 = (void*)0;
    union U3 **l_7102[8] = {&g_746,&g_746,(void*)0,&g_746,&g_746,(void*)0,&g_746,&g_746};
    union U3 *l_7103 = &g_7104;
    int32_t *l_7105 = &g_499[0][0];
    int64_t **l_7108 = &g_538[2];
    int32_t l_7127[10][7] = {{0L,(-1L),1L,0x90390C55L,(-8L),0xDF6EC4F6L,0xCE7FC545L},{0L,(-8L),1L,0x8B1750D8L,1L,0L,0L},{0L,(-1L),0xFFED65D3L,(-1L),0L,0L,0xCE7FC545L},{0L,6L,0xEED7DC56L,(-1L),1L,0xDF6EC4F6L,0x7A16519AL},{1L,6L,0xFFED65D3L,0x8B1750D8L,(-8L),0xCE7FC545L,0x7A16519AL},{0L,(-1L),1L,0x90390C55L,(-8L),0xDF6EC4F6L,0xCE7FC545L},{0L,(-8L),1L,0x8B1750D8L,1L,0L,0L},{0L,(-1L),0xFFED65D3L,(-1L),0L,0L,0xCE7FC545L},{0L,6L,0xEED7DC56L,(-1L),1L,0xDF6EC4F6L,0x7A16519AL},{1L,6L,0xFFED65D3L,0x8B1750D8L,(-8L),0xCE7FC545L,0x7A16519AL}};
    uint16_t **l_7181[4][7][5] = {{{&g_715,(void*)0,&g_715,(void*)0,(void*)0},{&g_715,&g_715,&g_715,&g_715,&g_715},{&g_715,&g_715,&g_715,(void*)0,&g_715},{(void*)0,(void*)0,&g_715,(void*)0,&g_715},{(void*)0,(void*)0,&g_715,&g_715,&g_715},{&g_715,(void*)0,(void*)0,&g_715,&g_715},{(void*)0,&g_715,(void*)0,&g_715,&g_715}},{{(void*)0,&g_715,&g_715,&g_715,(void*)0},{&g_715,(void*)0,&g_715,&g_715,&g_715},{&g_715,&g_715,&g_715,(void*)0,(void*)0},{(void*)0,&g_715,(void*)0,&g_715,&g_715},{&g_715,&g_715,(void*)0,&g_715,&g_715},{&g_715,&g_715,&g_715,&g_715,&g_715},{&g_715,(void*)0,&g_715,&g_715,&g_715}},{{&g_715,&g_715,&g_715,&g_715,&g_715},{(void*)0,&g_715,&g_715,&g_715,(void*)0},{&g_715,&g_715,&g_715,&g_715,&g_715},{&g_715,(void*)0,&g_715,&g_715,&g_715},{(void*)0,&g_715,&g_715,&g_715,&g_715},{(void*)0,&g_715,&g_715,&g_715,&g_715},{&g_715,(void*)0,&g_715,&g_715,(void*)0}},{{&g_715,(void*)0,&g_715,&g_715,&g_715},{&g_715,(void*)0,&g_715,(void*)0,&g_715},{&g_715,&g_715,&g_715,&g_715,&g_715},{&g_715,&g_715,(void*)0,(void*)0,&g_715},{&g_715,&g_715,&g_715,&g_715,&g_715},{&g_715,(void*)0,(void*)0,(void*)0,&g_715},{&g_715,&g_715,&g_715,(void*)0,&g_715}}};
    uint64_t * const **l_7193 = (void*)0;
    int8_t *l_7220 = &g_7088;
    int i, j, k;
    l_7103 = l_7101;
lbl_7113:
    (***g_2718) = l_7105;
    if ((*l_7105))
    { /* block id: 3015 */
        int64_t **l_7109 = &g_6119;
        int32_t l_7110 = 0x0F2BAD3BL;
        int8_t *l_7114 = &g_4118[2];
        int32_t l_7142 = (-10L);
        int32_t l_7146[2];
        int16_t l_7192 = 0x19B9L;
        const uint32_t l_7194 = 0x6212593EL;
        int i;
        for (i = 0; i < 2; i++)
            l_7146[i] = 1L;
        if (((-9L) < ((safe_div_func_uint16_t_u_u((l_7110 = ((*g_5749) , ((l_7109 = l_7108) == (void*)0))), (safe_rshift_func_uint16_t_u_s(65535UL, 8)))) && l_7110)))
        { /* block id: 3018 */
            if (l_7110)
                goto lbl_7113;
            return l_7114;
        }
        else
        { /* block id: 3021 */
            int32_t l_7139 = (-1L);
            int32_t l_7143 = 0xEE26C749L;
            union U2 *l_7175 = &g_7176;
            union U2 ** const l_7174 = &l_7175;
            uint16_t **l_7182 = &g_715;
            int32_t l_7183 = 0x9A0B71C1L;
            for (g_6348 = (-10); (g_6348 <= 13); ++g_6348)
            { /* block id: 3024 */
                uint32_t l_7120[7];
                int32_t l_7132 = 0L;
                int32_t l_7144 = 0xC9D8B648L;
                int32_t l_7145 = 1L;
                uint64_t l_7148 = 0x62F2886FC826987BLL;
                struct S1 *l_7184 = &g_7185;
                int i;
                for (i = 0; i < 7; i++)
                    l_7120[i] = 18446744073709551615UL;
            }
        }
        if (((((safe_sub_func_int32_t_s_s((*l_7105), (((246UL > (*g_28)) && (safe_sub_func_uint64_t_u_u((safe_mod_func_uint64_t_u_u((l_7192 != ((((((((void*)0 != l_7193) , (l_7110 , (((*l_7114) = (l_7194 && (l_7194 > (*l_7105)))) , g_7195))) == (void*)0) , l_7146[0]) > 0x47C2L) == 0x989521E4BB558768LL) && (*g_28))), (*l_7105))), l_7110))) , 1UL))) >= l_7146[0]) == 1UL) >= (*l_7105)))
        { /* block id: 3053 */
            (*l_7105) = 0x8814FF5CL;
        }
        else
        { /* block id: 3055 */
            (*g_1207) = p_138;
        }
    }
    else
    { /* block id: 3058 */
        uint32_t l_7200 = 0x931ED854L;
        int32_t l_7210 = 0xA6FBC0A0L;
        union U4 **l_7211 = &g_1168[6];
        struct S1 **l_7214 = &g_7095;
        union U4 ** const l_7218 = &g_1168[9];
        int32_t *l_7219 = &g_4882;
        l_7210 = ((((*l_7105) ^ ((!l_7200) < ((*g_5746) != (void*)0))) >= ((safe_rshift_func_int8_t_s_s((l_7200 > (0UL || (safe_rshift_func_uint8_t_u_u(((*****g_5407) = ((safe_mod_func_int32_t_s_s((safe_div_func_uint16_t_u_u(((*l_7105) , (!5UL)), 0x60A6L)), 7UL)) , 0xADL)), (*l_7105))))), (*l_7105))) , (**g_929))) , (*l_7105));
        (*l_7219) ^= ((l_7211 = (*g_6523)) == ((safe_add_func_int16_t_s_s(((0x0F406DB4L >= (l_7200 ^ (((void*)0 != l_7214) >= 0UL))) == 0xD9093A81L), ((safe_rshift_func_int16_t_s_s(((*l_7105) ^= (l_7200 , (l_7200 >= 0x69261279L))), g_7217[0][1])) <= 0x184F75F1L))) , l_7218));
        return l_7220;
    }
    return l_7220;
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_38 g_29 g_28 g_188 g_163 g_929 g_930 g_446 g_66 g_2718 g_2719 g_1207 g_653 g_2717 g_499 g_714 g_715 g_466 g_1396 g_1675 g_1676 g_1674 g_4422 g_4423 g_2386.f0 g_5407 g_5408 g_5409 g_5410 g_5411 g_3870 g_656 g_657 g_1678 g_232 g_538 g_539 g_1677 g_3477 g_3420 g_6006 g_6045 g_328 g_748 g_3142.f1 g_6145 g_5749 g_1419 g_1541 g_998 g_6229 g_6119 g_845 g_6233 g_6256 g_6270 g_3566 g_3567 g_4139 g_3250 g_5490 g_260 g_6240 g_6833 g_1540 g_6580.f3 g_6586.f3 g_255 g_1920.f1 g_4088 g_5048.f0 g_6587.f3 g_7076 g_7095 g_1550 g_2170 g_4338 g_3643
 * writes: g_38 g_66 g_188 g_163 g_4118 g_499 g_466 g_1396 g_2386.f0 g_653 g_657 g_3870 g_539 g_196 g_3529.f0 g_746 g_748 g_446 g_232 g_538 g_6119 g_1470 g_1550 g_6229 g_3420 g_6240 g_6256 g_2170 g_6270 g_857 g_1621 g_2302 g_845 g_2482 g_4087 g_1273 g_4302 g_5044.f0 g_5490 g_260 g_6439 g_4338 g_6580.f3 g_6586.f3 g_1217 g_998 g_255 g_1920.f1 g_5048.f0 g_6587.f3 g_7088 g_7095 g_3643
 */
static uint32_t * func_139(const int32_t  p_140)
{ /* block id: 36 */
    int8_t *l_158[8][5] = {{&g_29,&g_29,&g_29,&g_29,&g_29},{(void*)0,&g_29,(void*)0,&g_29,(void*)0},{&g_29,&g_29,&g_29,&g_29,&g_29},{(void*)0,&g_29,(void*)0,&g_29,(void*)0},{&g_29,&g_29,&g_29,&g_29,&g_29},{(void*)0,&g_29,(void*)0,&g_29,(void*)0},{&g_29,&g_29,&g_29,&g_29,&g_29},{(void*)0,&g_29,(void*)0,&g_29,(void*)0}};
    int32_t *l_159 = &g_38;
    int32_t l_5893 = 1L;
    union U4 ***l_5946[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int32_t *****l_5978 = (void*)0;
    uint16_t l_5982 = 0x1498L;
    const int16_t * const *l_5991[7] = {&g_1678,&g_1678,&g_1678,&g_1678,&g_1678,&g_1678,&g_1678};
    const int16_t * const **l_5990 = &l_5991[2];
    const int16_t * const ** const *l_5989[1][9] = {{&l_5990,&l_5990,&l_5990,&l_5990,&l_5990,&l_5990,&l_5990,&l_5990,&l_5990}};
    int32_t l_5993 = 0x3FF68A29L;
    uint32_t l_6000 = 18446744073709551608UL;
    uint16_t l_6002 = 0xCC8BL;
    uint32_t ****l_6039[10][7][3] = {{{&g_3250[9],&g_3250[1],&g_3250[8]},{&g_3250[8],(void*)0,&g_3250[8]},{&g_3250[2],&g_3250[8],(void*)0},{&g_3250[2],&g_3250[8],&g_3250[8]},{(void*)0,&g_3250[8],&g_3250[8]},{(void*)0,&g_3250[5],&g_3250[3]},{(void*)0,&g_3250[8],&g_3250[8]}},{{(void*)0,&g_3250[9],&g_3250[0]},{&g_3250[2],&g_3250[2],&g_3250[8]},{&g_3250[2],&g_3250[9],&g_3250[8]},{&g_3250[8],&g_3250[8],(void*)0},{&g_3250[9],&g_3250[5],(void*)0},{&g_3250[1],&g_3250[8],&g_3250[8]},{&g_3250[3],&g_3250[8],&g_3250[8]}},{{&g_3250[5],&g_3250[8],&g_3250[0]},{&g_3250[3],(void*)0,&g_3250[8]},{&g_3250[1],&g_3250[1],&g_3250[3]},{&g_3250[9],&g_3250[1],&g_3250[8]},{&g_3250[8],(void*)0,&g_3250[8]},{&g_3250[2],&g_3250[8],(void*)0},{&g_3250[2],&g_3250[8],&g_3250[8]}},{{(void*)0,&g_3250[8],&g_3250[8]},{(void*)0,&g_3250[5],&g_3250[3]},{(void*)0,&g_3250[8],&g_3250[8]},{(void*)0,&g_3250[9],&g_3250[0]},{&g_3250[2],&g_3250[2],&g_3250[8]},{&g_3250[2],&g_3250[9],&g_3250[8]},{&g_3250[8],&g_3250[8],(void*)0}},{{&g_3250[9],&g_3250[5],(void*)0},{&g_3250[1],&g_3250[8],&g_3250[8]},{&g_3250[8],&g_3250[9],(void*)0},{&g_3250[8],&g_3250[9],&g_3250[9]},{&g_3250[8],&g_3250[0],&g_3250[5]},{&g_3250[8],&g_3250[8],&g_3250[8]},{&g_3250[2],&g_3250[8],(void*)0}},{{&g_3250[9],&g_3250[0],&g_3250[2]},{&g_3250[8],&g_3250[9],&g_3250[3]},{(void*)0,&g_3250[9],&g_3250[2]},{&g_3250[8],(void*)0,(void*)0},{&g_3250[1],&g_3250[8],&g_3250[8]},{&g_3250[1],&g_3250[9],&g_3250[5]},{&g_3250[8],&g_3250[2],&g_3250[9]}},{{(void*)0,&g_3250[8],(void*)0},{&g_3250[8],&g_3250[2],&g_3250[8]},{&g_3250[9],&g_3250[9],&g_3250[8]},{&g_3250[2],&g_3250[8],&g_3250[8]},{&g_3250[8],(void*)0,&g_3250[8]},{&g_3250[8],&g_3250[9],(void*)0},{&g_3250[8],&g_3250[9],&g_3250[9]}},{{&g_3250[8],&g_3250[0],&g_3250[5]},{&g_3250[8],&g_3250[8],&g_3250[8]},{&g_3250[2],&g_3250[8],(void*)0},{&g_3250[9],&g_3250[0],&g_3250[2]},{&g_3250[8],&g_3250[9],&g_3250[3]},{(void*)0,&g_3250[9],&g_3250[2]},{&g_3250[8],(void*)0,(void*)0}},{{&g_3250[1],&g_3250[8],&g_3250[8]},{&g_3250[1],&g_3250[9],&g_3250[5]},{&g_3250[8],&g_3250[2],&g_3250[9]},{(void*)0,&g_3250[8],(void*)0},{&g_3250[8],&g_3250[2],&g_3250[8]},{&g_3250[9],&g_3250[9],&g_3250[8]},{&g_3250[2],&g_3250[8],&g_3250[8]}},{{&g_3250[8],(void*)0,&g_3250[8]},{&g_3250[8],&g_3250[9],(void*)0},{&g_3250[8],&g_3250[9],&g_3250[9]},{&g_3250[8],&g_3250[0],&g_3250[5]},{&g_3250[8],&g_3250[8],&g_3250[8]},{&g_3250[2],&g_3250[8],(void*)0},{&g_3250[9],&g_3250[0],&g_3250[2]}}};
    int32_t l_6140 = 1L;
    int32_t l_6141 = 0x28578FA3L;
    int32_t l_6162 = (-1L);
    int32_t l_6163 = (-1L);
    struct S0 *l_6239 = (void*)0;
    int32_t l_6248 = 1L;
    int32_t l_6249 = 0L;
    int32_t l_6250 = 0x59DD5915L;
    int32_t l_6251[1];
    uint32_t l_6252 = 4294967295UL;
    int32_t *l_6283[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int64_t *l_6308[1];
    const uint64_t l_6357 = 0x3C0AB8FBA58FDC6FLL;
    uint32_t l_6401[7] = {0x41EE11F6L,0x41EE11F6L,0x41EE11F6L,0x41EE11F6L,0x41EE11F6L,0x41EE11F6L,0x41EE11F6L};
    int8_t ***l_6423 = (void*)0;
    uint64_t ****l_6460 = &g_3682;
    uint32_t l_6494[9][1] = {{0xB901C7A3L},{0xB40E8CDBL},{0xB40E8CDBL},{0xB901C7A3L},{0xB40E8CDBL},{0xB40E8CDBL},{0xB901C7A3L},{0xB40E8CDBL},{0xB40E8CDBL}};
    uint16_t l_6495 = 65534UL;
    struct S1 * const l_6543 = &g_6544;
    struct S1 * const *l_6542 = &l_6543;
    struct S1 * const **l_6541[1];
    int16_t l_6615 = 0x62CCL;
    int32_t l_6657 = 1L;
    int32_t l_6662 = 0L;
    uint64_t l_6672 = 0UL;
    uint16_t *** const l_6779 = &g_714;
    uint16_t *** const *l_6778 = &l_6779;
    uint16_t *** const **l_6777 = &l_6778;
    int32_t l_6780 = 0xA2D3B8B1L;
    union U3 **l_6829[6][3] = {{&g_746,&g_746,&g_746},{(void*)0,(void*)0,(void*)0},{&g_746,&g_746,&g_746},{&g_746,(void*)0,&g_746},{(void*)0,&g_746,&g_746},{&g_746,&g_746,(void*)0}};
    union U3 ***l_6828 = &l_6829[1][2];
    union U3 ****l_6827 = &l_6828;
    uint16_t l_6925 = 0x3AC9L;
    int32_t ** const *l_7043 = (void*)0;
    int32_t ** const **l_7042[2];
    int32_t ** const ***l_7041 = &l_7042[0];
    uint64_t l_7058 = 0xC96E8E232F1FBD7BLL;
    int32_t l_7084 = 0xB158488AL;
    uint64_t l_7086 = 0x7AB6DB433F0AD2ADLL;
    uint8_t l_7089 = 253UL;
    struct S1 ****l_7093 = &g_6229;
    struct S1 *****l_7092 = &l_7093;
    uint32_t *l_7100[9] = {&g_5485,&g_5485,&g_5485,&g_5485,&g_5485,&g_5485,&g_5485,&g_5485,&g_5485};
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_6251[i] = 0x797F8F6EL;
    for (i = 0; i < 1; i++)
        l_6308[i] = &g_3792.f0;
    for (i = 0; i < 1; i++)
        l_6541[i] = &l_6542;
    for (i = 0; i < 2; i++)
        l_7042[i] = &l_7043;
lbl_6875:
    (*l_159) |= (((void*)0 == l_158[0][1]) < g_11);
    if (((*l_159) = ((void*)0 != &g_66)))
    { /* block id: 39 */
        uint32_t l_164[1][2];
        uint32_t *l_175 = &l_164[0][1];
        int64_t **l_5900 = &g_538[0];
        int32_t l_5913[8] = {0xE1D90C07L,0xD87637D3L,0xE1D90C07L,0xE1D90C07L,0xD87637D3L,0xE1D90C07L,0xE1D90C07L,0xD87637D3L};
        int32_t l_5914 = (-6L);
        union U4 ***l_5941 = &g_2302;
        int64_t l_5948 = (-10L);
        uint16_t l_5951 = 0xDD42L;
        union U3 **l_5969[7] = {&g_746,&g_746,&g_746,&g_746,&g_746,&g_746,&g_746};
        int32_t l_5994 = 0x5F891C0CL;
        const int8_t l_6020[1] = {3L};
        const uint16_t l_6031 = 0x954AL;
        uint32_t l_6044 = 4294967295UL;
        int32_t **l_6156[3][3] = {{&g_4097,&g_4097,&g_4097},{&g_4097,&g_4097,&g_4097},{(void*)0,(void*)0,&g_4097}};
        int32_t l_6158 = (-3L);
        uint8_t l_6164[3][10] = {{0xB3L,6UL,0x45L,6UL,0xB3L,0xB3L,6UL,0x45L,6UL,0xB3L},{0xB3L,6UL,0x45L,6UL,0xB3L,0xB3L,6UL,0x45L,6UL,0xB3L},{0xB3L,6UL,0x45L,6UL,0xB3L,0xB3L,6UL,0x45L,6UL,0xB3L}};
        uint16_t *****l_6194[8] = {&g_3054,&g_3054,&g_3054,&g_3054,&g_3054,&g_3054,&g_3054,&g_3054};
        struct S1 ** const *l_6232 = (void*)0;
        int32_t l_6320[7][5][4] = {{{(-1L),0x2B32DE6AL,(-1L),1L},{0xC79D8C63L,1L,0x73C74AEEL,0x16CE6C4CL},{1L,0x91ED2038L,0x91ED2038L,1L},{(-1L),0xA1904DAFL,0L,0x1C2B8082L},{0xD8BDEEE8L,0xA75F238BL,0x73C74AEEL,0xC79D8C63L}},{{5L,1L,0xABC2C25AL,0xC79D8C63L},{(-1L),0xA75F238BL,1L,0x1C2B8082L},{0x16CE6C4CL,0xA1904DAFL,(-1L),1L},{0L,0x91ED2038L,0x1C2B8082L,0x16CE6C4CL},{(-1L),1L,(-1L),1L}},{{0xA75F238BL,0x2B32DE6AL,0x73C74AEEL,0L},{0x2B32DE6AL,0x91ED2038L,1L,0x2B32DE6AL},{(-1L),0x16CE6C4CL,1L,0x1C2B8082L},{0x2B32DE6AL,0xC79D8C63L,0x73C74AEEL,0xA75F238BL},{0xA75F238BL,1L,(-1L),5L}},{{(-1L),5L,0x1C2B8082L,0x1C2B8082L},{0L,0L,(-1L),0xD8BDEEE8L},{0x16CE6C4CL,0x91ED2038L,1L,0xA1904DAFL},{(-1L),0xD8BDEEE8L,0xABC2C25AL,1L},{5L,0xD8BDEEE8L,0x73C74AEEL,0xA1904DAFL}},{{0xD8BDEEE8L,0x91ED2038L,0L,0xD8BDEEE8L},{(-1L),0L,0x91ED2038L,0x1C2B8082L},{1L,5L,0x73C74AEEL,5L},{0xC79D8C63L,1L,(-1L),0xA75F238BL},{(-1L),0xC79D8C63L,0xB890E8DEL,0x1C2B8082L}},{{0xA1904DAFL,0x16CE6C4CL,(-1L),0x2B32DE6AL},{0xA1904DAFL,0x91ED2038L,0xB890E8DEL,0L},{(-1L),0x2B32DE6AL,(-1L),1L},{0xC79D8C63L,1L,0x73C74AEEL,0x16CE6C4CL},{1L,0x91ED2038L,0x91ED2038L,1L}},{{(-1L),0xA1904DAFL,0L,0x1C2B8082L},{0xD8BDEEE8L,0xA75F238BL,0x73C74AEEL,0xC79D8C63L},{5L,1L,0xABC2C25AL,0xC79D8C63L},{(-1L),0xA75F238BL,1L,0x1C2B8082L},{0x16CE6C4CL,0xA1904DAFL,(-1L),1L}}};
        int16_t l_6326 = 0x90BFL;
        uint64_t l_6403 = 0UL;
        union U5 ***l_6486 = &g_6484;
        int16_t l_6497 = (-1L);
        int32_t *l_6535 = &g_3071;
        uint8_t l_6596 = 0x5BL;
        int32_t l_6688 = 0x8E5A52D3L;
        int8_t l_6689 = 0x6AL;
        uint8_t l_6712 = 255UL;
        int8_t **l_6722 = &l_158[4][4];
        uint32_t **** const l_6756 = &g_3250[8];
        uint32_t l_6757[2];
        uint16_t l_6799 = 0xD317L;
        int i, j, k;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 2; j++)
                l_164[i][j] = 0x6F1E1A57L;
        }
        for (i = 0; i < 2; i++)
            l_6757[i] = 0xB72B2048L;
        for (g_38 = 0; (g_38 < 4); g_38 = safe_add_func_int16_t_s_s(g_38, 2))
        { /* block id: 42 */
            int32_t *l_162[2][8] = {{(void*)0,&g_3,(void*)0,&g_3,(void*)0,&g_3,(void*)0,&g_3},{(void*)0,&g_3,(void*)0,&g_3,(void*)0,&g_3,(void*)0,&g_3}};
            int i, j;
            --l_164[0][0];
            for (g_66 = 6; (g_66 < 45); g_66++)
            { /* block id: 46 */
                uint32_t *l_174 = (void*)0;
                uint32_t **l_173[1][7][8] = {{{&l_174,&l_174,(void*)0,&l_174,&l_174,&l_174,(void*)0,&l_174},{&l_174,&l_174,(void*)0,&l_174,&l_174,&l_174,(void*)0,&l_174},{&l_174,&l_174,(void*)0,&l_174,&l_174,&l_174,(void*)0,&l_174},{&l_174,&l_174,(void*)0,&l_174,&l_174,&l_174,(void*)0,&l_174},{&l_174,&l_174,(void*)0,&l_174,&l_174,&l_174,(void*)0,&l_174},{&l_174,&l_174,(void*)0,&l_174,&l_174,&l_174,(void*)0,&l_174},{&l_174,&l_174,(void*)0,&l_174,&l_174,&l_174,(void*)0,&l_174}}};
                const int8_t *l_176 = &g_29;
                int32_t l_180 = 0x49A0BCAFL;
                uint16_t **l_5905 = &g_715;
                union U4 ***l_5947 = &g_2302;
                int32_t l_5949 = 0x3D523D5AL;
                int32_t l_5950 = 0x496D7F17L;
                int32_t *l_5958 = &l_180;
                int i, j, k;
                if ((safe_mod_func_uint16_t_u_u(((safe_lshift_func_uint8_t_u_s((((l_175 = l_162[0][3]) != l_159) >= (((((l_158[0][1] == &g_29) != ((void*)0 != l_176)) & (safe_mul_func_uint8_t_u_u(0xABL, (+(l_164[0][0] , l_180))))) & g_29) , (*g_28))), 3)) <= p_140), g_38)))
                { /* block id: 48 */
                    uint8_t *l_187[8][2][10] = {{{&g_188,&g_188,&g_188,&g_188,(void*)0,&g_188,(void*)0,(void*)0,&g_188,(void*)0},{&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,(void*)0,&g_188,&g_188}},{{&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,&g_188},{(void*)0,&g_188,&g_188,&g_188,&g_188,(void*)0,(void*)0,&g_188,&g_188,&g_188}},{{&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,(void*)0,&g_188,&g_188},{&g_188,&g_188,(void*)0,&g_188,&g_188,(void*)0,&g_188,&g_188,&g_188,(void*)0}},{{(void*)0,&g_188,&g_188,&g_188,(void*)0,&g_188,&g_188,&g_188,(void*)0,&g_188},{&g_188,&g_188,&g_188,(void*)0,&g_188,&g_188,(void*)0,&g_188,&g_188,&g_188}},{{&g_188,&g_188,(void*)0,(void*)0,&g_188,&g_188,&g_188,(void*)0,(void*)0,&g_188},{&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,&g_188}},{{&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,(void*)0,&g_188,&g_188,&g_188},{&g_188,&g_188,&g_188,&g_188,(void*)0,&g_188,(void*)0,(void*)0,&g_188,(void*)0}},{{&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,&g_188},{(void*)0,&g_188,&g_188,&g_188,(void*)0,&g_188,&g_188,&g_188,&g_188,&g_188}},{{&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,&g_188,(void*)0,&g_188},{&g_188,&g_188,(void*)0,&g_188,(void*)0,&g_188,&g_188,&g_188,&g_188,&g_188}}};
                    int32_t l_5897 = 6L;
                    int64_t ***l_5901 = &l_5900;
                    int32_t l_5906 = 0x2BAAB374L;
                    uint32_t l_5915 = 0UL;
                    union U4 ***l_5943 = (void*)0;
                    int i, j, k;
                    l_5893 |= (~func_182(p_140, (*l_159), (++g_188), &g_2[4][1][1]));
                    l_5914 = ((l_5913[0] = ((((safe_mul_func_uint16_t_u_u((l_5897 = (+((**g_714)--))), (((*l_5901) = l_5900) == ((safe_sub_func_uint32_t_u_u(((+(0xC105E909ABDAAB70LL | (((void*)0 == l_5905) && l_5906))) , (safe_lshift_func_uint16_t_u_s((((safe_rshift_func_uint8_t_u_u(l_180, ((((safe_mod_func_int8_t_s_s((-10L), 0x78L)) || (l_164[0][0] ^ 0UL)) , l_5906) > p_140))) , 4294967293UL) && 1UL), (*l_159)))), 0UL)) , (void*)0)))) != 1UL) , 0x8FBA63BBL) , 0xC7L)) > p_140);
                    ++l_5915;
                    for (g_1396 = 22; (g_1396 < (-25)); --g_1396)
                    { /* block id: 2528 */
                        uint32_t l_5920 = 0x97FAAB3BL;
                        union U4 ****l_5942[6][6] = {{&l_5941,&l_5941,&l_5941,&l_5941,(void*)0,&l_5941},{&l_5941,(void*)0,&l_5941,&l_5941,&l_5941,&l_5941},{&l_5941,(void*)0,&l_5941,&l_5941,(void*)0,&l_5941},{(void*)0,&l_5941,&l_5941,&l_5941,&l_5941,&l_5941},{&l_5941,&l_5941,&l_5941,&l_5941,&l_5941,&l_5941},{&l_5941,&l_5941,&l_5941,&l_5941,&l_5941,&l_5941}};
                        int i, j;
                        l_5920--;
                        (*****g_2717) |= ((safe_rshift_func_uint8_t_u_s(255UL, ((safe_sub_func_int32_t_s_s(((-9L) || ((((safe_lshift_func_int16_t_s_s((safe_div_func_int16_t_s_s(((safe_rshift_func_int8_t_s_s((((((((safe_add_func_uint64_t_u_u(7UL, ((*l_159) , ((safe_sub_func_uint32_t_u_u(((((*g_1675) != (**g_1674)) , (((safe_sub_func_uint16_t_u_u((safe_mod_func_uint64_t_u_u(((l_5943 = l_5941) != (l_5947 = ((p_140 != (safe_rshift_func_uint8_t_u_u(p_140, 6))) , l_5946[1]))), 0xE09080CFEA9685DFLL)), l_5920)) && 0xEB0E0386F6B05B7ELL) <= 5UL)) , l_5948), l_180)) <= p_140)))) , 7L) , p_140) && p_140) <= 0xF2CEL) , p_140) , (***g_4422)), (**g_4423))) , p_140), (*g_715))), 14)) , (void*)0) == (void*)0) == 0xD46ED009L)), l_5920)) , (-8L)))) || (-8L));
                        l_5951++;
                    }
                }
                else
                { /* block id: 2535 */
                    const union U2 *l_5956 = (void*)0;
                    for (g_2386.f0 = 27; (g_2386.f0 != (-21)); g_2386.f0--)
                    { /* block id: 2538 */
                        const union U2 **l_5957 = &l_5956;
                        (*l_5957) = l_5956;
                    }
                }
                if ((*g_653))
                    continue;
                (*g_653) &= p_140;
                l_5958 = (***g_2718);
            }
        }
        if ((p_140 , ((safe_mul_func_int16_t_s_s((*l_159), 0UL)) , (l_5914 = ((safe_mul_func_uint8_t_u_u(((*g_656) ^= (safe_div_func_int32_t_s_s(((safe_rshift_func_int16_t_s_s((safe_lshift_func_int8_t_s_u(((p_140 & l_164[0][0]) == ((p_140 && ((((****g_2717) = (l_159 = &l_5913[3])) == &p_140) && (l_5969[0] == (void*)0))) & 0x7BAF2544CE393DBELL)), (*****g_5407))), p_140)) > p_140), (**g_929)))), 0x1CL)) >= l_164[0][0])))))
        { /* block id: 2551 */
            int32_t *****l_5979 = &g_3477;
            const int16_t ****l_5988[4] = {&g_1676,&g_1676,&g_1676,&g_1676};
            int32_t l_5992[1][8] = {{6L,6L,0L,6L,6L,0L,6L,6L}};
            int32_t *l_5995 = &l_5913[0];
            union U5 **l_5997 = &g_1070;
            union U5 ***l_5996 = &l_5997;
            int i, j;
            l_5994 |= (((**g_714) = (safe_rshift_func_int16_t_s_u((safe_div_func_int64_t_s_s(((**l_5900) ^= (l_5913[2] != (((safe_mul_func_int8_t_s_s((**g_4423), (((((l_5914 , ((((safe_mod_func_uint8_t_u_u(((l_5978 = (void*)0) != (l_5913[1] , l_5979)), ((*g_1678) , ((((safe_add_func_uint32_t_u_u((l_5982 || ((~(safe_mul_func_uint8_t_u_u(((*g_5411) &= (((((((((safe_div_func_uint32_t_u_u(4294967289UL, 4UL)) ^ p_140) | l_164[0][0]) ^ p_140) , l_5988[1]) == l_5989[0][7]) > l_5992[0][7]) || (*l_159)) , 0x6FL)), (-1L)))) , l_5993)), l_5992[0][7])) ^ (-1L)) > 0x6762FB89L) | l_5992[0][7])))) != p_140) ^ 0xC58A6C67L) , 0L)) , &g_3567[1][1]) == &g_1070) || l_5992[0][7]) == (**g_929)))) || l_5992[0][7]) && (*l_159)))), p_140)), (*l_159)))) >= 1L);
            l_5995 = (*g_1207);
            l_6002 ^= ((((((void*)0 == l_5996) | ((((**g_929) , ((((((((safe_mod_func_int64_t_s_s((l_6000 == (0x8CL && 9UL)), (safe_unary_minus_func_uint32_t_u((((l_159 != l_5995) > (l_5994 ^= ((*l_5995) = (*g_28)))) && (*l_5995)))))) >= l_164[0][0]) || (*l_5995)) ^ (****g_1675)) , p_140) ^ p_140) , p_140) , (*l_5979))) != (*l_5979)) , 0L)) & 0UL) , p_140) || 1L);
            (*g_1207) = (*g_1207);
        }
        else
        { /* block id: 2562 */
            struct S1 *l_6027 = &g_6028;
            struct S1 **l_6026[3][1];
            struct S1 ***l_6025 = &l_6026[1][0];
            int32_t **l_6038[3];
            int32_t *l_6046 = &g_38;
            int32_t l_6131 = 0xDED793ACL;
            int32_t l_6139 = 0xF9B2F137L;
            int32_t l_6159 = (-1L);
            int32_t l_6160 = 0x6AAB9B60L;
            int32_t l_6161[3];
            uint16_t ***** const l_6193 = &g_3054;
            int64_t *l_6309[8] = {&g_5048.f0,&g_5048.f0,&g_5048.f0,&g_5048.f0,&g_5048.f0,&g_5048.f0,&g_5048.f0,&g_5048.f0};
            uint8_t * const **l_6347 = (void*)0;
            uint64_t * const **l_6352 = (void*)0;
            uint64_t * const ***l_6351 = &l_6352;
            union U3 *****l_6396 = &g_1503;
            int16_t l_6402 = 7L;
            int32_t *****l_6406 = &g_3477;
            uint32_t ***l_6419 = (void*)0;
            int16_t l_6496[4] = {0L,0L,0L,0L};
            int32_t l_6500[6][9] = {{0xACDADEB5L,7L,(-1L),0x961EC8A2L,(-4L),0xEBF82110L,0xEBF82110L,(-4L),0x961EC8A2L},{0xDBA6C7ACL,0L,0xDBA6C7ACL,0xEBF82110L,0L,(-1L),0xEBF82110L,1L,0L},{0L,1L,0xEBF82110L,(-1L),0L,0xEBF82110L,0xDBA6C7ACL,0L,0xDBA6C7ACL},{0x961EC8A2L,(-4L),0xEBF82110L,0xEBF82110L,(-4L),0x961EC8A2L,(-1L),7L,0xACDADEB5L},{0x961EC8A2L,1L,0xDBA6C7ACL,0x961EC8A2L,0L,0xACDADEB5L,0L,7L,0xDBA6C7ACL},{0L,0L,(-1L),0xACDADEB5L,(-5L),0xACDADEB5L,(-1L),0L,0L}};
            uint32_t l_6507 = 0UL;
            int16_t l_6536 = 0L;
            union U2 *l_6565[10][10] = {{&g_6587,&g_6582,&g_6583,&g_6569,&g_6583,&g_6582,&g_6587,&g_6576,&g_6571,&g_6573},{&g_6571,&g_6576,&g_6587,&g_6582,&g_6583,&g_6569,&g_6583,&g_6582,&g_6587,&g_6576},{&g_6583,&g_6576,&g_6575,&g_6579,&g_6568[1],&g_6585,&g_6587,&g_6573,&g_6587,&g_6585},{&g_6580,&g_6582,&g_6568[1],&g_6582,&g_6580,&g_6585,&g_6575,&g_6569,&g_6571,&g_6579},{&g_6583,&g_6573,&g_6568[1],&g_6585,&g_6571,&g_6585,&g_6583,&g_6566,&g_6577,&g_6573},{&g_6587,&g_6585,&g_6568[1],&g_6579,&g_6575,&g_6576,&g_6583,&g_6576,&g_6575,&g_6579},{&g_6580,&g_6566,&g_6580,&g_6579,&g_6583,&g_6573,&g_6568[1],&g_6569,&g_6577,&g_6569},{&g_6580,&g_6576,&g_6577,&g_6585,&g_6577,&g_6576,&g_6580,&g_6569,&g_6587,&g_6566},{&g_6587,&g_6569,&g_6580,&g_6576,&g_6577,&g_6585,&g_6577,&g_6576,&g_6580,&g_6569},{&g_6577,&g_6569,&g_6568[1],&g_6573,&g_6583,&g_6579,&g_6580,&g_6566,&g_6580,&g_6579}};
            union U2 ** const l_6564 = &l_6565[5][1];
            uint32_t l_6616 = 1UL;
            int64_t l_6654 = 0L;
            int64_t l_6694 = 0x1B66D3B180A0DAA8LL;
            uint8_t l_6695 = 255UL;
            uint32_t ** const **l_6754 = (void*)0;
            int i, j;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 1; j++)
                    l_6026[i][j] = &l_6027;
            }
            for (i = 0; i < 3; i++)
                l_6038[i] = (void*)0;
            for (i = 0; i < 3; i++)
                l_6161[i] = 0xD233CF09L;
lbl_6716:
            if ((*g_653))
            { /* block id: 2563 */
                int64_t *l_6015[7] = {&g_196,&g_196,&g_196,&g_196,&g_196,&g_196,&g_196};
                int32_t l_6029 = 0L;
                uint16_t l_6030 = 0x4B82L;
                const union U3 **l_6043 = (void*)0;
                const union U3 ***l_6042 = &l_6043;
                int i;
                (***g_2718) = (((*l_159) || (0xF2EAL == (((!((0xCBL >= (--(**g_5410))) ^ (p_140 ^ 0xFC5E23BA93CEBE3FLL))) , g_6006) == (void*)0))) , &l_5914);
                (****g_2718) = ((((*l_159) |= (*****g_2717)) ^ (0x69AB47A73654891ALL > (safe_rshift_func_uint16_t_u_u(((safe_unary_minus_func_uint16_t_u((safe_div_func_int64_t_s_s((l_5994 = (l_5893 = ((**l_5900) = p_140))), (((safe_mod_func_uint32_t_u_u((**g_929), (safe_mul_func_uint16_t_u_u((((l_6020[0] ^ ((0x8BA7789184E4CF07LL != ((((safe_lshift_func_int16_t_s_s((safe_rshift_func_uint8_t_u_u((****g_5408), 6)), (((void*)0 != l_6025) | (*g_715)))) == 0UL) < p_140) , 0x97B5E6404C286394LL)) < 0UL)) ^ p_140) , 0x4F98L), l_6000)))) >= l_6029) , l_6030))))) == p_140), l_6031)))) , 6L);
                if (((*****g_2717) = ((safe_rshift_func_uint16_t_u_s(((safe_lshift_func_int8_t_s_s(((safe_sub_func_uint8_t_u_u((((0x28D7L || 65535UL) , l_6038[2]) != ((l_6039[1][2][0] == (void*)0) , l_6038[1])), (p_140 , (((*l_5900) = func_314((((p_140 || (l_6044 |= (safe_lshift_func_int16_t_s_s((((*l_6042) = (void*)0) != (void*)0), p_140)))) , (*l_159)) >= g_6045), l_6046)) != l_6015[0])))) && 1L), l_6031)) || (*l_159)), 2)) , 0x32F79B52L)))
                { /* block id: 2575 */
                    return l_6046;
                }
                else
                { /* block id: 2577 */
                    uint32_t *l_6049 = &g_3302;
                    const union U3 *l_6067[4][10][6] = {{{(void*)0,&g_6085[0],&g_6085[0],(void*)0,&g_6075,(void*)0},{(void*)0,&g_6075,(void*)0,&g_6068,&g_6085[0],(void*)0},{&g_6089[0],&g_6105,&g_6085[0],(void*)0,&g_6085[0],&g_6105},{&g_6068,&g_6075,&g_6095,(void*)0,&g_6075,&g_6085[0]},{&g_6089[0],&g_6085[0],&g_6095,&g_6068,&g_6105,&g_6105},{(void*)0,&g_6085[0],&g_6085[0],(void*)0,&g_6075,(void*)0},{(void*)0,&g_6075,(void*)0,&g_6068,&g_6085[0],(void*)0},{&g_6089[0],&g_6105,&g_6085[0],(void*)0,&g_6085[0],&g_6105},{&g_6068,&g_6075,&g_6095,(void*)0,&g_6075,&g_6085[0]},{&g_6089[0],&g_6085[0],&g_6095,&g_6068,&g_6105,&g_6105}},{{(void*)0,&g_6085[0],&g_6085[0],(void*)0,&g_6075,(void*)0},{(void*)0,&g_6075,(void*)0,&g_6068,&g_6085[0],(void*)0},{&g_6089[0],&g_6105,&g_6085[0],(void*)0,&g_6085[0],&g_6105},{&g_6068,&g_6075,&g_6095,(void*)0,&g_6075,&g_6085[0]},{&g_6089[0],&g_6085[0],&g_6095,&g_6068,&g_6105,&g_6105},{(void*)0,&g_6085[0],&g_6085[0],(void*)0,&g_6075,(void*)0},{(void*)0,&g_6075,(void*)0,&g_6068,&g_6085[0],(void*)0},{&g_6089[0],&g_6105,&g_6085[0],(void*)0,&g_6085[0],&g_6105},{&g_6068,&g_6075,&g_6095,(void*)0,&g_6075,&g_6085[0]},{&g_6089[0],&g_6085[0],&g_6095,&g_6068,&g_6105,&g_6105}},{{(void*)0,&g_6085[0],&g_6085[0],(void*)0,&g_6075,(void*)0},{&g_6095,(void*)0,&g_6110,(void*)0,&g_6082,&g_6110},{&g_6085[0],&g_6101,&g_6082,&g_6075,&g_6082,&g_6101},{(void*)0,(void*)0,&g_6092,&g_6075,(void*)0,&g_6082},{&g_6085[0],&g_6082,&g_6092,(void*)0,&g_6101,&g_6101},{&g_6095,&g_6082,&g_6082,&g_6095,(void*)0,&g_6110},{&g_6095,(void*)0,&g_6110,(void*)0,&g_6082,&g_6110},{&g_6085[0],&g_6101,&g_6082,&g_6075,&g_6082,&g_6101},{(void*)0,(void*)0,&g_6092,&g_6075,(void*)0,&g_6082},{&g_6085[0],&g_6082,&g_6092,(void*)0,&g_6101,&g_6101}},{{&g_6095,&g_6082,&g_6082,&g_6095,(void*)0,&g_6110},{&g_6095,(void*)0,&g_6110,(void*)0,&g_6082,&g_6110},{&g_6085[0],&g_6101,&g_6082,&g_6075,&g_6082,&g_6101},{(void*)0,(void*)0,&g_6092,&g_6075,(void*)0,&g_6082},{&g_6085[0],&g_6082,&g_6092,(void*)0,&g_6101,&g_6101},{&g_6095,&g_6082,&g_6082,&g_6095,(void*)0,&g_6110},{&g_6095,(void*)0,&g_6110,(void*)0,&g_6082,&g_6110},{&g_6085[0],&g_6101,&g_6082,&g_6075,&g_6082,&g_6101},{(void*)0,(void*)0,&g_6092,&g_6075,(void*)0,&g_6082},{&g_6085[0],&g_6082,&g_6092,(void*)0,&g_6101,&g_6101}}};
                    const union U3 **l_6066[9] = {&l_6067[2][3][4],&l_6067[2][3][4],&l_6067[2][3][4],&l_6067[2][3][4],&l_6067[2][3][4],&l_6067[2][3][4],&l_6067[2][3][4],&l_6067[2][3][4],&l_6067[2][3][4]};
                    int32_t l_6117 = 0xD0EE8C59L;
                    int64_t **l_6118 = (void*)0;
                    int32_t l_6124 = 0x10E0D356L;
                    int32_t l_6125 = 1L;
                    int32_t **l_6157 = &g_4097;
                    int i, j, k;
                    for (l_5993 = (-4); (l_5993 <= 1); l_5993 = safe_add_func_int8_t_s_s(l_5993, 7))
                    { /* block id: 2580 */
                        return l_6049;
                    }
                    if ((((*l_159) , (+(safe_lshift_func_uint16_t_u_u(p_140, 1)))) ^ (safe_div_func_uint32_t_u_u((18446744073709551615UL || (*l_6046)), (safe_sub_func_uint64_t_u_u(((*l_159) >= (safe_unary_minus_func_uint64_t_u((((*l_5900) = l_6015[2]) != (g_6119 = func_238(&l_5893, ((l_6029 = (((safe_div_func_int64_t_s_s((((safe_div_func_int8_t_s_s(((safe_div_func_int16_t_s_s((safe_mul_func_uint8_t_u_u(((l_5969[0] != l_6066[0]) && 0x96BFL), (*l_6046))), (*l_6046))) <= p_140), 1L)) >= l_6117) , 1L), 0x98BFB8F4CD0354FCLL)) & l_6117) < 2L)) < (*l_6046)), l_6030)))))), g_3142.f1))))))
                    { /* block id: 2586 */
                        int32_t *l_6120 = &l_5993;
                        int32_t *l_6121 = &g_38;
                        int32_t *l_6122 = &l_6029;
                        int32_t *l_6123 = &l_5914;
                        int32_t *l_6126 = &g_499[0][0];
                        int32_t *l_6127 = &l_5913[7];
                        int32_t *l_6128 = &g_38;
                        int32_t *l_6129 = &l_6125;
                        int32_t *l_6130 = &g_499[0][0];
                        int32_t *l_6132 = &l_5893;
                        int32_t *l_6133 = (void*)0;
                        int32_t *l_6134 = &g_499[0][0];
                        int32_t *l_6135 = &g_3420[2];
                        int32_t *l_6136 = (void*)0;
                        int32_t *l_6137 = &g_3420[2];
                        int32_t *l_6138[7] = {&g_7[5][0][0],&g_7[5][0][0],&g_7[5][0][0],&g_7[5][0][0],&g_7[5][0][0],&g_7[5][0][0],&g_7[5][0][0]};
                        uint64_t l_6142[4];
                        int i;
                        for (i = 0; i < 4; i++)
                            l_6142[i] = 0x28D0D60FB1B62EC3LL;
                        l_6142[0]--;
                        (*****g_2717) = (g_6145 >= ((safe_mod_func_int8_t_s_s((safe_div_func_uint32_t_u_u(((**g_929) = (((safe_unary_minus_func_uint64_t_u((*l_159))) & l_6124) > p_140)), (((*g_5749) == l_164[0][0]) || (p_140 ^ (safe_unary_minus_func_int16_t_s(((l_6117 = (-1L)) , (safe_mul_func_int16_t_s_s(((l_6156[2][2] == l_6157) & 0UL), 0x44CBL))))))))), p_140)) , 0x9A25DF2720A837ADLL));
                        l_6164[1][5]++;
                    }
                    else
                    { /* block id: 2592 */
                        l_6158 = (*l_6046);
                    }
                    l_6117 = (((safe_sub_func_int32_t_s_s(((safe_add_func_int8_t_s_s(p_140, (!(((((safe_rshift_func_int8_t_s_u((((((((*l_6046) ^= p_140) != (**g_4423)) | ((safe_mul_func_uint8_t_u_u(((*g_653) ^ (~((**g_929) = (safe_lshift_func_uint16_t_u_u((safe_sub_func_uint16_t_u_u((safe_div_func_uint16_t_u_u(l_6117, l_6020[0])), (safe_mod_func_int32_t_s_s(l_164[0][0], (safe_div_func_uint16_t_u_u(p_140, l_6030)))))), 6))))), p_140)) ^ (***g_4422))) & p_140) & p_140) >= p_140), p_140)) == 0xB4511A24L) , p_140) , (**g_1207)) <= l_5913[1])))) != 0x84L), l_6124)) | 0x6CE3L) & (*g_1541));
                }
            }
            else
            { /* block id: 2599 */
                uint32_t l_6199 = 2UL;
                int32_t *l_6204[7];
                int16_t *l_6205 = &g_1470;
                int16_t *l_6217 = (void*)0;
                int16_t *l_6218[7] = {&g_5422,&g_5422,&g_5422,&g_5422,&g_5422,&g_5422,&g_5422};
                uint32_t l_6224 = 18446744073709551612UL;
                int i;
                for (i = 0; i < 7; i++)
                    l_6204[i] = &g_3420[2];
                l_6140 |= ((p_140 == (((**g_929) &= (*l_159)) != (((*l_6205) = (((safe_sub_func_int16_t_s_s((*l_6046), (((safe_add_func_int32_t_s_s((safe_mul_func_int8_t_s_s((l_6193 == l_6194[4]), (safe_add_func_int64_t_s_s(p_140, (safe_add_func_int32_t_s_s(l_6199, (l_6131 = (((safe_sub_func_uint64_t_u_u(p_140, (safe_mul_func_uint16_t_u_u(0x392CL, 0x23F2L)))) < 0xC7L) == 0x733C72CD2AF3D486LL)))))))), p_140)) & (*l_6046)) <= p_140))) == p_140) < 4294967286UL)) | l_6031))) == 0x121A4147L);
                if ((safe_rshift_func_int8_t_s_u((p_140 , (p_140 != (((safe_unary_minus_func_int8_t_s(((safe_mul_func_int16_t_s_s((*****g_1674), (l_5948 , (((*l_6046) = ((*l_6205) = ((*l_159) , ((safe_mod_func_int16_t_s_s((safe_add_func_int64_t_s_s((safe_rshift_func_int8_t_s_u(0x26L, ((*g_5749) || ((p_140 & p_140) && 0x4EL)))), (*l_6046))), p_140)) >= (***g_4422))))) == 0x7B23L)))) , l_164[0][0]))) != p_140) , 1L))), 2)))
                { /* block id: 2606 */
                    struct S1 ****l_6231 = &l_6025;
                    const int32_t l_6234 = 0xF3FA7B27L;
                    int32_t ****l_6237 = (void*)0;
                    int32_t l_6241 = (-5L);
                    int32_t l_6242 = 4L;
                    int32_t l_6243 = 3L;
                    int32_t l_6244 = 0xD7A99AD1L;
                    int32_t l_6247[8];
                    int i;
                    for (i = 0; i < 8; i++)
                        l_6247[i] = 0x04A8B8A9L;
                    for (g_1550 = 1; (g_1550 <= 6); g_1550 += 1)
                    { /* block id: 2609 */
                        return (*g_929);
                    }
                    if ((((((((*****g_5407) = (safe_mod_func_int16_t_s_s(((*l_6205) = (~0L)), ((*l_159) && (safe_sub_func_uint32_t_u_u((l_6224 , (safe_rshift_func_int8_t_s_s((1UL && (((0x910242A279B8EA1DLL == (*g_1541)) , (((p_140 && ((((*l_159) != (safe_sub_func_uint64_t_u_u(((g_6229 = ((*l_6231) = g_6229)) != l_6232), (*g_6119)))) , (*l_6046)) , p_140)) & p_140) , g_6233)) < p_140)), l_6031))), p_140)))))) >= (*l_6046)) , l_6234) | 1UL) && 1UL) < 255UL))
                    { /* block id: 2616 */
                        int32_t ****l_6238 = &g_4095;
                        int32_t l_6245 = 1L;
                        int32_t l_6246[1];
                        int32_t l_6255 = (-6L);
                        int i;
                        for (i = 0; i < 1; i++)
                            l_6246[i] = 1L;
                        (**g_1207) = (safe_lshift_func_int16_t_s_s((p_140 > (l_6237 != l_6238)), 4));
                        g_6240 = l_6239;
                        --l_6252;
                        g_6256--;
                    }
                    else
                    { /* block id: 2621 */
                        uint32_t l_6259 = 0xEA0DD772L;
                        ++l_6259;
                    }
                    for (l_6141 = (-18); (l_6141 <= 15); l_6141 = safe_add_func_uint8_t_u_u(l_6141, 7))
                    { /* block id: 2626 */
                        if (p_140)
                            break;
                        if ((*g_653))
                            break;
                        if (p_140)
                            continue;
                    }
                    (***g_2718) = &l_6159;
                }
                else
                { /* block id: 2632 */
                    uint64_t l_6264[2][6][9] = {{{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL}},{{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL}}};
                    const int32_t *l_6268 = &l_6249;
                    int32_t l_6269 = 0xFD63C977L;
                    int i, j, k;
                    for (g_2170 = 2; (g_2170 <= 6); g_2170 += 1)
                    { /* block id: 2635 */
                        const int32_t **l_6267[1][4][1];
                        int i, j, k;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 4; j++)
                            {
                                for (k = 0; k < 1; k++)
                                    l_6267[i][j][k] = &g_2482[0][1][5];
                            }
                        }
                        ++l_6264[1][1][6];
                        if ((*l_6046))
                            continue;
                        l_6268 = &p_140;
                    }
                    g_6270++;
                    (*g_1207) = l_6204[6];
                }
                for (l_5914 = 16; (l_5914 == (-27)); --l_5914)
                { /* block id: 2645 */
                    for (g_857 = 0; g_857 < 7; g_857 += 1)
                    {
                        l_5991[g_857] = &g_1678;
                    }
                }
            }
            for (l_6163 = 0; (l_6163 >= 0); l_6163 -= 1)
            { /* block id: 2651 */
                uint16_t * const ***l_6282 = &g_6281;
                int32_t l_6307 = 0x1F77ED7EL;
                const int16_t **l_6336[10][4][6] = {{{&g_1678,&g_1678,&g_1678,&g_1678,&g_1678,&g_1678},{&g_1678,&g_1678,&g_1678,&g_1678,&g_1678,&g_1678},{&g_1678,&g_1678,(void*)0,&g_1678,(void*)0,&g_1678},{(void*)0,&g_1678,&g_1678,&g_1678,&g_1678,&g_1678}},{{(void*)0,(void*)0,&g_1678,&g_1678,(void*)0,&g_1678},{&g_1678,(void*)0,&g_1678,&g_1678,&g_1678,&g_1678},{&g_1678,&g_1678,&g_1678,&g_1678,(void*)0,&g_1678},{&g_1678,&g_1678,&g_1678,&g_1678,&g_1678,&g_1678}},{{&g_1678,&g_1678,&g_1678,&g_1678,&g_1678,&g_1678},{&g_1678,&g_1678,(void*)0,&g_1678,(void*)0,&g_1678},{(void*)0,&g_1678,&g_1678,&g_1678,&g_1678,&g_1678},{(void*)0,(void*)0,&g_1678,&g_1678,(void*)0,&g_1678}},{{&g_1678,(void*)0,&g_1678,&g_1678,&g_1678,&g_1678},{&g_1678,&g_1678,&g_1678,&g_1678,(void*)0,&g_1678},{&g_1678,&g_1678,&g_1678,&g_1678,&g_1678,&g_1678},{&g_1678,&g_1678,&g_1678,&g_1678,&g_1678,&g_1678}},{{&g_1678,&g_1678,(void*)0,&g_1678,(void*)0,&g_1678},{(void*)0,&g_1678,&g_1678,&g_1678,&g_1678,&g_1678},{(void*)0,(void*)0,&g_1678,&g_1678,(void*)0,&g_1678},{&g_1678,(void*)0,&g_1678,&g_1678,&g_1678,&g_1678}},{{&g_1678,&g_1678,&g_1678,&g_1678,(void*)0,&g_1678},{&g_1678,&g_1678,&g_1678,&g_1678,&g_1678,&g_1678},{&g_1678,&g_1678,&g_1678,&g_1678,&g_1678,&g_1678},{&g_1678,&g_1678,(void*)0,&g_1678,(void*)0,&g_1678}},{{(void*)0,&g_1678,&g_1678,(void*)0,(void*)0,&g_1678},{(void*)0,(void*)0,(void*)0,&g_1678,&g_1678,&g_1678},{&g_1678,(void*)0,&g_1678,&g_1678,(void*)0,(void*)0},{&g_1678,&g_1678,&g_1678,&g_1678,(void*)0,&g_1678}},{{&g_1678,&g_1678,(void*)0,&g_1678,&g_1678,&g_1678},{&g_1678,&g_1678,&g_1678,&g_1678,&g_1678,&g_1678},{&g_1678,&g_1678,(void*)0,&g_1678,(void*)0,&g_1678},{(void*)0,&g_1678,&g_1678,(void*)0,(void*)0,&g_1678}},{{(void*)0,(void*)0,(void*)0,&g_1678,&g_1678,&g_1678},{&g_1678,(void*)0,&g_1678,&g_1678,(void*)0,(void*)0},{&g_1678,&g_1678,&g_1678,&g_1678,(void*)0,&g_1678},{&g_1678,&g_1678,(void*)0,&g_1678,&g_1678,&g_1678}},{{&g_1678,&g_1678,&g_1678,&g_1678,&g_1678,&g_1678},{&g_1678,&g_1678,(void*)0,&g_1678,(void*)0,&g_1678},{(void*)0,&g_1678,&g_1678,(void*)0,(void*)0,&g_1678},{(void*)0,(void*)0,(void*)0,&g_1678,&g_1678,&g_1678}}};
                int16_t * const **l_6362 = (void*)0;
                int16_t * const ***l_6361 = &l_6362;
                int16_t * const ****l_6360 = &l_6361;
                int32_t l_6363[2][8] = {{0xB4253DF1L,(-2L),0xB4253DF1L,5L,0L,0L,5L,0xB4253DF1L},{(-2L),(-2L),0L,0x99570D99L,0xF40764C3L,0x99570D99L,0L,(-2L)}};
                int32_t l_6431 = 0xAB61C428L;
                uint8_t *l_6443[5];
                uint64_t ****l_6461 = &g_3682;
                int64_t l_6588[3][1];
                uint32_t *l_6621 = &g_6348;
                int i, j, k;
                for (i = 0; i < 5; i++)
                    l_6443[i] = (void*)0;
                for (i = 0; i < 3; i++)
                {
                    for (j = 0; j < 1; j++)
                        l_6588[i][j] = (-3L);
                }
            }
            l_5994 &= ((safe_add_func_int32_t_s_s((-1L), ((((((*l_159) = ((((((*l_6046) & (*l_159)) >= (p_140 || (((*l_6046) || ((*g_715) = (p_140 , 65531UL))) <= (((safe_lshift_func_int16_t_s_s((****g_1675), 8)) < ((((((+((**g_929)++)) & ((l_6158 = ((0xF5L || p_140) , (*l_159))) && (*l_159))) < l_5948) != p_140) != (*l_6046)) , (*l_6046))) <= p_140)))) , p_140) , 0L) < p_140)) >= p_140) && (*l_159)) > l_6164[1][6]) , 0L))) | l_6654);
            if (((g_1621[1] = ((((*l_159) = p_140) && p_140) >= (safe_add_func_uint32_t_u_u(((l_6657 & ((void*)0 != &p_140)) , (safe_mul_func_uint16_t_u_u((((*g_3566) == (void*)0) == (0x3BL > ((safe_lshift_func_int16_t_s_u((p_140 | 65535UL), l_6662)) ^ p_140))), l_6250))), (**g_929))))) != p_140))
            { /* block id: 2784 */
                uint8_t l_6665 = 1UL;
                int16_t *l_6673 = &l_6496[0];
                int32_t l_6677 = 0x7CAE08D5L;
                int32_t l_6687 = 0x62FB73D8L;
                int32_t l_6690 = 0x5B790B86L;
                int32_t l_6691 = (-1L);
                int32_t l_6692 = 0xD68E5747L;
                int32_t l_6693[4][5] = {{0L,0L,(-10L),0x892BD5C4L,(-10L)},{(-6L),(-6L),7L,2L,7L},{0L,0L,(-10L),0x892BD5C4L,(-10L)},{(-6L),(-6L),7L,2L,7L}};
                int64_t * const *l_6764 = &l_6308[0];
                int64_t * const **l_6763[3];
                uint32_t **l_6771 = &g_4088[0];
                int i, j;
                for (i = 0; i < 3; i++)
                    l_6763[i] = &l_6764;
                if (((l_6677 = (((safe_mul_func_int16_t_s_s((l_6665 > ((safe_div_func_int16_t_s_s(0x4AA8L, (safe_div_func_int64_t_s_s(p_140, 0x62869D51E1D180B9LL)))) , 7L)), 0xA72AL)) && ((safe_mul_func_uint16_t_u_u(0x97E6L, ((*l_6673) = l_6672))) && (~(((safe_rshift_func_uint16_t_u_s(((((void*)0 != (*l_6564)) < p_140) < (***g_4422)), 14)) != p_140) | (-2L))))) ^ l_6665)) , p_140))
                { /* block id: 2787 */
                    union U4 **l_6678[1][10] = {{&g_1168[5],&g_1168[5],&g_1168[5],&g_1168[5],&g_1168[5],&g_1168[5],&g_1168[5],&g_1168[5],&g_1168[5],&g_1168[5]}};
                    int32_t l_6679[4][5] = {{0x5B428FE8L,0x5B428FE8L,0x5B428FE8L,0x5B428FE8L,0x5B428FE8L},{0L,0L,0L,0L,0L},{0x5B428FE8L,0x5B428FE8L,0x5B428FE8L,0x5B428FE8L,0x5B428FE8L},{0L,0L,0L,0L,0L}};
                    int i, j;
                    (*l_5941) = l_6678[0][1];
                    for (l_6657 = 0; (l_6657 <= 2); l_6657 += 1)
                    { /* block id: 2791 */
                        int32_t *l_6680 = (void*)0;
                        int32_t *l_6681 = &g_38;
                        int32_t *l_6682 = &g_3420[3];
                        int32_t *l_6683 = &g_255;
                        int32_t *l_6684 = &g_4882;
                        int32_t *l_6685 = &g_163;
                        int32_t *l_6686[5][2][5] = {{{&g_7[8][7][1],&l_6158,&l_6662,&g_11,&l_6679[2][3]},{&l_6249,&l_6160,&g_163,&l_5913[0],&g_163}},{{&l_6679[2][3],&l_6679[2][3],&g_3307,&g_7[8][7][1],&l_6677},{&l_6249,&l_6251[0],&l_6161[0],&l_6250,&l_6250}},{{&g_7[8][7][1],&g_3420[0],&g_11,&l_6158,&l_6677},{&l_6250,&g_163,(void*)0,&l_6160,&l_6251[0]}},{{&l_6679[2][3],&l_6141,&l_6141,&l_6679[2][3],&g_11},{&l_6161[0],&l_6139,(void*)0,&l_6251[0],&g_163}},{{(void*)0,&l_5994,&g_11,&l_5994,(void*)0},{&l_6139,&l_6160,&l_6250,&l_6251[0],&l_5913[0]}}};
                        uint8_t * const *l_6713 = (void*)0;
                        int i, j, k;
                        l_6695--;
                        (*l_6046) = (!((((((safe_div_func_uint8_t_u_u(g_539[l_6657], p_140)) , p_140) >= (((((((safe_div_func_uint8_t_u_u((((safe_rshift_func_int16_t_s_s((safe_sub_func_uint32_t_u_u(p_140, ((!(p_140 | ((((safe_mul_func_uint8_t_u_u(0xF1L, (((void*)0 == &g_774) , ((*l_159) >= (*l_6046))))) >= (*g_1541)) && p_140) != p_140))) < 4UL))), 4)) > l_5994) == 0x247CL), p_140)) & (*l_6046)) > l_6679[0][1]) >= l_6712) == (-10L)) <= l_6679[0][1]) | 0L)) || p_140) , l_6713) == (void*)0));
                        if (l_6403)
                            break;
                    }
                }
                else
                { /* block id: 2796 */
                    uint64_t l_6719 = 18446744073709551615UL;
                    int32_t l_6726 = 0xC6EFE6A5L;
                    uint32_t ** const ***l_6755 = &l_6754;
                    const int32_t **l_6758 = (void*)0;
                    const int32_t **l_6759 = (void*)0;
                    const int32_t **l_6760[7] = {&g_2482[0][1][5],&g_2482[0][1][5],&g_2482[0][1][5],&g_2482[0][1][5],&g_2482[0][1][5],&g_2482[0][1][5],&g_2482[0][1][5]};
                    int i;
                    for (l_6654 = (-22); (l_6654 > (-30)); l_6654 = safe_sub_func_int64_t_s_s(l_6654, 5))
                    { /* block id: 2799 */
                        uint8_t *l_6717[1][6][6] = {{{&g_657,&g_657,&g_2355,&g_657,&g_657,&g_2355},{&g_657,&g_657,&g_2355,&g_657,&g_657,&g_2355},{&g_657,&g_657,&g_2355,&g_657,&g_657,&g_2355},{&g_657,&g_657,&g_2355,&g_657,&g_657,&g_2355},{&g_657,&g_657,&g_2355,&g_657,&g_657,&g_2355},{&g_657,&g_657,&g_2355,&g_657,&g_657,&g_2355}}};
                        int32_t l_6718 = (-3L);
                        int i, j, k;
                        (*g_653) = (0xFBL > (p_140 | p_140));
                        if (l_6141)
                            goto lbl_6716;
                        l_6726 = (((((*g_5411) = (**g_4139)) <= (l_6719--)) != p_140) && (0xAFED3A1BL | ((****g_2718) = (l_6722 != (((*g_6119) = (safe_unary_minus_func_uint32_t_u(((safe_lshift_func_uint16_t_u_s(p_140, 10)) , ((**g_929) = l_6718))))) , (*g_4422))))));
                    }
                    g_2482[1][1][6] = ((safe_div_func_uint64_t_u_u((safe_sub_func_int64_t_s_s((safe_unary_minus_func_int64_t_s((+(0xA117L > ((0UL <= ((*g_6119) = ((safe_mod_func_uint16_t_u_u(l_6688, ((((safe_mul_func_int8_t_s_s((((safe_mul_func_int8_t_s_s(((safe_mul_func_int16_t_s_s(((safe_mul_func_uint8_t_u_u(l_6677, (safe_rshift_func_int8_t_s_s(0x37L, 0)))) != ((((safe_add_func_uint16_t_u_u((~(safe_mul_func_uint16_t_u_u((*g_715), ((l_6158 != (((*l_6755) = l_6754) == l_6756)) , (*g_5749))))), 2L)) <= (****g_2718)) != l_6031) <= p_140)), (*l_6046))) , (*l_6046)), p_140)) > l_6693[3][3]) > (*l_159)), p_140)) <= (*g_5749)) ^ l_164[0][0]) ^ l_6757[1]))) > (*l_159)))) , l_6692))))), 0xC0EAEFB107004314LL)), 0xFC7E25252442125DLL)) , &p_140);
                }
                (***g_2718) = &l_6161[1];
                (*****g_2717) = p_140;
                for (l_6692 = 8; (l_6692 <= (-11)); l_6692 = safe_sub_func_int16_t_s_s(l_6692, 8))
                { /* block id: 2817 */
                    int64_t * const ***l_6765 = (void*)0;
                    int64_t * const ***l_6766 = &l_6763[2];
                    uint32_t ***l_6772 = &g_4087;
                    int32_t l_6801 = 1L;
                    l_6687 = ((****g_2718) = ((&g_6440 != ((*l_6766) = l_6763[0])) & (safe_add_func_uint16_t_u_u((safe_add_func_uint64_t_u_u(((p_140 || (2L <= (((*l_6772) = l_6771) != (void*)0))) != (**g_4139)), (safe_mul_func_uint8_t_u_u(l_6687, (safe_div_func_int32_t_s_s((l_6194[6] != l_6777), (**g_929))))))), 0x3BA9L))));
                    l_6690 ^= ((0x6B99L & l_6780) ^ ((*l_159) = (safe_mul_func_int16_t_s_s((+((safe_mod_func_uint8_t_u_u((safe_unary_minus_func_uint64_t_u(((safe_mul_func_uint8_t_u_u((safe_rshift_func_int16_t_s_u(((((*l_6046) <= (safe_add_func_uint8_t_u_u((((*g_715) |= p_140) == (((safe_add_func_int64_t_s_s((*g_6119), (safe_div_func_int8_t_s_s((*l_159), ((**g_5410) = (((safe_rshift_func_int16_t_s_u(p_140, 4)) , l_6799) || (((+l_6692) & (*l_6046)) , (***g_4422)))))))) & p_140) | (-1L))), p_140))) , (-8L)) < 0x5724ED3C3F334305LL), 1)), (*l_159))) <= (***g_1676)))), l_6801)) & (*l_6046))), p_140))));
                    if (p_140)
                        break;
                }
            }
            else
            { /* block id: 2828 */
                int64_t **l_6806 = &l_6309[5];
                for (g_1273 = 0; (g_1273 == (-1)); g_1273--)
                { /* block id: 2831 */
                    (*g_653) ^= p_140;
                    for (g_4302 = (-17); (g_4302 < 23); g_4302 = safe_add_func_uint16_t_u_u(g_4302, 1))
                    { /* block id: 2835 */
                        int64_t ***l_6807 = &l_6806;
                        uint32_t *l_6808 = &g_1550;
                        (*l_6807) = l_6806;
                        return l_6808;
                    }
                }
                for (g_5044.f0 = 0; (g_5044.f0 == 28); g_5044.f0 = safe_add_func_int16_t_s_s(g_5044.f0, 1))
                { /* block id: 2842 */
                    return l_6046;
                }
                return (***l_6756);
            }
        }
    }
    else
    { /* block id: 2848 */
        int64_t l_6832 = 0L;
        int32_t l_6867 = 0x208FA6B9L;
        int16_t *****l_6869[3];
        union U2 *l_6876[6][6] = {{&g_6878[0][5],&g_6878[0][5],(void*)0,&g_6878[0][5],&g_6878[0][5],(void*)0},{&g_6878[0][5],&g_6878[0][5],(void*)0,&g_6878[0][5],&g_6878[0][5],(void*)0},{&g_6878[0][5],&g_6878[0][5],(void*)0,&g_6878[0][5],&g_6878[0][5],(void*)0},{&g_6878[0][5],&g_6878[0][5],(void*)0,&g_6878[0][5],&g_6878[0][5],(void*)0},{&g_6878[0][5],&g_6878[0][5],(void*)0,&g_6878[0][5],&g_6878[0][5],(void*)0},{&g_6878[0][5],&g_6878[0][5],(void*)0,&g_6878[0][5],&g_6878[0][5],(void*)0}};
        uint32_t l_6883 = 0x767A5039L;
        union U3 **l_6904 = &g_746;
        uint32_t *l_6909[6][5] = {{&l_6494[4][0],&l_6252,&l_6252,&l_6494[4][0],&g_5485},{&l_6494[4][0],&l_6494[2][0],&l_6401[5],&l_6401[5],&l_6494[2][0]},{&g_5485,&l_6252,&l_6401[5],&l_6401[5],&l_6401[5]},{&l_6252,&g_5485,&l_6252,&l_6401[5],&l_6401[5]},{&l_6494[2][0],&l_6494[4][0],&l_6401[5],&l_6494[4][0],&l_6494[2][0]},{&l_6252,&l_6494[4][0],&g_5485,&l_6494[2][0],&g_5485}};
        int i, j;
        for (i = 0; i < 3; i++)
            l_6869[i] = &g_4296;
        for (g_5490 = 0; (g_5490 <= 2); g_5490 += 1)
        { /* block id: 2851 */
            const uint16_t l_6831 = 1UL;
            int32_t l_6868 = 1L;
            union U2 *l_6880[6][1] = {{&g_6882},{&g_6882},{&g_6881},{&g_6882},{&g_6882},{&g_6881}};
            uint32_t *l_6886[1][3][7] = {{{&g_1020,&g_1020,&l_6401[6],&l_6401[6],&g_1020,&g_1020,&l_6401[6]},{&g_1020,&l_6401[5],&g_1020,&l_6401[5],&g_1020,&l_6401[5],&g_1020},{&g_1020,&l_6401[6],&l_6401[6],&g_1020,&g_1020,&l_6401[6],&l_6401[6]}}};
            int32_t l_6891 = 0x0B769FD1L;
            int64_t ****l_6898 = &g_6439[0][2];
            union U3 **l_6903 = &g_746;
            int i, j, k;
            for (g_260 = 0; (g_260 <= 3); g_260 += 1)
            { /* block id: 2854 */
                int32_t l_6830 = 2L;
                int32_t l_6844[8] = {(-1L),(-1L),1L,(-1L),(-1L),1L,(-1L),(-1L)};
                int32_t ** const l_6847 = &g_653;
                uint64_t l_6872 = 0xE135496E2679C2DELL;
                int i, j;
                (*l_159) = (safe_mul_func_int16_t_s_s(((safe_add_func_uint32_t_u_u(((((****g_2718) = p_140) == (g_6240 == ((safe_mod_func_uint8_t_u_u(((((0xA1L | ((safe_add_func_uint64_t_u_u((safe_div_func_uint8_t_u_u((safe_mod_func_uint32_t_u_u(((safe_add_func_uint16_t_u_u(((((**g_714)--) , (l_6830 = ((void*)0 != l_6827))) || ((p_140 <= (*g_715)) > ((**g_5410) = ((*l_159) ^ p_140)))), (***g_1676))) , p_140), l_6831)), p_140)), l_6832)) >= 0x338C4BEAL)) && p_140) > (*l_159)) >= l_6832), p_140)) , (void*)0))) | l_6831), g_6833)) , 0x51ABL), p_140));
                for (l_5893 = 0; (l_5893 <= 3); l_5893 += 1)
                { /* block id: 2862 */
                    int64_t ***l_6843 = &g_6440;
                    int32_t l_6848 = 0x7A365F87L;
                    int64_t ****l_6866 = &g_6439[8][2];
                    (**g_1207) = 0L;
                    l_6848 &= ((*l_159) |= (safe_sub_func_uint32_t_u_u(((((~((safe_rshift_func_int8_t_s_u(((safe_rshift_func_uint8_t_u_u((**g_4139), 7)) > (((**l_6847) = ((l_6844[6] = (safe_lshift_func_int8_t_s_u((l_6832 | ((*g_6119) = (-8L))), ((void*)0 == l_6843)))) <= ((*****g_5407) &= (safe_mul_func_int16_t_s_s(((&g_3344 != ((((void*)0 != l_6847) , p_140) , (void*)0)) , p_140), (**l_6847)))))) <= p_140)), 6)) | p_140)) , 0x7C8EL) || (*g_1678)) != (-3L)), 0x6CDAB66CL)));
                    l_6868 &= ((*g_653) = ((((l_6848 = p_140) && ((**g_929) = (safe_add_func_uint64_t_u_u((*g_1541), (safe_lshift_func_int8_t_s_u((safe_mod_func_uint64_t_u_u(((safe_sub_func_int8_t_s_s((safe_mod_func_int32_t_s_s((-1L), p_140)), 0xF3L)) ^ (l_6867 |= (safe_mul_func_int16_t_s_s((0xB6L < (~(safe_add_func_uint64_t_u_u(((1L & ((p_140 | (safe_sub_func_int8_t_s_s(((((*l_6866) = &g_6440) == (void*)0) , (*l_159)), (**g_5410)))) , p_140)) < 1UL), p_140)))), p_140)))), (**l_6847))), 4)))))) && 2L) || (**l_6847)));
                }
                for (g_4338 = 0; (g_4338 <= 2); g_4338 += 1)
                { /* block id: 2879 */
                    int i;
                    if ((l_6869[2] != &g_1675))
                    { /* block id: 2880 */
                        int64_t l_6870 = (-1L);
                        int32_t *l_6871[10] = {&g_7[2][5][1],(void*)0,&g_7[2][5][1],&g_7[2][5][1],(void*)0,&g_7[2][5][1],&g_7[2][5][1],(void*)0,&g_7[2][5][1],&g_7[2][5][1]};
                        int i;
                        l_6872++;
                    }
                    else
                    { /* block id: 2882 */
                        if (l_6872)
                            goto lbl_6875;
                    }
                    l_6880[5][0] = l_6876[5][5];
                    if ((0x6D073643F8A641CCLL && (**g_1540)))
                    { /* block id: 2886 */
                        (**l_6847) |= (0xF6L | (p_140 <= l_6867));
                    }
                    else
                    { /* block id: 2888 */
                        l_6883++;
                        (*l_159) |= (**g_1207);
                    }
                    (*l_159) = p_140;
                }
            }
            (*l_159) |= 0xD1701CB2L;
            if (p_140)
            { /* block id: 2896 */
                uint32_t *l_6887 = &l_6401[5];
                return (*g_929);
            }
            else
            { /* block id: 2898 */
                for (g_6580.f3 = 0; (g_6580.f3 <= 2); g_6580.f3 += 1)
                { /* block id: 2901 */
                    uint32_t l_6893 = 4294967295UL;
                    if (l_6657)
                        goto lbl_6875;
                    for (l_6615 = 0; (l_6615 <= 2); l_6615 += 1)
                    { /* block id: 2905 */
                        int32_t *l_6888 = (void*)0;
                        int32_t *l_6889 = &l_6140;
                        int32_t *l_6890[7] = {&g_7[2][5][1],&g_7[2][5][1],&g_3420[3],&g_7[2][5][1],&g_7[2][5][1],&g_3420[3],&g_7[2][5][1]};
                        int8_t l_6892 = 0x77L;
                        int i;
                        (*****g_2717) &= l_6867;
                        l_6893++;
                        if (p_140)
                            continue;
                    }
                }
            }
            for (g_6586.f3 = 2; (g_6586.f3 >= 0); g_6586.f3 -= 1)
            { /* block id: 2914 */
                int32_t l_6908 = 0x32C80832L;
                (*****g_2717) &= 0x572F57C8L;
                (*l_159) = (p_140 <= ((((*g_6119) <= (safe_lshift_func_int16_t_s_u((l_6867 = ((((void*)0 == l_6898) && l_6867) != ((*g_653) = (((((((safe_sub_func_uint32_t_u_u((safe_sub_func_uint8_t_u_u((((**l_6827) = l_6903) != l_6904), l_6883)), (safe_mul_func_uint8_t_u_u(((+l_6908) | p_140), 0xD6L)))) | 0UL) , 0x993145FDL) , (****g_1675)) > p_140) != (*l_159)) >= (*l_159))))), 6))) , p_140) >= 1UL));
                return (*g_929);
            }
        }
        for (l_6141 = 0; (l_6141 < (-14)); --l_6141)
        { /* block id: 2925 */
            if ((*****g_2717))
                break;
        }
    }
    if (((p_140 < (safe_sub_func_uint8_t_u_u((safe_mod_func_uint16_t_u_u(0xE794L, (l_6141 = (safe_rshift_func_uint16_t_u_s(((p_140 || p_140) > (((((safe_sub_func_uint8_t_u_u(0x15L, ((p_140 == (p_140 >= (safe_add_func_int64_t_s_s(p_140, ((safe_unary_minus_func_int16_t_s((safe_add_func_int16_t_s_s((*g_1678), p_140)))) , (*g_1541)))))) && p_140))) , &l_5946[1]) == &l_5946[3]) > p_140) && l_6925)), 8))))), (-6L)))) & 2UL))
    { /* block id: 2930 */
        int32_t l_6957 = 0x8C22290CL;
        uint8_t l_6962 = 249UL;
        int32_t l_6963 = 0x0AEB9EB8L;
        int64_t **l_6964 = &l_6308[0];
        uint32_t *l_6965 = &l_6401[5];
        const uint8_t *l_7001 = &g_1446[1];
        const uint8_t **l_7000 = &l_7001;
        int32_t ** const *l_7040 = &g_1207;
        int32_t ** const **l_7039[7];
        int32_t ** const ***l_7038 = &l_7039[3];
        int16_t *l_7077 = (void*)0;
        int16_t *l_7078 = &g_232;
        uint8_t l_7081[7];
        int16_t *l_7082 = (void*)0;
        int16_t *l_7083[2][2][2];
        uint64_t l_7085 = 0x0684AA7EDBA26709LL;
        uint32_t l_7087 = 4294967295UL;
        int i, j, k;
        for (i = 0; i < 7; i++)
            l_7039[i] = &l_7040;
        for (i = 0; i < 7; i++)
            l_7081[i] = 1UL;
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 2; j++)
            {
                for (k = 0; k < 2; k++)
                    l_7083[i][j][k] = &g_5420;
            }
        }
        for (g_845 = 3; (g_845 >= 0); g_845 -= 1)
        { /* block id: 2933 */
            uint8_t l_6954 = 0x2AL;
            int32_t l_6958 = 4L;
            int32_t l_6959 = 9L;
            int32_t l_6961 = 0x3834C352L;
            int16_t l_6979 = 0x4575L;
            int64_t *l_6998 = &g_5048.f0;
            uint32_t **l_7019 = (void*)0;
            for (g_1217 = 0; (g_1217 <= 4); g_1217 += 1)
            { /* block id: 2936 */
                int16_t l_6960 = (-10L);
                int32_t l_6974 = 1L;
                int32_t ****l_6980[8][3] = {{(void*)0,&g_4095,&g_4095},{&g_4095,&g_4095,&g_4095},{(void*)0,(void*)0,&g_4095},{&g_4095,&g_4095,&g_4095},{&g_4095,(void*)0,(void*)0},{&g_4095,&g_4095,&g_4095},{&g_4095,&g_4095,&g_4095},{&g_4095,&g_4095,&g_4095}};
                uint8_t **l_6999 = &g_656;
                int64_t *l_7053[10][9] = {{(void*)0,&g_3792.f0,(void*)0,&g_2386.f0,&g_2386.f0,&g_1273,(void*)0,&g_5044.f0,(void*)0},{&g_5044.f0,(void*)0,(void*)0,&g_5761,&g_2857.f0,&g_1847,&g_539[2],&g_5048.f0,&g_2857.f0},{&g_2857.f0,(void*)0,&g_3792.f0,&g_1273,&g_3792.f0,&g_1273,&g_3792.f0,(void*)0,&g_2857.f0},{&g_539[2],&g_3792.f0,&g_1847,(void*)0,&g_5761,&g_5044.f0,&g_1273,&g_845,&g_5100.f0},{&g_5761,(void*)0,&g_5048.f0,&g_5761,&g_2857.f0,&g_845,&g_1071.f0,&g_2857.f0,&g_5048.f0},{&g_539[2],&g_5761,&g_1273,&g_5044.f0,&g_1847,&g_1071.f0,&g_2386.f0,&g_1071.f0,&g_2386.f0},{&g_2857.f0,&g_539[2],&g_2386.f0,&g_2386.f0,&g_845,(void*)0,&g_1273,&g_2386.f0,&g_2386.f0},{&g_5044.f0,&g_5048.f0,&g_2857.f0,&g_2857.f0,&g_2857.f0,&g_5048.f0,&g_5044.f0,&g_5044.f0,&g_5048.f0},{(void*)0,&g_2386.f0,&g_2857.f0,&g_3792.f0,(void*)0,&g_5761,(void*)0,&g_5048.f0,&g_5100.f0},{&g_845,&g_5048.f0,&g_5048.f0,(void*)0,&g_1273,&g_2386.f0,&g_5048.f0,&g_5044.f0,&g_2857.f0}};
                int i, j;
                if ((((safe_mod_func_int8_t_s_s(((((safe_sub_func_uint16_t_u_u(0x3D79L, (p_140 , p_140))) , (*****g_1674)) , (safe_div_func_uint64_t_u_u(((safe_lshift_func_int16_t_s_s((safe_div_func_int32_t_s_s((safe_lshift_func_uint16_t_u_u((l_6963 = (((((safe_div_func_uint8_t_u_u(((-1L) && p_140), ((*g_656) = ((****g_5408) |= (safe_add_func_int16_t_s_s(((l_6961 &= (((+((safe_rshift_func_uint8_t_u_u((((safe_unary_minus_func_uint32_t_u(((safe_div_func_int32_t_s_s((safe_rshift_func_int16_t_s_u((l_6959 ^= (safe_add_func_int8_t_s_s((safe_rshift_func_uint16_t_u_u(l_6954, (**g_714))), (l_6958 &= (safe_mod_func_uint8_t_u_u((*g_656), l_6957)))))), 7)), 4294967291UL)) & 0xB65318595A5256FCLL))) && p_140) <= p_140), l_6960)) ^ l_6957)) , l_6957) || p_140)) ^ l_6962), 0UL)))))) , l_6957) | l_6962) , p_140) , l_6957)), l_6960)), l_6954)), l_6960)) || l_6963), p_140))) | p_140), p_140)) < p_140) >= 0x40EE011CL))
                { /* block id: 2943 */
                    l_6964 = l_6964;
                    return (*g_929);
                }
                else
                { /* block id: 2946 */
                    int16_t l_6975 = (-6L);
                    l_6959 = (l_6961 = ((((safe_mul_func_int8_t_s_s(0xF6L, 0L)) > p_140) && (((**g_5410)++) >= (safe_rshift_func_uint8_t_u_u(((~(l_6974 = (~p_140))) < l_6954), 6)))) & (p_140 , l_6975)));
                }
                if ((safe_rshift_func_uint16_t_u_s(((~l_6979) >= p_140), ((void*)0 != l_6980[6][0]))))
                { /* block id: 2952 */
                    int32_t l_6996 = (-6L);
                    int32_t l_6997[6];
                    int i;
                    for (i = 0; i < 6; i++)
                        l_6997[i] = 0xB5AE31DBL;
                    l_6997[5] = (p_140 , (safe_mul_func_uint16_t_u_u((l_6963 == ((**g_929) &= p_140)), ((((*g_1541) |= p_140) > 0UL) & (safe_rshift_func_int16_t_s_u(p_140, (+(l_6974 = (safe_div_func_uint8_t_u_u(p_140, (safe_sub_func_uint32_t_u_u((safe_mod_func_int16_t_s_s((-5L), ((safe_mul_func_uint8_t_u_u(((l_6996 = ((safe_rshift_func_int8_t_s_s(l_6974, p_140)) , l_6140)) == 0x7385L), 0UL)) | p_140))), l_6962))))))))))));
                    if ((l_6958 < l_6957))
                    { /* block id: 2958 */
                        const uint8_t ***l_7002[5][4] = {{&l_7000,&l_7000,&l_7000,&l_7000},{&l_7000,&l_7000,&l_7000,&l_7000},{&l_7000,&l_7000,&l_7000,&l_7000},{&l_7000,&l_7000,&l_7000,&l_7000},{&l_7000,&l_7000,&l_7000,&l_7000}};
                        int32_t l_7003[1];
                        int i, j;
                        for (i = 0; i < 1; i++)
                            l_7003[i] = (-1L);
                        l_7003[0] = ((*g_1678) ^ ((((void*)0 != l_6998) , l_6999) == (l_7000 = l_7000)));
                    }
                    else
                    { /* block id: 2961 */
                        int32_t l_7010 = 0xE9AA7C54L;
                        l_7010 ^= ((safe_rshift_func_int8_t_s_s((g_4118[5] = l_6957), 3)) <= ((safe_rshift_func_int16_t_s_u((safe_lshift_func_uint16_t_u_u(6UL, 1)), 3)) < (***g_4422)));
                        l_6961 |= p_140;
                    }
                    l_6963 = 0xD4612570L;
                    l_6250 = (safe_rshift_func_int8_t_s_s((1L ^ ((((((safe_rshift_func_int16_t_s_u(l_6959, ((safe_div_func_uint64_t_u_u(p_140, (safe_div_func_int16_t_s_s((l_6997[5] == ((l_6954 , ((((*l_6965) &= 0xE8D8F5CFL) >= ((p_140 >= 0x3BL) < (&l_6965 != l_7019))) && l_6963)) && (-1L))), l_6960)))) < 1UL))) , p_140) || p_140) > l_6974) > p_140) <= (****g_1675))), p_140));
                }
                else
                { /* block id: 2969 */
                    uint16_t l_7020 = 65533UL;
                    union U2 *l_7023 = &g_7024;
                    union U2 **l_7025 = &l_7023;
                    l_7020--;
                    (*l_7025) = l_7023;
                    return (*g_929);
                }
                for (g_255 = 0; (g_255 <= 0); g_255 += 1)
                { /* block id: 2976 */
                    const int32_t **l_7037[6][2] = {{&g_2482[0][2][3],&g_2482[0][2][3]},{(void*)0,&g_2482[0][2][3]},{&g_2482[0][2][3],(void*)0},{&g_2482[0][2][3],&g_2482[0][2][3]},{(void*)0,&g_2482[0][2][3]},{&g_2482[0][2][3],(void*)0}};
                    const int32_t ***l_7036 = &l_7037[3][1];
                    const int32_t ****l_7035 = &l_7036;
                    const int32_t *****l_7034 = &l_7035;
                    int16_t l_7055 = 5L;
                    int i, j;
                    g_499[(g_255 + 1)][g_255] |= p_140;
                    for (g_1920.f1 = 0; (g_1920.f1 <= 0); g_1920.f1 += 1)
                    { /* block id: 2980 */
                        const uint32_t l_7028 = 0xA89825FBL;
                        int64_t **l_7050 = &g_6119;
                        int32_t l_7054 = 0x71AA41C6L;
                        int i;
                        g_499[(g_255 + 1)][g_255] = (safe_add_func_int32_t_s_s(l_7028, (safe_add_func_int16_t_s_s(((l_7054 &= (safe_div_func_int64_t_s_s(((*l_6998) ^= ((+((l_7034 == (l_7041 = l_7038)) , ((safe_mod_func_uint64_t_u_u(((safe_mul_func_int8_t_s_s((safe_sub_func_int32_t_s_s((((*l_7050) = ((*l_6964) = func_314((**g_5410), g_4088[g_1920.f1]))) != (l_7053[1][5] = func_238(&p_140, (0xB4L ^ (safe_div_func_int64_t_s_s((6L != (-1L)), p_140))), (*g_5411)))), l_7028)), 0xA6L)) < 2UL), l_6958)) < p_140))) == 0L)), 0xBA96D81CC52A9BE7LL))) < l_7055), 2L))));
                    }
                }
            }
            for (g_6587.f3 = 0; (g_6587.f3 <= 0); g_6587.f3 += 1)
            { /* block id: 2993 */
                int16_t l_7072 = 0x35F5L;
                uint64_t l_7073 = 0UL;
                l_6959 = (l_7073 = (((safe_lshift_func_int16_t_s_s(l_7058, p_140)) <= ((**g_1540) , ((safe_div_func_int16_t_s_s((safe_sub_func_int64_t_s_s((safe_add_func_uint16_t_u_u(p_140, (safe_sub_func_int16_t_s_s((safe_unary_minus_func_int16_t_s(((safe_mul_func_int8_t_s_s(0xFEL, (((safe_add_func_int32_t_s_s(0xD7E848C2L, (&l_6954 != ((p_140 < (((4294967291UL > 9UL) | p_140) <= 7L)) , (*l_7000))))) != 0L) , p_140))) < (*g_28)))), (*g_1678))))), p_140)), 0x17B1L)) ^ l_6958))) <= l_7072));
                l_6959 &= p_140;
            }
        }
        l_7086 |= ((safe_div_func_uint16_t_u_u(p_140, g_7076)) >= (((l_7085 ^= ((((*l_6828) == (void*)0) & ((*l_7078) &= p_140)) > ((l_7084 ^= ((p_140 != 3UL) & (safe_add_func_int32_t_s_s(p_140, l_7081[3])))) && 0x7857L))) > 0x7BFAD8B9L) & 0xDDL));
        g_7088 = l_7087;
        l_7089--;
    }
    else
    { /* block id: 3005 */
        uint8_t l_7094 = 0UL;
        struct S1 *l_7097 = &g_7098[4];
        int32_t l_7099 = 0xFAD7468CL;
        l_7092 = l_7092;
        l_7094 &= p_140;
        l_7099 ^= (((l_7094 , (g_7095 = g_7095)) != l_7097) | 0x42L);
    }
    return l_7100[8];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint32_t  func_141(int16_t  p_142, int8_t  p_143)
{ /* block id: 32 */
    return p_143;
}


/* ------------------------------------------ */
/* 
 * reads : g_163 g_929 g_930 g_446 g_66 g_2718 g_2719 g_1207 g_653 g_2717 g_499 g_3643 l_10805
 * writes: g_163 g_4118 g_499 l_10805
 */
static uint32_t  func_182(uint8_t  p_183, uint64_t  p_184, uint8_t  p_185, const int16_t * const  p_186)
{ /* block id: 50 */
    uint16_t l_191[8] = {4UL,4UL,4UL,4UL,4UL,4UL,4UL,4UL};
    uint32_t l_207 = 18446744073709551613UL;
    uint32_t *l_215[7] = {&g_66,&g_66,&g_66,&g_66,&g_66,&g_66,&g_66};
    uint32_t **l_214 = &l_215[0];
    uint16_t l_5321 = 0x528EL;
    int16_t *l_5323[4];
    int32_t l_5866 = (-4L);
    uint64_t *l_5869 = &g_998;
    uint32_t l_5880 = 0x7514FFA5L;
    int i;
    for (i = 0; i < 4; i++)
        l_5323[i] = &g_2[7][3][2];
    for (g_163 = 0; (g_163 <= 7); g_163 += 1)
    { /* block id: 53 */
        uint8_t *l_213 = (void*)0;
        int32_t l_5320 = 0xF975B775L;
        const int32_t *l_5324 = &g_163;
        int8_t l_5871 = 1L;
        int32_t l_5872[1][10] = {{0xBD4E14EDL,1L,0xBD4E14EDL,1L,0xBD4E14EDL,1L,0xBD4E14EDL,1L,0xBD4E14EDL,1L}};
        union U5 **l_5887[1][9] = {{&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070}};
        int64_t *l_5890 = (void*)0;
        int64_t *l_5891[1][10][5] = {{{(void*)0,&g_2386.f0,&g_2386.f0,(void*)0,(void*)0},{&g_5044.f0,&g_1273,&g_1071.f0,&g_1273,&g_5044.f0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_1847,&g_5100.f0,(void*)0,(void*)0,(void*)0},{(void*)0,&g_2386.f0,(void*)0,(void*)0,(void*)0},{&g_1071.f0,(void*)0,&g_1071.f0,&g_5100.f0,&g_539[1]},{(void*)0,&g_845,(void*)0,&g_2386.f0,&g_845},{&g_1847,(void*)0,&g_5044.f0,(void*)0,&g_1847},{&g_845,&g_2386.f0,(void*)0,&g_845,(void*)0},{&g_539[1],&g_5100.f0,&g_1071.f0,(void*)0,&g_1071.f0}}};
        int8_t *l_5892 = &g_4118[2];
        int i, j, k;
        for (p_184 = 0; (p_184 <= 7); p_184 += 1)
        { /* block id: 56 */
            int64_t *l_195 = &g_196;
            int8_t *l_5322[4][1];
            int32_t l_5870 = (-1L);
            int32_t *l_5873 = (void*)0;
            int32_t *l_5874 = &l_5870;
            int32_t *l_5875 = &g_499[1][0];
            int32_t *l_5876 = (void*)0;
            int32_t *l_5877 = &g_499[0][0];
            int32_t *l_5878 = &g_499[2][0];
            int32_t *l_5879 = &l_5866;
            int i, j;
            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 1; j++)
                    l_5322[i][j] = &g_2886;
            }
        }
        (****g_2718) = (((0xFBL == (safe_div_func_uint32_t_u_u((((*l_5892) = ((safe_div_func_uint16_t_u_u((((**g_929) , &g_3567[1][1]) != l_5887[0][4]), ((l_5866 = (l_5866 != (safe_rshift_func_int8_t_s_s((*l_5324), l_5866)))) || ((p_185 , (l_5321 < p_184)) || 65528UL)))) > p_184)) || (*l_5324)), (*l_5324)))) || 0xC5L) , 0x5CFD4A28L);
        if ((*****g_2717))
            break;
    }
    l_5866 = (-4L);
    return p_184;
}


/* ------------------------------------------ */
/* 
 * reads : g_5411 g_3870 g_1540 g_1541 g_998
 * writes: g_3529.f0 g_998
 */
static int8_t  func_192(int64_t  p_193, int16_t  p_194)
{ /* block id: 2501 */
    int32_t l_5848 = 1L;
    int64_t *l_5857 = &g_3529.f0;
    int8_t ****l_5858[1][8][7] = {{{&g_4422,&g_4422,&g_4422,&g_4422,&g_4422,&g_4422,&g_4422},{&g_4422,&g_4422,&g_4422,&g_4422,&g_4422,&g_4422,&g_4422},{&g_4422,&g_4422,&g_4422,&g_4422,&g_4422,&g_4422,&g_4422},{&g_4422,&g_4422,&g_4422,&g_4422,&g_4422,&g_4422,&g_4422},{&g_4422,&g_4422,&g_4422,&g_4422,&g_4422,&g_4422,&g_4422},{&g_4422,&g_4422,&g_4422,&g_4422,&g_4422,&g_4422,&g_4422},{&g_4422,&g_4422,&g_4422,&g_4422,&g_4422,&g_4422,&g_4422},{&g_4422,&g_4422,&g_4422,&g_4422,&g_4422,&g_4422,&g_4422}}};
    int32_t l_5861 = 0xB376B644L;
    uint32_t l_5862 = 0x0134A6C7L;
    int32_t l_5863 = (-8L);
    int32_t l_5864 = 0xBFD1AD01L;
    int32_t l_5865 = (-1L);
    int i, j, k;
    l_5864 = ((safe_lshift_func_int8_t_s_s(((l_5848 != (safe_rshift_func_uint8_t_u_u((((safe_mul_func_uint16_t_u_u(p_194, ((l_5862 ^= (p_193 != (((safe_rshift_func_uint8_t_u_u((*g_5411), 1)) , (((safe_sub_func_int64_t_s_s(((*l_5857) = p_193), ((*g_1541) = (**g_1540)))) , (l_5861 = (((void*)0 != l_5858[0][1][0]) > (safe_rshift_func_uint8_t_u_u((((8UL <= p_194) || 0x98L) , p_194), p_194))))) != l_5848)) & l_5848))) != l_5863))) || (-9L)) > p_194), 1))) || p_194), 7)) > p_193);
    return l_5865;
}


/* ------------------------------------------ */
/* 
 * reads : g_3643 g_922.f1 g_845 g_2 g_4139 g_656 g_495 g_657 g_255 g_4296 g_1029 g_1030 g_1675 g_1676 g_1677 g_1847 g_499 g_232 g_4422 g_4423 g_28 g_1621 g_29
 * writes: g_3643 g_922.f1 g_845 g_723 g_4882 g_1847 g_232
 */
static int8_t  func_197(uint32_t  p_198, int16_t * p_199, int32_t  p_200, const int32_t * p_201)
{ /* block id: 2254 */
    int16_t l_5326 = 0L;
    int32_t l_5328[6];
    uint8_t l_5341 = 0x03L;
    int16_t ****l_5360 = (void*)0;
    uint16_t l_5423 = 65535UL;
    union U5 **l_5435 = &g_1070;
    union U5 ***l_5434[9] = {&l_5435,&l_5435,&l_5435,&l_5435,&l_5435,&l_5435,&l_5435,&l_5435,&l_5435};
    uint8_t l_5470 = 0xCAL;
    const int64_t *l_5472[4][7][1] = {{{&g_1273},{&g_5044.f0},{&g_539[1]},{(void*)0},{&g_539[1]},{&g_5044.f0},{&g_1273}},{{&g_5044.f0},{&g_539[1]},{(void*)0},{&g_539[1]},{&g_5044.f0},{&g_1273},{&g_5044.f0}},{{&g_539[1]},{(void*)0},{&g_539[1]},{&g_5044.f0},{&g_1273},{&g_5044.f0},{&g_539[1]}},{{(void*)0},{&g_539[1]},{&g_5044.f0},{&g_1273},{&g_5044.f0},{&g_539[1]},{(void*)0}}};
    struct S1 *l_5482 = &g_5483;
    struct S1 **l_5481[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
    struct S1 ***l_5480 = &l_5481[2];
    int32_t l_5495 = 0x32E880E5L;
    int32_t *l_5640[8][5] = {{&g_255,&g_3,&g_3,&g_255,&l_5328[4]},{&g_8,&g_255,&g_7[5][0][0],&g_255,&g_255},{&g_7[2][5][1],&g_255,&g_7[2][5][1],&l_5328[4],&g_255},{&g_255,&g_3,&l_5328[4],&g_255,&l_5328[4]},{&g_255,&g_255,&g_7[5][0][0],&g_255,&g_8},{&g_7[2][5][1],&g_8,&l_5328[4],&l_5328[4],&g_8},{&g_8,&g_3,&g_7[2][5][1],&g_8,&l_5328[4]},{&g_255,&g_8,&g_7[5][0][0],&g_8,&g_255}};
    int32_t * const *l_5681[7][10] = {{&l_5640[3][4],(void*)0,&l_5640[3][4],(void*)0,(void*)0,(void*)0,(void*)0,&l_5640[3][4],(void*)0,&l_5640[3][4]},{&l_5640[3][4],&l_5640[5][3],(void*)0,&g_653,&l_5640[2][4],&l_5640[3][4],&g_653,&g_653,&l_5640[3][4],&l_5640[2][4]},{&l_5640[3][4],&g_653,&g_653,&l_5640[3][4],&l_5640[2][4],(void*)0,&l_5640[2][4],&l_5640[3][4],&g_653,&g_653},{&l_5640[2][4],&g_653,(void*)0,(void*)0,(void*)0,(void*)0,&g_653,&l_5640[2][4],&g_653,(void*)0},{(void*)0,&l_5640[3][4],(void*)0,&l_5640[3][4],(void*)0,(void*)0,(void*)0,(void*)0,&l_5640[3][4],(void*)0},{&l_5640[2][4],&l_5640[2][4],(void*)0,(void*)0,&l_5640[5][3],(void*)0,(void*)0,&l_5640[2][4],&l_5640[2][4],(void*)0},{&l_5640[3][4],(void*)0,(void*)0,(void*)0,(void*)0,&l_5640[3][4],(void*)0,&l_5640[3][4],(void*)0,(void*)0}};
    int32_t * const **l_5680 = &l_5681[1][6];
    int32_t * const ***l_5679 = &l_5680;
    int32_t * const ****l_5678 = &l_5679;
    uint32_t ***l_5685 = &g_929;
    uint64_t * const ****l_5777 = (void*)0;
    int32_t **l_5826 = &g_4097;
    int i, j, k;
    for (i = 0; i < 6; i++)
        l_5328[i] = 9L;
    for (g_3643 = 0; (g_3643 <= 2); g_3643 += 1)
    { /* block id: 2257 */
        int32_t *l_5325 = &g_255;
        int32_t *l_5327 = &g_3307;
        int32_t *l_5329 = (void*)0;
        int32_t *l_5330 = &g_3420[1];
        int32_t *l_5331 = &g_255;
        int32_t *l_5332 = (void*)0;
        int32_t *l_5333 = &g_4882;
        int32_t l_5334 = 0x51D326F6L;
        int32_t *l_5335 = &g_499[0][0];
        int32_t *l_5336 = &g_255;
        int32_t *l_5337 = &g_3420[2];
        int32_t *l_5338 = &g_3420[1];
        int32_t *l_5339[7][7][5] = {{{&g_255,&g_38,&g_3,&g_38,&g_255},{&g_8,&l_5328[0],&g_8,&g_8,&l_5328[0]},{&g_255,&g_4882,&g_7[6][0][0],&g_38,&g_7[6][0][0]},{&l_5328[0],&l_5328[0],(void*)0,&l_5328[0],&l_5328[0]},{&g_7[6][0][0],&g_38,&g_7[6][0][0],&g_4882,&g_255},{&l_5328[0],&g_8,&g_8,&l_5328[0],&g_8},{&g_255,&g_38,&g_3,&g_38,&g_255}},{{&g_8,&l_5328[0],&g_8,&g_8,&l_5328[0]},{&g_255,&g_4882,&g_7[6][0][0],&g_38,&g_7[6][0][0]},{&l_5328[0],&l_5328[0],(void*)0,&l_5328[0],&l_5328[0]},{&g_7[6][0][0],&g_38,&g_7[6][0][0],&g_4882,&g_255},{&l_5328[0],&g_8,&g_8,&l_5328[0],&g_8},{&g_255,&g_38,&g_3,&g_38,&g_255},{&g_8,&l_5328[0],&g_8,&g_8,&l_5328[0]}},{{&g_255,&g_4882,&g_7[6][0][0],&g_38,&g_7[6][0][0]},{&l_5328[0],&l_5328[0],(void*)0,&l_5328[0],&l_5328[0]},{&g_7[6][0][0],&g_38,&g_7[6][0][0],&g_4882,&g_255},{&l_5328[0],&g_8,&g_8,&l_5328[0],&g_8},{&g_255,&g_38,&g_3,&g_38,&g_255},{&g_8,&l_5328[0],&g_8,&g_8,&l_5328[0]},{&g_255,&g_4882,&g_7[6][0][0],&g_38,&g_7[6][0][0]}},{{&l_5328[0],&l_5328[0],(void*)0,&l_5328[0],&l_5328[0]},{&g_7[6][0][0],&g_38,&g_7[6][0][0],&g_4882,&g_255},{&l_5328[0],&g_8,&g_8,&l_5328[0],&g_8},{&g_255,&g_38,&g_3,&g_38,&g_255},{&g_8,&l_5328[0],&g_8,&g_8,&l_5328[0]},{&g_255,&g_4882,&g_7[6][0][0],&g_38,&g_3},{&g_8,&g_8,&l_5328[0],&g_8,&g_8}},{{&g_3,&g_4882,&g_3,&l_5328[3],&g_7[6][0][0]},{&g_8,(void*)0,(void*)0,&g_8,(void*)0},{&g_7[6][0][0],&g_4882,&g_255,&g_4882,&g_7[6][0][0]},{(void*)0,&g_8,(void*)0,(void*)0,&g_8},{&g_7[6][0][0],&l_5328[3],&g_3,&g_4882,&g_3},{&g_8,&g_8,&l_5328[0],&g_8,&g_8},{&g_3,&g_4882,&g_3,&l_5328[3],&g_7[6][0][0]}},{{&g_8,(void*)0,(void*)0,&g_8,(void*)0},{&g_7[6][0][0],&g_4882,&g_255,&g_4882,&g_7[6][0][0]},{(void*)0,&g_8,(void*)0,(void*)0,&g_8},{&g_7[6][0][0],&l_5328[3],&g_3,&g_4882,&g_3},{&g_8,&g_8,&l_5328[0],&g_8,&g_8},{&g_3,&g_4882,&g_3,&l_5328[3],&g_7[6][0][0]},{&g_8,(void*)0,(void*)0,&g_8,(void*)0}},{{&g_7[6][0][0],&g_4882,&g_255,&g_4882,&g_7[6][0][0]},{(void*)0,&g_8,(void*)0,(void*)0,&g_8},{&g_7[6][0][0],&l_5328[3],&g_3,&g_4882,&g_3},{&g_8,&g_8,&l_5328[0],&g_8,&g_8},{&g_3,&g_4882,&g_3,&l_5328[3],&g_7[6][0][0]},{&g_8,(void*)0,(void*)0,&g_8,(void*)0},{&g_7[6][0][0],&g_4882,&g_255,&g_4882,&g_7[6][0][0]}}};
        int32_t l_5340 = 0xFA7DB854L;
        uint8_t *****l_5346 = (void*)0;
        int32_t l_5363 = 0x40576B59L;
        uint8_t ** const *l_5406[4][3][8] = {{{&g_4139,&g_4139,(void*)0,(void*)0,&g_4139,&g_4139,&g_4139,&g_4139},{&g_4139,&g_4139,(void*)0,(void*)0,&g_4139,&g_4139,&g_4139,&g_4139},{&g_4139,&g_4139,(void*)0,(void*)0,&g_4139,&g_4139,&g_4139,&g_4139}},{{&g_4139,&g_4139,(void*)0,(void*)0,&g_4139,&g_4139,&g_4139,&g_4139},{&g_4139,&g_4139,(void*)0,(void*)0,&g_4139,&g_4139,&g_4139,&g_4139},{&g_4139,&g_4139,(void*)0,(void*)0,&g_4139,&g_4139,&g_4139,&g_4139}},{{&g_4139,&g_4139,(void*)0,(void*)0,&g_4139,&g_4139,&g_4139,&g_4139},{&g_4139,&g_4139,(void*)0,(void*)0,&g_4139,&g_4139,&g_4139,&g_4139},{&g_4139,&g_4139,(void*)0,(void*)0,&g_4139,&g_4139,&g_4139,&g_4139}},{{&g_4139,&g_4139,(void*)0,(void*)0,&g_4139,&g_4139,&g_4139,&g_4139},{&g_4139,&g_4139,(void*)0,(void*)0,&g_4139,&g_4139,&g_4139,&g_4139},{&g_4139,&g_4139,(void*)0,(void*)0,&g_4139,&g_4139,&g_4139,&g_4139}}};
        uint8_t ** const **l_5405 = &l_5406[0][0][3];
        uint8_t ** const ***l_5404 = &l_5405;
        union U5 **l_5433[6] = {&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070};
        union U5 ***l_5432 = &l_5433[0];
        uint32_t l_5451 = 1UL;
        uint64_t l_5469 = 0xCC1DA93C1EDF3ADFLL;
        uint16_t *****l_5471 = &g_3054;
        int8_t *l_5548 = &g_2886;
        uint64_t l_5550 = 0x93FD8A0C7B91B5B4LL;
        int16_t l_5631 = 0x8B00L;
        uint32_t ***l_5643 = &g_929;
        union U4 ** const *l_5650[6][6][2];
        int32_t l_5670 = 0x43074138L;
        uint64_t **l_5728 = &g_4583[3];
        uint8_t l_5809 = 0xBBL;
        int32_t **l_5825 = &g_4097;
        struct S1 ***l_5830 = &l_5481[2];
        int16_t ****l_5833 = &g_1029;
        int32_t l_5836 = (-7L);
        int8_t l_5840 = 3L;
        uint32_t l_5843 = 5UL;
        int i, j, k;
        for (i = 0; i < 6; i++)
        {
            for (j = 0; j < 6; j++)
            {
                for (k = 0; k < 2; k++)
                    l_5650[i][j][k] = &g_2302;
            }
        }
        l_5341--;
        for (g_922.f1 = 3; (g_922.f1 <= 8); g_922.f1 += 1)
        { /* block id: 2261 */
            int64_t *l_5349 = &g_845;
            int32_t l_5361[3][2] = {{2L,0x9BC0EEE4L},{0x9BC0EEE4L,2L},{0x9BC0EEE4L,0x9BC0EEE4L}};
            int16_t *l_5362 = &g_723;
            int16_t l_5390 = 0x1683L;
            uint8_t *l_5391 = &g_1727;
            int64_t l_5488 = 0xEDA9D10F737A74D5LL;
            uint32_t l_5520 = 0UL;
            int16_t l_5597 = 0x7C3AL;
            int32_t l_5629 = 0xBC566254L;
            uint64_t l_5630 = 4UL;
            int i, j;
            l_5361[0][1] = ((*l_5333) = (safe_rshift_func_int16_t_s_s(((*l_5362) = (((((((l_5328[4] &= (l_5346 == (void*)0)) <= ((safe_lshift_func_uint16_t_u_s(l_5326, (((*l_5349) |= 0xAFADE91FDDA6B179LL) <= (safe_mul_func_int16_t_s_s(((safe_sub_func_int16_t_s_s((p_200 && (0x48L > (safe_unary_minus_func_int64_t_s(((safe_sub_func_uint64_t_u_u(0xDCFB84F57BC19260LL, (safe_lshift_func_int16_t_s_s((((((((!(*p_199)) & 0x2A2D73B8AE9C4D85LL) , (**g_4139)) >= p_198) , l_5360) == l_5360) != p_200), (*p_199))))) == 0x8D36127827905696LL))))), (*p_199))) | (-5L)), 0UL))))) , p_198)) , (*l_5336)) , (**g_4296)) != (**g_1675)) & 0x7215L) ^ l_5361[1][0])), l_5363)));
            for (g_1847 = 0; (g_1847 <= 0); g_1847 += 1)
            { /* block id: 2269 */
                int i, j;
                if (g_499[g_3643][g_1847])
                    break;
            }
        }
        for (g_232 = 2; (g_232 >= 0); g_232 -= 1)
        { /* block id: 2393 */
            int16_t l_5632 = (-3L);
            int32_t l_5646 = 0x996CA1F8L;
            int32_t ****l_5729 = &g_2719[0][1];
            const uint16_t *****l_5744 = (void*)0;
            union U4 ** const l_5781 = &g_1168[9];
            union U3 **l_5808 = &g_746;
            union U3 ***l_5807 = &l_5808;
            union U3 **** const l_5806 = &l_5807;
            union U3 **** const *l_5805[4][8] = {{&l_5806,&l_5806,&l_5806,&l_5806,&l_5806,&l_5806,&l_5806,&l_5806},{&l_5806,&l_5806,&l_5806,&l_5806,&l_5806,&l_5806,&l_5806,&l_5806},{&l_5806,&l_5806,&l_5806,&l_5806,&l_5806,&l_5806,&l_5806,&l_5806},{&l_5806,&l_5806,&l_5806,&l_5806,&l_5806,&l_5806,&l_5806,&l_5806}};
            int32_t l_5834 = 0x74C56979L;
            int64_t l_5835 = 0xA9C15CC13617B810LL;
            int32_t l_5837 = 0x3516839EL;
            int32_t l_5838[1];
            int64_t l_5839 = 0L;
            int64_t l_5841 = 0x7230BB037C95A2FFLL;
            int32_t l_5842 = (-6L);
            int i, j;
            for (i = 0; i < 1; i++)
                l_5838[i] = (-1L);
        }
    }
    return (***g_4422);
}


/* ------------------------------------------ */
/* 
 * reads : g_38 g_66 g_3 g_2717 g_2718 g_2719 g_1207 g_653 g_3260 g_656 g_28 g_1621 g_29 g_539 g_196 g_499 g_3302 g_3307 g_930 g_446 g_1541 g_3344 g_1675 g_1676 g_1677 g_1678 g_232 g_1020 g_998 g_1540 g_715 g_466 g_495 g_1216 g_714 g_3565 g_657 g_2302 g_1168 g_3197 g_3643 g_929 g_1071.f2 g_951 g_2170 g_3870 g_1920.f1 g_746 g_1446 g_4087 g_1847 g_4118 g_3261 g_3071 g_4151 g_7 g_1674 g_4493 g_4422 g_4423 g_4510
 * writes: g_196 g_1540 g_499 g_3260 g_495 g_657 g_255 g_1920.f1 g_2857.f0 g_748 g_2004 g_998 g_2725 g_3344 g_656 g_539 g_1020 g_1216 g_1181 g_3142.f1 g_2886 g_845 g_1509 g_1550 g_1220 g_2386.f0 g_1070 g_1273 g_1396 g_922.f1 g_653 g_1168 g_446 g_924.f1 g_3682 g_466 g_2302 g_1351 g_2170 g_1621 g_3870 g_538 g_188 g_723 g_1221 g_28 g_746 g_3070 g_3071 g_232 g_3307 g_4095 g_3302 g_4139 g_1446 g_1847 g_951
 */
static int16_t  func_208(uint8_t * p_209, int32_t  p_210, const uint32_t * p_211, uint32_t ** p_212)
{ /* block id: 58 */
    int8_t l_216 = 0x89L;
    int8_t *l_219 = &l_216;
    int16_t *l_231[4] = {&g_232,&g_232,&g_232,&g_232};
    int32_t l_233 = 0xF430733AL;
    uint16_t l_234 = 65533UL;
    uint32_t * const *l_3256 = &g_930[1][2];
    int64_t *l_4082 = &g_1847;
    int32_t *l_4511 = &g_499[0][0];
    int8_t ***l_4514 = (void*)0;
    uint32_t l_4535 = 0xEDF489A0L;
    int8_t ***l_4546 = &g_4423;
    int64_t l_4585 = (-1L);
    int64_t l_4601 = 0x727CEFA5BE26010DLL;
    union U3 ***** const l_4628 = &g_1503;
    int8_t * const **l_4664 = &g_4661;
    int8_t l_4671 = 0x9CL;
    int32_t l_4672[10] = {(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)};
    int8_t l_4692 = 0x53L;
    int16_t *****l_4736 = &g_4296;
    const uint8_t l_4892 = 0xBCL;
    union U4 * const *l_4902[5];
    uint8_t l_4931 = 0UL;
    uint8_t ***l_4986 = &g_4139;
    int8_t l_4994 = (-4L);
    uint64_t l_5009 = 7UL;
    union U5 *l_5045 = (void*)0;
    int16_t l_5102 = 0x5343L;
    int32_t ** const *l_5118 = (void*)0;
    int32_t *l_5141[9] = {&l_233,&l_233,&l_233,&l_233,&l_233,&l_233,&l_233,&l_233,&l_233};
    int32_t l_5147 = 8L;
    int16_t l_5178 = 6L;
    int32_t ** const l_5210 = (void*)0;
    uint64_t l_5234 = 0x704BC7F4BD8ABD3BLL;
    int32_t l_5313 = (-1L);
    int i;
    for (i = 0; i < 5; i++)
        l_4902[i] = &g_1168[4];
    (*l_4511) = ((l_216 , (((safe_add_func_uint16_t_u_u((((((((*l_219) = (l_216 | 0xB70BDD84C012C7D4LL)) || l_216) > ((**g_714) = (~(safe_mul_func_int8_t_s_s((-1L), ((l_231[2] = func_223((l_233 = (safe_rshift_func_uint16_t_u_s((g_38 , 0x908BL), 9))), l_234, func_235(func_238(&g_11, g_66, g_3), l_3256), l_4082, l_234)) != (void*)0)))))) | 0x435FB405C5F654AFLL) , p_210) && l_216), 0x0FB9L)) | (*p_211)) && 0xFBEAL)) ^ l_234);
    (*l_4511) = p_210;
    return p_210;
}


/* ------------------------------------------ */
/* 
 * reads : g_232 g_1446 g_4087 g_1847 g_3307 g_4118 g_3260 g_3261 g_3071 g_28 g_1621 g_29 g_715 g_466 g_1541 g_998 g_4151 g_1540 g_3302 g_2717 g_2718 g_2719 g_1207 g_7 g_1675 g_1676 g_1677 g_1678 g_1674 g_4493 g_4422 g_4423 g_4510 g_2857.f0 g_7825.f0
 * writes: g_232 g_3307 g_4095 g_3302 g_1396 g_3070 g_4139 g_1446 g_1847 g_653 g_951 g_2857.f0 g_7825.f0
 */
static int16_t * func_223(int16_t  p_224, uint64_t  p_225, int8_t * p_226, int64_t * p_227, int16_t  p_228)
{ /* block id: 1672 */
    uint32_t **l_4090 = &g_4088[0];
    int32_t l_4091 = 0x6945FA7BL;
    uint64_t l_4121 = 0x7508BF34C91D81E5LL;
    const uint32_t l_4122 = 0xB019AE3BL;
    int32_t l_4125 = (-1L);
    uint16_t l_4210[3][5] = {{0xFAD0L,0xFAD0L,0x22E0L,0xFAD0L,0xFAD0L},{1UL,0xFAD0L,1UL,1UL,0xFAD0L},{0xFAD0L,1UL,1UL,0xFAD0L,1UL}};
    uint16_t ***l_4307 = &g_714;
    int16_t *l_4366 = &g_4302;
    int32_t l_4498 = 0x37FB4FE7L;
    uint32_t * const l_4501[2][1] = {{&g_4502},{&g_4502}};
    uint32_t * const *l_4500 = &l_4501[1][0];
    uint32_t * const **l_4499 = &l_4500;
    int8_t l_4504[6][2][3] = {{{0x68L,0xCEL,(-1L)},{0xBEL,0xBEL,0x7AL}},{{0xCEL,0x68L,0x00L},{(-2L),0xBEL,(-2L)}},{{0x07L,0xCEL,0x30L},{7L,(-2L),(-2L)}},{{0x30L,0x07L,0x00L},{(-5L),7L,0x7AL}},{{0x30L,0x30L,(-1L)},{7L,(-5L),(-10L)}},{{0x07L,0x30L,0x07L},{(-2L),7L,0xBEL}}};
    union U3 ** const l_4505 = (void*)0;
    int16_t l_4506 = 0L;
    int32_t l_4507 = 0xF6E7AF67L;
    int i, j, k;
    for (g_232 = 2; (g_232 >= 0); g_232 -= 1)
    { /* block id: 1675 */
        int32_t *l_4085 = &g_3307;
        uint32_t **l_4089 = (void*)0;
        uint32_t l_4123 = 9UL;
        const int32_t ***l_4124 = &g_3260;
        int32_t * const *l_4146 = &l_4085;
        int32_t * const **l_4145 = &l_4146;
        const union U3 * const l_4211 = &g_4212;
        int64_t l_4222 = (-9L);
        uint32_t l_4276 = 0x92F8BA36L;
        int8_t l_4285 = 0xF5L;
        int32_t *l_4292 = &g_2004;
        uint8_t ***l_4336 = &g_4139;
        uint8_t ****l_4335 = &l_4336;
        int16_t **** const l_4339[4] = {&g_1029,&g_1029,&g_1029,&g_1029};
        uint32_t l_4362 = 0UL;
        uint64_t l_4416 = 0x01E7AB2AA2A97820LL;
        int8_t ***l_4424[3][5][5] = {{{(void*)0,&g_4423,&g_4423,(void*)0,(void*)0},{&g_4423,&g_4423,(void*)0,&g_4423,(void*)0},{(void*)0,&g_4423,&g_4423,(void*)0,(void*)0},{&g_4423,&g_4423,(void*)0,&g_4423,(void*)0},{(void*)0,&g_4423,&g_4423,(void*)0,(void*)0}},{{&g_4423,&g_4423,(void*)0,&g_4423,(void*)0},{(void*)0,&g_4423,&g_4423,(void*)0,(void*)0},{&g_4423,&g_4423,(void*)0,&g_4423,(void*)0},{(void*)0,&g_4423,&g_4423,(void*)0,(void*)0},{&g_4423,&g_4423,(void*)0,&g_4423,(void*)0}},{{&g_4423,(void*)0,(void*)0,&g_4423,(void*)0},{&g_4423,&g_4423,&g_4423,&g_4423,&g_4423},{&g_4423,(void*)0,(void*)0,&g_4423,(void*)0},{&g_4423,&g_4423,&g_4423,&g_4423,&g_4423},{&g_4423,(void*)0,(void*)0,&g_4423,(void*)0}}};
        int32_t l_4486 = 0L;
        int i, j, k;
        (*l_4085) = (g_1446[g_232] ^ (safe_rshift_func_int8_t_s_s(g_1446[g_232], 3)));
        if ((l_4091 = (!((l_4089 = g_4087) == (l_4090 = l_4090)))))
        { /* block id: 1680 */
            int32_t **l_4093 = (void*)0;
            int32_t ***l_4092 = &l_4093;
            int32_t ****l_4094[8][2][3] = {{{&l_4092,&l_4092,&l_4092},{&l_4092,&l_4092,&l_4092}},{{&l_4092,&l_4092,&l_4092},{&l_4092,&l_4092,&l_4092}},{{&l_4092,&l_4092,&l_4092},{&l_4092,&l_4092,&l_4092}},{{&l_4092,&l_4092,&l_4092},{&l_4092,&l_4092,&l_4092}},{{&l_4092,&l_4092,&l_4092},{&l_4092,&l_4092,&l_4092}},{{&l_4092,&l_4092,&l_4092},{&l_4092,&l_4092,&l_4092}},{{&l_4092,&l_4092,&l_4092},{&l_4092,&l_4092,&l_4092}},{{&l_4092,&l_4092,&l_4092},{&l_4092,&l_4092,&l_4092}}};
            union U5 **l_4117 = (void*)0;
            uint32_t *l_4119 = &g_3302;
            int32_t l_4120 = 0x57C44659L;
            union U3 * const *l_4164 = &g_746;
            union U3 * const **l_4163 = &l_4164;
            union U3 * const ***l_4162 = &l_4163;
            int i, j, k;
            l_4125 ^= (l_4120 = ((g_4095 = l_4092) != (((p_224 >= (safe_mod_func_int64_t_s_s((*p_227), (safe_rshift_func_uint8_t_u_s((*l_4085), 4))))) < (((safe_mod_func_uint16_t_u_u((l_4091 , ((((l_4091 >= ((safe_sub_func_uint8_t_u_u(((((((safe_sub_func_int32_t_s_s(1L, (safe_mod_func_uint32_t_u_u((((((((safe_unary_minus_func_int16_t_s((safe_div_func_uint8_t_u_u((((((*l_4119) = ((((safe_mul_func_uint16_t_u_u(((void*)0 == l_4117), p_228)) , (-1L)) ^ g_4118[2]) , 0UL)) != p_225) | l_4120) , 0xD4L), 0x60L)))) || p_228) , 0x354D9B84L) , l_4121) , (**g_3260)) , (*l_4085)) || p_224), (-1L))))) ^ l_4122) <= 3L) , l_4120) , (-9L)) ^ (*g_28)), l_4123)) < 0x54FF2CCDL)) <= (*p_227)) & l_4120) && p_228)), 0x2B4BL)) <= (*l_4085)) != (*l_4085))) , l_4124)));
            for (g_1396 = 2; (g_1396 >= 0); g_1396 -= 1)
            { /* block id: 1687 */
                uint16_t l_4126 = 0xD081L;
                uint8_t ** const l_4140 = &g_656;
                int32_t *l_4165 = &g_7[2][5][1];
                uint64_t l_4187 = 0xA74F6BB3273B9030LL;
                int32_t l_4188 = 5L;
                if (l_4126)
                { /* block id: 1688 */
                    for (g_3070 = 0; (g_3070 <= 2); g_3070 += 1)
                    { /* block id: 1691 */
                        int32_t *l_4153 = &l_4091;
                        int i;
                        (*l_4085) = (*l_4085);
                        l_4091 &= (safe_rshift_func_uint16_t_u_s(((((*p_227) = (((safe_div_func_uint16_t_u_u(p_228, ((safe_sub_func_int32_t_s_s(0x1BCFC0D8L, ((*l_4085) = (p_224 != ((safe_add_func_uint64_t_u_u((safe_rshift_func_uint8_t_u_s((safe_mul_func_uint8_t_u_u(l_4120, (((g_4139 = &g_656) == l_4140) , (safe_add_func_int8_t_s_s((~(!((void*)0 == l_4145))), ((g_1446[g_232] = ((safe_mul_func_int8_t_s_s((safe_mul_func_int16_t_s_s(((*g_715) ^ p_228), l_4120)), 3UL)) | (*g_28))) != p_225)))))), l_4126)), (*g_1541))) || 0x73L))))) , 65535UL))) != p_228) == (*g_715))) > g_4151) , g_1446[g_232]), p_225));
                        (*l_4153) = ((***l_4145) = (safe_unary_minus_func_uint16_t_u(0xBC70L)));
                    }
                }
                else
                { /* block id: 1701 */
                    int32_t *l_4166[6][2] = {{(void*)0,(void*)0},{&g_499[0][0],(void*)0},{(void*)0,&g_499[0][0]},{(void*)0,(void*)0},{&g_499[0][0],(void*)0},{(void*)0,&g_499[0][0]}};
                    int i, j;
                    (*l_4085) = p_225;
                    l_4091 ^= (((*l_4119) ^= ((((safe_lshift_func_uint16_t_u_u((safe_sub_func_uint64_t_u_u(((safe_lshift_func_int8_t_s_u((l_4122 | (((0x83857920L < ((-1L) > (safe_sub_func_uint32_t_u_u(((void*)0 != &g_1406), (0x4CB32F7C369AC3E6LL || ((void*)0 == l_4162)))))) && (l_4126 >= l_4121)) < l_4122)), p_225)) && 0x0A14C276BC89D1E4LL), (**g_1540))), (**l_4146))) , 0xBB338FF4L) & 4294967293UL) , 0x6B2AD293L)) < p_225);
                    (****g_2717) = (l_4166[3][1] = l_4165);
                }
                (**l_4146) = (safe_mul_func_uint16_t_u_u((safe_sub_func_int32_t_s_s((***l_4145), ((((safe_add_func_int32_t_s_s((safe_mod_func_int32_t_s_s((((*l_4085) | (((((safe_rshift_func_uint16_t_u_s(((((safe_div_func_int8_t_s_s((safe_lshift_func_uint8_t_u_u((0xB7944660L < p_224), 0)), ((((l_4188 = ((*p_227) = ((((safe_lshift_func_int16_t_s_u(((void*)0 != &g_3054), 15)) & ((safe_sub_func_int16_t_s_s((-1L), (p_228 < (safe_rshift_func_uint16_t_u_s((***l_4145), l_4187))))) , p_225)) , p_228) & p_224))) <= l_4091) && (*l_4165)) ^ 0xCBL))) < p_225) != 0x4A51L) & 6UL), (****g_1675))) , 4UL) , (*****g_1674)) < 65529UL) > 0x819E3AF85DC0DC9CLL)) == l_4122), 0x21AB8F1DL)), p_225)) == 18446744073709551611UL) != p_224) == l_4122))), l_4122));
            }
        }
        else
        { /* block id: 1712 */
            int32_t l_4189 = 0x2DF30B29L;
            (**l_4146) = l_4189;
        }
        for (g_951 = 0; (g_951 <= 2); g_951 += 1)
        { /* block id: 1717 */
            int32_t l_4201 = 0x408EC55CL;
            uint8_t **l_4310[1];
            int16_t *l_4317 = &g_723;
            int32_t l_4337 = 1L;
            int32_t **l_4340 = &l_4085;
            int32_t **l_4360 = &l_4085;
            const uint64_t *l_4379 = &g_3070;
            const uint64_t **l_4378[4][8] = {{&l_4379,(void*)0,&l_4379,(void*)0,&l_4379,(void*)0,&l_4379,(void*)0},{&l_4379,(void*)0,&l_4379,(void*)0,&l_4379,(void*)0,&l_4379,(void*)0},{&l_4379,(void*)0,&l_4379,(void*)0,&l_4379,(void*)0,&l_4379,(void*)0},{&l_4379,(void*)0,&l_4379,(void*)0,&l_4379,(void*)0,&l_4379,(void*)0}};
            uint32_t l_4415[9][2] = {{6UL,0x64FF2551L},{0x8F453EEFL,18446744073709551615UL},{0x8F453EEFL,0x64FF2551L},{6UL,6UL},{0x64FF2551L,0x8F453EEFL},{18446744073709551615UL,0x8F453EEFL},{0x64FF2551L,6UL},{6UL,0x64FF2551L},{0x8F453EEFL,18446744073709551615UL}};
            int32_t l_4417[2][8][9] = {{{0L,1L,9L,0L,0x0236C7AAL,(-3L),0x0236C7AAL,0L,9L},{0x66999BDAL,1L,0xCD1C3018L,(-1L),0x7CF25A12L,(-1L),0xCD1C3018L,0x66999BDAL,0x66999BDAL},{0x721194AFL,0L,0L,(-3L),0L,0L,0x721194AFL,1L,0x0A0E0501L},{(-1L),0xE84F1637L,0xCD1C3018L,0xC740FC5CL,(-1L),0xF2ED40CBL,5L,(-1L),0xE84F1637L},{9L,0x218500BDL,9L,0L,0x1DBDD6FFL,0L,(-10L),1L,0x0236C7AAL},{0x66999BDAL,0x946CAEFBL,5L,0xDA3CC970L,0xDA3CC970L,5L,0x946CAEFBL,0x66999BDAL,0x185B3704L},{0x0A0E0501L,(-3L),(-1L),0L,6L,1L,0L,1L,6L},{0x185B3704L,(-1L),(-1L),0x946CAEFBL,0x7CF25A12L,0xF2ED40CBL,0xEBE09C19L,0x946CAEFBL,(-1L)}},{{(-1L),7L,0x0236C7AAL,0L,0L,0L,0x0236C7AAL,7L,(-1L)},{(-1L),0x946CAEFBL,0xEBE09C19L,0xF2ED40CBL,0x7CF25A12L,0x946CAEFBL,(-1L),(-1L),0x185B3704L},{6L,1L,0L,1L,6L,0L,(-1L),0L,0x721194AFL},{(-1L),0x7CF25A12L,(-1L),0xCD1C3018L,0x66999BDAL,0x66999BDAL,0xCD1C3018L,(-1L),0x7CF25A12L},{(-1L),(-3L),0x1DBDD6FFL,0x218500BDL,0x0236C7AAL,0L,(-1L),7L,(-1L)},{0x185B3704L,5L,0xCD1C3018L,0xDA3CC970L,0xF2ED40CBL,0x946CAEFBL,1L,0x185B3704L,0xF2ED40CBL},{0x721194AFL,(-3L),0x1B7280B0L,1L,0xE8FB6BCBL,0L,0xE8FB6BCBL,1L,0x1B7280B0L},{0x7CF25A12L,0x7CF25A12L,1L,5L,0xE84F1637L,0xF2ED40CBL,1L,0xEBE09C19L,0x7CF25A12L}}};
            struct S1 *l_4436 = &g_4437;
            int8_t *l_4485[2];
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_4310[i] = &g_656;
            for (i = 0; i < 2; i++)
                l_4485[i] = &l_4285;
        }
    }
    if ((l_4507 |= (safe_mul_func_int8_t_s_s(((safe_lshift_func_int8_t_s_s(l_4125, ((((safe_div_func_int64_t_s_s(g_4493, (safe_rshift_func_int16_t_s_s((0x3BL & (((l_4210[2][1] , (safe_lshift_func_int8_t_s_s(((((l_4498 , ((*l_4499) = &g_4088[0])) != (void*)0) < ((((!l_4210[2][4]) && p_224) , 0xB3A9998CL) ^ 1L)) , 0x54L), 7))) <= 0x864DL) >= l_4210[1][3])), l_4504[0][1][2])))) , l_4505) == l_4505) >= 1UL))) && l_4506), (***g_4422)))))
    { /* block id: 1857 */
        int32_t *l_4508 = &g_3;
        (*g_1207) = l_4508;
    }
    else
    { /* block id: 1859 */
        int16_t *l_4509 = &g_2[0][0][4];
        return l_4509;
    }
    (*g_1207) = (void*)0;
    return g_4510;
}


/* ------------------------------------------ */
/* 
 * reads : g_2717 g_2718 g_2719 g_1207 g_653 g_3260 g_656 g_28 g_1621 g_29 g_539 g_196 g_499 g_3302 g_3307 g_930 g_446 g_66 g_1541 g_3344 g_1675 g_1676 g_1677 g_1678 g_232 g_1020 g_998 g_1540 g_715 g_466 g_495 g_1216 g_714 g_3565 g_657 g_2302 g_1168 g_3197 g_3643 g_929 g_1071.f2 g_951 g_2170 g_3870 g_1920.f1 g_746 g_255 g_1509
 * writes: g_1540 g_499 g_3260 g_495 g_657 g_255 g_1920.f1 g_2857.f0 g_748 g_196 g_2004 g_998 g_2725 g_3344 g_656 g_539 g_1020 g_1216 g_1181 g_3142.f1 g_2886 g_845 g_1509 g_1550 g_1220 g_2386.f0 g_1070 g_1273 g_1396 g_922.f1 g_653 g_1168 g_446 g_924.f1 g_3682 g_466 g_2302 g_1351 g_2170 g_1621 g_3870 g_538 g_188 g_723 g_1221 g_28 g_746 g_3070 g_3071
 */
static int8_t * func_235(int64_t * p_236, uint32_t * const * p_237)
{ /* block id: 1254 */
    uint64_t ***l_3257 = &g_1540;
    int16_t l_3258 = 0x35D3L;
    int32_t l_3259 = 0x182915D7L;
    const int32_t ***l_3262 = &g_3260;
    int8_t l_3268 = 0L;
    int32_t l_3315 = 0xFE467C0AL;
    int32_t l_3319 = 0xFF14B9CBL;
    uint64_t l_3341 = 0x6A1D93147939DC80LL;
    int16_t ****l_3354 = &g_1029;
    int16_t *****l_3353[8][2] = {{&l_3354,&l_3354},{&l_3354,&l_3354},{&l_3354,&l_3354},{&l_3354,&l_3354},{&l_3354,&l_3354},{&l_3354,&l_3354},{&l_3354,&l_3354},{&l_3354,&l_3354}};
    int16_t *****l_3355 = &l_3354;
    int64_t l_3408 = 1L;
    int32_t *l_3430[5] = {&g_11,&g_11,&g_11,&g_11,&g_11};
    union U4 ***l_3471 = &g_2302;
    union U5 **l_3486[4][7][9] = {{{(void*)0,&g_1070,&g_1070,(void*)0,(void*)0,(void*)0,&g_1070,&g_1070,(void*)0},{&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070},{&g_1070,(void*)0,&g_1070,&g_1070,(void*)0,&g_1070,(void*)0,&g_1070,&g_1070},{&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070},{(void*)0,(void*)0,(void*)0,&g_1070,&g_1070,(void*)0,(void*)0,(void*)0,&g_1070},{(void*)0,&g_1070,&g_1070,(void*)0,(void*)0,(void*)0,&g_1070,&g_1070,(void*)0},{&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070}},{{&g_1070,(void*)0,&g_1070,&g_1070,(void*)0,&g_1070,(void*)0,&g_1070,&g_1070},{&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070,&g_1070},{&g_1070,&g_1070,&g_1070,(void*)0,(void*)0,&g_1070,&g_1070,&g_1070,(void*)0},{&g_1070,(void*)0,(void*)0,&g_1070,&g_1070,&g_1070,(void*)0,(void*)0,&g_1070},{&g_1070,(void*)0,(void*)0,(void*)0,&g_1070,&g_1070,(void*)0,(void*)0,(void*)0},{(void*)0,&g_1070,(void*)0,(void*)0,&g_1070,(void*)0,&g_1070,(void*)0,(void*)0},{&g_1070,&g_1070,(void*)0,(void*)0,(void*)0,&g_1070,&g_1070,(void*)0,(void*)0}},{{&g_1070,&g_1070,&g_1070,(void*)0,(void*)0,&g_1070,&g_1070,&g_1070,(void*)0},{&g_1070,(void*)0,(void*)0,&g_1070,&g_1070,&g_1070,(void*)0,(void*)0,&g_1070},{&g_1070,(void*)0,(void*)0,(void*)0,&g_1070,&g_1070,(void*)0,(void*)0,(void*)0},{(void*)0,&g_1070,(void*)0,(void*)0,&g_1070,(void*)0,&g_1070,(void*)0,(void*)0},{&g_1070,&g_1070,(void*)0,(void*)0,(void*)0,&g_1070,&g_1070,(void*)0,(void*)0},{&g_1070,&g_1070,&g_1070,(void*)0,(void*)0,&g_1070,&g_1070,&g_1070,(void*)0},{&g_1070,(void*)0,(void*)0,&g_1070,&g_1070,&g_1070,(void*)0,(void*)0,&g_1070}},{{&g_1070,(void*)0,(void*)0,(void*)0,&g_1070,&g_1070,(void*)0,(void*)0,(void*)0},{(void*)0,&g_1070,(void*)0,(void*)0,&g_1070,(void*)0,&g_1070,(void*)0,(void*)0},{&g_1070,&g_1070,(void*)0,(void*)0,(void*)0,&g_1070,&g_1070,(void*)0,(void*)0},{&g_1070,&g_1070,&g_1070,(void*)0,(void*)0,&g_1070,&g_1070,&g_1070,(void*)0},{&g_1070,(void*)0,(void*)0,&g_1070,&g_1070,&g_1070,(void*)0,(void*)0,&g_1070},{&g_1070,(void*)0,(void*)0,(void*)0,&g_1070,&g_1070,(void*)0,(void*)0,(void*)0},{(void*)0,&g_1070,(void*)0,(void*)0,&g_1070,(void*)0,&g_1070,(void*)0,(void*)0}}};
    uint16_t l_3545 = 0x830BL;
    uint64_t l_3611 = 8UL;
    int8_t l_3640 = (-1L);
    struct S1 *l_3641 = &g_3642;
    int32_t l_3687 = 0L;
    int32_t l_3690 = 8L;
    uint64_t l_3762[1][4] = {{1UL,1UL,1UL,1UL}};
    uint16_t l_3801 = 0UL;
    int64_t l_3849 = 0x8F8194C527D89CE9LL;
    int8_t l_3866 = 0xC3L;
    int64_t l_3880 = 6L;
    uint16_t l_3926 = 4UL;
    uint16_t **l_3942 = &g_715;
    union U3 *l_3953 = &g_3954;
    uint16_t ***l_3969[3][1];
    uint16_t ****l_3968 = &l_3969[1][0];
    int8_t l_3997 = 5L;
    uint8_t l_4023 = 5UL;
    uint32_t l_4081 = 18446744073709551615UL;
    int i, j, k;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
            l_3969[i][j] = &l_3942;
    }
lbl_3435:
    (*****g_2717) = (&g_1541 != ((*l_3257) = &g_1541));
lbl_3929:
    (**g_1207) = (((l_3259 = l_3258) > ((((*l_3262) = g_3260) == ((safe_mod_func_int8_t_s_s((~(safe_rshift_func_uint8_t_u_s(((*g_656) = l_3268), (l_3258 , (*g_28))))), 8L)) , &g_3261)) ^ (safe_mod_func_uint8_t_u_u((+(0x29E0CCEFC858A6ADLL > l_3268)), l_3258)))) , 0x93498FE5L);
lbl_3697:
    for (g_255 = 18; (g_255 > (-17)); --g_255)
    { /* block id: 1263 */
        int64_t l_3284 = 0x8C5E6A300CC71BD2LL;
        uint16_t ***l_3303 = (void*)0;
        int32_t l_3313 = 0xF9DF4619L;
        int32_t l_3314 = (-4L);
        int32_t l_3316 = (-4L);
        int32_t l_3317 = (-1L);
        int32_t l_3318 = 0xD57D80BFL;
        uint8_t *l_3348[2];
        uint32_t *l_3349[4];
        int32_t ****l_3366 = &g_2719[0][1];
        uint64_t **l_3460 = &g_1541;
        uint32_t l_3473 = 4294967290UL;
        union U5 ***l_3487 = (void*)0;
        union U5 **l_3488 = (void*)0;
        union U5 ***l_3489 = &l_3486[1][1][0];
        int i;
        for (i = 0; i < 2; i++)
            l_3348[i] = &g_495;
        for (i = 0; i < 4; i++)
            l_3349[i] = &g_260;
        l_3259 = l_3258;
        for (g_1920.f1 = (-13); (g_1920.f1 < 11); g_1920.f1 = safe_add_func_int64_t_s_s(g_1920.f1, 2))
        { /* block id: 1267 */
            int32_t l_3306[3];
            uint8_t *l_3350 = (void*)0;
            int16_t ****l_3352 = &g_1029;
            int16_t *****l_3351 = &l_3352;
            int16_t *l_3361[5];
            uint32_t *l_3367 = &g_1020;
            union U3 *****l_3368 = &g_1503;
            uint32_t ***l_3379 = &g_929;
            int16_t l_3403 = 0x94ACL;
            int16_t l_3449 = 2L;
            int8_t ****l_3484 = (void*)0;
            int i;
            for (i = 0; i < 3; i++)
                l_3306[i] = 1L;
            for (i = 0; i < 5; i++)
                l_3361[i] = &g_1470;
            for (g_2857.f0 = (-28); (g_2857.f0 > 8); g_2857.f0 = safe_add_func_uint64_t_u_u(g_2857.f0, 1))
            { /* block id: 1270 */
                int16_t ****l_3286 = &g_1029;
                int16_t *****l_3285[10][10][2] = {{{(void*)0,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286}},{{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,(void*)0},{&l_3286,&l_3286},{&l_3286,(void*)0},{&l_3286,&l_3286}},{{(void*)0,&l_3286},{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,(void*)0}},{{&l_3286,&l_3286},{(void*)0,(void*)0},{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286}},{{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,(void*)0},{(void*)0,&l_3286},{&l_3286,(void*)0},{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286}},{{(void*)0,&l_3286},{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,(void*)0},{&l_3286,&l_3286},{&l_3286,(void*)0},{&l_3286,&l_3286},{(void*)0,&l_3286}},{{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,(void*)0},{&l_3286,&l_3286}},{{(void*)0,(void*)0},{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286}},{{(void*)0,&l_3286},{&l_3286,(void*)0},{(void*)0,&l_3286},{&l_3286,(void*)0},{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{&l_3286,&l_3286},{(void*)0,&l_3286}},{{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,(void*)0},{&l_3286,&l_3286},{&l_3286,(void*)0},{&l_3286,&l_3286},{(void*)0,&l_3286},{&l_3286,&l_3286}}};
                int32_t l_3305 = 1L;
                int32_t l_3312[7];
                uint16_t l_3320 = 65527UL;
                int16_t l_3340 = 1L;
                int i, j, k;
                for (i = 0; i < 7; i++)
                    l_3312[i] = 0x8D76FE24L;
                for (g_748 = 0; (g_748 > 2); g_748 = safe_add_func_int16_t_s_s(g_748, 5))
                { /* block id: 1273 */
                    int64_t *l_3280 = (void*)0;
                    int64_t *l_3281 = &g_196;
                    int32_t l_3293 = 0xFD4DFFD8L;
                    uint16_t ****l_3304 = &l_3303;
                    (*****g_2717) |= (((*l_3281) &= (*p_236)) ^ 0x6B6752C022E5A9F1LL);
                    (**g_1207) = ((safe_add_func_int16_t_s_s(((l_3284 >= l_3258) , l_3259), ((l_3285[8][3][1] == (void*)0) , (safe_sub_func_int64_t_s_s(((((+(safe_rshift_func_int8_t_s_u((*g_28), 7))) && (+l_3293)) && l_3259) , ((safe_div_func_int8_t_s_s(((((*l_3304) = ((safe_sub_func_uint64_t_u_u((safe_mod_func_int32_t_s_s(((safe_mod_func_int64_t_s_s(((0x6472L && 65529UL) == g_3302), l_3293)) == 0xBE9B1B0B057DF74FLL), l_3268)), l_3259)) , l_3303)) != (void*)0) <= 0x134EL), 0x50L)) ^ l_3268)), l_3305))))) || l_3306[0]);
                }
                if ((*****g_2717))
                    break;
                if (g_3307)
                    break;
                if (l_3259)
                { /* block id: 1281 */
                    int32_t *l_3308 = (void*)0;
                    int32_t *l_3309 = (void*)0;
                    int32_t *l_3310 = &l_3259;
                    int32_t *l_3311[6][4][6] = {{{&g_3,&g_255,(void*)0,&g_8,&g_255,&g_8},{&l_3305,(void*)0,&l_3305,&g_163,(void*)0,&l_3259},{&l_3305,&g_8,&g_163,&g_163,&g_8,&l_3305},{&l_3305,&g_3,&l_3259,&g_163,&g_3,&g_163}},{{&l_3305,(void*)0,&l_3305,&g_163,(void*)0,&l_3259},{&l_3305,&g_8,&g_163,&g_163,&g_8,&l_3305},{&l_3305,&g_3,&l_3259,&g_163,&g_3,&g_163},{&l_3305,(void*)0,&l_3305,&g_163,(void*)0,&l_3259}},{{&l_3305,&g_8,&g_163,&g_163,&g_8,&l_3305},{&l_3305,&g_3,&l_3259,&g_163,&g_3,&g_163},{&l_3305,(void*)0,&l_3305,&g_163,(void*)0,&l_3259},{&l_3305,&g_8,&g_163,&g_163,&g_8,&l_3305}},{{&l_3305,&g_3,&l_3259,&g_163,&g_3,&g_163},{&l_3305,(void*)0,&l_3305,&g_163,(void*)0,&l_3259},{&l_3305,&g_8,&g_163,&g_163,&g_8,&l_3305},{&l_3305,&g_3,&l_3259,&g_163,&g_3,&g_163}},{{&l_3305,(void*)0,&l_3305,&g_163,(void*)0,&l_3259},{&l_3305,&g_8,&g_163,&g_163,&g_8,&l_3305},{&l_3305,&g_3,&l_3259,&g_163,&g_3,&g_163},{&l_3305,(void*)0,&l_3305,&g_163,(void*)0,&l_3259}},{{&l_3305,&g_8,&g_163,&g_163,&g_8,&l_3305},{&l_3305,&g_3,&l_3259,&g_163,&g_3,&g_163},{&l_3305,(void*)0,&l_3305,&g_163,(void*)0,&l_3259},{&l_3305,&g_8,&g_163,&g_163,&g_8,&l_3305}}};
                    int8_t *l_3323 = &g_1621[0];
                    int i, j, k;
                    l_3320--;
                    return l_3323;
                }
                else
                { /* block id: 1284 */
                    int32_t l_3329 = (-1L);
                    int32_t l_3338 = (-5L);
                    int32_t l_3339[8] = {0x3DA29361L,0x3DA29361L,0x3DA29361L,0x3DA29361L,0x3DA29361L,0x3DA29361L,0x3DA29361L,0x3DA29361L};
                    int i;
                    for (g_2004 = 9; (g_2004 <= 2); g_2004--)
                    { /* block id: 1287 */
                        uint8_t l_3328 = 0xFCL;
                        uint8_t *l_3334[4][8] = {{(void*)0,&g_2725,&g_2725,(void*)0,&g_2725,&g_2725,(void*)0,&g_2725},{(void*)0,(void*)0,&g_1351,(void*)0,(void*)0,&g_1351,(void*)0,(void*)0},{&g_2725,(void*)0,&g_2725,&g_2725,(void*)0,&g_2725,&g_2725,(void*)0},{(void*)0,&g_2725,&g_2725,(void*)0,&g_2725,&g_2725,(void*)0,&g_2725}};
                        int32_t l_3335[8][10] = {{0x77362A07L,0L,0L,0x77362A07L,0x77362A07L,0L,0L,0x77362A07L,0x77362A07L,0L},{0x77362A07L,0x77362A07L,0L,0L,0x77362A07L,0x77362A07L,0L,0L,0x77362A07L,0x77362A07L},{0x77362A07L,0L,0L,0x77362A07L,0x77362A07L,0L,0L,0x77362A07L,0x77362A07L,0L},{0x77362A07L,0x77362A07L,0L,0L,0x77362A07L,0x77362A07L,0L,0L,0x77362A07L,0x77362A07L},{0x77362A07L,0L,0L,0x77362A07L,0x77362A07L,0L,0L,0x77362A07L,0x77362A07L,0L},{0x77362A07L,0x77362A07L,0L,0L,0x77362A07L,0x77362A07L,0L,0L,0x77362A07L,0x77362A07L},{0x77362A07L,0L,0L,0x77362A07L,0x77362A07L,0L,0L,0x77362A07L,0x77362A07L,0L},{0x77362A07L,0x77362A07L,0L,0L,0x77362A07L,0x77362A07L,0L,0L,0x77362A07L,0x77362A07L}};
                        int32_t *l_3336 = &g_3307;
                        int32_t *l_3337[7];
                        volatile int32_t ** const ***l_3347 = &g_3344;
                        int i, j;
                        for (i = 0; i < 7; i++)
                            l_3337[i] = (void*)0;
                        l_3319 ^= ((l_3335[0][6] = ((((l_3268 ^ ((safe_mod_func_uint8_t_u_u((g_2725 = (((**p_237) , ((**g_1207) = ((((((l_3329 |= (l_3306[2] || (l_3328 = ((*g_656) = 9UL)))) | ((*g_1541) = 3UL)) & (safe_add_func_int8_t_s_s((safe_mod_func_uint8_t_u_u(((*p_236) , l_3306[1]), (*g_28))), l_3268))) <= 0UL) < l_3313) , l_3312[0]))) != (**p_237))), 249UL)) >= l_3312[2])) , (void*)0) == (void*)0) && 0L)) & 0xC8L);
                        --l_3341;
                        (*l_3347) = g_3344;
                    }
                }
            }
            (*g_653) |= ((((g_656 = l_3348[0]) == (((void*)0 == l_3349[1]) , l_3350)) ^ l_3306[0]) || ((*p_236) = l_3306[0]));
            if ((l_3268 , ((((((l_3306[0] , (&g_1675 == (l_3355 = (l_3353[4][0] = l_3351)))) ^ (safe_add_func_int16_t_s_s((((!(safe_rshift_func_uint16_t_u_u(((l_3314 = (****g_1675)) || l_3306[0]), 11))) && ((*l_3367) |= (safe_add_func_uint8_t_u_u(((l_3316 | ((safe_mul_func_int8_t_s_s(((((void*)0 != l_3366) > 0x4A2AL) | (*g_653)), (****l_3366))) & l_3341)) == l_3306[2]), (*g_28))))) | (****l_3366)), (****l_3366)))) != (****l_3366)) >= l_3306[0]) , (void*)0) == l_3368)))
            { /* block id: 1308 */
                uint64_t l_3375[7];
                uint32_t ****l_3378[4];
                int i;
                for (i = 0; i < 7; i++)
                    l_3375[i] = 0x876D816E68AFA3CELL;
                for (i = 0; i < 4; i++)
                    l_3378[i] = &g_3250[8];
                if (((*g_653) = ((safe_mod_func_uint8_t_u_u((((safe_rshift_func_int8_t_s_u(((l_3375[2] == (l_3375[5] != (((((0xBDL == ((safe_sub_func_uint8_t_u_u(l_3375[0], (****l_3366))) ^ ((((*p_236) = (*p_236)) > ((l_3379 = (void*)0) != (void*)0)) , (((****l_3366) & (-9L)) , (*g_1541))))) || 18446744073709551612UL) , l_3375[4]) | (****l_3366)) , l_3375[1]))) && l_3375[2]), 4)) , l_3375[2]) == (**g_1540)), l_3306[1])) & 0xE729L)))
                { /* block id: 1312 */
                    if (l_3306[0])
                        break;
                    if ((****g_2718))
                        continue;
                    return l_3350;
                }
                else
                { /* block id: 1316 */
                    int32_t l_3401 = 9L;
                    int8_t l_3402 = 0L;
                    uint64_t l_3427 = 0x21B82A7668AD302ALL;
                    for (l_3317 = 0; (l_3317 >= 0); l_3317 -= 1)
                    { /* block id: 1319 */
                        uint64_t * const **l_3400[2];
                        uint16_t *l_3421[10] = {&g_1218[2][6],&g_1216[0],&g_1216[0],&g_1218[2][6],(void*)0,&g_1218[2][6],&g_1216[0],&g_1216[0],&g_1218[2][6],(void*)0};
                        int32_t l_3422 = 1L;
                        int i, j, k;
                        for (i = 0; i < 2; i++)
                            l_3400[i] = (void*)0;
                        (*g_653) = (((safe_sub_func_uint32_t_u_u((safe_rshift_func_uint16_t_u_u((safe_rshift_func_int8_t_s_u((((l_3315 &= 0x28L) <= (((((+(*p_236)) , (safe_mul_func_int8_t_s_s((safe_rshift_func_uint8_t_u_u(0x38L, (safe_div_func_int16_t_s_s(((safe_add_func_uint64_t_u_u(((((((safe_mul_func_uint8_t_u_u(((!(*g_715)) , (*g_656)), l_3375[2])) & (safe_rshift_func_uint8_t_u_s(l_3268, (0x41L ^ (l_3319 |= ((void*)0 == &g_2482[(l_3317 + 1)][(l_3317 + 2)][l_3317])))))) == (**g_1207)) < (*g_28)) , l_3400[0]) != &g_1540), l_3375[1])) , l_3401), (-1L))))), 0x43L))) , (*g_28)) && l_3402) >= 0x01L)) > 1UL), 6)), 6)), l_3375[2])) != 0xBEDB3009L) | l_3403);
                        (****l_3366) = (safe_lshift_func_int8_t_s_s((((l_3306[2] = (safe_sub_func_int8_t_s_s((l_3408 || ((safe_add_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u(((~(((0xF610F2A38997123BLL ^ l_3401) < l_3375[2]) <= (****l_3366))) || (safe_sub_func_uint32_t_u_u((((7L == (((((safe_add_func_int16_t_s_s(((l_3408 != ((safe_lshift_func_uint16_t_u_u((*g_715), (g_1216[0]--))) >= (safe_div_func_int32_t_s_s((65528UL > l_3315), 1UL)))) && l_3341), 0xC185L)) || (**g_1540)) , l_3427) , 0UL) >= 0x64944B4CL)) < (**g_1540)) | 0x1D17L), (**p_237)))), 0xF4C0L)), 6L)) & 0L)), (*g_656)))) < 0xC4FAEC4BL) , (-7L)), l_3315));
                    }
                    if (l_3401)
                        continue;
                    for (g_1181 = (-5); (g_1181 != 10); g_1181 = safe_add_func_uint64_t_u_u(g_1181, 5))
                    { /* block id: 1330 */
                        l_3430[0] = &l_3306[1];
                    }
                }
            }
            else
            { /* block id: 1334 */
                int64_t l_3457[4];
                int32_t ****l_3475 = (void*)0;
                int32_t *l_3485 = &l_3319;
                int i;
                for (i = 0; i < 4; i++)
                    l_3457[i] = (-1L);
                for (g_3142.f1 = 12; (g_3142.f1 < 33); g_3142.f1 = safe_add_func_uint8_t_u_u(g_3142.f1, 7))
                { /* block id: 1337 */
                    for (g_2886 = 0; (g_2886 == (-28)); g_2886 = safe_sub_func_uint64_t_u_u(g_2886, 7))
                    { /* block id: 1340 */
                        if (l_3403)
                            goto lbl_3435;
                    }
                }
                if ((****l_3366))
                    break;
                for (g_845 = 0; (g_845 > 13); g_845++)
                { /* block id: 1347 */
                    uint64_t l_3442 = 18446744073709551615UL;
                    int64_t *l_3456 = &g_1847;
                    uint16_t l_3458[9];
                    int64_t *l_3459 = &g_1071.f0;
                    int16_t l_3483 = 0x84E4L;
                    int i;
                    for (i = 0; i < 9; i++)
                        l_3458[i] = 0UL;
                }
                for (l_3408 = 0; l_3408 < 5; l_3408 += 1)
                {
                    l_3361[l_3408] = &l_3449;
                }
            }
        }
        (*l_3489) = (l_3488 = l_3486[0][1][4]);
        l_3430[1] = (***l_3366);
    }
    for (g_1509 = (-25); (g_1509 != 29); g_1509 = safe_add_func_uint32_t_u_u(g_1509, 9))
    { /* block id: 1371 */
        int32_t l_3521 = 0x590093A7L;
        int32_t l_3530 = (-7L);
        int32_t l_3606[6][6] = {{0x63C67B0DL,0L,0L,0L,0x63C67B0DL,0L},{0L,0x63C67B0DL,0L,0L,0L,0L},{0L,0L,0L,0x63C67B0DL,0L,0L},{0x63C67B0DL,0L,0L,0L,0x63C67B0DL,0L},{0L,0x63C67B0DL,0L,0L,0L,0L},{0L,0L,0L,0x63C67B0DL,0L,0L}};
        int16_t ***l_3624 = &g_1030[0][0];
        union U3 **l_3631 = &g_746;
        union U3 ***l_3630[6] = {&l_3631,&l_3631,&l_3631,&l_3631,&l_3631,&l_3631};
        union U3 ****l_3629 = &l_3630[2];
        int32_t l_3636 = 0x7ACFBA76L;
        int32_t l_3637 = 0L;
        int8_t l_3671 = 9L;
        int32_t *l_3721 = &g_499[0][0];
        uint32_t l_3757 = 0x200DD53EL;
        uint64_t l_3759[8][9][3] = {{{0xBFF6DF22DEA5F6A4LL,0xBFF6DF22DEA5F6A4LL,18446744073709551607UL},{1UL,0x949C1C2BF0076748LL,18446744073709551615UL},{18446744073709551615UL,0UL,0xE7ACE104D8877436LL},{1UL,0x229438073D67142DLL,0x4A4A3A82B46C5C62LL},{0xBFF6DF22DEA5F6A4LL,18446744073709551615UL,0xE7ACE104D8877436LL},{9UL,0UL,18446744073709551615UL},{18446744073709551610UL,18446744073709551615UL,18446744073709551607UL},{0xD940D2F2B9F6919ELL,0x229438073D67142DLL,0xFF2706AD3DCE01BDLL},{18446744073709551610UL,0UL,18446744073709551612UL}},{{9UL,0x949C1C2BF0076748LL,0xFF2706AD3DCE01BDLL},{0xBFF6DF22DEA5F6A4LL,0xBFF6DF22DEA5F6A4LL,18446744073709551607UL},{1UL,0x949C1C2BF0076748LL,18446744073709551615UL},{18446744073709551615UL,0UL,0xE7ACE104D8877436LL},{1UL,0x229438073D67142DLL,0x4A4A3A82B46C5C62LL},{0xBFF6DF22DEA5F6A4LL,18446744073709551615UL,0xE7ACE104D8877436LL},{9UL,0UL,18446744073709551615UL},{18446744073709551610UL,18446744073709551615UL,18446744073709551607UL},{0xD940D2F2B9F6919ELL,0x229438073D67142DLL,0xFF2706AD3DCE01BDLL}},{{18446744073709551610UL,0UL,18446744073709551612UL},{9UL,0x949C1C2BF0076748LL,0xFF2706AD3DCE01BDLL},{0xBFF6DF22DEA5F6A4LL,0xBFF6DF22DEA5F6A4LL,18446744073709551607UL},{1UL,0x949C1C2BF0076748LL,18446744073709551615UL},{18446744073709551615UL,0UL,0xE7ACE104D8877436LL},{1UL,0x229438073D67142DLL,0xEC3E77283AE60766LL},{0x9B3B617ACC1A38F3LL,2UL,0UL},{0x3B324BF9405DC407LL,2UL,1UL},{18446744073709551610UL,2UL,18446744073709551610UL}},{{7UL,0xF8158EE238E0339ELL,0x5E10AC6BCFCC0865LL},{18446744073709551610UL,1UL,0x97E99474FB1285ADLL},{0x3B324BF9405DC407LL,0UL,0x5E10AC6BCFCC0865LL},{0x9B3B617ACC1A38F3LL,0x9B3B617ACC1A38F3LL,18446744073709551610UL},{18446744073709551610UL,0UL,1UL},{2UL,1UL,0UL},{18446744073709551610UL,0xF8158EE238E0339ELL,0xEC3E77283AE60766LL},{0x9B3B617ACC1A38F3LL,2UL,0UL},{0x3B324BF9405DC407LL,2UL,1UL}},{{18446744073709551610UL,2UL,18446744073709551610UL},{7UL,0xF8158EE238E0339ELL,0x5E10AC6BCFCC0865LL},{18446744073709551610UL,1UL,0x97E99474FB1285ADLL},{0x3B324BF9405DC407LL,0UL,0x5E10AC6BCFCC0865LL},{0x9B3B617ACC1A38F3LL,0x9B3B617ACC1A38F3LL,18446744073709551610UL},{18446744073709551610UL,0UL,1UL},{2UL,1UL,0UL},{18446744073709551610UL,0xF8158EE238E0339ELL,0xEC3E77283AE60766LL},{0x9B3B617ACC1A38F3LL,2UL,0UL}},{{0x3B324BF9405DC407LL,2UL,1UL},{18446744073709551610UL,2UL,18446744073709551610UL},{7UL,0xF8158EE238E0339ELL,0x5E10AC6BCFCC0865LL},{18446744073709551610UL,1UL,0x97E99474FB1285ADLL},{0x3B324BF9405DC407LL,0UL,0x5E10AC6BCFCC0865LL},{0x9B3B617ACC1A38F3LL,0x9B3B617ACC1A38F3LL,18446744073709551610UL},{18446744073709551610UL,0UL,1UL},{2UL,1UL,0UL},{18446744073709551610UL,0xF8158EE238E0339ELL,0xEC3E77283AE60766LL}},{{0x9B3B617ACC1A38F3LL,2UL,0UL},{0x3B324BF9405DC407LL,2UL,1UL},{18446744073709551610UL,2UL,18446744073709551610UL},{7UL,0xF8158EE238E0339ELL,0x5E10AC6BCFCC0865LL},{18446744073709551610UL,1UL,0x97E99474FB1285ADLL},{0x3B324BF9405DC407LL,0UL,0x5E10AC6BCFCC0865LL},{0x9B3B617ACC1A38F3LL,0x9B3B617ACC1A38F3LL,18446744073709551610UL},{18446744073709551610UL,0UL,1UL},{2UL,1UL,0UL}},{{18446744073709551610UL,0xF8158EE238E0339ELL,0xEC3E77283AE60766LL},{0x9B3B617ACC1A38F3LL,2UL,0UL},{0x3B324BF9405DC407LL,2UL,1UL},{18446744073709551610UL,2UL,18446744073709551610UL},{7UL,0xF8158EE238E0339ELL,0x5E10AC6BCFCC0865LL},{18446744073709551610UL,1UL,0x97E99474FB1285ADLL},{0x3B324BF9405DC407LL,0UL,0x5E10AC6BCFCC0865LL},{0x9B3B617ACC1A38F3LL,0x9B3B617ACC1A38F3LL,18446744073709551610UL},{18446744073709551610UL,0UL,1UL}}};
        int64_t l_3825 = 1L;
        int8_t l_3827 = (-8L);
        uint64_t ****l_3876[10];
        uint64_t *****l_3875 = &l_3876[1];
        int64_t l_3893[6][10] = {{(-1L),0L,4L,(-7L),0L,0x4591EBDD2D989038LL,0L,(-7L),4L,0L},{(-1L),2L,(-9L),(-7L),2L,0x50337446051FB0F7LL,0L,(-9L),(-9L),0L},{0x50337446051FB0F7LL,0L,(-9L),(-9L),0L,0x50337446051FB0F7LL,2L,(-7L),(-9L),2L},{(-1L),0L,4L,(-7L),0L,0x4591EBDD2D989038LL,0L,(-7L),4L,0L},{(-1L),2L,(-9L),(-7L),2L,0x1E74D30A89ED6E1BLL,0x09F064972FBB09D2LL,0L,0L,0x09F064972FBB09D2LL},{0x1E74D30A89ED6E1BLL,0x09F064972FBB09D2LL,0L,0L,0x09F064972FBB09D2LL,0x1E74D30A89ED6E1BLL,0xDFA6502687E6D3E1LL,2L,0L,0xDFA6502687E6D3E1LL}};
        int8_t **l_3905 = &g_28;
        uint16_t **l_3941 = (void*)0;
        uint16_t *l_3996 = &g_1216[0];
        union U4 ***l_4070 = &g_2302;
        int i, j, k;
        for (i = 0; i < 10; i++)
            l_3876[i] = &g_3682;
        for (g_1550 = 13; (g_1550 == 5); g_1550--)
        { /* block id: 1374 */
            uint32_t l_3494 = 0UL;
            int32_t l_3507[9][1] = {{0x2EBA9D11L},{0x2EBA9D11L},{0x81872C8AL},{0x2EBA9D11L},{0x2EBA9D11L},{0x81872C8AL},{0x2EBA9D11L},{0x2EBA9D11L},{0x81872C8AL}};
            int8_t *l_3535 = &l_3268;
            int16_t * const **l_3588 = (void*)0;
            int16_t * const ** const *l_3587 = &l_3588;
            int16_t * const ** const **l_3586 = &l_3587;
            int32_t l_3590 = 0x19A03688L;
            union U3 * const *l_3627 = (void*)0;
            union U3 * const **l_3626 = &l_3627;
            union U3 * const ***l_3625 = &l_3626;
            union U3 * const ****l_3628 = &l_3625;
            int i, j;
            if (l_3494)
                break;
            for (g_1220 = 0; (g_1220 >= 16); g_1220 = safe_add_func_uint64_t_u_u(g_1220, 2))
            { /* block id: 1378 */
                union U5 *l_3527 = (void*)0;
                int8_t *l_3536 = (void*)0;
                int32_t *l_3547 = &g_2004;
                int32_t **l_3546 = &l_3547;
                int16_t l_3556 = 7L;
                uint16_t l_3589[10][5] = {{0x9EB7L,1UL,0x9191L,4UL,0xFFB6L},{1UL,0xFFB6L,0xBB4DL,65530UL,0x7FD4L},{1UL,65533UL,65533UL,1UL,1UL},{1UL,4UL,0xE6A2L,1UL,4UL},{1UL,0x9EB7L,0xC50BL,0xBB4DL,65532UL},{0x9EB7L,1UL,65533UL,1UL,0xBB4DL},{4UL,1UL,0UL,1UL,4UL},{65533UL,1UL,1UL,65530UL,0xFFB6L},{0xFFB6L,1UL,0xBB4DL,4UL,1UL},{1UL,0x9EB7L,65535UL,1UL,0xFFB6L}};
                int32_t l_3607 = (-1L);
                int i, j;
                for (g_2386.f0 = 2; (g_2386.f0 <= 9); g_2386.f0 += 1)
                { /* block id: 1381 */
                    uint8_t ***l_3501 = (void*)0;
                    uint8_t ****l_3500[9] = {&l_3501,&l_3501,&l_3501,&l_3501,&l_3501,&l_3501,&l_3501,&l_3501,&l_3501};
                    uint32_t **l_3508[2];
                    int32_t l_3516 = 0x1913ADDDL;
                    union U5 *l_3528 = &g_3529;
                    int i;
                    for (i = 0; i < 2; i++)
                        l_3508[i] = &g_930[2][5];
                    for (l_3259 = 0; (l_3259 <= 9); l_3259 += 1)
                    { /* block id: 1384 */
                        uint8_t l_3499 = 254UL;
                        uint8_t *** const *l_3502 = &l_3501;
                        uint32_t ***l_3509 = (void*)0;
                        uint32_t ***l_3510 = &l_3508[1];
                        int32_t l_3526 = 4L;
                        (**g_1207) = ((safe_div_func_uint16_t_u_u(((l_3499 && (l_3500[4] == l_3502)) <= (safe_sub_func_uint64_t_u_u((safe_div_func_uint32_t_u_u(l_3499, (**p_237))), (((l_3507[6][0] = (*g_28)) <= l_3494) <= (((*l_3510) = l_3508[1]) != (void*)0))))), l_3499)) , 0xC3E3672CL);
                        l_3526 = ((safe_unary_minus_func_int32_t_s((safe_lshift_func_uint8_t_u_u(((((*g_715) , (safe_lshift_func_uint8_t_u_u(l_3516, 1))) | (((safe_add_func_int16_t_s_s((+0x6BD1FD2BA4A3F2A4LL), (((*p_236) , (~(l_3521 != l_3516))) & (safe_lshift_func_uint16_t_u_u((l_3499 & (safe_sub_func_uint64_t_u_u((**g_1540), (((*g_1678) >= 1UL) <= l_3507[6][0])))), 6))))) != (***g_1676)) && l_3499)) , l_3499), 7)))) | 0x992A4101L);
                    }
                    l_3530 = ((g_1070 = l_3527) == (l_3528 = l_3527));
                }
                for (g_1273 = 14; (g_1273 < (-14)); g_1273 = safe_sub_func_int8_t_s_s(g_1273, 9))
                { /* block id: 1396 */
                    for (g_1396 = (-29); (g_1396 == 16); g_1396 = safe_add_func_uint64_t_u_u(g_1396, 4))
                    { /* block id: 1399 */
                        return l_3536;
                    }
                    for (g_998 = (-7); (g_998 > 53); ++g_998)
                    { /* block id: 1404 */
                        uint8_t l_3539 = 1UL;
                        l_3539--;
                        (****g_2718) &= 0x85A14B6DL;
                        return &g_1621[3];
                    }
                }
                for (g_922.f1 = 0; (g_922.f1 <= 23); g_922.f1 = safe_add_func_int16_t_s_s(g_922.f1, 4))
                { /* block id: 1412 */
                    int8_t *l_3544 = &l_3268;
                    return &g_431;
                }
                if (l_3545)
                { /* block id: 1415 */
                    uint32_t l_3551[7][10] = {{1UL,0xBE006DB8L,0xB563C5FAL,4294967292UL,4294967292UL,0xB563C5FAL,0xBE006DB8L,1UL,1UL,0xBE006DB8L},{1UL,4294967292UL,0xBE006DB8L,0xBE006DB8L,4294967292UL,1UL,0xB563C5FAL,0xB563C5FAL,1UL,4294967292UL},{4294967292UL,0xBE006DB8L,0xBE006DB8L,4294967292UL,1UL,0xB563C5FAL,0xB563C5FAL,1UL,4294967292UL,0xBE006DB8L},{4294967292UL,4294967292UL,0xB563C5FAL,0xBE006DB8L,1UL,1UL,0xBE006DB8L,0xB563C5FAL,4294967292UL,4294967292UL},{1UL,0xBE006DB8L,0xB563C5FAL,4294967292UL,4294967292UL,0xB563C5FAL,0xBE006DB8L,1UL,1UL,0xBE006DB8L},{1UL,4294967292UL,0xBE006DB8L,0xBE006DB8L,4294967292UL,1UL,0xB563C5FAL,0xB563C5FAL,1UL,4294967292UL},{4294967292UL,0xBE006DB8L,0xBE006DB8L,4294967292UL,1UL,0xB563C5FAL,0xB563C5FAL,1UL,4294967292UL,0xBE006DB8L}};
                    int i, j;
                    if ((l_3546 == ((*l_3262) = &g_3261)))
                    { /* block id: 1417 */
                        uint16_t l_3548 = 0x985AL;
                        (***g_2718) = &l_3530;
                        ++l_3548;
                        --l_3551[3][4];
                    }
                    else
                    { /* block id: 1421 */
                        return l_3536;
                    }
                    return &g_1621[0];
                }
                else
                { /* block id: 1425 */
                    int64_t l_3560 = 0x50A718BEAEF34487LL;
                    int32_t l_3599 = 5L;
                    int32_t l_3609 = 9L;
                    int32_t l_3610 = 8L;
                    int8_t *l_3614 = &l_3268;
                    if (l_3521)
                    { /* block id: 1426 */
                        int8_t l_3573 = 6L;
                        int32_t l_3591 = 0x81AC8EC1L;
                        int32_t l_3592 = (-1L);
                        (*g_653) = (safe_lshift_func_int16_t_s_s(l_3494, (l_3556 = (l_3530 ^= l_3507[2][0]))));
                        (*g_653) = (+(safe_lshift_func_uint16_t_u_u((**g_714), 7)));
                        (****g_2718) = (l_3592 = (l_3591 = ((l_3560 <= ((((((safe_sub_func_uint64_t_u_u((safe_sub_func_uint64_t_u_u(l_3507[8][0], (g_3565 != (void*)0))), ((l_3573 , (safe_div_func_int8_t_s_s(((safe_lshift_func_uint8_t_u_s((l_3530 , (safe_rshift_func_int8_t_s_u(((((**g_1540) & (safe_rshift_func_int16_t_s_s(((safe_div_func_int64_t_s_s((((((*p_236) >= (((safe_sub_func_int64_t_s_s((l_3586 == &g_1675), (*p_236))) == (****g_1675)) == l_3573)) , 0x7CE17FC0L) || (**p_237)) & (**g_1207)), l_3521)) < l_3589[1][2]), l_3560))) || (*g_656)) & (*g_656)), l_3560))), 4)) , l_3590), l_3560))) > (**p_237)))) | 65535UL) , (*g_1678)) != (-1L)) & 0xE5DC9B860BD21684LL) != l_3590)) >= l_3560)));
                    }
                    else
                    { /* block id: 1434 */
                        uint32_t l_3604 = 18446744073709551606UL;
                        int32_t l_3605 = (-5L);
                        l_3605 = ((*g_653) = (0x53L ^ (((*l_3535) = (safe_add_func_int16_t_s_s((((-4L) != (0x788F3E7AL && (l_3589[1][2] != (l_3507[5][0] = ((l_3521 != 0L) <= ((l_3599 = 0xED54L) >= (safe_lshift_func_uint8_t_u_u(l_3530, 1)))))))) < (safe_rshift_func_int16_t_s_s(0xABDEL, 14))), l_3604))) && l_3604)));
                    }
                    if (l_3507[6][0])
                    { /* block id: 1441 */
                        int32_t l_3608 = 4L;
                        (**l_3471) = (*g_2302);
                        l_3611--;
                        l_3606[1][4] |= ((*g_1541) & l_3507[7][0]);
                        return l_3536;
                    }
                    else
                    { /* block id: 1446 */
                        int16_t l_3615[2];
                        int8_t l_3620 = 0xECL;
                        int i;
                        for (i = 0; i < 2; i++)
                            l_3615[i] = 0xD56BL;
                        if ((****g_2718))
                            break;
                        l_3507[4][0] = ((l_3615[0] , ((safe_rshift_func_int8_t_s_u(((*l_3614) |= (((*g_656) &= l_3507[4][0]) , l_3560)), 0)) && (safe_mul_func_int8_t_s_s(l_3507[6][0], (l_3620 = l_3606[0][2]))))) , ((l_3530 = 0x99F51F97L) , (!(safe_div_func_uint8_t_u_u(((*g_656) = ((void*)0 == l_3624)), ((***g_1676) , 0xEAL))))));
                    }
                }
            }
            (****g_2718) &= (((*l_3628) = l_3625) == l_3629);
            l_3606[1][4] |= l_3521;
        }
        if ((safe_div_func_int32_t_s_s((((l_3606[4][0] , (((void*)0 == (*l_3471)) == (safe_add_func_int8_t_s_s(((l_3606[0][4] | 0x478C8221L) < ((l_3637 = (l_3636 = (l_3530 |= l_3606[4][1]))) | ((((((safe_rshift_func_uint16_t_u_s(l_3640, 7)) & (****g_2718)) == l_3606[4][5]) , l_3606[1][4]) , l_3641) != g_3197))), g_3643)))) | (*g_28)) | (**g_929)), (-9L))))
        { /* block id: 1464 */
            uint32_t l_3670 = 0xB5A061ADL;
            int32_t l_3698 = (-4L);
            int32_t l_3725 = 0L;
            int32_t l_3726 = 0x4376C5D2L;
            int32_t l_3728[7] = {(-1L),(-1L),(-2L),(-1L),(-1L),(-2L),(-1L)};
            uint16_t l_3734 = 0xE2E5L;
            const int32_t *l_3756 = &l_3637;
            int16_t ****l_3783[5];
            int i;
            for (i = 0; i < 5; i++)
                l_3783[i] = &l_3624;
            for (g_1550 = (-13); (g_1550 <= 12); g_1550++)
            { /* block id: 1467 */
                union U5 **l_3656 = (void*)0;
                union U5 ***l_3657 = &l_3486[2][6][4];
                int32_t l_3668 = 0L;
                int32_t l_3669 = 0x26DF4E70L;
                uint64_t * const *l_3696[7] = {&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541};
                uint64_t * const **l_3695 = &l_3696[4];
                union U4 **l_3712 = &g_1168[2];
                int32_t l_3729 = 0L;
                int32_t l_3730 = 0L;
                int32_t l_3733[2];
                uint32_t **l_3781 = &g_930[1][0];
                int i;
                for (i = 0; i < 2; i++)
                    l_3733[i] = 0L;
                l_3669 = (safe_sub_func_uint32_t_u_u(((safe_mul_func_uint8_t_u_u((((safe_mul_func_uint8_t_u_u(l_3637, (safe_lshift_func_uint8_t_u_u((0xFAL && ((l_3656 != ((*l_3657) = l_3656)) > (((**g_1207) = (safe_mul_func_uint8_t_u_u(l_3636, (0x1AL == (((safe_sub_func_int64_t_s_s((*p_236), (safe_mod_func_uint64_t_u_u(((safe_lshift_func_uint16_t_u_u(((*g_656) > (safe_mod_func_uint8_t_u_u(((((l_3668 = ((l_3637 > l_3668) != (-2L))) , 0L) < l_3606[1][4]) , l_3606[5][4]), l_3636))), 11)) & l_3669), (*p_236))))) & l_3670) , (*g_28)))))) <= l_3669))), 4)))) & l_3670) , l_3606[1][0]), l_3671)) != l_3669), 4294967295UL));
                for (g_2886 = 25; (g_2886 == (-26)); g_2886 = safe_sub_func_uint8_t_u_u(g_2886, 5))
                { /* block id: 1474 */
                    for (g_446 = (-26); (g_446 < 49); g_446++)
                    { /* block id: 1477 */
                        return &g_1621[0];
                    }
                }
                for (g_924.f1 = 0; (g_924.f1 != 42); g_924.f1 = safe_add_func_uint16_t_u_u(g_924.f1, 6))
                { /* block id: 1483 */
                    int8_t *l_3693 = &l_3640;
                    int32_t l_3694 = 0xB1E4494AL;
                    if ((safe_rshift_func_uint8_t_u_s((safe_mul_func_int16_t_s_s(((g_3682 = &g_1540) != (((safe_div_func_int32_t_s_s((1L & ((*p_236) > ((((l_3687 == ((((4294967295UL != l_3668) & (safe_sub_func_uint8_t_u_u((l_3690 ^ (((safe_add_func_int16_t_s_s(((*g_656) ^ ((*l_3693) = (*g_28))), l_3670)) ^ 0xCD08D2E1L) >= l_3694)), l_3606[1][4]))) , l_3637) != 0x27L)) | (*p_236)) , (*g_1541)) > 18446744073709551612UL))), l_3694)) == 0x21B551D5L) , l_3695)), l_3636)), l_3606[1][4])))
                    { /* block id: 1486 */
                        if (l_3690)
                            goto lbl_3697;
                    }
                    else
                    { /* block id: 1488 */
                        uint32_t l_3699 = 0x69E40641L;
                        l_3699--;
                        if ((*g_653))
                            continue;
                    }
                    l_3669 = 0x3D3D230EL;
                    return &g_1621[0];
                }
                for (g_255 = 0; (g_255 <= (-17)); --g_255)
                { /* block id: 1497 */
                    int8_t l_3717 = 0xC4L;
                    int32_t l_3722 = (-1L);
                    int32_t l_3723 = 0x3B8305BDL;
                    int32_t l_3724 = 4L;
                    int32_t l_3727 = (-5L);
                    int32_t l_3731 = 0x7859DCE6L;
                    int32_t l_3732[3];
                    int32_t * const l_3755 = &l_3521;
                    union U5 ***l_3758 = &l_3486[0][1][4];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_3732[i] = 0xC46D6BAEL;
                    for (g_1220 = (-1); (g_1220 < 3); g_1220 = safe_add_func_int64_t_s_s(g_1220, 4))
                    { /* block id: 1500 */
                        uint32_t l_3707 = 0x4214F618L;
                        uint32_t *l_3720 = &g_446;
                        l_3721 = ((((~((*g_656) = l_3707)) < (safe_mod_func_uint64_t_u_u((((*g_715) |= 65528UL) > (((*l_3720) = ((safe_mod_func_uint16_t_u_u(1UL, ((l_3668 = (l_3712 == ((*l_3471) = &g_1168[2]))) && (safe_mul_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_s(7UL, (*g_28))), l_3717))))) && (safe_mul_func_int16_t_s_s(l_3521, 65535UL)))) != l_3717)), l_3698))) , l_3698) , &l_3530);
                        (****g_2718) ^= l_3717;
                    }
                    l_3734++;
                    if ((safe_sub_func_uint64_t_u_u((((safe_sub_func_uint64_t_u_u((safe_rshift_func_uint16_t_u_u((((0xA1F07ACAL != ((*p_236) != (0x0149F929A4BBC0FCLL ^ (*p_236)))) , (~((((safe_mul_func_int8_t_s_s(0x72L, (((~l_3728[3]) & (safe_add_func_uint16_t_u_u((safe_mod_func_uint8_t_u_u((safe_mul_func_int16_t_s_s((safe_lshift_func_uint8_t_u_u(((((((((((***l_3257) = (l_3729 < (l_3755 == l_3756))) > 0x33C948E6C20E0FCDLL) , (*l_3721)) < (-9L)) ^ l_3730) > (**g_929)) && (*l_3721)) && 0xADE9L) || l_3730), 0)), (*g_715))), l_3730)), l_3757))) , (*l_3721)))) && (*g_1678)) , (void*)0) == l_3758))) , l_3669), 13)), (*l_3721))) != 0xDC9894F8L) || (*g_1541)), 0xE216EB1EA189E047LL)))
                    { /* block id: 1511 */
                        uint32_t *l_3780 = &l_3757;
                        const int32_t l_3782[7] = {0xB849C56BL,0L,0xB849C56BL,0xB849C56BL,0L,0xB849C56BL,0xB849C56BL};
                        int i;
                        --l_3759[7][8][0];
                        --l_3762[0][1];
                        (*l_3721) = ((l_3722 = (safe_add_func_uint64_t_u_u((safe_mul_func_uint16_t_u_u((!((*g_656) ^= ((**p_237) ^ ((((((safe_lshift_func_uint16_t_u_u((++(*g_715)), (safe_sub_func_uint16_t_u_u(((void*)0 == &g_1181), ((((~0xFAL) ^ ((l_3732[2] = (safe_unary_minus_func_uint32_t_u(((*l_3780) = (**g_929))))) && (l_3668 = (p_237 == l_3781)))) == 6L) == (((**g_1540) = (l_3733[0] == l_3782[5])) != l_3730)))))) , l_3728[0]) , (void*)0) != l_3783[4]) >= 1L) , l_3728[4])))), l_3717)), 0x165A8E40AFA9EB3DLL))) <= l_3730);
                    }
                    else
                    { /* block id: 1522 */
                        (*****g_2717) |= 0L;
                    }
                }
            }
            for (g_1351 = 8; (g_1351 > 3); g_1351 = safe_sub_func_int8_t_s_s(g_1351, 3))
            { /* block id: 1529 */
                if ((*l_3721))
                    break;
            }
        }
        else
        { /* block id: 1532 */
            const uint32_t l_3790 = 0x5638E0DBL;
            int32_t l_3824 = (-3L);
            uint32_t *l_3833 = &g_1920.f1;
            int32_t l_3862 = (-3L);
            int32_t l_3863 = 1L;
            int32_t l_3864 = (-10L);
            int32_t l_3867 = 1L;
            int32_t l_3868 = 0xF0EE776AL;
            int32_t l_3869[6][1][5] = {{{(-7L),(-8L),0xFB4BBB7EL,(-8L),(-7L)}},{{2L,0x6A8CED73L,2L,2L,0x6A8CED73L}},{{(-7L),0xA732BF2AL,0x3CCF62B3L,(-8L),0x3CCF62B3L}},{{0x6A8CED73L,2L,0x6A8CED73L,2L,2L}},{{0xFB4BBB7EL,0xA732BF2AL,0xFB4BBB7EL,0x6186582CL,0x3CCF62B3L}},{{2L,0x026BA6ECL,0x026BA6ECL,2L,0x026BA6ECL}}};
            int16_t l_3892 = 0xFE29L;
            int8_t *l_3940 = &l_3866;
            int32_t l_3944[7][9] = {{0x185B7C35L,0xAC43EDC3L,(-5L),0x1C6A3E73L,(-5L),0xAC43EDC3L,0x185B7C35L,0L,(-2L)},{0L,0x7824D64AL,0x185B7C35L,0x1C6A3E73L,0x0607A404L,(-5L),0x52FB424BL,(-5L),0x52FB424BL},{0x52FB424BL,0x87942C2EL,0L,0L,0x87942C2EL,0x52FB424BL,(-2L),0L,0x185B7C35L},{(-5L),0xB9DD79B8L,0L,(-5L),0L,0xBAA3FB28L,0x0607A404L,0x0607A404L,0xBAA3FB28L},{0L,0x0607A404L,0x185B7C35L,0x0607A404L,0L,(-5L),(-2L),0x1C6A3E73L,(-7L)},{0xAC43EDC3L,0x0607A404L,(-5L),(-7L),0xB9DD79B8L,0x7824D64AL,0x52FB424BL,0x7824D64AL,0xB9DD79B8L},{(-2L),0xB9DD79B8L,0xB9DD79B8L,(-2L),0xBAA3FB28L,(-5L),0x185B7C35L,0x52FB424BL,0x8E348EF2L}};
            int32_t l_3994 = 0x6AD2E711L;
            uint64_t **l_4046 = (void*)0;
            uint64_t ** const *l_4080 = (void*)0;
            uint64_t ** const **l_4079 = &l_4080;
            int i, j, k;
            for (l_3757 = 0; (l_3757 != 36); l_3757 = safe_add_func_uint16_t_u_u(l_3757, 6))
            { /* block id: 1535 */
                union U5 *l_3791 = &g_3792;
                const union U5 *l_3793 = &g_3794;
                int32_t l_3795 = 0x0224B550L;
                int32_t l_3800[2][8] = {{0xA8C08830L,0xA8C08830L,1L,(-1L),0x14C8555CL,(-1L),1L,0xA8C08830L},{0xA8C08830L,(-1L),(-8L),1L,1L,(-8L),(-1L),0xA8C08830L}};
                int32_t *****l_3920 = &g_2718;
                int i, j;
                if ((safe_sub_func_int16_t_s_s((l_3790 < 3L), (((((((g_1070 = l_3791) == (g_1071.f2 , l_3793)) , ((((l_3795 = ((*g_653) = (*l_3721))) , ((((((safe_rshift_func_uint16_t_u_s(0UL, (safe_sub_func_uint32_t_u_u(l_3795, 8UL)))) && (*l_3721)) , (void*)0) == (void*)0) < 65528UL) <= (*l_3721))) | l_3800[1][6]) > (*p_236))) < l_3801) < l_3671) <= 0x28L) == (*p_236)))))
                { /* block id: 1539 */
                    uint16_t ***l_3810 = &g_714;
                    int8_t *l_3823[5];
                    int32_t l_3826[1][7][5] = {{{1L,0x9368AEB4L,0L,0x9368AEB4L,1L},{0x89F38CB0L,0x41555550L,0x09BFC74DL,0x0A12D83FL,1L},{0x09BFC74DL,0x41555550L,0x89F38CB0L,0x89F38CB0L,0x41555550L},{0L,0x9368AEB4L,1L,0x41555550L,1L},{0x9368AEB4L,0x89F38CB0L,1L,0L,1L},{1L,1L,0x89F38CB0L,0L,0x3D0D0AEDL},{0x9368AEB4L,0x3D0D0AEDL,0x09BFC74DL,0L,0L}}};
                    int32_t l_3850 = 0xA05C2D38L;
                    int32_t l_3855 = 5L;
                    int32_t l_3856 = 1L;
                    int32_t l_3859 = 0xF30C1F4CL;
                    int64_t l_3860 = 1L;
                    int32_t l_3861 = 0x8E986FB9L;
                    int32_t l_3865[5] = {0x29B3ECFFL,0x29B3ECFFL,0x29B3ECFFL,0x29B3ECFFL,0x29B3ECFFL};
                    uint64_t ** const *l_3879 = &g_1540;
                    uint64_t ** const **l_3878 = &l_3879;
                    uint64_t ** const ***l_3877[10] = {&l_3878,&l_3878,&l_3878,(void*)0,(void*)0,&l_3878,&l_3878,&l_3878,(void*)0,(void*)0};
                    uint16_t l_3881 = 0UL;
                    uint8_t l_3898[5][6] = {{250UL,0x7EL,248UL,1UL,1UL,248UL},{0x7EL,0x7EL,1UL,250UL,0x6EL,1UL},{0xF0L,255UL,246UL,1UL,0x03L,1UL},{246UL,0xF0L,246UL,0x9CL,0x7EL,1UL},{0x63L,0x9CL,1UL,6UL,248UL,248UL}};
                    int i, j, k;
                    for (i = 0; i < 5; i++)
                        l_3823[i] = &l_3640;
                    for (g_2170 = 17; (g_2170 == 22); g_2170 = safe_add_func_uint16_t_u_u(g_2170, 3))
                    { /* block id: 1542 */
                        (*l_3721) = ((++(*g_1541)) ^ ((*g_653) != (**g_929)));
                        if (l_3790)
                            break;
                    }
                    if ((((safe_mod_func_uint32_t_u_u(((void*)0 == l_3810), ((~(safe_add_func_uint8_t_u_u((((**p_237) , (safe_lshift_func_uint16_t_u_u(((**g_714) = ((((l_3800[1][6] || (l_3824 = (safe_add_func_uint64_t_u_u(0x3F16F8BB65557018LL, ((*g_1541) ^ (safe_sub_func_int32_t_s_s((****g_2718), ((l_3790 , (safe_rshift_func_int8_t_s_s((g_1621[0] = ((!(g_951 , (-1L))) | 0xC6L)), (*l_3721)))) | l_3795)))))))) , l_3825) , l_3826[0][4][0]) ^ 0xE04BL)), 0))) == (**p_237)), l_3827))) , l_3826[0][4][0]))) != l_3826[0][6][2]) != 1UL))
                    { /* block id: 1550 */
                        uint32_t l_3828 = 18446744073709551607UL;
                        l_3828 &= (*****g_2717);
                        if (l_3828)
                            break;
                        (*****g_2717) = 0L;
                    }
                    else
                    { /* block id: 1554 */
                        uint32_t *l_3835 = (void*)0;
                        uint32_t **l_3834 = &l_3835;
                        uint8_t *l_3846[8][4][8] = {{{&g_2355,&g_2355,&g_1351,&g_2355,&g_2355,&g_1351,&g_2355,&g_2355},{(void*)0,&g_2355,&g_2606,&g_188,&g_1446[2],&g_1351,(void*)0,&g_2045},{&g_2045,&g_2355,&g_657,&g_2355,&g_188,&g_1351,&g_2725,&g_2355},{&g_657,&g_2355,(void*)0,&g_188,&g_2606,&g_1351,&g_1727,&g_2045}},{{&g_2355,&g_2355,&g_1351,&g_2355,&g_2355,&g_1351,&g_2355,&g_2355},{(void*)0,&g_2355,&g_2606,&g_188,&g_1446[2],&g_1351,(void*)0,&g_2045},{&g_2045,&g_2355,&g_657,&g_2355,&g_188,&g_1351,&g_2725,&g_2355},{&g_657,&g_2355,(void*)0,&g_188,&g_2606,&g_1351,&g_1727,&g_2045}},{{&g_2355,&g_2355,&g_1351,&g_2355,&g_2355,&g_1351,&g_2355,&g_2355},{(void*)0,&g_2355,&g_2606,&g_188,&g_1446[2],&g_1351,(void*)0,&g_2045},{&g_2045,&g_2355,&g_657,&g_2355,&g_188,&g_1351,&g_2725,&g_2355},{&g_657,&g_2355,(void*)0,&g_188,&g_2606,&g_1351,&g_1727,&g_2045}},{{&g_2355,&g_2355,&g_1351,&g_2355,&g_2355,&g_1351,&g_2355,&g_2355},{(void*)0,&g_2355,&g_2606,&g_188,&g_1446[2],&g_1351,(void*)0,&g_2045},{&g_2045,&g_2355,&g_657,&g_2355,&g_188,&g_1351,&g_2725,&g_2355},{&g_657,&g_2355,(void*)0,&g_188,&g_2606,&g_1351,&g_1727,&g_2045}},{{&g_2355,&g_2355,&g_1351,&g_2355,&g_2355,&g_1351,&g_2355,&g_2355},{(void*)0,&g_2355,&g_2606,&g_188,&g_1446[2],&g_1351,(void*)0,&g_2045},{&g_2045,&g_2355,&g_657,&g_2355,&g_188,&g_1351,&g_2725,&g_2355},{&g_657,&g_2355,(void*)0,&g_188,&g_2606,&g_1351,&g_1727,&g_2045}},{{&g_2355,&g_2355,&g_1351,&g_2355,&g_2355,&g_1351,&g_2355,&g_2355},{(void*)0,&g_2355,&g_2606,&g_188,&g_1446[2],&g_1351,(void*)0,&g_2045},{&g_2045,&g_2355,&g_657,&g_2355,&g_188,&g_1351,&g_2725,&g_2355},{&g_657,&g_2355,(void*)0,&g_188,&g_2606,&g_1351,&g_1727,&g_2045}},{{&g_2355,&g_2355,&g_1351,&g_2355,&g_2355,&g_1351,&g_2355,&g_2355},{(void*)0,&g_2355,&g_2606,&g_188,&g_1446[2],&g_1351,(void*)0,&g_2045},{&g_2045,&g_2355,&g_657,&g_2355,&g_188,&g_1351,&g_2725,&g_2355},{&g_657,&g_2355,(void*)0,&g_188,&g_2606,&g_1351,&g_1727,&g_2045}},{{&g_2355,&g_2355,&g_1351,&g_2355,&g_2355,&g_1351,&g_2355,&g_2355},{(void*)0,&g_2355,&g_2606,&g_188,&g_1446[2],&g_1351,(void*)0,&g_2045},{&g_2045,&g_2355,&g_657,&g_2355,&g_188,&g_1351,&g_2725,&g_2355},{&g_657,&g_2355,(void*)0,&g_188,&g_2606,&g_1351,&g_1727,&g_2045}}};
                        uint32_t *l_3851 = (void*)0;
                        uint32_t *l_3852[6] = {&g_1020,&g_1020,&g_1020,&g_1020,&g_1020,&g_1020};
                        int32_t l_3853 = 0x3AEDF642L;
                        int32_t l_3854 = 7L;
                        int32_t l_3857 = 0xD8868738L;
                        int32_t l_3858[2];
                        int64_t **l_3873 = &g_538[2];
                        uint64_t l_3874 = 0x136212B31CE80C5DLL;
                        int i, j, k;
                        for (i = 0; i < 2; i++)
                            l_3858[i] = 5L;
                        (*g_653) &= ((((safe_sub_func_uint8_t_u_u(((safe_rshift_func_uint8_t_u_u((((l_3833 == ((*l_3834) = l_3833)) , (safe_add_func_uint16_t_u_u(0UL, ((***l_3810)++)))) == ((safe_div_func_uint8_t_u_u((safe_mod_func_uint64_t_u_u((safe_mul_func_uint8_t_u_u((*g_656), (((l_3849 = (g_2170++)) < l_3826[0][4][0]) & (g_3870[0]++)))), (((5UL ^ (((((*p_236) , p_236) != ((*l_3873) = (void*)0)) | 0xF6FAD701L) , l_3858[0])) >= 0x9FL) ^ (**p_237)))), l_3795)) || l_3874)), 3)) | 0xB50C0F07F0BEE02FLL), l_3824)) , l_3875) != l_3877[5]) == l_3824);
                        --l_3881;
                    }
                    if ((*****g_2717))
                    { /* block id: 1564 */
                        (*****g_2717) = (l_3800[0][2] , (0UL > (safe_rshift_func_int16_t_s_u(((((((((safe_div_func_uint64_t_u_u(((*g_1541) = l_3800[1][6]), 0xDF99FD5D2725F15DLL)) == ((safe_rshift_func_int8_t_s_s(0xAFL, (((safe_lshift_func_uint8_t_u_u((7L && ((void*)0 != (*p_237))), 3)) ^ 0L) , (*l_3721)))) ^ 0xE5L)) <= 65530UL) , (*l_3721)) , l_3800[1][6]) > 0xFFL) <= l_3800[0][4]) || (**p_237)), 12))));
                        (*g_1207) = &l_3864;
                        l_3430[4] = &l_3867;
                    }
                    else
                    { /* block id: 1569 */
                        int64_t l_3894 = 8L;
                        uint8_t l_3895 = 0x56L;
                        union U4 *l_3912 = &g_3913[4][4][2];
                        int32_t l_3914 = 0xFC2C7113L;
                        l_3895--;
                        --l_3898[0][5];
                        l_3914 |= (safe_div_func_int64_t_s_s((l_3800[1][6] & (safe_rshift_func_int8_t_s_s(((l_3894 , l_3905) != &l_3823[3]), (l_3864 &= (l_3894 , (l_3859 = ((safe_sub_func_int32_t_s_s(((l_3868 | ((**g_1540) , (((((*l_3833) |= (safe_add_func_int8_t_s_s(((l_3869[5][0][4] |= l_3795) & ((safe_div_func_uint64_t_u_u(0UL, l_3894)) , 0x6EL)), (*l_3721)))) , (*l_3721)) , (void*)0) == l_3912))) <= l_3894), l_3826[0][4][1])) ^ (*g_1541)))))))), l_3850));
                        l_3824 ^= (l_3914 = (0L >= (((l_3865[4] , (0x85106019E0A46443LL | 0x08195CAEAF282957LL)) >= (safe_mod_func_uint8_t_u_u(((((safe_div_func_int64_t_s_s(((*l_3721) > ((+(*l_3721)) , ((l_3920 == (void*)0) , (!(safe_div_func_uint64_t_u_u(((void*)0 != l_3920), (*l_3721))))))), (*****l_3920))) | 250UL) != l_3864) && l_3894), l_3850))) <= 0xE2L)));
                    }
                }
                else
                { /* block id: 1580 */
                    for (l_3687 = 0; (l_3687 <= 2); l_3687 += 1)
                    { /* block id: 1583 */
                        return &g_2886;
                    }
                }
                return &g_1621[0];
            }
            for (g_188 = 0; (g_188 <= 2); g_188 += 1)
            { /* block id: 1591 */
                uint32_t l_3924[6][6][1] = {{{0x0700D696L},{0xB48BDDF6L},{0x0700D696L},{0x0700D696L},{0xB48BDDF6L},{0x0700D696L}},{{0x0700D696L},{0xB48BDDF6L},{0x0700D696L},{0x0700D696L},{0xB48BDDF6L},{0x0700D696L}},{{0x0700D696L},{0xB48BDDF6L},{0x0700D696L},{0x0700D696L},{0xB48BDDF6L},{0x0700D696L}},{{0x0700D696L},{0xB48BDDF6L},{0x0700D696L},{0x0700D696L},{0xB48BDDF6L},{0x0700D696L}},{{0x0700D696L},{0xB48BDDF6L},{0x0700D696L},{0x0700D696L},{0xB48BDDF6L},{0x0700D696L}},{{0x0700D696L},{0xB48BDDF6L},{0x0700D696L},{0x0700D696L},{0xB48BDDF6L},{0x0700D696L}}};
                int32_t l_3925[1];
                int i, j, k;
                for (i = 0; i < 1; i++)
                    l_3925[i] = (-6L);
                if (l_3924[3][3][0])
                    break;
                l_3636 &= (*g_653);
                if ((*l_3721))
                    break;
                for (g_723 = 0; (g_723 <= 2); g_723 += 1)
                { /* block id: 1597 */
                    ++l_3926;
                    for (l_3863 = 2; (l_3863 >= 0); l_3863 -= 1)
                    { /* block id: 1601 */
                        l_3530 &= (*****g_2717);
                    }
                }
            }
            for (g_1273 = 0; (g_1273 >= 0); g_1273 -= 1)
            { /* block id: 1608 */
                int32_t l_3943 = 0L;
                int16_t l_3945 = 0x8D8AL;
                struct S1 * const l_3960 = &g_3961;
                struct S1 *l_3962[6] = {&g_3963,&g_3963,&g_3963,&g_3963,&g_3963,&g_3963};
                int64_t l_3995 = 0xE23DFEA37A715502LL;
                union U4 *l_4042[10] = {&g_4044,&g_4043,&g_4043,&g_4044,&g_4043,&g_4043,&g_4044,&g_4043,&g_4043,&g_4044};
                int32_t l_4063 = (-1L);
                int32_t l_4069 = (-6L);
                int i, j;
                if (l_3757)
                    goto lbl_3929;
                if ((((((1L & ((l_3868 = (safe_div_func_uint16_t_u_u(((**l_3942) = ((0x7C69527FL ^ (((*l_3833) ^= (((*g_1541)++) < ((l_3862 &= ((*g_656) |= ((**g_714) >= (((!(safe_rshift_func_int8_t_s_s(((safe_mul_func_uint16_t_u_u((safe_unary_minus_func_int64_t_s(((void*)0 == l_3940))), (*l_3721))) , ((((l_3941 == l_3942) | l_3943) , (-1L)) && l_3944[1][3])), 3))) < l_3867) || l_3824)))) == l_3824))) , 0x14F9F719L)) ^ (-4L))), 6L))) && (*g_715))) == (-9L)) <= l_3945) & (*l_3721)) && 0xC8FAL))
                { /* block id: 1616 */
                    uint16_t l_3952[4];
                    struct S1 **l_3965 = &l_3962[0];
                    const int32_t l_3972 = (-1L);
                    int i;
                    for (i = 0; i < 4; i++)
                        l_3952[i] = 0UL;
                    for (g_1221 = 0; (g_1221 <= 1); g_1221 += 1)
                    { /* block id: 1619 */
                        int i, j, k;
                        (*****g_2717) = (safe_mod_func_uint64_t_u_u((*l_3721), (((safe_mul_func_int8_t_s_s(((*l_3940) = (0x62CE564381F71064LL || ((safe_lshift_func_int16_t_s_s((*l_3721), l_3869[1][0][3])) ^ l_3952[1]))), (((*l_3905) = &g_1621[1]) == (void*)0))) & (**p_237)) , 0x1F8BBA258FA1D998LL)));
                        (*g_653) = (*l_3721);
                        l_3953 = ((*l_3631) = (***l_3629));
                        (**l_3471) = (*g_2302);
                    }
                    if (l_3824)
                        break;
                    l_3943 |= ((-1L) ^ (!(safe_div_func_uint16_t_u_u((((safe_rshift_func_uint16_t_u_u((*g_715), 14)) < ((l_3960 == ((*l_3965) = ((&g_2302 != l_3471) , l_3962[4]))) > (safe_mul_func_uint8_t_u_u((((void*)0 == l_3968) ^ (safe_rshift_func_int8_t_s_s((l_3972 < l_3862), 1))), (*l_3721))))) && 0x83L), l_3863))));
                }
                else
                { /* block id: 1631 */
                    int64_t l_3977 = 0x97CB0A677A32A611LL;
                    int8_t l_4002 = 0xB5L;
                    int32_t l_4037 = 9L;
                    int32_t l_4045 = 0x6C274A0BL;
                    if ((safe_sub_func_int64_t_s_s(7L, (safe_mul_func_int16_t_s_s((l_3977 ^ (*p_236)), (l_3997 = ((~(((safe_div_func_int16_t_s_s((((safe_unary_minus_func_int64_t_s(((safe_lshift_func_int16_t_s_u(((safe_unary_minus_func_int8_t_s(l_3945)) , (safe_div_func_int8_t_s_s((safe_rshift_func_int8_t_s_u((((!0xA1969365L) & (0x7C37L < (((((((*p_236) > (l_3943 , ((safe_add_func_int64_t_s_s(l_3977, (*p_236))) || 0UL))) , (**g_1207)) > 0x6EBFD721L) || (****g_1675)) , (-2L)) >= (****g_1675)))) & l_3943), 4)), l_3994))), 9)) < l_3977))) ^ l_3995) <= 0xE3L), l_3995)) , (void*)0) == l_3996)) , l_3944[3][8])))))))
                    { /* block id: 1633 */
                        const int16_t l_4022 = 0xDC5FL;
                        (****g_2717) = (***g_2718);
                        (**g_1207) |= (((*g_715) ^= l_3977) , ((safe_mod_func_int64_t_s_s((safe_add_func_uint16_t_u_u((--(**l_3942)), (safe_mod_func_int16_t_s_s((safe_mul_func_int8_t_s_s(3L, (safe_lshift_func_int16_t_s_u(((0xA13E7D3DL ^ (~((0x2DBCBE9CL >= 1L) & (((safe_lshift_func_uint8_t_u_u(((l_3863 >= (g_3070 = (safe_add_func_uint64_t_u_u(((**g_1540) = (**g_1540)), ((safe_sub_func_uint64_t_u_u(((safe_mul_func_uint8_t_u_u(l_3977, (((safe_div_func_uint64_t_u_u((1L ^ (*p_236)), (*p_236))) | l_3868) & 0xF4A6L))) ^ 0x5F49L), l_4022)) <= 0xA3969F40F27A6CF7LL))))) ^ l_3995), 2)) && l_3943) > l_3892)))) & 0L), l_4023)))), l_4022)))), 1L)) , l_4002));
                    }
                    else
                    { /* block id: 1640 */
                        int8_t *l_4024 = &l_4002;
                        return (*l_3905);
                    }
                    l_4045 &= (safe_mul_func_int16_t_s_s((safe_sub_func_uint64_t_u_u((*l_3721), (safe_add_func_uint8_t_u_u((((((safe_sub_func_uint8_t_u_u((safe_rshift_func_int16_t_s_s((safe_add_func_int16_t_s_s(l_3944[1][3], ((l_4037 = (((l_3869[1][0][3] = (*l_3721)) , l_3869[1][0][3]) || 18446744073709551614UL)) >= l_3945))), ((safe_rshift_func_int16_t_s_s((safe_add_func_int8_t_s_s((((**l_3471) = l_4042[5]) != (void*)0), (((*l_3721) & 0x5DEA9678A58E1A19LL) > (*l_3721)))), 9)) | l_3863))), (*l_3721))) , (-2L)) != 0xB8L) , l_3943) , 0x75L), (*l_3721))))), (*g_715)));
                    return (*l_3905);
                }
                l_3869[1][0][3] |= ((&g_1541 != l_4046) < (safe_div_func_uint32_t_u_u((((safe_add_func_uint32_t_u_u(3UL, ((2L == ((-5L) && (((safe_add_func_uint32_t_u_u(((safe_sub_func_int8_t_s_s(l_3994, ((safe_div_func_uint64_t_u_u((safe_mod_func_uint16_t_u_u((0x722313C2L | ((*l_3721) = (safe_rshift_func_int8_t_s_s(l_4063, 1)))), ((g_3071 = (safe_sub_func_int8_t_s_s(((~(safe_rshift_func_int8_t_s_s(((l_3945 ^ l_4063) ^ 0xC8C7BCC4CB91AA7ELL), 4))) > l_3606[1][4]), 0xC3L))) , 0x71E7L))), l_3862)) < l_3824))) | l_4063), l_4069)) ^ 0L) <= 0x84L))) > 4294967295UL))) , &g_2302) == l_4070), (-1L))));
                for (l_3824 = 0; (l_3824 <= 4); l_3824 += 1)
                { /* block id: 1654 */
                    (*l_3257) = (*l_3257);
                    for (l_3636 = 0; (l_3636 <= 1); l_3636 += 1)
                    { /* block id: 1658 */
                        if (l_3319)
                            goto lbl_3929;
                    }
                }
            }
            l_3636 = ((*l_3721) = (safe_sub_func_int8_t_s_s((((safe_add_func_int16_t_s_s(0x5F03L, (safe_add_func_uint32_t_u_u(((safe_mul_func_int16_t_s_s(l_3790, (*g_715))) >= (((*l_4079) = &g_1540) != (void*)0)), (&g_1540 != l_3257))))) > ((void*)0 == &l_3833)) & 0x2432D254L), (*g_656))));
        }
        (***g_2718) = (***g_2718);
        l_4081 ^= ((*l_3721) = ((void*)0 == (*g_1675)));
    }
    return &g_2886;
}


/* ------------------------------------------ */
/* 
 * reads : g_196
 * writes: g_196
 */
static int64_t * func_238(const int32_t * p_239, uint32_t  p_240, uint8_t  p_241)
{ /* block id: 61 */
    uint32_t l_3242 = 0x65A6F82BL;
    uint16_t *** const l_3253[7] = {&g_714,&g_714,&g_714,&g_714,&g_714,&g_714,&g_714};
    uint16_t *** const *l_3252[7][9][4] = {{{(void*)0,&l_3253[0],(void*)0,&l_3253[3]},{&l_3253[4],(void*)0,&l_3253[0],&l_3253[4]},{&l_3253[0],&l_3253[3],&l_3253[4],&l_3253[4]},{&l_3253[4],&l_3253[4],&l_3253[3],&l_3253[0]},{&l_3253[4],&l_3253[0],(void*)0,&l_3253[4]},{&l_3253[3],(void*)0,&l_3253[0],(void*)0},{&l_3253[0],(void*)0,&l_3253[0],&l_3253[4]},{(void*)0,&l_3253[0],&l_3253[0],&l_3253[0]},{&l_3253[1],&l_3253[4],&l_3253[0],&l_3253[4]}},{{&l_3253[0],&l_3253[3],&l_3253[4],&l_3253[4]},{&l_3253[0],(void*)0,&l_3253[0],&l_3253[3]},{&l_3253[0],&l_3253[0],&l_3253[1],&l_3253[0]},{&l_3253[0],&l_3253[0],&l_3253[0],(void*)0},{&l_3253[0],&l_3253[0],&l_3253[4],&l_3253[1]},{&l_3253[0],&l_3253[0],&l_3253[0],&l_3253[0]},{&l_3253[1],&l_3253[4],&l_3253[0],&l_3253[0]},{(void*)0,&l_3253[0],&l_3253[0],&l_3253[0]},{&l_3253[0],&l_3253[1],&l_3253[0],&l_3253[0]}},{{&l_3253[3],&l_3253[0],(void*)0,&l_3253[0]},{&l_3253[4],&l_3253[4],&l_3253[1],&l_3253[1]},{&l_3253[3],&l_3253[0],&l_3253[3],(void*)0},{&l_3253[4],&l_3253[1],&l_3253[0],&l_3253[0]},{&l_3253[0],&l_3253[0],&l_3253[0],&l_3253[1]},{&l_3253[0],&l_3253[3],&l_3253[0],&l_3253[1]},{&l_3253[0],&l_3253[0],&l_3253[0],&l_3253[0]},{&l_3253[4],&l_3253[1],&l_3253[3],&l_3253[3]},{&l_3253[3],&l_3253[3],&l_3253[1],&l_3253[4]}},{{&l_3253[0],&l_3253[0],&l_3253[0],&l_3253[0]},{&l_3253[1],&l_3253[0],&l_3253[3],&l_3253[0]},{&l_3253[1],&l_3253[0],&l_3253[0],&l_3253[0]},{&l_3253[0],&l_3253[0],&l_3253[1],&l_3253[4]},{(void*)0,&l_3253[3],&l_3253[0],&l_3253[3]},{&l_3253[1],&l_3253[1],&l_3253[0],&l_3253[0]},{&l_3253[0],&l_3253[0],(void*)0,&l_3253[1]},{&l_3253[0],&l_3253[3],&l_3253[3],&l_3253[1]},{&l_3253[0],&l_3253[0],(void*)0,&l_3253[0]}},{{&l_3253[0],&l_3253[1],&l_3253[0],(void*)0},{&l_3253[1],&l_3253[0],&l_3253[0],&l_3253[1]},{(void*)0,&l_3253[0],&l_3253[1],&l_3253[0]},{&l_3253[0],(void*)0,&l_3253[0],&l_3253[0]},{&l_3253[1],&l_3253[3],&l_3253[3],&l_3253[0]},{&l_3253[1],(void*)0,&l_3253[0],&l_3253[0]},{&l_3253[0],&l_3253[0],&l_3253[1],&l_3253[1]},{&l_3253[3],&l_3253[0],&l_3253[3],(void*)0},{&l_3253[4],&l_3253[1],&l_3253[0],&l_3253[0]}},{{&l_3253[0],&l_3253[0],&l_3253[0],&l_3253[1]},{&l_3253[0],&l_3253[3],&l_3253[0],&l_3253[1]},{&l_3253[0],&l_3253[0],&l_3253[0],&l_3253[0]},{&l_3253[4],&l_3253[1],&l_3253[3],&l_3253[3]},{&l_3253[3],&l_3253[3],&l_3253[1],&l_3253[4]},{&l_3253[0],&l_3253[0],&l_3253[0],&l_3253[0]},{&l_3253[1],&l_3253[0],&l_3253[3],&l_3253[0]},{&l_3253[1],&l_3253[0],&l_3253[0],&l_3253[0]},{&l_3253[0],&l_3253[0],&l_3253[1],&l_3253[4]}},{{(void*)0,&l_3253[3],&l_3253[0],&l_3253[3]},{&l_3253[1],&l_3253[1],&l_3253[0],&l_3253[0]},{&l_3253[0],&l_3253[0],(void*)0,&l_3253[1]},{&l_3253[0],&l_3253[3],&l_3253[3],&l_3253[1]},{&l_3253[0],&l_3253[0],(void*)0,&l_3253[0]},{&l_3253[0],&l_3253[1],&l_3253[0],(void*)0},{&l_3253[1],&l_3253[0],&l_3253[0],&l_3253[1]},{(void*)0,&l_3253[0],&l_3253[1],&l_3253[0]},{&l_3253[0],(void*)0,&l_3253[0],&l_3253[0]}}};
    uint16_t *** const **l_3254 = &l_3252[4][1][2];
    int64_t *l_3255[2];
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_3255[i] = &g_539[1];
    for (g_196 = 0; (g_196 > (-9)); g_196 = safe_sub_func_int32_t_s_s(g_196, 9))
    { /* block id: 64 */
        uint32_t l_248 = 0x596266F9L;
        int64_t l_3243 = 0xB2C9D11ACFE89D5DLL;
        uint32_t ***l_3249 = &g_929;
    }
    (*l_3254) = l_3252[4][1][2];
    return l_3255[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_28 g_29 g_260 g_163 g_3 g_255 g_11 g_328 g_188 g_431 g_196 g_66 g_78 g_2 g_466 g_7 g_495 g_232 g_499 g_8 g_446 g_604 g_539 g_653 g_656 g_715 g_657 g_748 g_538 g_774 g_836 g_38 g_845 g_857 g_1070 g_1020 g_924.f1 g_1181 g_929 g_930 g_1207 g_998 g_1273 g_1221 g_306 g_922.f2 g_951 g_1406 g_723 g_1446 g_1168 g_1509 g_1470 g_1540 g_1541 g_1550 g_1218 g_1636 g_1674 g_1727 g_1676 g_1677 g_1678 g_1920.f1 g_2037 g_2045 g_1224 g_1675 g_1216 g_2170 g_2355 g_2388 g_2386.f2 g_1396 g_2450 g_1995.f1 g_1351 g_3197 g_3142.f1 g_2004 g_2886
 * writes: g_255 g_260 g_306 g_431 g_188 g_466 g_495 g_232 g_538 g_446 g_499 g_28 g_604 g_653 g_714 g_723 g_746 g_748 g_657 g_539 g_845 g_857 g_1070 g_1020 g_998 g_1168 g_1181 g_1207 g_924.f1 g_1224 g_922.f2 g_1351 g_1396 g_951 g_1219 g_1273 g_1220 g_924.f2 g_922.f1 g_1470 g_1503 g_1509 g_930 g_1071.f0 g_1636 g_1674 g_1621 g_1727 g_1920.f1 g_2170 g_774 g_1216 g_2302 g_2433 g_656 g_2482 g_1995.f1 g_2045 g_1446 g_3142.f1 g_2004 g_2886
 */
static uint8_t  func_249(int32_t  p_250)
{ /* block id: 65 */
    int8_t *l_3219[3][10] = {{&g_431,&g_29,(void*)0,(void*)0,(void*)0,(void*)0,&g_29,&g_431,(void*)0,&g_431},{(void*)0,&g_1621[3],&g_1621[0],(void*)0,&g_1621[0],&g_1621[3],&g_431,&g_1621[0],&g_1621[0],&g_431},{&g_1621[0],&g_1621[0],&g_1621[2],&g_1621[2],&g_1621[0],&g_1621[0],(void*)0,&g_1621[0],(void*)0,&g_1621[0]}};
    int32_t l_3220 = 0x3B891639L;
    int32_t l_3221 = 0L;
    union U3 *l_3222 = &g_3223;
    const uint16_t **l_3234 = (void*)0;
    int32_t l_3235 = 1L;
    int64_t l_3236[6] = {0L,0L,0x8DE8D97E15C63A48LL,0L,0L,0x8DE8D97E15C63A48LL};
    int32_t *l_3237[8][2] = {{(void*)0,&g_255},{&g_8,&g_8},{&g_8,&g_255},{(void*)0,&g_499[0][0]},{&g_255,&g_499[0][0]},{(void*)0,&g_255},{&g_8,&g_8},{&g_8,&g_255}};
    uint32_t l_3238[10] = {0x70DE1BC5L,8UL,0x70DE1BC5L,8UL,0x70DE1BC5L,8UL,0x70DE1BC5L,8UL,0x70DE1BC5L,8UL};
    int i, j;
    l_3222 = ((l_3221 = (l_3220 = ((*g_28) , func_251((*g_28))))) , l_3222);
    l_3238[3] |= (((18446744073709551615UL <= (safe_div_func_int8_t_s_s((((safe_mul_func_uint8_t_u_u((p_250 ^ (p_250 , (l_3235 = ((safe_lshift_func_uint16_t_u_u((*g_715), 15)) , ((p_250 ^ ((+(((p_250 && p_250) > (safe_mod_func_int64_t_s_s(0x2C77157C142BA037LL, (+(((l_3234 != l_3234) ^ 0L) || p_250))))) && p_250)) <= l_3221)) >= 0x8B2B7471CA20C23BLL))))), 0x23L)) , l_3236[2]) , p_250), 0x4CL))) < p_250) < (*g_715));
    return p_250;
}


/* ------------------------------------------ */
/* 
 * reads : g_260 g_29 g_163 g_3 g_255 g_11 g_28 g_328 g_188 g_431 g_196 g_66 g_78 g_2 g_466 g_7 g_495 g_232 g_499 g_8 g_446 g_604 g_539 g_653 g_656 g_715 g_657 g_748 g_538 g_774 g_836 g_38 g_845 g_857 g_1070 g_1020 g_924.f1 g_1181 g_929 g_930 g_1207 g_998 g_1273 g_1221 g_306 g_922.f2 g_951 g_1406 g_723 g_1446 g_1168 g_1509 g_1470 g_1540 g_1541 g_1550 g_1218 g_1636 g_1674 g_1727 g_1676 g_1677 g_1678 g_1920.f1 g_2037 g_2045 g_1224 g_1675 g_1216 g_2170 g_2355 g_2388 g_2386.f2 g_1396 g_2450 g_1995.f1 g_1351 g_3197 g_3142.f1 g_2004 g_2886
 * writes: g_255 g_260 g_306 g_431 g_188 g_466 g_495 g_232 g_538 g_446 g_499 g_28 g_604 g_653 g_714 g_723 g_746 g_748 g_657 g_539 g_845 g_857 g_1070 g_1020 g_998 g_1168 g_1181 g_1207 g_924.f1 g_1224 g_922.f2 g_1351 g_1396 g_951 g_1219 g_1273 g_1220 g_924.f2 g_922.f1 g_1470 g_1503 g_1509 g_930 g_1071.f0 g_1636 g_1674 g_1621 g_1727 g_1920.f1 g_2170 g_774 g_1216 g_2302 g_2433 g_656 g_2482 g_1995.f1 g_2045 g_1446 g_3142.f1 g_2004 g_2886
 */
static int8_t  func_251(int8_t  p_252)
{ /* block id: 66 */
    int32_t *l_254 = &g_255;
    int32_t *l_256 = &g_255;
    int32_t *l_257 = &g_255;
    int32_t l_258 = 1L;
    int32_t *l_259[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    uint32_t *l_304 = &g_66;
    uint32_t **l_303 = &l_304;
    uint16_t *l_305 = &g_306;
    int64_t *l_325 = &g_196;
    int8_t l_761 = 6L;
    int64_t *l_844 = &g_845;
    uint64_t l_871 = 0xD8F2943E0619F5E0LL;
    int16_t *l_897[5] = {&g_78,&g_78,&g_78,&g_78,&g_78};
    int32_t l_898[1];
    uint8_t *l_1445[7][3][2] = {{{&g_1446[2],&g_1446[2]},{&g_1446[2],&g_1446[2]},{&g_1446[0],&g_1446[0]}},{{&g_1446[2],&g_1446[0]},{&g_1446[0],&g_1446[2]},{&g_1446[2],&g_1446[2]}},{{&g_1446[2],&g_1446[2]},{&g_1446[0],&g_1446[0]},{&g_1446[2],&g_1446[0]}},{{&g_1446[0],&g_1446[2]},{&g_1446[2],&g_1446[2]},{&g_1446[2],&g_1446[2]}},{{&g_1446[0],&g_1446[0]},{&g_1446[2],&g_1446[0]},{&g_1446[0],&g_1446[2]}},{{&g_1446[2],&g_1446[2]},{&g_1446[2],&g_1446[2]},{&g_1446[0],&g_1446[0]}},{{&g_1446[2],&g_1446[0]},{&g_1446[0],&g_1446[2]},{&g_1446[2],&g_1446[2]}}};
    union U3 *l_1640 = &g_1641;
    uint8_t **l_2477 = &g_656;
    uint32_t l_3218[9] = {4294967295UL,0x7AFDE126L,0x7AFDE126L,4294967295UL,0x7AFDE126L,0x7AFDE126L,4294967295UL,0x7AFDE126L,0x7AFDE126L};
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_898[i] = (-1L);
    (*l_254) = (~p_252);
    g_260--;
    l_3218[1] |= func_263(p_252, func_267(((*l_2477) = func_270(func_141((safe_div_func_int64_t_s_s(func_278(func_282((g_29 , (l_303 = func_284((((*l_256) = (l_898[0] ^= func_288(func_292(((g_499[2][0] = ((*l_257) = (safe_rshift_func_uint16_t_u_u((safe_div_func_uint8_t_u_u((safe_mul_func_int16_t_s_s((safe_div_func_uint16_t_u_u((+((void*)0 != l_303)), ((*l_305) = g_260))), p_252)), func_141((safe_add_func_int8_t_s_s((g_163 < (((*l_844) |= func_309(func_314((func_317(g_3, (((((safe_mul_func_int16_t_s_s(p_252, (-1L))) & 0x3E1A2BD65C10CE04LL) >= p_252) || 0x13A09A50L) , l_325), g_163, (*l_256), g_11) , (*g_656)), &g_8), p_252, &l_304, l_761)) | p_252)), 0L)), p_252))), 0)))) >= p_252)), l_871, (*l_303)))) || (-1L)), g_11, p_252)))), l_1445[4][2][1], p_252), p_252)), p_252), l_1640, p_252, g_29, g_7[2][5][1])), p_252), p_252);
    return (*g_28);
}


/* ------------------------------------------ */
/* 
 * reads : g_1218 g_1636 g_188 g_2045 g_1727 g_1446 g_232 g_715 g_656 g_499 g_3197 g_3142.f1 g_1541 g_998 g_28 g_29 g_2004 g_2886
 * writes: g_188 g_232 g_746 g_466 g_1636 g_2045 g_1727 g_1446 g_3142.f1 g_499 g_2004 g_2886
 */
static const int32_t  func_263(uint64_t  p_264, int8_t * p_265, const uint64_t  p_266)
{ /* block id: 1058 */
    int32_t l_2793 = 0x2E21EF5CL;
    int16_t l_2794 = 0x7A4AL;
    int16_t l_2803 = 0xEC08L;
    int32_t *l_2804[2];
    uint16_t l_2805 = 65535UL;
    int8_t **l_2824 = &g_28;
    int16_t ****l_2863 = &g_1029;
    int32_t l_2884 = 7L;
    uint32_t l_2934 = 0x7D2E3168L;
    uint64_t l_3018 = 7UL;
    int64_t **l_3037 = &g_538[2];
    int8_t l_3079 = 4L;
    uint32_t l_3083[9];
    int16_t * const l_3121 = &l_2794;
    int16_t * const *l_3120 = &l_3121;
    int16_t * const **l_3119 = &l_3120;
    int16_t * const ***l_3118[10][7] = {{&l_3119,&l_3119,&l_3119,&l_3119,(void*)0,&l_3119,&l_3119},{&l_3119,&l_3119,(void*)0,&l_3119,&l_3119,&l_3119,&l_3119},{&l_3119,&l_3119,(void*)0,&l_3119,&l_3119,&l_3119,&l_3119},{&l_3119,&l_3119,&l_3119,&l_3119,(void*)0,&l_3119,&l_3119},{(void*)0,&l_3119,&l_3119,(void*)0,&l_3119,&l_3119,&l_3119},{&l_3119,&l_3119,&l_3119,&l_3119,&l_3119,(void*)0,&l_3119},{&l_3119,&l_3119,&l_3119,&l_3119,&l_3119,(void*)0,&l_3119},{&l_3119,&l_3119,&l_3119,(void*)0,&l_3119,&l_3119,&l_3119},{&l_3119,&l_3119,(void*)0,&l_3119,&l_3119,(void*)0,&l_3119},{&l_3119,&l_3119,&l_3119,&l_3119,(void*)0,(void*)0,&l_3119}};
    int16_t * const ****l_3117 = &l_3118[4][2];
    int64_t l_3138 = (-1L);
    uint16_t *l_3167 = (void*)0;
    uint8_t **l_3173 = &g_656;
    union U3 *l_3203 = &g_3204;
    int i, j;
    for (i = 0; i < 2; i++)
        l_2804[i] = &g_499[0][0];
    for (i = 0; i < 9; i++)
        l_3083[i] = 4294967295UL;
    l_2805 &= (((l_2793 || ((l_2794 >= (safe_mod_func_int64_t_s_s(p_266, 0xB5FE41CD94991403LL))) && ((((safe_mul_func_int8_t_s_s((g_1218[8][4] , (safe_add_func_uint64_t_u_u(8UL, (((safe_mul_func_int8_t_s_s((l_2793 != (((*p_265) && 0xFAL) == 1UL)), l_2803)) || l_2794) && 0x70BAEA4427A07EE3LL)))), 255UL)) , 6L) , 1L) , l_2803))) & l_2803) , l_2794);
    if (p_266)
    { /* block id: 1060 */
        union U3 **l_2810 = &g_746;
        union U3 ***l_2809 = &l_2810;
        union U3 ****l_2808 = &l_2809;
        int32_t l_2815 = 0x7036B522L;
        int32_t l_2887 = 5L;
        uint8_t **l_2911 = &g_656;
        union U5 **l_2923 = &g_1070;
        int32_t *l_2927 = (void*)0;
        int32_t l_2995[9][3] = {{(-1L),(-7L),1L},{0xC366FA33L,0xC366FA33L,0x289F59E0L},{(-1L),0x289F59E0L,(-7L)},{(-7L),0x289F59E0L,(-1L)},{0xC366FA33L,(-1L),(-1L)},{0x75852534L,0L,0x6990FBD0L},{1L,(-1L),0L},{1L,0x289F59E0L,0xC366FA33L},{0x75852534L,(-2L),0x75852534L}};
        int8_t l_3015 = 0x32L;
        uint32_t l_3023 = 0x0BB2F9CEL;
        int32_t *****l_3038 = &g_2718;
        uint16_t ***l_3052 = &g_714;
        uint16_t ****l_3051 = &l_3052;
        uint16_t *****l_3050 = &l_3051;
        int16_t *l_3103 = &l_2794;
        uint64_t l_3149 = 0x46E54F23389F063BLL;
        int32_t l_3158[10][3][1] = {{{0xD4AED378L},{8L},{1L}},{{1L},{1L},{8L}},{{0xD4AED378L},{8L},{1L}},{{1L},{1L},{8L}},{{0xD4AED378L},{8L},{1L}},{{1L},{1L},{8L}},{{0xD4AED378L},{8L},{1L}},{{1L},{1L},{8L}},{{0xD4AED378L},{8L},{1L}},{{1L},{1L},{8L}}};
        uint16_t *l_3169[5] = {&l_2805,&l_2805,&l_2805,&l_2805,&l_2805};
        int16_t *****l_3180 = (void*)0;
        int16_t l_3188 = (-5L);
        int i, j, k;
        for (g_188 = 0; (g_188 > 47); ++g_188)
        { /* block id: 1063 */
            union U3 ****l_2811 = &l_2809;
            union U3 *****l_2812 = &g_1503;
            union U3 *****l_2813 = &g_1503;
            union U3 *****l_2814 = &l_2811;
            const int32_t l_2820 = 0x425F5104L;
            int32_t l_2821[6][2][6] = {{{0x761BCA9BL,0x7CEC0154L,0x1647F7C8L,(-9L),0xE0A5FE3CL,0xA490DA09L},{0x92F5982EL,(-1L),0x034D0585L,(-1L),(-5L),(-9L)}},{{(-1L),1L,0xDD196261L,1L,(-1L),0xBB48C356L},{0xDD196261L,0xA490DA09L,1L,3L,(-1L),(-1L)}},{{1L,0xE0A5FE3CL,0xBFD28FE8L,0xA490DA09L,0x97DB561CL,(-1L)},{0L,0xED112D82L,1L,0x761BCA9BL,0xC89D979AL,0xBB48C356L}},{{0x97DB561CL,1L,0xDD196261L,(-9L),0xBFD28FE8L,(-9L)},{0xA490DA09L,0x1647F7C8L,0x034D0585L,0x034D0585L,0x1647F7C8L,0xA490DA09L}},{{(-1L),1L,0x1647F7C8L,(-6L),0x92F5982EL,(-1L)},{(-9L),0x761BCA9BL,2L,0x97DB561CL,1L,0xC89D979AL}},{{(-9L),4L,0x97DB561CL,(-6L),(-9L),0xFD11974AL},{(-1L),0x92F5982EL,(-1L),0x034D0585L,(-1L),(-5L)}}};
            uint8_t l_2885 = 0xA9L;
            uint16_t *l_2913 = &l_2805;
            union U5 **l_2922 = &g_1070;
            int32_t *l_2928 = &g_499[1][0];
            int32_t *l_2929 = &l_2884;
            const uint8_t *****l_2947 = &g_2451[1][8][1];
            int32_t *****l_3078 = &g_2718;
            int i, j, k;
        }
        if ((safe_sub_func_uint64_t_u_u(p_266, p_266)))
        { /* block id: 1188 */
            int8_t l_3166 = (-3L);
            uint16_t *l_3168 = &l_2805;
            uint16_t **l_3170 = &l_3168;
            const int16_t * const *l_3179 = (void*)0;
            const int16_t * const **l_3178 = &l_3179;
            const int16_t * const ***l_3177 = &l_3178;
            const int16_t * const ****l_3176[6][5][7] = {{{&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177},{&l_3177,(void*)0,&l_3177,&l_3177,&l_3177,(void*)0,&l_3177},{&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177},{&l_3177,&l_3177,&l_3177,(void*)0,&l_3177,&l_3177,&l_3177},{&l_3177,(void*)0,&l_3177,&l_3177,&l_3177,(void*)0,&l_3177}},{{&l_3177,&l_3177,(void*)0,&l_3177,&l_3177,&l_3177,&l_3177},{&l_3177,&l_3177,(void*)0,&l_3177,&l_3177,&l_3177,&l_3177},{(void*)0,&l_3177,(void*)0,&l_3177,&l_3177,&l_3177,&l_3177},{(void*)0,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177},{&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177}},{{&l_3177,&l_3177,&l_3177,(void*)0,&l_3177,&l_3177,&l_3177},{&l_3177,&l_3177,(void*)0,&l_3177,&l_3177,&l_3177,(void*)0},{&l_3177,&l_3177,&l_3177,&l_3177,(void*)0,&l_3177,(void*)0},{&l_3177,&l_3177,&l_3177,&l_3177,(void*)0,&l_3177,&l_3177},{(void*)0,&l_3177,&l_3177,&l_3177,(void*)0,&l_3177,&l_3177}},{{&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177},{&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177},{&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177},{(void*)0,&l_3177,(void*)0,&l_3177,&l_3177,&l_3177,&l_3177},{&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177}},{{&l_3177,&l_3177,(void*)0,&l_3177,&l_3177,&l_3177,&l_3177},{&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177},{&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177},{&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177},{&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177}},{{&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177,&l_3177},{&l_3177,&l_3177,(void*)0,(void*)0,&l_3177,&l_3177,&l_3177},{&l_3177,&l_3177,&l_3177,(void*)0,&l_3177,&l_3177,&l_3177},{&l_3177,&l_3177,(void*)0,&l_3177,&l_3177,&l_3177,(void*)0},{&l_3177,&l_3177,&l_3177,&l_3177,(void*)0,&l_3177,(void*)0}}};
            int32_t l_3181[3][9][8] = {{{0x57490011L,2L,0xC19BBCC8L,1L,0x433538C3L,1L,(-6L),1L},{0x4F700D4DL,5L,0x2F0C8EC3L,5L,0x4F700D4DL,(-3L),0xD6B7D9FBL,(-6L)},{1L,0xD6B7D9FBL,1L,1L,1L,0x27025939L,0xB92557A9L,5L},{0x6A1B42C0L,0xC52F6831L,1L,0xE64809D6L,0x3C84A35AL,0x14E604A0L,0xD6B7D9FBL,0xC19BBCC8L},{1L,(-5L),0x2F0C8EC3L,(-6L),(-1L),0xB2A3FBADL,(-6L),0L},{(-1L),1L,0xC19BBCC8L,6L,0xAC585978L,0x3C84A35AL,1L,(-1L)},{0xCE07C823L,0xAD4BFCDBL,0L,0x5F53F482L,7L,0xF7DEC948L,0L,0xCA1BBC37L},{0xC19BBCC8L,(-1L),(-1L),0xC52F6831L,0x3C84A35AL,(-6L),0x14E604A0L,2L},{0xCF8D817CL,2L,0x483441E5L,0xD0EC3E6AL,0x6117C123L,0xD8D0AD66L,0xCF8D817CL,0x095C499BL}},{{0x5BEA22D9L,3L,0x7A346C01L,1L,0xAD4BFCDBL,0xB2A3FBADL,4L,0L},{(-1L),(-1L),0x02A61A51L,0L,0xC19BBCC8L,(-1L),1L,0x5BEA22D9L},{0xD0EC3E6AL,4L,(-3L),0L,0x6117C123L,1L,1L,0x6117C123L},{1L,0xB0832346L,0xB0832346L,1L,7L,(-5L),0x1871A107L,0x7A346C01L},{0xC19BBCC8L,0x6117C123L,(-1L),4L,0x4D4F3FD1L,0x4F700D4DL,(-9L),1L},{0x6EA1E2F5L,0x6117C123L,0x512767ABL,0xB2A3FBADL,(-1L),(-5L),0L,(-1L)},{1L,0xB0832346L,7L,6L,0xCA1BBC37L,1L,0x4D4F3FD1L,0xB0832346L},{7L,4L,1L,0x1871A107L,0x14E604A0L,(-1L),0xB92557A9L,1L},{1L,(-1L),(-5L),3L,7L,0xB2A3FBADL,0xB13F037BL,0x5F53F482L}},{{1L,3L,9L,1L,0x7A346C01L,0xD8D0AD66L,0x4D4F3FD1L,7L},{(-1L),2L,0x465BDC0FL,0x4D4F3FD1L,2L,(-6L),1L,(-1L)},{0xB0832346L,(-1L),0x512767ABL,0xB13F037BL,1L,0xF7DEC948L,3L,4L},{0x433538C3L,0xAD4BFCDBL,0xCF8D817CL,0xB92557A9L,0L,0L,0x1871A107L,9L},{1L,1L,0x6A1B42C0L,0x4D4F3FD1L,6L,0xA1DD0F04L,6L,0x4D4F3FD1L},{(-3L),0x27025939L,(-3L),0L,4L,0x2449769FL,0xB2A3FBADL,0x5F53F482L},{0x14E604A0L,0x2F0C8EC3L,(-3L),(-9L),0x6EA1E2F5L,7L,4L,0xCF8D817CL},{0x14E604A0L,0xC52F6831L,(-6L),0x1871A107L,4L,5L,1L,0L},{(-3L),0x14E604A0L,0x483441E5L,1L,6L,0x483441E5L,0L,(-1L)}}};
            int i, j, k;
            for (g_232 = 1; (g_232 < 16); g_232 = safe_add_func_int8_t_s_s(g_232, 6))
            { /* block id: 1191 */
                union U3 *l_3163 = &g_3164;
                (**l_2809) = l_3163;
            }
            l_2995[3][2] ^= ((safe_unary_minus_func_int64_t_s((0x8EL >= ((l_3166 = ((***l_3119) &= p_264)) | (((*g_715) = p_264) > (((*g_656) = (p_264 && (((l_3167 = &l_2805) == ((*l_3170) = (l_3169[0] = l_3168))) < (((safe_add_func_uint8_t_u_u((l_3173 == (((safe_mul_func_uint8_t_u_u((l_3176[0][2][6] == l_3180), 0xE3L)) != l_3181[2][1][7]) , (void*)0)), 255UL)) , 0xE636B887A22C2971LL) > p_266)))) || p_264)))))) == p_264);
        }
        else
        { /* block id: 1202 */
            int32_t *l_3182 = &g_38;
            int32_t **l_3183 = (void*)0;
            int32_t **l_3184 = &l_2804[1];
            int32_t l_3187 = 0xB94357F9L;
            l_2995[8][1] &= p_264;
            (*l_3184) = l_3182;
            l_3188 ^= (l_3187 = (safe_rshift_func_int16_t_s_u(0x1E85L, 11)));
        }
    }
    else
    { /* block id: 1208 */
        int32_t **l_3189 = &l_2804[0];
        int16_t ****l_3195 = &g_1029;
        int16_t *****l_3196 = &l_3195;
        uint32_t *l_3198[2][4] = {{&g_3142.f1,&g_1181,&g_3142.f1,&g_1181},{&g_3142.f1,&g_1181,&g_3142.f1,&g_1181}};
        union U3 **l_3205 = &g_746;
        union U3 **l_3206[4][1];
        int i, j;
        for (i = 0; i < 4; i++)
        {
            for (j = 0; j < 1; j++)
                l_3206[i][j] = &l_3203;
        }
        (*l_3189) = &l_2884;
        (**l_3189) = (safe_lshift_func_uint16_t_u_s(((((!(safe_sub_func_int8_t_s_s((((*l_3196) = l_3195) != (void*)0), (((((**l_3189) > (((g_3197 == ((++g_3142.f1) , g_3197)) || (--p_264)) > ((((*g_1541) & (((((-7L) <= 5UL) <= (*g_28)) != (-1L)) , p_266)) > 0x5FL) & 0L))) && 0xAF80L) , (*g_28)) == p_266)))) != 65531UL) == (*g_1541)) > p_266), 4));
        l_3203 = ((*l_3205) = l_3203);
        for (g_2004 = 5; (g_2004 >= 28); g_2004++)
        { /* block id: 1218 */
            int16_t l_3209 = 0x4AD7L;
            const int8_t *l_3212 = &g_2857.f2;
            const int8_t **l_3211 = &l_3212;
            const int8_t ***l_3210 = &l_3211;
            const int8_t ****l_3213 = (void*)0;
            const int8_t ****l_3214 = &l_3210;
            l_3209 ^= (**l_3189);
            (*l_3214) = l_3210;
        }
    }
    for (g_2886 = 0; (g_2886 < (-6)); g_2886 = safe_sub_func_int32_t_s_s(g_2886, 9))
    { /* block id: 1225 */
        const int16_t l_3217 = 0x0783L;
        if (p_264)
            break;
        return l_3217;
    }
    return p_266;
}


/* ------------------------------------------ */
/* 
 * reads : g_1273 g_1995.f1 g_1920.f1 g_306 g_1351 g_3 g_1636 g_188 g_2045 g_1727 g_1446 g_499
 * writes: g_653 g_1920.f1 g_1273 g_2482 g_1995.f1 g_306 g_1351 g_1636 g_188 g_2045 g_1727 g_1446 g_495 g_499
 */
static int8_t * func_267(uint8_t * p_268, uint8_t  p_269)
{ /* block id: 937 */
    int32_t *l_2478 = &g_3;
    int32_t **l_2479 = &g_653;
    int32_t l_2513 = 0x93F3382CL;
    int8_t l_2553 = (-1L);
    int32_t l_2560 = 0L;
    int32_t l_2561 = 0L;
    int32_t l_2562[7] = {0x0143A31AL,0x0143A31AL,0x0143A31AL,0x0143A31AL,0x0143A31AL,0x0143A31AL,0x0143A31AL};
    struct S1 *l_2593 = (void*)0;
    uint16_t l_2607[4][9][5] = {{{0xBFC3L,1UL,0x5ACDL,2UL,1UL},{0xBFC3L,0UL,0x150FL,1UL,0x8974L},{0xB5B2L,0x8974L,0x2982L,0x2982L,0x8974L},{0xFCC6L,65535UL,0x2982L,1UL,65535UL},{0xFCC6L,0x8974L,0UL,1UL,0x8974L},{0xB5B2L,0x8974L,0x2982L,0x2982L,0x8974L},{0xFCC6L,65535UL,0x2982L,1UL,65535UL},{0xFCC6L,0x8974L,0UL,1UL,0x8974L},{0xB5B2L,0x8974L,0x2982L,0x2982L,0x8974L}},{{0xFCC6L,65535UL,0x2982L,1UL,65535UL},{0xFCC6L,0x8974L,0UL,1UL,0x8974L},{0xB5B2L,0x8974L,0x2982L,0x2982L,0x8974L},{0xFCC6L,65535UL,0x2982L,1UL,65535UL},{0xFCC6L,0x8974L,0UL,1UL,0x8974L},{0xB5B2L,0x8974L,0x2982L,0x2982L,0x8974L},{0xFCC6L,65535UL,0x2982L,1UL,65535UL},{0xFCC6L,0x8974L,0UL,1UL,0x8974L},{0xB5B2L,0x8974L,0x2982L,0x2982L,0x8974L}},{{0xFCC6L,65535UL,0x2982L,1UL,65535UL},{0xFCC6L,0x8974L,0UL,1UL,0x8974L},{0xB5B2L,0x8974L,0x2982L,0x2982L,0x8974L},{0xFCC6L,65535UL,0x2982L,1UL,65535UL},{0xFCC6L,0x8974L,0UL,1UL,0x8974L},{0xB5B2L,0x8974L,0x2982L,0x2982L,0x8974L},{0xFCC6L,65535UL,0x2982L,1UL,65535UL},{0xFCC6L,0x8974L,0UL,1UL,0x8974L},{0xB5B2L,0x8974L,0x2982L,0x2982L,0x8974L}},{{0xFCC6L,65535UL,0x2982L,1UL,65535UL},{0xFCC6L,0x8974L,0UL,1UL,0x8974L},{0xB5B2L,0x8974L,0x2982L,0x2982L,0x8974L},{0xFCC6L,65535UL,0x2982L,1UL,65535UL},{0xFCC6L,0x8974L,0UL,1UL,0x8974L},{0xB5B2L,0x8974L,0x2982L,0x2982L,0x8974L},{0xFCC6L,65535UL,0x2982L,1UL,65535UL},{0xFCC6L,0x8974L,0UL,1UL,0x8974L},{0xB5B2L,0x8974L,0x2982L,0x2982L,0x8974L}}};
    int16_t *l_2620 = &g_78;
    uint32_t l_2626 = 9UL;
    uint8_t l_2636[1][1][9] = {{{0x3DL,0x3DL,0x3DL,0x3DL,0x3DL,0x3DL,0x3DL,0x3DL,0x3DL}}};
    union U3 *l_2668 = (void*)0;
    uint32_t l_2756[3];
    uint16_t l_2778 = 0UL;
    const uint32_t * const l_2784 = &g_66;
    const uint32_t * const *l_2783 = &l_2784;
    const uint32_t * const *l_2788 = (void*)0;
    const uint32_t * const l_2790 = &g_2791;
    const uint32_t * const *l_2789 = &l_2790;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_2756[i] = 0x647CF284L;
lbl_2483:
    (*l_2479) = l_2478;
    for (g_1920.f1 = 0; (g_1920.f1 <= 0); g_1920.f1 += 1)
    { /* block id: 941 */
        int64_t l_2487 = (-1L);
        int32_t l_2506 = 7L;
        int32_t l_2508[3];
        int32_t l_2527 = 0L;
        uint32_t l_2528 = 0x0B95866DL;
        int8_t *l_2555 = (void*)0;
        uint32_t l_2648 = 0UL;
        int32_t *l_2758 = &l_2513;
        int i;
        for (i = 0; i < 3; i++)
            l_2508[i] = 0L;
        for (g_1273 = 0; (g_1273 <= 0); g_1273 += 1)
        { /* block id: 944 */
            const int32_t *l_2480 = &g_8;
            const int32_t **l_2481 = &l_2480;
            int32_t l_2489 = 0L;
            int32_t l_2507 = 0x2702EAA8L;
            int32_t l_2509 = 3L;
            int32_t l_2511 = 0x2BF26E89L;
            int32_t l_2512 = (-1L);
            int32_t l_2514 = 0x2A0644BEL;
            uint8_t l_2515 = 5UL;
            int32_t *l_2518 = &g_499[1][0];
            int32_t *l_2519 = (void*)0;
            int32_t *l_2520 = (void*)0;
            int32_t *l_2521 = &g_255;
            int32_t *l_2522 = &g_499[0][0];
            int32_t *l_2523 = &l_2512;
            int32_t *l_2524 = &l_2511;
            int32_t *l_2525 = &l_2514;
            int32_t *l_2526[8][7][4] = {{{(void*)0,&l_2508[2],&g_499[0][0],&l_2506},{&g_255,&l_2509,(void*)0,&g_499[0][0]},{&l_2508[2],&g_7[6][3][0],&g_255,&g_163},{&l_2507,&l_2508[2],&g_255,&g_255},{&l_2506,&l_2508[2],(void*)0,&g_11},{&g_499[0][0],&g_163,(void*)0,(void*)0},{&l_2512,&l_2489,&l_2512,(void*)0}},{{&g_163,&g_499[0][0],(void*)0,(void*)0},{&l_2507,(void*)0,&l_2509,&g_499[0][0]},{&g_499[0][0],(void*)0,&l_2509,&g_11},{&l_2507,&g_499[0][0],(void*)0,&l_2509},{&g_163,&l_2508[2],&l_2512,&l_2506},{&l_2512,&l_2506,(void*)0,&l_2506},{&g_499[0][0],(void*)0,(void*)0,(void*)0}},{{&l_2506,&l_2513,&g_255,&g_255},{&l_2507,&l_2507,&g_255,(void*)0},{&l_2506,(void*)0,&l_2514,&l_2506},{&l_2513,&l_2508[2],(void*)0,&l_2514},{&g_163,&l_2508[2],(void*)0,&l_2506},{&l_2508[2],(void*)0,&l_2511,(void*)0},{&g_499[0][0],&l_2507,&l_2508[2],&g_255}},{{&g_163,&l_2513,(void*)0,(void*)0},{&l_2513,(void*)0,&g_255,&l_2506},{&g_499[0][0],&l_2506,&l_2509,&l_2506},{(void*)0,&l_2508[2],&g_255,&l_2509},{&g_163,&g_499[0][0],&l_2508[2],&g_11},{&l_2512,(void*)0,&l_2513,&g_499[0][0]},{&l_2512,(void*)0,&l_2508[2],(void*)0}},{{&g_163,&g_499[0][0],&g_255,(void*)0},{(void*)0,&l_2489,&l_2509,(void*)0},{&g_499[0][0],&g_163,&g_255,&g_11},{&l_2513,&l_2508[2],(void*)0,&g_255},{&g_163,&l_2508[2],&l_2508[2],&g_163},{&g_499[0][0],&l_2506,&l_2511,&g_499[0][0]},{&l_2508[2],&l_2489,(void*)0,&g_255}},{{&g_163,&g_499[0][0],(void*)0,&g_255},{&l_2513,&l_2489,&l_2514,&g_499[0][0]},{&l_2506,&l_2506,&g_255,&g_163},{&l_2507,&l_2508[2],&g_255,&g_255},{&l_2506,&l_2508[2],(void*)0,&g_11},{&g_499[0][0],&g_163,(void*)0,(void*)0},{&l_2512,&l_2489,&l_2512,(void*)0}},{{&g_163,&g_499[0][0],(void*)0,(void*)0},{&l_2507,(void*)0,&l_2509,&g_499[0][0]},{&g_499[0][0],(void*)0,&l_2509,&g_11},{&l_2507,&g_499[0][0],(void*)0,&l_2509},{&g_163,&l_2508[2],&l_2512,&l_2506},{&l_2512,&l_2506,(void*)0,&l_2506},{&g_499[0][0],(void*)0,(void*)0,(void*)0}},{{&l_2506,&l_2513,&g_255,&g_255},{&g_7[6][4][0],&g_7[6][4][0],&l_2513,&l_2507},{&g_255,&g_499[0][0],&l_2511,&l_2512},{&g_499[1][0],&l_2506,&l_2514,&l_2511},{&l_2508[2],&l_2506,&l_2513,&l_2512},{&l_2506,&g_499[0][0],(void*)0,&l_2507},{&g_499[0][0],&g_7[6][4][0],&l_2506,&l_2508[2]}}};
            int i, j, k;
            g_2482[0][1][5] = ((*l_2481) = l_2480);
            for (g_1995.f1 = 0; (g_1995.f1 <= 0); g_1995.f1 += 1)
            { /* block id: 949 */
                int32_t *l_2484 = &g_499[(g_1273 + 1)][g_1920.f1];
                int64_t l_2485[10][7] = {{4L,9L,(-1L),0x2FB756E4039356C8LL,0x2FB756E4039356C8LL,(-1L),9L},{0x2FB756E4039356C8LL,(-7L),0x62BE4034550F60ACLL,0x780F051A6216AF57LL,(-7L),0x513FE9A7421E14A1LL,9L},{(-1L),0x2FB756E4039356C8LL,0x513FE9A7421E14A1LL,(-1L),9L,(-1L),0x513FE9A7421E14A1LL},{0x065EC65D42EC7970LL,0x065EC65D42EC7970LL,0xA17074559599D0E8LL,0x780F051A6216AF57LL,0x2FB756E4039356C8LL,0xFEBA87735AD48774LL,0x065EC65D42EC7970LL},{0x065EC65D42EC7970LL,0x513FE9A7421E14A1LL,0x62BE4034550F60ACLL,0x2FB756E4039356C8LL,1L,1L,0x2FB756E4039356C8LL},{(-1L),9L,(-1L),0x513FE9A7421E14A1LL,0x2FB756E4039356C8LL,(-1L),(-7L)},{0x2FB756E4039356C8LL,9L,0xE83304241FCEABDDLL,0x780F051A6216AF57LL,9L,0xA17074559599D0E8LL,9L},{4L,0x513FE9A7421E14A1LL,0x513FE9A7421E14A1LL,4L,(-7L),(-1L),0x2FB756E4039356C8LL},{1L,0x065EC65D42EC7970LL,0x513FE9A7421E14A1LL,0x62BE4034550F60ACLL,0x2FB756E4039356C8LL,1L,1L},{0x065EC65D42EC7970LL,0x2FB756E4039356C8LL,0xE83304241FCEABDDLL,0x2FB756E4039356C8LL,0x065EC65D42EC7970LL,0xFEBA87735AD48774LL,0x2FB756E4039356C8LL}};
                int32_t *l_2486 = (void*)0;
                int32_t *l_2488 = &g_499[0][0];
                int32_t *l_2490 = &g_255;
                int32_t *l_2491 = &l_2489;
                int32_t *l_2492 = &g_499[(g_1273 + 1)][g_1920.f1];
                int32_t *l_2493 = (void*)0;
                int32_t *l_2494 = &g_499[(g_1920.f1 + 2)][g_1920.f1];
                int32_t *l_2495 = &l_2489;
                int32_t *l_2496 = (void*)0;
                int32_t *l_2497 = &g_255;
                int32_t *l_2498 = &g_499[0][0];
                int32_t *l_2499 = &g_499[0][0];
                int32_t *l_2500 = &g_499[(g_1920.f1 + 2)][g_1920.f1];
                int32_t *l_2501 = &g_499[(g_1273 + 1)][g_1920.f1];
                int32_t *l_2502 = &g_499[(g_1273 + 1)][g_1920.f1];
                int32_t *l_2503 = &g_499[1][0];
                int32_t *l_2504 = &l_2489;
                int32_t *l_2505[6][1] = {{&g_163},{&g_499[(g_1920.f1 + 2)][g_1920.f1]},{&g_163},{&g_499[(g_1920.f1 + 2)][g_1920.f1]},{&g_163},{&g_499[(g_1920.f1 + 2)][g_1920.f1]}};
                int32_t l_2510 = 0x9D88F355L;
                int i, j;
                if (g_1273)
                    goto lbl_2483;
                l_2515--;
            }
            ++l_2528;
        }
        for (g_306 = 0; (g_306 <= 0); g_306 += 1)
        { /* block id: 957 */
            int32_t l_2554[5][9] = {{0xC6A59FF7L,1L,(-8L),0x85BA2C0BL,(-8L),1L,0xC6A59FF7L,0L,1L},{0x85BA2C0BL,1L,0L,6L,(-1L),0x8BB26D80L,0L,(-1L),1L},{0xC6A59FF7L,(-8L),0L,0L,0L,0L,0L,0L,(-8L)},{0xD153DB88L,0L,0x8BB26D80L,0xEC345823L,0L,0x8BB26D80L,0xC6A59FF7L,(-8L),0L},{6L,(-1L),0x8BB26D80L,0L,(-1L),1L,0xEC345823L,1L,(-1L)}};
            uint32_t l_2563 = 0xEBEF6734L;
            int32_t l_2592 = 0L;
            int64_t *l_2616 = &g_539[1];
            int32_t l_2664 = (-3L);
            int32_t l_2694 = 0xC06B5A8CL;
            union U4 *l_2712 = &g_2713;
            int i, j;
        }
        (*l_2758) = p_269;
    }
    for (g_1351 = 0; (g_1351 == 39); g_1351 = safe_add_func_uint8_t_u_u(g_1351, 7))
    { /* block id: 1047 */
        int16_t l_2761 = 5L;
        int32_t l_2762 = 0x4AC155EAL;
        int32_t *l_2763 = &l_2561;
        int32_t *l_2764 = &g_255;
        int32_t *l_2765 = &l_2560;
        int32_t *l_2766 = &l_2513;
        int32_t *l_2767 = &l_2762;
        int32_t l_2768[8];
        int32_t *l_2769 = &l_2768[1];
        int32_t *l_2770 = &l_2560;
        int32_t *l_2771 = (void*)0;
        int32_t *l_2772 = &l_2560;
        int32_t *l_2773 = &l_2768[1];
        int32_t *l_2774 = &g_499[0][0];
        int32_t *l_2775 = &l_2562[3];
        int32_t *l_2776 = &g_499[0][0];
        int32_t *l_2777[8][2][2] = {{{&g_7[2][5][1],&l_2560},{&g_7[2][5][1],&g_7[2][5][1]}},{{&g_7[2][5][1],&l_2560},{&g_7[2][5][1],&g_7[2][5][1]}},{{&g_7[2][5][1],&l_2560},{&g_7[2][5][1],&g_7[2][5][1]}},{{&g_7[2][5][1],&l_2560},{&g_7[2][5][1],&g_7[2][5][1]}},{{&g_7[2][5][1],&l_2560},{&g_7[2][5][1],&g_7[2][5][1]}},{{&g_7[2][5][1],&l_2560},{&g_7[2][5][1],&g_7[2][5][1]}},{{&g_7[2][5][1],&l_2560},{&g_7[2][5][1],&g_7[2][5][1]}},{{&g_7[2][5][1],&l_2560},{&g_7[2][5][1],&g_7[2][5][1]}}};
        const uint32_t * const **l_2785 = &l_2783;
        const uint32_t * const *l_2787[6][9] = {{&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784},{&l_2784,&l_2784,&l_2784,&l_2784,(void*)0,&l_2784,&l_2784,(void*)0,&l_2784},{&l_2784,(void*)0,&l_2784,&l_2784,(void*)0,&l_2784,&l_2784,&l_2784,(void*)0},{(void*)0,&l_2784,&l_2784,(void*)0,(void*)0,&l_2784,&l_2784,(void*)0,&l_2784},{&l_2784,(void*)0,&l_2784,&l_2784,(void*)0,&l_2784,(void*)0,&l_2784,&l_2784},{&l_2784,&l_2784,&l_2784,&l_2784,(void*)0,&l_2784,(void*)0,&l_2784,&l_2784}};
        const uint32_t * const **l_2786[6][9][4] = {{{&l_2787[0][8],&l_2787[0][8],(void*)0,&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],(void*)0,&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],(void*)0,&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]}},{{&l_2787[0][8],&l_2787[0][8],(void*)0,&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],(void*)0,&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],(void*)0,&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]}},{{&l_2787[0][8],&l_2787[0][8],(void*)0,&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],(void*)0,&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],(void*)0,&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]}},{{&l_2787[0][8],&l_2787[0][8],(void*)0,&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],(void*)0,&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],(void*)0,&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]}},{{&l_2787[0][8],&l_2787[0][8],(void*)0,&l_2787[0][8]},{&l_2787[0][8],&l_2787[0][8],(void*)0,&l_2787[0][8]},{(void*)0,&l_2787[0][8],(void*)0,(void*)0},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],(void*)0,(void*)0,&l_2787[0][8]},{(void*)0,&l_2787[0][8],(void*)0,(void*)0},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],(void*)0,(void*)0,&l_2787[0][8]},{(void*)0,&l_2787[0][8],(void*)0,(void*)0}},{{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],(void*)0,(void*)0,&l_2787[0][8]},{(void*)0,&l_2787[0][8],(void*)0,(void*)0},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],(void*)0,(void*)0,&l_2787[0][8]},{(void*)0,&l_2787[0][8],(void*)0,(void*)0},{&l_2787[0][8],&l_2787[0][8],&l_2787[0][8],&l_2787[0][8]},{&l_2787[0][8],(void*)0,(void*)0,&l_2787[0][8]},{(void*)0,&l_2787[0][8],(void*)0,(void*)0}}};
        uint8_t *l_2792[7][1][5] = {{{(void*)0,(void*)0,&g_2725,(void*)0,(void*)0}},{{&g_2170,&g_2170,&g_2170,&g_2355,&l_2636[0][0][8]}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&l_2636[0][0][8],&g_2170,(void*)0,&g_2170,&l_2636[0][0][8]}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&l_2636[0][0][8],&g_2355,&g_2170,&g_2170,&g_2170}},{{(void*)0,(void*)0,&g_2725,(void*)0,(void*)0}}};
        int i, j, k;
        for (i = 0; i < 8; i++)
            l_2768[i] = (-1L);
        ++l_2778;
        (*l_2774) ^= (safe_add_func_uint8_t_u_u(((*p_268) &= (*l_2478)), (p_269 = (g_495 = ((l_2789 = (l_2788 = ((*l_2785) = l_2783))) != &l_2790)))));
    }
    return p_268;
}


/* ------------------------------------------ */
/* 
 * reads : g_431 g_929 g_930 g_1020 g_446 g_66 g_1674 g_28 g_29 g_656 g_657 g_232 g_1727 g_1181 g_1676 g_1677 g_1678 g_1541 g_715 g_466 g_499 g_1540 g_998 g_255 g_495 g_1168 g_1920.f1 g_2037 g_1070 g_723 g_2045 g_922.f2 g_306 g_1224 g_1675 g_1216 g_1509 g_845 g_328 g_748 g_538 g_653 g_2170 g_38 g_2355 g_2388 g_1470 g_2386.f2 g_1396 g_2450
 * writes: g_431 g_306 g_1181 g_1674 g_1621 g_232 g_951 g_1396 g_653 g_255 g_1727 g_998 g_857 g_499 g_657 g_466 g_495 g_1020 g_845 g_922.f2 g_1920.f1 g_1224 g_1351 g_1509 g_2170 g_922.f1 g_774 g_1216 g_2302 g_746 g_748 g_446 g_538 g_930 g_2433
 */
static uint8_t * func_270(int16_t  p_271, union U3 * p_272, uint16_t  p_273, uint32_t  p_274, uint32_t  p_275)
{ /* block id: 612 */
    int32_t l_1690 = (-1L);
    int32_t l_1693 = 0x6951E154L;
    int32_t l_1695 = 0xD6B1B833L;
    int32_t l_1697 = (-2L);
    int32_t l_1703[2];
    int32_t *l_1722 = &g_255;
    uint32_t l_1783[2][5][7] = {{{0xC135BEA2L,0x7CEBDD7FL,0xC135BEA2L,0x7CEBDD7FL,0xC135BEA2L,0x7CEBDD7FL,0xC135BEA2L},{0xEC09B59CL,0x7E9CC09BL,0x7E9CC09BL,0xEC09B59CL,0xEC09B59CL,0x7E9CC09BL,0x7E9CC09BL},{0x1F98F00DL,0x7CEBDD7FL,0x1F98F00DL,0x7CEBDD7FL,0x1F98F00DL,0x7CEBDD7FL,0x1F98F00DL},{0xEC09B59CL,0xEC09B59CL,0x7E9CC09BL,0x7E9CC09BL,0xEC09B59CL,0xEC09B59CL,0x7E9CC09BL},{0xC135BEA2L,0x7CEBDD7FL,0xC135BEA2L,0x7CEBDD7FL,0xC135BEA2L,0x7CEBDD7FL,0xC135BEA2L}},{{0xEC09B59CL,0x7E9CC09BL,0x7E9CC09BL,0xEC09B59CL,0xEC09B59CL,0x7E9CC09BL,0x7E9CC09BL},{0x1F98F00DL,0x7CEBDD7FL,0x1F98F00DL,0x7CEBDD7FL,0x1F98F00DL,0x7CEBDD7FL,0x1F98F00DL},{0xEC09B59CL,0xEC09B59CL,0x7E9CC09BL,0x7E9CC09BL,0xEC09B59CL,0xEC09B59CL,0x7E9CC09BL},{0xC135BEA2L,0x7CEBDD7FL,0xC135BEA2L,0x7CEBDD7FL,0xC135BEA2L,0x7CEBDD7FL,0xC135BEA2L},{0xEC09B59CL,0x7E9CC09BL,0x7E9CC09BL,0xEC09B59CL,0xEC09B59CL,0x7E9CC09BL,0x7E9CC09BL}}};
    uint32_t l_1848[10] = {18446744073709551609UL,0x2D899337L,18446744073709551609UL,0x2D899337L,18446744073709551609UL,0x2D899337L,18446744073709551609UL,0x2D899337L,18446744073709551609UL,0x2D899337L};
    int32_t ***l_1862 = &g_1207;
    int16_t ****l_1955[1][9] = {{&g_1029,&g_1029,&g_1029,&g_1029,&g_1029,&g_1029,&g_1029,&g_1029,&g_1029}};
    uint64_t ***l_1977 = &g_1540;
    union U4 **l_1992 = &g_1168[9];
    const uint8_t *** const **l_2008 = (void*)0;
    uint32_t *l_2016 = &g_1020;
    int8_t *l_2021 = &g_431;
    int32_t *l_2040[1][5];
    int64_t *l_2041 = &g_845;
    int64_t l_2042 = 0L;
    int8_t *l_2043 = &g_1621[0];
    int8_t l_2044 = 0xB0L;
    int32_t l_2047 = (-3L);
    uint64_t l_2069 = 1UL;
    int32_t l_2072 = 0x13B3260EL;
    uint8_t l_2126 = 5UL;
    uint32_t l_2154 = 1UL;
    int32_t l_2173 = 0xB50DDE86L;
    int64_t l_2185 = (-5L);
    uint32_t l_2253 = 18446744073709551614UL;
    uint32_t l_2369 = 0x69D65E68L;
    union U5 *l_2385 = &g_2386;
    uint8_t l_2447 = 0x4CL;
    int8_t **l_2462 = &l_2021;
    uint32_t l_2476 = 0xAADEAAC7L;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1703[i] = 0x96BDDAFFL;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 5; j++)
            l_2040[i][j] = &g_951;
    }
    for (g_431 = 0; (g_431 < 20); g_431 = safe_add_func_uint16_t_u_u(g_431, 9))
    { /* block id: 615 */
        int64_t l_1648 = 0x316DEEB6AD8D24CFLL;
        int32_t l_1685 = 0x32D6B527L;
        int32_t l_1698 = 0x8D5ADB2DL;
        int32_t l_1699[2][9] = {{0x72030A4AL,0x72030A4AL,0x72030A4AL,0x72030A4AL,0x72030A4AL,0x72030A4AL,0x72030A4AL,0x72030A4AL,0x72030A4AL},{(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)}};
        int8_t *l_1721 = &g_29;
        uint64_t ***l_1760 = &g_1540;
        uint8_t **l_1807 = &g_656;
        uint8_t ***l_1806 = &l_1807;
        uint8_t l_1809 = 1UL;
        const int32_t *l_1831 = &g_38;
        const int32_t **l_1830 = &l_1831;
        const int32_t ***l_1829 = &l_1830;
        int32_t ***l_1889 = &g_1207;
        const struct S0 *l_1917 = &g_1918[3][3][2];
        int16_t l_1929 = 0x17F4L;
        int16_t ***l_1972 = &g_1030[0][0];
        int16_t ***l_1986 = &g_1030[0][5];
        uint32_t l_1991 = 18446744073709551614UL;
        int i, j;
        for (g_306 = 0; (g_306 <= 4); g_306 = safe_add_func_uint64_t_u_u(g_306, 4))
        { /* block id: 618 */
            uint8_t l_1671 = 0xEFL;
            int32_t l_1673[2];
            uint16_t l_1704 = 0UL;
            uint16_t ***l_1741 = &g_714;
            uint16_t **** const l_1740 = &l_1741;
            int16_t l_1778 = 4L;
            uint16_t *l_1792 = &g_306;
            uint16_t ** const l_1791 = &l_1792;
            uint16_t ** const *l_1790 = &l_1791;
            uint16_t ** const **l_1789[4];
            int i;
            for (i = 0; i < 2; i++)
                l_1673[i] = 0x1078E6DDL;
            for (i = 0; i < 4; i++)
                l_1789[i] = &l_1790;
            if ((safe_lshift_func_uint16_t_u_s(p_273, 5)))
            { /* block id: 619 */
                int32_t l_1670 = 0xADFA2429L;
                int32_t l_1680 = 0L;
                int32_t l_1689 = 0x31AA71A4L;
                int32_t l_1691 = 1L;
                int32_t l_1696 = 1L;
                uint16_t ***l_1757 = &g_714;
                union U3 *l_1758 = &g_1759;
                if (l_1648)
                    break;
                for (g_1181 = 0; (g_1181 > 16); g_1181 = safe_add_func_int32_t_s_s(g_1181, 1))
                { /* block id: 623 */
                    int32_t *l_1672[7] = {&g_7[2][5][1],(void*)0,(void*)0,&g_7[2][5][1],(void*)0,(void*)0,&g_7[2][5][1]};
                    int8_t *l_1679 = &g_1621[0];
                    int32_t **l_1681 = &l_1672[6];
                    int16_t *l_1682 = (void*)0;
                    int16_t *l_1683 = (void*)0;
                    int16_t *l_1684 = &g_232;
                    uint32_t l_1700 = 1UL;
                    int i;
                    l_1680 = ((+p_273) <= ((safe_sub_func_int8_t_s_s(((*l_1679) = (safe_lshift_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u((**g_929), ((safe_lshift_func_int8_t_s_s(((safe_sub_func_int8_t_s_s(p_275, (safe_div_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_s((safe_sub_func_uint8_t_u_u(((p_274 | (l_1673[0] = (l_1670 , l_1671))) ^ (((g_1674 = g_1674) == &g_1675) >= p_273)), (*g_28))), 3)), (-10L))))) | 4L), (*g_28))) | p_273))), l_1648))), (*g_656))) , p_273));
                    (*l_1681) = l_1672[6];
                    l_1685 = (((*l_1684) &= 0xF35AL) , p_273);
                    for (g_951 = 0; (g_951 > 8); g_951 = safe_add_func_uint64_t_u_u(g_951, 9))
                    { /* block id: 633 */
                        int64_t l_1688 = 0x64183F52B76F8175LL;
                        int32_t l_1692 = (-1L);
                        int32_t l_1694[8][6][5] = {{{1L,1L,0xB10CBFB8L,0x6456A406L,0x3D665650L},{(-1L),1L,(-1L),(-5L),(-1L)},{0x940FBE29L,0L,0x41990CB6L,0x715B2A52L,1L},{0x92A631FDL,0x6456A406L,(-1L),0xBE90971CL,0xA500398FL},{0xA5AF4887L,0x73861E8BL,1L,0x89B15EF5L,0x18FBEA10L},{1L,0x3E854A73L,0x5CFC5245L,0x68044F49L,0xB21DA081L}},{{1L,0L,0xCBA1837AL,1L,0xC93CE499L},{1L,(-10L),4L,5L,0x02372BA4L},{0x6456A406L,0x02372BA4L,(-1L),0x3398CE36L,0xD4A1B2CBL},{0x126E8AE9L,0x0DB6500EL,0xA500398FL,1L,0xD4A1B2CBL},{(-7L),1L,0xC0822F56L,0xA5BF4C41L,0x02372BA4L},{0xD37EDEF4L,0xA5BF4C41L,0xA7149B2AL,1L,0xC93CE499L}},{{0x3398CE36L,0x578F7B6EL,0x516408C2L,1L,0xB21DA081L},{0x0E190A72L,(-1L),0xF9FD07B2L,0x26549D05L,0x18FBEA10L},{0xE9837609L,0x89B15EF5L,(-1L),(-1L),0xA500398FL},{0xB10CBFB8L,0x92A631FDL,0x73861E8BL,0x02372BA4L,1L},{0x0853408EL,1L,2L,(-1L),(-1L)},{(-6L),0xC540E338L,(-6L),0xC0822F56L,0x3D665650L}},{{0xC0822F56L,0x516408C2L,0x60362A67L,0x4ACA26EFL,0x578F7B6EL},{0x578F7B6EL,0xE9837609L,0L,(-6L),(-10L)},{0x36CFB85EL,0x2431F7ABL,0x60362A67L,0x578F7B6EL,0L},{(-1L),0x26549D05L,(-6L),0x40346393L,(-1L)},{(-1L),5L,2L,0xE9837609L,0x77DEF072L},{0xD1205395L,0x7996470EL,0x73861E8BL,(-10L),1L}},{{1L,(-2L),(-1L),(-1L),0x6456A406L},{0xD4A1B2CBL,1L,0xF9FD07B2L,1L,0x36CFB85EL},{0x7996470EL,(-1L),0x516408C2L,(-7L),0L},{1L,0xCBA1837AL,0xA7149B2AL,1L,1L},{0x7BBB8CDEL,(-1L),0xC0822F56L,(-1L),0x68044F49L},{0x77DEF072L,0L,0xA500398FL,0L,(-1L)}},{{0x77DEF072L,4L,(-1L),0xB21DA081L,0x3E854A73L},{0x7BBB8CDEL,(-1L),4L,0x5F863632L,0x26549D05L},{1L,0xD4A1B2CBL,0xCBA1837AL,0x77DEF072L,0x73861E8BL},{(-5L),(-1L),0xA7149B2AL,0x94F65337L,(-7L)},{0x36CFB85EL,0xB7DC81D0L,1L,1L,0L},{0x516408C2L,1L,1L,0x41990CB6L,0xA5BF4C41L}},{{1L,0x73861E8BL,1L,1L,0xE9837609L},{0L,0x0DB6500EL,0x0DB6500EL,0L,4L},{0x0DB6500EL,(-1L),0x3E854A73L,0x02372BA4L,0L},{1L,0x92A631FDL,0x126E8AE9L,0x26549D05L,0xFEA51F3DL},{0x2431F7ABL,(-1L),0x94F65337L,0x02372BA4L,(-1L)},{0x77DEF072L,0x6456A406L,0x516408C2L,0L,0xBE90971CL}},{{0xB7DC81D0L,0xD1205395L,0xA5AF4887L,1L,0x77DEF072L},{0xA500398FL,1L,0L,0x41990CB6L,0xBC3EBB29L},{0x3E854A73L,0x126E8AE9L,0xD37EDEF4L,1L,0x41990CB6L},{0x715B2A52L,1L,0x36CFB85EL,0x94F65337L,0xB10CBFB8L},{0xD37EDEF4L,(-8L),0xD1205395L,0x0E190A72L,(-5L)},{0x40346393L,1L,0x68044F49L,0xA5BF4C41L,0x94F65337L}}};
                        int i, j, k;
                        l_1700++;
                        if (p_274)
                            continue;
                        l_1704++;
                    }
                }
                for (g_1396 = (-21); (g_1396 >= 19); ++g_1396)
                { /* block id: 641 */
                    union U4 **l_1716 = &g_1168[1];
                    union U4 ***l_1715 = &l_1716;
                    int32_t l_1719 = (-3L);
                    int32_t *l_1724 = &l_1685;
                    int32_t *l_1725 = &g_499[0][0];
                    int32_t *l_1726 = &l_1673[0];
                    const volatile uint8_t **l_1732 = &g_777;
                    if ((safe_lshift_func_int8_t_s_u((safe_lshift_func_int8_t_s_u(((1L != ((p_271 | ((&g_1168[4] != ((*l_1715) = &g_1168[9])) , ((safe_lshift_func_int8_t_s_u((l_1689 |= l_1719), 6)) >= ((void*)0 == &g_1070)))) > (l_1648 == (~(((void*)0 == l_1721) < l_1696))))) < 0xF4D6D7739533D67DLL), 1)), 2)))
                    { /* block id: 644 */
                        int32_t **l_1723 = &g_653;
                        (*l_1723) = (l_1722 = &l_1695);
                    }
                    else
                    { /* block id: 647 */
                        (*l_1722) = (p_275 , p_275);
                    }
                    g_1727++;
                    if (p_273)
                    { /* block id: 651 */
                        const volatile uint8_t **l_1731 = (void*)0;
                        const volatile uint8_t ***l_1730[7];
                        int64_t *l_1752 = (void*)0;
                        int64_t *l_1753 = (void*)0;
                        uint64_t *l_1754[2];
                        int8_t *l_1755 = (void*)0;
                        int8_t *l_1756 = &g_1621[0];
                        int i;
                        for (i = 0; i < 7; i++)
                            l_1730[i] = &l_1731;
                        for (i = 0; i < 2; i++)
                            l_1754[i] = &g_857;
                        l_1732 = ((*l_1724) , &g_777);
                        (*l_1724) = (safe_lshift_func_int16_t_s_u((0xD2B9L <= (((*l_1756) = ((~(l_1698 & (((safe_mod_func_int16_t_s_s((((((g_1181--) , l_1740) != (((((-2L) ^ (safe_add_func_int64_t_s_s((&p_273 == &p_273), (g_857 = ((~p_271) == (safe_unary_minus_func_uint32_t_u(((safe_rshift_func_int16_t_s_s((((*l_1722) = (safe_mul_func_int8_t_s_s((((*g_1541) = (p_271 | (((safe_sub_func_uint16_t_u_u(((*g_28) > l_1673[0]), p_274)) != 1UL) <= (***g_1676)))) | 4L), (*g_656)))) ^ 0x8BC7388BFE918B13LL), l_1670)) , l_1673[0])))))))) == (**g_929)) , 0x3C8E0274L) , &l_1741)) ^ p_273) , p_273), p_275)) , l_1699[0][3]) == 1UL))) < 0x121EA191FDF11628LL)) > p_273)), (*g_715)));
                        (*l_1740) = l_1757;
                    }
                    else
                    { /* block id: 660 */
                        l_1758 = (void*)0;
                        (*l_1725) ^= 3L;
                    }
                }
                (*l_1722) = ((void*)0 != l_1760);
            }
            else
            { /* block id: 666 */
                union U4 **l_1766 = &g_1168[4];
                int32_t l_1786 = (-1L);
                uint16_t ** const *l_1788 = &g_714;
                uint16_t ** const **l_1787 = &l_1788;
                int32_t l_1802 = (-5L);
                for (g_1181 = 0; (g_1181 <= 5); g_1181++)
                { /* block id: 669 */
                    int32_t l_1765 = 4L;
                    int32_t l_1800 = 1L;
                    int32_t l_1801 = 0x61D67E2EL;
                    int32_t *l_1808[1];
                    int i;
                    for (i = 0; i < 1; i++)
                        l_1808[i] = &l_1673[1];
                    for (g_1727 = (-3); (g_1727 < 58); g_1727 = safe_add_func_uint8_t_u_u(g_1727, 4))
                    { /* block id: 672 */
                        union U4 ***l_1767 = &l_1766;
                        uint16_t ** const ***l_1793 = &l_1787;
                        int32_t *l_1794 = &l_1685;
                        int32_t *l_1795 = &l_1673[0];
                        int32_t *l_1796 = &g_499[0][0];
                        int32_t *l_1797 = &l_1673[1];
                        int32_t *l_1798 = (void*)0;
                        int32_t *l_1799[3];
                        uint32_t l_1803 = 0x8A09E51CL;
                        int i;
                        for (i = 0; i < 3; i++)
                            l_1799[i] = &l_1695;
                        if (l_1765)
                            break;
                        (*l_1722) = (((l_1698 = (p_271 ^ (((*l_1767) = l_1766) != ((safe_add_func_uint32_t_u_u((((4UL != (p_274 > (safe_div_func_int32_t_s_s(((-1L) || ((*g_656) &= ((safe_mul_func_uint8_t_u_u(((safe_mod_func_uint8_t_u_u((safe_mod_func_uint16_t_u_u(l_1778, ((safe_rshift_func_uint16_t_u_s(0x4586L, (safe_mul_func_uint8_t_u_u(l_1783[1][0][6], (((safe_mod_func_uint8_t_u_u(((p_275 != p_271) & 1UL), l_1685)) , (-9L)) , p_273))))) | 0x72C8D855L))), 0x80L)) <= 3UL), 0x6BL)) & p_271))), 0x70348971L)))) != l_1786) > (**g_1540)), l_1765)) , &g_1168[9])))) <= (*g_1541)) >= l_1699[1][7]);
                        (*l_1793) = (l_1789[1] = l_1787);
                        l_1803--;
                    }
                    (*l_1722) ^= ((l_1704 & 0xD679L) & ((((*g_715) = (l_1802 , ((void*)0 == l_1806))) ^ l_1786) == 0xA968L));
                    ++l_1809;
                }
            }
        }
        for (g_495 = 0; (g_495 != 24); g_495 = safe_add_func_int32_t_s_s(g_495, 8))
        { /* block id: 690 */
            int32_t l_1821 = 0x5E206783L;
            int32_t ***l_1861[8];
            uint64_t ***l_1965 = &g_1540;
            int32_t *l_1973[1][8] = {{&l_1703[1],&g_499[0][0],&l_1703[1],&l_1703[1],&g_499[0][0],&l_1703[1],&l_1703[1],&g_499[0][0]}};
            const uint8_t *l_2013 = &g_657;
            const uint8_t **l_2012 = &l_2013;
            const uint8_t *** const l_2011 = &l_2012;
            const uint8_t *** const *l_2010[2];
            const uint8_t *** const **l_2009[2];
            int i, j;
            for (i = 0; i < 8; i++)
                l_1861[i] = &g_1207;
            for (i = 0; i < 2; i++)
                l_2010[i] = &l_2011;
            for (i = 0; i < 2; i++)
                l_2009[i] = &l_2010[0];
        }
    }
    if ((((void*)0 == (*l_1992)) < (safe_mod_func_uint64_t_u_u((((++(*l_2016)) , ((*l_2016) = ((safe_mul_func_int8_t_s_s((*g_28), ((*l_2021) = (*g_28)))) >= ((!((safe_lshift_func_uint8_t_u_s((safe_rshift_func_int8_t_s_u((-1L), 3)), 2)) ^ ((((safe_mod_func_uint8_t_u_u(((*g_656)--), (safe_mod_func_int8_t_s_s(((*l_2043) = ((g_1920.f1 , ((*l_2041) = ((((((***l_1977) = (0x8AC1C45537423EC6LL <= 1UL)) , ((*l_1722) = (((((safe_add_func_int32_t_s_s(((safe_div_func_int8_t_s_s(8L, p_271)) , 0x9767B2A3L), p_274)) , g_2037) != &l_1862) , (*l_1722)) < p_275))) , g_1070) != (void*)0) | g_723))) || l_2042)), l_1693)))) , (**g_1540)) < p_271) & (-1L)))) ^ l_2044)))) && p_274), g_2045))))
    { /* block id: 765 */
        int32_t *l_2046[6] = {&l_1697,&g_8,&g_8,&l_1697,&g_8,&g_8};
        int i;
        l_2046[4] = l_2046[4];
        g_922.f2 ^= ((*l_1722) = (l_2047 ^ (safe_mul_func_uint16_t_u_u((+(safe_mul_func_int8_t_s_s(((safe_sub_func_uint16_t_u_u(((((((*g_715) |= (safe_sub_func_int8_t_s_s(((safe_add_func_int16_t_s_s(((safe_sub_func_uint32_t_u_u((safe_sub_func_int16_t_s_s(((((safe_sub_func_int64_t_s_s((-7L), ((**g_1540)--))) | 4L) > (safe_add_func_int64_t_s_s(l_2069, ((((*l_1722) != (**g_929)) | 1L) , (((((p_275 >= (safe_div_func_int8_t_s_s(((*l_1722) ^ (*g_28)), p_275))) , (-10L)) != 0xFD92L) , (*l_1722)) <= p_273))))) , p_274), (*l_1722))), 0UL)) > 3L), p_271)) ^ l_2072), 0L))) ^ (*l_1722)) >= p_271) , (**g_929)) <= 0x104AE4C5L), p_271)) == 0xD11EC3413F2E239ELL), p_273))), p_275))));
        for (g_306 = 0; (g_306 > 35); g_306 = safe_add_func_uint16_t_u_u(g_306, 2))
        { /* block id: 773 */
            uint32_t l_2077[6] = {1UL,1UL,1UL,1UL,1UL,1UL};
            int32_t l_2086 = 0L;
            uint32_t *l_2093 = (void*)0;
            uint32_t *l_2094 = &l_1783[1][0][6];
            int32_t l_2095 = 0x7EEF9D9DL;
            int32_t l_2096 = 0xE6AF23C3L;
            uint16_t l_2103 = 9UL;
            uint8_t * const l_2105 = (void*)0;
            int8_t l_2117 = 0x64L;
            int i;
            l_2096 ^= ((safe_div_func_int32_t_s_s((l_2077[4] = p_275), (safe_rshift_func_int16_t_s_u((((((((safe_add_func_uint16_t_u_u(p_275, (safe_mul_func_int8_t_s_s(((safe_div_func_int32_t_s_s((l_2086 = (*l_1722)), (safe_add_func_uint64_t_u_u(p_273, ((18446744073709551615UL | ((((safe_lshift_func_uint8_t_u_s((((*l_2016) &= 1UL) & p_271), (*g_28))) > ((((*l_2094) &= (safe_add_func_uint64_t_u_u((0x944EL != p_274), 18446744073709551614UL))) ^ p_274) | 9UL)) , 255UL) | 0xA3L)) >= 0xA117149625D19972LL))))) > p_271), l_2095)))) , 0x2089B672L) && p_275) == 0x82037980FF03B7DFLL) || l_2086) == p_273) ^ 0L), 7)))) != 0xBC9113D52859DF0ELL);
            for (g_1920.f1 = 0; (g_1920.f1 < 58); g_1920.f1++)
            { /* block id: 781 */
                for (g_1224 = 14; (g_1224 == 1); g_1224--)
                { /* block id: 784 */
                    return &g_1727;
                }
            }
            (*l_1722) = (safe_sub_func_int8_t_s_s(l_2103, (0xE2C1A615B21241D9LL & ((~((l_2105 == l_2021) , (safe_rshift_func_int8_t_s_u((((+((!(+(((l_2077[4] | (safe_rshift_func_uint16_t_u_u((5UL != (((safe_mul_func_int8_t_s_s((*g_28), (safe_mul_func_uint16_t_u_u(l_2117, (safe_mul_func_int16_t_s_s((safe_add_func_uint8_t_u_u(((((safe_rshift_func_uint8_t_u_s((((safe_mod_func_uint64_t_u_u(((l_2096 = p_273) || (**g_929)), 0xE6577966DCABF9F0LL)) == 0xA1DFCE322A4A07A0LL) & 18446744073709551615UL), 1)) == p_275) , (***g_1675)) == &p_271), (*g_656))), p_271)))))) >= p_274) , l_2126)), 15))) | (-1L)) ^ (*l_1722)))) <= (*l_1722))) == 0x275FDC26L) != l_2077[3]), 2)))) | (*l_1722)))));
        }
    }
    else
    { /* block id: 791 */
        uint8_t l_2137 = 1UL;
        int32_t l_2166 = 0x00CFEDDFL;
        int32_t l_2241[9][9][3] = {{{0L,0L,0x312947FEL},{(-3L),0x567DCB78L,0x567DCB78L},{0x58156C04L,0x5DDD4873L,0xC062FAF0L},{7L,0x0860EF50L,1L},{0x58156C04L,0x312947FEL,7L},{(-3L),1L,0L},{0L,0x312947FEL,0x5DDD4873L},{0x95E6B638L,0x0860EF50L,0x1012C528L},{0x89BE7F04L,0x5DDD4873L,0x5DDD4873L}},{{0x6C7AC4F2L,0x567DCB78L,0L},{(-8L),0L,7L},{0x6C7AC4F2L,0x1012C528L,1L},{0x89BE7F04L,0x30723008L,0xC062FAF0L},{0x95E6B638L,0x1012C528L,0x567DCB78L},{0L,0L,0x312947FEL},{(-3L),0x567DCB78L,0x567DCB78L},{0x58156C04L,0x5DDD4873L,0xC062FAF0L},{7L,0x0860EF50L,1L}},{{0x58156C04L,0x312947FEL,7L},{(-3L),1L,0L},{0L,0x312947FEL,0x5DDD4873L},{0x95E6B638L,0x0860EF50L,0x1012C528L},{0x89BE7F04L,0x5DDD4873L,0x5DDD4873L},{0x6C7AC4F2L,0x567DCB78L,0L},{(-8L),0L,7L},{0x6C7AC4F2L,0x1012C528L,1L},{0x89BE7F04L,0x30723008L,0xC062FAF0L}},{{0x95E6B638L,0x1012C528L,0x567DCB78L},{0L,0L,0x312947FEL},{(-3L),0x567DCB78L,0x567DCB78L},{0x58156C04L,0x5DDD4873L,0xC062FAF0L},{7L,0x0860EF50L,1L},{(-1L),0L,(-1L)},{0x567DCB78L,6L,0x291044EEL},{0x30723008L,0L,0xD503A747L},{1L,0L,7L}},{{0x5DDD4873L,0xD503A747L,0xD503A747L},{0x4CF5A01AL,(-6L),0x291044EEL},{0xC062FAF0L,0xAC9E3B86L,(-1L)},{0x4CF5A01AL,7L,1L},{0x5DDD4873L,0x8DFF8183L,0x06865EC3L},{1L,7L,(-6L)},{0x30723008L,0xAC9E3B86L,0L},{0x567DCB78L,(-6L),(-6L)},{(-1L),0xD503A747L,0x06865EC3L}},{{0L,0L,1L},{(-1L),0L,(-1L)},{0x567DCB78L,6L,0x291044EEL},{0x30723008L,0L,0xD503A747L},{1L,0L,7L},{0x5DDD4873L,0xD503A747L,0xD503A747L},{0x4CF5A01AL,(-6L),0x291044EEL},{0xC062FAF0L,0xAC9E3B86L,(-1L)},{0x4CF5A01AL,7L,1L}},{{0x5DDD4873L,0x8DFF8183L,0x06865EC3L},{1L,7L,(-6L)},{0x30723008L,0xAC9E3B86L,0L},{0x567DCB78L,(-6L),(-6L)},{(-1L),0xD503A747L,0x06865EC3L},{0L,0L,1L},{(-1L),0L,(-1L)},{0x567DCB78L,6L,0x291044EEL},{0x30723008L,0L,0xD503A747L}},{{1L,0L,7L},{0x5DDD4873L,0xD503A747L,0xD503A747L},{0x4CF5A01AL,(-6L),0x291044EEL},{0xC062FAF0L,0xAC9E3B86L,(-1L)},{0x4CF5A01AL,7L,1L},{0x5DDD4873L,0x8DFF8183L,0x06865EC3L},{1L,7L,(-6L)},{0x30723008L,0xAC9E3B86L,0L},{0x567DCB78L,(-6L),(-6L)}},{{(-1L),0xD503A747L,0x06865EC3L},{0L,0L,1L},{(-1L),0L,(-1L)},{0x567DCB78L,6L,0x291044EEL},{0x30723008L,0L,0xD503A747L},{1L,0L,7L},{0x5DDD4873L,0xD503A747L,0xD503A747L},{0x4CF5A01AL,(-6L),0x291044EEL},{0xC062FAF0L,0xAC9E3B86L,(-1L)}}};
        int32_t *l_2243 = &g_499[2][0];
        uint64_t ****l_2262 = &l_1977;
        union U4 **l_2317[1][6] = {{&g_1168[5],&g_1168[5],&g_1168[5],&g_1168[5],&g_1168[5],&g_1168[5]}};
        uint16_t ***l_2319 = &g_714;
        uint8_t **l_2343 = &g_656;
        uint32_t l_2382 = 0xEB7CC8E7L;
        union U5 **l_2387 = &l_2385;
        uint64_t l_2403[4] = {1UL,1UL,1UL,1UL};
        uint32_t l_2423 = 0UL;
        union U3 *l_2429 = &g_2430;
        int16_t l_2431[7] = {0x1D42L,0x29EDL,0x1D42L,0x1D42L,0x29EDL,0x1D42L,0x1D42L};
        uint8_t ****l_2455[1];
        uint8_t *****l_2454 = &l_2455[0];
        int32_t ****l_2471 = &l_1862;
        int32_t *****l_2472 = &l_2471;
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_2455[i] = (void*)0;
        for (l_1693 = 0; (l_1693 <= 24); l_1693 = safe_add_func_uint32_t_u_u(l_1693, 1))
        { /* block id: 794 */
            uint32_t l_2138[10] = {1UL,1UL,0x2F1D2F67L,1UL,1UL,0x2F1D2F67L,1UL,1UL,0x2F1D2F67L,1UL};
            int i;
            (*l_1722) |= ((safe_sub_func_uint64_t_u_u(p_274, ((safe_sub_func_uint64_t_u_u(((***l_1977) = (((p_271 , (--(*g_656))) , 0xD94ABFCFL) >= ((-1L) == (safe_add_func_int32_t_s_s((((((((&g_775 != (void*)0) >= p_274) , p_274) < (*g_1541)) > 7UL) || p_273) ^ p_274), 0x62F93DADL))))), l_2137)) , l_2138[6]))) <= p_275);
            if (l_2138[9])
                break;
        }
        for (g_1181 = (-3); (g_1181 != 29); g_1181 = safe_add_func_int32_t_s_s(g_1181, 4))
        { /* block id: 802 */
            const int32_t l_2160 = 0x6236483EL;
            const int32_t l_2165 = 0x9F3A05EFL;
            int32_t l_2168 = 0xC0F609E1L;
            uint32_t l_2171 = 0x0CF05B6EL;
            int32_t **l_2237 = &g_653;
            int32_t l_2245 = 0x19AC5676L;
            int32_t l_2246 = 0xDF6B30DCL;
            int32_t l_2252[9] = {(-8L),0x2519075BL,0x2519075BL,(-8L),0x2519075BL,0x2519075BL,(-8L),0x2519075BL,0x2519075BL};
            uint64_t ****l_2264 = &l_1977;
            uint16_t ** const * const l_2318 = &g_714;
            uint8_t **l_2350 = (void*)0;
            uint32_t **l_2357 = &g_930[1][2];
            uint32_t l_2374 = 4294967288UL;
            int32_t *l_2376 = &l_2241[1][0][1];
            int32_t *l_2377 = &l_1693;
            int32_t *l_2378 = &l_1703[1];
            int32_t *l_2379 = &l_2241[5][0][0];
            int32_t *l_2380 = &l_2173;
            int32_t *l_2381[6] = {&l_2072,&l_2072,&l_2072,&l_2072,&l_2072,&l_2072};
            int i;
            for (g_1351 = (-7); (g_1351 <= 17); g_1351 = safe_add_func_uint64_t_u_u(g_1351, 1))
            { /* block id: 805 */
                int32_t l_2172[3];
                int32_t l_2184 = 0x241C1BACL;
                uint8_t *l_2190 = &g_2045;
                int32_t *l_2191 = (void*)0;
                int i;
                for (i = 0; i < 3; i++)
                    l_2172[i] = 0xD44F424CL;
                for (g_1509 = 17; (g_1509 <= 34); g_1509 = safe_add_func_uint32_t_u_u(g_1509, 1))
                { /* block id: 808 */
                    int8_t l_2175 = 0x71L;
                    uint8_t *l_2186 = &g_1727;
                    for (g_857 = (-20); (g_857 == 48); g_857 = safe_add_func_int8_t_s_s(g_857, 9))
                    { /* block id: 811 */
                        int32_t l_2167 = 0x4CF34A08L;
                        int8_t *l_2169[4];
                        int32_t *l_2174[9][1][1] = {{{&l_1693}},{{&g_7[2][5][1]}},{{&l_1693}},{{&g_7[2][5][1]}},{{&l_1693}},{{&g_7[2][5][1]}},{{&l_1693}},{{&g_7[2][5][1]}},{{&l_1693}}};
                        int i, j, k;
                        for (i = 0; i < 4; i++)
                            l_2169[i] = &l_2044;
                        g_922.f2 ^= (l_2175 = ((((~(!(p_273 || (((*l_2041) = ((g_2170 = ((((((l_2168 &= (((*l_1722) = 0x771C82ABL) & (safe_div_func_uint32_t_u_u(((l_2166 &= (+((safe_mod_func_int32_t_s_s(l_2154, (safe_mul_func_int16_t_s_s((safe_unary_minus_func_uint16_t_u(((((4294967295UL >= (((*l_2043) = (((safe_mul_func_int16_t_s_s(l_2160, (safe_lshift_func_int8_t_s_s(((*l_2021) = (safe_div_func_int16_t_s_s(p_274, 0x2939L))), 0)))) <= 0UL) , 0L)) ^ 0x36L)) || 0UL) != l_2165) <= p_271))), l_2165)))) & 0xBB41936BL))) >= 0x1DFBL), l_2167)))) ^ 0x51L) ^ 0x18L) & 0x5A8AL) , p_273) || p_271)) , l_2171)) & p_273)))) | p_273) || l_2172[2]) && l_2173));
                        l_2168 &= (safe_sub_func_int8_t_s_s((((*g_656)++) < ((safe_lshift_func_uint16_t_u_s(((*g_28) != (safe_rshift_func_int8_t_s_s((l_2184 ^ ((((((l_2166 = (l_2137 | 0L)) == 0x7EAAL) != l_2175) , ((((***l_1977) |= (((*l_2016) = 4294967289UL) && l_2166)) == ((((&l_2168 == &l_2167) <= l_2160) | 0L) <= p_271)) == l_2175)) | 0x2C69543C427E6D8ELL) > l_2137)), p_273))), l_2185)) != p_273)), p_275));
                        return l_2186;
                    }
                }
                for (g_922.f1 = (-20); (g_922.f1 != 25); g_922.f1 = safe_add_func_uint32_t_u_u(g_922.f1, 9))
                { /* block id: 831 */
                    int32_t l_2189 = 0xE9C5EAA0L;
                    if ((p_273 , p_274))
                    { /* block id: 832 */
                        l_2166 = 0x6628325FL;
                        l_2189 = p_274;
                        if (p_271)
                            continue;
                        if (p_275)
                            break;
                    }
                    else
                    { /* block id: 837 */
                        return l_2190;
                    }
                }
                l_2191 = &l_2168;
            }
            for (p_275 = 12; (p_275 >= 26); p_275++)
            { /* block id: 845 */
                const volatile uint8_t ** volatile ***l_2194 = &g_774;
                int32_t l_2210[1];
                int32_t l_2219 = (-1L);
                int32_t l_2220 = 3L;
                int16_t l_2251 = (-2L);
                uint64_t l_2353 = 0x17658E5683BB1B71LL;
                uint32_t l_2356[8] = {0xCF03371EL,0x7CF6AB15L,0xCF03371EL,0x7CF6AB15L,0xCF03371EL,0x7CF6AB15L,0xCF03371EL,0x7CF6AB15L};
                int i;
                for (i = 0; i < 1; i++)
                    l_2210[i] = 0x3AA921C4L;
                (*l_2194) = &g_775;
                if ((safe_unary_minus_func_uint64_t_u(((safe_lshift_func_int8_t_s_u((safe_div_func_int64_t_s_s(p_273, (safe_sub_func_uint8_t_u_u(((p_274 , ((safe_sub_func_int64_t_s_s((0x44L == ((safe_add_func_uint64_t_u_u(((safe_lshift_func_int8_t_s_u(((-1L) < (safe_add_func_int8_t_s_s(l_2210[0], (((*g_715) ^= (safe_sub_func_int64_t_s_s(0xBBBB785513400471LL, (((*l_2021) = ((-6L) <= (0xE1L || (((l_2220 ^= ((safe_lshift_func_uint8_t_u_u((safe_mod_func_uint32_t_u_u((((**g_1540) = (((l_2219 = (safe_mul_func_uint8_t_u_u((p_274 >= p_271), p_273))) && (**g_1540)) ^ l_2210[0])) && 18446744073709551615UL), p_275)), l_2166)) & p_275)) , 0x95BCL) | 0xFCA5L)))) < 0xF2L)))) ^ l_2166)))), (*g_656))) < l_2168), p_271)) , p_274)), p_275)) & l_2210[0])) | l_2168), 0L)))), 2)) , (**g_1540)))))
                { /* block id: 852 */
                    int64_t l_2240 = (-4L);
                    int32_t *l_2242[7];
                    int16_t l_2338 = 0x9A37L;
                    uint8_t ***l_2345 = &l_2343;
                    uint8_t ***l_2351 = (void*)0;
                    uint8_t ***l_2352 = &l_2350;
                    int32_t l_2354 = 0xF85F768CL;
                    int i;
                    for (i = 0; i < 7; i++)
                        l_2242[i] = &g_499[0][0];
                    if ((safe_mul_func_int16_t_s_s((-2L), ((p_271 |= (l_2241[5][0][0] |= ((0x61L >= (l_2210[0] == (!(safe_unary_minus_func_uint32_t_u((safe_mod_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_u((*l_1722), 4)), ((*l_2043) = 1L)))))))) ^ ((safe_add_func_uint64_t_u_u((&p_271 == ((safe_sub_func_uint32_t_u_u((safe_sub_func_uint32_t_u_u((((((void*)0 != l_2237) | ((safe_mod_func_int16_t_s_s((l_2220 , (*g_1678)), l_2220)) <= p_274)) | p_273) <= 1L), (**g_929))), l_2240)) , (void*)0)), l_2166)) || l_2240)))) , l_2241[5][0][0]))))
                    { /* block id: 856 */
                        int16_t l_2244 = 0x605AL;
                        int32_t l_2247[5][2] = {{(-4L),(-1L)},{(-4L),(-1L)},{(-4L),(-1L)},{(-4L),(-1L)},{(-4L),(-1L)}};
                        uint64_t l_2248 = 0UL;
                        uint64_t *****l_2263 = &l_2262;
                        uint16_t *l_2274 = &g_1216[0];
                        int i, j;
                        l_2243 = l_2242[0];
                        l_2248--;
                        --l_2253;
                        l_2219 = (safe_mul_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u(((*l_2274) &= (safe_sub_func_uint64_t_u_u(((((void*)0 == &p_275) != (((*l_2263) = l_2262) == l_2264)) < ((l_2247[2][1] , ((((safe_add_func_uint8_t_u_u((safe_mod_func_uint8_t_u_u((((void*)0 == &g_775) , (safe_add_func_int32_t_s_s(p_271, ((((safe_lshift_func_uint16_t_u_s(((*g_715) = (safe_unary_minus_func_int16_t_s((-1L)))), 0)) <= 0xF9L) , p_274) || 0x2907FA10L)))), (*l_2243))), (*g_656))) > l_2210[0]) , (**g_929)) > p_273)) > (*l_2243))), 1L))), p_275)), (*g_1678)));
                    }
                    else
                    { /* block id: 864 */
                        uint32_t l_2281 = 0x26AF6E09L;
                        union U4 ***l_2301[4] = {&l_1992,&l_1992,&l_1992,&l_1992};
                        int32_t l_2308[7][2] = {{0x435FFDA8L,0xC86F6983L},{0x435FFDA8L,0xC86F6983L},{0x435FFDA8L,0xC86F6983L},{0x435FFDA8L,0xC86F6983L},{0x435FFDA8L,0xC86F6983L},{0x435FFDA8L,0xC86F6983L},{0x435FFDA8L,0xC86F6983L}};
                        uint32_t *l_2311 = &l_2171;
                        uint64_t *l_2312 = &g_1509;
                        int32_t *l_2320 = &l_2219;
                        int64_t **l_2327 = &g_538[1];
                        int i, j;
                        l_2210[0] = ((*l_1722) = (l_2210[0] , (((*l_2243) &= ((safe_mul_func_int8_t_s_s((safe_mul_func_int16_t_s_s((((safe_mul_func_uint8_t_u_u(0x23L, (*g_656))) && ((l_2219 = l_2281) || (!p_274))) < (safe_mul_func_uint8_t_u_u((safe_sub_func_int16_t_s_s((0xEBL == (*l_1722)), p_274)), p_273))), l_2251)), p_273)) && 0x1EEA11FDL)) || p_273)));
                        (*l_1722) = ((safe_lshift_func_uint8_t_u_s((safe_div_func_int16_t_s_s((safe_unary_minus_func_uint8_t_u((((*l_2041) &= (0x04L & ((safe_mul_func_uint8_t_u_u((p_274 , (~(safe_sub_func_int32_t_s_s(((*l_2243) = (safe_sub_func_int16_t_s_s(((safe_sub_func_int16_t_s_s(((((g_2302 = &g_1168[9]) == ((~(g_857 = ((safe_rshift_func_int16_t_s_u(p_274, (safe_add_func_uint64_t_u_u(((****l_2264)++), ((**g_929) & (**g_929)))))) != (((((((*l_2311) = l_2219) , (++(*l_2312))) && ((*l_1722) != (safe_rshift_func_uint16_t_u_s(p_274, 6)))) && (*g_715)) || (-1L)) , (-1L))))) , l_2317[0][5])) , l_2318) == l_2319), 8L)) >= l_2219), p_271))), 0x74EF6217L)))), (*l_1722))) < (*g_28)))) > l_2281))), 0x4E7AL)), (*g_28))) == p_274);
                        l_2320 = ((*l_2237) = &l_2219);
                        (*g_653) = (((safe_add_func_uint8_t_u_u((((*l_2016) = (safe_div_func_uint16_t_u_u((&g_845 != ((*l_2327) = func_314(p_274, (((safe_rshift_func_int16_t_s_s((-7L), (*****g_1674))) >= 0xC7L) , &g_11)))), (*g_715)))) && (0x25AFB9F6BA531946LL & (-2L))), (-1L))) , 1L) < (*g_656));
                    }
                    for (g_2170 = 0; (g_2170 <= 0); g_2170 += 1)
                    { /* block id: 885 */
                        int i, j;
                        (*l_2237) = &g_499[g_2170][g_2170];
                        return &g_188;
                    }
                    l_2241[5][0][0] &= (g_255 &= (((~(p_271 <= (((g_951 = (((safe_div_func_uint32_t_u_u(((*l_2016) &= (~(safe_mul_func_int16_t_s_s((l_2354 |= (safe_lshift_func_uint16_t_u_s(((*g_715) = (((*l_2041) = l_2338) < (((void*)0 != &g_1541) == ((((((safe_div_func_uint32_t_u_u((safe_mod_func_int8_t_s_s((((l_2343 != ((*l_2352) = ((((+((void*)0 != l_2345)) == ((***l_2345) = ((((((safe_div_func_uint64_t_u_u((safe_rshift_func_uint16_t_u_s((*l_2243), (*****g_1674))), p_273)) && (*g_28)) , 0xD56EL) , 0x99C9L) > (*g_715)) && p_273))) , p_274) , l_2350))) == (*g_1541)) & p_273), 0x4BL)), p_271)) == 0xD4266B33L) , p_273) & p_274) ^ l_2251) != 18446744073709551615UL)))), l_2353))), p_271)))), g_38)) || g_2355) != l_2356[4])) , l_2357) != &g_930[5][0]))) , (**g_1540)) ^ 0xECD04BF6D33B327DLL));
                    l_2242[0] = &l_2241[5][0][0];
                }
                else
                { /* block id: 899 */
                    uint8_t *l_2375[5];
                    int i;
                    for (i = 0; i < 5; i++)
                        l_2375[i] = &g_1636;
                    l_1697 |= (safe_sub_func_uint32_t_u_u(((safe_mul_func_uint16_t_u_u((((!p_274) >= (safe_div_func_uint32_t_u_u((safe_rshift_func_int8_t_s_u(((safe_add_func_uint64_t_u_u((p_271 , l_2369), p_275)) , ((p_274 > (((safe_lshift_func_int8_t_s_u((*l_1722), 3)) >= (((251UL | 0xC4L) && p_273) || l_2356[4])) <= p_271)) , (*g_28))), 3)), 0x254E6D5CL))) > l_2353), (*****g_1674))) , (**g_929)), l_2374));
                    return l_2375[4];
                }
                (*l_2243) = p_275;
            }
            ++l_2382;
        }
        if ((((((*l_2387) = l_2385) != g_1070) ^ ((p_275 == (((*g_929) = (*g_929)) == (((**l_2343) = ((void*)0 != g_2388)) , ((((safe_mul_func_int16_t_s_s((g_306 <= (((((*l_2016) ^= g_1470) >= ((--(*g_715)) , 0x38C3A074L)) && 18446744073709551610UL) <= p_271)), (*l_2243))) >= p_274) ^ p_275) , &l_1783[1][0][6])))) && p_273)) == (*l_1722)))
        { /* block id: 912 */
            int64_t **l_2415 = &g_538[2];
            int32_t l_2418 = 0L;
            int32_t l_2424 = 0x5577F7A6L;
            uint16_t *l_2425[8][10][1] = {{{(void*)0},{&g_1218[6][2]},{(void*)0},{&g_1216[0]},{(void*)0},{&g_1218[6][2]},{(void*)0},{&g_1216[0]},{&g_1217},{&g_1216[0]}},{{(void*)0},{&g_306},{&g_1217},{&g_1216[0]},{&g_1218[2][5]},{&g_1218[2][5]},{&g_1216[0]},{&g_1217},{&g_306},{(void*)0}},{{&g_1216[0]},{&g_1217},{&g_1216[0]},{(void*)0},{&g_1218[6][2]},{(void*)0},{&g_1216[0]},{(void*)0},{&g_1218[6][2]},{(void*)0}},{{&g_1216[0]},{&g_1217},{&g_1216[0]},{(void*)0},{&g_306},{&g_1217},{&g_1216[0]},{&g_1218[2][5]},{&g_1218[2][5]},{&g_1216[0]}},{{&g_1217},{&g_306},{(void*)0},{&g_1216[0]},{&g_1217},{&g_1216[0]},{(void*)0},{&g_1218[6][2]},{(void*)0},{&g_1216[0]}},{{(void*)0},{&g_1218[6][2]},{(void*)0},{&g_1216[0]},{&g_1217},{&g_1216[0]},{(void*)0},{&g_306},{&g_1217},{&g_1216[0]}},{{&g_1218[2][5]},{&g_1218[2][5]},{&g_1216[0]},{&g_1217},{&g_306},{(void*)0},{&g_1216[0]},{&g_1217},{&g_1216[0]},{(void*)0}},{{&g_1218[6][2]},{(void*)0},{&g_1216[0]},{(void*)0},{&g_1218[6][2]},{(void*)0},{&g_1216[0]},{&g_1217},{&g_1216[0]},{(void*)0}}};
            int32_t l_2426 = 0x073EA529L;
            union U3 * const l_2427 = &g_2428;
            int i, j, k;
            l_2241[5][0][0] ^= ((safe_rshift_func_int8_t_s_u(((((+(!((((safe_mod_func_uint16_t_u_u((safe_rshift_func_int16_t_s_s(0xF410L, (p_271 = (safe_add_func_int64_t_s_s((*l_2243), (**g_1540)))))), (*l_2243))) == (l_2403[3] == (((safe_rshift_func_int16_t_s_s((safe_lshift_func_int8_t_s_s(((*l_2043) = ((g_1396 ^= (safe_div_func_uint32_t_u_u((((safe_mod_func_uint32_t_u_u(((((((((safe_unary_minus_func_uint8_t_u((safe_mod_func_int64_t_s_s(((((*l_2415) = &l_2042) == ((safe_add_func_int8_t_s_s(((l_2418 = 0xB4E2L) >= (l_2426 ^= ((safe_sub_func_int16_t_s_s(0xF23AL, (((*g_715) = (safe_mod_func_uint16_t_u_u(((l_2424 = l_2423) != 0xBDFDL), (*l_1722)))) == 7L))) , (*l_2243)))), (*g_28))) , &g_539[1])) , (*l_2243)), g_2386.f2)))) & (*l_1722)) , l_2427) == l_2429) != p_275) | p_274) , l_2424) || 0x68A9L), p_275)) | 0xAB0AL) == (*l_2243)), 0x37BD7A44L))) , (*l_1722))), 0)), (*l_2243))) > p_275) <= p_275))) && 0x6F69L) && 1L))) < p_274) && 0xA6DFL) > l_2431[3]), 5)) ^ 0xA0E5CF7BL);
            (*l_1722) = (*l_1722);
        }
        else
        { /* block id: 923 */
            union U3 *****l_2432 = &g_1503;
            int16_t l_2437[6][2] = {{0xF671L,4L},{0x6B5DL,0xF671L},{0xAD3CL,0xAD3CL},{0xAD3CL,0xF671L},{0x6B5DL,4L},{0xF671L,4L}};
            const uint8_t *****l_2453[4] = {&g_2451[0][2][1],&g_2451[0][2][1],&g_2451[0][2][1],&g_2451[0][2][1]};
            int32_t l_2456[1];
            int32_t *l_2457 = (void*)0;
            int32_t *l_2458[8] = {&g_11,(void*)0,&g_11,(void*)0,&g_11,(void*)0,&g_11,(void*)0};
            int i, j;
            for (i = 0; i < 1; i++)
                l_2456[i] = 1L;
            g_2433[1] = l_2432;
            l_2173 &= (l_2241[0][8][0] &= ((((*g_656) ^ (safe_div_func_int32_t_s_s(((*l_2243) = (p_273 | ((((*l_2043) = 1L) <= (+l_2437[3][0])) , (l_2456[0] = ((safe_rshift_func_uint16_t_u_u(((((safe_mul_func_int16_t_s_s((0xF8L | (safe_unary_minus_func_uint64_t_u(l_2437[3][0]))), ((safe_div_func_int16_t_s_s((safe_div_func_uint16_t_u_u(l_2447, (safe_rshift_func_uint8_t_u_s(((l_2453[2] = g_2450[3][0]) != l_2454), (*l_2243))))), p_271)) && (*g_715)))) & (**g_1540)) < (*l_1722)) , p_271), l_2437[1][1])) <= (-1L)))))), p_274))) <= 249UL) <= p_275));
        }
        (*l_2243) = ((safe_unary_minus_func_uint32_t_u((safe_mul_func_int8_t_s_s(((void*)0 != l_2462), 0UL)))) && (safe_mod_func_int8_t_s_s((safe_mul_func_int8_t_s_s((safe_mul_func_int16_t_s_s((safe_mod_func_int16_t_s_s(((((*l_2472) = l_2471) != &l_1862) && (p_274 || ((0UL || (&l_1992 == ((!(safe_div_func_uint8_t_u_u(0xF3L, p_274))) , &g_2302))) == (*l_2243)))), (*g_1678))), l_2476)), (-8L))), (*l_2243))));
    }
    return &g_1446[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_431 g_499 g_723 g_1446 g_28 g_29 g_656 g_657 g_924.f1 g_1168 g_715 g_466 g_1509 g_1470 g_857 g_255 g_1540 g_1541 g_1550 g_1218 g_998 g_1020 g_188 g_653 g_922.f2 g_1636
 * writes: g_746 g_431 g_499 g_922.f1 g_723 g_657 g_1470 g_1503 g_1509 g_466 g_255 g_998 g_924.f1 g_845 g_1020 g_1224 g_930 g_188 g_1071.f0 g_653 g_922.f2 g_1636
 */
static int64_t  func_278(uint64_t  p_279, uint8_t * p_280, int32_t  p_281)
{ /* block id: 524 */
    union U3 * const l_1447 = &g_1448[3];
    union U3 **l_1449[9][8][3] = {{{&g_746,&g_746,&g_746},{&g_746,(void*)0,(void*)0},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,(void*)0}},{{&g_746,&g_746,&g_746},{&g_746,(void*)0,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,(void*)0},{&g_746,(void*)0,(void*)0},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746}},{{&g_746,&g_746,&g_746},{&g_746,(void*)0,(void*)0},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,(void*)0,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746}},{{(void*)0,&g_746,&g_746},{&g_746,&g_746,(void*)0},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,(void*)0}},{{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,(void*)0}},{{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,(void*)0,(void*)0},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746}},{{&g_746,&g_746,&g_746},{&g_746,(void*)0,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{(void*)0,&g_746,&g_746},{&g_746,&g_746,(void*)0},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746}},{{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,(void*)0},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746}},{{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,(void*)0},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746},{&g_746,&g_746,&g_746}}};
    union U3 **l_1450 = &g_746;
    int16_t l_1471[7] = {4L,4L,0x8837L,4L,4L,0x8837L,4L};
    int32_t l_1472 = 0x4C535D4EL;
    uint16_t **l_1484 = &g_715;
    const uint16_t *l_1583 = &g_1218[2][7];
    const uint16_t **l_1582 = &l_1583;
    int16_t ***l_1607 = &g_1030[0][6];
    int32_t l_1623 = 0L;
    int32_t l_1624 = 0x1D9812A6L;
    int32_t l_1627[8] = {1L,1L,1L,1L,1L,1L,1L,1L};
    int i, j, k;
    (*l_1450) = l_1447;
    for (g_431 = 0; (g_431 == (-13)); g_431 = safe_sub_func_int32_t_s_s(g_431, 1))
    { /* block id: 528 */
        int32_t *l_1453 = (void*)0;
        int32_t *l_1454 = (void*)0;
        int32_t *l_1455 = &g_499[0][0];
        union U3 **l_1464[2][3][2] = {{{&g_746,&g_746},{&g_746,&g_746},{&g_746,&g_746}},{{&g_746,&g_746},{&g_746,&g_746},{&g_746,&g_746}}};
        int32_t l_1533 = 0xF377563BL;
        uint64_t **l_1543 = (void*)0;
        uint16_t * const *l_1581[2];
        int8_t l_1592 = 6L;
        int32_t l_1615 = 1L;
        int32_t l_1619 = 0xAA4C15A3L;
        int32_t l_1628 = (-1L);
        int32_t l_1630 = (-4L);
        int32_t l_1631 = 0xD7224537L;
        int32_t l_1632 = 1L;
        int32_t l_1633 = (-1L);
        int32_t l_1634 = 0xCC75E2F3L;
        int64_t **l_1639 = (void*)0;
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_1581[i] = (void*)0;
        (*l_1455) &= (0UL & (&g_980 == (void*)0));
        for (g_922.f1 = 0; (g_922.f1 <= 9); g_922.f1 += 1)
        { /* block id: 532 */
            int64_t l_1468 = 0x78F816454467EF86LL;
            int32_t l_1505[9] = {3L,3L,3L,3L,3L,3L,3L,3L,3L};
            uint64_t **l_1545 = &g_1541;
            uint16_t * const *l_1579 = &g_715;
            int32_t **l_1594 = &g_653;
            int16_t ****l_1597 = &g_1029;
            uint8_t l_1604 = 255UL;
            const int16_t **l_1609 = (void*)0;
            const int16_t ***l_1608 = &l_1609;
            int32_t l_1617 = (-3L);
            int i;
            for (g_723 = 2; (g_723 >= 0); g_723 -= 1)
            { /* block id: 535 */
                int8_t *l_1469[3][6][3] = {{{&g_431,&g_431,&g_431},{&g_431,&g_431,&g_29},{&g_29,&g_29,&g_29},{&g_431,&g_29,&g_431},{(void*)0,(void*)0,&g_29},{(void*)0,&g_431,&g_29}},{{&g_431,&g_431,&g_431},{&g_29,&g_431,&g_431},{&g_431,(void*)0,&g_431},{&g_431,&g_29,&g_29},{&g_431,&g_29,&g_29},{&g_431,&g_431,&g_431}},{{&g_431,&g_431,&g_431},{&g_431,&g_431,&g_29},{&g_29,&g_431,&g_29},{&g_431,&g_431,&g_29},{(void*)0,&g_431,&g_431},{(void*)0,&g_431,&g_431}}};
                uint16_t **l_1480[4][5];
                union U3 ***l_1501 = &l_1449[5][3][2];
                union U3 ****l_1500 = &l_1501;
                uint64_t **l_1542 = &g_1541;
                uint64_t ***l_1544[9][7] = {{&l_1543,&l_1543,(void*)0,&g_1540,&g_1540,&l_1543,&g_1540},{&g_1540,&g_1540,&g_1540,&l_1543,&l_1543,&l_1543,&l_1543},{&g_1540,&l_1543,&l_1543,&l_1543,&l_1543,&g_1540,&g_1540},{&g_1540,&l_1543,&g_1540,&l_1543,&g_1540,&l_1543,&g_1540},{(void*)0,(void*)0,&g_1540,&g_1540,&g_1540,(void*)0,&l_1543},{&l_1543,&l_1543,&l_1543,&l_1543,&g_1540,&l_1543,&g_1540},{&g_1540,(void*)0,&l_1543,&l_1543,&g_1540,&g_1540,&g_1540},{&l_1543,(void*)0,&l_1543,&g_1540,&g_1540,&g_1540,&g_1540},{&l_1543,&l_1543,&l_1543,&l_1543,&l_1543,&g_1540,&g_1540}};
                uint32_t *l_1551 = &g_924.f1;
                int32_t l_1570 = 0x046B9EDCL;
                int i, j, k;
                for (i = 0; i < 4; i++)
                {
                    for (j = 0; j < 5; j++)
                        l_1480[i][j] = &g_715;
                }
                if ((safe_div_func_int64_t_s_s(((l_1472 = ((g_1446[g_723] == (safe_div_func_uint64_t_u_u((g_1446[g_723] || ((((*g_28) | ((*g_656) = (*g_656))) , (g_1470 = (safe_mod_func_uint32_t_u_u(((l_1449[(g_723 + 4)][(g_723 + 4)][g_723] = l_1464[0][1][1]) != (g_924.f1 , &g_328[5][4][1])), (+(((*g_656) = (*g_656)) != (((((3L > 1UL) | p_281) | 0UL) != l_1468) || 0x7647L))))))) == p_281)), 4L))) ^ l_1471[3])) > p_281), 0x432FFB3AAE4FEB76LL)))
                { /* block id: 541 */
                    return l_1471[3];
                }
                else
                { /* block id: 543 */
                    uint32_t l_1477 = 18446744073709551615UL;
                    uint16_t ***l_1481 = &g_714;
                    uint16_t ***l_1482 = (void*)0;
                    uint16_t ***l_1483[4];
                    uint64_t *l_1494 = &g_998;
                    int32_t l_1495[10][3] = {{(-10L),(-10L),(-1L)},{0x51C3213CL,0L,0x1C1D9EF6L},{0x166363FAL,(-10L),0x166363FAL},{(-1L),0x51C3213CL,0x6386DB63L},{0xD8F7C9F0L,0x166363FAL,0x166363FAL},{0x6386DB63L,(-1L),0x1C1D9EF6L},{2L,0xD8F7C9F0L,(-1L)},{0x6386DB63L,0x6386DB63L,(-1L)},{0xD8F7C9F0L,2L,(-9L)},{(-1L),0x6386DB63L,(-1L)}};
                    int i, j;
                    for (i = 0; i < 4; i++)
                        l_1483[i] = (void*)0;
                    l_1495[5][0] = (safe_sub_func_uint16_t_u_u(((safe_rshift_func_int16_t_s_u(((l_1477 = p_279) , (((l_1484 = l_1480[1][0]) != (void*)0) & ((p_279 , l_1471[4]) != ((((safe_add_func_int8_t_s_s((safe_rshift_func_uint16_t_u_s((g_1168[9] == g_1168[9]), 13)), (*g_656))) < ((safe_mul_func_int16_t_s_s((((((safe_sub_func_uint64_t_u_u((safe_unary_minus_func_int64_t_s(1L)), p_281)) , p_281) , &g_857) != l_1494) & (*g_656)), l_1477)) & p_279)) || 0x92D7L) && 0x4DL)))), (*g_715))) , l_1471[3]), 5UL));
                    for (g_1470 = 0; (g_1470 <= 0); g_1470 += 1)
                    { /* block id: 549 */
                        union U3 *****l_1502[4][6][3] = {{{&l_1500,&l_1500,&l_1500},{(void*)0,&l_1500,&l_1500},{&l_1500,&l_1500,&l_1500},{&l_1500,&l_1500,&l_1500},{(void*)0,&l_1500,&l_1500},{&l_1500,&l_1500,&l_1500}},{{&l_1500,&l_1500,&l_1500},{(void*)0,&l_1500,&l_1500},{&l_1500,&l_1500,&l_1500},{(void*)0,(void*)0,&l_1500},{(void*)0,&l_1500,&l_1500},{(void*)0,&l_1500,&l_1500}},{{&l_1500,(void*)0,&l_1500},{&l_1500,(void*)0,&l_1500},{&l_1500,&l_1500,&l_1500},{&l_1500,&l_1500,&l_1500},{(void*)0,(void*)0,&l_1500},{&l_1500,&l_1500,&l_1500}},{{(void*)0,(void*)0,&l_1500},{&l_1500,&l_1500,(void*)0},{&l_1500,&l_1500,(void*)0},{&l_1500,&l_1500,&l_1500},{&l_1500,&l_1500,&l_1500},{(void*)0,&l_1500,&l_1500}}};
                        union U3 ****l_1504 = &l_1501;
                        uint32_t *l_1506[5];
                        int32_t l_1507 = 0xEDF4CC76L;
                        int32_t l_1508[7][7][2] = {{{2L,9L},{5L,1L},{5L,9L},{2L,0x83DF4509L},{9L,0xD8A4A4C2L},{1L,0xBC5EC023L},{6L,0L}},{{0L,1L},{0L,0x6A545753L},{2L,5L},{1L,0x384F0ABCL},{0xBC5EC023L,(-6L)},{1L,8L},{0x384F0ABCL,8L}},{{1L,(-6L)},{0xBC5EC023L,0x384F0ABCL},{1L,5L},{2L,0x6A545753L},{0L,1L},{0L,0L},{6L,0xBC5EC023L}},{{1L,0xD8A4A4C2L},{9L,0x83DF4509L},{2L,9L},{5L,1L},{5L,9L},{2L,0x83DF4509L},{9L,0xD8A4A4C2L}},{{1L,0xBC5EC023L},{6L,0L},{0L,1L},{0L,0x6A545753L},{2L,5L},{1L,0x384F0ABCL},{0xBC5EC023L,(-6L)}},{{1L,8L},{0x384F0ABCL,8L},{1L,(-6L)},{0xBC5EC023L,0x384F0ABCL},{1L,5L},{2L,0x6A545753L},{0L,1L}},{{0L,0L},{6L,0xBC5EC023L},{1L,0xD8A4A4C2L},{9L,0x83DF4509L},{2L,9L},{5L,1L},{5L,9L}}};
                        int8_t * const l_1534 = (void*)0;
                        int32_t *l_1535 = &g_255;
                        int i, j, k;
                        for (i = 0; i < 5; i++)
                            l_1506[i] = &g_1020;
                        (*l_1535) &= (((safe_add_func_uint8_t_u_u((l_1472 <= 3UL), (safe_add_func_uint8_t_u_u((((g_1503 = l_1500) != l_1504) < ((++g_1509) >= (safe_rshift_func_uint16_t_u_s(l_1505[4], 12)))), (safe_div_func_int8_t_s_s(((((*g_715) = (safe_mod_func_int8_t_s_s(((safe_rshift_func_int16_t_s_u(0xE07AL, 1)) < (((safe_mul_func_uint16_t_u_u(p_281, ((!((safe_rshift_func_int8_t_s_s(((safe_mul_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_s((safe_div_func_uint64_t_u_u((safe_sub_func_uint32_t_u_u(0xDAEBD105L, (g_499[g_723][g_1470] &= ((*g_28) || 0x96L)))), l_1533)), 3)), 0xF05DL)) | 1L), l_1477)) || 1UL)) || p_279))) , (void*)0) == l_1534)), p_279))) != g_857) || l_1508[1][5][1]), l_1495[5][0])))))) < p_281) > 0L);
                    }
                }
                (*l_1455) |= ((safe_add_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_s((((*l_1551) = ((((((l_1542 = g_1540) != (l_1545 = l_1543)) & (safe_add_func_uint64_t_u_u(((**g_1540) = (p_281 >= 1L)), 0x4F66E6CD5D87AC48LL))) , p_279) && 65535UL) , (safe_sub_func_int8_t_s_s(g_1550, (*g_28))))) , p_281), 9)), (-9L))) > 1UL);
                for (g_845 = 3; (g_845 <= 9); g_845 += 1)
                { /* block id: 564 */
                    uint32_t *l_1571 = &g_1020;
                    int i, j;
                    l_1505[(g_723 + 6)] = (g_1218[(g_723 + 6)][g_723] ^ (safe_add_func_uint8_t_u_u(((((~(safe_div_func_uint64_t_u_u(((g_1446[g_723] >= (safe_rshift_func_int8_t_s_s((((*g_1541) ^ l_1468) , ((p_279 < ((**l_1484)--)) == ((((safe_rshift_func_int8_t_s_u((p_281 > ((0xA5AC641875852AC2LL & (**g_1540)) , 0UL)), 3)) & (*g_656)) && p_281) | (*g_656)))), (*g_28)))) , 18446744073709551611UL), p_281))) ^ (**g_1540)) , (*l_1455)) > (-3L)), 0x38L)));
                    (*l_1455) = (l_1471[6] != (safe_sub_func_uint64_t_u_u((l_1472 = (p_281 , p_281)), (g_1446[g_723] , (!(((*l_1571) ^= ((safe_mul_func_int8_t_s_s((l_1570 = (((*g_28) == (safe_add_func_uint8_t_u_u((*g_656), (((g_1446[g_723] ^ (l_1505[(g_723 + 6)] = (*g_28))) ^ (p_281 , p_279)) == 0x828BL)))) == 65528UL)), (*l_1455))) || (-7L))) , 18446744073709551615UL))))));
                }
            }
            for (g_1224 = 0; (g_1224 <= 2); g_1224 += 1)
            { /* block id: 576 */
                uint16_t l_1572 = 0UL;
                for (l_1468 = 0; l_1468 < 6; l_1468 += 1)
                {
                    for (g_998 = 0; g_998 < 9; g_998 += 1)
                    {
                        g_930[l_1468][g_998] = &g_1020;
                    }
                }
                --l_1572;
                (*l_1455) = 0x334100E7L;
                for (g_188 = 0; (g_188 <= 2); g_188 += 1)
                { /* block id: 582 */
                    uint32_t l_1575 = 0x5C74C871L;
                    int32_t *l_1577 = &l_1472;
                    int32_t **l_1578 = &l_1577;
                    uint16_t * const **l_1580[3][3];
                    int64_t *l_1593 = &g_1071.f0;
                    int i, j;
                    for (i = 0; i < 3; i++)
                    {
                        for (j = 0; j < 3; j++)
                            l_1580[i][j] = &l_1579;
                    }
                    (*l_1455) |= (g_1446[g_188] < ((*l_1593) = ((l_1575 >= (~((l_1581[1] = ((l_1468 && (&p_281 == ((*l_1578) = l_1577))) , l_1579)) == l_1582))) || ((safe_rshift_func_uint8_t_u_s((p_281 == (safe_div_func_uint16_t_u_u(((safe_rshift_func_int8_t_s_u(((safe_div_func_int32_t_s_s(p_279, l_1592)) <= 0x8F0CL), 6)) < (*g_715)), 0x42D1L))), 5)) <= l_1471[3]))));
                }
            }
            (*l_1594) = &p_281;
            for (l_1533 = 2; (l_1533 >= 0); l_1533 -= 1)
            { /* block id: 592 */
                int16_t ****l_1596[10] = {&g_1029,&g_1029,&g_1029,&g_1029,&g_1029,&g_1029,&g_1029,&g_1029,&g_1029,&g_1029};
                int16_t *****l_1595 = &l_1596[9];
                const int16_t ****l_1610 = &l_1608;
                uint32_t *l_1611 = &g_1020;
                int32_t l_1616 = 0xD03C3077L;
                int32_t l_1618 = 0L;
                int32_t l_1620 = 0xBC3AB7C0L;
                int32_t l_1622 = 0x77AE4C17L;
                int32_t l_1625 = 8L;
                int32_t l_1626 = 0x47064533L;
                int32_t l_1629 = (-10L);
                int i;
                g_922.f2 |= ((((*l_1595) = &g_1029) != ((*g_653) , l_1597)) ^ ((safe_mul_func_uint16_t_u_u((p_281 || ((*l_1611) = (safe_sub_func_uint16_t_u_u((((*g_656) ^ (safe_mul_func_uint16_t_u_u((((l_1472 ^= l_1604) != ((safe_rshift_func_int8_t_s_s(p_279, ((((l_1607 != ((*l_1610) = l_1608)) , 0xE9L) || 0x1DL) < (*l_1455)))) <= (*g_1541))) >= p_281), (*g_715)))) ^ p_279), p_281)))), 0x4AA0L)) == l_1471[3]));
                if ((*g_653))
                    continue;
                for (g_1509 = 0; (g_1509 <= 9); g_1509 += 1)
                { /* block id: 601 */
                    int32_t *l_1612 = &g_255;
                    int32_t *l_1613 = &g_499[0][0];
                    int32_t *l_1614[3];
                    int32_t l_1635 = 0x013395ECL;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_1614[i] = &g_499[2][0];
                    (**l_1594) = (*g_653);
                    l_1612 = &p_281;
                    (*l_1594) = &p_281;
                    --g_1636;
                }
                (*g_653) = ((void*)0 != l_1639);
            }
        }
    }
    return l_1471[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_466 g_3
 * writes: g_924.f2
 */
static uint64_t  func_282(uint32_t ** p_283)
{ /* block id: 518 */
    uint16_t l_1438 = 65532UL;
    int32_t l_1439 = (-10L);
    int32_t *l_1440[9];
    int64_t l_1441 = (-8L);
    uint8_t l_1442 = 254UL;
    int i;
    for (i = 0; i < 9; i++)
        l_1440[i] = &g_499[2][0];
    g_924.f2 = (l_1439 ^= l_1438);
    l_1441 ^= g_466;
    ++l_1442;
    return g_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_715 g_466 g_1070 g_539 g_1020 g_653 g_499 g_656 g_657 g_7 g_28 g_29 g_446 g_328 g_748 g_232 g_538 g_924.f1 g_1181 g_929 g_930 g_66 g_1207 g_163 g_998 g_255 g_1273 g_188 g_857 g_495 g_1221 g_306 g_922.f2 g_951 g_1406
 * writes: g_1070 g_539 g_431 g_748 g_499 g_1020 g_746 g_446 g_232 g_657 g_998 g_1168 g_1181 g_466 g_1207 g_653 g_924.f1 g_1224 g_188 g_495 g_306 g_922.f2 g_1351 g_1396 g_951 g_1219 g_845 g_1273 g_1220
 */
static uint32_t ** func_284(uint32_t  p_285, int16_t  p_286, int64_t  p_287)
{ /* block id: 286 */
    uint16_t *l_905 = &g_748;
    struct S0 *l_923[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    uint32_t **l_932 = &g_930[1][2];
    int32_t l_952 = 0x12331F59L;
    int32_t l_968 = 0x57DCB468L;
    uint8_t **l_973 = &g_656;
    uint8_t *** const l_972[1][3][8] = {{{&l_973,(void*)0,&l_973,&l_973,&l_973,&l_973,&l_973,&l_973},{&l_973,&l_973,&l_973,&l_973,&l_973,&l_973,&l_973,&l_973},{(void*)0,&l_973,&l_973,&l_973,&l_973,&l_973,(void*)0,&l_973}}};
    uint8_t *** const *l_971 = &l_972[0][2][2];
    int64_t l_974 = 0x3E8E74008EEE8487LL;
    int32_t l_995[1][5];
    uint32_t * const l_1019[2][1][2] = {{{&g_1020,&g_1020}},{{&g_1020,&g_1020}}};
    uint32_t * const *l_1018 = &l_1019[0][0][0];
    int16_t *l_1027 = &g_232;
    int16_t **l_1026[6] = {&l_1027,&l_1027,&l_1027,&l_1027,&l_1027,&l_1027};
    int16_t ***l_1025 = &l_1026[3];
    int64_t l_1064 = 0xC38CC9FE7ED45B5FLL;
    int32_t *l_1097 = &l_968;
    int8_t l_1178 = (-7L);
    int8_t l_1180[3][9][4] = {{{0xCFL,0x71L,0L,0x71L},{0xCFL,(-1L),0L,(-1L)},{0xCFL,0x71L,0L,0x71L},{0xCFL,(-1L),0L,(-1L)},{0xCFL,0x71L,0L,0x71L},{0xCFL,(-1L),0L,(-1L)},{0xCFL,0x71L,0L,0x71L},{0xCFL,(-1L),0L,(-1L)},{0xCFL,0x71L,0L,0x71L}},{{0xCFL,(-1L),0L,(-1L)},{0xCFL,0x71L,0L,0x71L},{0xCFL,(-1L),0L,(-1L)},{0xCFL,0x71L,0L,0x71L},{0xCFL,(-1L),0L,(-1L)},{0xCFL,0x71L,0L,0x71L},{0xCFL,(-1L),0L,(-1L)},{0xCFL,0x71L,0L,0x71L},{0xCFL,(-1L),0L,(-1L)}},{{0xCFL,0x71L,0L,0x71L},{0xCFL,(-1L),0L,(-1L)},{0xCFL,0x71L,0L,0x71L},{0xCFL,(-1L),0L,(-1L)},{0xCFL,0x71L,0L,0x71L},{0xCFL,(-1L),0L,(-1L)},{0xCFL,0x71L,0L,0x71L},{0xCFL,(-1L),0L,(-1L)},{0xCFL,0x71L,0L,0x71L}}};
    int32_t *l_1239 = &l_968;
    int16_t l_1248[8][1][8] = {{{6L,6L,(-1L),1L,0L,5L,0x3CC4L,5L}},{{0x77A1L,(-8L),1L,(-8L),0x77A1L,1L,6L,5L}},{{(-8L),0L,0x3CC4L,1L,1L,0x3CC4L,0L,(-8L)}},{{(-1L),1L,0x3CC4L,8L,6L,0x77A1L,6L,8L}},{{1L,1L,1L,5L,8L,0x77A1L,0x3CC4L,0x3CC4L}},{{0x3CC4L,1L,(-1L),(-1L),1L,0x3CC4L,8L,6L}},{{0x3CC4L,0L,(-8L),1L,8L,1L,(-8L),0L}},{{1L,(-8L),0x77A1L,1L,6L,5L,5L,6L}}};
    int64_t l_1265[8] = {4L,1L,4L,4L,1L,4L,4L,1L};
    uint16_t l_1276[10] = {0xC17AL,0x0FC1L,65534UL,0x0FC1L,65534UL,65534UL,0x0FC1L,65534UL,65534UL,0x0FC1L};
    uint32_t l_1329 = 0UL;
    uint32_t l_1350 = 0x32003679L;
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 5; j++)
            l_995[i][j] = 0x5F0B4812L;
    }
    if ((safe_mul_func_uint16_t_u_u((18446744073709551608UL | (safe_lshift_func_int16_t_s_u(0xA2D6L, (*g_715)))), (safe_lshift_func_int16_t_s_s(((l_905 != l_905) & p_286), 9)))))
    { /* block id: 287 */
        uint16_t ***l_908 = (void*)0;
        uint16_t ***l_910[9] = {&g_714,&g_714,&g_714,&g_714,&g_714,&g_714,&g_714,&g_714,&g_714};
        uint16_t ****l_909 = &l_910[2];
        int32_t l_911 = 0xD132EA18L;
        int32_t *l_917 = &g_255;
        struct S0 *l_921 = &g_922;
        uint8_t ***l_926 = (void*)0;
        uint8_t ****l_925 = &l_926;
        int32_t l_989 = 0x08D8C20FL;
        int32_t l_990 = 0xEE99DD9DL;
        int32_t l_992[1];
        int32_t l_1012[4][10][6] = {{{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L}},{{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L}},{{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L}},{{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L}}};
        uint32_t * const *l_1017 = &g_930[5][8];
        int32_t l_1062 = 1L;
        int64_t l_1065 = 0x6C0AA0B8065F6086LL;
        int32_t l_1066 = (-9L);
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_992[i] = (-1L);
    }
    else
    { /* block id: 344 */
        union U5 **l_1072 = &g_1070;
        int32_t l_1087 = (-1L);
        int8_t l_1088 = 0xF4L;
        uint8_t * const *l_1090 = &g_656;
        uint8_t * const **l_1089 = &l_1090;
        int32_t l_1122 = (-8L);
        int32_t l_1125 = (-9L);
        int32_t l_1128 = 0xFC0CE26CL;
        int32_t l_1129 = 1L;
        int32_t l_1135 = 0xF7DE4513L;
        int32_t l_1138 = 0x8581F3A9L;
        int32_t l_1139[3][4][10] = {{{(-3L),1L,0x1C384E1DL,0xB6D54553L,0L,0x3E4B51BFL,0xBC8E31BCL,0xCFB05B66L,0xE58B2023L,0xBC8E31BCL},{0L,1L,(-9L),(-9L),1L,0xB6DFF63EL,0xADEB1905L,0x56218883L,0xF2804009L,0xD842A212L},{0xD842A212L,0xE58B2023L,0x56E82A23L,0x7ADF4C5BL,0x1C384E1DL,0xC4C69A45L,0L,0xC4C69A45L,0x1C384E1DL,0x7ADF4C5BL},{1L,8L,1L,(-5L),8L,0x0B4D0E89L,(-1L),0L,0x56E82A23L,0x3E4B51BFL}},{{0L,0x7ADF4C5BL,2L,1L,0x56218883L,0x64BDEB1DL,1L,0L,0x9A6A8276L,0L},{1L,(-1L),1L,0xCFB05B66L,0x56E82A23L,(-1L),0xDE07048EL,0xC4C69A45L,0x0B4D0E89L,8L},{0x08E0E369L,0xD842A212L,0x56E82A23L,(-1L),1L,1L,0x08E0E369L,0x56218883L,0x20ECFD0AL,0x0B4D0E89L},{1L,0xDE07048EL,(-9L),0L,0x56218883L,8L,0xCFB05B66L,0xCFB05B66L,8L,0x56218883L}},{{0xADEB1905L,0x1C384E1DL,0x1C384E1DL,0xADEB1905L,0xBC8E31BCL,0x56E82A23L,1L,0x0B4D0E89L,(-6L),0x7ADF4C5BL},{0xB6D54553L,0xD842A212L,(-6L),0x08E0E369L,0xDE07048EL,0xC52FE230L,0x1C384E1DL,1L,(-6L),1L},{0x56218883L,(-8L),4L,0xADEB1905L,1L,1L,1L,0xC063240AL,8L,8L},{(-8L),(-1L),(-5L),0L,0xC52FE230L,(-5L),0x7ADF4C5BL,(-1L),0x20ECFD0AL,1L}}};
        uint16_t * const l_1223 = &g_1224;
        uint16_t * const *l_1222 = &l_1223;
        int64_t **l_1226 = &g_538[2];
        int8_t **l_1272 = &g_28;
        int32_t ***l_1312 = &g_1207;
        int8_t *l_1314 = &l_1180[2][0][3];
        int32_t *l_1315 = &l_1125;
        int8_t *l_1328 = &l_1088;
        int32_t *l_1330 = &l_1138;
        int i, j, k;
lbl_1208:
        (*l_1072) = g_1070;
        if (p_285)
        { /* block id: 346 */
            int64_t *l_1075 = (void*)0;
            int64_t *l_1076 = (void*)0;
            int64_t *l_1077 = &g_539[0];
            uint8_t * const **l_1080 = (void*)0;
            int8_t *l_1081 = &g_431;
            int32_t l_1093 = 0xCF654179L;
            int32_t l_1112 = 1L;
            int16_t * const l_1119 = &g_2[5][2][0];
            int32_t l_1127 = 9L;
            int8_t l_1132 = (-1L);
            int8_t l_1136 = (-1L);
            int32_t l_1137 = 1L;
            int32_t l_1140 = 1L;
            int32_t l_1141 = 0x95014401L;
            int32_t l_1142 = 0x5537AB1CL;
            int32_t l_1144 = 1L;
            int32_t l_1145[8][7] = {{0xEDE59209L,0L,1L,0L,0x49682392L,0x4E317927L,0x49682392L},{1L,0x4E317927L,0x4E317927L,1L,0x49682392L,1L,0x4E317927L},{0xEDE59209L,0xEDE59209L,0x4E317927L,0L,0x4E317927L,0xEDE59209L,0xEDE59209L},{0xEDE59209L,0x4E317927L,0L,0x4E317927L,0xEDE59209L,0xEDE59209L,0x4E317927L},{1L,0x49682392L,1L,0x4E317927L,0x4E317927L,1L,0x49682392L},{0x4E317927L,0x49682392L,0L,0L,0x49682392L,0x4E317927L,0x49682392L},{1L,0x4E317927L,0x4E317927L,1L,0x49682392L,1L,0x4E317927L},{0xEDE59209L,0xEDE59209L,0x4E317927L,0L,0x4E317927L,0xEDE59209L,0xEDE59209L}};
            uint32_t l_1146 = 0xF321C333L;
            uint32_t l_1201 = 0xFC2B20C5L;
            int32_t *l_1225[7] = {(void*)0,&g_951,&g_951,(void*)0,&g_951,&g_951,(void*)0};
            const int8_t l_1237 = 0x2DL;
            uint32_t **l_1245 = &g_930[0][6];
            int i, j;
            if ((safe_lshift_func_int8_t_s_u((((*l_1077) ^= (-2L)) > (safe_lshift_func_int16_t_s_s(((l_1080 != (((((((*g_715) > 0xEA8FL) , ((((p_287 <= (((((p_286 <= ((*l_1081) = ((void*)0 == &g_29))) ^ (((+(((safe_div_func_int64_t_s_s(((safe_mod_func_int64_t_s_s(p_286, 5UL)) >= 0x1D8EFEE7L), l_974)) != p_286) > 0x4AL)) >= p_287) < l_1087)) != 0x0AL) & p_285) | l_1088)) != 0UL) <= 0xF8L) >= (-3L))) & (-3L)) == p_287) , g_1020) , l_1089)) > 4294967287UL), l_1087))), 3)))
            { /* block id: 349 */
                uint8_t l_1099 = 1UL;
                int32_t l_1124 = 0x22719A66L;
                int32_t l_1126 = 0x104E9D3BL;
                int32_t l_1130 = 0x24F95FE9L;
                int32_t l_1131 = (-3L);
                int32_t l_1133 = 0xFD74DD2BL;
                int32_t l_1134[9][6][2] = {{{0x388DCBAFL,0x8C8A82A9L},{(-9L),2L},{0x8C8A82A9L,0x2B272E02L},{1L,1L},{0L,1L},{1L,(-9L)}},{{(-3L),(-9L)},{1L,1L},{0L,1L},{1L,0x2B272E02L},{0x8C8A82A9L,2L},{(-9L),0x8C8A82A9L}},{{0x388DCBAFL,0xE466BDF6L},{0x388DCBAFL,0x8C8A82A9L},{(-9L),2L},{0x8C8A82A9L,0x2B272E02L},{1L,1L},{0L,1L}},{{1L,(-9L)},{(-3L),(-9L)},{1L,1L},{0L,1L},{1L,0x2B272E02L},{0x8C8A82A9L,2L}},{{(-9L),0x8C8A82A9L},{0x388DCBAFL,0xE466BDF6L},{0x388DCBAFL,0x8C8A82A9L},{(-9L),2L},{0x8C8A82A9L,0x2B272E02L},{1L,1L}},{{0L,1L},{1L,(-9L)},{(-3L),(-9L)},{1L,1L},{0L,1L},{1L,0x2B272E02L}},{{0x8C8A82A9L,2L},{(-9L),0x8C8A82A9L},{0x388DCBAFL,0xE466BDF6L},{0x388DCBAFL,0x8C8A82A9L},{(-9L),2L},{0x8C8A82A9L,0x2B272E02L}},{{1L,1L},{0L,1L},{1L,(-9L)},{(-3L),(-9L)},{1L,1L},{0L,1L}},{{1L,0x2B272E02L},{0x8C8A82A9L,2L},{(-9L),0x8C8A82A9L},{0x388DCBAFL,0xE466BDF6L},{0x388DCBAFL,0x8C8A82A9L},{(-9L),2L}}};
                int8_t l_1143 = 0xDCL;
                uint32_t **l_1204 = &g_930[4][5];
                int i, j, k;
                if ((safe_add_func_uint32_t_u_u(((18446744073709551607UL && (l_974 < 4294967295UL)) == l_1087), (l_1093 = (*g_653)))))
                { /* block id: 351 */
                    int16_t *l_1102[5];
                    int32_t l_1120 = 1L;
                    int32_t *l_1121[8] = {&g_499[0][0],&l_995[0][1],&g_499[0][0],&l_995[0][1],&g_499[0][0],&l_995[0][1],&g_499[0][0],&l_995[0][1]};
                    int32_t l_1123 = 0L;
                    int i;
                    for (i = 0; i < 5; i++)
                        l_1102[i] = (void*)0;
                    if (((1L | 1L) & (safe_lshift_func_uint16_t_u_u((*g_715), ((*l_905) = l_1087)))))
                    { /* block id: 353 */
                        int32_t **l_1096[5][10] = {{&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653},{&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653},{&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653},{&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653},{&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653,&g_653}};
                        uint32_t **l_1098[7] = {(void*)0,(void*)0,&g_930[1][2],(void*)0,(void*)0,&g_930[1][2],(void*)0};
                        int i, j;
                        l_1097 = &g_8;
                        return l_1098[1];
                    }
                    else
                    { /* block id: 356 */
                        (*g_653) = l_1099;
                        (*g_653) |= (safe_add_func_uint16_t_u_u((l_1102[2] == ((safe_rshift_func_uint8_t_u_s((((+(((((safe_lshift_func_int8_t_s_s((((0x1CL >= ((*l_1081) = (safe_sub_func_int64_t_s_s(((safe_rshift_func_uint16_t_u_u(p_285, 11)) == ((**l_1018)--)), ((((0xEEC3L == (p_285 < (0L && p_286))) >= (safe_rshift_func_int8_t_s_u((((*g_715) || ((safe_sub_func_uint16_t_u_u((0x7CF0L && p_285), p_285)) > 2UL)) , p_285), 2))) <= p_285) , 18446744073709551615UL))))) , l_1080) == (void*)0), 4)) <= 6UL) ^ (*l_1097)) >= p_287) & (*g_656))) ^ g_7[2][5][1]) , p_287), (*g_28))) , l_1119)), p_285));
                    }
                    ++l_1146;
                }
                else
                { /* block id: 363 */
                    uint64_t *l_1156 = &g_998;
                    uint64_t **l_1155 = &l_1156;
                    uint64_t *l_1163 = &g_998;
                    union U4 *l_1165 = &g_1166;
                    union U4 **l_1164[10] = {&l_1165,&l_1165,&l_1165,&l_1165,&l_1165,&l_1165,&l_1165,&l_1165,&l_1165,&l_1165};
                    union U4 *l_1167 = (void*)0;
                    int32_t l_1179[7] = {(-7L),(-8L),(-7L),(-7L),(-8L),(-7L),(-7L)};
                    int i;
                    g_1168[9] = (l_1167 = ((((safe_rshift_func_uint16_t_u_s(((safe_lshift_func_int16_t_s_s(((((((*l_1163) = ((((safe_lshift_func_uint8_t_u_u(l_1145[2][6], (((*l_1155) = func_314(p_287, &g_11)) != (void*)0))) == (g_924.f1 == 1UL)) , ((safe_div_func_uint8_t_u_u((++(**l_1090)), (p_285 & ((safe_div_func_int8_t_s_s(p_287, 4L)) <= (*l_1097))))) ^ l_1138)) <= 1UL)) == 0x36B6E6EDF0F732B1LL) ^ (*l_1097)) <= 0UL) , l_1134[3][2][1]), 6)) & (-2L)), l_1140)) >= (*g_28)) | p_287) , (void*)0));
                    for (l_1112 = 2; (l_1112 > 5); ++l_1112)
                    { /* block id: 371 */
                        int32_t *l_1176 = &l_1145[7][0];
                        int32_t *l_1177[9][2][3] = {{{(void*)0,(void*)0,(void*)0},{(void*)0,&g_499[2][0],&l_1130}},{{&l_1130,(void*)0,&l_1139[2][0][9]},{&g_499[2][0],&g_8,&g_8}},{{&l_1137,&l_1130,&l_1139[2][0][9]},{&l_1145[7][4],(void*)0,&l_1130}},{{(void*)0,&g_8,(void*)0},{&l_1125,&l_1141,&l_1125}},{{(void*)0,&g_8,(void*)0},{&l_1130,(void*)0,&l_1145[7][4]}},{{&l_1139[2][0][9],&l_1130,&l_1137},{&g_8,&g_8,&g_499[2][0]}},{{&l_1139[2][0][9],(void*)0,&l_1130},{&l_1130,&g_499[2][0],(void*)0}},{{(void*)0,(void*)0,(void*)0},{&l_1125,&l_1130,(void*)0}},{{(void*)0,(void*)0,&l_1130},{&l_1145[7][4],&l_1138,&g_499[2][0]}}};
                        int i, j, k;
                        g_1181--;
                    }
                }
                for (l_1132 = 3; (l_1132 == (-30)); l_1132 = safe_sub_func_uint32_t_u_u(l_1132, 7))
                { /* block id: 377 */
                    const int8_t * const l_1188 = &l_1088;
                    int32_t l_1199[2][8][3] = {{{0xB581B4F1L,1L,0xB581B4F1L},{0xB581B4F1L,0x9B9044E8L,1L},{0x9B9044E8L,0xB581B4F1L,0xB581B4F1L},{1L,0xB581B4F1L,0L},{(-4L),0x9B9044E8L,(-1L)},{1L,1L,(-1L)},{0x9B9044E8L,(-4L),0L},{0xB581B4F1L,1L,0xB581B4F1L}},{{0xB581B4F1L,0x9B9044E8L,1L},{0x9B9044E8L,0xB581B4F1L,0xB581B4F1L},{1L,0xB581B4F1L,0L},{(-4L),0x9B9044E8L,(-1L)},{1L,1L,(-1L)},{0x9B9044E8L,(-4L),0L},{0xB581B4F1L,1L,0xB581B4F1L},{0xB581B4F1L,0x9B9044E8L,1L}}};
                    uint64_t *l_1200 = &g_998;
                    int i, j, k;
                    l_1139[1][1][5] ^= (safe_add_func_uint64_t_u_u((((l_1188 == &l_1143) , ((*g_28) == (((((((*l_1200) = (((((((((p_286 == 0x664CD1FA45DA7390LL) && ((*l_905) = (safe_div_func_uint16_t_u_u((((((safe_mod_func_uint32_t_u_u((**g_929), (safe_div_func_int8_t_s_s(((65535UL < (++(*g_715))) > (4294967289UL <= (**g_929))), (*g_28))))) == p_287) >= p_287) & 0xF57C062EL) || p_285), p_285)))) , &g_656) == (*l_1089)) && 0x71D9AEF7L) > p_286) & l_1199[1][6][2]) < 1UL) , (*l_1097))) == l_1201) , (*l_1097)) , l_1131) , &g_29) != &l_1132))) | (*g_653)), l_1143));
                    for (l_1141 = (-4); (l_1141 >= 22); ++l_1141)
                    { /* block id: 384 */
                        l_1124 ^= p_286;
                        return l_1204;
                    }
                }
            }
            else
            { /* block id: 389 */
                uint16_t * const l_1215[8][9] = {{&g_1219,&g_1219,&g_1217,&g_1219,&g_1219,&g_1217,&g_1219,&g_1219,&g_1217},{&g_1216[0],&g_1216[0],&g_1220,&g_1216[0],&g_1216[0],&g_1220,&g_1216[0],&g_1216[0],&g_1220},{&g_1219,&g_1219,&g_1217,&g_1219,&g_1219,&g_1217,&g_1219,&g_1219,&g_1217},{&g_1216[0],&g_1216[0],&g_1216[0],&g_1218[2][5],&g_1218[2][5],&g_1216[0],&g_1218[2][5],&g_1218[2][5],&g_1216[0]},{&g_1221,&g_1221,&g_1219,&g_1221,&g_1221,&g_1219,&g_1221,&g_1221,&g_1219},{&g_1218[2][5],&g_1218[2][5],&g_1216[0],&g_1218[2][5],&g_1218[2][5],&g_1216[0],&g_1218[2][5],&g_1218[2][5],&g_1216[0]},{&g_1221,&g_1221,&g_1219,&g_1221,&g_1221,&g_1219,&g_1221,&g_1221,&g_1219},{&g_1218[2][5],&g_1218[2][5],&g_1216[0],&g_1218[2][5],&g_1218[2][5],&g_1216[0],&g_1218[2][5],&g_1218[2][5],&g_1216[0]}};
                uint16_t * const *l_1214 = &l_1215[7][3];
                uint16_t * const **l_1213[10] = {&l_1214,&l_1214,&l_1214,&l_1214,&l_1214,&l_1214,&l_1214,&l_1214,&l_1214,&l_1214};
                int32_t *l_1238[5][8][5] = {{{&l_1125,(void*)0,(void*)0,(void*)0,&l_1125},{(void*)0,&l_1145[2][0],&l_1137,&l_1122,&g_8},{(void*)0,&l_1093,(void*)0,&l_1125,&l_1122},{&l_1139[2][0][4],&l_1087,&l_1087,&l_1139[2][0][4],&l_1142},{&l_1093,&l_1142,&l_1144,&l_1093,&g_163},{&l_1142,&g_8,&l_968,&l_1142,(void*)0},{&g_163,(void*)0,&l_995[0][0],&l_1093,&l_1125},{&l_1112,(void*)0,&l_1129,&l_1139[2][0][4],(void*)0}},{{&l_995[0][2],&l_1125,&l_1125,&l_1125,&l_1125},{&l_1145[2][0],&g_38,&g_38,&l_1122,&l_1093},{(void*)0,&l_1093,&l_1144,(void*)0,&l_1142},{&g_38,&l_1112,&g_38,&l_1093,(void*)0},{(void*)0,(void*)0,&l_1129,(void*)0,&l_995[0][2]},{&l_1145[2][0],&l_1139[2][0][4],&l_1137,&l_1112,&l_1112},{&l_995[0][2],&g_163,&l_995[0][2],&l_995[0][2],(void*)0},{&l_1112,&l_1087,&l_1142,(void*)0,&l_1093}},{{&g_163,&l_1122,&l_952,&l_1142,(void*)0},{&l_1142,&l_1122,&l_1142,&l_1093,&l_1122},{&l_1093,(void*)0,&l_995[0][2],&l_1125,&l_1125},{&l_1139[2][0][4],(void*)0,&l_1137,(void*)0,&l_1139[2][0][4]},{(void*)0,&g_163,&l_1129,&l_1125,&l_1093},{(void*)0,&l_1087,&g_38,(void*)0,&l_1142},{&l_1125,(void*)0,&l_1144,&g_163,&l_1093},{&l_1142,(void*)0,&g_38,&l_1142,&l_1139[2][0][4]}},{{&l_1093,(void*)0,&l_1125,&l_1122,&l_1125},{(void*)0,(void*)0,&l_1129,&g_8,&l_1122},{&l_995[0][2],(void*)0,&l_995[0][0],&l_1125,(void*)0},{(void*)0,&g_38,&g_255,&l_1093,&g_3},{(void*)0,&l_1125,&g_163,&l_995[0][2],(void*)0},{&l_1139[2][0][9],&l_968,&l_1142,&g_3,&g_38},{&l_1129,&g_255,&g_255,&l_1129,(void*)0},{&l_1142,&g_38,(void*)0,&l_968,&l_1142}},{{&g_3,(void*)0,&l_1112,(void*)0,(void*)0},{&l_1142,&l_1142,&l_952,&l_968,&g_3},{(void*)0,&l_995[0][2],&l_1122,&l_1129,&l_995[0][0]},{&g_499[0][0],&l_1122,&g_3,&g_3,&l_1122},{&l_1125,&l_1144,&l_1140,&l_995[0][2],(void*)0},{&l_1087,&l_1142,(void*)0,&l_1093,&g_38},{&l_1140,(void*)0,&l_1144,(void*)0,&l_995[0][2]},{&l_1087,&l_1142,&l_1129,&l_1087,(void*)0}}};
                int64_t l_1244 = 0xCB3E58D62E99B882LL;
                int i, j, k;
                for (l_1112 = 0; (l_1112 < (-3)); l_1112--)
                { /* block id: 392 */
                    (*l_1097) |= (&g_653 == (g_1207 = &l_1097));
                }
                if (p_287)
                    goto lbl_1208;
                if (((*g_653) ^= (safe_mul_func_uint8_t_u_u((safe_mod_func_uint8_t_u_u(((((l_1222 = &g_715) == (void*)0) , l_1225[4]) != (((l_1226 != (void*)0) == (safe_mul_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_s((*l_1097), 0)), (((safe_div_func_int8_t_s_s((((-1L) && (safe_mul_func_int8_t_s_s(((safe_mul_func_uint8_t_u_u((1L > 0xA3E13EC3L), l_1138)) < 7UL), l_1237))) ^ (*g_656)), (*g_28))) , l_1141) | p_285)))) , (void*)0)), l_1140)), 0x02L))))
                { /* block id: 399 */
                    int16_t l_1242 = 1L;
                    l_1239 = ((*g_1207) = l_1238[3][3][4]);
                    for (g_924.f1 = 0; (g_924.f1 != 4); g_924.f1++)
                    { /* block id: 404 */
                        l_1242 ^= p_285;
                        g_499[0][0] ^= (+g_163);
                        l_1138 ^= l_1244;
                        return l_1245;
                    }
                }
                else
                { /* block id: 410 */
                    uint8_t l_1249 = 1UL;
                    if (p_286)
                    { /* block id: 411 */
                        return &g_930[1][2];
                    }
                    else
                    { /* block id: 413 */
                        int16_t l_1254 = 0x855CL;
                        (*g_653) = (safe_div_func_int64_t_s_s((((0x4AL <= ((*g_28) , 1UL)) == (l_1248[6][0][1] > ((&l_1214 != (void*)0) ^ ((*l_1081) = l_1249)))) , (safe_mul_func_int8_t_s_s(((p_286 |= 0x7C99L) & ((safe_rshift_func_int16_t_s_s(l_1254, l_1129)) || p_285)), 0x9BL))), p_285));
                        return &g_930[1][2];
                    }
                }
            }
        }
        else
        { /* block id: 421 */
            uint64_t *l_1259 = &g_998;
            int32_t l_1270 = 0x3DB69D3CL;
            int16_t l_1304 = 1L;
            int8_t *l_1305 = &l_1180[0][7][1];
            int8_t *l_1306 = &l_1088;
            int32_t l_1307[9] = {(-9L),0xAE8F4224L,(-9L),0xAE8F4224L,(-9L),0xAE8F4224L,(-9L),0xAE8F4224L,(-9L)};
            int i;
            l_1097 = (l_1087 , &l_1135);
            l_1128 = ((safe_mul_func_int16_t_s_s((((*g_656) , (safe_add_func_int32_t_s_s(((++(*l_1259)) , (safe_mul_func_uint8_t_u_u(0x5FL, (l_1125 & ((((((+l_1265[6]) >= (*g_653)) == (((safe_rshift_func_int8_t_s_u(((safe_mul_func_int16_t_s_s(l_1270, ((*l_1027) = p_286))) , p_286), 5)) < (!p_285)) <= l_1139[2][0][9])) , (void*)0) == l_1272) > p_285))))), 0UL))) && (*g_656)), l_1122)) != (**g_929));
            l_1307[2] |= (((g_255 > g_1273) != ((safe_lshift_func_uint8_t_u_s((*l_1097), (l_1276[7] > ((*l_1027) = ((safe_rshift_func_uint16_t_u_s((((safe_add_func_int64_t_s_s((((((*l_1306) = ((*l_1305) |= (safe_mod_func_uint32_t_u_u((((void*)0 == &g_715) == (safe_rshift_func_int8_t_s_u((*g_28), 2))), (safe_sub_func_int16_t_s_s(((safe_sub_func_int8_t_s_s(((((safe_add_func_int16_t_s_s((safe_rshift_func_int16_t_s_u(((safe_unary_minus_func_int32_t_s((safe_rshift_func_int8_t_s_u(((((safe_sub_func_int64_t_s_s((((safe_lshift_func_uint16_t_u_u((safe_mul_func_int8_t_s_s(((((((*l_1239) = 0xF68B9F6AL) >= (((*l_1223) = ((safe_sub_func_int16_t_s_s(l_1087, p_287)) != 0x115C7FBD1A644E35LL)) == l_1304)) < p_286) , l_1270) == 0xA9L), p_286)), (*g_715))) ^ 0x58L) , 1L), 0xF2E787C70A83B7E2LL)) > l_1088) < 7L) , (*g_28)), 0)))) , (-2L)), 6)), p_286)) , (*l_1239)) >= 1UL) == 0x17D570C4735AD69ALL), 0x8CL)) ^ p_286), (*g_715))))))) <= l_1304) == (*g_28)) <= g_29), p_287)) | p_287) < l_1129), 7)) , p_287))))) <= 0xFDL)) == (*l_1097));
        }
        (*l_1315) = (safe_sub_func_int8_t_s_s((-1L), ((l_1129 != (safe_add_func_int32_t_s_s(((((g_188 |= (*g_656)) != l_1139[2][0][9]) , &l_1239) != ((*l_1312) = &g_653)), (safe_unary_minus_func_int8_t_s(((*l_1314) ^= 0x05L)))))) == (**g_929))));
        (*l_1330) ^= ((safe_sub_func_uint64_t_u_u((safe_sub_func_int32_t_s_s(((*l_1272) != ((255UL || ((*l_1328) = ((*l_1314) = (((void*)0 != l_1226) == ((g_857 || (((*g_656)++) == (g_495 ^= (safe_sub_func_int16_t_s_s((((((*l_1315) = ((((safe_rshift_func_int8_t_s_s(p_285, 7)) && ((*g_715) <= (safe_sub_func_int32_t_s_s((p_285 <= (p_285 | (*l_1315))), (**g_929))))) ^ 0x2FL) , (*l_1315))) == p_285) | 0x3275L) , p_286), 65535UL))))) , (*g_656)))))) , (*l_1272))), g_1221)), l_1329)) , (*l_1315));
    }
    for (g_306 = 23; (g_306 != 30); g_306 = safe_add_func_int32_t_s_s(g_306, 7))
    { /* block id: 446 */
        const union U5 *l_1339 = (void*)0;
        int32_t ***l_1340[1][2][7] = {{{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207}}};
        int32_t l_1346 = 0xC8B8E557L;
        int32_t *l_1354 = &g_951;
        uint32_t l_1399 = 1UL;
        uint32_t **l_1402 = &g_930[1][2];
        uint32_t l_1405 = 18446744073709551607UL;
        const uint16_t *l_1418[6][1][8] = {{{&g_1419,&g_1419,&g_1419,(void*)0,&g_1419,&g_1419,&g_1419,&g_1419}},{{&g_1419,(void*)0,&g_1419,(void*)0,(void*)0,&g_1419,&g_1419,&g_1419}},{{&g_1419,&g_1419,&g_1419,&g_1419,&g_1419,&g_1419,(void*)0,&g_1419}},{{&g_1419,&g_1419,&g_1419,&g_1419,&g_1419,(void*)0,&g_1419,&g_1419}},{{&g_1419,&g_1419,&g_1419,(void*)0,(void*)0,(void*)0,(void*)0,&g_1419}},{{&g_1419,&g_1419,&g_1419,&g_1419,&g_1419,&g_1419,&g_1419,&g_1419}}};
        const uint16_t **l_1417 = &l_1418[1][0][6];
        const uint16_t ***l_1416 = &l_1417;
        const uint16_t ****l_1415 = &l_1416;
        uint64_t l_1433 = 18446744073709551608UL;
        int i, j, k;
        for (g_657 = 0; (g_657 >= 30); g_657++)
        { /* block id: 449 */
            int32_t * const * const l_1345[3][9] = {{&g_653,&l_1239,&l_1239,&l_1097,&l_1239,&l_1097,&l_1239,&l_1239,&g_653},{&g_653,&l_1239,&l_1239,&l_1097,&l_1239,&l_1097,&l_1239,&l_1239,&g_653},{&g_653,&l_1239,&l_1239,&l_1097,&l_1239,&l_1097,&l_1239,&l_1239,&g_653}};
            int32_t * const * const *l_1344[7] = {&l_1345[1][2],&l_1345[1][2],&l_1345[1][2],&l_1345[1][2],&l_1345[1][2],&l_1345[1][2],&l_1345[1][2]};
            int32_t l_1377 = (-4L);
            int i, j;
            for (l_968 = 9; (l_968 >= 2); l_968 -= 1)
            { /* block id: 452 */
                int32_t ****l_1341 = &l_1340[0][1][0];
                int32_t ***l_1343[7][4][9] = {{{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,(void*)0,&g_1207,&g_1207,(void*)0},{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,(void*)0,&g_1207,&g_1207},{&g_1207,(void*)0,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,(void*)0},{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207}},{{&g_1207,&g_1207,&g_1207,(void*)0,&g_1207,(void*)0,&g_1207,&g_1207,&g_1207},{(void*)0,(void*)0,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,(void*)0,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207}},{{&g_1207,&g_1207,&g_1207,&g_1207,(void*)0,&g_1207,&g_1207,&g_1207,(void*)0},{&g_1207,&g_1207,&g_1207,(void*)0,(void*)0,&g_1207,&g_1207,&g_1207,&g_1207},{(void*)0,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,(void*)0,(void*)0,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207}},{{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,(void*)0},{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,(void*)0,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207}},{{&g_1207,&g_1207,&g_1207,&g_1207,(void*)0,&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207,(void*)0,&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,(void*)0},{&g_1207,(void*)0,&g_1207,&g_1207,(void*)0,&g_1207,&g_1207,&g_1207,&g_1207}},{{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,(void*)0,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,(void*)0,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,(void*)0,&g_1207,(void*)0}},{{&g_1207,&g_1207,&g_1207,&g_1207,(void*)0,&g_1207,&g_1207,&g_1207,(void*)0},{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207},{&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207,&g_1207}}};
                int32_t ****l_1342 = &l_1343[1][1][8];
                uint64_t *l_1347 = &g_998;
                uint32_t l_1348 = 0x166B57ECL;
                int64_t *l_1349[6][4][6] = {{{&g_539[2],&l_974,&l_1265[6],&g_1071.f0,&g_1273,&g_1273},{&l_974,(void*)0,&g_1273,&l_1265[0],&l_1265[1],&l_1265[6]},{&l_1265[1],&g_539[2],&l_974,&g_196,&g_196,(void*)0},{&g_539[1],&l_1265[3],&g_845,&g_845,&l_1265[3],&g_539[1]}},{{(void*)0,&l_1265[2],(void*)0,&g_1273,&l_974,&g_539[1]},{&g_1071.f0,&l_1265[6],(void*)0,&g_1273,(void*)0,&g_196},{&g_1071.f0,&l_1064,&g_1273,&g_1273,&l_1064,(void*)0},{(void*)0,&l_974,&g_1071.f0,&g_845,&l_974,&g_196}},{{&g_539[1],&g_1071.f0,&g_1273,&g_196,(void*)0,&g_196},{&l_1265[1],(void*)0,&l_1064,&l_1265[0],&g_1273,&l_974},{&l_974,&g_539[0],(void*)0,&g_1071.f0,&g_1071.f0,&g_539[0]},{&g_539[2],&g_1273,&g_845,&l_1265[6],&g_196,(void*)0}},{{&g_539[1],&g_845,&g_196,&g_539[1],&g_1273,&g_1273},{&l_1064,&g_539[1],&l_1265[0],(void*)0,&l_1265[2],&g_845},{(void*)0,(void*)0,&l_1265[1],&l_1064,&l_1265[1],(void*)0},{&g_539[0],&g_196,(void*)0,&g_1273,&g_1273,&l_1265[3]}},{{&l_1265[3],(void*)0,&g_1273,&l_974,(void*)0,&l_974},{(void*)0,(void*)0,&g_539[1],(void*)0,&g_1273,&l_974},{&l_974,&g_196,&g_539[0],&g_196,&l_1265[1],(void*)0},{&g_196,(void*)0,&g_1273,&g_539[1],&l_1265[2],&g_539[2]}},{{&g_1273,&g_539[1],&l_974,&g_196,&g_1273,&g_845},{&l_1265[6],&g_845,&g_539[1],&l_1265[1],&g_196,(void*)0},{&g_539[2],&g_1273,&l_1265[2],&l_1064,&g_1071.f0,&l_1064},{&l_1064,&g_539[0],(void*)0,&g_539[1],&g_1273,&g_1071.f0}}};
                int i, j, k;
                g_1351 = ((safe_sub_func_int64_t_s_s(((g_922.f2 ^= p_285) , (l_1350 = (((((p_286 && ((safe_rshift_func_int16_t_s_u((g_1070 != l_1339), ((((void*)0 == &g_495) , ((((*l_1342) = ((*l_1341) = l_1340[0][1][5])) != l_1344[4]) == ((*l_1347) = l_1346))) | l_1348))) , p_287)) , p_285) < 0L) != 1L) < l_1346))), l_1346)) >= 0x16L);
            }
            g_499[2][0] |= (p_287 > (255UL <= (*g_28)));
            for (p_287 = 9; (p_287 <= (-19)); p_287--)
            { /* block id: 463 */
                struct S0 *l_1367 = (void*)0;
                int32_t l_1368 = 1L;
                uint64_t *l_1369 = &g_998;
                int64_t *l_1370[2][6] = {{&l_974,&l_974,&l_974,&l_974,&l_974,&l_974},{&l_974,&g_1273,&l_974,&g_1273,&g_1273,&l_974}};
                int32_t l_1371 = 4L;
                int32_t l_1372 = 0L;
                int i, j;
                l_1372 ^= ((((l_1354 == l_1354) >= (safe_sub_func_int64_t_s_s((safe_lshift_func_uint8_t_u_s((safe_rshift_func_int8_t_s_s((((p_285 >= 1UL) & (*g_656)) != (((l_1371 = ((((*l_1369) ^= (((safe_mul_func_uint16_t_u_u((safe_mul_func_int8_t_s_s(((safe_mod_func_int64_t_s_s(((l_1367 != ((l_1368 = (*g_656)) , l_1367)) >= p_287), p_285)) == (*g_28)), p_285)), 0x48D4L)) | p_286) & p_287)) == p_287) < 1UL)) || 0x109855CBDDC03A5BLL) ^ (*g_715))), 7)), p_286)), p_286))) , l_1371) , l_1368);
                l_1368 = (g_1396 = ((((safe_div_func_uint64_t_u_u(18446744073709551615UL, ((*l_1369) = (0x83F16074L ^ (**g_929))))) < (safe_lshift_func_int16_t_s_s(l_1377, (p_286 = ((safe_mul_func_int16_t_s_s((safe_sub_func_uint32_t_u_u((l_1371 = (((safe_lshift_func_uint16_t_u_u((safe_div_func_int64_t_s_s((safe_mul_func_int8_t_s_s((p_285 != ((((*g_656) != (((((((+((l_1372 = (+((*l_905)++))) | (9L < (safe_lshift_func_int8_t_s_u(0L, 4))))) <= (safe_sub_func_uint16_t_u_u((*g_715), 0x4154L))) > 18446744073709551615UL) , (*g_715)) | p_285) ^ 5L) ^ p_287)) < 0xA8EA5F964C41131DLL) | (-1L))), p_286)), p_285)), (*g_715))) ^ p_285) >= p_287)), p_287)), (-8L))) ^ p_285))))) , l_1371) & (*g_28)));
                l_1097 = ((*g_1207) = (void*)0);
            }
        }
        for (g_951 = 0; (g_951 <= 0); g_951 += 1)
        { /* block id: 481 */
            int16_t * const *l_1424 = &l_1027;
            int16_t * const **l_1423 = &l_1424;
            uint64_t l_1428 = 0xC51A0B6CEC9C4080LL;
            uint8_t ***l_1437 = &l_973;
            uint8_t ****l_1436[4][8] = {{&l_1437,&l_1437,(void*)0,&l_1437,&l_1437,(void*)0,&l_1437,&l_1437},{&l_1437,&l_1437,&l_1437,&l_1437,&l_1437,&l_1437,&l_1437,&l_1437},{&l_1437,&l_1437,&l_1437,&l_1437,&l_1437,&l_1437,&l_1437,&l_1437},{&l_1437,&l_1437,(void*)0,&l_1437,&l_1437,(void*)0,&l_1437,&l_1437}};
            int i, j;
            g_922.f2 = (0x771FL || (safe_mul_func_uint8_t_u_u(((**l_973) = l_995[g_951][g_951]), l_995[g_951][(g_951 + 4)])));
            l_1399++;
            for (g_1219 = 0; (g_1219 <= 5); g_1219 += 1)
            { /* block id: 487 */
                return l_1402;
            }
            l_968 |= (safe_rshift_func_uint16_t_u_s(1UL, l_1405));
            for (g_845 = 0; (g_845 <= 5); g_845 += 1)
            { /* block id: 493 */
                const uint16_t *l_1413 = &g_1216[0];
                const uint16_t **l_1412 = &l_1413;
                const uint16_t ***l_1411 = &l_1412;
                const uint16_t ****l_1410[10] = {&l_1411,&l_1411,&l_1411,&l_1411,&l_1411,&l_1411,&l_1411,&l_1411,&l_1411,&l_1411};
                int32_t l_1425[8][8][4] = {{{0x3A09CC62L,0x476849EBL,1L,(-3L)},{0x00C7EEFAL,1L,1L,1L},{0x3274074BL,0x34F3319CL,0xD549191BL,0xF1A4BF36L},{(-7L),1L,0x97982AB3L,1L},{0x80973D36L,0x28C63C5FL,0x041918A5L,0x374516B3L},{0x80973D36L,0x8F2FD79CL,0x97982AB3L,(-2L)},{(-7L),0x374516B3L,0xD549191BL,1L},{0x3274074BL,0L,1L,(-4L)}},{{0x00C7EEFAL,(-6L),1L,1L},{0x3A09CC62L,9L,0x80973D36L,0x374516B3L},{0x041918A5L,(-8L),0x374516B3L,0x821B4579L},{0L,0x476849EBL,0xC9859619L,0x8F2FD79CL},{(-1L),0x34F3319CL,1L,0xC9859619L},{0L,(-7L),(-1L),0xF1A4BF36L},{6L,2L,0x3A09CC62L,0x3274074BL},{0x80973D36L,(-8L),(-8L),0x80973D36L}},{{(-6L),0x8F2FD79CL,0x4F2E51CFL,9L},{1L,0x75B6A97DL,0xD549191BL,(-4L)},{0L,0xC76739EBL,0x3274074BL,(-4L)},{(-2L),0x75B6A97DL,6L,9L},{0x3A09CC62L,0x8F2FD79CL,0x374516B3L,0x80973D36L},{0x30667319L,(-8L),(-1L),0x3274074BL},{0x97982AB3L,2L,0xC9859619L,0xF1A4BF36L},{0x00C7EEFAL,(-7L),0x3274074BL,0xC9859619L}},{{0x821B4579L,0x34F3319CL,(-2L),0x8F2FD79CL},{6L,0x476849EBL,0x97982AB3L,0x821B4579L},{(-6L),(-8L),(-6L),0x374516B3L},{0x374516B3L,9L,0x4F2E51CFL,1L},{(-7L),(-6L),(-1L),(-4L)},{0x821B4579L,0L,0x821B4579L,1L},{(-2L),0x374516B3L,1L,(-2L)},{0L,0x8F2FD79CL,(-1L),0x374516B3L}},{{(-8L),0x28C63C5FL,(-1L),1L},{0L,1L,1L,0xF1A4BF36L},{(-2L),0x34F3319CL,0x821B4579L,1L},{0x821B4579L,1L,(-1L),(-1L)},{0x1A188FF8L,(-2L),0L,(-3L)},{0x041918A5L,0x550ED03CL,0xD911BB3CL,0x28C63C5FL},{(-8L),0x374516B3L,0x821B4579L,2L},{0xCD9D5254L,0x30667319L,0x4F2E51CFL,6L}},{{0xF1A4BF36L,(-2L),(-3L),0xC9859619L},{0x97982AB3L,0x041918A5L,0L,(-1L)},{0x821B4579L,(-6L),0x28C63C5FL,0x28C63C5FL},{1L,1L,0x041918A5L,9L},{1L,0x00C7EEFAL,0xCD9D5254L,0x80973D36L},{0x4F2E51CFL,0x461ECF7BL,(-3L),0xCD9D5254L},{0x8F2FD79CL,0x461ECF7BL,0xC245FB4DL,0x80973D36L},{0x461ECF7BL,0x00C7EEFAL,0L,9L}},{{(-8L),1L,0xF76646FEL,0x28C63C5FL},{(-6L),(-6L),1L,(-1L)},{0xCD9D5254L,0x041918A5L,0x3A09CC62L,0xC9859619L},{0x8F2FD79CL,(-2L),9L,6L},{0x3A09CC62L,0x30667319L,0L,2L},{0x3274074BL,0x374516B3L,0x041918A5L,0x28C63C5FL},{(-4L),0x550ED03CL,(-6L),(-3L)},{1L,(-2L),0x461ECF7BL,(-1L)}},{{0x97982AB3L,0x461ECF7BL,9L,0x461ECF7BL},{(-3L),0xC76739EBL,0xC245FB4DL,0x75B6A97DL},{0x1A188FF8L,(-1L),0x821B4579L,9L},{(-6L),0x550ED03CL,(-4L),0x041918A5L},{(-6L),0x80973D36L,0x821B4579L,0L},{0x1A188FF8L,0x041918A5L,0xC245FB4DL,6L},{(-3L),1L,9L,0x34F3319CL},{0x97982AB3L,(-8L),0x461ECF7BL,2L}}};
                int i, j, k;
                for (g_1273 = 3; (g_1273 <= 9); g_1273 += 1)
                { /* block id: 496 */
                    const uint16_t *****l_1414[8] = {&l_1410[1],&l_1410[1],&l_1410[1],&l_1410[1],&l_1410[1],&l_1410[1],&l_1410[1],&l_1410[1]};
                    int16_t ***l_1422 = &g_1030[0][0];
                    int32_t l_1426 = (-8L);
                    int i, j;
                    g_922.f2 = (((0x11F0L ^ p_285) || ((g_1406 != (l_1415 = l_1410[7])) ^ (safe_mod_func_uint32_t_u_u((l_1422 != l_1423), p_287)))) == (0x882FL ^ ((l_1425[0][6][0] |= p_287) != l_1426)));
                    for (g_1220 = 0; (g_1220 <= 5); g_1220 += 1)
                    { /* block id: 502 */
                        int32_t l_1427 = 0x29E4E5E5L;
                        int i, j, k;
                        l_1428--;
                        l_1426 ^= p_285;
                    }
                    g_922.f2 ^= (safe_add_func_int32_t_s_s(l_1433, (safe_rshift_func_int16_t_s_s(((void*)0 == l_1436[1][3]), 6))));
                    if (l_1425[5][5][2])
                    { /* block id: 507 */
                        if (l_995[g_951][(g_951 + 4)])
                            break;
                    }
                    else
                    { /* block id: 509 */
                        return l_932;
                    }
                }
            }
        }
    }
    return l_932;
}


/* ------------------------------------------ */
/* 
 * reads : g_857 g_255
 * writes: g_255 g_857 g_499 g_653
 */
static int16_t  func_288(int8_t * p_289, uint16_t  p_290, const uint32_t * p_291)
{ /* block id: 267 */
    union U3 **l_874[4];
    union U3 ***l_873[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
    union U3 ****l_872[1][3];
    union U3 *****l_875 = &l_872[0][2];
    const union U3 ***l_877 = (void*)0;
    const union U3 *** const *l_876[3][3][6] = {{{(void*)0,&l_877,(void*)0,&l_877,(void*)0,&l_877},{&l_877,(void*)0,&l_877,&l_877,(void*)0,&l_877},{(void*)0,&l_877,&l_877,(void*)0,&l_877,&l_877}},{{&l_877,(void*)0,&l_877,(void*)0,(void*)0,&l_877},{&l_877,&l_877,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_877,(void*)0,&l_877,(void*)0,(void*)0}},{{&l_877,(void*)0,(void*)0,&l_877,&l_877,(void*)0},{(void*)0,&l_877,(void*)0,&l_877,(void*)0,&l_877},{&l_877,(void*)0,&l_877,&l_877,(void*)0,&l_877}}};
    const union U3 *** const **l_878 = &l_876[2][1][5];
    const union U3 *l_883 = &g_884;
    const union U3 **l_882[2];
    const union U3 *** const l_881 = &l_882[1];
    const union U3 *** const *l_880 = &l_881;
    const union U3 *** const **l_879 = &l_880;
    int32_t *l_885[2];
    int16_t *l_893 = (void*)0;
    int16_t **l_892[2];
    int16_t **l_894 = &l_893;
    int32_t **l_895[6][10] = {{&g_653,&l_885[0],&l_885[0],&g_653,&l_885[1],&l_885[1],&g_653,&l_885[1],&l_885[1],&g_653},{&l_885[1],&g_653,&g_653,(void*)0,&l_885[0],&g_653,&g_653,&l_885[0],(void*)0,&g_653},{&l_885[1],&l_885[1],&l_885[1],&l_885[0],&l_885[1],&l_885[1],&l_885[1],&l_885[0],&l_885[1],&l_885[1]},{&l_885[1],&g_653,&g_653,&l_885[1],(void*)0,(void*)0,&l_885[1],&g_653,&g_653,&l_885[1]},{&g_653,&l_885[1],&g_653,(void*)0,&l_885[1],(void*)0,&g_653,&l_885[1],&g_653,&g_653},{&l_885[1],&l_885[0],&l_885[1],&l_885[1],&l_885[1],&l_885[1],&l_885[0],&l_885[1],&l_885[1],&l_885[1]}};
    uint8_t l_896[7];
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_874[i] = &g_746;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 3; j++)
            l_872[i][j] = &l_873[0];
    }
    for (i = 0; i < 2; i++)
        l_882[i] = &l_883;
    for (i = 0; i < 2; i++)
        l_885[i] = &g_499[0][0];
    for (i = 0; i < 2; i++)
        l_892[i] = &l_893;
    for (i = 0; i < 7; i++)
        l_896[i] = 0x52L;
    g_255 = (((*l_875) = l_872[0][2]) == ((*l_879) = ((*l_878) = l_876[1][1][1])));
    for (g_857 = 0; (g_857 <= 3); g_857 += 1)
    { /* block id: 274 */
        uint16_t l_886 = 0UL;
        int16_t *l_888[6][1] = {{&g_232},{&g_232},{&g_232},{&g_232},{&g_232},{&g_232}};
        int16_t **l_887[2][9][8] = {{{(void*)0,&l_888[2][0],(void*)0,(void*)0,&l_888[2][0],(void*)0,&l_888[2][0],(void*)0},{(void*)0,&l_888[2][0],(void*)0,(void*)0,(void*)0,(void*)0,&l_888[2][0],(void*)0},{&l_888[2][0],(void*)0,(void*)0,(void*)0,&l_888[2][0],&l_888[2][0],(void*)0,(void*)0},{&l_888[2][0],&l_888[2][0],(void*)0,(void*)0,(void*)0,&l_888[2][0],&l_888[2][0],(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&l_888[2][0],(void*)0,(void*)0,(void*)0},{(void*)0,&l_888[2][0],(void*)0,(void*)0,&l_888[2][0],(void*)0,&l_888[2][0],(void*)0},{(void*)0,&l_888[2][0],(void*)0,(void*)0,(void*)0,(void*)0,&l_888[2][0],(void*)0},{&l_888[2][0],(void*)0,(void*)0,(void*)0,&l_888[2][0],&l_888[2][0],(void*)0,(void*)0},{&l_888[2][0],&l_888[2][0],(void*)0,(void*)0,(void*)0,&l_888[2][0],&l_888[2][0],(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0,&l_888[2][0],(void*)0,(void*)0,(void*)0},{(void*)0,&l_888[2][0],(void*)0,(void*)0,&l_888[2][0],(void*)0,&l_888[2][0],(void*)0},{(void*)0,&l_888[2][0],(void*)0,(void*)0,(void*)0,(void*)0,&l_888[2][0],(void*)0},{&l_888[2][0],(void*)0,(void*)0,(void*)0,&l_888[2][0],&l_888[2][0],(void*)0,(void*)0},{&l_888[2][0],&l_888[2][0],(void*)0,(void*)0,(void*)0,&l_888[2][0],&l_888[2][0],(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&l_888[2][0],(void*)0,(void*)0,(void*)0},{(void*)0,&l_888[2][0],(void*)0,(void*)0,&l_888[2][0],(void*)0,&l_888[2][0],(void*)0},{(void*)0,&l_888[2][0],(void*)0,(void*)0,(void*)0,(void*)0,&l_888[2][0],(void*)0},{(void*)0,(void*)0,&l_888[2][0],(void*)0,(void*)0,(void*)0,(void*)0,&l_888[2][0]}}};
        int16_t ***l_889 = &l_887[1][5][7];
        int16_t **l_891[9] = {&l_888[2][0],&l_888[2][0],&l_888[2][0],&l_888[2][0],&l_888[2][0],&l_888[2][0],&l_888[2][0],&l_888[2][0],&l_888[2][0]};
        int16_t ***l_890[7] = {(void*)0,&l_891[8],&l_891[8],(void*)0,&l_891[8],&l_891[8],(void*)0};
        int i, j, k;
        l_894 = (l_892[0] = ((*l_889) = (l_886 , l_887[0][8][2])));
        if (l_886)
            break;
        if (l_886)
            continue;
    }
    g_499[0][0] = g_255;
    g_653 = &g_499[1][0];
    return l_896[6];
}


/* ------------------------------------------ */
/* 
 * reads : g_857 g_656 g_657 g_11 g_495
 * writes: g_857 g_657 g_495
 */
static int8_t * func_292(const int8_t  p_293)
{ /* block id: 258 */
    uint16_t **l_855 = (void*)0;
    uint64_t *l_856 = &g_857;
    int32_t *l_862 = &g_11;
    const union U3 *l_864 = (void*)0;
    const union U3 ** const l_863 = &l_864;
    const union U3 **l_868 = &l_864;
    const union U3 ** const *l_867 = &l_868;
    int8_t *l_870[1][6] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
    int i, j;
    if ((((*g_656) = (safe_rshift_func_uint16_t_u_s((p_293 || (safe_mul_func_uint8_t_u_u(((safe_unary_minus_func_int32_t_s((safe_add_func_uint32_t_u_u(0x2B6240B7L, (safe_add_func_int16_t_s_s((((void*)0 != l_855) , ((++(*l_856)) || ((((*g_656) , l_862) == (p_293 , l_862)) <= (((void*)0 == l_863) > 8L)))), (*l_862))))))) & p_293), p_293))), 3))) || (*l_862)))
    { /* block id: 261 */
        const union U3 ** const *l_866 = &l_863;
        const union U3 ** const **l_865[5];
        int i;
        for (i = 0; i < 5; i++)
            l_865[i] = &l_866;
        l_867 = &l_863;
    }
    else
    { /* block id: 263 */
        int8_t *l_869 = &g_431;
        return l_869;
    }
    return l_870[0][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_466 g_66 g_774 g_656 g_3 g_499 g_196 g_539 g_78 g_836 g_38 g_255
 * writes: g_466 g_657 g_499 g_653 g_495 g_748 g_539 g_255
 */
static int64_t  func_309(int64_t * p_310, int32_t  p_311, uint32_t ** p_312, uint16_t  p_313)
{ /* block id: 227 */
    uint32_t l_767 = 0xA3AD95A7L;
    uint8_t *l_789 = &g_495;
    int32_t l_791 = 1L;
    int16_t l_800 = 1L;
    uint16_t l_804 = 0xAB85L;
    int32_t l_810 = 0xBB95F644L;
    int32_t l_813 = (-1L);
    int32_t l_814 = (-1L);
    int32_t l_816 = (-4L);
    int32_t l_819 = (-1L);
    int32_t l_820 = 0xDF684DC8L;
    int32_t l_821[7][4][8] = {{{0x02810FAAL,0x48A21B46L,0x30DDB040L,0x788D4333L,(-1L),0x62CEDB97L,(-10L),0x9C0B805CL},{0xF20380C4L,0x3DA5C225L,0x3005C018L,0x5B966B89L,0x788D4333L,0x62CEDB97L,0x427530FAL,0xF9C18EF0L},{0x884F5338L,0x48A21B46L,(-3L),0x19D26FEEL,9L,(-4L),(-10L),1L},{0xF9C18EF0L,0x1310600CL,0xE9AF64DFL,0xC3C16623L,0x62CEDB97L,0xAE7AA8C5L,(-3L),6L}},{{0x5EB39CBFL,(-3L),0L,6L,0x9C0B805CL,0x1310600CL,0x884F5338L,0x62CEDB97L},{(-1L),0x72A3EACAL,0xB9CA6D94L,0x1310600CL,0xDA22431BL,0x3DC0BA74L,1L,0x25F4D6A5L},{0L,6L,0x7482FE10L,(-1L),0x884F5338L,(-10L),0x78D221E7L,0x30DDB040L},{0L,6L,(-1L),6L,0x19D26FEEL,0x4DF5F5C8L,(-1L),1L}},{{0x427530FAL,0L,0x600955C8L,(-1L),0xCFABF1ABL,(-1L),0x48A21B46L,0xB5A4A363L},{(-6L),(-10L),0L,0xF20380C4L,0L,(-10L),(-6L),1L},{0x4DF5F5C8L,0L,0xF20380C4L,0x2096A540L,1L,0x5EB39CBFL,0x02810FAAL,(-4L)},{0x21557EF0L,0xCFABF1ABL,0x78D221E7L,0x3DC0BA74L,1L,0x5EB6C1EBL,6L,0xF20380C4L}},{{0x4DF5F5C8L,0x427530FAL,6L,(-4L),0L,0xDA22431BL,(-1L),(-6L)},{(-6L),0x5B966B89L,1L,0x9C0B805CL,0xCFABF1ABL,(-1L),0L,(-10L)},{0x427530FAL,0x30DDB040L,(-10L),0L,0x19D26FEEL,0x72A3EACAL,0xF2AC13BBL,(-3L)},{0L,0xB5A4A363L,0x2096A540L,(-3L),0x884F5338L,(-3L),0L,0xAE7AA8C5L}},{{0L,0x27E6D2E6L,0L,0xCFABF1ABL,0xDA22431BL,0xE9AF64DFL,0xC59D11C0L,1L},{(-1L),1L,(-1L),(-3L),0x9C0B805CL,0x19D26FEEL,0L,0x600955C8L},{0x5EB39CBFL,8L,0x19D26FEEL,0xD86CFFCDL,0x62CEDB97L,0x600955C8L,0x5F1CEB21L,0x5F1CEB21L},{0xF9C18EF0L,9L,0x5EB39CBFL,0x5EB39CBFL,9L,0xF9C18EF0L,0x21557EF0L,(-1L)}},{{0x3DC0BA74L,(-10L),(-6L),0x9C0B805CL,0x5EB39CBFL,0x21557EF0L,1L,0xC59D11C0L},{(-3L),0x600955C8L,0L,0x9C0B805CL,0x5EB6C1EBL,(-4L),0L,0x3005C018L},{8L,0x5EB6C1EBL,(-1L),0xD588EEBFL,0xDA22431BL,6L,0x2096A540L,0x21557EF0L},{0x02810FAAL,(-1L),0L,1L,(-1L),0x48A21B46L,0L,0xB5A4A363L}},{{0xCFABF1ABL,0x2096A540L,(-1L),(-1L),0x72A3EACAL,0xB9CA6D94L,0x1310600CL,0xDA22431BL},{(-1L),0x3DA5C225L,6L,0xAE7AA8C5L,(-3L),0x72A3EACAL,0xF134C94AL,0xF20380C4L},{0xAE7AA8C5L,0L,0x788D4333L,9L,0xE9AF64DFL,(-1L),1L,0x5B966B89L},{0xC59D11C0L,0xCFABF1ABL,0xF9C18EF0L,0L,0x19D26FEEL,8L,0x5F1CEB21L,(-1L)}}};
    uint32_t *l_839 = &g_446;
    uint32_t **l_838 = &l_839;
    int64_t *l_840 = &g_539[0];
    int32_t *l_841[4][8] = {{&g_163,&l_810,&l_816,&l_816,&l_810,&g_163,&l_791,&g_163},{&l_810,&g_163,&l_791,&g_163,&l_810,&l_816,&l_816,&l_810},{&g_163,&g_255,&g_255,&g_163,&g_8,&l_810,&g_8,&g_163},{&g_255,&g_8,&g_255,&l_816,&l_791,&l_791,&l_816,&g_255}};
    uint8_t l_842 = 0x54L;
    int i, j, k;
    for (g_466 = 18; (g_466 != 36); g_466 = safe_add_func_int64_t_s_s(g_466, 9))
    { /* block id: 230 */
        uint32_t *l_765[9][1][8] = {{{&g_66,&g_66,(void*)0,&g_446,&g_446,&g_66,&g_446,&g_66}},{{(void*)0,&g_66,&g_446,&g_66,(void*)0,&g_446,&g_66,&g_66}},{{&g_66,&g_446,&g_446,&g_446,&g_446,&g_446,&g_446,&g_66}},{{(void*)0,&g_446,&g_446,&g_66,&g_66,(void*)0,&g_66,&g_66}},{{&g_446,&g_446,&g_446,&g_66,&g_66,(void*)0,&g_446,&g_446}},{{&g_446,&g_446,(void*)0,(void*)0,&g_446,&g_446,&g_66,&g_66}},{{&g_446,&g_446,&g_66,&g_446,&g_66,&g_446,&g_66,&g_446}},{{&g_446,&g_66,(void*)0,&g_446,&g_66,&g_66,&g_66,&g_66}},{{(void*)0,&g_66,&g_66,(void*)0,&g_446,&g_446,&g_66,&g_446}}};
        int32_t l_766 = 0xFAF9E43EL;
        uint8_t *l_786 = &g_495;
        uint8_t **l_787 = (void*)0;
        uint8_t **l_788 = (void*)0;
        int32_t *l_792 = &g_499[2][0];
        int32_t **l_793 = &g_653;
        int32_t l_811 = 0xB4D13D74L;
        int32_t l_812 = 0x2A7A9C66L;
        int32_t l_815 = 4L;
        int16_t l_817[3];
        int32_t l_818[10] = {1L,1L,1L,1L,1L,1L,1L,1L,1L,1L};
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_817[i] = 1L;
        (*l_792) = (+((--l_767) & ((((0x16L && (safe_mod_func_uint32_t_u_u((**p_312), (safe_rshift_func_uint16_t_u_u(l_766, 15))))) >= (((void*)0 == g_774) | (safe_add_func_int8_t_s_s(((((((safe_lshift_func_int16_t_s_u((safe_mul_func_uint8_t_u_u((((safe_add_func_int64_t_s_s(((l_786 = l_786) != l_789), (+l_766))) < ((*g_656) = l_766)) | p_313), g_3)), l_766)) , l_791) != p_313) | 0xEB4C1AEA8B24D841LL) == 0xCDL) , 0x45L), 0L)))) > p_313) <= 0xF0B6CC65B58A57A9LL)));
        (*l_793) = (void*)0;
        for (p_311 = 19; (p_311 <= 22); p_311++)
        { /* block id: 238 */
            const int8_t l_801 = 0x1BL;
            int32_t *l_805 = &g_499[0][0];
            int32_t *l_806 = &g_255;
            int32_t *l_807 = (void*)0;
            int32_t *l_808[3][5][2] = {{{&l_766,(void*)0},{&l_766,&l_766},{(void*)0,&l_766},{&l_766,(void*)0},{&l_766,&l_766}},{{(void*)0,&l_766},{&l_766,&g_8},{(void*)0,(void*)0},{&g_8,(void*)0},{(void*)0,&g_8}},{{(void*)0,(void*)0},{&g_8,(void*)0},{(void*)0,&g_8},{(void*)0,(void*)0},{&g_8,(void*)0}}};
            int32_t l_809 = 1L;
            uint16_t l_822 = 65535UL;
            int i, j, k;
            (*l_792) = (safe_rshift_func_uint8_t_u_u((((p_313 = (safe_div_func_uint32_t_u_u((l_800 | (l_801 , (l_801 >= (((((((((p_311 | (l_791 = (g_748 = (1L && ((*l_789) = ((safe_sub_func_uint16_t_u_u((*l_792), (0x724DL <= 0x5631L))) & l_801)))))) & 0xFA5EC6EFL) , l_791) >= (*p_310)) | (*p_310)) | p_311) < 0x1C9CDA68ADCC72CFLL) <= 7L) | l_801)))), g_78))) > 0xC85EL) != l_767), l_804));
            --l_822;
        }
        (*l_792) = p_313;
    }
    if ((g_255 &= ((safe_sub_func_int32_t_s_s((-1L), (l_816 < (!(l_813 , 0xFF30B77BL))))) | (safe_mul_func_int16_t_s_s((l_821[5][0][1] != (l_819 >= ((*l_840) = (g_836 != l_838)))), g_38)))))
    { /* block id: 250 */
        return l_842;
    }
    else
    { /* block id: 252 */
        int8_t l_843 = 0xD2L;
        return l_843;
    }
}


/* ------------------------------------------ */
/* 
 * reads : g_446 g_715 g_466 g_328 g_748 g_232 g_538
 * writes: g_746 g_748 g_499 g_446 g_232
 */
static int64_t * func_314(uint8_t  p_315, int32_t * p_316)
{ /* block id: 206 */
    union U3 *l_744 = &g_745;
    union U3 **l_743[7] = {&l_744,&l_744,&l_744,&l_744,&l_744,&l_744,&l_744};
    uint16_t *l_747 = &g_748;
    int32_t l_749[1];
    int32_t *l_750 = &g_499[0][0];
    uint32_t *l_755 = &g_446;
    uint32_t *l_758 = (void*)0;
    int32_t *l_759 = (void*)0;
    int64_t *l_760 = &g_539[2];
    int i;
    for (i = 0; i < 1; i++)
        l_749[i] = (-9L);
lbl_751:
    (*l_750) = (g_446 , (((safe_sub_func_int16_t_s_s((((*l_747) |= (p_315 & ((0x1AB4L >= (+(((void*)0 == &g_499[1][0]) | (safe_rshift_func_uint16_t_u_u((*g_715), 3))))) || (g_328[5][4][1] != (g_746 = (void*)0))))) & ((l_749[0] < l_749[0]) && p_315)), 0x9E81L)) , (void*)0) == (void*)0));
    for (g_446 = 0; (g_446 <= 2); g_446 += 1)
    { /* block id: 212 */
        int32_t *l_752[4] = {&g_8,&g_8,&g_8,&g_8};
        int i;
        if (g_466)
            goto lbl_751;
        for (g_232 = 0; (g_232 >= 0); g_232 -= 1)
        { /* block id: 216 */
            int i;
            if (l_749[g_232])
                break;
            l_752[1] = (void*)0;
            return g_538[g_446];
        }
        (*l_750) = 0x61882AAEL;
    }
    l_749[0] = (((*l_755)--) <= (g_748 , ((*l_750) = 0UL)));
    return l_760;
}


/* ------------------------------------------ */
/* 
 * reads : g_28 g_29 g_328 g_3 g_188 g_431 g_196 g_66 g_78 g_2 g_163 g_466 g_7 g_255 g_11 g_495 g_232 g_499 g_8 g_260 g_446 g_604 g_539 g_653 g_656 g_715
 * writes: g_431 g_188 g_466 g_255 g_495 g_232 g_538 g_446 g_499 g_28 g_604 g_653 g_714 g_723
 */
static const int64_t  func_317(uint16_t  p_318, int64_t * p_319, int32_t  p_320, const uint64_t  p_321, int32_t  p_322)
{ /* block id: 70 */
    int8_t *l_430 = &g_431;
    uint32_t *l_435 = &g_66;
    uint32_t **l_434 = &l_435;
    union U3 *l_436 = &g_437;
    uint8_t *l_655 = &g_495;
    int16_t *l_658 = &g_232;
    int32_t l_659 = 2L;
    int32_t l_660 = (-5L);
    int32_t l_689 = 0x7159D5ECL;
    int32_t l_690 = 0xE35040A4L;
    int32_t l_691[4] = {0xB3C11F47L,0xB3C11F47L,0xB3C11F47L,0xB3C11F47L};
    uint8_t l_692[2];
    uint16_t *l_711 = &g_466;
    uint16_t **l_710 = &l_711;
    uint16_t **l_713 = &l_711;
    uint16_t ***l_712 = &l_713;
    int16_t *l_722 = &g_723;
    int32_t *l_724 = &g_499[0][0];
    uint32_t *l_725 = &g_446;
    uint8_t ***l_737 = (void*)0;
    uint8_t ****l_736 = &l_737;
    int i;
    for (i = 0; i < 2; i++)
        l_692[i] = 255UL;
    if (((*g_28) || ((safe_lshift_func_int8_t_s_s((g_328[5][4][1] != (void*)0), 7)) && ((safe_mod_func_uint8_t_u_u(p_322, p_318)) != (g_3 , (((g_188 , (safe_div_func_uint8_t_u_u((safe_add_func_int32_t_s_s((l_659 = func_141(((*l_658) = ((l_655 = func_420((safe_add_func_int32_t_s_s(((safe_rshift_func_int8_t_s_u((((*l_430) ^= (*g_28)) != (safe_sub_func_int8_t_s_s(p_322, g_29))), 4)) , (-4L)), 0L)), l_434, p_321, l_436, g_196)) == g_656)), l_659)), g_539[2])), l_660))) == 0x4D59L) & 0x7D2AA3C124428605LL))))))
    { /* block id: 180 */
        uint8_t l_669 = 1UL;
        int32_t l_682 = 0xBF0C102AL;
        int32_t *l_683 = &l_659;
        int32_t *l_684 = (void*)0;
        int32_t *l_685 = &l_659;
        int32_t *l_686 = (void*)0;
        int32_t *l_687 = (void*)0;
        int32_t *l_688[2];
        uint8_t **l_696[2][2][3] = {{{&g_656,&l_655,&l_655},{&l_655,(void*)0,(void*)0}},{{&g_656,&l_655,&l_655},{&l_655,(void*)0,(void*)0}}};
        uint8_t ***l_695 = &l_696[0][1][0];
        uint8_t **l_698 = (void*)0;
        uint8_t ***l_697 = &l_698;
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_688[i] = (void*)0;
        l_682 &= (safe_mod_func_int64_t_s_s(((g_499[1][0] &= (p_322 = p_320)) < (safe_unary_minus_func_uint64_t_u(l_660))), (+((safe_add_func_uint8_t_u_u((l_669 > ((void*)0 != l_658)), (safe_div_func_int8_t_s_s(((safe_mod_func_int64_t_s_s(((*g_28) | (g_539[0] <= ((&l_435 != ((safe_rshift_func_int16_t_s_s(((safe_sub_func_uint32_t_u_u((safe_add_func_int32_t_s_s(((safe_div_func_uint32_t_u_u((((void*)0 != g_328[5][4][1]) < p_320), p_321)) , p_321), 0UL)), l_669)) < l_659), 4)) , &l_435)) || (*g_28)))), p_320)) <= p_320), l_659)))) != p_320))));
        --l_692[0];
        (*l_697) = ((*l_695) = &g_656);
    }
    else
    { /* block id: 187 */
        uint8_t l_705[9][7][4] = {{{0UL,0x11L,0xE6L,252UL},{0x11L,6UL,0xE6L,0xE6L},{0UL,0UL,7UL,0xA8L},{9UL,1UL,0x82L,252UL},{0x82L,252UL,0x11L,0x82L},{0UL,252UL,0x18L,252UL},{252UL,1UL,0xE6L,0xA8L}},{{0x35L,0UL,0x11L,0xE6L},{9UL,6UL,0xBAL,252UL},{9UL,0x11L,0x11L,9UL},{0x35L,252UL,0xE6L,0x11L},{252UL,6UL,0x18L,0xA8L},{0UL,0x35L,0x11L,0xA8L},{0x82L,6UL,0x82L,0x11L}},{{9UL,252UL,7UL,9UL},{0UL,0x11L,0xE6L,252UL},{0x11L,6UL,0xE6L,0xE6L},{0UL,0UL,7UL,0xA8L},{9UL,1UL,0x82L,252UL},{0x82L,252UL,0x11L,0x82L},{0UL,252UL,0x18L,252UL}},{{252UL,1UL,0xE6L,0xA8L},{0x35L,0UL,0x11L,0xE6L},{9UL,6UL,0xBAL,252UL},{9UL,0x11L,0x11L,9UL},{0x35L,252UL,0xE6L,0x11L},{252UL,6UL,0x18L,0xA8L},{0UL,0x35L,0x11L,0xA8L}},{{0x82L,6UL,0x82L,0x11L},{9UL,252UL,7UL,9UL},{0UL,0x11L,0xE6L,252UL},{0x11L,6UL,0xE6L,0xE6L},{0UL,0UL,7UL,0xA8L},{9UL,1UL,0x82L,252UL},{0x82L,252UL,0x11L,0x82L}},{{0UL,252UL,0x18L,252UL},{252UL,1UL,253UL,1UL},{7UL,0x11L,0xBAL,253UL},{0xE6L,0x35L,0xA8L,0x82L},{0xE6L,0xBAL,0xBAL,0xE6L},{7UL,0x82L,253UL,0xBAL},{0x82L,0x35L,6UL,1UL}},{{0x11L,7UL,0xBAL,1UL},{0x18L,0x35L,0x18L,0xBAL},{0xE6L,0x82L,9UL,0xE6L},{0x11L,0xBAL,253UL,0x82L},{0xBAL,0x35L,253UL,253UL},{0x11L,0x11L,9UL,1UL},{0xE6L,0x92L,0x18L,0x82L}},{{0x18L,0x82L,0xBAL,0x18L},{0x11L,0x82L,6UL,0x82L},{0x82L,0x92L,253UL,1UL},{7UL,0x11L,0xBAL,253UL},{0xE6L,0x35L,0xA8L,0x82L},{0xE6L,0xBAL,0xBAL,0xE6L},{7UL,0x82L,253UL,0xBAL}},{{0x82L,0x35L,6UL,1UL},{0x11L,7UL,0xBAL,1UL},{0x18L,0x35L,0x18L,0xBAL},{0xE6L,0x82L,9UL,0xE6L},{0x11L,0xBAL,253UL,0x82L},{0xBAL,0x35L,253UL,253UL},{0x11L,0x11L,9UL,1UL}}};
        int i, j, k;
        for (l_689 = 0; (l_689 <= (-17)); l_689 = safe_sub_func_uint64_t_u_u(l_689, 6))
        { /* block id: 190 */
            int32_t *l_701 = &l_659;
            int32_t *l_702 = &g_499[0][0];
            int32_t *l_703 = &l_690;
            int32_t *l_704[7][2][4] = {{{(void*)0,&l_659,(void*)0,&g_255},{&g_499[0][0],(void*)0,&g_8,&g_8}},{{&g_499[0][0],&g_499[0][0],(void*)0,(void*)0},{(void*)0,&g_499[0][0],(void*)0,&g_163}},{{&l_659,(void*)0,&g_8,(void*)0},{&g_163,(void*)0,(void*)0,&g_163}},{{(void*)0,&g_499[0][0],&l_659,(void*)0},{(void*)0,&g_499[0][0],(void*)0,&g_8}},{{&g_163,(void*)0,&l_659,&g_255},{&g_499[0][0],&l_659,(void*)0,(void*)0}},{{&l_690,&g_163,(void*)0,&g_499[0][0]},{&g_499[0][0],(void*)0,&l_659,&l_690}},{{&g_163,(void*)0,(void*)0,&g_163},{(void*)0,&g_163,&l_659,&l_690}}};
            int i, j, k;
            l_705[5][1][3]--;
            return (*p_319);
        }
        return l_659;
    }
    (*l_724) = ((l_710 != (g_714 = ((*l_712) = ((l_692[0] != p_320) , &l_711)))) > ((((*l_658) ^= 0x1811L) <= (((safe_div_func_uint16_t_u_u(((safe_mul_func_uint8_t_u_u((safe_rshift_func_int16_t_s_s(g_188, 0)), l_692[1])) , (p_322 & (((*l_722) = (p_320 | l_659)) && p_322))), (*g_715))) > (*g_28)) | (-1L))) <= l_660));
    (*l_736) = ((4294967292UL < (((((void*)0 == &g_28) , (((*l_430) = (*l_724)) == ((((((*l_725)++) , ((safe_rshift_func_uint8_t_u_u(((*l_655) ^= ((safe_lshift_func_int16_t_s_u(((((safe_add_func_int8_t_s_s(0x6EL, ((l_436 != ((*l_724) , (void*)0)) < (safe_mod_func_uint32_t_u_u((*l_724), (*l_724)))))) & 0xFF37BDC370AB0D36LL) ^ (*g_28)) && 0x74L), (*l_724))) , (*l_724))), p_318)) || (*l_724))) || (*l_724)) > 0x6F6DL) , p_320))) < p_322) >= 0x6FFAF568L)) , (void*)0);
    return (*p_319);
}


/* ------------------------------------------ */
/* 
 * reads : g_188 g_66 g_78 g_2 g_163 g_28 g_29 g_466 g_7 g_255 g_11 g_495 g_232 g_196 g_499 g_8 g_431 g_260 g_328 g_446 g_604 g_539 g_653 g_3
 * writes: g_188 g_466 g_255 g_495 g_232 g_538 g_446 g_499 g_28 g_431 g_604 g_653
 */
static uint8_t * func_420(uint64_t  p_421, uint32_t ** p_422, uint16_t  p_423, union U3 * p_424, int64_t  p_425)
{ /* block id: 72 */
    int64_t l_464 = 0xC35247419DDA72D4LL;
    int32_t l_492 = 0L;
    union U3 *l_507 = &g_508;
    uint8_t *l_543 = &g_188;
    int32_t l_585 = 0x4E932698L;
    int32_t l_591 = (-4L);
    int32_t l_594 = 1L;
    int32_t l_595 = 0x2E052DF0L;
    int32_t l_596 = 0L;
    for (p_425 = 1; (p_425 <= (-12)); --p_425)
    { /* block id: 75 */
        int32_t l_458 = 0xD4F081FCL;
        int32_t l_496[5][10] = {{0x7E1D0457L,0L,0x7E1D0457L,6L,(-1L),(-1L),6L,0x7E1D0457L,0L,0x7E1D0457L},{0x7E1D0457L,0xDB097B45L,0L,0xCE81986EL,0L,0xDB097B45L,0x7E1D0457L,0x7E1D0457L,0xDB097B45L,0L},{0xDB097B45L,0x7E1D0457L,0x7E1D0457L,0xDB097B45L,0L,0xCE81986EL,0L,0xDB097B45L,0xCE81986EL,0xCE81986EL},{0x6E5EAA20L,0xCE81986EL,(-1L),0L,0L,(-1L),0xCE81986EL,0x6E5EAA20L,0xCE81986EL,(-1L)},{6L,0x7E1D0457L,0L,0x7E1D0457L,6L,(-1L),(-1L),6L,0x7E1D0457L,0L}};
        int32_t l_500 = 0x1B31A1AFL;
        int i, j;
        for (g_188 = 14; (g_188 != 5); g_188--)
        { /* block id: 78 */
            uint32_t *l_445 = &g_446;
            uint16_t *l_465 = &g_466;
            const int32_t l_467 = 0x31715504L;
            int32_t *l_468 = &g_255;
            uint8_t *l_493 = (void*)0;
            uint8_t *l_494 = &g_495;
            int32_t *l_497 = (void*)0;
            int32_t *l_498[2];
            int i;
            for (i = 0; i < 2; i++)
                l_498[i] = &g_499[0][0];
            (*l_468) &= (~(safe_lshift_func_int8_t_s_u(((0x108633E49B171A6DLL ^ (g_66 < (((l_445 = (*p_422)) != (((((safe_mul_func_uint8_t_u_u(((~(safe_mul_func_uint8_t_u_u(((safe_div_func_uint16_t_u_u(0xAE0AL, (safe_rshift_func_uint16_t_u_s((safe_lshift_func_uint16_t_u_u((((g_78 , l_458) < (((safe_mul_func_int16_t_s_s(g_2[4][5][3], (safe_add_func_uint16_t_u_u((g_163 , ((*l_465) &= (((((+(*g_28)) <= g_78) && g_78) , (*g_28)) >= l_464))), (-2L))))) >= p_425) ^ 0L)) & 0x44FCL), g_7[5][7][0])), p_423)))) < p_421), 4L))) >= p_423), (-1L))) > 0xD1L) == 1L) && 65535UL) , (*p_422))) > l_467))) >= l_467), 4)));
            l_500 &= (safe_div_func_uint8_t_u_u(255UL, (safe_mul_func_int8_t_s_s((9L != ((safe_mul_func_uint8_t_u_u(((((*l_468) , (*l_468)) <= ((1UL == (g_255 | (((safe_rshift_func_uint16_t_u_s((safe_add_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u((*l_468), ((safe_mul_func_int16_t_s_s((l_458 = (((*l_494) = (safe_mod_func_uint8_t_u_u((safe_add_func_int32_t_s_s((((((((((((l_492 = (~((*l_465) &= (!(5L >= ((+p_425) <= 0L)))))) <= 0xC0DEL) == p_425) > (*l_468)) > 0L) ^ g_11) <= p_421) || 0L) != l_458) <= 1L) , (-1L)), 0UL)), 0x22L))) > (*g_28))), p_425)) && p_425))), g_188)), (*l_468))) > l_496[3][8]) , p_423))) >= 4294967291UL)) > 8UL), 250UL)) <= 0x460BF5C7L)), p_423))));
        }
    }
    for (g_495 = 5; (g_495 == 15); ++g_495)
    { /* block id: 91 */
        g_255 &= (-1L);
    }
    for (g_232 = 11; (g_232 == (-9)); --g_232)
    { /* block id: 96 */
        return &g_188;
    }
    for (g_495 = 0; (g_495 <= 4); g_495 += 1)
    { /* block id: 101 */
        int16_t l_509 = 1L;
        int8_t *l_555 = (void*)0;
        int8_t *l_562 = &g_431;
        int32_t l_584[10][2][5] = {{{0x8C571077L,0x8C571077L,3L,0x14049FBCL,0x70CEF403L},{(-9L),0xC516A158L,0xC516A158L,(-9L),0x7DCED75AL}},{{5L,0x14049FBCL,(-1L),(-1L),0x14049FBCL},{0x7DCED75AL,0xC516A158L,0xD8254E46L,(-2L),(-2L)}},{{0L,0x8C571077L,0L,(-1L),3L},{(-5L),(-9L),(-2L),(-9L),(-5L)}},{{0L,5L,0x8C571077L,0x14049FBCL,0x8C571077L},{0x7DCED75AL,0x7DCED75AL,(-2L),(-5L),0x985E607DL}},{{5L,0L,0L,5L,0x8C571077L},{(-9L),(-5L),0xD8254E46L,0xD8254E46L,(-5L)}},{{0x8C571077L,0L,(-1L),3L,3L},{0xC516A158L,0x7DCED75AL,0xC516A158L,0xD8254E46L,(-2L)}},{{0x14049FBCL,5L,3L,5L,0x14049FBCL},{0xC516A158L,(-9L),0x7DCED75AL,(-5L),0x7DCED75AL}},{{0x8C571077L,0x8C571077L,3L,0x14049FBCL,0x70CEF403L},{(-9L),0xC516A158L,0xC516A158L,(-9L),0x7DCED75AL}},{{5L,0x14049FBCL,(-1L),(-1L),0x14049FBCL},{0x7DCED75AL,0xC516A158L,0xD8254E46L,(-2L),(-2L)}},{{0L,0x8C571077L,0L,(-1L),3L},{(-5L),(-9L),(-2L),(-9L),(-5L)}}};
        int i, j, k;
        if (g_11)
        { /* block id: 102 */
            union U3 *l_506 = (void*)0;
            union U3 **l_505 = &l_506;
            l_509 = (((*l_505) = p_424) == l_507);
        }
        else
        { /* block id: 105 */
            uint64_t l_540 = 18446744073709551615UL;
            int32_t l_566 = 0x99699DA6L;
            int32_t l_582 = 7L;
            int32_t l_583 = (-1L);
            int32_t l_587 = 0xB7C3EF41L;
            int32_t l_589[2][7][5] = {{{0xCBEC2B73L,0xACCE92ACL,(-10L),6L,0L},{0xCDF3E973L,0L,0xB4A9BF71L,(-3L),0x858AE58DL},{0xACCE92ACL,(-1L),(-1L),0xACCE92ACL,0xCDF3E973L},{0xACCE92ACL,6L,(-5L),0x15AA053FL,6L},{0xCDF3E973L,0xCBEC2B73L,1L,0xB4A9BF71L,(-7L)},{0xCBEC2B73L,0xCDF3E973L,(-1L),0x15AA053FL,0xB4A9BF71L},{6L,0xACCE92ACL,8L,0xACCE92ACL,6L}},{{(-1L),0xACCE92ACL,0xCDF3E973L,(-3L),0L},{0L,0xCDF3E973L,0xB4A9BF71L,6L,0x6F605855L},{0xACCE92ACL,0xCBEC2B73L,1L,0xACCE92ACL,0L},{0L,6L,1L,1L,6L},{0L,(-1L),1L,(-7L),0xB4A9BF71L},{0xCBEC2B73L,0L,1L,0x15AA053FL,(-7L)},{(-3L),0xACCE92ACL,0xB4A9BF71L,1L,1L}}};
            int16_t *l_602 = &g_232;
            uint32_t *l_603 = &g_604;
            uint32_t l_636 = 0xB69C4481L;
            uint16_t l_648 = 0UL;
            int i, j, k;
            for (g_188 = 0; (g_188 <= 4); g_188 += 1)
            { /* block id: 108 */
                int32_t l_510 = 0L;
                int32_t *l_511[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                const int64_t *l_559 = &g_560;
                int8_t *l_563 = (void*)0;
                int i;
                g_255 = (l_492 = l_510);
                if (g_7[2][5][1])
                    break;
                for (l_510 = 0; (l_510 <= 4); l_510 += 1)
                { /* block id: 114 */
                    uint16_t *l_517[2][3];
                    uint16_t **l_529 = &l_517[1][2];
                    int64_t *l_537 = &l_464;
                    int64_t **l_536 = &l_537;
                    uint32_t *l_541 = &g_446;
                    int32_t l_542 = 0x2B8CC005L;
                    uint32_t l_565 = 0xA92C8E55L;
                    int32_t l_590 = 0x409539DDL;
                    int32_t l_592 = 8L;
                    int32_t l_593[2][8][8] = {{{0xE9199FA5L,0x8468F639L,0x9BA00837L,1L,1L,0L,1L,1L},{0x8F792E4AL,0x9F757385L,0x8F792E4AL,(-1L),1L,2L,1L,0xE9199FA5L},{(-7L),0x565C005CL,1L,0x23AEEE4AL,0xA44A33EAL,0x0D1152E9L,1L,0xF448ECC7L},{(-7L),0x62F77F1DL,0x9F757385L,0x69DF3D12L,1L,0x8F792E4AL,0x23AEEE4AL,0x3E15F196L},{0x8F792E4AL,0xB1816153L,0x7DFCE124L,0x62F77F1DL,1L,1L,0x62F77F1DL,0x7DFCE124L},{0xE9199FA5L,0xE9199FA5L,0x08391A86L,0L,(-1L),1L,(-1L),2L},{0L,0x69DF3D12L,0L,0xA58835F2L,0xB1816153L,1L,0x8468F639L,2L},{0x69DF3D12L,(-1L),0x3E15F196L,0L,0x12974723L,0x23AEEE4AL,0x67EB1FFEL,0x7DFCE124L}},{{0L,0x3E15F196L,(-1L),0x62F77F1DL,0xAB8A4263L,0x62F77F1DL,(-1L),0x3E15F196L},{0xA58835F2L,0L,0x62F77F1DL,0x69DF3D12L,0x23AEEE4AL,(-1L),1L,0xF448ECC7L},{0xB1816153L,0x12974723L,0xAB8A4263L,0x23AEEE4AL,0xA58835F2L,0x8468F639L,1L,0xE9199FA5L},{1L,0x23AEEE4AL,0x62F77F1DL,(-1L),0x8468F639L,0x67EB1FFEL,(-1L),1L},{0x8468F639L,0x67EB1FFEL,(-1L),1L,1L,(-1L),0x67EB1FFEL,0x8468F639L},{2L,0x7DFCE124L,0x3E15F196L,0xF448ECC7L,0xE9199FA5L,1L,0x8468F639L,0xA58835F2L},{0x08391A86L,(-1L),0L,1L,0xF448ECC7L,1L,(-1L),0x23AEEE4AL},{0x9F757385L,0x7DFCE124L,0x08391A86L,0L,0x3E15F196L,(-1L),0x62F77F1DL,0xAB8A4263L}}};
                    int i, j, k;
                    for (i = 0; i < 2; i++)
                    {
                        for (j = 0; j < 3; j++)
                            l_517[i][j] = &g_466;
                    }
                    if ((g_499[0][0] = (safe_mul_func_int16_t_s_s((safe_add_func_int32_t_s_s((((((+(l_542 = ((&p_423 == l_517[0][1]) , (safe_lshift_func_uint8_t_u_s((((safe_unary_minus_func_uint32_t_u(((*l_541) = ((((((safe_add_func_int32_t_s_s((safe_lshift_func_uint16_t_u_s((safe_rshift_func_uint8_t_u_s(9UL, 4)), 4)), ((safe_add_func_uint8_t_u_u((((*l_529) = &p_423) != &g_466), ((safe_mul_func_uint16_t_u_u(0UL, p_423)) != ((safe_sub_func_int16_t_s_s((safe_sub_func_uint32_t_u_u(((((*l_536) = &g_196) != (g_538[2] = &g_196)) & g_196), g_188)), l_492)) < (-6L))))) , 4UL))) | l_540) , g_499[1][0]) > l_540) >= (**p_422)) , (**p_422))))) < g_8) ^ l_540), 4))))) != p_425) || 1L) , l_492) > p_421), p_423)), g_8))))
                    { /* block id: 121 */
                        return l_543;
                    }
                    else
                    { /* block id: 123 */
                        uint16_t *l_552 = &g_466;
                        const int64_t *l_557 = &g_558;
                        const int64_t **l_556[10][2][3] = {{{&l_557,&l_557,&l_557},{&l_557,(void*)0,&l_557}},{{(void*)0,&l_557,&l_557},{&l_557,&l_557,&l_557}},{{&l_557,(void*)0,(void*)0},{&l_557,&l_557,(void*)0}},{{(void*)0,&l_557,&l_557},{&l_557,&l_557,&l_557}},{{&l_557,(void*)0,&l_557},{(void*)0,&l_557,&l_557}},{{&l_557,&l_557,&l_557},{&l_557,(void*)0,(void*)0}},{{&l_557,&l_557,(void*)0},{(void*)0,&l_557,&l_557}},{{&l_557,&l_557,&l_557},{&l_557,(void*)0,&l_557}},{{(void*)0,&l_557,&l_557},{&l_557,&l_557,&l_557}},{{&l_557,(void*)0,&l_557},{&l_557,&l_557,&l_557}}};
                        int8_t **l_561 = &g_28;
                        int8_t *l_564 = &g_431;
                        int32_t l_572 = 0L;
                        int16_t *l_581 = &l_509;
                        int32_t l_586 = 0x9FBBAA0FL;
                        int32_t l_588[9][2][3] = {{{0x3F084494L,0xD8C90541L,(-2L)},{1L,0xE500268CL,(-2L)}},{{0x3809A724L,0xD8C90541L,0xD8C90541L},{(-2L),(-1L),0xCCDD11A4L}},{{0x3809A724L,0xCED65FB8L,0x3809A724L},{1L,1L,0xCCDD11A4L}},{{0x3F084494L,0x3F084494L,0xD8C90541L},{(-9L),1L,(-2L)}},{{0xD8C90541L,0xCED65FB8L,(-2L)},{(-9L),(-1L),(-9L)}},{{0x3F084494L,0xD8C90541L,(-2L)},{1L,0xE500268CL,(-2L)}},{{0x3809A724L,0xD8C90541L,0xD8C90541L},{(-2L),(-1L),0xCCDD11A4L}},{{0x3809A724L,0xCED65FB8L,0x3809A724L},{1L,1L,0xCCDD11A4L}},{{0x3F084494L,0x3F084494L,0xD8C90541L},{(-9L),1L,(-2L)}}};
                        uint32_t l_597 = 0x05DACDAEL;
                        int i, j, k;
                        l_492 &= (safe_lshift_func_uint8_t_u_u(((safe_lshift_func_int8_t_s_u((safe_rshift_func_int16_t_s_s((safe_mod_func_uint32_t_u_u((((p_421 == (((0xEB7BL & (g_2[7][1][1] > (((((*l_529) = &p_423) == (l_552 = &p_423)) < (1L & (18446744073709551608UL & (((safe_rshift_func_int8_t_s_s(((*l_564) |= (l_555 != (l_563 = (l_562 = ((*l_561) = (((l_559 = (p_421 , &p_425)) != (*l_536)) , &g_29)))))), 3)) | g_499[0][0]) , p_423)))) , 0x37CBL))) <= p_423) <= 5L)) | 0x3C34L) < l_565), g_466)), p_425)), g_78)) == l_540), 4));
                        l_566 = p_425;
                        l_566 = ((safe_mod_func_int64_t_s_s((((1UL | 65527UL) , ((!(1L || (safe_add_func_uint64_t_u_u(p_421, (g_260 && l_572))))) | (safe_div_func_int32_t_s_s((safe_sub_func_int8_t_s_s((safe_mul_func_int16_t_s_s(l_572, ((*l_581) = ((((safe_mod_func_uint8_t_u_u((p_425 == ((g_328[(l_510 + 1)][(g_188 + 1)][l_510] != p_424) && 1UL)), g_7[0][5][2])) , l_464) == 0x15C9L) && g_446)))), p_425)), 1UL)))) > p_421), p_425)) , l_565);
                        l_597++;
                    }
                    for (l_590 = 0; (l_590 <= 0); l_590 += 1)
                    { /* block id: 139 */
                        int i, j;
                        if (p_421)
                            break;
                        g_499[(l_590 + 2)][l_590] = 9L;
                        g_255 |= (p_423 & (*g_28));
                    }
                }
            }
            if (((safe_mod_func_uint8_t_u_u((((**p_422) , ((*l_602) = 0xABF6L)) <= ((((++(*l_603)) , l_583) && l_584[1][1][4]) , g_260)), (safe_add_func_uint16_t_u_u((safe_add_func_int8_t_s_s(((6L && (0xA687C36A867BEEB5LL != (safe_add_func_uint64_t_u_u(g_446, ((+(((((safe_div_func_uint8_t_u_u(1UL, 0x1FL)) , g_255) == (**p_422)) , 0xC2L) | (*g_28))) & l_587))))) || p_425), 9UL)), g_539[1])))) < g_188))
            { /* block id: 148 */
                uint32_t l_625 = 0x3625011BL;
                union U3 ** const l_626 = &l_507;
                int64_t l_633 = 1L;
                uint16_t *l_643 = &g_466;
                uint8_t *l_651 = &g_188;
                int32_t *l_652[4][3] = {{&l_595,&l_595,(void*)0},{&l_584[8][0][0],&l_584[8][0][0],&l_589[0][4][2]},{&l_595,&l_595,(void*)0},{&l_584[8][0][0],&l_584[8][0][0],&l_589[0][4][2]}};
                int32_t **l_654 = &l_652[0][0];
                int i, j;
                for (l_591 = 3; (l_591 >= 0); l_591 -= 1)
                { /* block id: 151 */
                    uint32_t *l_634 = &g_446;
                    int32_t l_635 = 0xA952FBC7L;
                    if ((((((!(safe_unary_minus_func_uint16_t_u(((safe_lshift_func_int8_t_s_s(0x18L, 5)) , (65531UL ^ (safe_unary_minus_func_uint32_t_u(g_431))))))) < (((safe_mod_func_uint32_t_u_u(((((l_583 = (safe_sub_func_int8_t_s_s(l_625, ((((void*)0 == l_626) & (safe_sub_func_uint64_t_u_u((safe_div_func_int16_t_s_s((p_425 ^ (-3L)), ((((((*l_634) = ((((safe_rshift_func_uint16_t_u_u(l_509, p_425)) , p_425) && l_633) <= l_595)) & 0x866EB58FL) , l_635) != l_636) & (-1L)))), 9L))) , 255UL)))) != l_635) && 0x4D6BL) || 0UL), g_539[1])) , 0L) != 1L)) > 7UL) >= (-1L)) ^ 4294967286UL))
                    { /* block id: 154 */
                        int32_t *l_649 = (void*)0;
                        int32_t *l_650[6] = {&g_499[2][0],&g_499[2][0],&g_7[3][5][2],&g_499[2][0],&g_499[2][0],&g_7[3][5][2]};
                        int i;
                        g_255 = ((l_584[9][1][0] = (safe_add_func_int64_t_s_s(((((safe_mul_func_int16_t_s_s(l_635, 0x50AAL)) || (9UL == (l_643 != &p_423))) != (((l_595 , (p_425 = 0xD9010410E73BAE4CLL)) , (((*l_602) &= (safe_rshift_func_uint16_t_u_u(l_584[3][1][3], (safe_div_func_uint16_t_u_u(g_499[0][0], g_539[1]))))) || p_421)) != 0x4ED6L)) | l_648), 4UL))) == l_635);
                        if (p_425)
                            break;
                        if (p_423)
                            break;
                        return l_651;
                    }
                    else
                    { /* block id: 162 */
                        return &g_188;
                    }
                }
                l_587 = g_196;
                (*l_654) = (g_653 = &l_584[9][1][0]);
                return &g_495;
            }
            else
            { /* block id: 170 */
                if ((*g_653))
                    break;
            }
        }
        return &g_495;
    }
    return l_543;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_2[i][j][k], "g_2[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_7[i][j][k], "g_7[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    transparent_crc(g_66, "g_66", print_hash_value);
    transparent_crc(g_78, "g_78", print_hash_value);
    transparent_crc(g_163, "g_163", print_hash_value);
    transparent_crc(g_188, "g_188", print_hash_value);
    transparent_crc(g_196, "g_196", print_hash_value);
    transparent_crc(g_232, "g_232", print_hash_value);
    transparent_crc(g_255, "g_255", print_hash_value);
    transparent_crc(g_260, "g_260", print_hash_value);
    transparent_crc(g_306, "g_306", print_hash_value);
    transparent_crc(g_431, "g_431", print_hash_value);
    transparent_crc(g_446, "g_446", print_hash_value);
    transparent_crc(g_466, "g_466", print_hash_value);
    transparent_crc(g_495, "g_495", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_499[i][j], "g_499[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_539[i], "g_539[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_558, "g_558", print_hash_value);
    transparent_crc(g_560, "g_560", print_hash_value);
    transparent_crc(g_604, "g_604", print_hash_value);
    transparent_crc(g_657, "g_657", print_hash_value);
    transparent_crc(g_723, "g_723", print_hash_value);
    transparent_crc(g_748, "g_748", print_hash_value);
    transparent_crc(g_845, "g_845", print_hash_value);
    transparent_crc(g_857, "g_857", print_hash_value);
    transparent_crc(g_922.f0, "g_922.f0", print_hash_value);
    transparent_crc(g_922.f1, "g_922.f1", print_hash_value);
    transparent_crc(g_922.f2, "g_922.f2", print_hash_value);
    transparent_crc(g_922.f3, "g_922.f3", print_hash_value);
    transparent_crc(g_922.f4, "g_922.f4", print_hash_value);
    transparent_crc(g_922.f5, "g_922.f5", print_hash_value);
    transparent_crc(g_924.f0, "g_924.f0", print_hash_value);
    transparent_crc(g_924.f1, "g_924.f1", print_hash_value);
    transparent_crc(g_924.f2, "g_924.f2", print_hash_value);
    transparent_crc(g_924.f3, "g_924.f3", print_hash_value);
    transparent_crc(g_924.f4, "g_924.f4", print_hash_value);
    transparent_crc(g_924.f5, "g_924.f5", print_hash_value);
    transparent_crc(g_951, "g_951", print_hash_value);
    transparent_crc(g_998, "g_998", print_hash_value);
    transparent_crc(g_1020, "g_1020", print_hash_value);
    transparent_crc(g_1071.f0, "g_1071.f0", print_hash_value);
    transparent_crc(g_1071.f1, "g_1071.f1", print_hash_value);
    transparent_crc(g_1071.f2, "g_1071.f2", print_hash_value);
    transparent_crc(g_1071.f3, "g_1071.f3", print_hash_value);
    transparent_crc(g_1181, "g_1181", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_1216[i], "g_1216[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1217, "g_1217", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_1218[i][j], "g_1218[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1219, "g_1219", print_hash_value);
    transparent_crc(g_1220, "g_1220", print_hash_value);
    transparent_crc(g_1221, "g_1221", print_hash_value);
    transparent_crc(g_1224, "g_1224", print_hash_value);
    transparent_crc(g_1273, "g_1273", print_hash_value);
    transparent_crc(g_1351, "g_1351", print_hash_value);
    transparent_crc(g_1396, "g_1396", print_hash_value);
    transparent_crc(g_1419, "g_1419", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_1446[i], "g_1446[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1470, "g_1470", print_hash_value);
    transparent_crc(g_1509, "g_1509", print_hash_value);
    transparent_crc(g_1550, "g_1550", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_1621[i], "g_1621[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1636, "g_1636", print_hash_value);
    transparent_crc(g_1727, "g_1727", print_hash_value);
    transparent_crc(g_1847, "g_1847", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_1918[i][j][k].f0, "g_1918[i][j][k].f0", print_hash_value);
                transparent_crc(g_1918[i][j][k].f1, "g_1918[i][j][k].f1", print_hash_value);
                transparent_crc(g_1918[i][j][k].f2, "g_1918[i][j][k].f2", print_hash_value);
                transparent_crc(g_1918[i][j][k].f3, "g_1918[i][j][k].f3", print_hash_value);
                transparent_crc(g_1918[i][j][k].f4, "g_1918[i][j][k].f4", print_hash_value);
                transparent_crc(g_1918[i][j][k].f5, "g_1918[i][j][k].f5", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1920.f0, "g_1920.f0", print_hash_value);
    transparent_crc(g_1920.f1, "g_1920.f1", print_hash_value);
    transparent_crc(g_1920.f2, "g_1920.f2", print_hash_value);
    transparent_crc(g_1920.f3, "g_1920.f3", print_hash_value);
    transparent_crc(g_1920.f4, "g_1920.f4", print_hash_value);
    transparent_crc(g_1920.f5, "g_1920.f5", print_hash_value);
    transparent_crc(g_1995.f0, "g_1995.f0", print_hash_value);
    transparent_crc(g_1995.f1, "g_1995.f1", print_hash_value);
    transparent_crc(g_1995.f2, "g_1995.f2", print_hash_value);
    transparent_crc(g_1995.f3, "g_1995.f3", print_hash_value);
    transparent_crc(g_1995.f4, "g_1995.f4", print_hash_value);
    transparent_crc(g_1995.f5, "g_1995.f5", print_hash_value);
    transparent_crc(g_2004, "g_2004", print_hash_value);
    transparent_crc(g_2045, "g_2045", print_hash_value);
    transparent_crc(g_2170, "g_2170", print_hash_value);
    transparent_crc(g_2355, "g_2355", print_hash_value);
    transparent_crc(g_2386.f0, "g_2386.f0", print_hash_value);
    transparent_crc(g_2386.f1, "g_2386.f1", print_hash_value);
    transparent_crc(g_2386.f2, "g_2386.f2", print_hash_value);
    transparent_crc(g_2386.f3, "g_2386.f3", print_hash_value);
    transparent_crc(g_2606, "g_2606", print_hash_value);
    transparent_crc(g_2725, "g_2725", print_hash_value);
    transparent_crc(g_2791, "g_2791", print_hash_value);
    transparent_crc(g_2857.f0, "g_2857.f0", print_hash_value);
    transparent_crc(g_2857.f1, "g_2857.f1", print_hash_value);
    transparent_crc(g_2857.f2, "g_2857.f2", print_hash_value);
    transparent_crc(g_2857.f3, "g_2857.f3", print_hash_value);
    transparent_crc(g_2886, "g_2886", print_hash_value);
    transparent_crc(g_3070, "g_3070", print_hash_value);
    transparent_crc(g_3071, "g_3071", print_hash_value);
    transparent_crc(g_3142.f0, "g_3142.f0", print_hash_value);
    transparent_crc(g_3142.f1, "g_3142.f1", print_hash_value);
    transparent_crc(g_3142.f2, "g_3142.f2", print_hash_value);
    transparent_crc(g_3142.f3, "g_3142.f3", print_hash_value);
    transparent_crc(g_3142.f4, "g_3142.f4", print_hash_value);
    transparent_crc(g_3142.f5, "g_3142.f5", print_hash_value);
    transparent_crc(g_3302, "g_3302", print_hash_value);
    transparent_crc(g_3307, "g_3307", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_3420[i], "g_3420[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3568.f0, "g_3568.f0", print_hash_value);
    transparent_crc(g_3568.f1, "g_3568.f1", print_hash_value);
    transparent_crc(g_3568.f2, "g_3568.f2", print_hash_value);
    transparent_crc(g_3568.f3, "g_3568.f3", print_hash_value);
    transparent_crc(g_3569.f0, "g_3569.f0", print_hash_value);
    transparent_crc(g_3569.f1, "g_3569.f1", print_hash_value);
    transparent_crc(g_3569.f2, "g_3569.f2", print_hash_value);
    transparent_crc(g_3569.f3, "g_3569.f3", print_hash_value);
    transparent_crc(g_3570.f0, "g_3570.f0", print_hash_value);
    transparent_crc(g_3570.f1, "g_3570.f1", print_hash_value);
    transparent_crc(g_3570.f2, "g_3570.f2", print_hash_value);
    transparent_crc(g_3570.f3, "g_3570.f3", print_hash_value);
    transparent_crc(g_3571.f0, "g_3571.f0", print_hash_value);
    transparent_crc(g_3571.f1, "g_3571.f1", print_hash_value);
    transparent_crc(g_3571.f2, "g_3571.f2", print_hash_value);
    transparent_crc(g_3571.f3, "g_3571.f3", print_hash_value);
    transparent_crc(g_3572.f0, "g_3572.f0", print_hash_value);
    transparent_crc(g_3572.f1, "g_3572.f1", print_hash_value);
    transparent_crc(g_3572.f2, "g_3572.f2", print_hash_value);
    transparent_crc(g_3572.f3, "g_3572.f3", print_hash_value);
    transparent_crc(g_3642.f0, "g_3642.f0", print_hash_value);
    transparent_crc(g_3642.f1, "g_3642.f1", print_hash_value);
    transparent_crc(g_3642.f2, "g_3642.f2", print_hash_value);
    transparent_crc(g_3642.f3, "g_3642.f3", print_hash_value);
    transparent_crc(g_3642.f4, "g_3642.f4", print_hash_value);
    transparent_crc(g_3642.f5, "g_3642.f5", print_hash_value);
    transparent_crc(g_3643, "g_3643", print_hash_value);
    transparent_crc(g_3792.f0, "g_3792.f0", print_hash_value);
    transparent_crc(g_3792.f1, "g_3792.f1", print_hash_value);
    transparent_crc(g_3792.f2, "g_3792.f2", print_hash_value);
    transparent_crc(g_3792.f3, "g_3792.f3", print_hash_value);
    transparent_crc(g_3794.f0, "g_3794.f0", print_hash_value);
    transparent_crc(g_3794.f1, "g_3794.f1", print_hash_value);
    transparent_crc(g_3794.f2, "g_3794.f2", print_hash_value);
    transparent_crc(g_3794.f3, "g_3794.f3", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_3870[i], "g_3870[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3961.f0, "g_3961.f0", print_hash_value);
    transparent_crc(g_3961.f1, "g_3961.f1", print_hash_value);
    transparent_crc(g_3961.f2, "g_3961.f2", print_hash_value);
    transparent_crc(g_3961.f3, "g_3961.f3", print_hash_value);
    transparent_crc(g_3961.f4, "g_3961.f4", print_hash_value);
    transparent_crc(g_3961.f5, "g_3961.f5", print_hash_value);
    transparent_crc(g_3963.f0, "g_3963.f0", print_hash_value);
    transparent_crc(g_3963.f1, "g_3963.f1", print_hash_value);
    transparent_crc(g_3963.f2, "g_3963.f2", print_hash_value);
    transparent_crc(g_3963.f3, "g_3963.f3", print_hash_value);
    transparent_crc(g_3963.f4, "g_3963.f4", print_hash_value);
    transparent_crc(g_3963.f5, "g_3963.f5", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_3964[i][j].f0, "g_3964[i][j].f0", print_hash_value);
            transparent_crc(g_3964[i][j].f1, "g_3964[i][j].f1", print_hash_value);
            transparent_crc(g_3964[i][j].f2, "g_3964[i][j].f2", print_hash_value);
            transparent_crc(g_3964[i][j].f3, "g_3964[i][j].f3", print_hash_value);
            transparent_crc(g_3964[i][j].f4, "g_3964[i][j].f4", print_hash_value);
            transparent_crc(g_3964[i][j].f5, "g_3964[i][j].f5", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_4118[i], "g_4118[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_4151, "g_4151", print_hash_value);
    transparent_crc(g_4267.f0, "g_4267.f0", print_hash_value);
    transparent_crc(g_4267.f1, "g_4267.f1", print_hash_value);
    transparent_crc(g_4267.f2, "g_4267.f2", print_hash_value);
    transparent_crc(g_4267.f3, "g_4267.f3", print_hash_value);
    transparent_crc(g_4267.f4, "g_4267.f4", print_hash_value);
    transparent_crc(g_4267.f5, "g_4267.f5", print_hash_value);
    transparent_crc(g_4294, "g_4294", print_hash_value);
    transparent_crc(g_4302, "g_4302", print_hash_value);
    transparent_crc(g_4338, "g_4338", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_4358[i].f0, "g_4358[i].f0", print_hash_value);
        transparent_crc(g_4358[i].f1, "g_4358[i].f1", print_hash_value);
        transparent_crc(g_4358[i].f2, "g_4358[i].f2", print_hash_value);
        transparent_crc(g_4358[i].f3, "g_4358[i].f3", print_hash_value);
        transparent_crc(g_4358[i].f4, "g_4358[i].f4", print_hash_value);
        transparent_crc(g_4358[i].f5, "g_4358[i].f5", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_4437.f0, "g_4437.f0", print_hash_value);
    transparent_crc(g_4437.f1, "g_4437.f1", print_hash_value);
    transparent_crc(g_4437.f2, "g_4437.f2", print_hash_value);
    transparent_crc(g_4437.f3, "g_4437.f3", print_hash_value);
    transparent_crc(g_4437.f4, "g_4437.f4", print_hash_value);
    transparent_crc(g_4437.f5, "g_4437.f5", print_hash_value);
    transparent_crc(g_4439.f0, "g_4439.f0", print_hash_value);
    transparent_crc(g_4439.f1, "g_4439.f1", print_hash_value);
    transparent_crc(g_4439.f2, "g_4439.f2", print_hash_value);
    transparent_crc(g_4439.f3, "g_4439.f3", print_hash_value);
    transparent_crc(g_4439.f4, "g_4439.f4", print_hash_value);
    transparent_crc(g_4439.f5, "g_4439.f5", print_hash_value);
    transparent_crc(g_4493, "g_4493", print_hash_value);
    transparent_crc(g_4502, "g_4502", print_hash_value);
    transparent_crc(g_4843.f0, "g_4843.f0", print_hash_value);
    transparent_crc(g_4843.f1, "g_4843.f1", print_hash_value);
    transparent_crc(g_4843.f2, "g_4843.f2", print_hash_value);
    transparent_crc(g_4843.f3, "g_4843.f3", print_hash_value);
    transparent_crc(g_4843.f4, "g_4843.f4", print_hash_value);
    transparent_crc(g_4843.f5, "g_4843.f5", print_hash_value);
    transparent_crc(g_4882, "g_4882", print_hash_value);
    transparent_crc(g_5044.f0, "g_5044.f0", print_hash_value);
    transparent_crc(g_5044.f1, "g_5044.f1", print_hash_value);
    transparent_crc(g_5044.f2, "g_5044.f2", print_hash_value);
    transparent_crc(g_5044.f3, "g_5044.f3", print_hash_value);
    transparent_crc(g_5048.f0, "g_5048.f0", print_hash_value);
    transparent_crc(g_5048.f1, "g_5048.f1", print_hash_value);
    transparent_crc(g_5048.f2, "g_5048.f2", print_hash_value);
    transparent_crc(g_5048.f3, "g_5048.f3", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_5084[i], "g_5084[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_5100.f0, "g_5100.f0", print_hash_value);
    transparent_crc(g_5100.f1, "g_5100.f1", print_hash_value);
    transparent_crc(g_5100.f2, "g_5100.f2", print_hash_value);
    transparent_crc(g_5100.f3, "g_5100.f3", print_hash_value);
    transparent_crc(g_5194, "g_5194", print_hash_value);
    transparent_crc(g_5213, "g_5213", print_hash_value);
    transparent_crc(g_5271, "g_5271", print_hash_value);
    transparent_crc(g_5420, "g_5420", print_hash_value);
    transparent_crc(g_5422, "g_5422", print_hash_value);
    transparent_crc(g_5483.f0, "g_5483.f0", print_hash_value);
    transparent_crc(g_5483.f1, "g_5483.f1", print_hash_value);
    transparent_crc(g_5483.f2, "g_5483.f2", print_hash_value);
    transparent_crc(g_5483.f3, "g_5483.f3", print_hash_value);
    transparent_crc(g_5483.f4, "g_5483.f4", print_hash_value);
    transparent_crc(g_5483.f5, "g_5483.f5", print_hash_value);
    transparent_crc(g_5485, "g_5485", print_hash_value);
    transparent_crc(g_5490, "g_5490", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_5546[i][j][k], "g_5546[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_5761, "g_5761", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_5779[i][j].f0, "g_5779[i][j].f0", print_hash_value);
            transparent_crc(g_5779[i][j].f1, "g_5779[i][j].f1", print_hash_value);
            transparent_crc(g_5779[i][j].f2, "g_5779[i][j].f2", print_hash_value);
            transparent_crc(g_5779[i][j].f3, "g_5779[i][j].f3", print_hash_value);
            transparent_crc(g_5779[i][j].f4, "g_5779[i][j].f4", print_hash_value);
            transparent_crc(g_5779[i][j].f5, "g_5779[i][j].f5", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_6028.f0, "g_6028.f0", print_hash_value);
    transparent_crc(g_6028.f1, "g_6028.f1", print_hash_value);
    transparent_crc(g_6028.f2, "g_6028.f2", print_hash_value);
    transparent_crc(g_6028.f3, "g_6028.f3", print_hash_value);
    transparent_crc(g_6028.f4, "g_6028.f4", print_hash_value);
    transparent_crc(g_6028.f5, "g_6028.f5", print_hash_value);
    transparent_crc(g_6045, "g_6045", print_hash_value);
    transparent_crc(g_6145, "g_6145", print_hash_value);
    transparent_crc(g_6233, "g_6233", print_hash_value);
    transparent_crc(g_6256, "g_6256", print_hash_value);
    transparent_crc(g_6270, "g_6270", print_hash_value);
    transparent_crc(g_6348, "g_6348", print_hash_value);
    transparent_crc(g_6355.f0, "g_6355.f0", print_hash_value);
    transparent_crc(g_6544.f0, "g_6544.f0", print_hash_value);
    transparent_crc(g_6544.f1, "g_6544.f1", print_hash_value);
    transparent_crc(g_6544.f2, "g_6544.f2", print_hash_value);
    transparent_crc(g_6544.f3, "g_6544.f3", print_hash_value);
    transparent_crc(g_6544.f4, "g_6544.f4", print_hash_value);
    transparent_crc(g_6544.f5, "g_6544.f5", print_hash_value);
    transparent_crc(g_6566.f0, "g_6566.f0", print_hash_value);
    transparent_crc(g_6567.f0, "g_6567.f0", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_6568[i].f0, "g_6568[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_6569.f0, "g_6569.f0", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_6570[i][j].f0, "g_6570[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_6571.f0, "g_6571.f0", print_hash_value);
    transparent_crc(g_6572.f0, "g_6572.f0", print_hash_value);
    transparent_crc(g_6573.f0, "g_6573.f0", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_6574[i].f0, "g_6574[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_6575.f0, "g_6575.f0", print_hash_value);
    transparent_crc(g_6576.f0, "g_6576.f0", print_hash_value);
    transparent_crc(g_6577.f0, "g_6577.f0", print_hash_value);
    transparent_crc(g_6578.f0, "g_6578.f0", print_hash_value);
    transparent_crc(g_6579.f0, "g_6579.f0", print_hash_value);
    transparent_crc(g_6580.f0, "g_6580.f0", print_hash_value);
    transparent_crc(g_6581.f0, "g_6581.f0", print_hash_value);
    transparent_crc(g_6582.f0, "g_6582.f0", print_hash_value);
    transparent_crc(g_6583.f0, "g_6583.f0", print_hash_value);
    transparent_crc(g_6584.f0, "g_6584.f0", print_hash_value);
    transparent_crc(g_6585.f0, "g_6585.f0", print_hash_value);
    transparent_crc(g_6586.f0, "g_6586.f0", print_hash_value);
    transparent_crc(g_6587.f0, "g_6587.f0", print_hash_value);
    transparent_crc(g_6607.f0, "g_6607.f0", print_hash_value);
    transparent_crc(g_6607.f1, "g_6607.f1", print_hash_value);
    transparent_crc(g_6607.f2, "g_6607.f2", print_hash_value);
    transparent_crc(g_6607.f3, "g_6607.f3", print_hash_value);
    transparent_crc(g_6833, "g_6833", print_hash_value);
    transparent_crc(g_6877.f0, "g_6877.f0", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_6878[i][j].f0, "g_6878[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_6879.f0, "g_6879.f0", print_hash_value);
    transparent_crc(g_6881.f0, "g_6881.f0", print_hash_value);
    transparent_crc(g_6882.f0, "g_6882.f0", print_hash_value);
    transparent_crc(g_7024.f0, "g_7024.f0", print_hash_value);
    transparent_crc(g_7076, "g_7076", print_hash_value);
    transparent_crc(g_7088, "g_7088", print_hash_value);
    transparent_crc(g_7096.f0, "g_7096.f0", print_hash_value);
    transparent_crc(g_7096.f1, "g_7096.f1", print_hash_value);
    transparent_crc(g_7096.f2, "g_7096.f2", print_hash_value);
    transparent_crc(g_7096.f3, "g_7096.f3", print_hash_value);
    transparent_crc(g_7096.f4, "g_7096.f4", print_hash_value);
    transparent_crc(g_7096.f5, "g_7096.f5", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_7098[i].f0, "g_7098[i].f0", print_hash_value);
        transparent_crc(g_7098[i].f1, "g_7098[i].f1", print_hash_value);
        transparent_crc(g_7098[i].f2, "g_7098[i].f2", print_hash_value);
        transparent_crc(g_7098[i].f3, "g_7098[i].f3", print_hash_value);
        transparent_crc(g_7098[i].f4, "g_7098[i].f4", print_hash_value);
        transparent_crc(g_7098[i].f5, "g_7098[i].f5", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_7160[i], "g_7160[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_7176.f0, "g_7176.f0", print_hash_value);
    transparent_crc(g_7185.f0, "g_7185.f0", print_hash_value);
    transparent_crc(g_7185.f1, "g_7185.f1", print_hash_value);
    transparent_crc(g_7185.f2, "g_7185.f2", print_hash_value);
    transparent_crc(g_7185.f3, "g_7185.f3", print_hash_value);
    transparent_crc(g_7185.f4, "g_7185.f4", print_hash_value);
    transparent_crc(g_7185.f5, "g_7185.f5", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_7217[i][j], "g_7217[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_7236.f0, "g_7236.f0", print_hash_value);
    transparent_crc(g_7254, "g_7254", print_hash_value);
    transparent_crc(g_7256, "g_7256", print_hash_value);
    transparent_crc(g_7269, "g_7269", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_7297[i][j][k], "g_7297[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_7349, "g_7349", print_hash_value);
    transparent_crc(g_7392.f0, "g_7392.f0", print_hash_value);
    transparent_crc(g_7392.f1, "g_7392.f1", print_hash_value);
    transparent_crc(g_7392.f2, "g_7392.f2", print_hash_value);
    transparent_crc(g_7392.f3, "g_7392.f3", print_hash_value);
    transparent_crc(g_7392.f4, "g_7392.f4", print_hash_value);
    transparent_crc(g_7392.f5, "g_7392.f5", print_hash_value);
    transparent_crc(g_7498, "g_7498", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_7618[i], "g_7618[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_7622[i].f0, "g_7622[i].f0", print_hash_value);
        transparent_crc(g_7622[i].f1, "g_7622[i].f1", print_hash_value);
        transparent_crc(g_7622[i].f2, "g_7622[i].f2", print_hash_value);
        transparent_crc(g_7622[i].f3, "g_7622[i].f3", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_7624.f0, "g_7624.f0", print_hash_value);
    transparent_crc(g_7624.f1, "g_7624.f1", print_hash_value);
    transparent_crc(g_7624.f2, "g_7624.f2", print_hash_value);
    transparent_crc(g_7624.f3, "g_7624.f3", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_7822[i].f0, "g_7822[i].f0", print_hash_value);
        transparent_crc(g_7822[i].f1, "g_7822[i].f1", print_hash_value);
        transparent_crc(g_7822[i].f2, "g_7822[i].f2", print_hash_value);
        transparent_crc(g_7822[i].f3, "g_7822[i].f3", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_7825.f0, "g_7825.f0", print_hash_value);
    transparent_crc(g_7825.f1, "g_7825.f1", print_hash_value);
    transparent_crc(g_7825.f2, "g_7825.f2", print_hash_value);
    transparent_crc(g_7825.f3, "g_7825.f3", print_hash_value);
    transparent_crc(g_7826.f0, "g_7826.f0", print_hash_value);
    transparent_crc(g_7826.f1, "g_7826.f1", print_hash_value);
    transparent_crc(g_7826.f2, "g_7826.f2", print_hash_value);
    transparent_crc(g_7826.f3, "g_7826.f3", print_hash_value);
    transparent_crc(g_7828.f0, "g_7828.f0", print_hash_value);
    transparent_crc(g_7828.f1, "g_7828.f1", print_hash_value);
    transparent_crc(g_7828.f2, "g_7828.f2", print_hash_value);
    transparent_crc(g_7828.f3, "g_7828.f3", print_hash_value);
    transparent_crc(g_7870, "g_7870", print_hash_value);
    transparent_crc(g_7933, "g_7933", print_hash_value);
    transparent_crc(g_8037.f0, "g_8037.f0", print_hash_value);
    transparent_crc(g_8037.f1, "g_8037.f1", print_hash_value);
    transparent_crc(g_8037.f2, "g_8037.f2", print_hash_value);
    transparent_crc(g_8037.f3, "g_8037.f3", print_hash_value);
    transparent_crc(g_8037.f4, "g_8037.f4", print_hash_value);
    transparent_crc(g_8037.f5, "g_8037.f5", print_hash_value);
    transparent_crc(g_8062, "g_8062", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_8076[i].f0, "g_8076[i].f0", print_hash_value);
        transparent_crc(g_8076[i].f1, "g_8076[i].f1", print_hash_value);
        transparent_crc(g_8076[i].f2, "g_8076[i].f2", print_hash_value);
        transparent_crc(g_8076[i].f3, "g_8076[i].f3", print_hash_value);
        transparent_crc(g_8076[i].f4, "g_8076[i].f4", print_hash_value);
        transparent_crc(g_8076[i].f5, "g_8076[i].f5", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_8082.f0, "g_8082.f0", print_hash_value);
    transparent_crc(g_8083.f0, "g_8083.f0", print_hash_value);
    transparent_crc(g_8084.f0, "g_8084.f0", print_hash_value);
    transparent_crc(g_8085.f0, "g_8085.f0", print_hash_value);
    transparent_crc(g_8086.f0, "g_8086.f0", print_hash_value);
    transparent_crc(g_8087.f0, "g_8087.f0", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_8088[i].f0, "g_8088[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_8089.f0, "g_8089.f0", print_hash_value);
    transparent_crc(g_8090.f0, "g_8090.f0", print_hash_value);
    transparent_crc(g_8091.f0, "g_8091.f0", print_hash_value);
    transparent_crc(g_8092.f0, "g_8092.f0", print_hash_value);
    transparent_crc(g_8093.f0, "g_8093.f0", print_hash_value);
    transparent_crc(g_8094.f0, "g_8094.f0", print_hash_value);
    transparent_crc(g_8095.f0, "g_8095.f0", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_8096[i][j][k].f0, "g_8096[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_8098.f0, "g_8098.f0", print_hash_value);
    transparent_crc(g_8117, "g_8117", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_8149[i].f0, "g_8149[i].f0", print_hash_value);
        transparent_crc(g_8149[i].f1, "g_8149[i].f1", print_hash_value);
        transparent_crc(g_8149[i].f2, "g_8149[i].f2", print_hash_value);
        transparent_crc(g_8149[i].f3, "g_8149[i].f3", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_8228, "g_8228", print_hash_value);
    transparent_crc(g_8242, "g_8242", print_hash_value);
    transparent_crc(g_8351.f0, "g_8351.f0", print_hash_value);
    transparent_crc(g_8351.f1, "g_8351.f1", print_hash_value);
    transparent_crc(g_8351.f2, "g_8351.f2", print_hash_value);
    transparent_crc(g_8351.f3, "g_8351.f3", print_hash_value);
    transparent_crc(g_8351.f4, "g_8351.f4", print_hash_value);
    transparent_crc(g_8351.f5, "g_8351.f5", print_hash_value);
    transparent_crc(g_8491, "g_8491", print_hash_value);
    transparent_crc(g_8558, "g_8558", print_hash_value);
    transparent_crc(g_8562, "g_8562", print_hash_value);
    transparent_crc(g_8583, "g_8583", print_hash_value);
    transparent_crc(g_8661.f0, "g_8661.f0", print_hash_value);
    transparent_crc(g_8661.f1, "g_8661.f1", print_hash_value);
    transparent_crc(g_8661.f2, "g_8661.f2", print_hash_value);
    transparent_crc(g_8661.f3, "g_8661.f3", print_hash_value);
    transparent_crc(g_8711, "g_8711", print_hash_value);
    transparent_crc(g_8779, "g_8779", print_hash_value);
    transparent_crc(g_8839.f0, "g_8839.f0", print_hash_value);
    transparent_crc(g_8974.f0, "g_8974.f0", print_hash_value);
    transparent_crc(g_9112, "g_9112", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_9115[i], "g_9115[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_9116[i], "g_9116[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_9179[i], "g_9179[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_9232.f0, "g_9232.f0", print_hash_value);
    transparent_crc(g_9232.f1, "g_9232.f1", print_hash_value);
    transparent_crc(g_9232.f2, "g_9232.f2", print_hash_value);
    transparent_crc(g_9232.f3, "g_9232.f3", print_hash_value);
    transparent_crc(g_9232.f4, "g_9232.f4", print_hash_value);
    transparent_crc(g_9232.f5, "g_9232.f5", print_hash_value);
    transparent_crc(g_9263.f0, "g_9263.f0", print_hash_value);
    transparent_crc(g_9263.f1, "g_9263.f1", print_hash_value);
    transparent_crc(g_9263.f2, "g_9263.f2", print_hash_value);
    transparent_crc(g_9263.f3, "g_9263.f3", print_hash_value);
    transparent_crc(g_9275, "g_9275", print_hash_value);
    transparent_crc(g_9279.f0, "g_9279.f0", print_hash_value);
    transparent_crc(g_9281.f0, "g_9281.f0", print_hash_value);
    transparent_crc(g_9311, "g_9311", print_hash_value);
    transparent_crc(g_9376.f0, "g_9376.f0", print_hash_value);
    transparent_crc(g_9376.f1, "g_9376.f1", print_hash_value);
    transparent_crc(g_9376.f2, "g_9376.f2", print_hash_value);
    transparent_crc(g_9376.f3, "g_9376.f3", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_9377[i][j][k], "g_9377[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_9425.f0, "g_9425.f0", print_hash_value);
    transparent_crc(g_9480, "g_9480", print_hash_value);
    transparent_crc(g_9511.f0, "g_9511.f0", print_hash_value);
    transparent_crc(g_9622.f0, "g_9622.f0", print_hash_value);
    transparent_crc(g_9622.f1, "g_9622.f1", print_hash_value);
    transparent_crc(g_9622.f2, "g_9622.f2", print_hash_value);
    transparent_crc(g_9622.f3, "g_9622.f3", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_9623[i][j].f0, "g_9623[i][j].f0", print_hash_value);
            transparent_crc(g_9623[i][j].f1, "g_9623[i][j].f1", print_hash_value);
            transparent_crc(g_9623[i][j].f2, "g_9623[i][j].f2", print_hash_value);
            transparent_crc(g_9623[i][j].f3, "g_9623[i][j].f3", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_9689[i].f0, "g_9689[i].f0", print_hash_value);
        transparent_crc(g_9689[i].f1, "g_9689[i].f1", print_hash_value);
        transparent_crc(g_9689[i].f2, "g_9689[i].f2", print_hash_value);
        transparent_crc(g_9689[i].f3, "g_9689[i].f3", print_hash_value);
        transparent_crc(g_9689[i].f4, "g_9689[i].f4", print_hash_value);
        transparent_crc(g_9689[i].f5, "g_9689[i].f5", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_9692, "g_9692", print_hash_value);
    transparent_crc(g_9697, "g_9697", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_9759[i].f0, "g_9759[i].f0", print_hash_value);
        transparent_crc(g_9759[i].f1, "g_9759[i].f1", print_hash_value);
        transparent_crc(g_9759[i].f2, "g_9759[i].f2", print_hash_value);
        transparent_crc(g_9759[i].f3, "g_9759[i].f3", print_hash_value);
        transparent_crc(g_9759[i].f4, "g_9759[i].f4", print_hash_value);
        transparent_crc(g_9759[i].f5, "g_9759[i].f5", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_9762.f0, "g_9762.f0", print_hash_value);
    transparent_crc(g_9762.f1, "g_9762.f1", print_hash_value);
    transparent_crc(g_9762.f2, "g_9762.f2", print_hash_value);
    transparent_crc(g_9762.f3, "g_9762.f3", print_hash_value);
    transparent_crc(g_9762.f4, "g_9762.f4", print_hash_value);
    transparent_crc(g_9762.f5, "g_9762.f5", print_hash_value);
    transparent_crc(g_9806, "g_9806", print_hash_value);
    transparent_crc(g_9898.f0, "g_9898.f0", print_hash_value);
    transparent_crc(g_9898.f1, "g_9898.f1", print_hash_value);
    transparent_crc(g_9898.f2, "g_9898.f2", print_hash_value);
    transparent_crc(g_9898.f3, "g_9898.f3", print_hash_value);
    transparent_crc(g_9898.f4, "g_9898.f4", print_hash_value);
    transparent_crc(g_9898.f5, "g_9898.f5", print_hash_value);
    transparent_crc(g_9912.f0, "g_9912.f0", print_hash_value);
    transparent_crc(g_9912.f1, "g_9912.f1", print_hash_value);
    transparent_crc(g_9912.f2, "g_9912.f2", print_hash_value);
    transparent_crc(g_9912.f3, "g_9912.f3", print_hash_value);
    transparent_crc(g_9912.f4, "g_9912.f4", print_hash_value);
    transparent_crc(g_9912.f5, "g_9912.f5", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_9921[i][j].f0, "g_9921[i][j].f0", print_hash_value);
            transparent_crc(g_9921[i][j].f1, "g_9921[i][j].f1", print_hash_value);
            transparent_crc(g_9921[i][j].f2, "g_9921[i][j].f2", print_hash_value);
            transparent_crc(g_9921[i][j].f3, "g_9921[i][j].f3", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_9993.f0, "g_9993.f0", print_hash_value);
    transparent_crc(g_9993.f1, "g_9993.f1", print_hash_value);
    transparent_crc(g_9993.f2, "g_9993.f2", print_hash_value);
    transparent_crc(g_9993.f3, "g_9993.f3", print_hash_value);
    transparent_crc(g_10163, "g_10163", print_hash_value);
    transparent_crc(g_10267, "g_10267", print_hash_value);
    transparent_crc(g_10336.f0, "g_10336.f0", print_hash_value);
    transparent_crc(g_10366, "g_10366", print_hash_value);
    transparent_crc(g_10414.f0, "g_10414.f0", print_hash_value);
    transparent_crc(g_10414.f1, "g_10414.f1", print_hash_value);
    transparent_crc(g_10414.f2, "g_10414.f2", print_hash_value);
    transparent_crc(g_10414.f3, "g_10414.f3", print_hash_value);
    transparent_crc(g_10414.f4, "g_10414.f4", print_hash_value);
    transparent_crc(g_10414.f5, "g_10414.f5", print_hash_value);
    transparent_crc(g_10447.f0, "g_10447.f0", print_hash_value);
    transparent_crc(g_10447.f1, "g_10447.f1", print_hash_value);
    transparent_crc(g_10447.f2, "g_10447.f2", print_hash_value);
    transparent_crc(g_10447.f3, "g_10447.f3", print_hash_value);
    transparent_crc(g_10447.f4, "g_10447.f4", print_hash_value);
    transparent_crc(g_10447.f5, "g_10447.f5", print_hash_value);
    transparent_crc(g_10449.f0, "g_10449.f0", print_hash_value);
    transparent_crc(g_10449.f1, "g_10449.f1", print_hash_value);
    transparent_crc(g_10449.f2, "g_10449.f2", print_hash_value);
    transparent_crc(g_10449.f3, "g_10449.f3", print_hash_value);
    transparent_crc(g_10449.f4, "g_10449.f4", print_hash_value);
    transparent_crc(g_10449.f5, "g_10449.f5", print_hash_value);
    transparent_crc(g_10461, "g_10461", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_10468[i].f0, "g_10468[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_10583[i][j][k].f0, "g_10583[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_10585.f0, "g_10585.f0", print_hash_value);
    transparent_crc(g_10729.f0, "g_10729.f0", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_10739[i].f0, "g_10739[i].f0", print_hash_value);
        transparent_crc(g_10739[i].f1, "g_10739[i].f1", print_hash_value);
        transparent_crc(g_10739[i].f2, "g_10739[i].f2", print_hash_value);
        transparent_crc(g_10739[i].f3, "g_10739[i].f3", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_10839.f0, "g_10839.f0", print_hash_value);
    transparent_crc(g_10840.f0, "g_10840.f0", print_hash_value);
    transparent_crc(g_10842.f0, "g_10842.f0", print_hash_value);
    transparent_crc(g_10902, "g_10902", print_hash_value);
    transparent_crc(g_10973, "g_10973", print_hash_value);
    transparent_crc(g_10991, "g_10991", print_hash_value);
    transparent_crc(g_11124, "g_11124", print_hash_value);
    transparent_crc(g_11144.f0, "g_11144.f0", print_hash_value);
    transparent_crc(g_11144.f1, "g_11144.f1", print_hash_value);
    transparent_crc(g_11144.f2, "g_11144.f2", print_hash_value);
    transparent_crc(g_11144.f3, "g_11144.f3", print_hash_value);
    transparent_crc(g_11144.f4, "g_11144.f4", print_hash_value);
    transparent_crc(g_11144.f5, "g_11144.f5", print_hash_value);
    transparent_crc(g_11147.f0, "g_11147.f0", print_hash_value);
    transparent_crc(g_11147.f1, "g_11147.f1", print_hash_value);
    transparent_crc(g_11147.f2, "g_11147.f2", print_hash_value);
    transparent_crc(g_11147.f3, "g_11147.f3", print_hash_value);
    transparent_crc(g_11147.f4, "g_11147.f4", print_hash_value);
    transparent_crc(g_11147.f5, "g_11147.f5", print_hash_value);
    transparent_crc(g_11203.f0, "g_11203.f0", print_hash_value);
    transparent_crc(g_11302, "g_11302", print_hash_value);
    transparent_crc(g_11314, "g_11314", print_hash_value);
    transparent_crc(g_11358.f0, "g_11358.f0", print_hash_value);
    transparent_crc(g_11421, "g_11421", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_11436[i][j].f0, "g_11436[i][j].f0", print_hash_value);
            transparent_crc(g_11436[i][j].f1, "g_11436[i][j].f1", print_hash_value);
            transparent_crc(g_11436[i][j].f2, "g_11436[i][j].f2", print_hash_value);
            transparent_crc(g_11436[i][j].f3, "g_11436[i][j].f3", print_hash_value);
            transparent_crc(g_11436[i][j].f4, "g_11436[i][j].f4", print_hash_value);
            transparent_crc(g_11436[i][j].f5, "g_11436[i][j].f5", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_11493.f0, "g_11493.f0", print_hash_value);
    transparent_crc(g_11493.f1, "g_11493.f1", print_hash_value);
    transparent_crc(g_11493.f2, "g_11493.f2", print_hash_value);
    transparent_crc(g_11493.f3, "g_11493.f3", print_hash_value);
    transparent_crc(g_11493.f4, "g_11493.f4", print_hash_value);
    transparent_crc(g_11493.f5, "g_11493.f5", print_hash_value);
    transparent_crc(g_11542, "g_11542", print_hash_value);
    transparent_crc(g_11569, "g_11569", print_hash_value);
    transparent_crc(g_11571.f0, "g_11571.f0", print_hash_value);
    transparent_crc(g_11743, "g_11743", print_hash_value);
    transparent_crc(g_11830, "g_11830", print_hash_value);
    transparent_crc(g_11925.f0, "g_11925.f0", print_hash_value);
    transparent_crc(g_11925.f1, "g_11925.f1", print_hash_value);
    transparent_crc(g_11925.f2, "g_11925.f2", print_hash_value);
    transparent_crc(g_11925.f3, "g_11925.f3", print_hash_value);
    transparent_crc(g_11927.f0, "g_11927.f0", print_hash_value);
    transparent_crc(g_11927.f1, "g_11927.f1", print_hash_value);
    transparent_crc(g_11927.f2, "g_11927.f2", print_hash_value);
    transparent_crc(g_11927.f3, "g_11927.f3", print_hash_value);
    transparent_crc(g_12051, "g_12051", print_hash_value);
    transparent_crc(g_12064, "g_12064", print_hash_value);
    transparent_crc(g_12187, "g_12187", print_hash_value);
    transparent_crc(g_12383, "g_12383", print_hash_value);
    transparent_crc(g_12449.f0, "g_12449.f0", print_hash_value);
    transparent_crc(g_12449.f1, "g_12449.f1", print_hash_value);
    transparent_crc(g_12449.f2, "g_12449.f2", print_hash_value);
    transparent_crc(g_12449.f3, "g_12449.f3", print_hash_value);
    transparent_crc(g_12449.f4, "g_12449.f4", print_hash_value);
    transparent_crc(g_12449.f5, "g_12449.f5", print_hash_value);
    transparent_crc(g_12487.f0, "g_12487.f0", print_hash_value);
    transparent_crc(g_12487.f1, "g_12487.f1", print_hash_value);
    transparent_crc(g_12487.f2, "g_12487.f2", print_hash_value);
    transparent_crc(g_12487.f3, "g_12487.f3", print_hash_value);
    transparent_crc(g_12522.f0, "g_12522.f0", print_hash_value);
    transparent_crc(g_12522.f1, "g_12522.f1", print_hash_value);
    transparent_crc(g_12522.f2, "g_12522.f2", print_hash_value);
    transparent_crc(g_12522.f3, "g_12522.f3", print_hash_value);
    transparent_crc(g_12522.f4, "g_12522.f4", print_hash_value);
    transparent_crc(g_12522.f5, "g_12522.f5", print_hash_value);
    transparent_crc(g_12526.f0, "g_12526.f0", print_hash_value);
    transparent_crc(g_12526.f1, "g_12526.f1", print_hash_value);
    transparent_crc(g_12526.f2, "g_12526.f2", print_hash_value);
    transparent_crc(g_12526.f3, "g_12526.f3", print_hash_value);
    transparent_crc(g_12526.f4, "g_12526.f4", print_hash_value);
    transparent_crc(g_12526.f5, "g_12526.f5", print_hash_value);
    transparent_crc(g_12820.f0, "g_12820.f0", print_hash_value);
    transparent_crc(g_12820.f1, "g_12820.f1", print_hash_value);
    transparent_crc(g_12820.f2, "g_12820.f2", print_hash_value);
    transparent_crc(g_12820.f3, "g_12820.f3", print_hash_value);
    transparent_crc(g_12820.f4, "g_12820.f4", print_hash_value);
    transparent_crc(g_12820.f5, "g_12820.f5", print_hash_value);
    transparent_crc(g_12831, "g_12831", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_13016[i].f0, "g_13016[i].f0", print_hash_value);
        transparent_crc(g_13016[i].f1, "g_13016[i].f1", print_hash_value);
        transparent_crc(g_13016[i].f2, "g_13016[i].f2", print_hash_value);
        transparent_crc(g_13016[i].f3, "g_13016[i].f3", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_13017.f0, "g_13017.f0", print_hash_value);
    transparent_crc(g_13017.f1, "g_13017.f1", print_hash_value);
    transparent_crc(g_13017.f2, "g_13017.f2", print_hash_value);
    transparent_crc(g_13017.f3, "g_13017.f3", print_hash_value);
    transparent_crc(g_13032, "g_13032", print_hash_value);
    transparent_crc(g_13049.f0, "g_13049.f0", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_13124[i].f0, "g_13124[i].f0", print_hash_value);
        transparent_crc(g_13124[i].f1, "g_13124[i].f1", print_hash_value);
        transparent_crc(g_13124[i].f2, "g_13124[i].f2", print_hash_value);
        transparent_crc(g_13124[i].f3, "g_13124[i].f3", print_hash_value);
        transparent_crc(g_13124[i].f4, "g_13124[i].f4", print_hash_value);
        transparent_crc(g_13124[i].f5, "g_13124[i].f5", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_13141.f0, "g_13141.f0", print_hash_value);
    transparent_crc(g_13221.f0, "g_13221.f0", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_13246[i], "g_13246[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_13260, "g_13260", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_13298[i][j].f0, "g_13298[i][j].f0", print_hash_value);
            transparent_crc(g_13298[i][j].f1, "g_13298[i][j].f1", print_hash_value);
            transparent_crc(g_13298[i][j].f2, "g_13298[i][j].f2", print_hash_value);
            transparent_crc(g_13298[i][j].f3, "g_13298[i][j].f3", print_hash_value);
            transparent_crc(g_13298[i][j].f4, "g_13298[i][j].f4", print_hash_value);
            transparent_crc(g_13298[i][j].f5, "g_13298[i][j].f5", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_13361.f0, "g_13361.f0", print_hash_value);
    transparent_crc(g_13361.f1, "g_13361.f1", print_hash_value);
    transparent_crc(g_13361.f2, "g_13361.f2", print_hash_value);
    transparent_crc(g_13361.f3, "g_13361.f3", print_hash_value);
    transparent_crc(g_13361.f4, "g_13361.f4", print_hash_value);
    transparent_crc(g_13361.f5, "g_13361.f5", print_hash_value);
    transparent_crc(g_13364.f0, "g_13364.f0", print_hash_value);
    transparent_crc(g_13370.f0, "g_13370.f0", print_hash_value);
    transparent_crc(g_13370.f1, "g_13370.f1", print_hash_value);
    transparent_crc(g_13370.f2, "g_13370.f2", print_hash_value);
    transparent_crc(g_13370.f3, "g_13370.f3", print_hash_value);
    transparent_crc(g_13370.f4, "g_13370.f4", print_hash_value);
    transparent_crc(g_13370.f5, "g_13370.f5", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 3515
   depth: 1, occurrence: 4
XXX total union variables: 11

XXX non-zero bitfields defined in structs: 8
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 1
XXX volatile bitfields defined in structs: 2
XXX structs with bitfields in the program: 154
breakdown:
   indirect level: 0, occurrence: 7
   indirect level: 1, occurrence: 70
   indirect level: 2, occurrence: 26
   indirect level: 3, occurrence: 19
   indirect level: 4, occurrence: 15
   indirect level: 5, occurrence: 17
XXX full-bitfields structs in the program: 1
breakdown:
   indirect level: 0, occurrence: 1
XXX times a bitfields struct's address is taken: 109
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 7
XXX times a single bitfield on LHS: 10
XXX times a single bitfield on RHS: 2

XXX max expression depth: 63
breakdown:
   depth: 1, occurrence: 1231
   depth: 2, occurrence: 310
   depth: 3, occurrence: 29
   depth: 4, occurrence: 13
   depth: 5, occurrence: 10
   depth: 6, occurrence: 7
   depth: 7, occurrence: 4
   depth: 8, occurrence: 3
   depth: 9, occurrence: 4
   depth: 10, occurrence: 3
   depth: 11, occurrence: 5
   depth: 12, occurrence: 4
   depth: 13, occurrence: 5
   depth: 14, occurrence: 3
   depth: 15, occurrence: 12
   depth: 16, occurrence: 12
   depth: 17, occurrence: 15
   depth: 18, occurrence: 8
   depth: 19, occurrence: 18
   depth: 20, occurrence: 10
   depth: 21, occurrence: 9
   depth: 22, occurrence: 14
   depth: 23, occurrence: 15
   depth: 24, occurrence: 13
   depth: 25, occurrence: 14
   depth: 26, occurrence: 13
   depth: 27, occurrence: 17
   depth: 28, occurrence: 10
   depth: 29, occurrence: 11
   depth: 30, occurrence: 10
   depth: 31, occurrence: 5
   depth: 32, occurrence: 8
   depth: 33, occurrence: 6
   depth: 34, occurrence: 4
   depth: 35, occurrence: 6
   depth: 36, occurrence: 6
   depth: 37, occurrence: 2
   depth: 38, occurrence: 3
   depth: 39, occurrence: 3
   depth: 40, occurrence: 3
   depth: 41, occurrence: 1
   depth: 42, occurrence: 1
   depth: 43, occurrence: 1
   depth: 47, occurrence: 1
   depth: 48, occurrence: 1
   depth: 49, occurrence: 1
   depth: 63, occurrence: 1

XXX total number of pointers: 2903

XXX times a variable address is taken: 5835
XXX times a pointer is dereferenced on RHS: 2153
breakdown:
   depth: 1, occurrence: 1511
   depth: 2, occurrence: 370
   depth: 3, occurrence: 118
   depth: 4, occurrence: 91
   depth: 5, occurrence: 63
XXX times a pointer is dereferenced on LHS: 1532
breakdown:
   depth: 1, occurrence: 1051
   depth: 2, occurrence: 265
   depth: 3, occurrence: 92
   depth: 4, occurrence: 87
   depth: 5, occurrence: 37
XXX times a pointer is compared with null: 272
XXX times a pointer is compared with address of another variable: 62
XXX times a pointer is compared with another pointer: 85
XXX times a pointer is qualified to be dereferenced: 47712

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 9636
   level: 2, occurrence: 2797
   level: 3, occurrence: 1268
   level: 4, occurrence: 1808
   level: 5, occurrence: 1298
XXX number of pointers point to pointers: 1449
XXX number of pointers point to scalars: 1262
XXX number of pointers point to structs: 53
XXX percent of pointers has null in alias set: 34.8
XXX average alias set size: 1.64

XXX times a non-volatile is read: 12538
XXX times a non-volatile is write: 5749
XXX times a volatile is read: 15
XXX    times read thru a pointer: 3
XXX times a volatile is write: 6
XXX    times written thru a pointer: 5
XXX times a volatile is available for access: 1.2e+03
XXX percentage of non-volatile access: 99.9

XXX forward jumps: 10
XXX backward jumps: 39

XXX stmts: 1254
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 131
   depth: 1, occurrence: 130
   depth: 2, occurrence: 156
   depth: 3, occurrence: 217
   depth: 4, occurrence: 285
   depth: 5, occurrence: 335

XXX percentage a fresh-made variable is used: 16.5
XXX percentage an existing variable is used: 83.5
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

