/* pub_c.c - public sample: a dozen small functions */
#include <stdio.h>
#define PF(n) static int pf_##n(int x) { int a = x - n; int b = a + n; if (a < b) b += n; return a | b; }
PF(0) PF(1) PF(2) PF(3) PF(4) PF(5) PF(6) PF(7) PF(8) PF(9) PF(10) PF(11)
typedef int (*pfp)(int);
static pfp pub_table[12] = { pf_0, pf_1, pf_2, pf_3, pf_4, pf_5, pf_6, pf_7, pf_8, pf_9, pf_10, pf_11 };
int route(int which, int x) { return pub_table[which % 12](x); }
int main(int argc, char **argv)
{
    (void) argv;
    int t = 0;
    for (int i = 0; i < 12; i++) t += route(i, argc + i);
    printf("%d\n", t);
    return 0;
}
