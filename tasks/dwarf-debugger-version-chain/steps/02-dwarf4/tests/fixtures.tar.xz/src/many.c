/* many.c - many small functions: a dense line table and many FDEs */
#include <stdio.h>

#define FN(n) \
    static int fn_##n(int x) \
    { \
        int a = x + n; \
        int b = a * 2; \
        if (a > b) { \
            b -= n; \
        } \
        return a ^ b; \
    }

FN(0) FN(1) FN(2) FN(3) FN(4) FN(5) FN(6) FN(7)
FN(8) FN(9) FN(10) FN(11) FN(12) FN(13) FN(14) FN(15)
FN(16) FN(17) FN(18) FN(19) FN(20) FN(21) FN(22) FN(23)

typedef int (*fp)(int);

static fp table[24] = {
    fn_0, fn_1, fn_2, fn_3, fn_4, fn_5, fn_6, fn_7,
    fn_8, fn_9, fn_10, fn_11, fn_12, fn_13, fn_14, fn_15,
    fn_16, fn_17, fn_18, fn_19, fn_20, fn_21, fn_22, fn_23
};

int dispatch(int which, int x)
{
    return table[which % 24](x);
}

int main(int argc, char **argv)
{
    (void) argv;
    int t = 0;
    for (int i = 0; i < 24; i++) {
        t += dispatch(i, argc + i);
    }
    printf("%d\n", t);
    return 0;
}
