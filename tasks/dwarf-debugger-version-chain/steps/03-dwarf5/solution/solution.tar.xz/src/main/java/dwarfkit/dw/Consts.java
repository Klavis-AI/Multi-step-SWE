package dwarfkit.dw;

/** DWARF constants used by the reader (DWARF 2 through 5). */
public final class Consts {
    private Consts() {}

    // tags
    public static final int DW_TAG_array_type = 0x01, DW_TAG_class_type = 0x02,
            DW_TAG_enumeration_type = 0x04, DW_TAG_formal_parameter = 0x05,
            DW_TAG_lexical_block = 0x0b, DW_TAG_member = 0x0d, DW_TAG_pointer_type = 0x0f,
            DW_TAG_reference_type = 0x10, DW_TAG_compile_unit = 0x11,
            DW_TAG_structure_type = 0x13, DW_TAG_subroutine_type = 0x15,
            DW_TAG_typedef = 0x16, DW_TAG_union_type = 0x17,
            DW_TAG_unspecified_parameters = 0x18, DW_TAG_variant = 0x19,
            DW_TAG_inheritance = 0x1c, DW_TAG_inlined_subroutine = 0x1d,
            DW_TAG_subrange_type = 0x21, DW_TAG_base_type = 0x24,
            DW_TAG_const_type = 0x26, DW_TAG_enumerator = 0x28,
            DW_TAG_subprogram = 0x2e, DW_TAG_variable = 0x34,
            DW_TAG_volatile_type = 0x35, DW_TAG_restrict_type = 0x37,
            DW_TAG_namespace = 0x39, DW_TAG_unspecified_type = 0x3b,
            DW_TAG_rvalue_reference_type = 0x42, DW_TAG_call_site = 0x48,
            DW_TAG_skeleton_unit = 0x4a, DW_TAG_immutable_type = 0x4b,
            DW_TAG_type_unit = 0x41, DW_TAG_partial_unit = 0x3c,
            DW_TAG_atomic_type = 0x47, DW_TAG_GNU_call_site = 0x4109;

    // attributes
    public static final int DW_AT_location = 0x02, DW_AT_name = 0x03,
            DW_AT_byte_size = 0x0b, DW_AT_stmt_list = 0x10, DW_AT_low_pc = 0x11,
            DW_AT_high_pc = 0x12, DW_AT_language = 0x13, DW_AT_comp_dir = 0x1b,
            DW_AT_const_value = 0x1c, DW_AT_upper_bound = 0x2f, DW_AT_producer = 0x25,
            DW_AT_prototyped = 0x27, DW_AT_count = 0x37, DW_AT_data_member_location = 0x38,
            DW_AT_decl_file = 0x3a, DW_AT_decl_line = 0x3b, DW_AT_declaration = 0x3c,
            DW_AT_encoding = 0x3e, DW_AT_external = 0x3f, DW_AT_frame_base = 0x40,
            DW_AT_specification = 0x47, DW_AT_type = 0x49, DW_AT_ranges = 0x55,
            DW_AT_trampoline = 0x56, DW_AT_call_column = 0x57, DW_AT_call_file = 0x58,
            DW_AT_call_line = 0x59, DW_AT_description = 0x5a,
            DW_AT_abstract_origin = 0x31, DW_AT_inline = 0x20, DW_AT_artificial = 0x34,
            DW_AT_str_offsets_base = 0x72, DW_AT_addr_base = 0x73,
            DW_AT_rnglists_base = 0x74, DW_AT_dwo_name = 0x76,
            DW_AT_loclists_base = 0x8c, DW_AT_linkage_name = 0x6e,
            DW_AT_MIPS_linkage_name = 0x2007, DW_AT_GNU_dwo_name = 0x2130,
            DW_AT_GNU_dwo_id = 0x2131, DW_AT_GNU_ranges_base = 0x2132,
            DW_AT_GNU_addr_base = 0x2133, DW_AT_GNU_pubnames = 0x2134;

    // forms
    public static final int DW_FORM_addr = 0x01, DW_FORM_block2 = 0x03, DW_FORM_block4 = 0x04,
            DW_FORM_data2 = 0x05, DW_FORM_data4 = 0x06, DW_FORM_data8 = 0x07,
            DW_FORM_string = 0x08, DW_FORM_block = 0x09, DW_FORM_block1 = 0x0a,
            DW_FORM_data1 = 0x0b, DW_FORM_flag = 0x0c, DW_FORM_sdata = 0x0d,
            DW_FORM_strp = 0x0e, DW_FORM_udata = 0x0f, DW_FORM_ref_addr = 0x10,
            DW_FORM_ref1 = 0x11, DW_FORM_ref2 = 0x12, DW_FORM_ref4 = 0x13,
            DW_FORM_ref8 = 0x14, DW_FORM_ref_udata = 0x15, DW_FORM_indirect = 0x16,
            DW_FORM_sec_offset = 0x17, DW_FORM_exprloc = 0x18, DW_FORM_flag_present = 0x19,
            DW_FORM_strx = 0x1a, DW_FORM_addrx = 0x1b, DW_FORM_ref_sup4 = 0x1c,
            DW_FORM_strp_sup = 0x1d, DW_FORM_data16 = 0x1e, DW_FORM_line_strp = 0x1f,
            DW_FORM_ref_sig8 = 0x20, DW_FORM_implicit_const = 0x21, DW_FORM_loclistx = 0x22,
            DW_FORM_rnglistx = 0x23, DW_FORM_ref_sup8 = 0x24,
            DW_FORM_strx1 = 0x25, DW_FORM_strx2 = 0x26, DW_FORM_strx3 = 0x27,
            DW_FORM_strx4 = 0x28, DW_FORM_addrx1 = 0x29, DW_FORM_addrx2 = 0x2a,
            DW_FORM_addrx3 = 0x2b, DW_FORM_addrx4 = 0x2c;

    // unit types (DWARF 5)
    public static final int DW_UT_compile = 0x01, DW_UT_type = 0x02, DW_UT_partial = 0x03,
            DW_UT_skeleton = 0x04, DW_UT_split_compile = 0x05, DW_UT_split_type = 0x06;

    // line number program
    public static final int DW_LNS_copy = 1, DW_LNS_advance_pc = 2, DW_LNS_advance_line = 3,
            DW_LNS_set_file = 4, DW_LNS_set_column = 5, DW_LNS_negate_stmt = 6,
            DW_LNS_set_basic_block = 7, DW_LNS_const_add_pc = 8, DW_LNS_fixed_advance_pc = 9,
            DW_LNS_set_prologue_end = 10, DW_LNS_set_epilogue_begin = 11, DW_LNS_set_isa = 12;
    public static final int DW_LNE_end_sequence = 1, DW_LNE_set_address = 2,
            DW_LNE_define_file = 3, DW_LNE_set_discriminator = 4;
    public static final int DW_LNCT_path = 1, DW_LNCT_directory_index = 2,
            DW_LNCT_timestamp = 3, DW_LNCT_size = 4, DW_LNCT_MD5 = 5;

    // range list entries (DWARF 5)
    public static final int DW_RLE_end_of_list = 0, DW_RLE_base_addressx = 1,
            DW_RLE_startx_endx = 2, DW_RLE_startx_length = 3, DW_RLE_offset_pair = 4,
            DW_RLE_base_address = 5, DW_RLE_start_end = 6, DW_RLE_start_length = 7;
    public static final int DW_LLE_end_of_list = 0, DW_LLE_base_addressx = 1,
            DW_LLE_startx_endx = 2, DW_LLE_startx_length = 3, DW_LLE_offset_pair = 4,
            DW_LLE_default_location = 5, DW_LLE_base_address = 6, DW_LLE_start_end = 7,
            DW_LLE_start_length = 8;
}
