package dwarfkit.rsp;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * RSP framing: the "$payload#cc" frame, the +/- acknowledgements, the brace
 * escape and the '*' run-length encoding.
 *
 * We never emit run-length encoding (it is optional) but we must decode what
 * gdb sends, and we must escape the four magic bytes in any binary reply or
 * gdb will mis-frame it.
 */
public final class Packet {
    /** The out-of-band interrupt byte, returned by read() as a one-char string. */
    public static final String INTERRUPT = String.valueOf((char) 3);

    private final InputStream in;
    private final OutputStream out;
    private boolean noAck;

    public Packet(InputStream in, OutputStream out) {
        this.in = in;
        this.out = out;
    }

    public void setNoAck(boolean v) { noAck = v; }

    /** The next packet payload, or null at end of stream. */
    public String read() throws IOException {
        while (true) {
            int c = in.read();
            if (c < 0) return null;
            if (c == '+' || c == '-') continue;       // acknowledgements
            if (c == 3) return INTERRUPT;             // out-of-band interrupt
            if (c != '$') continue;                   // resynchronise
            ByteArrayOutputStream raw = new ByteArrayOutputStream();
            int sum = 0;
            while (true) {
                int b = in.read();
                if (b < 0) return null;
                if (b == '#') break;
                sum = (sum + b) & 0xff;
                raw.write(b);
            }
            int h1 = in.read(), h2 = in.read();
            if (h1 < 0 || h2 < 0) return null;
            int want = (hex(h1) << 4) | hex(h2);
            if (!noAck) {
                out.write(sum == want ? '+' : '-');
                out.flush();
            }
            if (sum != want) continue;                // gdb will resend
            return unescape(raw.toByteArray());
        }
    }

    private static int hex(int c) {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        return 0;
    }

    private static String unescape(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length);
        for (int i = 0; i < b.length; i++) {
            int c = b[i] & 0xff;
            if (c == '}' && i + 1 < b.length) {
                sb.append((char) ((b[++i] & 0xff) ^ 0x20));
            } else if (c == '*' && i + 1 < b.length && sb.length() > 0) {
                int n = (b[++i] & 0xff) - 29;
                char last = sb.charAt(sb.length() - 1);
                for (int k = 0; k < n; k++) sb.append(last);
            } else {
                sb.append((char) c);
            }
        }
        return sb.toString();
    }

    /** Sends a payload made only of safe ASCII (hex, keywords, XML text). */
    public void send(String payload) throws IOException {
        sendBytes(payload.getBytes(StandardCharsets.ISO_8859_1), false);
    }

    /** Sends a payload that may contain arbitrary bytes; escapes the magic four. */
    public void sendBinary(byte[] payload) throws IOException {
        sendBytes(payload, true);
    }

    private void sendBytes(byte[] payload, boolean escape) throws IOException {
        ByteArrayOutputStream body = new ByteArrayOutputStream(payload.length + 16);
        for (byte value : payload) {
            int c = value & 0xff;
            if (escape && (c == '}' || c == '#' || c == '$' || c == '*')) {
                body.write('}');
                body.write(c ^ 0x20);
            } else {
                body.write(c);
            }
        }
        byte[] b = body.toByteArray();
        int sum = 0;
        for (byte value : b) sum = (sum + (value & 0xff)) & 0xff;
        ByteArrayOutputStream frame = new ByteArrayOutputStream(b.length + 4);
        frame.write('$');
        frame.write(b, 0, b.length);
        frame.write('#');
        frame.write(hexDigit(sum >> 4));
        frame.write(hexDigit(sum & 0xf));
        byte[] wire = frame.toByteArray();
        out.write(wire);
        out.flush();
        if (!noAck) {
            int a = in.read();                        // gdb's + for this reply
            while (a == '-') {                        // it wants it again
                out.write(wire);
                out.flush();
                a = in.read();
            }
        }
    }

    private static int hexDigit(int v) { return v < 10 ? '0' + v : 'a' + (v - 10); }

    /* ---- hex helpers shared by the packet handlers ---- */

    public static String toHex(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte value : b) {
            sb.append(hexChar((value >> 4) & 0xf)).append(hexChar(value & 0xf));
        }
        return sb.toString();
    }

    private static char hexChar(int v) { return (char) (v < 10 ? '0' + v : 'a' + (v - 10)); }

    public static byte[] fromHex(String s) {
        int n = s.length() / 2;
        byte[] b = new byte[n];
        for (int i = 0; i < n; i++) {
            b[i] = (byte) ((hex(s.charAt(i * 2)) << 4) | hex(s.charAt(i * 2 + 1)));
        }
        return b;
    }

    /** A little-endian register value as it appears in a 'T' stop reply. */
    public static String leHex(long v, int bytes) {
        StringBuilder sb = new StringBuilder(bytes * 2);
        for (int i = 0; i < bytes; i++) {
            int by = (int) ((v >>> (8 * i)) & 0xff);
            sb.append(hexChar(by >> 4)).append(hexChar(by & 0xf));
        }
        return sb.toString();
    }
}
