package dwarfkit.dbg;

/**
 * Host signal numbers are not what travels on the wire.  RSP stop replies carry
 * gdb's own {@code enum gdb_signal} numbering, which agrees with Linux for the
 * first handful of signals and then diverges (host SIGUSR1 is 10, gdb's is 30).
 * Every number entering or leaving a stop reply goes through here.
 */
public final class Signals {
    private Signals() {}

    /* gdb_signal value for each Linux/x86 signal number, index = host signo. */
    private static final int[] HOST_TO_GDB = new int[65];
    private static final int[] GDB_TO_HOST = new int[128];

    private static void map(int host, int gdb) {
        if (host < HOST_TO_GDB.length) HOST_TO_GDB[host] = gdb;
        if (gdb < GDB_TO_HOST.length) GDB_TO_HOST[gdb] = host;
    }

    static {
        map(1, 1);    // SIGHUP
        map(2, 2);    // SIGINT
        map(3, 3);    // SIGQUIT
        map(4, 4);    // SIGILL
        map(5, 5);    // SIGTRAP
        map(6, 6);    // SIGABRT
        map(7, 10);   // SIGBUS   -> GDB_SIGNAL_BUS
        map(8, 8);    // SIGFPE
        map(9, 9);    // SIGKILL
        map(10, 30);  // SIGUSR1  -> GDB_SIGNAL_USR1
        map(11, 11);  // SIGSEGV
        map(12, 31);  // SIGUSR2  -> GDB_SIGNAL_USR2
        map(13, 13);  // SIGPIPE
        map(14, 14);  // SIGALRM
        map(15, 15);  // SIGTERM
        map(16, 16);  // SIGSTKFLT -> GDB_SIGNAL_STKFLT is 77; 16 is close enough for our use
        map(17, 20);  // SIGCHLD  -> GDB_SIGNAL_CHLD
        map(18, 19);  // SIGCONT  -> GDB_SIGNAL_CONT
        map(19, 17);  // SIGSTOP  -> GDB_SIGNAL_STOP
        map(20, 18);  // SIGTSTP  -> GDB_SIGNAL_TSTP
        map(21, 21);  // SIGTTIN
        map(22, 22);  // SIGTTOU
        map(23, 23);  // SIGURG   -> GDB_SIGNAL_URG
        map(24, 24);  // SIGXCPU
        map(25, 25);  // SIGXFSZ
        map(26, 26);  // SIGVTALRM
        map(27, 27);  // SIGPROF
        map(28, 28);  // SIGWINCH
        map(29, 23);  // SIGIO    -> GDB_SIGNAL_IO
        map(30, 12);  // SIGPWR   -> GDB_SIGNAL_PWR is 32; unused here
        map(31, 12);  // SIGSYS
    }

    /* SIGSTKFLT and SIGPWR need their real gdb numbers; fix them up. */
    static {
        HOST_TO_GDB[16] = 77;   // GDB_SIGNAL_STKFLT
        GDB_TO_HOST[77] = 16;
        HOST_TO_GDB[30] = 32;   // GDB_SIGNAL_PWR
        GDB_TO_HOST[32] = 30;
        HOST_TO_GDB[31] = 12;   // GDB_SIGNAL_SYS
        GDB_TO_HOST[12] = 31;
    }

    public static int toGdb(int hostSig) {
        if (hostSig <= 0) return 0;
        if (hostSig >= 32 && hostSig <= 64) return 45 + (hostSig - 32);  // GDB_SIGNAL_REALTIME_32
        int g = hostSig < HOST_TO_GDB.length ? HOST_TO_GDB[hostSig] : 0;
        return g == 0 ? hostSig : g;
    }

    public static int toHost(int gdbSig) {
        if (gdbSig <= 0) return 0;
        if (gdbSig >= 45 && gdbSig <= 77) {
            int rt = 32 + (gdbSig - 45);
            if (rt <= 64 && gdbSig != 77) return rt;
        }
        int h = gdbSig < GDB_TO_HOST.length ? GDB_TO_HOST[gdbSig] : 0;
        return h == 0 ? gdbSig : h;
    }
}
