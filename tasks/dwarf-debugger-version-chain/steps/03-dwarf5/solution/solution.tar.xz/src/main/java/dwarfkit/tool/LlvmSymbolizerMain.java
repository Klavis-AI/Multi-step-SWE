package dwarfkit.tool;

import dwarfkit.elf.Elf;
import dwarfkit.sym.Symbolizer;
import dwarfkit.dw.LineTable;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * llvm-symbolizer(1) command line and stdin protocol.
 * See llvm.org/docs/CommandGuide/llvm-symbolizer.html.
 */
public final class LlvmSymbolizerMain {

    static final int FN_NONE = 0, FN_SHORT = 1, FN_LINKAGE = 2;
    static final int ST_LLVM = 0, ST_GNU = 1, ST_JSON = 2;

    String obj;
    int functions = FN_LINKAGE;
    int style = ST_LLVM;
    boolean inlines = true;
    boolean demangle = true;
    boolean printAddress = false;
    boolean pretty = false;
    int pathStyle = LineTable.ABSOLUTE;
    long adjustVma = 0;

    final Map<String, Symbolizer> cache = new HashMap<>();
    final PrintStream out = new PrintStream(new java.io.BufferedOutputStream(System.out, 1 << 16));
    boolean argvMode = false;
    final List<String> jsonBatch = new ArrayList<>();

    public static void main(String[] args) {
        LlvmSymbolizerMain m = new LlvmSymbolizerMain();
        int rc = m.run(args);
        m.out.flush();
        System.exit(rc);
    }

    int run(String[] args) {
        List<String> positional = new ArrayList<>();
        for (int ai = 0; ai < args.length; ai++) {
            String a = args[ai];
            if ((a.equals("-e") || a.equals("--obj") || a.equals("--exe")) && ai + 1 < args.length) {
                obj = args[++ai];
                continue;
            }
            if (a.startsWith("--obj=") || a.startsWith("-obj=")) obj = after(a);
            else if (a.startsWith("--exe=") || a.startsWith("-exe=") || a.startsWith("-e=")) obj = after(a);
            else if (a.startsWith("--functions=") || a.startsWith("-functions=") || a.startsWith("-f=")) {
                String v = after(a);
                functions = v.equals("none") ? FN_NONE : v.equals("short") ? FN_SHORT : FN_LINKAGE;
            } else if (a.startsWith("--output-style=")) {
                String v = after(a);
                style = v.equalsIgnoreCase("GNU") ? ST_GNU : v.equalsIgnoreCase("JSON") ? ST_JSON : ST_LLVM;
            } else if (a.equals("--inlines") || a.equals("-i") || a.equals("--inlining")) inlines = true;
            else if (a.equals("--no-inlines")) inlines = false;
            else if (a.equals("--demangle") || a.equals("-C")) demangle = true;
            else if (a.equals("--no-demangle")) demangle = false;
            else if (a.equals("--basenames") || a.equals("-s")) pathStyle = LineTable.BASENAME;
            else if (a.equals("--relativenames")) pathStyle = LineTable.RELATIVE;
            else if (a.equals("--print-address") || a.equals("--addresses") || a.equals("-a")) printAddress = true;
            else if (a.equals("--pretty-print") || a.equals("-p")) pretty = true;
            else if (a.startsWith("--adjust-vma=")) adjustVma = parseAddr(after(a));
            else if (a.startsWith("-")) { /* ignore unknown options, as llvm does for many */ }
            else positional.add(a);
        }
        if (!positional.isEmpty()) {
            argvMode = true;
            for (String p : positional) handleLine(p);
            if (style == ST_JSON) out.println("[" + String.join(",", jsonBatch) + "]");
            return 0;
        }
        try (BufferedReader r = new BufferedReader(new InputStreamReader(System.in))) {
            String line;
            while ((line = r.readLine()) != null) handleLine(line);
        } catch (Exception e) {
            return 1;
        }
        return 0;
    }

    static String after(String a) { return a.substring(a.indexOf('=') + 1); }

    static long parseAddr(String s) {
        s = s.trim();
        try {
            if (s.startsWith("0x") || s.startsWith("0X")) return Long.parseUnsignedLong(s.substring(2), 16);
            return Long.parseUnsignedLong(s);
        } catch (NumberFormatException e) {
            try {
                return Long.parseUnsignedLong(s, 16);
            } catch (NumberFormatException e2) {
                return -1;
            }
        }
    }

    void handleLine(String line) {
        line = line.trim();
        if (line.isEmpty()) return;
        String cmd = "CODE";
        for (String c : new String[]{"CODE", "DATA", "FRAME"}) {
            if (line.startsWith(c + " ") || line.equals(c)) {
                cmd = c;
                line = line.substring(Math.min(c.length() + 1, line.length())).trim();
                break;
            }
        }
        String file = obj;
        String addrTok = line;
        int sp = lastSpaceOutsideQuotes(line);
        if (sp > 0) {
            file = unquote(line.substring(0, sp).trim());
            addrTok = line.substring(sp + 1).trim();
        }
        long addr = parseAddr(addrTok);
        if (file == null) {
            System.err.println("dwarfkit: '" + addrTok + "': no module offset has been specified");
            emitUnknown(cmd, addr, "");
            return;
        }
        Symbolizer s = load(file);
        if (s == null) {
            if (style == ST_JSON) {
                out.println("{\"Address\":\"0x" + Long.toHexString(addr) + "\",\"Error\":{\"Message\":"
                        + "\"No such file or directory\"},\"ModuleName\":\"" + file + "\"}");
            } else {
                System.err.println("dwarfkit: '" + file + "': No such file or directory");
                emitUnknown(cmd, addr, file);
            }
            return;
        }
        long target = addr - adjustVma;
        if (cmd.equals("FRAME")) {
            java.util.List<Symbolizer.Var> vars = s.frame(target, pathStyle);
            if (vars == null) {
                out.println("??");
                out.println();
                return;
            }
            for (Symbolizer.Var v : vars) {
                out.println(v.function == null ? "??" : v.function);
                out.println(v.name);
                out.println((v.file == null ? "??" : v.file) + ":" + v.line);
                out.println(v.offset + " " + v.size + " " + v.tagOffset);
            }
            out.println();
        } else if (cmd.equals("DATA")) {
            emitData(s, addr, s.data(target, pathStyle), file);
        } else {
            emitCode(s, addr, s.code(target, inlines, functions, demangle, pathStyle), file);
        }
    }

    static int lastSpaceOutsideQuotes(String s) {
        return s.lastIndexOf(' ');
    }

    static String unquote(String s) {
        if (s.length() >= 2 && s.charAt(0) == '"' && s.charAt(s.length() - 1) == '"') {
            return s.substring(1, s.length() - 1);
        }
        return s;
    }

    Symbolizer load(String path) {
        if (cache.containsKey(path)) return cache.get(path);
        Symbolizer s = null;
        try {
            s = new Symbolizer(path, Elf.open(path));
        } catch (Exception e) {
            s = null;
        }
        cache.put(path, s);
        return s;
    }

    void emitUnknown(String cmd, long addr, String file) {
        if (cmd.equals("DATA")) {
            out.println("??");
            out.println("0 0");
            out.println("??:?");
            out.println();
        } else if (style == ST_GNU) {
            out.println("??");
            out.println("??:0");
        } else if (style == ST_JSON) {
            out.println("{\"Address\":\"0x" + Long.toHexString(addr) + "\",\"ModuleName\":\"" + file
                    + "\",\"Symbol\":[{\"Column\":0,\"Discriminator\":0,\"FileName\":\"\","
                    + "\"FunctionName\":\"\",\"Line\":0,\"StartAddress\":\"\",\"StartFileName\":\"\","
                    + "\"StartLine\":0}]}");
        } else {
            out.println("??");
            out.println("??:0:0");
            out.println();
        }
    }

    void emitCode(Symbolizer s, long addr, List<Symbolizer.Frame> frames, String file) {
        if (style == ST_JSON) {
            StringBuilder sb = new StringBuilder();
            sb.append("{\"Address\":\"0x").append(Long.toHexString(addr)).append("\",\"ModuleName\":\"")
              .append(file).append("\",\"Symbol\":[");
            for (int i = 0; i < frames.size(); i++) {
                Symbolizer.Frame f = frames.get(i);
                if (i > 0) sb.append(',');
                sb.append("{\"Column\":").append(f.column)
                  .append(",\"Discriminator\":").append(f.discriminator)
                  .append(",\"FileName\":\"").append(js(f.file == null ? "" : f.file))
                  .append("\",\"FunctionName\":\"").append(js(f.function == null ? "" : f.function))
                  .append("\",\"Line\":").append(f.line)
                  .append(",\"StartAddress\":\"").append(f.startAddress < 0 ? "" : "0x" + Long.toHexString(f.startAddress))
                  .append("\",\"StartFileName\":\"").append(js(f.startFile == null ? "" : f.startFile))
                  .append("\",\"StartLine\":").append(f.startLine).append('}');
            }
            sb.append("]}");
            if (argvMode) jsonBatch.add(sb.toString()); else out.println(sb);
            return;
        }
        if (printAddress && !pretty) out.println("0x" + Long.toHexString(addr));
        for (int i = 0; i < frames.size(); i++) {
            Symbolizer.Frame f = frames.get(i);
            String name = f.function == null ? "??" : f.function;
            String loc = location(f);
            if (pretty) {
                String head = (printAddress && i == 0) ? "0x" + Long.toHexString(addr) + ": " : "";
                if (i == 0) {
                    out.println(head + (functions == FN_NONE ? loc : name + " at " + loc));
                } else {
                    out.println(" (inlined by) " + (functions == FN_NONE ? loc : name + " at " + loc));
                }
            } else {
                if (functions != FN_NONE) out.println(name);
                out.println(loc);
            }
        }
        if (style == ST_LLVM && !pretty) out.println();
        if (style == ST_LLVM && pretty) out.println();
    }

    String location(Symbolizer.Frame f) {
        if (f.file == null) return style == ST_GNU ? "??:0" : "??:0:0";
        if (style == ST_GNU) {
            String base = f.file + ":" + f.line;
            if (f.discriminator != 0) base += " (discriminator " + f.discriminator + ")";
            return base;
        }
        return f.file + ":" + f.line + ":" + f.column;
    }

    void emitData(Symbolizer s, long addr, Symbolizer.DataInfo d, String file) {
        if (d == null || d.name == null) {
            out.println("??");
            out.println("0 0");
            out.println("??:?");
            out.println();
            return;
        }
        out.println(d.name);
        out.println(Long.toUnsignedString(d.start) + " " + Long.toUnsignedString(d.size));
        out.println(d.file == null ? "??:?" : d.file + ":" + d.line);
        out.println();
    }

    static String js(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
