package dwarfkit.rsp;

/**
 * The target description served over qXfer:features:read:target.xml.
 *
 * Register order in this document defines the 'g' packet layout, because gdb
 * numbers registers sequentially in document order when no regnum is given.
 * The result is the classic amd64 layout: 0-15 general, 16 rip, 17 eflags,
 * 18-23 segments, 24-31 x87, 32-39 x87 control, 40-55 xmm, 56 mxcsr,
 * 57 orig_rax, 58-59 fs_base/gs_base -- 560 bytes in total.
 *
 * Only built-in gdb types are used (int64, code_ptr, data_ptr, i387_ext,
 * uint128, int32), so no flags or union definitions are needed.
 */
public final class TargetXml {
    private TargetXml() {}

    public static final String XML = build();

    private static String build() {
        StringBuilder b = new StringBuilder(4096);
        b.append("<?xml version=\"1.0\"?>\n");
        b.append("<!DOCTYPE target SYSTEM \"gdb-target.dtd\">\n");
        b.append("<target>\n");
        b.append("  <architecture>i386:x86-64</architecture>\n");
        b.append("  <osabi>GNU/Linux</osabi>\n");

        b.append("  <feature name=\"org.gnu.gdb.i386.core\">\n");
        for (String r : new String[]{"rax", "rbx", "rcx", "rdx", "rsi", "rdi"}) {
            reg(b, r, 64, "int64");
        }
        reg(b, "rbp", 64, "data_ptr");
        reg(b, "rsp", 64, "data_ptr");
        for (int i = 8; i <= 15; i++) reg(b, "r" + i, 64, "int64");
        reg(b, "rip", 64, "code_ptr");
        reg(b, "eflags", 32, "int32");
        for (String s : new String[]{"cs", "ss", "ds", "es", "fs", "gs"}) reg(b, s, 32, "int32");
        for (int i = 0; i < 8; i++) reg(b, "st" + i, 80, "i387_ext");
        for (String s : new String[]{"fctrl", "fstat", "ftag", "fiseg", "fioff",
                "foseg", "fooff", "fop"}) {
            reg(b, s, 32, "int32");
        }
        b.append("  </feature>\n");

        b.append("  <feature name=\"org.gnu.gdb.i386.sse\">\n");
        for (int i = 0; i < 16; i++) reg(b, "xmm" + i, 128, "uint128");
        reg(b, "mxcsr", 32, "int32");
        b.append("  </feature>\n");

        b.append("  <feature name=\"org.gnu.gdb.i386.linux\">\n");
        reg(b, "orig_rax", 64, "int64");
        b.append("  </feature>\n");

        b.append("  <feature name=\"org.gnu.gdb.i386.segments\">\n");
        reg(b, "fs_base", 64, "int64");
        reg(b, "gs_base", 64, "int64");
        b.append("  </feature>\n");

        b.append("</target>\n");
        return b.toString();
    }

    private static void reg(StringBuilder b, String name, int bits, String type) {
        b.append("    <reg name=\"").append(name).append("\" bitsize=\"").append(bits)
                .append("\" type=\"").append(type).append("\"/>\n");
    }
}
