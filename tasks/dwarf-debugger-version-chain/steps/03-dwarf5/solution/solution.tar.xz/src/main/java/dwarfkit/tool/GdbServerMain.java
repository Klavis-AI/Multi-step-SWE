package dwarfkit.tool;

import dwarfkit.dbg.Inferior;
import dwarfkit.rsp.RspServer;

import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

/**
 * A gdbserver(1) work-alike: GdbServerMain HOST:PORT PROGRAM [ARGS...].
 *
 * The whole server -- the fork, every ptrace request, waitpid and the packet
 * loop -- runs on one platform thread, because a tracee may only be controlled
 * from the thread that attached to it; a request from any other thread fails
 * with ESRCH.  A single-threaded executor owns that thread and the task never
 * hands work back to another.
 */
public final class GdbServerMain {

    public static void main(String[] args) throws Exception {
        if (args.length < 2) {
            System.err.println("Usage: GdbServerMain HOST:PORT PROGRAM [ARGS...]");
            System.exit(1);
        }
        final String hostPort = args[0];
        final String program = args[1];
        final String[] rest = Arrays.copyOfRange(args, 2, args.length);

        ThreadFactory tf = r -> {
            Thread t = new Thread(null, r, "dwarfkit-gdbserver", 8L * 1024 * 1024);
            t.setDaemon(false);
            return t;
        };
        ExecutorService pinned = Executors.newSingleThreadExecutor(tf);
        try {
            pinned.submit(() -> run(hostPort, program, rest)).get();
        } finally {
            pinned.shutdownNow();
        }
    }

    private static Void run(String hostPort, String program, String[] rest) {
        ServerSocket server = null;
        Inferior inf = null;
        try {
            int colon = hostPort.lastIndexOf(':');
            String host = colon < 0 ? "127.0.0.1" : hostPort.substring(0, colon);
            int port = Integer.parseInt(hostPort.substring(colon + 1));
            if (host.isEmpty()) host = "0.0.0.0";

            inf = Inferior.launch(program, rest);
            System.out.println("Process " + program + " created; pid = " + inf.pid);

            server = new ServerSocket();
            server.setReuseAddress(true);
            server.bind(new InetSocketAddress(host, port), 1);
            System.out.println("Listening on port " + port);
            System.out.flush();

            try (Socket sock = server.accept()) {
                sock.setTcpNoDelay(true);
                new RspServer(inf, sock).serve();
            }
        } catch (Exception e) {
            System.err.println("gdbserver: " + e);
            e.printStackTrace();
        } finally {
            if (inf != null && !inf.exited) inf.kill();
            if (server != null) {
                try {
                    server.close();
                } catch (Exception ignore) {
                    // shutting down
                }
            }
        }
        return null;
    }
}
