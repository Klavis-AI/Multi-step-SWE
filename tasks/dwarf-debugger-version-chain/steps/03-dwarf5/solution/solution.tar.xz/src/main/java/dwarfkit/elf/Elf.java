package dwarfkit.elf;

import dwarfkit.util.Buf;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

/** ELF32/ELF64 reader: sections (SHF_COMPRESSED aware), symbols, segments, notes. */
public final class Elf {
    public static final int ET_EXEC = 2, ET_DYN = 3, ET_CORE = 4;
    public static final int EM_X86_64 = 62, EM_AARCH64 = 183, EM_386 = 3;
    public static final int SHF_COMPRESSED = 0x800;
    public static final int PT_LOAD = 1, PT_NOTE = 4;
    public static final int ELFCOMPRESS_ZLIB = 1, ELFCOMPRESS_ZSTD = 2;

    public static final class Section {
        public String name;
        public int type, link, info, nameOff;
        public long flags, addr, offset, size, entsize, addralign;
        public byte[] data;          // decompressed on demand
        public boolean compressed;
    }

    public static final class Sym {
        public String name;
        public String file;          // STT_FILE this local symbol belongs to
        public int index;            // position in the symbol table
        public long value, size;
        public int info, other, shndx;
        public int type() { return info & 0xf; }
        public int bind() { return info >> 4; }
    }

    public static final class Phdr {
        public int type, flags;
        public long offset, vaddr, paddr, filesz, memsz, align;
    }

    public static final class Note {
        public String owner;
        public int type;
        public byte[] desc;
    }

    public final byte[] image;
    public final boolean little;
    public final boolean is64;
    public final int etype, machine;
    public final long entry;
    public final List<Section> sections = new ArrayList<>();
    public final List<Phdr> phdrs = new ArrayList<>();
    private final Map<String, Section> byName = new HashMap<>();
    private List<Sym> symtab;
    public final String path;

    public static Elf open(String path) throws IOException {
        return new Elf(path, Files.readAllBytes(Path.of(path)));
    }

    public Elf(String path, byte[] image) {
        this.path = path;
        this.image = image;
        if (image.length < 64 || image[0] != 0x7f || image[1] != 'E' || image[2] != 'L'
                || image[3] != 'F') {
            throw new IllegalArgumentException("not an ELF file: " + path);
        }
        is64 = image[4] == 2;
        little = image[5] == 1;
        Buf b = new Buf(image);
        b.little = little;
        b.seek(16);
        etype = b.u16();
        machine = b.u16();
        b.u32();                                   // e_version
        entry = is64 ? b.u64() : b.u32();
        long phoff = is64 ? b.u64() : b.u32();
        long shoff = is64 ? b.u64() : b.u32();
        b.u32();                                   // e_flags
        b.u16();                                   // e_ehsize
        int phentsize = b.u16();
        int phnum = b.u16();
        int shentsize = b.u16();
        int shnum = b.u16();
        int shstrndx = b.u16();

        for (int i = 0; i < phnum; i++) {
            b.seek((int) (phoff + (long) i * phentsize));
            Phdr p = new Phdr();
            p.type = (int) b.u32();
            if (is64) {
                p.flags = (int) b.u32();
                p.offset = b.u64();
                p.vaddr = b.u64();
                p.paddr = b.u64();
                p.filesz = b.u64();
                p.memsz = b.u64();
                p.align = b.u64();
            } else {
                p.offset = b.u32();
                p.vaddr = b.u32();
                p.paddr = b.u32();
                p.filesz = b.u32();
                p.memsz = b.u32();
                p.flags = (int) b.u32();
                p.align = b.u32();
            }
            phdrs.add(p);
        }
        for (int i = 0; i < shnum; i++) {
            b.seek((int) (shoff + (long) i * shentsize));
            Section s = new Section();
            s.nameOff = (int) b.u32();
            s.type = (int) b.u32();
            s.flags = is64 ? b.u64() : b.u32();
            s.addr = is64 ? b.u64() : b.u32();
            s.offset = is64 ? b.u64() : b.u32();
            s.size = is64 ? b.u64() : b.u32();
            s.link = (int) b.u32();
            s.info = (int) b.u32();
            s.addralign = is64 ? b.u64() : b.u32();
            s.entsize = is64 ? b.u64() : b.u32();
            sections.add(s);
        }
        if (shstrndx < sections.size()) {
            Section shstr = sections.get(shstrndx);
            byte[] raw = rawBytes(shstr);
            for (Section s : sections) s.name = Buf.cstrAt(raw, s.nameOff);
        }
        for (Section s : sections) {
            if (s.name != null) byName.putIfAbsent(s.name, s);
        }
    }

    private byte[] rawBytes(Section s) {
        if (s.type == 8 /* SHT_NOBITS */) return new byte[0];
        int off = (int) s.offset;
        int len = (int) Math.min(s.size, image.length - off);
        byte[] out = new byte[Math.max(len, 0)];
        System.arraycopy(image, off, out, 0, out.length);
        return out;
    }

    /** Section contents, transparently decompressing SHF_COMPRESSED sections. */
    public byte[] data(Section s) {
        if (s.data != null) return s.data;
        byte[] raw = rawBytes(s);
        if ((s.flags & SHF_COMPRESSED) != 0 && raw.length > 12) {
            Buf b = new Buf(raw);
            b.little = little;
            int ch_type = (int) b.u32();
            long ch_size;
            if (is64) {
                b.u32();                 // ch_reserved
                ch_size = b.u64();
                b.u64();                 // ch_addralign
            } else {
                ch_size = b.u32();
                b.u32();
            }
            int hdr = is64 ? 24 : 12;
            if (ch_type == ELFCOMPRESS_ZLIB) {
                raw = inflate(raw, hdr, (int) ch_size);
            }
            s.compressed = true;
        } else if (s.name != null && s.name.startsWith(".zdebug") && raw.length > 12
                && raw[0] == 'Z' && raw[1] == 'L' && raw[2] == 'I' && raw[3] == 'B') {
            long sz = 0;
            for (int i = 4; i < 12; i++) sz = (sz << 8) | (raw[i] & 0xff);
            raw = inflate(raw, 12, (int) sz);
            s.compressed = true;
        }
        s.data = raw;
        return raw;
    }

    private static byte[] inflate(byte[] in, int off, int outLen) {
        Inflater inf = new Inflater();
        inf.setInput(in, off, in.length - off);
        byte[] out = new byte[Math.max(outLen, 0)];
        try {
            int n = 0;
            while (n < out.length && !inf.finished()) {
                int k = inf.inflate(out, n, out.length - n);
                if (k == 0) break;
                n += k;
            }
        } catch (DataFormatException e) {
            return new byte[0];
        } finally {
            inf.end();
        }
        return out;
    }

    public Section section(String name) { return byName.get(name); }

    public byte[] sectionData(String name) {
        Section s = byName.get(name);
        return s == null ? null : data(s);
    }

    public Buf sectionBuf(String name) {
        byte[] d = sectionData(name);
        if (d == null) return null;
        Buf b = new Buf(d);
        b.little = little;
        return b;
    }

    /** .symtab if present, else .dynsym; sorted by address. */
    public List<Sym> symbols() {
        if (symtab != null) return symtab;
        List<Sym> out = new ArrayList<>();
        for (String n : new String[]{".symtab", ".dynsym"}) {
            Section s = byName.get(n);
            if (s == null) continue;
            Section strs = (s.link >= 0 && s.link < sections.size()) ? sections.get(s.link) : null;
            byte[] str = strs == null ? new byte[0] : data(strs);
            byte[] d = data(s);
            Buf b = new Buf(d);
            b.little = little;
            int ent = (int) (s.entsize != 0 ? s.entsize : (is64 ? 24 : 16));
            String curFile = null;
            for (int off = 0; off + ent <= d.length; off += ent) {
                b.seek(off);
                Sym sym = new Sym();
                int nameOff = (int) b.u32();
                if (is64) {
                    sym.info = b.u8();
                    sym.other = b.u8();
                    sym.shndx = b.u16();
                    sym.value = b.u64();
                    sym.size = b.u64();
                } else {
                    sym.value = b.u32();
                    sym.size = b.u32();
                    sym.info = b.u8();
                    sym.other = b.u8();
                    sym.shndx = b.u16();
                }
                sym.name = Buf.cstrAt(str, nameOff);
                sym.index = off / ent;
                if (sym.type() == 4 /* STT_FILE */) {
                    curFile = sym.name;
                } else if (sym.bind() == 0 /* STB_LOCAL */) {
                    sym.file = curFile;
                }
                if (sym.name != null && !sym.name.isEmpty()) out.add(sym);
            }
            if (!out.isEmpty()) break;
        }
        out.sort((x, y) -> Long.compareUnsigned(x.value, y.value));
        symtab = out;
        return out;
    }

    public List<Note> notes() {
        List<Note> out = new ArrayList<>();
        for (Phdr p : phdrs) {
            if (p.type != PT_NOTE) continue;
            Buf b = new Buf(image, (int) p.offset, (int) p.filesz);
            b.little = little;
            while (b.remaining() > 12) {
                int nsz = (int) b.u32();
                int dsz = (int) b.u32();
                int typ = (int) b.u32();
                if (nsz < 0 || dsz < 0 || nsz > b.remaining()) break;
                byte[] nm = b.bytes(nsz);
                b.skip((4 - (nsz & 3)) & 3);
                if (dsz > b.remaining()) break;
                Note n = new Note();
                int end = nsz;
                while (end > 0 && nm[end - 1] == 0) end--;
                n.owner = new String(nm, 0, end, java.nio.charset.StandardCharsets.UTF_8);
                n.type = typ;
                n.desc = b.bytes(dsz);
                b.skip((4 - (dsz & 3)) & 3);
                out.add(n);
            }
        }
        return out;
    }

    public boolean isCore() { return etype == ET_CORE; }
}
