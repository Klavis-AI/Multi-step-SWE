package dwarfkit.tool;

import dwarfkit.core.CoreFile;
import dwarfkit.dw.Cfi;
import dwarfkit.dw.LineTable;
import dwarfkit.elf.Elf;
import dwarfkit.sym.Symbolizer;
import dwarfkit.util.Buf;

import java.io.PrintStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * eu-stack(1): print the stack of every thread in a core file.
 *
 * Frame 0 is unwound at its own pc; every return address is looked up at pc-1,
 * which is the instruction that made the call.
 */
public final class EuStackMain {

    String corePath, exePath;
    int maxFrames = 256;
    boolean source = false, oneThread = false, quiet = false;

    public static void main(String[] args) {
        EuStackMain m = new EuStackMain();
        System.exit(m.run(args));
    }

    int run(String[] args) {
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.startsWith("--core=")) corePath = a.substring(7);
            else if (a.equals("--core")) corePath = args[++i];
            else if (a.startsWith("--executable=")) exePath = a.substring(13);
            else if (a.equals("-e") || a.equals("--executable")) exePath = args[++i];
            else if (a.equals("-n")) maxFrames = Integer.parseInt(args[++i]);
            else if (a.startsWith("-n")) maxFrames = Integer.parseInt(a.substring(2));
            else if (a.equals("-s") || a.equals("--source")) source = true;
            else if (a.equals("-1")) oneThread = true;
            else if (a.equals("-q") || a.equals("--quiet")) quiet = true;
        }
        if (corePath == null) {
            System.err.println("dwarfkit: no core file given");
            return 64;
        }
        PrintStream out = new PrintStream(new java.io.BufferedOutputStream(System.out, 1 << 16));
        int rc = 0;
        try {
            Elf coreElf = Elf.open(corePath);
            CoreFile core = new CoreFile(coreElf);
            Elf exe = exePath == null ? null : Elf.open(exePath);
            Symbolizer sym = exe == null ? null : new Symbolizer(exePath, exe);
            Cfi cfi = exe == null ? null : Cfi.of(exe);
            out.println("PID " + core.pid + " - core");
            for (CoreFile.Thread t : core.threads) {
                out.println("TID " + t.tid + ":");
                rc |= walk(out, core, sym, cfi, t);
                if (oneThread) break;
            }
        } catch (Exception e) {
            System.err.println("dwarfkit: " + e);
            return 2;
        } finally {
            out.flush();
        }
        return rc;
    }

    private int walk(PrintStream out, CoreFile core, Symbolizer sym, Cfi cfi, CoreFile.Thread t) {
        Map<Integer, Long> regs = new HashMap<>(t.regs);
        long pc = t.pc;
        int addrSize = core.core.is64 ? 8 : 4;
        int n = 0;
        int rc = 0;
        while (n < maxFrames) {
            long lookup = (n == 0) ? pc : pc - 1;
            printFrame(out, sym, n, pc, lookup);
            n++;
            if (cfi == null) break;
            Cfi.Row row = cfi.rowAt(lookup);
            if (row == null) { rc = 1; break; }
            Long cfa = computeCfa(row, regs, core);
            if (cfa == null) { rc = 1; break; }
            int ra = row.returnAddressColumn();
            Long next = applyRule(row, ra, cfa, regs, core, addrSize);
            if (next == null || next == 0) break;
            Map<Integer, Long> caller = new HashMap<>(regs);
            for (int r = 0; r < row.columns(); r++) {
                if (row.ruleKind(r) == Cfi.RULE_UNREFERENCED) continue;
                Long v = applyRule(row, r, cfa, regs, core, addrSize);
                if (v != null) caller.put(r, v);
            }
            caller.put(spRegister(core), cfa);
            caller.put(ra, next);
            if (Long.compareUnsigned(cfa, regs.getOrDefault(spRegister(core), 0L)) <= 0) break;
            regs = caller;
            pc = next;
        }
        return rc;
    }

    private int spRegister(CoreFile core) {
        return core.core.machine == Elf.EM_AARCH64 ? 31 : 7;
    }

    private Long computeCfa(Cfi.Row row, Map<Integer, Long> regs, CoreFile core) {
        if (row.cfaExpression) {
            return null;                       // no expression CFA in these fixtures
        }
        Long base = regs.get(row.cfaRegister);
        if (base == null) return null;
        return base + row.cfaOffset;
    }

    private Long applyRule(Cfi.Row row, int reg, long cfa, Map<Integer, Long> regs,
                           CoreFile core, int addrSize) {
        switch (row.ruleKind(reg)) {
            case Cfi.RULE_OFFSET:
                return core.readWord(cfa + row.ruleValue(reg), addrSize);
            case Cfi.RULE_VAL_OFFSET:
                return cfa + row.ruleValue(reg);
            case Cfi.RULE_REGISTER:
                return regs.get((int) row.ruleValue(reg));
            case Cfi.RULE_SAME_VALUE:
                return regs.get(reg);
            case Cfi.RULE_UNDEFINED:
                return null;
            default:
                return null;
        }
    }

    private void printFrame(PrintStream out, Symbolizer sym, int n, long pc, long lookup) {
        String name = null;
        if (sym != null && !quiet) name = sym.symbolNameEarliest(lookup, true);
        StringBuilder sb = new StringBuilder();
        sb.append('#').append(n);
        while (sb.length() < 4) sb.append(' ');
        sb.append("0x").append(String.format("%016x", pc));
        if (name != null) sb.append(' ').append(name);
        out.println(sb);
        if (source && sym != null) {
            List<Symbolizer.Frame> fr = sym.code(lookup, false, 1, false, LineTable.RELATIVE);
            if (!fr.isEmpty() && fr.get(0).file != null) {
                Symbolizer.Frame f = fr.get(0);
                out.println("    " + f.file + ":" + f.line + ":" + f.column);
            }
        }
    }
}
