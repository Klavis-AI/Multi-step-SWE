package dwarfkit.dbg;

import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.Linker;
import java.lang.foreign.MemoryLayout;
import java.lang.foreign.MemorySegment;
import java.lang.foreign.StructLayout;
import java.lang.foreign.SymbolLookup;
import java.lang.foreign.ValueLayout;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.VarHandle;

/**
 * The platform C library, reached through the FFM API and nothing else.
 *
 * Only {@link SymbolLookup#defaultLookup()} is used, so no library is ever
 * dlopen'd; ptrace(2) is variadic in glibc and is bound with
 * {@link Linker.Option#firstVariadicArg} plus an errno capture, because a
 * successful PTRACE_PEEK* legitimately returns -1.
 */
public final class Native {
    private Native() {}

    private static final Linker LINKER = Linker.nativeLinker();
    private static final SymbolLookup LIB = LINKER.defaultLookup();

    /* ---- ptrace requests (sys/ptrace.h) ---- */
    public static final int TRACEME = 0, PEEKDATA = 2, POKEDATA = 5, CONT = 7,
            KILL = 8, SINGLESTEP = 9, GETREGS = 12, SETREGS = 13, GETFPREGS = 14,
            ATTACH = 16, DETACH = 17, SETOPTIONS = 0x4200, GETEVENTMSG = 0x4201,
            LISTEN = 0x4208, INTERRUPT = 0x4207, SEIZE = 0x4206;

    /* ptrace options */
    public static final int O_TRACECLONE = 0x00000008, O_TRACEEXIT = 0x00000040,
            O_EXITKILL = 0x00100000, O_TRACESYSGOOD = 0x00000001;

    /* ptrace events, delivered as status >> 16 */
    public static final int EVENT_CLONE = 3, EVENT_EXIT = 6;

    /* waitpid flags */
    public static final int WNOHANG = 1, WUNTRACED = 2, __WALL = 0x40000000;

    public static final long ADDR_NO_RANDOMIZE = 0x0040000L;

    /** Layout of the errno capture buffer used by the checked calls. */
    public static final StructLayout CAPTURE = Linker.Option.captureStateLayout();
    private static final VarHandle ERRNO =
            CAPTURE.varHandle(MemoryLayout.PathElement.groupElement("errno"));

    private static MethodHandle dc(String name, FunctionDescriptor fd, Linker.Option... opts) {
        return LINKER.downcallHandle(LIB.find(name).orElseThrow(
                () -> new UnsatisfiedLinkError("no symbol " + name)), fd, opts);
    }

    /* long ptrace(enum request, pid_t, void *, void *) -- variadic after arg 0. */
    private static final MethodHandle PTRACE = dc("ptrace",
            FunctionDescriptor.of(ValueLayout.JAVA_LONG, ValueLayout.JAVA_INT,
                    ValueLayout.JAVA_INT, ValueLayout.JAVA_LONG, ValueLayout.JAVA_LONG),
            Linker.Option.firstVariadicArg(1), Linker.Option.captureCallState("errno"));

    /* The same call without the capture buffer, for the post-fork child path. */
    private static final MethodHandle PTRACE_RAW = dc("ptrace",
            FunctionDescriptor.of(ValueLayout.JAVA_LONG, ValueLayout.JAVA_INT,
                    ValueLayout.JAVA_INT, ValueLayout.JAVA_LONG, ValueLayout.JAVA_LONG),
            Linker.Option.firstVariadicArg(1));

    private static final MethodHandle FORK =
            dc("fork", FunctionDescriptor.of(ValueLayout.JAVA_INT));
    private static final MethodHandle EXECVP = dc("execvp",
            FunctionDescriptor.of(ValueLayout.JAVA_INT, ValueLayout.ADDRESS, ValueLayout.ADDRESS));
    private static final MethodHandle WAITPID = dc("waitpid",
            FunctionDescriptor.of(ValueLayout.JAVA_INT, ValueLayout.JAVA_INT,
                    ValueLayout.ADDRESS, ValueLayout.JAVA_INT),
            Linker.Option.captureCallState("errno"));
    private static final MethodHandle KILLFN = dc("kill",
            FunctionDescriptor.of(ValueLayout.JAVA_INT, ValueLayout.JAVA_INT, ValueLayout.JAVA_INT));
    private static final MethodHandle TGKILL = dc("syscall",
            FunctionDescriptor.of(ValueLayout.JAVA_LONG, ValueLayout.JAVA_LONG,
                    ValueLayout.JAVA_LONG, ValueLayout.JAVA_LONG, ValueLayout.JAVA_LONG),
            Linker.Option.firstVariadicArg(1));
    private static final MethodHandle PERSONALITY = dc("personality",
            FunctionDescriptor.of(ValueLayout.JAVA_INT, ValueLayout.JAVA_LONG));
    private static final MethodHandle EXIT_RAW =
            dc("_exit", FunctionDescriptor.ofVoid(ValueLayout.JAVA_INT));

    /** errno as left by the last call made with {@code cap}. */
    public static int errno(MemorySegment cap) { return (int) ERRNO.get(cap, 0L); }

    public static long ptrace(MemorySegment cap, int req, int pid, long addr, long data) {
        try {
            return (long) PTRACE.invokeExact(cap, req, pid, addr, data);
        } catch (Throwable t) {
            throw new RuntimeException("ptrace", t);
        }
    }

    /** ptrace with no errno capture; the only form legal in the forked child. */
    public static long ptraceRaw(int req, int pid, long addr, long data) {
        try {
            return (long) PTRACE_RAW.invokeExact(req, pid, addr, data);
        } catch (Throwable t) {
            throw new RuntimeException("ptrace", t);
        }
    }

    public static int fork() {
        try {
            return (int) FORK.invokeExact();
        } catch (Throwable t) {
            throw new RuntimeException("fork", t);
        }
    }

    public static int execvp(MemorySegment path, MemorySegment argv) {
        try {
            return (int) EXECVP.invokeExact(path, argv);
        } catch (Throwable t) {
            throw new RuntimeException("execvp", t);
        }
    }

    public static int waitpid(MemorySegment cap, int pid, MemorySegment status, int options) {
        try {
            return (int) WAITPID.invokeExact(cap, pid, status, options);
        } catch (Throwable t) {
            throw new RuntimeException("waitpid", t);
        }
    }

    public static int kill(int pid, int sig) {
        try {
            return (int) KILLFN.invokeExact(pid, sig);
        } catch (Throwable t) {
            throw new RuntimeException("kill", t);
        }
    }

    /** tgkill(2) via syscall(3); signals one specific thread of a thread group. */
    public static int tgkill(int tgid, int tid, int sig) {
        try {
            return (int) (long) TGKILL.invokeExact(234L, (long) tgid, (long) tid, (long) sig);
        } catch (Throwable t) {
            throw new RuntimeException("tgkill", t);
        }
    }

    public static int personality(long persona) {
        try {
            return (int) PERSONALITY.invokeExact(persona);
        } catch (Throwable t) {
            throw new RuntimeException("personality", t);
        }
    }

    public static void exitRaw(int code) {
        try {
            EXIT_RAW.invokeExact(code);
        } catch (Throwable t) {
            throw new RuntimeException("_exit", t);
        }
    }

    /* ---- wait status decoding (bits/waitstatus.h) ---- */
    public static boolean ifExited(int s) { return (s & 0x7f) == 0; }
    public static int exitStatus(int s) { return (s >> 8) & 0xff; }
    /* glibc casts to signed char BEFORE shifting; without that cast a
       stopped status (low byte 0x7f) is misread as a termination. */
    public static boolean ifSignaled(int s) { return (((byte) ((s & 0x7f) + 1)) >> 1) > 0; }
    public static int termSig(int s) { return s & 0x7f; }
    public static boolean ifStopped(int s) { return (s & 0xff) == 0x7f; }
    public static int stopSig(int s) { return (s >> 8) & 0xff; }
    public static int event(int s) { return (s >> 16) & 0xff; }

    /** A process-lifetime arena; segments handed to the forked child live here. */
    public static final Arena GLOBAL = Arena.global();
}
