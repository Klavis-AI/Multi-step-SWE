package dwarfkit.dw;

import dwarfkit.elf.Elf;

import java.util.ArrayList;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * DWARF call frame information: a parser for {@code .eh_frame} and
 * {@code .debug_frame} plus the unwind-table row computation.
 *
 * <p>The interpreter deliberately mirrors GNU binutils 2.44
 * ({@code binutils/dwarf.c:display_debug_frames}) step for step, including its
 * quirks, so that {@link dwarfkit.tool.ReadelfMain} can reproduce
 * {@code readelf --debug-dump=frames-interp} byte for byte.  Quirks reproduced
 * on purpose:
 * <ul>
 *   <li>{@code get_encoded_value} only applies {@code DW_EH_PE_pcrel}; textrel,
 *       datarel, funcrel, aligned and indirect are read but not relocated, and
 *       the uleb128/sleb128 formats are read as the fixed width that
 *       {@code size_of_encoded_value} reports.</li>
 *   <li>An FDE's {@code cfa_exp} flag is <em>not</em> inherited from its CIE.</li>
 *   <li>{@code DW_CFA_advance_loc} multiplies by the code alignment factor in
 *       32-bit arithmetic, while {@code advance_loc1/2/4} use 64-bit.</li>
 *   <li>Resolving a forward CIE reference clobbers the FDE's own length field,
 *       which is then what gets printed.</li>
 *   <li>The column set of an entry comes from a separate sizing pass over the
 *       instruction stream: a register only gets a column when this entry's own
 *       program mentions it.</li>
 * </ul>
 *
 * <h2>Re-usable unwinding API</h2>
 * The row computation is independent of printing.  Modules that need to unwind a
 * stack should use:
 * <pre>{@code
 *   Cfi cfi = Cfi.of(elf);          // parses every frame section, in section order
 *   Cfi.Row row = cfi.rowAt(pc);    // unwind row in effect at pc, or null
 *   if (row != null) {
 *       long cfa = row.cfaExpression
 *               ? evalExpr(row.cfaExpressionBytes())      // CFA given by an expression
 *               : regs[row.cfaRegister] + row.cfaOffset;  // ... or by reg+offset
 *       for (int r = 0; r < row.columns(); r++) {
 *           switch (row.ruleKind(r)) {
 *               case RULE_OFFSET:         prev[r] = mem(cfa + row.ruleValue(r)); break;
 *               case RULE_VAL_OFFSET:     prev[r] = cfa + row.ruleValue(r);      break;
 *               case RULE_REGISTER:       prev[r] = regs[(int) row.ruleValue(r)]; break;
 *               case RULE_SAME_VALUE:     prev[r] = regs[r];                      break;
 *               case RULE_EXPRESSION:     prev[r] = mem(evalExpr(row.ruleExpression(r))); break;
 *               case RULE_VAL_EXPRESSION: prev[r] = evalExpr(row.ruleExpression(r));      break;
 *               case RULE_UNDEFINED: case RULE_UNREFERENCED: break;  // no rule: not restorable
 *           }
 *       }
 *       long returnAddress = prev[row.returnAddressColumn()];
 *   }
 * }</pre>
 * {@link #rowAt(long)} locates the FDE covering {@code pc} and returns the last
 * row whose address is {@code <=} pc (unsigned), falling back to the FDE's
 * initial row (the state its CIE establishes) when the FDE's program emits none.
 * {@link #fdeFor(long)} exposes the FDE itself and {@link #fdes()} the whole
 * address-sorted table.  Rows are immutable snapshots and may be cached.
 */
public final class Cfi {

    /* ------------------------------------------------------------------ */
    /* DW_CFA opcodes.                                                     */
    /* ------------------------------------------------------------------ */
    public static final int DW_CFA_advance_loc = 0x40;
    public static final int DW_CFA_offset = 0x80;
    public static final int DW_CFA_restore = 0xc0;
    public static final int DW_CFA_nop = 0x00;
    public static final int DW_CFA_set_loc = 0x01;
    public static final int DW_CFA_advance_loc1 = 0x02;
    public static final int DW_CFA_advance_loc2 = 0x03;
    public static final int DW_CFA_advance_loc4 = 0x04;
    public static final int DW_CFA_offset_extended = 0x05;
    public static final int DW_CFA_restore_extended = 0x06;
    public static final int DW_CFA_undefined = 0x07;
    public static final int DW_CFA_same_value = 0x08;
    public static final int DW_CFA_register = 0x09;
    public static final int DW_CFA_remember_state = 0x0a;
    public static final int DW_CFA_restore_state = 0x0b;
    public static final int DW_CFA_def_cfa = 0x0c;
    public static final int DW_CFA_def_cfa_register = 0x0d;
    public static final int DW_CFA_def_cfa_offset = 0x0e;
    public static final int DW_CFA_def_cfa_expression = 0x0f;
    public static final int DW_CFA_expression = 0x10;
    public static final int DW_CFA_offset_extended_sf = 0x11;
    public static final int DW_CFA_def_cfa_sf = 0x12;
    public static final int DW_CFA_def_cfa_offset_sf = 0x13;
    public static final int DW_CFA_val_offset = 0x14;
    public static final int DW_CFA_val_offset_sf = 0x15;
    public static final int DW_CFA_val_expression = 0x16;
    public static final int DW_CFA_lo_user = 0x1c;
    public static final int DW_CFA_MIPS_advance_loc8 = 0x1d;
    /** aarch64 only (0x2c). */
    public static final int DW_CFA_AARCH64_negate_ra_state_with_pc = 0x2c;
    /** 0x2d: DW_CFA_GNU_window_save on sparc, DW_CFA_AARCH64_negate_ra_state on aarch64. */
    public static final int DW_CFA_GNU_window_save = 0x2d;
    public static final int DW_CFA_AARCH64_negate_ra_state = 0x2d;
    public static final int DW_CFA_GNU_args_size = 0x2e;
    public static final int DW_CFA_GNU_negative_offset_extended = 0x2f;
    public static final int DW_CFA_hi_user = 0x3f;

    /* ------------------------------------------------------------------ */
    /* Register rule kinds (binutils stores the DW_CFA opcode per column).  */
    /* ------------------------------------------------------------------ */
    /** Column not mentioned by this entry: there is no rule at all. */
    public static final int RULE_UNREFERENCED = -1;
    /** Register is not recoverable in the caller. */
    public static final int RULE_UNDEFINED = DW_CFA_undefined;
    /** Register has the same value in the caller. */
    public static final int RULE_SAME_VALUE = DW_CFA_same_value;
    /** Saved at {@code *(cfa + ruleValue)}. */
    public static final int RULE_OFFSET = DW_CFA_offset;
    /** Value is {@code cfa + ruleValue}. */
    public static final int RULE_VAL_OFFSET = DW_CFA_val_offset;
    /** Saved in another register, whose number is {@code ruleValue}. */
    public static final int RULE_REGISTER = DW_CFA_register;
    /** Saved at the address computed by the DWARF expression. */
    public static final int RULE_EXPRESSION = DW_CFA_expression;
    /** Value is the result of the DWARF expression. */
    public static final int RULE_VAL_EXPRESSION = DW_CFA_val_expression;

    /* ------------------------------------------------------------------ */
    /* DW_EH_PE pointer encodings.                                         */
    /* ------------------------------------------------------------------ */
    public static final int DW_EH_PE_absptr = 0x00;
    public static final int DW_EH_PE_uleb128 = 0x01;
    public static final int DW_EH_PE_udata2 = 0x02;
    public static final int DW_EH_PE_udata4 = 0x03;
    public static final int DW_EH_PE_udata8 = 0x04;
    public static final int DW_EH_PE_signed = 0x08;
    public static final int DW_EH_PE_sleb128 = 0x09;
    public static final int DW_EH_PE_sdata2 = 0x0a;
    public static final int DW_EH_PE_sdata4 = 0x0b;
    public static final int DW_EH_PE_sdata8 = 0x0c;
    public static final int DW_EH_PE_pcrel = 0x10;
    public static final int DW_EH_PE_textrel = 0x20;
    public static final int DW_EH_PE_datarel = 0x30;
    public static final int DW_EH_PE_funcrel = 0x40;
    public static final int DW_EH_PE_aligned = 0x50;
    public static final int DW_EH_PE_indirect = 0x80;
    public static final int DW_EH_PE_omit = 0xff;

    /* ------------------------------------------------------------------ */
    /* Register naming (binutils' tables, verbatim).                       */
    /* ------------------------------------------------------------------ */

    /** A DWARF register-number to name mapping. */
    public static final class Regs {
        private final String[] table;
        /** Table length; 0 when the machine has no table (all names become rN). */
        public final int count;
        /** True for EM_AARCH64, where 0x2d is DW_CFA_AARCH64_negate_ra_state. */
        public final boolean isAarch64;

        Regs(String[] table, boolean isAarch64) {
            this.table = table;
            this.count = table == null ? 0 : table.length;
            this.isAarch64 = isAarch64;
        }

        /** The bare name, or {@code null} when the register has none. */
        public String lookup(int regno) {
            if (table == null || regno < 0 || regno >= table.length) return null;
            return table[regno];
        }

        /**
         * Formats a register the way binutils does: {@code nameOnly} gives
         * {@code "rsp"}, otherwise {@code "r7 (rsp)"}; unknown registers are
         * always {@code "r7"}.
         */
        public String name(int regno, boolean nameOnly) {
            String n = lookup(regno);
            if (n != null) return nameOnly ? n : ("r" + Integer.toUnsignedString(regno) + " (" + n + ")");
            return "r" + Integer.toUnsignedString(regno);
        }
    }

    private static final String[] REGS_X86_64 = {
        "rax", "rdx", "rcx", "rbx",
        "rsi", "rdi", "rbp", "rsp",
        "r8", "r9", "r10", "r11",
        "r12", "r13", "r14", "r15",
        "rip",
        "xmm0", "xmm1", "xmm2", "xmm3",
        "xmm4", "xmm5", "xmm6", "xmm7",
        "xmm8", "xmm9", "xmm10", "xmm11",
        "xmm12", "xmm13", "xmm14", "xmm15",
        "st0", "st1", "st2", "st3",
        "st4", "st5", "st6", "st7",
        "mm0", "mm1", "mm2", "mm3",
        "mm4", "mm5", "mm6", "mm7",
        "rflags",
        "es", "cs", "ss", "ds", "fs", "gs", null, null,
        "fs.base", "gs.base", null, null,
        "tr", "ldtr",
        "mxcsr", "fcw", "fsw",
        "xmm16", "xmm17", "xmm18", "xmm19",
        "xmm20", "xmm21", "xmm22", "xmm23",
        "xmm24", "xmm25", "xmm26", "xmm27",
        "xmm28", "xmm29", "xmm30", "xmm31",
        null, null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, null,
        null, null, null,
        "k0", "k1", "k2", "k3", "k4", "k5", "k6", "k7",
        "bnd0", "bnd1", "bnd2", "bnd3",
    };

    private static final String[] REGS_AARCH64 = {
        "x0", "x1", "x2", "x3", "x4", "x5", "x6", "x7",
        "x8", "x9", "x10", "x11", "x12", "x13", "x14", "x15",
        "x16", "x17", "x18", "x19", "x20", "x21", "x22", "x23",
        "x24", "x25", "x26", "x27", "x28", "x29", "x30", "sp",
        null, "elr", null, null, null, null, null, null,
        null, null, null, null, null, null, "vg", "ffr",
        "p0", "p1", "p2", "p3", "p4", "p5", "p6", "p7",
        "p8", "p9", "p10", "p11", "p12", "p13", "p14", "p15",
        "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31",
        "z0", "z1", "z2", "z3", "z4", "z5", "z6", "z7",
        "z8", "z9", "z10", "z11", "z12", "z13", "z14", "z15",
        "z16", "z17", "z18", "z19", "z20", "z21", "z22", "z23",
        "z24", "z25", "z26", "z27", "z28", "z29", "z30", "z31",
    };

    private static final String[] REGS_I386 = {
        "eax", "ecx", "edx", "ebx",
        "esp", "ebp", "esi", "edi",
        "eip", "eflags", null,
        "st0", "st1", "st2", "st3",
        "st4", "st5", "st6", "st7",
        null, null,
        "xmm0", "xmm1", "xmm2", "xmm3",
        "xmm4", "xmm5", "xmm6", "xmm7",
        "mm0", "mm1", "mm2", "mm3",
        "mm4", "mm5", "mm6", "mm7",
        "fcw", "fsw", "mxcsr",
        "es", "cs", "ss", "ds", "fs", "gs", null, null,
        "tr", "ldtr",
        null, null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, null,
        null, null, null,
        "k0", "k1", "k2", "k3", "k4", "k5", "k6", "k7",
    };

    private static Regs regsFor(int machine) {
        switch (machine) {
            case 3:               /* EM_386 */
                return new Regs(REGS_I386, false);
            case 62:              /* EM_X86_64 */
            case 180:             /* EM_L1OM */
            case 181:             /* EM_K1OM */
                return new Regs(REGS_X86_64, false);
            case 183:             /* EM_AARCH64 */
                return new Regs(REGS_AARCH64, true);
            default:
                return new Regs(null, false);
        }
    }

    /* ------------------------------------------------------------------ */
    /* Public data model.                                                  */
    /* ------------------------------------------------------------------ */

    /** What an {@link Entry} is. */
    public enum Kind { CIE, FDE, ZERO }

    /**
     * One row of an unwind table: the CFA rule plus a register rule per column,
     * in effect from {@link #pc} until the next row.  Immutable.
     */
    public static final class Row {
        /** Address this row starts at. */
        public final long pc;
        /** True when the CFA is a DWARF expression rather than register+offset. */
        public final boolean cfaExpression;
        /** Base register of the CFA rule (meaningless when {@link #cfaExpression}). */
        public final int cfaRegister;
        /** Offset added to the CFA base register. */
        public final long cfaOffset;
        private final byte[] cfaExpr;
        private final short[] colType;
        private final long[] colOffset;
        private final byte[][] colExpr;
        private final int ra;
        private final int addrSize;
        private final Regs regs;

        Row(long pc, boolean cfaExpression, int cfaRegister, long cfaOffset, byte[] cfaExpr,
            short[] colType, long[] colOffset, byte[][] colExpr, int ra, int addrSize, Regs regs) {
            this.pc = pc;
            this.cfaExpression = cfaExpression;
            this.cfaRegister = cfaRegister;
            this.cfaOffset = cfaOffset;
            this.cfaExpr = cfaExpr;
            this.colType = colType;
            this.colOffset = colOffset;
            this.colExpr = colExpr;
            this.ra = ra;
            this.addrSize = addrSize;
            this.regs = regs;
        }

        /** Number of register columns carried by this row. */
        public int columns() { return colType.length; }

        /** DWARF register number holding the return address. */
        public int returnAddressColumn() { return ra; }

        /** Address size in bytes in effect for this row. */
        public int addressSize() { return addrSize; }

        /** Register naming table for the containing file. */
        public Regs registers() { return regs; }

        /** Raw DWARF expression bytes for the CFA, or {@code null}. */
        public byte[] cfaExpressionBytes() { return cfaExpr; }

        /** One of the {@code RULE_*} constants; {@link #RULE_UNREFERENCED} if no rule. */
        public int ruleKind(int reg) {
            if (reg < 0 || reg >= colType.length) return RULE_UNREFERENCED;
            return colType[reg];
        }

        /**
         * The rule payload: a CFA-relative byte offset for {@link #RULE_OFFSET}
         * and {@link #RULE_VAL_OFFSET}, a DWARF register number for
         * {@link #RULE_REGISTER}, 0 otherwise.
         */
        public long ruleValue(int reg) {
            if (reg < 0 || reg >= colOffset.length) return 0;
            return colOffset[reg];
        }

        /** Raw DWARF expression bytes for expression rules, else {@code null}. */
        public byte[] ruleExpression(int reg) {
            if (colExpr == null || reg < 0 || reg >= colExpr.length) return null;
            return colExpr[reg];
        }

        /** The CFA rule as readelf renders it, e.g. {@code "rsp+8"} or {@code "exp"}. */
        public String cfaText() {
            if (cfaExpression) return "exp";
            return regs.name(cfaRegister, true) + String.format("%+d", (int) cfaOffset);
        }

        /** A register rule as readelf renders it, e.g. {@code "c-8"} or {@code "u"}. */
        public String ruleText(int reg) {
            switch (ruleKind(reg)) {
                case RULE_UNDEFINED:      return "u";
                case RULE_SAME_VALUE:     return "s";
                case RULE_OFFSET:         return "c" + withSign(colOffset[reg]);
                case RULE_VAL_OFFSET:     return "v" + withSign(colOffset[reg]);
                case RULE_REGISTER:       return regs.name((int) colOffset[reg], false);
                case RULE_EXPRESSION:     return "exp";
                case RULE_VAL_EXPRESSION: return "vexp";
                default:                  return "n/a";
            }
        }

        private static String withSign(long v) { return (v < 0 ? "" : "+") + v; }
    }

    /** A CIE, an FDE, or a zero terminator, in section order. */
    public static final class Entry {
        public Kind kind;
        /** Offset of this entry within its section. */
        public int offset;
        /** Value of the length field, as binutils prints it. */
        public long length;
        /** Byte width used when printing {@link #length}. */
        public int lengthWidth;
        /** Raw CIE id / CIE pointer field. */
        public long cieId;
        /** 4 for 32-bit DWARF, 8 for the 64-bit escape. */
        public int offsetSize = 4;
        /** Resolved section offset of this FDE's CIE, or -1 for {@code cie=invalid}. */
        public int cieOffset = -1;
        public int version;
        public String augmentation = "";
        /** Code alignment factor (unsigned). */
        public int codeFactor;
        /** Data alignment factor (signed). */
        public int dataFactor;
        /** Return address column. */
        public int ra;
        public int ptrSize;
        public int segmentSize;
        public long segmentSelector;
        public long pcBegin;
        public long pcRange;
        /** Rows emitted by this entry's program, in order. */
        public final List<Row> rows = new ArrayList<>();
        /**
         * Body items in output order: {@link Row} objects interleaved with
         * {@link String} diagnostics that binutils prints even in interp mode.
         */
        public final List<Object> items = new ArrayList<>();
        /** Raw DW_CFA instruction lines, as `--debug-dump=frames` prints them. */
        public final List<String> rawLines = new ArrayList<>();
        /** Augmentation data bytes ('z' augmentations), or {@code null}. */
        public byte[] augData;
        /** State at {@link #pcBegin} before the program runs; set for FDEs. */
        public Row initial;
        /** Section this entry belongs to. */
        public FrameSection section;
    }

    /** One parsed {@code .eh_frame} / {@code .debug_frame} section. */
    public static final class FrameSection {
        public String name;
        public boolean isEh;
        public long addr;
        public final List<Entry> entries = new ArrayList<>();
    }

    /* ------------------------------------------------------------------ */
    /* Instance state.                                                     */
    /* ------------------------------------------------------------------ */

    public final Elf elf;
    public final Regs regs;
    /** Parsed frame sections, in ELF section-header order. */
    public final List<FrameSection> sections = new ArrayList<>();

    private final boolean little;
    private final int fileAddrSize;
    private int ehAddrSize;
    private int maxRegs;
    private Entry[] fdeIndex;

    private Cfi(Elf elf) {
        this.elf = elf;
        this.little = elf.little;
        this.regs = regsFor(elf.machine);
        this.fileAddrSize = elf.is64 ? 8 : 4;
        this.ehAddrSize = this.fileAddrSize;
    }

    /** Section names that readelf routes to {@code display_debug_frames}. */
    public static boolean isFrameSectionName(String n) {
        if (n == null) return false;
        return n.equals(".debug_frame") || n.equals(".zdebug_frame")
                || n.equals(".debug_frame.dwo") || n.equals(".zdebug_frame.dwo")
                || n.equals(".eh_frame");
    }

    /**
     * Parses every call-frame section of {@code elf}, visiting sections in ELF
     * section-header order, which is the order readelf dumps them in.
     */
    public static Cfi of(Elf elf) {
        Cfi c = new Cfi(elf);
        for (Elf.Section s : elf.sections) {
            if (!isFrameSectionName(s.name)) continue;
            if (s.type == 8 /* SHT_NOBITS */) continue;
            byte[] data;
            try {
                data = elf.data(s);
            } catch (RuntimeException e) {
                continue;
            }
            if (data == null || data.length == 0) continue;
            c.ehAddrSize = c.fileAddrSize;
            try {
                c.parseSection(s, data);
            } catch (RuntimeException e) {
                /* A malformed section must not abort the rest of the dump. */
            }
        }
        return c;
    }

    /* ------------------------------------------------------------------ */
    /* pc -> row lookup.                                                   */
    /* ------------------------------------------------------------------ */

    /** Every FDE across all parsed sections, sorted by start address (unsigned). */
    public Entry[] fdes() {
        if (fdeIndex == null) {
            List<Entry> l = new ArrayList<>();
            for (FrameSection fs : sections)
                for (Entry e : fs.entries)
                    if (e.kind == Kind.FDE) l.add(e);
            l.sort((a, b) -> Long.compareUnsigned(a.pcBegin, b.pcBegin));
            fdeIndex = l.toArray(new Entry[0]);
        }
        return fdeIndex;
    }

    /** The FDE whose address range covers {@code pc}, or {@code null}. */
    public Entry fdeFor(long pc) {
        Entry[] a = fdes();
        int lo = 0, hi = a.length - 1, best = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (Long.compareUnsigned(a[mid].pcBegin, pc) <= 0) { best = mid; lo = mid + 1; }
            else hi = mid - 1;
        }
        for (int i = best; i >= 0; i--) {
            Entry e = a[i];
            if (Long.compareUnsigned(pc - e.pcBegin, e.pcRange) < 0) return e;
            if (i > 0 && a[i - 1].pcBegin != e.pcBegin) break;
        }
        return null;
    }

    /**
     * The unwind-table row in effect at {@code pc}, or {@code null} when no FDE
     * covers it.  This is the entry point other modules should use to unwind:
     * the returned row carries the CFA rule and every register rule.
     */
    public Row rowAt(long pc) {
        Entry e = fdeFor(pc);
        if (e == null) return null;
        Row best = e.initial;
        for (Row r : e.rows) {
            if (Long.compareUnsigned(r.pc, pc) <= 0) best = r;
            else break;
        }
        return best;
    }

    /* ------------------------------------------------------------------ */
    /* Low-level readers mirroring binutils' safe accessors.               */
    /* ------------------------------------------------------------------ */

    private long byteGet(byte[] d, int p, int n) {
        long v = 0;
        if (little) {
            for (int i = n - 1; i >= 0; i--) v = (v << 8) | (d[p + i] & 0xffL);
        } else {
            for (int i = 0; i < n; i++) v = (v << 8) | (d[p + i] & 0xffL);
        }
        return v;
    }

    private long byteGetSigned(byte[] d, int p, int n) {
        long v = byteGet(d, p, n);
        if (n < 8) {
            long sign = 1L << (n * 8 - 1);
            if ((v & sign) != 0) v -= (sign << 1);
        }
        return v;
    }

    /** SAFE_BYTE_GET: clamps the read to {@code end}, yielding 0 when nothing fits. */
    private long safeGet(byte[] d, int ptr, int amount, int end) {
        if (amount > 8) amount = 8;
        if (ptr + amount >= end) amount = (ptr < end) ? (end - ptr) : 0;
        if (amount <= 0) return 0;
        if (ptr < 0 || ptr + amount > d.length) return 0;
        return byteGet(d, ptr, amount);
    }

    private int lebLen;

    private long readLeb(byte[] d, int ptr, int end, boolean sign) {
        long result = 0;
        int shift = 0, n = 0, b = 0;
        if (ptr < 0) ptr = 0;
        while (ptr + n < end && ptr + n < d.length) {
            b = d[ptr + n] & 0xff;
            n++;
            if (shift < 64) result |= ((long) (b & 0x7f)) << shift;
            shift += 7;
            if ((b & 0x80) == 0) break;
        }
        if (sign && shift < 64 && (b & 0x40) != 0) result |= -(1L << shift);
        lebLen = n;
        return result;
    }

    private static int sizeOfEncodedValue(int encoding, int ehAddrSize) {
        switch (encoding & 0x7) {
            case 2: return 2;
            case 3: return 4;
            case 4: return 8;
            default: return ehAddrSize;
        }
    }

    private int gevPos;

    /**
     * get_encoded_value, reproduced exactly: only DW_EH_PE_pcrel is applied, and
     * the size always comes from size_of_encoded_value, so the uleb128/sleb128
     * formats are read as a fixed-width value.
     */
    private long getEncodedValue(byte[] d, int data, int encoding, long secAddr, int end) {
        int size = sizeOfEncodedValue(encoding, ehAddrSize);
        if (data >= end || size > end - data || size > 8 || size == 0
                || data < 0 || data + size > d.length) {
            gevPos = end;
            return 0;
        }
        long val = ((encoding & DW_EH_PE_signed) != 0)
                ? byteGetSigned(d, data, size) : byteGet(d, data, size);
        if ((encoding & 0x70) == DW_EH_PE_pcrel) val += secAddr + data;
        gevPos = data + size;
        return val;
    }

    /* ------------------------------------------------------------------ */
    /* Interpreter state, mirroring binutils' Frame_Chunk.                 */
    /* ------------------------------------------------------------------ */

    private static final short UNREF = (short) RULE_UNREFERENCED;

    private static final class Chunk {
        int chunkStart = -1;         /* -1 stands for a NULL pointer */
        int ncols;
        short[] colType = new short[0];
        long[] colOffset = new long[0];
        byte[][] colExpr = new byte[0][];
        String augmentation = "";
        int codeFactor;              /* unsigned int */
        int dataFactor;              /* int */
        long pcBegin, pcRange;
        int cfaReg;                  /* unsigned int */
        long cfaOffset;
        byte[] cfaExprBytes;
        int ra;                      /* unsigned int */
        int fdeEncoding;             /* unsigned char */
        boolean cfaExp;
        int ptrSize, segmentSize;
    }

    private int frameNeedSpace(Chunk fc, int reg) {
        int prev = fc.ncols;
        if (Integer.compareUnsigned(reg, fc.ncols) < 0) return 0;
        if (regs.count > 0 && Integer.compareUnsigned(reg, regs.count) > 0) return -1;
        fc.ncols = reg + 1;
        if (fc.ncols == 0) return -1;
        if (Integer.compareUnsigned(fc.ncols, 1024) > 0 && regs.count == 0) {
            fc.ncols = 0;
            return -1;
        }
        fc.colType = Arrays.copyOf(fc.colType, fc.ncols);
        fc.colOffset = Arrays.copyOf(fc.colOffset, fc.ncols);
        fc.colExpr = Arrays.copyOf(fc.colExpr, fc.ncols);
        for (int i = prev; i < fc.ncols; i++) {
            fc.colType[i] = UNREF;
            fc.colOffset[i] = 0;
            fc.colExpr[i] = null;
        }
        return 1;
    }

    private Row snapshot(Chunk fc) {
        return new Row(fc.pcBegin, fc.cfaExp, fc.cfaReg, fc.cfaOffset, fc.cfaExprBytes,
                Arrays.copyOf(fc.colType, fc.ncols), Arrays.copyOf(fc.colOffset, fc.ncols),
                Arrays.copyOf(fc.colExpr, fc.ncols), fc.ra, ehAddrSize, regs);
    }

    /* read_cie outputs */
    private Chunk rcFc;
    private int rcVersion;
    private long rcAugLen;
    private int rcAugPos;

    private int readCie(byte[] d, int start, int end) {
        rcFc = null;
        rcVersion = 0;
        rcAugLen = 0;
        rcAugPos = -1;
        if (start >= end) return end;

        Chunk fc = new Chunk();
        int version = d[start++] & 0xff;

        int augPos = start;
        while (start < end) if ((d[start++] & 0xff) == 0) break;
        if (start == end) return end;                     /* no terminator */
        fc.augmentation = cstring(d, augPos, end);

        if (fc.augmentation.equals("eh")) {
            if (ehAddrSize > end - start) return end;
            start += ehAddrSize;
        }

        if (version >= 4) {
            if (2 > end - start) return end;
            fc.ptrSize = (int) safeGet(d, start, 1, end); start += 1;
            if (fc.ptrSize < 1 || fc.ptrSize > 8) return end;
            fc.segmentSize = (int) safeGet(d, start, 1, end); start += 1;
            if (fc.segmentSize > 8 || fc.segmentSize + fc.ptrSize > 8) return end;
            ehAddrSize = fc.ptrSize;
        } else {
            fc.ptrSize = ehAddrSize;
            fc.segmentSize = 0;
        }

        fc.codeFactor = (int) readLeb(d, start, end, false); start += lebLen;
        fc.dataFactor = (int) readLeb(d, start, end, true); start += lebLen;

        if (start >= end) return end;

        if (version == 1) {
            fc.ra = (int) safeGet(d, start, 1, end); start += 1;
        } else {
            fc.ra = (int) readLeb(d, start, end, false); start += lebLen;
        }

        long augLen = 0;
        int augDataPos = -1;
        if (fc.augmentation.startsWith("z")) {
            if (start >= end) return end;
            augLen = readLeb(d, start, end, false); start += lebLen;
            augDataPos = start;
            if (Long.compareUnsigned(augLen, end - start) > 0) return end;
            start += (int) augLen;
        }

        if (augLen != 0) {
            int p = augPos + 1;
            int q = augDataPos;
            int qend = augDataPos + (int) augLen;
            while (p < end && q < qend) {
                int c = d[p] & 0xff;
                if (c == 'L') q++;
                else if (c == 'P') q += 1 + sizeOfEncodedValue(d[q] & 0xff, ehAddrSize);
                else if (c == 'R') { fc.fdeEncoding = d[q] & 0xff; q++; }
                else if (c == 'S') { /* signal frame */ }
                else if (c == 'B') { /* pointer authentication B key */ }
                else break;
                p++;
            }
        }

        rcFc = fc;
        rcVersion = version;
        rcAugLen = augLen;
        rcAugPos = augDataPos;
        return start;
    }

    private static String cstring(byte[] d, int off, int end) {
        int e = off;
        while (e < end && e < d.length && d[e] != 0) e++;
        return new String(d, off, e - off, java.nio.charset.StandardCharsets.UTF_8);
    }

    /* ------------------------------------------------------------------ */
    /* display_debug_frames                                                */
    /* ------------------------------------------------------------------ */

    private void parseSection(Elf.Section sec, byte[] d) {
        FrameSection fs = new FrameSection();
        fs.name = sec.name;
        fs.isEh = ".eh_frame".equals(sec.name);
        fs.addr = sec.addr;
        sections.add(fs);
        fdeIndex = null;

        final int end = d.length;
        int start = 0;
        List<Chunk> chunks = new ArrayList<>();
        Map<Integer, Chunk> forwardRefs = new HashMap<>();
        Deque<Chunk> remembered = new ArrayDeque<>();
        maxRegs = 0;
        final int savedEhAddrSize = ehAddrSize;

        while (start < end) {
            int savedStart = start;
            long length = safeGet(d, start, 4, end); start += 4;

            if (length == 0) {
                Entry z = new Entry();
                z.kind = Kind.ZERO;
                z.offset = savedStart;
                z.section = fs;
                fs.entries.add(z);
                while (start < end && d[start] == 0) start++;
                continue;
            }

            int offsetSize;
            if (length == 0xffffffffL) {
                length = safeGet(d, start, 8, end); start += 8;
                offsetSize = 8;
            } else {
                offsetSize = 4;
            }

            int blockEnd;
            if (Long.compareUnsigned(length, end - start) > 0) blockEnd = end;
            else blockEnd = start + (int) length;

            long cieId = safeGet(d, start, offsetSize, blockEnd); start += offsetSize;

            Chunk fc;
            Chunk cie;
            Entry entry = new Entry();
            entry.section = fs;
            entry.offset = savedStart;
            entry.offsetSize = offsetSize;
            entry.cieId = cieId;
            int encodedPtrSize = savedEhAddrSize;

            boolean isCie = fs.isEh ? (cieId == 0)
                    : ((offsetSize == 4 && cieId == 0xffffffffL)
                       || (offsetSize == 8 && cieId == -1L));

            if (isCie) {
                start = readCie(d, start, blockEnd);
                cie = rcFc;
                if (cie == null) break;
                fc = cie;
                chunks.add(0, fc);
                fc.chunkStart = savedStart;
                int mreg = maxRegs > 0 ? maxRegs - 1 : 0;
                if (Integer.compareUnsigned(mreg, fc.ra) < 0) mreg = fc.ra;
                if (frameNeedSpace(fc, mreg) < 0) break;
                if (fc.fdeEncoding != 0) encodedPtrSize = sizeOfEncodedValue(fc.fdeEncoding, ehAddrSize);

                entry.kind = Kind.CIE;
                entry.length = length;
                entry.lengthWidth = fc.ptrSize;
                entry.version = rcVersion;
                entry.augmentation = fc.augmentation;
                entry.codeFactor = fc.codeFactor;
                entry.dataFactor = fc.dataFactor;
                entry.ra = fc.ra;
                entry.ptrSize = fc.ptrSize;
                entry.segmentSize = fc.segmentSize;
                if (rcAugLen > 0 && rcAugPos >= 0 && rcAugPos + rcAugLen <= d.length)
                    entry.augData = Arrays.copyOfRange(d, rcAugPos, rcAugPos + (int) rcAugLen);
            } else {
                long cieOff = cieId;
                if (fs.isEh) {
                    long sign = 1L << (offsetSize * 8 - 1);
                    cieOff = (cieOff ^ sign) - sign;
                    cieOff = (start - 4) - cieOff;      /* binutils hardcodes the 4 */
                }

                int lookFor = (int) cieOff;
                cie = null;
                if (Long.compareUnsigned(cieOff, savedStart) <= 0) {
                    for (Chunk c : chunks) if (c.chunkStart == lookFor) { cie = c; break; }
                } else if (Long.compareUnsigned(cieOff, end) >= 0) {
                    cie = null;
                } else {
                    cie = forwardRefs.get(lookFor);
                    if (cie == null) {
                        int cieScan = lookFor;
                        int offSize = 4;
                        /* binutils reuses `length` here, so a forward CIE
                           reference makes the FDE print the CIE's length. */
                        length = safeGet(d, cieScan, 4, end); cieScan += 4;
                        if (length == 0xffffffffL) {
                            length = safeGet(d, cieScan, 8, end); cieScan += 8;
                            offSize = 8;
                        }
                        if (length != 0 && Long.compareUnsigned(length, end - cieScan) <= 0) {
                            int cieEnd = cieScan + (int) length;
                            long cId = safeGet(d, cieScan, offSize, cieEnd); cieScan += offSize;
                            boolean thatIsCie = fs.isEh ? (cId == 0)
                                    : ((offSize == 4 && cId == 0xffffffffL)
                                       || (offSize == 8 && cId == -1L));
                            if (thatIsCie) {
                                readCie(d, cieScan, cieEnd);
                                cie = rcFc;
                                if (cie == null) break;
                                forwardRefs.put(lookFor, cie);
                                cie.chunkStart = lookFor;
                                int mreg = maxRegs > 0 ? maxRegs - 1 : 0;
                                if (Integer.compareUnsigned(mreg, cie.ra) < 0) mreg = cie.ra;
                                if (frameNeedSpace(cie, mreg) < 0) break;
                                if (cie.fdeEncoding != 0)
                                    encodedPtrSize = sizeOfEncodedValue(cie.fdeEncoding, ehAddrSize);
                            }
                        }
                    }
                }

                fc = new Chunk();
                if (cie == null) {
                    fc.ncols = 0;
                    if (frameNeedSpace(fc, maxRegs > 0 ? maxRegs - 1 : 0) < 0) break;
                    cie = fc;
                    fc.augmentation = "";
                    fc.fdeEncoding = 0;
                    fc.ptrSize = ehAddrSize;
                    fc.segmentSize = 0;
                } else {
                    fc.ncols = cie.ncols;
                    fc.colType = Arrays.copyOf(cie.colType, fc.ncols);
                    fc.colOffset = Arrays.copyOf(cie.colOffset, fc.ncols);
                    fc.colExpr = Arrays.copyOf(cie.colExpr, fc.ncols);
                    fc.augmentation = cie.augmentation;
                    fc.ptrSize = cie.ptrSize;
                    ehAddrSize = cie.ptrSize;
                    fc.segmentSize = cie.segmentSize;
                    fc.codeFactor = cie.codeFactor;
                    fc.dataFactor = cie.dataFactor;
                    fc.cfaReg = cie.cfaReg;
                    fc.cfaOffset = cie.cfaOffset;
                    fc.ra = cie.ra;
                    if (frameNeedSpace(fc, maxRegs > 0 ? maxRegs - 1 : 0) < 0) break;
                    fc.fdeEncoding = cie.fdeEncoding;
                }

                if (fc.fdeEncoding != 0) encodedPtrSize = sizeOfEncodedValue(fc.fdeEncoding, ehAddrSize);

                long segmentSelector = 0;
                if (fc.segmentSize != 0) {
                    if (fc.segmentSize > 8) fc.segmentSize = 4;
                    segmentSelector = safeGet(d, start, fc.segmentSize, blockEnd);
                    start += fc.segmentSize;
                }

                fc.pcBegin = getEncodedValue(d, start, fc.fdeEncoding, fs.addr, blockEnd);
                start = gevPos;
                fc.pcRange = safeGet(d, start, encodedPtrSize, blockEnd);
                start += encodedPtrSize;

                if (cie.augmentation.startsWith("z")) {
                    long augLen = readLeb(d, start, blockEnd, false);
                    start += lebLen;
                    int augPos = start;
                    if (Long.compareUnsigned(augLen, blockEnd - start) > 0) {
                        start = blockEnd;
                    } else {
                        start += (int) augLen;
                        if (augLen > 0 && augPos + augLen <= d.length)
                            entry.augData = Arrays.copyOfRange(d, augPos, augPos + (int) augLen);
                    }
                }

                entry.kind = Kind.FDE;
                entry.length = length;
                entry.lengthWidth = fc.ptrSize;
                entry.cieOffset = cie.chunkStart;
                entry.augmentation = fc.augmentation;
                entry.codeFactor = fc.codeFactor;
                entry.dataFactor = fc.dataFactor;
                entry.ra = fc.ra;
                entry.ptrSize = fc.ptrSize;
                entry.segmentSize = fc.segmentSize;
                entry.segmentSelector = segmentSelector;
                entry.pcBegin = fc.pcBegin;
                entry.pcRange = fc.pcRange;
            }

            /* ---- Pass 1: work out which columns this entry uses. ---- */
            int tmp = start;
            while (start < blockEnd) {
                int op = d[start++] & 0xff;
                int opa = op & 0x3f;
                if ((op & 0xc0) != 0) op &= 0xc0;
                int reg = -1;
                boolean haveReg = false;
                switch (op) {
                    case DW_CFA_advance_loc:
                        break;
                    case DW_CFA_offset:
                        readLeb(d, start, blockEnd, false); start += lebLen;
                        reg = opa; haveReg = true;
                        break;
                    case DW_CFA_restore:
                        reg = opa; haveReg = true;
                        break;
                    case DW_CFA_set_loc:
                        start = (blockEnd - start < encodedPtrSize) ? blockEnd : start + encodedPtrSize;
                        break;
                    case DW_CFA_advance_loc1:
                        start = (blockEnd - start < 1) ? blockEnd : start + 1;
                        break;
                    case DW_CFA_advance_loc2:
                        start = (blockEnd - start < 2) ? blockEnd : start + 2;
                        break;
                    case DW_CFA_advance_loc4:
                        start = (blockEnd - start < 4) ? blockEnd : start + 4;
                        break;
                    case DW_CFA_offset_extended:
                    case DW_CFA_val_offset:
                        reg = (int) readLeb(d, start, blockEnd, false); start += lebLen; haveReg = true;
                        readLeb(d, start, blockEnd, false); start += lebLen;
                        break;
                    case DW_CFA_restore_extended:
                    case DW_CFA_undefined:
                    case DW_CFA_same_value:
                        reg = (int) readLeb(d, start, blockEnd, false); start += lebLen; haveReg = true;
                        break;
                    case DW_CFA_register:
                        reg = (int) readLeb(d, start, blockEnd, false); start += lebLen; haveReg = true;
                        readLeb(d, start, blockEnd, false); start += lebLen;
                        break;
                    case DW_CFA_def_cfa:
                        readLeb(d, start, blockEnd, false); start += lebLen;
                        readLeb(d, start, blockEnd, false); start += lebLen;
                        break;
                    case DW_CFA_def_cfa_register:
                    case DW_CFA_def_cfa_offset:
                        readLeb(d, start, blockEnd, false); start += lebLen;
                        break;
                    case DW_CFA_def_cfa_expression: {
                        long t = readLeb(d, start, blockEnd, false); start += lebLen;
                        start = (Long.compareUnsigned(blockEnd - start, t) < 0) ? blockEnd : start + (int) t;
                        break;
                    }
                    case DW_CFA_expression:
                    case DW_CFA_val_expression: {
                        reg = (int) readLeb(d, start, blockEnd, false); start += lebLen; haveReg = true;
                        long t = readLeb(d, start, blockEnd, false); start += lebLen;
                        start = (Long.compareUnsigned(blockEnd - start, t) < 0) ? blockEnd : start + (int) t;
                        break;
                    }
                    case DW_CFA_offset_extended_sf:
                    case DW_CFA_val_offset_sf:
                        reg = (int) readLeb(d, start, blockEnd, false); start += lebLen; haveReg = true;
                        readLeb(d, start, blockEnd, true); start += lebLen;
                        break;
                    case DW_CFA_def_cfa_sf:
                        readLeb(d, start, blockEnd, false); start += lebLen;
                        readLeb(d, start, blockEnd, true); start += lebLen;
                        break;
                    case DW_CFA_def_cfa_offset_sf:
                        readLeb(d, start, blockEnd, true); start += lebLen;
                        break;
                    case DW_CFA_MIPS_advance_loc8:
                        start = (blockEnd - start < 8) ? blockEnd : start + 8;
                        break;
                    case DW_CFA_GNU_args_size:
                        readLeb(d, start, blockEnd, false); start += lebLen;
                        break;
                    case DW_CFA_GNU_negative_offset_extended:
                        reg = (int) readLeb(d, start, blockEnd, false); start += lebLen; haveReg = true;
                        readLeb(d, start, blockEnd, false); start += lebLen;
                        break;
                    default:
                        break;
                }
                if (haveReg && reg != -1 && frameNeedSpace(fc, reg) >= 0) {
                    if (Integer.compareUnsigned(reg, cie.ncols) >= 0 || cie.colType[reg] == UNREF)
                        fc.colType[reg] = (short) DW_CFA_undefined;
                    else
                        fc.colType[reg] = cie.colType[reg];
                }
            }
            start = tmp;

            if (entry.kind == Kind.FDE) entry.initial = snapshot(fc);

            /* ---- Pass 2: run the program, emitting rows. ---- */
            boolean allNops = true;
            while (start < blockEnd) {
                int op = d[start++] & 0xff;
                int opa = op & 0x3f;
                if ((op & 0xc0) != 0) op &= 0xc0;
                if (op != DW_CFA_nop) allNops = false;

                int reg;
                long ofs;
                long sofs;
                boolean bad;
                String ln;

                switch (op) {
                    case DW_CFA_advance_loc: {
                        long adv = ((long) opa * (fc.codeFactor & 0xffffffffL)) & 0xffffffffL;
                        entry.rawLines.add("  DW_CFA_advance_loc: " + (int) adv + " to "
                                + hexNs(fc.pcBegin + adv, fc.ptrSize));
                        emitRow(entry, fc);
                        fc.pcBegin += adv;
                        break;
                    }
                    case DW_CFA_offset:
                        ofs = readLeb(d, start, blockEnd, false); start += lebLen;
                        ofs *= fc.dataFactor;
                        bad = Integer.compareUnsigned(opa, fc.ncols) >= 0;
                        ln = "  DW_CFA_offset: " + (bad ? BAD_REG : "") + regs.name(opa, false)
                                + " at cfa" + signed(ofs);
                        entry.rawLines.add(ln);
                        if (bad) entry.items.add(ln);
                        else {
                            fc.colType[opa] = (short) DW_CFA_offset;
                            fc.colOffset[opa] = ofs;
                        }
                        break;
                    case DW_CFA_restore:
                        bad = Integer.compareUnsigned(opa, fc.ncols) >= 0;
                        ln = "  DW_CFA_restore: " + (bad ? BAD_REG : "") + regs.name(opa, false);
                        entry.rawLines.add(ln);
                        if (bad) { entry.items.add(ln); break; }
                        if (Integer.compareUnsigned(opa, cie.ncols) >= 0 || cie.colType[opa] == UNREF) {
                            fc.colType[opa] = (short) DW_CFA_undefined;
                            fc.colOffset[opa] = 0;
                        } else {
                            fc.colType[opa] = cie.colType[opa];
                            fc.colOffset[opa] = cie.colOffset[opa];
                            fc.colExpr[opa] = cie.colExpr[opa];
                        }
                        break;
                    case DW_CFA_set_loc:
                        ofs = getEncodedValue(d, start, fc.fdeEncoding, fs.addr, blockEnd);
                        start = gevPos;
                        entry.rawLines.add("  DW_CFA_set_loc: " + hexNs(ofs, fc.ptrSize));
                        emitRow(entry, fc);
                        fc.pcBegin = ofs;
                        break;
                    case DW_CFA_advance_loc1:
                        ofs = safeGet(d, start, 1, blockEnd); start += 1;
                        ofs *= (fc.codeFactor & 0xffffffffL);
                        entry.rawLines.add("  DW_CFA_advance_loc1: " + ofs + " to "
                                + hexNs(fc.pcBegin + ofs, fc.ptrSize));
                        emitRow(entry, fc);
                        fc.pcBegin += ofs;
                        break;
                    case DW_CFA_advance_loc2:
                        ofs = safeGet(d, start, 2, blockEnd); start += 2;
                        ofs *= (fc.codeFactor & 0xffffffffL);
                        entry.rawLines.add("  DW_CFA_advance_loc2: " + ofs + " to "
                                + hexNs(fc.pcBegin + ofs, fc.ptrSize));
                        emitRow(entry, fc);
                        fc.pcBegin += ofs;
                        break;
                    case DW_CFA_advance_loc4:
                        ofs = safeGet(d, start, 4, blockEnd); start += 4;
                        ofs *= (fc.codeFactor & 0xffffffffL);
                        entry.rawLines.add("  DW_CFA_advance_loc4: " + ofs + " to "
                                + hexNs(fc.pcBegin + ofs, fc.ptrSize));
                        emitRow(entry, fc);
                        fc.pcBegin += ofs;
                        break;
                    case DW_CFA_offset_extended:
                        reg = (int) readLeb(d, start, blockEnd, false); start += lebLen;
                        ofs = readLeb(d, start, blockEnd, false); start += lebLen;
                        ofs *= fc.dataFactor;
                        bad = Integer.compareUnsigned(reg, fc.ncols) >= 0;
                        ln = "  DW_CFA_offset_extended: " + (bad ? BAD_REG : "")
                                + regs.name(reg, false) + " at cfa" + signed(ofs);
                        entry.rawLines.add(ln);
                        if (bad) entry.items.add(ln);
                        else {
                            fc.colType[reg] = (short) DW_CFA_offset;
                            fc.colOffset[reg] = ofs;
                        }
                        break;
                    case DW_CFA_val_offset:
                        reg = (int) readLeb(d, start, blockEnd, false); start += lebLen;
                        ofs = readLeb(d, start, blockEnd, false); start += lebLen;
                        ofs *= fc.dataFactor;
                        bad = Integer.compareUnsigned(reg, fc.ncols) >= 0;
                        ln = "  DW_CFA_val_offset: " + (bad ? BAD_REG : "")
                                + regs.name(reg, false) + " is cfa" + signed(ofs);
                        entry.rawLines.add(ln);
                        if (bad) entry.items.add(ln);
                        else {
                            fc.colType[reg] = (short) DW_CFA_val_offset;
                            fc.colOffset[reg] = ofs;
                        }
                        break;
                    case DW_CFA_restore_extended:
                        reg = (int) readLeb(d, start, blockEnd, false); start += lebLen;
                        bad = Integer.compareUnsigned(reg, fc.ncols) >= 0;
                        ln = "  DW_CFA_restore_extended: " + (bad ? BAD_REG : "") + regs.name(reg, false);
                        entry.rawLines.add(ln);
                        if (bad) { entry.items.add(ln); break; }
                        if (Integer.compareUnsigned(reg, cie.ncols) >= 0 || cie.colType[reg] == UNREF) {
                            fc.colType[reg] = (short) DW_CFA_undefined;
                            fc.colOffset[reg] = 0;
                        } else {
                            fc.colType[reg] = cie.colType[reg];
                            fc.colOffset[reg] = cie.colOffset[reg];
                            fc.colExpr[reg] = cie.colExpr[reg];
                        }
                        break;
                    case DW_CFA_undefined:
                        reg = (int) readLeb(d, start, blockEnd, false); start += lebLen;
                        bad = Integer.compareUnsigned(reg, fc.ncols) >= 0;
                        ln = "  DW_CFA_undefined: " + (bad ? BAD_REG : "") + regs.name(reg, false);
                        entry.rawLines.add(ln);
                        if (bad) entry.items.add(ln);
                        else {
                            fc.colType[reg] = (short) DW_CFA_undefined;
                            fc.colOffset[reg] = 0;
                        }
                        break;
                    case DW_CFA_same_value:
                        reg = (int) readLeb(d, start, blockEnd, false); start += lebLen;
                        bad = Integer.compareUnsigned(reg, fc.ncols) >= 0;
                        ln = "  DW_CFA_same_value: " + (bad ? BAD_REG : "") + regs.name(reg, false);
                        entry.rawLines.add(ln);
                        if (bad) entry.items.add(ln);
                        else {
                            fc.colType[reg] = (short) DW_CFA_same_value;
                            fc.colOffset[reg] = 0;
                        }
                        break;
                    case DW_CFA_register:
                        reg = (int) readLeb(d, start, blockEnd, false); start += lebLen;
                        ofs = readLeb(d, start, blockEnd, false); start += lebLen;
                        bad = Integer.compareUnsigned(reg, fc.ncols) >= 0;
                        ln = "  DW_CFA_register: " + (bad ? BAD_REG : "") + regs.name(reg, false)
                                + " in " + regs.name((int) ofs, false);
                        entry.rawLines.add(ln);
                        if (bad) entry.items.add(ln);
                        else {
                            fc.colType[reg] = (short) DW_CFA_register;
                            fc.colOffset[reg] = ofs;
                        }
                        break;
                    case DW_CFA_remember_state: {
                        entry.rawLines.add("  DW_CFA_remember_state");
                        Chunk rs = new Chunk();
                        rs.cfaOffset = fc.cfaOffset;
                        rs.cfaReg = fc.cfaReg;
                        rs.ra = fc.ra;
                        rs.cfaExp = fc.cfaExp;
                        rs.cfaExprBytes = fc.cfaExprBytes;
                        rs.ncols = fc.ncols;
                        rs.colType = Arrays.copyOf(fc.colType, rs.ncols);
                        rs.colOffset = Arrays.copyOf(fc.colOffset, rs.ncols);
                        rs.colExpr = Arrays.copyOf(fc.colExpr, rs.ncols);
                        remembered.push(rs);
                        break;
                    }
                    case DW_CFA_restore_state: {
                        entry.rawLines.add("  DW_CFA_restore_state");
                        Chunk rs = remembered.poll();
                        if (rs != null) {
                            fc.cfaOffset = rs.cfaOffset;
                            fc.cfaReg = rs.cfaReg;
                            fc.ra = rs.ra;
                            fc.cfaExp = rs.cfaExp;
                            fc.cfaExprBytes = rs.cfaExprBytes;
                            if (frameNeedSpace(fc, rs.ncols - 1) < 0) {
                                fc.ncols = 0;
                            } else {
                                System.arraycopy(rs.colType, 0, fc.colType, 0, rs.ncols);
                                System.arraycopy(rs.colOffset, 0, fc.colOffset, 0, rs.ncols);
                                System.arraycopy(rs.colExpr, 0, fc.colExpr, 0, rs.ncols);
                            }
                        }
                        break;
                    }
                    case DW_CFA_def_cfa:
                        fc.cfaReg = (int) readLeb(d, start, blockEnd, false); start += lebLen;
                        fc.cfaOffset = readLeb(d, start, blockEnd, false); start += lebLen;
                        fc.cfaExp = false;
                        fc.cfaExprBytes = null;
                        entry.rawLines.add("  DW_CFA_def_cfa: " + regs.name(fc.cfaReg, false)
                                + " ofs " + (int) fc.cfaOffset);
                        break;
                    case DW_CFA_def_cfa_register:
                        fc.cfaReg = (int) readLeb(d, start, blockEnd, false); start += lebLen;
                        fc.cfaExp = false;
                        fc.cfaExprBytes = null;
                        entry.rawLines.add("  DW_CFA_def_cfa_register: " + regs.name(fc.cfaReg, false));
                        break;
                    case DW_CFA_def_cfa_offset:
                        fc.cfaOffset = readLeb(d, start, blockEnd, false); start += lebLen;
                        entry.rawLines.add("  DW_CFA_def_cfa_offset: " + (int) fc.cfaOffset);
                        break;
                    case DW_CFA_nop:
                        entry.rawLines.add("  DW_CFA_nop");
                        break;
                    case DW_CFA_def_cfa_expression:
                        ofs = readLeb(d, start, blockEnd, false); start += lebLen;
                        if (Long.compareUnsigned(ofs, blockEnd - start) > 0) {
                            ln = "  DW_CFA_def_cfa_expression: <corrupt len "
                                    + Long.toUnsignedString(ofs) + ">";
                            entry.rawLines.add(ln);
                            entry.items.add(ln);
                            break;
                        }
                        entry.rawLines.add("  DW_CFA_def_cfa_expression ("
                                + decodeExpr(d, start, ofs, ehAddrSize, 0, -1, 0, fs.addr).text + ")");
                        fc.cfaExp = true;
                        fc.cfaExprBytes = Arrays.copyOfRange(d, start, start + (int) ofs);
                        start += (int) ofs;
                        break;
                    case DW_CFA_expression:
                        reg = (int) readLeb(d, start, blockEnd, false); start += lebLen;
                        ofs = readLeb(d, start, blockEnd, false); start += lebLen;
                        bad = Integer.compareUnsigned(reg, fc.ncols) >= 0;
                        if (Long.compareUnsigned(ofs, blockEnd - start) > 0) {
                            ln = "  DW_CFA_expression: <corrupt len " + Long.toUnsignedString(ofs) + ">";
                            entry.rawLines.add(ln);
                            entry.items.add(ln);
                            break;
                        }
                        ln = "  DW_CFA_expression: " + (bad ? BAD_REG : "") + regs.name(reg, false)
                                + " (" + decodeExpr(d, start, ofs, ehAddrSize, 0, -1, 0, fs.addr).text + ")";
                        entry.rawLines.add(ln);
                        if (bad) entry.items.add(ln);
                        else {
                            fc.colType[reg] = (short) DW_CFA_expression;
                            fc.colExpr[reg] = Arrays.copyOfRange(d, start, start + (int) ofs);
                        }
                        start += (int) ofs;
                        break;
                    case DW_CFA_val_expression:
                        reg = (int) readLeb(d, start, blockEnd, false); start += lebLen;
                        ofs = readLeb(d, start, blockEnd, false); start += lebLen;
                        bad = Integer.compareUnsigned(reg, fc.ncols) >= 0;
                        if (Long.compareUnsigned(ofs, blockEnd - start) > 0) {
                            ln = "  DW_CFA_val_expression: <corrupt len " + Long.toUnsignedString(ofs) + ">";
                            entry.rawLines.add(ln);
                            entry.items.add(ln);
                            break;
                        }
                        ln = "  DW_CFA_val_expression: " + (bad ? BAD_REG : "") + regs.name(reg, false)
                                + " (" + decodeExpr(d, start, ofs, ehAddrSize, 0, -1, 0, fs.addr).text + ")";
                        entry.rawLines.add(ln);
                        if (bad) entry.items.add(ln);
                        else {
                            fc.colType[reg] = (short) DW_CFA_val_expression;
                            fc.colExpr[reg] = Arrays.copyOfRange(d, start, start + (int) ofs);
                        }
                        start += (int) ofs;
                        break;
                    case DW_CFA_offset_extended_sf:
                        reg = (int) readLeb(d, start, blockEnd, false); start += lebLen;
                        sofs = readLeb(d, start, blockEnd, true); start += lebLen;
                        ofs = sofs * fc.dataFactor;
                        bad = Integer.compareUnsigned(reg, fc.ncols) >= 0;
                        ln = "  DW_CFA_offset_extended_sf: " + (bad ? BAD_REG : "")
                                + regs.name(reg, false) + " at cfa" + signed(ofs);
                        entry.rawLines.add(ln);
                        if (bad) entry.items.add(ln);
                        else {
                            fc.colType[reg] = (short) DW_CFA_offset;
                            fc.colOffset[reg] = ofs;
                        }
                        break;
                    case DW_CFA_val_offset_sf:
                        reg = (int) readLeb(d, start, blockEnd, false); start += lebLen;
                        sofs = readLeb(d, start, blockEnd, true); start += lebLen;
                        ofs = sofs * fc.dataFactor;
                        bad = Integer.compareUnsigned(reg, fc.ncols) >= 0;
                        ln = "  DW_CFA_val_offset_sf: " + (bad ? BAD_REG : "")
                                + regs.name(reg, false) + " is cfa" + signed(ofs);
                        entry.rawLines.add(ln);
                        if (bad) entry.items.add(ln);
                        else {
                            fc.colType[reg] = (short) DW_CFA_val_offset;
                            fc.colOffset[reg] = ofs;
                        }
                        break;
                    case DW_CFA_def_cfa_sf:
                        fc.cfaReg = (int) readLeb(d, start, blockEnd, false); start += lebLen;
                        sofs = readLeb(d, start, blockEnd, true); start += lebLen;
                        fc.cfaOffset = sofs * fc.dataFactor;
                        fc.cfaExp = false;
                        fc.cfaExprBytes = null;
                        entry.rawLines.add("  DW_CFA_def_cfa_sf: " + regs.name(fc.cfaReg, false)
                                + " ofs " + fc.cfaOffset);
                        break;
                    case DW_CFA_def_cfa_offset_sf:
                        sofs = readLeb(d, start, blockEnd, true); start += lebLen;
                        fc.cfaOffset = sofs * fc.dataFactor;
                        entry.rawLines.add("  DW_CFA_def_cfa_offset_sf: " + fc.cfaOffset);
                        break;
                    case DW_CFA_MIPS_advance_loc8:
                        ofs = safeGet(d, start, 8, blockEnd); start += 8;
                        ofs *= (fc.codeFactor & 0xffffffffL);
                        entry.rawLines.add("  DW_CFA_MIPS_advance_loc8: " + ofs + " to "
                                + hexNs(fc.pcBegin + ofs, fc.ptrSize));
                        emitRow(entry, fc);
                        fc.pcBegin += ofs;
                        break;
                    case DW_CFA_AARCH64_negate_ra_state_with_pc:
                        entry.rawLines.add("  DW_CFA_AARCH64_negate_ra_state_with_pc");
                        break;
                    case DW_CFA_GNU_window_save:
                        /* DW_CFA_AARCH64_negate_ra_state on aarch64: no table effect. */
                        entry.rawLines.add(regs.isAarch64
                                ? "  DW_CFA_AARCH64_negate_ra_state"
                                : "  DW_CFA_GNU_window_save");
                        break;
                    case DW_CFA_GNU_args_size:
                        ofs = readLeb(d, start, blockEnd, false); start += lebLen;
                        entry.rawLines.add("  DW_CFA_GNU_args_size: " + Long.toUnsignedString(ofs));
                        break;
                    case DW_CFA_GNU_negative_offset_extended:
                        reg = (int) readLeb(d, start, blockEnd, false); start += lebLen;
                        sofs = readLeb(d, start, blockEnd, true); start += lebLen;
                        ofs = (-sofs) * fc.dataFactor;
                        bad = Integer.compareUnsigned(reg, fc.ncols) >= 0;
                        ln = "  DW_CFA_GNU_negative_offset_extended: " + (bad ? BAD_REG : "")
                                + regs.name(reg, false) + " at cfa" + signed(ofs);
                        entry.rawLines.add(ln);
                        if (bad) entry.items.add(ln);
                        else {
                            fc.colType[reg] = (short) DW_CFA_offset;
                            fc.colOffset[reg] = ofs;
                        }
                        break;
                    default:
                        if (op >= DW_CFA_lo_user && op <= DW_CFA_hi_user) {
                            ln = "  DW_CFA_??? (User defined call frame op: " + hashHex(op) + ")";
                            entry.rawLines.add(ln);
                            entry.items.add(ln);
                        }
                        start = blockEnd;
                        break;
                }
            }

            if (!allNops) emitRow(entry, fc);

            fs.entries.add(entry);
            start = blockEnd;
            ehAddrSize = savedEhAddrSize;
        }
    }

    private void emitRow(Entry e, Chunk fc) {
        /* frame_display_row keeps max_regs in step with the entry being printed. */
        maxRegs = fc.ncols;
        Row r = snapshot(fc);
        e.rows.add(r);
        e.items.add(r);
    }

    private static String signed(long v) { return (v < 0 ? "" : "+") + v; }

    /* ------------------------------------------------------------------ */
    /* Formatting helpers shared with ReadelfMain.                         */
    /* ------------------------------------------------------------------ */

    /** binutils {@code print_hex_ns}: zero padded hex, value masked to {@code numBytes}. */
    public static String hexNs(long value, int numBytes) {
        if (numBytes == 0) numBytes = 2;
        if (numBytes > 8) numBytes = 8;
        long mask = (numBytes >= 8) ? -1L : ((1L << (numBytes * 8)) - 1);
        return String.format("%0" + (numBytes * 2) + "x", value & mask);
    }

    /** binutils {@code print_hex}: like {@link #hexNs} but with a trailing space. */
    public static String hex(long value, int numBytes) { return hexNs(value, numBytes) + " "; }

    /* ================================================================== */
    /* DWARF expression rendering (binutils decode_location_expression).   */
    /* ================================================================== */

    private static final String BAD_REG = "bad register: ";

    private static final int DW_OP_addr = 0x03, DW_OP_deref = 0x06,
            DW_OP_const1u = 0x08, DW_OP_const1s = 0x09, DW_OP_const2u = 0x0a, DW_OP_const2s = 0x0b,
            DW_OP_const4u = 0x0c, DW_OP_const4s = 0x0d, DW_OP_const8u = 0x0e, DW_OP_const8s = 0x0f,
            DW_OP_constu = 0x10, DW_OP_consts = 0x11, DW_OP_dup = 0x12, DW_OP_drop = 0x13,
            DW_OP_over = 0x14, DW_OP_pick = 0x15, DW_OP_swap = 0x16, DW_OP_rot = 0x17,
            DW_OP_xderef = 0x18, DW_OP_abs = 0x19, DW_OP_and = 0x1a, DW_OP_div = 0x1b,
            DW_OP_minus = 0x1c, DW_OP_mod = 0x1d, DW_OP_mul = 0x1e, DW_OP_neg = 0x1f,
            DW_OP_not = 0x20, DW_OP_or = 0x21, DW_OP_plus = 0x22, DW_OP_plus_uconst = 0x23,
            DW_OP_shl = 0x24, DW_OP_shr = 0x25, DW_OP_shra = 0x26, DW_OP_xor = 0x27,
            DW_OP_bra = 0x28, DW_OP_eq = 0x29, DW_OP_ge = 0x2a, DW_OP_gt = 0x2b, DW_OP_le = 0x2c,
            DW_OP_lt = 0x2d, DW_OP_ne = 0x2e, DW_OP_skip = 0x2f,
            DW_OP_lit0 = 0x30, DW_OP_lit31 = 0x4f,
            DW_OP_reg0 = 0x50, DW_OP_reg31 = 0x6f,
            DW_OP_breg0 = 0x70, DW_OP_breg31 = 0x8f,
            DW_OP_regx = 0x90, DW_OP_fbreg = 0x91, DW_OP_bregx = 0x92, DW_OP_piece = 0x93,
            DW_OP_deref_size = 0x94, DW_OP_xderef_size = 0x95, DW_OP_nop = 0x96,
            DW_OP_push_object_address = 0x97, DW_OP_call2 = 0x98, DW_OP_call4 = 0x99,
            DW_OP_call_ref = 0x9a, DW_OP_form_tls_address = 0x9b, DW_OP_call_frame_cfa = 0x9c,
            DW_OP_bit_piece = 0x9d, DW_OP_implicit_value = 0x9e, DW_OP_stack_value = 0x9f,
            DW_OP_implicit_pointer = 0xa0, DW_OP_entry_value = 0xa3, DW_OP_const_type = 0xa4,
            DW_OP_regval_type = 0xa5, DW_OP_deref_type = 0xa6, DW_OP_convert = 0xa8,
            DW_OP_reinterpret = 0xa9, DW_OP_addrx = 0xa1,
            DW_OP_lo_user = 0xe0, DW_OP_hi_user = 0xff,
            DW_OP_GNU_push_tls_address = 0xe0, DW_OP_GNU_uninit = 0xf0,
            DW_OP_GNU_encoded_addr = 0xf1, DW_OP_GNU_implicit_pointer = 0xf2,
            DW_OP_GNU_entry_value = 0xf3, DW_OP_GNU_const_type = 0xf4,
            DW_OP_GNU_regval_type = 0xf5, DW_OP_GNU_deref_type = 0xf6,
            DW_OP_GNU_convert = 0xf7, DW_OP_GNU_reinterpret = 0xf9,
            DW_OP_GNU_parameter_ref = 0xfa, DW_OP_GNU_addr_index = 0xfb,
            DW_OP_GNU_const_index = 0xfc, DW_OP_GNU_variable_value = 0xfd,
            DW_OP_HP_is_value = 0xe1, DW_OP_HP_fltconst4 = 0xe2, DW_OP_HP_fltconst8 = 0xe3,
            DW_OP_HP_mod_range = 0xe4, DW_OP_HP_unmod_range = 0xe5, DW_OP_HP_tls = 0xe6,
            DW_OP_PGI_omp_thread_num = 0xf8;

    /** A rendered DWARF expression plus whether it needs DW_AT_frame_base. */
    public static final class Expr {
        public final String text;
        public final boolean needFrameBase;
        Expr(String t, boolean n) { text = t; needFrameBase = n; }
    }

    /** SAFE_SIGNED_BYTE_GET: like {@link #safeGet} but sign extended. */
    private long safeGetS(byte[] d, int ptr, int amount, int end) {
        if (amount > 8) amount = 8;
        if (ptr + amount >= end) amount = (ptr < end) ? (end - ptr) : 0;
        if (amount <= 0) return 0;
        if (ptr < 0 || ptr + amount > d.length) return 0;
        return byteGetSigned(d, ptr, amount);
    }

    /** C's {@code %#x}: a zero value gets no {@code 0x} prefix. */
    private static String hashHex(long v) {
        return v == 0 ? "0" : "0x" + Long.toHexString(v);
    }

    private int dbPos;

    /** binutils {@code display_block}. */
    private String displayBlock(byte[] d, int data, long length, int end, char delim) {
        StringBuilder sb = new StringBuilder();
        sb.append(delim).append(Long.toUnsignedString(length)).append(" byte block: ");
        if (data > end) { dbPos = end; return sb.toString(); }
        long maxlen = end - data;
        if (Long.compareUnsigned(length, maxlen) > 0) length = maxlen;
        while (length-- > 0 && data < d.length)
            sb.append(Long.toHexString(d[data++] & 0xffL)).append(' ');
        dbPos = data;
        return sb.toString();
    }

    /**
     * Renders a DWARF location expression exactly the way binutils'
     * {@code decode_location_expression} prints it.  Frame info passes
     * {@code dwarfVersion == -1}, which makes the ops that need a DIE context
     * bail out with a {@code "(... in frame info)"} note, as binutils does.
     */
    public Expr decodeExpr(byte[] d, int data, long length, int pointerSize, int offsetSize,
                           int dwarfVersion, long cuOffset, long secAddr) {
        StringBuilder sb = new StringBuilder();
        boolean nfb = false;
        int end = (int) Math.min((long) data + Math.max(length, 0), d.length);
        while (data < end) {
            int op = d[data++] & 0xff;
            long uv, sv;
            if (op >= DW_OP_lit0 && op <= DW_OP_lit31) {
                sb.append("DW_OP_lit").append(op - DW_OP_lit0);
            } else if (op >= DW_OP_reg0 && op <= DW_OP_reg31) {
                sb.append("DW_OP_reg").append(op - DW_OP_reg0)
                  .append(" (").append(regs.name(op - DW_OP_reg0, true)).append(')');
            } else if (op >= DW_OP_breg0 && op <= DW_OP_breg31) {
                sv = readLeb(d, data, end, true); data += lebLen;
                sb.append("DW_OP_breg").append(op - DW_OP_breg0)
                  .append(" (").append(regs.name(op - DW_OP_breg0, true)).append("): ").append(sv);
            } else {
                switch (op) {
                    case DW_OP_addr:
                        uv = safeGet(d, data, pointerSize, end); data += pointerSize;
                        sb.append("DW_OP_addr: ").append(Long.toHexString(uv));
                        break;
                    case DW_OP_deref: sb.append("DW_OP_deref"); break;
                    case DW_OP_const1u:
                        uv = safeGet(d, data, 1, end); data += 1;
                        sb.append("DW_OP_const1u: ").append(Long.toUnsignedString(uv)); break;
                    case DW_OP_const1s:
                        sv = safeGetS(d, data, 1, end); data += 1;
                        sb.append("DW_OP_const1s: ").append(sv); break;
                    case DW_OP_const2u:
                        uv = safeGet(d, data, 2, end); data += 2;
                        sb.append("DW_OP_const2u: ").append(Long.toUnsignedString(uv)); break;
                    case DW_OP_const2s:
                        sv = safeGetS(d, data, 2, end); data += 2;
                        sb.append("DW_OP_const2s: ").append(sv); break;
                    case DW_OP_const4u:
                        uv = safeGet(d, data, 4, end); data += 4;
                        sb.append("DW_OP_const4u: ").append(Long.toUnsignedString(uv)); break;
                    case DW_OP_const4s:
                        sv = safeGetS(d, data, 4, end); data += 4;
                        sb.append("DW_OP_const4s: ").append(sv); break;
                    case DW_OP_const8u:
                        uv = safeGet(d, data, 8, end); data += 8;
                        sb.append("DW_OP_const8u: ").append(Long.toUnsignedString(uv)); break;
                    case DW_OP_const8s:
                        sv = safeGetS(d, data, 8, end); data += 8;
                        sb.append("DW_OP_const8s: ").append(sv); break;
                    case DW_OP_constu:
                        uv = readLeb(d, data, end, false); data += lebLen;
                        sb.append("DW_OP_constu: ").append(Long.toUnsignedString(uv)); break;
                    case DW_OP_consts:
                        sv = readLeb(d, data, end, true); data += lebLen;
                        sb.append("DW_OP_consts: ").append(sv); break;
                    case DW_OP_dup: sb.append("DW_OP_dup"); break;
                    case DW_OP_drop: sb.append("DW_OP_drop"); break;
                    case DW_OP_over: sb.append("DW_OP_over"); break;
                    case DW_OP_pick:
                        uv = safeGet(d, data, 1, end); data += 1;
                        sb.append("DW_OP_pick: ").append(Long.toUnsignedString(uv)); break;
                    case DW_OP_swap: sb.append("DW_OP_swap"); break;
                    case DW_OP_rot: sb.append("DW_OP_rot"); break;
                    case DW_OP_xderef: sb.append("DW_OP_xderef"); break;
                    case DW_OP_abs: sb.append("DW_OP_abs"); break;
                    case DW_OP_and: sb.append("DW_OP_and"); break;
                    case DW_OP_div: sb.append("DW_OP_div"); break;
                    case DW_OP_minus: sb.append("DW_OP_minus"); break;
                    case DW_OP_mod: sb.append("DW_OP_mod"); break;
                    case DW_OP_mul: sb.append("DW_OP_mul"); break;
                    case DW_OP_neg: sb.append("DW_OP_neg"); break;
                    case DW_OP_not: sb.append("DW_OP_not"); break;
                    case DW_OP_or: sb.append("DW_OP_or"); break;
                    case DW_OP_plus: sb.append("DW_OP_plus"); break;
                    case DW_OP_plus_uconst:
                        uv = readLeb(d, data, end, false); data += lebLen;
                        sb.append("DW_OP_plus_uconst: ").append(Long.toUnsignedString(uv)); break;
                    case DW_OP_shl: sb.append("DW_OP_shl"); break;
                    case DW_OP_shr: sb.append("DW_OP_shr"); break;
                    case DW_OP_shra: sb.append("DW_OP_shra"); break;
                    case DW_OP_xor: sb.append("DW_OP_xor"); break;
                    case DW_OP_bra:
                        sv = safeGetS(d, data, 2, end); data += 2;
                        sb.append("DW_OP_bra: ").append(sv); break;
                    case DW_OP_eq: sb.append("DW_OP_eq"); break;
                    case DW_OP_ge: sb.append("DW_OP_ge"); break;
                    case DW_OP_gt: sb.append("DW_OP_gt"); break;
                    case DW_OP_le: sb.append("DW_OP_le"); break;
                    case DW_OP_lt: sb.append("DW_OP_lt"); break;
                    case DW_OP_ne: sb.append("DW_OP_ne"); break;
                    case DW_OP_skip:
                        sv = safeGetS(d, data, 2, end); data += 2;
                        sb.append("DW_OP_skip: ").append(sv); break;
                    case DW_OP_regx:
                        uv = readLeb(d, data, end, false); data += lebLen;
                        sb.append("DW_OP_regx: ").append(Long.toUnsignedString(uv))
                          .append(" (").append(regs.name((int) uv, true)).append(')');
                        break;
                    case DW_OP_fbreg:
                        nfb = true;
                        sv = readLeb(d, data, end, true); data += lebLen;
                        sb.append("DW_OP_fbreg: ").append(sv); break;
                    case DW_OP_bregx:
                        uv = readLeb(d, data, end, false); data += lebLen;
                        sv = readLeb(d, data, end, true); data += lebLen;
                        sb.append("DW_OP_bregx: ").append(Long.toUnsignedString(uv))
                          .append(" (").append(regs.name((int) uv, true)).append(") ").append(sv);
                        break;
                    case DW_OP_piece:
                        uv = readLeb(d, data, end, false); data += lebLen;
                        sb.append("DW_OP_piece: ").append(Long.toUnsignedString(uv)); break;
                    case DW_OP_deref_size:
                        uv = safeGet(d, data, 1, end); data += 1;
                        sb.append("DW_OP_deref_size: ").append(Long.toUnsignedString(uv)); break;
                    case DW_OP_xderef_size:
                        uv = safeGet(d, data, 1, end); data += 1;
                        sb.append("DW_OP_xderef_size: ").append(Long.toUnsignedString(uv)); break;
                    case DW_OP_nop: sb.append("DW_OP_nop"); break;
                    case DW_OP_push_object_address: sb.append("DW_OP_push_object_address"); break;
                    case DW_OP_call2:
                        sv = safeGetS(d, data, 2, end); data += 2;
                        sb.append("DW_OP_call2: <").append(hashHex(sv + cuOffset)).append('>'); break;
                    case DW_OP_call4:
                        sv = safeGetS(d, data, 4, end); data += 4;
                        sb.append("DW_OP_call4: <").append(hashHex(sv + cuOffset)).append('>'); break;
                    case DW_OP_call_ref:
                        if (dwarfVersion == -1) {
                            sb.append("(DW_OP_call_ref in frame info)");
                            return new Expr(sb.toString(), nfb);
                        }
                        if (dwarfVersion == 2) { uv = safeGet(d, data, pointerSize, end); data += pointerSize; }
                        else { uv = safeGet(d, data, offsetSize, end); data += offsetSize; }
                        sb.append("DW_OP_call_ref: <").append(hashHex(uv)).append('>'); break;
                    case DW_OP_form_tls_address: sb.append("DW_OP_form_tls_address"); break;
                    case DW_OP_call_frame_cfa: sb.append("DW_OP_call_frame_cfa"); break;
                    case DW_OP_bit_piece:
                        sb.append("DW_OP_bit_piece: ");
                        uv = readLeb(d, data, end, false); data += lebLen;
                        sb.append("size: ").append(Long.toUnsignedString(uv)).append(' ');
                        uv = readLeb(d, data, end, false); data += lebLen;
                        sb.append("offset: ").append(Long.toUnsignedString(uv)).append(' ');
                        break;
                    case DW_OP_stack_value: sb.append("DW_OP_stack_value"); break;
                    case DW_OP_implicit_value:
                        sb.append("DW_OP_implicit_value");
                        uv = readLeb(d, data, end, false); data += lebLen;
                        sb.append(displayBlock(d, data, uv, end, ' '));
                        data = dbPos;
                        break;
                    case DW_OP_GNU_push_tls_address:
                        sb.append("DW_OP_GNU_push_tls_address or DW_OP_HP_unknown"); break;
                    case DW_OP_GNU_uninit: sb.append("DW_OP_GNU_uninit"); break;
                    case DW_OP_GNU_encoded_addr: {
                        int encoding = 0;
                        if (data < end) encoding = d[data++] & 0xff;
                        long addr = getEncodedValue(d, data, encoding, secAddr, end);
                        data = gevPos;
                        sb.append(String.format("DW_OP_GNU_encoded_addr: fmt:%02x addr:", encoding))
                          .append(hexNs(addr, pointerSize));
                        break;
                    }
                    case DW_OP_implicit_pointer:
                    case DW_OP_GNU_implicit_pointer: {
                        String nm = (op == DW_OP_implicit_pointer)
                                ? "DW_OP_implicit_pointer" : "DW_OP_GNU_implicit_pointer";
                        if (dwarfVersion == -1) {
                            sb.append('(').append(nm).append(" in frame info)");
                            return new Expr(sb.toString(), nfb);
                        }
                        if (dwarfVersion == 2) { uv = safeGet(d, data, pointerSize, end); data += pointerSize; }
                        else { uv = safeGet(d, data, offsetSize, end); data += offsetSize; }
                        sv = readLeb(d, data, end, true); data += lebLen;
                        sb.append(nm).append(": <").append(hashHex(uv)).append("> ").append(sv);
                        break;
                    }
                    case DW_OP_entry_value:
                    case DW_OP_GNU_entry_value: {
                        uv = readLeb(d, data, end, false); data += lebLen;
                        if (Long.compareUnsigned(uv, end - data) > 0) uv = end - data;
                        sb.append(op == DW_OP_entry_value ? "DW_OP_entry_value" : "DW_OP_GNU_entry_value")
                          .append(": (");
                        Expr inner = decodeExpr(d, data, uv, pointerSize, offsetSize,
                                dwarfVersion, cuOffset, secAddr);
                        if (inner.needFrameBase) nfb = true;
                        sb.append(inner.text).append(')');
                        data += (int) uv;
                        break;
                    }
                    case DW_OP_const_type:
                    case DW_OP_GNU_const_type:
                        uv = readLeb(d, data, end, false); data += lebLen;
                        sb.append(op == DW_OP_const_type ? "DW_OP_const_type" : "DW_OP_GNU_const_type")
                          .append(": <").append(hashHex(cuOffset + uv)).append("> ");
                        uv = safeGet(d, data, 1, end); data += 1;
                        sb.append(displayBlock(d, data, uv, end, ' '));
                        data = dbPos;
                        break;
                    case DW_OP_regval_type:
                    case DW_OP_GNU_regval_type:
                        uv = readLeb(d, data, end, false); data += lebLen;
                        sb.append(op == DW_OP_regval_type ? "DW_OP_regval_type" : "DW_OP_GNU_regval_type")
                          .append(": ").append(Long.toUnsignedString(uv))
                          .append(" (").append(regs.name((int) uv, true)).append(')');
                        uv = readLeb(d, data, end, false); data += lebLen;
                        sb.append(" <").append(hashHex(cuOffset + uv)).append('>');
                        break;
                    case DW_OP_deref_type:
                    case DW_OP_GNU_deref_type:
                        uv = safeGet(d, data, 1, end); data += 1;
                        sb.append(op == DW_OP_deref_type ? "DW_OP_deref_type" : "DW_OP_GNU_deref_type")
                          .append(": ").append(uv);
                        uv = readLeb(d, data, end, false); data += lebLen;
                        sb.append(" <").append(hashHex(cuOffset + uv)).append('>');
                        break;
                    case DW_OP_convert:
                    case DW_OP_GNU_convert:
                        uv = readLeb(d, data, end, false); data += lebLen;
                        sb.append(op == DW_OP_convert ? "DW_OP_convert" : "DW_OP_GNU_convert")
                          .append(" <").append(hashHex(uv != 0 ? cuOffset + uv : uv)).append('>');
                        break;
                    case DW_OP_reinterpret:
                    case DW_OP_GNU_reinterpret:
                        uv = readLeb(d, data, end, false); data += lebLen;
                        sb.append(op == DW_OP_reinterpret ? "DW_OP_reinterpret" : "DW_OP_GNU_reinterpret")
                          .append(" <").append(hashHex(uv != 0 ? cuOffset + uv : uv)).append('>');
                        break;
                    case DW_OP_GNU_parameter_ref:
                        uv = safeGet(d, data, 4, end); data += 4;
                        sb.append("DW_OP_GNU_parameter_ref: <").append(hashHex(cuOffset + uv)).append('>');
                        break;
                    case DW_OP_addrx:
                        uv = readLeb(d, data, end, false); data += lebLen;
                        sb.append("DW_OP_addrx <").append(hashHex(uv)).append('>'); break;
                    case DW_OP_GNU_addr_index:
                        uv = readLeb(d, data, end, false); data += lebLen;
                        sb.append("DW_OP_GNU_addr_index <").append(hashHex(uv)).append('>'); break;
                    case DW_OP_GNU_const_index:
                        uv = readLeb(d, data, end, false); data += lebLen;
                        sb.append("DW_OP_GNU_const_index <").append(hashHex(uv)).append('>'); break;
                    case DW_OP_GNU_variable_value:
                        if (dwarfVersion == -1) {
                            sb.append("(DW_OP_GNU_variable_value in frame info)");
                            return new Expr(sb.toString(), nfb);
                        }
                        if (dwarfVersion == 2) { uv = safeGet(d, data, pointerSize, end); data += pointerSize; }
                        else { uv = safeGet(d, data, offsetSize, end); data += offsetSize; }
                        sb.append("DW_OP_GNU_variable_value: <").append(hashHex(uv)).append('>');
                        break;
                    case DW_OP_HP_is_value: sb.append("DW_OP_HP_is_value"); break;
                    case DW_OP_HP_fltconst4: sb.append("DW_OP_HP_fltconst4"); break;
                    case DW_OP_HP_fltconst8: sb.append("DW_OP_HP_fltconst8"); break;
                    case DW_OP_HP_mod_range: sb.append("DW_OP_HP_mod_range"); break;
                    case DW_OP_HP_unmod_range: sb.append("DW_OP_HP_unmod_range"); break;
                    case DW_OP_HP_tls: sb.append("DW_OP_HP_tls"); break;
                    case DW_OP_PGI_omp_thread_num: sb.append("DW_OP_PGI_omp_thread_num"); break;
                    default:
                        if (op >= DW_OP_lo_user && op <= DW_OP_hi_user)
                            sb.append("(User defined location op ").append(hashHex(op)).append(')');
                        else
                            sb.append("(Unknown location op ").append(hashHex(op)).append(')');
                        return new Expr(sb.toString(), nfb);
                }
            }
            if (data < end) sb.append("; ");
        }
        return new Expr(sb.toString(), nfb);
    }

    /* ================================================================== */
    /* Minimal .debug_info scan (binutils load_debug_info / do_loc path).  */
    /* ================================================================== */

    private static final int DW_FORM_addr = 0x01, DW_FORM_block2 = 0x03, DW_FORM_block4 = 0x04,
            DW_FORM_data2 = 0x05, DW_FORM_data4 = 0x06, DW_FORM_data8 = 0x07, DW_FORM_string = 0x08,
            DW_FORM_block = 0x09, DW_FORM_block1 = 0x0a, DW_FORM_data1 = 0x0b, DW_FORM_flag = 0x0c,
            DW_FORM_sdata = 0x0d, DW_FORM_strp = 0x0e, DW_FORM_udata = 0x0f,
            DW_FORM_ref_addr = 0x10, DW_FORM_ref1 = 0x11, DW_FORM_ref2 = 0x12, DW_FORM_ref4 = 0x13,
            DW_FORM_ref8 = 0x14, DW_FORM_ref_udata = 0x15, DW_FORM_indirect = 0x16,
            DW_FORM_sec_offset = 0x17, DW_FORM_exprloc = 0x18, DW_FORM_flag_present = 0x19,
            DW_FORM_strx = 0x1a, DW_FORM_addrx = 0x1b, DW_FORM_ref_sup4 = 0x1c,
            DW_FORM_strp_sup = 0x1d, DW_FORM_data16 = 0x1e, DW_FORM_line_strp = 0x1f,
            DW_FORM_ref_sig8 = 0x20, DW_FORM_implicit_const = 0x21, DW_FORM_loclistx = 0x22,
            DW_FORM_rnglistx = 0x23, DW_FORM_ref_sup8 = 0x24, DW_FORM_strx1 = 0x25,
            DW_FORM_strx2 = 0x26, DW_FORM_strx3 = 0x27, DW_FORM_strx4 = 0x28,
            DW_FORM_addrx1 = 0x29, DW_FORM_addrx2 = 0x2a, DW_FORM_addrx3 = 0x2b,
            DW_FORM_addrx4 = 0x2c, DW_FORM_GNU_addr_index = 0x1f01, DW_FORM_GNU_str_index = 0x1f02,
            DW_FORM_GNU_ref_alt = 0x1f20, DW_FORM_GNU_strp_alt = 0x1f21;

    private static final int DW_AT_location = 0x02, DW_AT_low_pc = 0x11, DW_AT_string_length = 0x19,
            DW_AT_return_addr = 0x2a, DW_AT_data_member_location = 0x38, DW_AT_frame_base = 0x40,
            DW_AT_segment = 0x46, DW_AT_static_link = 0x48, DW_AT_use_location = 0x4a,
            DW_AT_vtable_elem_location = 0x4d, DW_AT_call_value = 0x7e, DW_AT_call_target = 0x83,
            DW_AT_call_target_clobbered = 0x84, DW_AT_call_data_value = 0x86,
            DW_AT_GNU_call_site_value = 0x2111, DW_AT_GNU_call_site_data_value = 0x2112,
            DW_AT_GNU_call_site_target = 0x2113, DW_AT_GNU_call_site_target_clobbered = 0x2114,
            DW_AT_GNU_locviews = 0x2137,
            DW_AT_str_offsets_base = 0x72, DW_AT_addr_base = 0x73,
            DW_AT_rnglists_base = 0x74, DW_AT_loclists_base = 0x8c,
            DW_AT_GNU_addr_base = 0x2133;

    /** binutils' DEBUG_INFO_UNAVAILABLE sentinel ((unsigned int) -1). */
    public static final long DEBUG_INFO_UNAVAILABLE = 0xffffffffL;

    private static final int DW_TAG_entry_point = 0x03, DW_TAG_compile_unit = 0x11,
            DW_TAG_subprogram = 0x2e, DW_TAG_skeleton_unit = 0x4a;

    /** Per compilation unit info needed to interpret location lists. */
    public static final class CuInfo {
        public long cuOffset;
        public int pointerSize = 8, offsetSize = 4, version;
        public long baseAddress;
        /** DW_AT_addr_base; DEBUG_INFO_UNAVAILABLE until seen. */
        public long addrBase = DEBUG_INFO_UNAVAILABLE;
        /** DW_AT_loclists_base; 0 until seen. */
        public long loclistsBase;
        public long rnglistsBase = DEBUG_INFO_UNAVAILABLE;
        public final List<Long> locOffsets = new ArrayList<>();
        public final List<Long> locViews = new ArrayList<>();
        public final List<Integer> haveFrameBase = new ArrayList<>();
    }

    private static final class AbbrevAttr { int attribute, form; long implicitConst; }

    private static final class AbbrevEntry {
        int tag;
        boolean children;
        final List<AbbrevAttr> attrs = new ArrayList<>();
    }

    private List<CuInfo> cus;
    private boolean cusLoaded;
    private int hfb;              /* binutils' have_frame_base */
    private int frameBaseLevel;
    private int fPos;             /* cursor used by readForm */

    private Map<Long, AbbrevEntry> parseAbbrev(byte[] ab, int start, int end) {
        Map<Long, AbbrevEntry> m = new HashMap<>();
        int p = Math.max(0, Math.min(start, end));
        while (p < end) {
            long num = readLeb(ab, p, end, false); p += lebLen;
            if (num == 0) break;
            AbbrevEntry e = new AbbrevEntry();
            e.tag = (int) readLeb(ab, p, end, false); p += lebLen;
            if (p >= end) break;
            e.children = (ab[p++] & 0xff) != 0;
            while (p < end) {
                AbbrevAttr a = new AbbrevAttr();
                a.attribute = (int) readLeb(ab, p, end, false); p += lebLen;
                a.form = (int) readLeb(ab, p, end, false); p += lebLen;
                if (a.form == DW_FORM_implicit_const) {
                    a.implicitConst = readLeb(ab, p, end, true); p += lebLen;
                }
                if (a.attribute == 0 && a.form == 0) break;
                e.attrs.add(a);
            }
            m.putIfAbsent(num, e);
        }
        return m;
    }

    /** Reads one attribute value, advancing {@link #fPos}; returns binutils' uvalue. */
    private long readForm(byte[] d, int end, int form, long implicitConst,
                          int pointerSize, int offsetSize, int version) {
        long uvalue = 0;
        int p = fPos;
        boolean known = true;
        switch (form) {
            case DW_FORM_ref_addr: {
                int n = (version == 2) ? pointerSize : offsetSize;
                uvalue = safeGet(d, p, n, end); p += n; break;
            }
            case DW_FORM_addr: uvalue = safeGet(d, p, pointerSize, end); p += pointerSize; break;
            case DW_FORM_strp: case DW_FORM_line_strp: case DW_FORM_sec_offset:
            case DW_FORM_GNU_ref_alt: case DW_FORM_GNU_strp_alt: case DW_FORM_strp_sup:
                uvalue = safeGet(d, p, offsetSize, end); p += offsetSize; break;
            case DW_FORM_flag_present: uvalue = 1; break;
            case DW_FORM_ref1: case DW_FORM_flag: case DW_FORM_data1:
            case DW_FORM_strx1: case DW_FORM_addrx1:
                uvalue = safeGet(d, p, 1, end); p += 1; break;
            case DW_FORM_ref2: case DW_FORM_data2: case DW_FORM_strx2: case DW_FORM_addrx2:
                uvalue = safeGet(d, p, 2, end); p += 2; break;
            case DW_FORM_strx3: case DW_FORM_addrx3:
                uvalue = safeGet(d, p, 3, end); p += 3; break;
            case DW_FORM_ref4: case DW_FORM_data4: case DW_FORM_strx4:
            case DW_FORM_addrx4: case DW_FORM_ref_sup4:
                uvalue = safeGet(d, p, 4, end); p += 4; break;
            case DW_FORM_ref8: case DW_FORM_data8: case DW_FORM_ref_sig8: case DW_FORM_ref_sup8:
                uvalue = safeGet(d, p, 8, end); p += 8; break;
            case DW_FORM_data16: uvalue = safeGet(d, p, 8, end); p += 16; break;
            case DW_FORM_sdata: uvalue = readLeb(d, p, end, true); p += lebLen; break;
            case DW_FORM_GNU_str_index: case DW_FORM_strx: case DW_FORM_ref_udata:
            case DW_FORM_udata: case DW_FORM_GNU_addr_index: case DW_FORM_addrx:
            case DW_FORM_loclistx: case DW_FORM_rnglistx:
                uvalue = readLeb(d, p, end, false); p += lebLen; break;
            case DW_FORM_implicit_const: uvalue = implicitConst; break;
            case DW_FORM_indirect: {
                int f2 = (int) readLeb(d, p, end, false); p += lebLen;
                long ic = 0;
                if (f2 == DW_FORM_implicit_const) { ic = readLeb(d, p, end, true); p += lebLen; }
                fPos = p;
                return readForm(d, end, f2, ic, pointerSize, offsetSize, version);
            }
            case DW_FORM_string: {
                int q = p;
                while (q < end && q < d.length && d[q] != 0) q++;
                p = q;
                if (p < end) p++;
                break;
            }
            case DW_FORM_block: case DW_FORM_exprloc:
                uvalue = readLeb(d, p, end, false); p += lebLen;
                p = blockEndOf(p, uvalue, end);
                break;
            case DW_FORM_block1:
                uvalue = safeGet(d, p, 1, end); p += 1;
                p = blockEndOf(p, uvalue, end);
                break;
            case DW_FORM_block2:
                uvalue = safeGet(d, p, 2, end); p += 2;
                p = blockEndOf(p, uvalue, end);
                break;
            case DW_FORM_block4:
                uvalue = safeGet(d, p, 4, end); p += 4;
                p = blockEndOf(p, uvalue, end);
                break;
            default:
                known = false;
                break;
        }
        if (!known) p++;              /* binutils consumes one byte and warns */
        fPos = p;
        return uvalue;
    }

    private int blockEndOf(int blockStart, long uvalue, int end) {
        if (blockStart >= end) return end;
        long max = end - blockStart;
        if (Long.compareUnsigned(uvalue, max) > 0) uvalue = max;
        return blockStart + (int) uvalue;
    }

    /**
     * Scans {@code .debug_info} for the per-CU data that location lists need:
     * address size, offset size, version, CU base address, and the ordered list
     * of {@code .debug_loc} offsets referenced by location attributes.  Returns
     * {@code null} when the information is unavailable, which is what makes
     * binutils skip the {@code .debug_loc} dump entirely.
     */
    public List<CuInfo> debugInfoCus() {
        if (cusLoaded) return cus;
        cusLoaded = true;
        cus = null;
        byte[] info = elf.sectionData(".debug_info");
        byte[] ab = elf.sectionData(".debug_abbrev");
        if (info == null || info.length == 0 || ab == null) return null;

        List<CuInfo> list = new ArrayList<>();
        Map<Long, Map<Long, AbbrevEntry>> abbrevCache = new HashMap<>();
        hfb = 0;
        frameBaseLevel = 0;
        final int end = info.length;
        int start = 0;
        while (start < end) {
            int cuOffset = start;
            int hdr = start;
            long cuLength = safeGet(info, hdr, 4, end); hdr += 4;
            int offsetSize;
            if (cuLength == 0xffffffffL) {
                cuLength = safeGet(info, hdr, 8, end); hdr += 8;
                offsetSize = 8;
            } else {
                offsetSize = 4;
            }
            int endCu = (int) Math.min((long) hdr + cuLength, end);
            if (endCu <= hdr) break;
            int version = (int) safeGet(info, hdr, 2, endCu); hdr += 2;
            int unitType = 0x01;
            int pointerSize = -1;
            boolean doTypes = false;
            if (version >= 5) {
                unitType = (int) safeGet(info, hdr, 1, endCu); hdr += 1;
                doTypes = (unitType == 0x02);
                pointerSize = (int) safeGet(info, hdr, 1, endCu); hdr += 1;
            }
            long abbrevOffset = safeGet(info, hdr, offsetSize, endCu); hdr += offsetSize;
            if (version < 5) { pointerSize = (int) safeGet(info, hdr, 1, endCu); hdr += 1; }
            if (unitType == 0x05 || unitType == 0x04) hdr += 8;     /* dwo_id */
            if (pointerSize < 2 || pointerSize > 8) pointerSize = offsetSize;
            if (doTypes) { hdr += 8; hdr += offsetSize; }

            CuInfo cu = new CuInfo();
            list.add(cu);
            CuInfo rec = null;
            if (!doTypes) {
                cu.pointerSize = pointerSize;
                cu.offsetSize = offsetSize;
                cu.version = version;
                cu.cuOffset = cuOffset;
                rec = cu;
            }

            int tags = hdr;
            start = endCu;
            if (version < 2 || version > 5) continue;
            if (unitType != 0x01 && unitType != 0x03 && unitType != 0x02
                    && unitType != 0x05 && unitType != 0x04) continue;

            final byte[] abf = ab;
            Map<Long, AbbrevEntry> abbrevs = abbrevCache.computeIfAbsent(abbrevOffset,
                    k -> parseAbbrev(abf, (int) Math.min(k, abf.length), abf.length));

            int level = 0;
            boolean needBaseAddress = false;
            while (tags < endCu) {
                long abbrevNumber = readLeb(info, tags, endCu, false); tags += lebLen;
                if (abbrevNumber == 0) {
                    if (level == 0 && endCu == end) {
                        boolean allZero = true;
                        for (int chk = tags; chk < endCu; chk++)
                            if (info[chk] != 0) { allZero = false; break; }
                        if (allZero) break;
                    }
                    --level;
                    continue;
                }
                AbbrevEntry ent = abbrevs.get(abbrevNumber);
                if (ent == null) break;
                /* binutils read_bases(): on a DWARF5 top DIE the *_base
                   attributes are read ahead so that attributes referencing
                   them in the same DIE resolve correctly. */
                if (rec != null && version >= 5 && level == 0) {
                    int look = tags;
                    for (AbbrevAttr at : ent.attrs) {
                        fPos = look;
                        long uv = readForm(info, endCu, at.form, at.implicitConst,
                                pointerSize, offsetSize, version);
                        look = fPos;
                        if (at.form == DW_FORM_sec_offset) {
                            if (at.attribute == DW_AT_addr_base
                                    || at.attribute == DW_AT_GNU_addr_base) rec.addrBase = uv;
                            else if (at.attribute == DW_AT_rnglists_base) rec.rnglistsBase = uv;
                            else if (at.attribute == DW_AT_loclists_base) rec.loclistsBase = uv;
                        }
                    }
                }
                switch (ent.tag) {
                    case DW_TAG_compile_unit:
                    case DW_TAG_skeleton_unit: needBaseAddress = true; break;
                    case DW_TAG_entry_point: needBaseAddress = false; hfb = 0; break;
                    case DW_TAG_subprogram:
                        needBaseAddress = false;
                        if (level <= frameBaseLevel) hfb = 0;
                        break;
                    default: needBaseAddress = false; break;
                }
                for (AbbrevAttr at : ent.attrs) {
                    fPos = tags;
                    long uvalue = readForm(info, endCu, at.form, at.implicitConst,
                            pointerSize, offsetSize, version);
                    if (fPos <= tags && at.form != DW_FORM_flag_present
                            && at.form != DW_FORM_implicit_const) {
                        tags = fPos > tags ? fPos : tags + 1;   /* guarantee progress */
                    } else {
                        tags = fPos;
                    }
                    recordAttr(rec, at.attribute, at.form, uvalue, level, needBaseAddress,
                            version, pointerSize, offsetSize);
                }
                if (rec != null) {
                    while (rec.locOffsets.size() > rec.locViews.size()) rec.locViews.add(-1L);
                    while (rec.locViews.size() > rec.locOffsets.size())
                        rec.locViews.remove(rec.locViews.size() - 1);
                }
                if (ent.children) ++level;
            }
        }
        cus = list.isEmpty() ? null : list;
        return cus;
    }

    private void recordAttr(CuInfo rec, int attribute, int form, long uvalue,
                            int level, boolean needBaseAddress, int version,
                            int pointerSize, int offsetSize) {
        if (attribute == DW_AT_frame_base) { hfb = 1; frameBaseLevel = level; }
        if (rec == null) return;
        switch (attribute) {
            case DW_AT_frame_base:
            case DW_AT_location:
            case DW_AT_GNU_locviews:
            case DW_AT_string_length:
            case DW_AT_return_addr:
            case DW_AT_data_member_location:
            case DW_AT_vtable_elem_location:
            case DW_AT_segment:
            case DW_AT_static_link:
            case DW_AT_use_location:
            case DW_AT_call_value:
            case DW_AT_GNU_call_site_value:
            case DW_AT_call_data_value:
            case DW_AT_GNU_call_site_data_value:
            case DW_AT_call_target:
            case DW_AT_GNU_call_site_target:
            case DW_AT_call_target_clobbered:
            case DW_AT_GNU_call_site_target_clobbered:
                if ((version < 4 && (form == DW_FORM_data4 || form == DW_FORM_data8))
                        || form == DW_FORM_sec_offset || form == DW_FORM_loclistx) {
                    int num = rec.locOffsets.size();
                    while (rec.haveFrameBase.size() <= num) rec.haveFrameBase.add(0);
                    rec.haveFrameBase.set(num, hfb);
                    /* binutils resolves DW_FORM_loclistx using the running
                       count as the index, not the attribute's own value. */
                    if (form == DW_FORM_loclistx)
                        uvalue = fetchIndexedOffset(num, rec.loclistsBase, offsetSize);
                    if (attribute != DW_AT_GNU_locviews) {
                        if (rec.locOffsets.size() <= rec.locViews.size())
                            rec.locOffsets.add(uvalue);
                    } else {
                        if (rec.locViews.size() <= num) rec.locViews.add(uvalue);
                    }
                }
                break;
            case DW_AT_low_pc:
                if (needBaseAddress) {
                    if (form == DW_FORM_addrx || form == DW_FORM_addrx1
                            || form == DW_FORM_addrx2 || form == DW_FORM_addrx3
                            || form == DW_FORM_addrx4 || form == DW_FORM_GNU_addr_index)
                        uvalue = fetchIndexedAddr(rec.addrBase + uvalue * pointerSize, pointerSize);
                    rec.baseAddress = uvalue;
                }
                break;
            case DW_AT_addr_base:
            case DW_AT_GNU_addr_base:
                rec.addrBase = uvalue;
                break;
            case DW_AT_loclists_base:
                rec.loclistsBase = uvalue;
                break;
            default:
                break;
        }
    }

    /* ================================================================== */
    /* .debug_loc rendering (binutils display_debug_loc/display_loc_list). */
    /* ================================================================== */

    /** Section names readelf routes to {@code display_debug_loc}. */
    public static boolean isLocSectionName(String n) {
        if (n == null) return false;
        return n.equals(".debug_loc") || n.equals(".zdebug_loc") || n.equals(".debug_loc.dwo")
                || n.equals(".debug_loclists") || n.equals(".zdebug_loclists")
                || n.equals(".debug_loclists.dwo");
    }

    private static boolean isMaxAddress(long addr, int pointerSize) {
        long mask = (pointerSize >= 8) ? -1L : ((1L << (pointerSize * 8)) - 1);
        return (addr & mask) == mask;
    }

    /**
     * Renders {@code readelf --debug-dump=loc} for one {@code .debug_loc}
     * section, or {@code null} when there is nothing to print (no usable
     * {@code .debug_info}, or a {@code .debug_loclists} section, which uses a
     * different encoding and is not handled here).
     */
    public List<String> locLines(String sectionName, byte[] d, long secAddr) {
        if (sectionName.contains("loclists")) return loclistsLines(sectionName, d, secAddr);
        List<CuInfo> cl = debugInfoCus();
        if (cl == null || cl.isEmpty()) return null;

        long lastOffset = 0, lastView = 0;
        int first = 0;
        boolean seenFirst = false, locsSorted = true;
        for (CuInfo cu : cl) {
            int num = cu.locOffsets.size();
            if (locsSorted && num != 0) {
                int j;
                if (!seenFirst) {
                    lastOffset = cu.locOffsets.get(0);
                    lastView = cu.locViews.get(0);
                    first = cl.indexOf(cu);
                    seenFirst = true;
                    j = 1;
                } else {
                    j = 0;
                }
                for (; j < num; j++) {
                    long o = cu.locOffsets.get(j), v = cu.locViews.get(j);
                    if (Long.compareUnsigned(lastOffset, o) > 0
                            || (lastOffset == o && Long.compareUnsigned(lastView, v) > 0)) {
                        locsSorted = false;
                        break;
                    }
                    lastOffset = o;
                    lastView = v;
                }
            }
        }
        if (!seenFirst) return null;

        List<String> out = new ArrayList<>();
        out.add("Contents of the " + sectionName + " section:");
        out.add("");
        out.add("    Offset   Begin            End              Expression");

        for (int i = first; i < cl.size(); i++) {
            CuInfo cu = cl.get(i);
            int n = cu.locOffsets.size();
            Integer[] order = new Integer[n];
            for (int k = 0; k < n; k++) order[k] = k;
            if (!locsSorted) {
                final CuInfo fcu = cu;
                java.util.Arrays.sort(order, (x, y) -> {
                    int c = Long.compareUnsigned(fcu.locOffsets.get(x), fcu.locOffsets.get(y));
                    if (c != 0) return c;
                    return Long.compareUnsigned(fcu.locViews.get(x), fcu.locViews.get(y));
                });
            }
            for (int k = 0; k < n; k++) {
                int j = order[k];
                if (k > 0) {
                    int pj = order[k - 1];
                    if (cu.locOffsets.get(pj).equals(cu.locOffsets.get(j))
                            && cu.locViews.get(pj).equals(cu.locViews.get(j))) continue;
                }
                long offset = cu.locOffsets.get(j);
                if (Long.compareUnsigned(offset, d.length) >= 0) continue;
                boolean hasFrameBase = j < cu.haveFrameBase.size() && cu.haveFrameBase.get(j) != 0;
                locList(out, d, offset, cu, cu.baseAddress, hasFrameBase, secAddr);
            }
        }
        return out;
    }

    private void locList(List<String> out, byte[] d, long offset, CuInfo cu,
                         long baseAddress, boolean hasFrameBase, long secAddr) {
        final int sectionEnd = d.length;
        final int startPtr0 = (int) offset;
        int start = startPtr0;
        final int ps = cu.pointerSize;
        if (ps < 2 || ps > 8) return;
        while (true) {
            long off = offset + (start - startPtr0);
            if (2L * ps > sectionEnd - start) break;
            long begin = safeGet(d, start, ps, sectionEnd); start += ps;
            long endv = safeGet(d, start, ps, sectionEnd); start += ps;

            if (begin == 0 && endv == 0) {
                out.add("    " + hex(off, 4) + "<End of list>");
                break;
            }
            if (isMaxAddress(begin, ps) && !isMaxAddress(endv, ps)) {
                baseAddress = endv;
                out.add("    " + hex(off, 4) + hex(begin, ps) + hex(endv, ps) + "(base address)");
                continue;
            }
            if (2 > sectionEnd - start) break;
            int length = (int) safeGet(d, start, 2, sectionEnd); start += 2;
            if (length > sectionEnd - start) break;

            StringBuilder sb = new StringBuilder();
            sb.append("    ").append(hex(off, 4))
              .append(hex(begin + baseAddress, ps)).append(hex(endv + baseAddress, ps)).append('(');
            Expr e = decodeExpr(d, start, length, ps, cu.offsetSize, cu.version, cu.cuOffset, secAddr);
            sb.append(e.text).append(')');
            if (e.needFrameBase && !hasFrameBase) sb.append(" [without DW_AT_frame_base]");
            if (begin == endv) sb.append(" (start == end)");
            else if (Long.compareUnsigned(begin, endv) > 0) sb.append(" (start > end)");
            out.add(sb.toString());
            start += length;
        }
    }

    /* ================================================================== */
    /* .debug_addr / indexed offset resolution                            */
    /* ================================================================== */

    private byte[] addrSec;
    private boolean addrSecLoaded;
    private byte[] loclistsSec;
    private boolean loclistsSecLoaded;
    private byte[] strSec;
    private boolean strSecLoaded;

    private byte[] debugAddr() {
        if (!addrSecLoaded) { addrSecLoaded = true; addrSec = elf.sectionData(".debug_addr"); }
        return addrSec;
    }

    private byte[] debugLoclists() {
        if (!loclistsSecLoaded) {
            loclistsSecLoaded = true;
            loclistsSec = elf.sectionData(".debug_loclists");
        }
        return loclistsSec;
    }

    private byte[] debugStr() {
        if (!strSecLoaded) { strSecLoaded = true; strSec = elf.sectionData(".debug_str"); }
        return strSec;
    }

    /** binutils {@code fetch_indexed_addr}: read an address out of .debug_addr. */
    private long fetchIndexedAddr(long offset, int numBytes) {
        byte[] a = debugAddr();
        if (a == null) return 0;
        if (Long.compareUnsigned(offset + numBytes, a.length) > 0) return 0;
        if (offset < 0) return 0;
        return byteGet(a, (int) offset, numBytes);
    }

    /**
     * binutils {@code fetch_indexed_offset}: resolve DW_FORM_loclistx through the
     * offset-entry table that {@code loclists_base} points at.  Note the odd
     * {@code >=} bound check and that the table base is added to the result.
     */
    private long fetchIndexedOffset(long idx, long baseAddress, int offsetSize) {
        byte[] a = debugLoclists();
        if (a == null) return -1;
        if (a.length < 4) return -1;
        long offsetOfOffset = baseAddress + idx * offsetSize;
        if (Long.compareUnsigned(offsetOfOffset + offsetSize, a.length) >= 0) return -1;
        return baseAddress + byteGet(a, (int) offsetOfOffset, offsetSize);
    }

    /** binutils {@code fetch_indirect_string}. */
    private String fetchIndirectString(long offset) {
        byte[] a = debugStr();
        if (a == null) return "<no .debug_str section>";
        if (Long.compareUnsigned(offset, a.length) >= 0) return "<offset is too big>";
        int o = (int) offset, e = o;
        while (e < a.length && a[e] != 0) e++;
        if (e == a.length) return "<no NUL byte at end of .debug_str section>";
        return new String(a, o, e - o, java.nio.charset.StandardCharsets.UTF_8);
    }

    /* ================================================================== */
    /* .debug_loclists (DWARF 5)                                          */
    /* ================================================================== */

    private static final int DW_LLE_end_of_list = 0x00, DW_LLE_base_addressx = 0x01,
            DW_LLE_startx_endx = 0x02, DW_LLE_startx_length = 0x03,
            DW_LLE_offset_pair = 0x04, DW_LLE_default_location = 0x05,
            DW_LLE_base_address = 0x06, DW_LLE_start_end = 0x07,
            DW_LLE_start_length = 0x08, DW_LLE_view_pair = 0x09;

    /**
     * Renders {@code readelf --debug-dump=loc} for a DWARF 5
     * {@code .debug_loclists} section.
     */
    private List<String> loclistsLines(String sectionName, byte[] d, long secAddr) {
        final int end = d.length;
        /* binutils validates the first unit header before doing anything else. */
        int p = 0;
        long llLength = safeGet(d, p, 4, end); p += 4;
        if (llLength == 0xffffffffL) { llLength = safeGet(d, p, 8, end); p += 8; }
        int llVersion = (int) safeGet(d, p, 2, end); p += 2;
        if (llVersion != 5) return null;
        p += 1;                                    /* address_size */
        int segSel = (int) safeGet(d, p, 1, end); p += 1;
        if (segSel != 0) return null;

        List<CuInfo> cl = debugInfoCus();
        if (cl == null || cl.isEmpty()) return null;

        long lastOffset = 0, lastView = 0;
        int first = 0;
        boolean seenFirst = false, locsSorted = true;
        for (int i = 0; i < cl.size(); i++) {
            CuInfo cu = cl.get(i);
            int num = cu.locOffsets.size();
            if (locsSorted && num != 0) {
                int j;
                if (!seenFirst) {
                    lastOffset = cu.locOffsets.get(0);
                    lastView = cu.locViews.get(0);
                    first = i;
                    seenFirst = true;
                    j = 1;
                } else {
                    j = 0;
                }
                for (; j < num; j++) {
                    long o = cu.locOffsets.get(j), v = cu.locViews.get(j);
                    if (Long.compareUnsigned(lastOffset, o) > 0
                            || (lastOffset == o && Long.compareUnsigned(lastView, v) > 0)) {
                        locsSorted = false;
                        break;
                    }
                    lastOffset = o;
                    lastView = v;
                }
            }
        }

        List<String> out = new ArrayList<>();
        out.add("Contents of the " + sectionName + " section:");
        out.add("");

        long nextHeaderOffset = 0;
        for (int i = first; i < cl.size(); i++) {
            CuInfo cu = cl.get(i);
            int n = cu.locOffsets.size();
            Integer[] order = new Integer[n];
            for (int k = 0; k < n; k++) order[k] = k;
            if (!locsSorted) {
                final CuInfo fcu = cu;
                java.util.Arrays.sort(order, (x, y) -> {
                    int c = Long.compareUnsigned(fcu.locOffsets.get(x), fcu.locOffsets.get(y));
                    if (c != 0) return c;
                    return Long.compareUnsigned(fcu.locViews.get(x), fcu.locViews.get(y));
                });
            }
            if (cu.version == 5) {
                long offset = 0;
                if (n > 0) offset = cu.locOffsets.get(order[0]);
                if (Long.compareUnsigned(nextHeaderOffset, offset) < 0) {
                    while (Long.compareUnsigned(nextHeaderOffset, offset) < 0) {
                        long nh = emitLoclistsUnitHeader(out, d, nextHeaderOffset);
                        if (nh == -1) return out;
                        nextHeaderOffset = nh;
                    }
                    out.add("    Offset   Begin            End              Expression");
                }
            }
            for (int k = 0; k < n; k++) {
                int j = order[k];
                if (k > 0) {
                    int pj = order[k - 1];
                    if (cu.locOffsets.get(pj).equals(cu.locOffsets.get(j))
                            && cu.locViews.get(pj).equals(cu.locViews.get(j))) continue;
                }
                long offset = cu.locOffsets.get(j);
                if (Long.compareUnsigned(offset, d.length) >= 0) continue;
                boolean hfbFlag = j < cu.haveFrameBase.size() && cu.haveFrameBase.get(j) != 0;
                loclistsList(out, d, offset, cu, cu.baseAddress, hfbFlag, secAddr);
            }
        }
        return out;
    }

    /** binutils {@code display_loclists_unit_header}; returns the next header offset. */
    private long emitLoclistsUnitHeader(List<String> out, byte[] d, long headerOffset) {
        final int end = d.length;
        int p = (int) headerOffset;
        out.add("Table at Offset " + hashHex(headerOffset));
        long length = safeGet(d, p, 4, end); p += 4;
        boolean is64 = false;
        if (length == 0xffffffffL) { is64 = true; length = safeGet(d, p, 8, end); p += 8; }
        int version = (int) safeGet(d, p, 2, end); p += 2;
        int addressSize = (int) safeGet(d, p, 1, end); p += 1;
        int segSel = (int) safeGet(d, p, 1, end); p += 1;
        long offsetCount = safeGet(d, p, 4, end); p += 4;

        out.add("  Length:          " + hashHex(length));
        out.add("  DWARF version:   " + version);
        out.add("  Address size:    " + addressSize);
        out.add("  Segment size:    " + segSel);
        out.add("  Offset entries:  " + Long.toUnsignedString(offsetCount));

        if (segSel != 0) return -1;

        if (offsetCount != 0) {
            out.add("");
            out.add("   Offset Entries starting at " + hashHex(p) + ":");
            for (long i = 0; i < offsetCount; i++) {
                long entry = safeGet(d, p, is64 ? 8 : 4, end);
                p += is64 ? 8 : 4;
                out.add(String.format("    [%6d] ", i) + hashHex(entry));
            }
        }
        out.add("");
        return headerOffset + length + (is64 ? 12 : 4);
    }

    /** binutils {@code display_loclists_list}. */
    private void loclistsList(List<String> out, byte[] d, long offset, CuInfo cu,
                              long baseAddress, boolean hasFrameBase, long secAddr) {
        final int sectionEnd = d.length;
        final int startPtr0 = (int) offset;
        int start = startPtr0;
        final int ps = cu.pointerSize;
        if (ps < 2 || ps > 8) return;
        long begin = -1, end = -1;

        while (true) {
            long off = offset + (start - startPtr0);
            if (start + 1 > sectionEnd) break;
            StringBuilder line = new StringBuilder();
            line.append("    ").append(hex(off, 4));
            int llet = (int) safeGet(d, start, 1, sectionEnd); start += 1;

            switch (llet) {
                case DW_LLE_end_of_list:
                    out.add(line.append("<End of list>").toString());
                    return;
                case DW_LLE_base_addressx: {
                    long idx = readLeb(d, start, sectionEnd, false); start += lebLen;
                    line.append(hex(idx, ps)).append("(index into .debug_addr) ");
                    baseAddress = fetchIndexedAddr(cu.addrBase + idx * ps, ps);
                    line.append(hex(baseAddress, ps)).append("(base address)");
                    out.add(line.toString());
                    continue;
                }
                case DW_LLE_startx_endx: {
                    long idx = readLeb(d, start, sectionEnd, false); start += lebLen;
                    begin = fetchIndexedAddr(cu.addrBase + idx * ps, ps);
                    idx = readLeb(d, start, sectionEnd, false); start += lebLen;
                    end = fetchIndexedAddr(cu.addrBase + idx * ps, ps);
                    break;
                }
                case DW_LLE_startx_length: {
                    long idx = readLeb(d, start, sectionEnd, false); start += lebLen;
                    begin = fetchIndexedAddr(cu.addrBase + idx * ps, ps);
                    end = readLeb(d, start, sectionEnd, false); start += lebLen;
                    end += begin;
                    break;
                }
                case DW_LLE_default_location:
                    begin = end = 0;
                    break;
                case DW_LLE_offset_pair:
                    begin = readLeb(d, start, sectionEnd, false); start += lebLen;
                    begin += baseAddress;
                    end = readLeb(d, start, sectionEnd, false); start += lebLen;
                    end += baseAddress;
                    break;
                case DW_LLE_base_address:
                    baseAddress = safeGet(d, start, ps, sectionEnd); start += ps;
                    line.append(hex(baseAddress, ps)).append("(base address)");
                    out.add(line.toString());
                    continue;
                case DW_LLE_start_end:
                    begin = safeGet(d, start, ps, sectionEnd); start += ps;
                    end = safeGet(d, start, ps, sectionEnd); start += ps;
                    break;
                case DW_LLE_start_length:
                    begin = safeGet(d, start, ps, sectionEnd); start += ps;
                    end = readLeb(d, start, sectionEnd, false); start += lebLen;
                    end += begin;
                    break;
                case DW_LLE_view_pair:
                    /* GNU extension; readelf prints the views and loops. */
                    readLeb(d, start, sectionEnd, false); start += lebLen;
                    readLeb(d, start, sectionEnd, false); start += lebLen;
                    continue;
                default:
                    return;                       /* invalid entry type */
            }

            if (start == sectionEnd) break;
            long length = readLeb(d, start, sectionEnd, false); start += lebLen;
            if (Long.compareUnsigned(length, sectionEnd - start) > 0) break;

            line.append(hex(begin, ps)).append(hex(end, ps)).append('(');
            Expr e = decodeExpr(d, start, length, ps, cu.offsetSize, cu.version,
                    cu.cuOffset, secAddr);
            line.append(e.text).append(')');
            if (e.needFrameBase && !hasFrameBase) line.append(" [without DW_AT_frame_base]");
            if (begin == end) line.append(" (start == end)");
            else if (Long.compareUnsigned(begin, end) > 0) line.append(" (start > end)");
            out.add(line.toString());
            start += length;
        }
    }

    /* ================================================================== */
    /* .debug_names (DWARF 5)                                             */
    /* ================================================================== */

    /** Section names readelf routes to the {@code gdb_index} keyword. */
    public static boolean isNamesSectionName(String n) {
        return ".debug_names".equals(n);
    }

    private static final Map<Integer, String> IDX_NAMES = new HashMap<>();
    static {
        IDX_NAMES.put(1, "DW_IDX_compile_unit");
        IDX_NAMES.put(2, "DW_IDX_type_unit");
        IDX_NAMES.put(3, "DW_IDX_die_offset");
        IDX_NAMES.put(4, "DW_IDX_parent");
        IDX_NAMES.put(5, "DW_IDX_type_hash");
        IDX_NAMES.put(0x2000, "DW_IDX_GNU_internal");
        IDX_NAMES.put(0x2001, "DW_IDX_GNU_external");
        IDX_NAMES.put(0x2002, "DW_IDX_GNU_main");
        IDX_NAMES.put(0x2003, "DW_IDX_GNU_language");
        IDX_NAMES.put(0x2004, "DW_IDX_GNU_linkage_name");
    }

    private static String getIdxName(long idx) {
        String n = IDX_NAMES.get((int) idx);
        if (n != null) return n;
        return "Unknown IDX value: " + Long.toHexString(idx);
    }

    private static final Map<Integer, String> TAG_NAMES = new HashMap<>();
    private static void tag(int v, String n) { TAG_NAMES.put(v, n); }
    static {
        tag(0x01, "DW_TAG_array_type"); tag(0x02, "DW_TAG_class_type");
        tag(0x03, "DW_TAG_entry_point"); tag(0x04, "DW_TAG_enumeration_type");
        tag(0x05, "DW_TAG_formal_parameter"); tag(0x08, "DW_TAG_imported_declaration");
        tag(0x0a, "DW_TAG_label"); tag(0x0b, "DW_TAG_lexical_block");
        tag(0x0d, "DW_TAG_member"); tag(0x0f, "DW_TAG_pointer_type");
        tag(0x10, "DW_TAG_reference_type"); tag(0x11, "DW_TAG_compile_unit");
        tag(0x12, "DW_TAG_string_type"); tag(0x13, "DW_TAG_structure_type");
        tag(0x15, "DW_TAG_subroutine_type"); tag(0x16, "DW_TAG_typedef");
        tag(0x17, "DW_TAG_union_type"); tag(0x18, "DW_TAG_unspecified_parameters");
        tag(0x19, "DW_TAG_variant"); tag(0x1a, "DW_TAG_common_block");
        tag(0x1b, "DW_TAG_common_inclusion"); tag(0x1c, "DW_TAG_inheritance");
        tag(0x1d, "DW_TAG_inlined_subroutine"); tag(0x1e, "DW_TAG_module");
        tag(0x1f, "DW_TAG_ptr_to_member_type"); tag(0x20, "DW_TAG_set_type");
        tag(0x21, "DW_TAG_subrange_type"); tag(0x22, "DW_TAG_with_stmt");
        tag(0x23, "DW_TAG_access_declaration"); tag(0x24, "DW_TAG_base_type");
        tag(0x25, "DW_TAG_catch_block"); tag(0x26, "DW_TAG_const_type");
        tag(0x27, "DW_TAG_constant"); tag(0x28, "DW_TAG_enumerator");
        tag(0x29, "DW_TAG_file_type"); tag(0x2a, "DW_TAG_friend");
        tag(0x2b, "DW_TAG_namelist"); tag(0x2c, "DW_TAG_namelist_item");
        tag(0x2d, "DW_TAG_packed_type"); tag(0x2e, "DW_TAG_subprogram");
        tag(0x2f, "DW_TAG_template_type_param"); tag(0x30, "DW_TAG_template_value_param");
        tag(0x31, "DW_TAG_thrown_type"); tag(0x32, "DW_TAG_try_block");
        tag(0x33, "DW_TAG_variant_part"); tag(0x34, "DW_TAG_variable");
        tag(0x35, "DW_TAG_volatile_type"); tag(0x36, "DW_TAG_dwarf_procedure");
        tag(0x37, "DW_TAG_restrict_type"); tag(0x38, "DW_TAG_interface_type");
        tag(0x39, "DW_TAG_namespace"); tag(0x3a, "DW_TAG_imported_module");
        tag(0x3b, "DW_TAG_unspecified_type"); tag(0x3c, "DW_TAG_partial_unit");
        tag(0x3d, "DW_TAG_imported_unit"); tag(0x3f, "DW_TAG_condition");
        tag(0x40, "DW_TAG_shared_type"); tag(0x41, "DW_TAG_type_unit");
        tag(0x42, "DW_TAG_rvalue_reference_type"); tag(0x43, "DW_TAG_template_alias");
        tag(0x44, "DW_TAG_coarray_type"); tag(0x45, "DW_TAG_generic_subrange");
        tag(0x46, "DW_TAG_dynamic_type"); tag(0x47, "DW_TAG_atomic_type");
        tag(0x48, "DW_TAG_call_site"); tag(0x49, "DW_TAG_call_site_parameter");
        tag(0x4a, "DW_TAG_skeleton_unit"); tag(0x4b, "DW_TAG_immutable_type");
        tag(0x4081, "DW_TAG_MIPS_loop"); tag(0x4101, "DW_TAG_format_label");
        tag(0x4102, "DW_TAG_function_template"); tag(0x4103, "DW_TAG_class_template");
        tag(0x4104, "DW_TAG_GNU_BINCL"); tag(0x4105, "DW_TAG_GNU_EINCL");
        tag(0x4106, "DW_TAG_GNU_template_template_param");
        tag(0x4107, "DW_TAG_GNU_template_parameter_pack");
        tag(0x4108, "DW_TAG_GNU_formal_parameter_pack");
        tag(0x4109, "DW_TAG_GNU_call_site"); tag(0x410a, "DW_TAG_GNU_call_site_parameter");
    }

    private static String getTagName(long t) {
        String n = TAG_NAMES.get((int) t);
        if (n != null) return n;
        if (t >= 0x4080 && t <= 0xffff) return "User TAG value: " + hashHex(t);
        return "Unknown TAG value: " + hashHex(t);
    }

    /** The form-level value printing readelf uses for {@code attribute == 0}. */
    private String attrValueText(int form, long uvalue, char delim, long cuOffset) {
        switch (form) {
            case DW_FORM_ref_addr:
                return delim + "<" + hashHex(uvalue) + ">";
            case DW_FORM_GNU_ref_alt:
                return delim + "<alt " + hashHex(uvalue) + ">";
            case DW_FORM_ref1: case DW_FORM_ref2: case DW_FORM_ref4:
            case DW_FORM_ref_sup4: case DW_FORM_ref_udata:
                return delim + "<" + hashHex(uvalue + cuOffset) + ">";
            case DW_FORM_data4: case DW_FORM_addr: case DW_FORM_sec_offset:
                return delim + hashHex(uvalue);
            case DW_FORM_flag_present: case DW_FORM_flag: case DW_FORM_data1:
            case DW_FORM_data2: case DW_FORM_sdata: case DW_FORM_implicit_const:
                return delim + Long.toString(uvalue);
            case DW_FORM_udata:
                return delim + Long.toUnsignedString(uvalue);
            case DW_FORM_ref8:
                return delim + hashHex(uvalue + cuOffset);
            case DW_FORM_data8: case DW_FORM_ref_sup8:
                return delim + hashHex(uvalue);
            case DW_FORM_ref_sig8:
                return delim + "signature: " + hashHex(uvalue);
            case DW_FORM_strp:
                return delim + "(indirect string, offset: " + hashHex(uvalue) + "): "
                        + fetchIndirectString(uvalue);
            default:
                return "";
        }
    }

    /** Reproduces {@code readelf --debug-dump=gdb_index} for {@code .debug_names}. */
    public List<String> namesLines(String sectionName, byte[] d) {
        List<String> out = new ArrayList<>();
        out.add("Contents of the " + sectionName + " section:");
        out.add("");
        final int sectionEnd = d.length;
        int hdrptr = 0;
        while (hdrptr < sectionEnd) {
            int unitStart = hdrptr;
            long unitLength = safeGet(d, hdrptr, 4, sectionEnd); hdrptr += 4;
            int offsetSize = 4;
            if (unitLength == 0xffffffffL) {
                unitLength = safeGet(d, hdrptr, 8, sectionEnd); hdrptr += 8;
                offsetSize = 8;
            }
            if (Long.compareUnsigned(unitLength, sectionEnd - hdrptr) > 0
                    || Long.compareUnsigned(unitLength, 2 + 2 + 4 * 7) < 0) return out;
            int unitEnd = hdrptr + (int) unitLength;

            int version = (int) safeGet(d, hdrptr, 2, unitEnd); hdrptr += 2;
            out.add("Version " + version);
            if (version != 5) return out;
            hdrptr += 2;                                          /* padding */

            long compUnitCount = safeGet(d, hdrptr, 4, unitEnd); hdrptr += 4;
            long localTuCount = safeGet(d, hdrptr, 4, unitEnd); hdrptr += 4;
            long foreignTuCount = safeGet(d, hdrptr, 4, unitEnd); hdrptr += 4;
            long bucketCount = safeGet(d, hdrptr, 4, unitEnd); hdrptr += 4;
            long nameCount = safeGet(d, hdrptr, 4, unitEnd); hdrptr += 4;
            long abbrevTableSize = safeGet(d, hdrptr, 4, unitEnd); hdrptr += 4;
            long augStrSize = safeGet(d, hdrptr, 4, unitEnd); hdrptr += 4;
            if (augStrSize % 4 != 0) augStrSize += (-augStrSize) & 3;
            if (Long.compareUnsigned(augStrSize, unitEnd - hdrptr) > 0) return out;

            StringBuilder aug = new StringBuilder("Augmentation string:");
            int augStart = hdrptr;
            boolean printable = true;
            for (long i = 0; i < augStrSize; i++) {
                int uc = (int) safeGet(d, hdrptr, 1, unitEnd); hdrptr += 1;
                aug.append(String.format(" %02x", uc));
                if (uc != 0 && (uc < 0x20 || uc > 0x7e)) printable = false;
            }
            if (printable) {
                aug.append("  (\"");
                for (long i = 0; i < augStrSize && d[augStart + (int) i] != 0; i++)
                    aug.append((char) (d[augStart + (int) i] & 0xff));
                aug.append("\")");
            }
            out.add(aug.toString());

            out.add("CU table:");
            for (long i = 0; i < compUnitCount; i++) {
                long v = safeGet(d, hdrptr, offsetSize, unitEnd); hdrptr += offsetSize;
                out.add(String.format("[%3d] ", i) + hashHex(v));
            }
            out.add("");
            out.add("TU table:");
            for (long i = 0; i < localTuCount; i++) {
                long v = safeGet(d, hdrptr, offsetSize, unitEnd); hdrptr += offsetSize;
                out.add(String.format("[%3d] ", i) + hashHex(v));
            }
            out.add("");
            out.add("Foreign TU table:");
            for (long i = 0; i < foreignTuCount; i++) {
                long sig = safeGet(d, hdrptr, 8, unitEnd); hdrptr += 8;
                out.add(String.format("[%3d] ", i) + hexNs(sig, 8));
            }
            out.add("");

            long xtra = bucketCount * 4 + nameCount * (4 + 2L * offsetSize) + abbrevTableSize;
            if (Long.compareUnsigned(xtra, unitEnd - hdrptr) > 0) return out;

            int hashBuckets = hdrptr;
            hdrptr += (int) (bucketCount * 4);
            int hashHashes = hdrptr;
            if (bucketCount != 0) hdrptr += (int) (nameCount * 4);
            int nameStringOffsets = hdrptr;
            hdrptr += (int) (nameCount * offsetSize);
            int nameEntryOffsets = hdrptr;
            hdrptr += (int) (nameCount * offsetSize);
            int abbrevTable = hdrptr;
            hdrptr += (int) abbrevTableSize;
            int abbrevTableEnd = hdrptr;
            int entryPool = hdrptr;

            long bucketsFilled = 0;
            for (long b = 0; b < bucketCount; b++)
                if (safeGet(d, hashBuckets + (int) (b * 4), 4, unitEnd) != 0) bucketsFilled++;
            out.add("Used " + bucketsFilled + " of " + bucketCount
                    + (bucketCount == 1 ? " bucket." : " buckets."));

            if (bucketCount != 0) {
                long hashPrev = 0, clashes = 0, longest = 0, thisLength = 0;
                for (long hi = 0; hi < nameCount; hi++) {
                    long hashThis = safeGet(d, hashHashes + (int) (hi * 4), 4, unitEnd);
                    if (hi > 0) {
                        if (hashPrev % bucketCount == hashThis % bucketCount) {
                            clashes++;
                            thisLength++;
                            longest = Math.max(longest, thisLength);
                        } else {
                            thisLength = 0;
                        }
                    }
                    hashPrev = hashThis;
                }
                out.add("Out of " + nameCount + " items there are " + clashes
                        + " bucket clashes (longest of " + longest + " entries).");
            }

            /* Abbreviation table: tag -> pointer just past the abbrev code. */
            Map<Long, Integer> abbrevLookup = new HashMap<>();
            int ap = abbrevTable;
            while (true) {
                long abbrevTag = readLeb(d, ap, abbrevTableEnd, false); ap += lebLen;
                if (abbrevTag == 0) break;
                abbrevLookup.putIfAbsent(abbrevTag, ap);
                readLeb(d, ap, abbrevTableEnd, false); ap += lebLen;      /* DWARF tag */
                while (true) {
                    long xi = readLeb(d, ap, abbrevTableEnd, false); ap += lebLen;
                    long fm = readLeb(d, ap, abbrevTableEnd, false); ap += lebLen;
                    if (xi == 0 && fm == 0) break;
                    if (ap >= abbrevTableEnd) break;
                }
                if (ap >= abbrevTableEnd) break;
            }

            out.add("");
            out.add("Symbol table:");
            for (long namei = 0; namei < nameCount; namei++) {
                long stringOffset = safeGet(d, nameStringOffsets + (int) (namei * offsetSize),
                        offsetSize, unitEnd);
                long entryOffset = safeGet(d, nameEntryOffsets + (int) (namei * offsetSize),
                        offsetSize, unitEnd);
                StringBuilder line = new StringBuilder();
                line.append(String.format("[%3d] ", namei + 1));
                if (bucketCount != 0)
                    line.append(String.format("#%08x ",
                            safeGet(d, hashHashes + (int) (namei * 4), 4, unitEnd)));
                line.append(fetchIndirectString(stringOffset)).append(':');

                int entryptr = entryPool + (int) entryOffset;
                if (entryptr < entryPool || entryptr >= unitEnd) {
                    out.add(line.toString());
                    continue;
                }
                int tagno = -2;
                long secondAbbrevTag = -1;
                while (true) {
                    long abbrevTag = readLeb(d, entryptr, unitEnd, false); entryptr += lebLen;
                    if (tagno == -1) {
                        secondAbbrevTag = abbrevTag;
                        tagno = 0;
                        entryptr = entryPool + (int) entryOffset;
                        continue;
                    }
                    if (abbrevTag == 0) break;
                    if (tagno >= 0)
                        line.append(tagno == 0 && secondAbbrevTag == 0 ? " " : "\n\t")
                            .append('<').append(Long.toUnsignedString(abbrevTag)).append('>');
                    Integer ptr = abbrevLookup.get(abbrevTag);
                    if (ptr == null) break;
                    int abp = ptr;
                    long dwarfTag = readLeb(d, abp, abbrevTableEnd, false); abp += lebLen;
                    if (tagno >= 0) line.append(' ').append(getTagName(dwarfTag));
                    while (true) {
                        long xi = readLeb(d, abp, abbrevTableEnd, false); abp += lebLen;
                        long fm = readLeb(d, abp, abbrevTableEnd, false); abp += lebLen;
                        if (xi == 0 && fm == 0) break;
                        if (tagno >= 0) line.append(' ').append(getIdxName(xi));
                        fPos = entryptr;
                        long uv = readForm(d, unitEnd, (int) fm, 0, 0, offsetSize, version);
                        /* Zero-length forms (flag_present, implicit_const) consume
                           no bytes; forcing progress here would desynchronise the
                           entry pool and run past the abbrev_tag == 0 terminator. */
                        entryptr = fPos;
                        if (tagno >= 0) line.append(attrValueText((int) fm, uv, '=', 0));
                    }
                    ++tagno;
                }
                if (tagno <= 0) line.append(" <no entries>");
                for (String part : line.toString().split("\n", -1)) out.add(part);
            }
            hdrptr = unitEnd;
        }
        return out;
    }
}
