package dwarfkit.dbg;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.foreign.Arena;
import java.lang.foreign.MemorySegment;
import java.lang.foreign.ValueLayout;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.List;
import java.util.Map;

/**
 * One traced process and its threads.
 *
 * Every method here must be called from the single platform thread that forked
 * the inferior: ptrace(2) binds a tracee to the exact OS thread that attached to
 * it, and a request from any other thread fails with ESRCH.  {@code GdbServerMain}
 * guarantees this by running the whole server on one pinned thread.
 *
 * The model is all-stop: whenever one thread reports an interesting event every
 * other thread is stopped before the event is handed to the client.
 */
public final class Inferior {

    public static final int SIGHUP = 1, SIGTRAP = 5, SIGKILL = 9, SIGSEGV = 11,
            SIGSTOP = 19, SIGCONT = 18;
    private static final byte INT3 = (byte) 0xcc;

    /** What a resumed thread ended up doing. */
    public static final class Stop {
        public static final int STOPPED = 0, EXITED = 1, SIGNALLED = 2;
        public int kind = STOPPED;
        public int tid;
        public int sig;          // host signal number
        public int code;         // exit status when kind == EXITED
        public boolean swbreak;  // stopped on one of our 0xCC patches
    }

    /** One vCont action after parsing. */
    public static final class Act {
        public boolean step;
        public int sig;          // host signal to deliver, 0 for none
        public int tid;          // -1 means "every thread"
    }

    private static final class Thr {
        final int tid;
        boolean running;
        boolean fresh = true;    // created by clone, never resumed by us yet
        int stopsPending;        // SIGSTOPs we sent that we have not yet seen
        Stop deferred;           // an event that landed while we were quiescing
        Thr(int t) { tid = t; }
    }

    public final int pid;
    public final String program;
    public boolean exited;
    public Stop lastStop = new Stop();

    private final SortedMap<Integer, Thr> threads = new TreeMap<>();
    private final Map<Long, Integer> bpRef = new HashMap<>();
    private final Map<Long, Byte> bpOrig = new HashMap<>();

    private final Arena arena = Arena.ofShared();
    private final MemorySegment cap = arena.allocate(Native.CAPTURE);
    private final MemorySegment statusSeg = arena.allocate(ValueLayout.JAVA_INT);
    private final MemorySegment msgSeg = arena.allocate(ValueLayout.JAVA_LONG);
    private final MemorySegment regSeg = arena.allocate(Regs.URS_BYTES);
    private final MemorySegment fpSeg = arena.allocate(Regs.FPREGS_BYTES);
    private RandomAccessFile mem;

    private Inferior(int pid, String program) {
        this.pid = pid;
        this.program = program;
    }

    /* ------------------------------------------------------------------ */
    /* launch                                                              */
    /* ------------------------------------------------------------------ */

    /**
     * fork(2) + PTRACE_TRACEME + execvp(3).  Everything the child touches is
     * allocated and every downcall stub is linked before the fork, because
     * between fork and exec a child of a multi-threaded JVM may not allocate.
     */
    public static Inferior launch(String program, String[] extraArgs) throws IOException {
        Arena g = Native.GLOBAL;
        MemorySegment path = g.allocateFrom(program);
        int argc = 1 + (extraArgs == null ? 0 : extraArgs.length);
        MemorySegment argv = g.allocate(ValueLayout.ADDRESS, argc + 1);
        argv.setAtIndex(ValueLayout.ADDRESS, 0, path);
        for (int i = 1; i < argc; i++) {
            argv.setAtIndex(ValueLayout.ADDRESS, i, g.allocateFrom(extraArgs[i - 1]));
        }
        argv.setAtIndex(ValueLayout.ADDRESS, argc, MemorySegment.NULL);

        /* Link the three stubs the child will use, while still in the parent. */
        MemorySegment warm = g.allocate(Native.CAPTURE);
        MemorySegment nothing = g.allocateFrom("");
        Native.ptrace(warm, Native.PEEKDATA, 0, 0L, 0L);
        Native.ptraceRaw(Native.PEEKDATA, 0, 0L, 0L);
        Native.personality(0xffffffffL);             // query, does not change us
        Native.execvp(nothing, argv);                // fails ENOENT, links the stub

        int child = Native.fork();
        if (child == 0) {
            /* Child: no allocation, no logging, no Java objects created. */
            Native.ptraceRaw(Native.TRACEME, 0, 0L, 0L);
            Native.personality(Native.ADDR_NO_RANDOMIZE);
            Native.execvp(path, argv);
            Native.exitRaw(127);
            return null;                              // not reached
        }
        if (child < 0) throw new IOException("fork failed");

        Inferior inf = new Inferior(child, program);
        inf.afterFork();
        return inf;
    }

    private void afterFork() throws IOException {
        int w = Native.waitpid(cap, pid, statusSeg, 0);
        if (w != pid) throw new IOException("waitpid after fork returned " + w);
        int st = statusSeg.get(ValueLayout.JAVA_INT, 0);
        if (!Native.ifStopped(st)) throw new IOException("inferior did not stop after exec");
        Native.ptrace(cap, Native.SETOPTIONS, pid, 0L,
                Native.O_TRACECLONE | Native.O_EXITKILL);
        Thr t = new Thr(pid);
        t.fresh = false;
        threads.put(pid, t);
        mem = new RandomAccessFile("/proc/" + pid + "/mem", "rw");
        lastStop = new Stop();
        lastStop.kind = Stop.STOPPED;
        lastStop.tid = pid;
        lastStop.sig = Native.stopSig(st);
    }

    /* ------------------------------------------------------------------ */
    /* threads                                                             */
    /* ------------------------------------------------------------------ */

    /**
     * Live threads, lowest tid first, which is creation order in practice.
     *
     * The set is maintained purely from ptrace clone and exit events.  Scanning
     * /proc instead would invent entries whose running flag we do not know, and
     * stopOthers skips threads it believes are stopped -- such a thread would
     * keep running through a single-step window, with the breakpoint unplanted,
     * and sail straight past it.
     */
    public List<Integer> threadIds() {
        return new ArrayList<>(threads.keySet());
    }

    public boolean hasThread(int tid) { return threads.containsKey(tid); }

    /** The value of /proc/pid/task/tid/comm, which gdb shows in `info threads`. */
    public String threadName(int tid) {
        try {
            String s = Files.readString(Path.of("/proc/" + pid + "/task/" + tid + "/comm"),
                    StandardCharsets.UTF_8);
            return s.trim();
        } catch (IOException e) {
            return "";
        }
    }

    /* ------------------------------------------------------------------ */
    /* registers                                                           */
    /* ------------------------------------------------------------------ */

    public long[] getRegs(int tid) {
        long[] u = new long[Regs.URS_LONGS];
        if (exited) return u;
        Native.ptrace(cap, Native.GETREGS, tid, 0L, regSeg.address());
        for (int i = 0; i < Regs.URS_LONGS; i++) {
            u[i] = regSeg.get(ValueLayout.JAVA_LONG, i * 8L);
        }
        return u;
    }

    public void setRegs(int tid, long[] u) {
        if (exited) return;
        for (int i = 0; i < Regs.URS_LONGS; i++) {
            regSeg.set(ValueLayout.JAVA_LONG, i * 8L, u[i]);
        }
        Native.ptrace(cap, Native.SETREGS, tid, 0L, regSeg.address());
    }

    public byte[] getFpRegs(int tid) {
        if (exited) return new byte[Regs.FPREGS_BYTES];
        long r = Native.ptrace(cap, Native.GETFPREGS, tid, 0L, fpSeg.address());
        byte[] out = new byte[Regs.FPREGS_BYTES];
        if (r == 0 || Native.errno(cap) == 0) {
            MemorySegment.copy(fpSeg, ValueLayout.JAVA_BYTE, 0, out, 0, Regs.FPREGS_BYTES);
        }
        return out;
    }

    /* ------------------------------------------------------------------ */
    /* memory                                                              */
    /* ------------------------------------------------------------------ */

    private byte[] rawRead(long addr, int len) throws IOException {
        if (mem == null) throw new IOException("no live process");
        byte[] b = new byte[len];
        int n = 0;
        try {
            mem.seek(addr);
            while (n < len) {
                int k = mem.read(b, n, len - n);
                if (k <= 0) break;
                n += k;
            }
        } catch (IOException e) {
            if (n == 0) throw e;
        }
        if (n == 0) throw new IOException("cannot read " + Long.toHexString(addr));
        return n == len ? b : Arrays.copyOf(b, n);
    }

    private void rawWrite(long addr, byte[] data) throws IOException {
        if (mem == null) throw new IOException("no live process");
        try {
            mem.seek(addr);
            mem.write(data);
            return;
        } catch (IOException e) {
            // fall through to POKEDATA, which some kernels allow where write(2) fails
        }
        for (int i = 0; i < data.length; ) {
            long wordAddr = (addr + i) & ~7L;
            long word = Native.ptrace(cap, Native.PEEKDATA, activeTid(), wordAddr, 0L);
            for (int b = 0; b < 8 && i < data.length; b++) {
                long a = wordAddr + b;
                if (a < addr + i) continue;
                word = (word & ~(0xffL << (8 * b))) | ((data[i] & 0xffL) << (8 * b));
                i++;
            }
            Native.ptrace(cap, Native.POKEDATA, activeTid(), wordAddr, word);
        }
    }

    /** Memory as the client should see it: our 0xCC patches are hidden. */
    public byte[] readMem(long addr, int len) throws IOException {
        byte[] b = rawRead(addr, len);
        for (Map.Entry<Long, Byte> e : bpOrig.entrySet()) {
            long a = e.getKey();
            if (a >= addr && a < addr + b.length) b[(int) (a - addr)] = e.getValue();
        }
        return b;
    }

    public void writeMem(long addr, byte[] data) throws IOException {
        byte[] copy = data.clone();
        for (int i = 0; i < copy.length; i++) {
            long a = addr + i;
            if (bpOrig.containsKey(a)) {
                bpOrig.put(a, copy[i]);      // the client's byte becomes the new shadow
                copy[i] = INT3;              // but the trap stays planted
            }
        }
        rawWrite(addr, copy);
    }

    /* ------------------------------------------------------------------ */
    /* breakpoints                                                         */
    /* ------------------------------------------------------------------ */

    public void insertBreak(long addr) throws IOException {
        int n = bpRef.merge(addr, 1, Integer::sum);
        if (n > 1) return;
        byte[] orig = rawRead(addr, 1);
        bpOrig.put(addr, orig[0]);
        rawWrite(addr, new byte[]{INT3});
    }

    public void removeBreak(long addr) throws IOException {
        Integer n = bpRef.get(addr);
        if (n == null) return;
        if (n > 1) { bpRef.put(addr, n - 1); return; }
        bpRef.remove(addr);
        Byte orig = bpOrig.remove(addr);
        if (orig != null) rawWrite(addr, new byte[]{orig});
    }

    public boolean isBreak(long addr) { return bpOrig.containsKey(addr); }

    private void unplant(long addr) throws IOException {
        Byte orig = bpOrig.get(addr);
        if (orig != null) rawWrite(addr, new byte[]{orig});
    }

    private void replant(long addr) throws IOException {
        if (bpOrig.containsKey(addr)) rawWrite(addr, new byte[]{INT3});
    }

    /* ------------------------------------------------------------------ */
    /* execution                                                           */
    /* ------------------------------------------------------------------ */

    private int activeTid() {
        return lastStop != null && threads.containsKey(lastStop.tid) ? lastStop.tid : pid;
    }

    private static Act actionFor(int tid, List<Act> acts) {
        for (Act a : acts) if (a.tid == tid || a.tid == -1) return a;
        return null;
    }

    private void contThread(int tid, boolean step, int sig) {
        Thr t = threads.get(tid);
        if (t == null) return;
        Native.ptrace(cap, step ? Native.SINGLESTEP : Native.CONT, tid, 0L, sig);
        t.running = true;
        t.fresh = false;
    }

    private int waitAny() {
        return Native.waitpid(cap, -1, statusSeg, Native.__WALL);
    }

    private int status() { return statusSeg.get(ValueLayout.JAVA_INT, 0); }

    /**
     * Executes one vCont.  Returns when some thread has an event the client
     * should hear about; by then every other thread is stopped too.
     */
    public Stop resume(List<Act> acts) throws IOException {
        if (exited) return lastStop;

        /* A thread that hit a breakpoint while we were quiescing the others
           never got reported; hand that event over now instead of resuming,
           exactly as the stock server does with its pending-event queue. */
        for (Thr t : threads.values()) {
            if (t.deferred != null) {
                Stop s = t.deferred;
                t.deferred = null;
                lastStop = s;
                return s;
            }
        }

        /* A thread sitting exactly on one of our traps must step off it first. */
        for (Integer tid : new ArrayList<>(threads.keySet())) {
            Act a = actionFor(tid, acts);
            if (a == null || a.step) continue;
            long rip = getRegs(tid)[Regs.RIP];
            if (!bpOrig.containsKey(rip)) continue;
            unplant(rip);
            Native.ptrace(cap, Native.SINGLESTEP, tid, 0L, 0);
            int w = Native.waitpid(cap, tid, statusSeg, Native.__WALL);
            int st = status();
            if (w == tid && (Native.ifExited(st) || Native.ifSignaled(st))) {
                replant(rip);
                return reapDeath(tid, st);
            }
            replant(rip);
        }

        for (Integer tid : new ArrayList<>(threads.keySet())) {
            Act a = actionFor(tid, acts);
            if (a == null) continue;
            contThread(tid, a.step, a.sig);
        }

        while (true) {
            int w = waitAny();
            if (w < 0) {
                exited = true;
                Stop s = new Stop();
                s.kind = Stop.EXITED;
                s.tid = pid;
                lastStop = s;
                return s;
            }
            int st = status();
            Thr t = threads.computeIfAbsent(w, Thr::new);
            t.running = false;

            if (Native.ifExited(st) || Native.ifSignaled(st)) {
                threads.remove(w);
                if (w == pid || threads.isEmpty()) return reapDeath(w, st);
                continue;
            }

            int sig = Native.stopSig(st);
            int ev = Native.event(st);

            if (sig == SIGTRAP && ev == Native.EVENT_CLONE) {
                Native.ptrace(cap, Native.GETEVENTMSG, w, 0L, msgSeg.address());
                int nt = (int) msgSeg.get(ValueLayout.JAVA_LONG, 0);
                Thr child = threads.computeIfAbsent(nt, Thr::new);
                /* Start the child before the parent, but only wait for its birth
                   stop if the main loop has not already reaped it: the child's
                   SIGSTOP and the parent's clone event race, and an unguarded
                   waitpid here blocks until the child stops AGAIN -- on the
                   breakpoint -- and then silently continues it, swallowing the
                   hit and letting the thread run past its own breakpoint. */
                if (child.fresh) {
                    int cw = Native.waitpid(cap, nt, statusSeg, Native.__WALL);
                    if (cw == nt) {
                        child.fresh = false;
                        contThread(nt, false, 0);
                    }
                }
                contThread(w, false, 0);
                continue;
            }
            if (sig == SIGTRAP && ev != 0) {           // exec/exit/vfork events
                contThread(w, false, 0);
                continue;
            }
            if (sig == SIGSTOP && t.stopsPending > 0) {
                /* One of ours, queued from an earlier quiesce.  Delivering it
                   would make gdb announce "received signal SIGSTOP". */
                t.stopsPending--;
                contThread(w, false, 0);
                continue;
            }
            if (sig == SIGSTOP && t.fresh) {           // a brand new thread's first stop
                t.fresh = false;
                contThread(w, false, 0);
                continue;
            }

            boolean swbreak = false;
            if (sig == SIGTRAP) {
                long[] u = getRegs(w);
                long prev = u[Regs.RIP] - 1;
                if (bpOrig.containsKey(prev)) {
                    /* The client expects the pc already rewound onto the trap. */
                    u[Regs.RIP] = prev;
                    setRegs(w, u);
                    swbreak = true;
                }
            }

            stopOthers(w);
            Stop s = new Stop();
            s.kind = Stop.STOPPED;
            s.tid = w;
            s.sig = sig;
            s.swbreak = swbreak;
            lastStop = s;
            return s;
        }
    }

    private Stop reapDeath(int who, int st) {
        /* Drain any remaining thread notifications so waitpid does not block later. */
        exited = true;
        threads.clear();
        Stop s = new Stop();
        s.tid = who;
        if (Native.ifExited(st)) {
            s.kind = Stop.EXITED;
            s.code = Native.exitStatus(st);
        } else {
            s.kind = Stop.SIGNALLED;
            s.sig = Native.termSig(st);
        }
        lastStop = s;
        try { if (mem != null) mem.close(); } catch (IOException ignore) { /* closing */ }
        mem = null;
        return s;
    }

    /**
     * All-stop: quiesce every thread other than the one that reported.
     *
     * A thread can stop on its own -- typically on the very same breakpoint --
     * between the reporting thread's event and our SIGSTOP.  That event must be
     * kept and replayed on the next resume, not thrown away, and the SIGSTOP we
     * queued for that thread must be accounted for so it is never delivered.
     */
    private void stopOthers(int except) {
        for (Integer tid : new ArrayList<>(threads.keySet())) {
            if (tid == except) continue;
            Thr t = threads.get(tid);
            if (t == null || !t.running) continue;
            /* Nothing is consulted from /proc here on purpose: this is the path
               taken the instant a breakpoint fires, and even one file read per
               thread lets the others run measurably further before they are
               quiesced, which changes which frames the client then sees. */
            t.stopsPending++;
            Native.tgkill(pid, tid, SIGSTOP);
            while (true) {
                int w = Native.waitpid(cap, tid, statusSeg, Native.__WALL);
                if (w != tid) break;
                int st = status();
                if (Native.ifExited(st) || Native.ifSignaled(st)) {
                    threads.remove(tid);
                    break;
                }
                int sig = Native.stopSig(st);
                int ev = Native.event(st);
                if (sig == SIGTRAP && ev == Native.EVENT_CLONE) {
                    Native.ptrace(cap, Native.GETEVENTMSG, tid, 0L, msgSeg.address());
                    int nt = (int) msgSeg.get(ValueLayout.JAVA_LONG, 0);
                    threads.computeIfAbsent(nt, Thr::new);
                    contThread(tid, false, 0);
                    continue;
                }
                t.running = false;
                if (sig == SIGSTOP && t.stopsPending > 0) {
                    t.stopsPending--;                  // this was our doing
                    break;
                }
                Stop d = new Stop();
                d.kind = Stop.STOPPED;
                d.tid = tid;
                d.sig = sig;
                if (sig == SIGTRAP) {
                    long[] u = getRegs(tid);
                    long prev = u[Regs.RIP] - 1;
                    if (bpOrig.containsKey(prev)) {
                        u[Regs.RIP] = prev;
                        setRegs(tid, u);
                        d.swbreak = true;
                    }
                }
                t.deferred = d;
                break;
            }
        }
    }

    /* ------------------------------------------------------------------ */
    /* teardown                                                            */
    /* ------------------------------------------------------------------ */

    public void kill() {
        if (exited) return;
        for (Integer tid : new ArrayList<>(threads.keySet())) {
            Native.ptrace(cap, Native.KILL, tid, 0L, 0L);
        }
        Native.kill(pid, SIGKILL);
        for (int i = 0; i < 64; i++) {
            int w = Native.waitpid(cap, -1, statusSeg, Native.__WALL);
            if (w < 0) break;
            int st = status();
            if (w == pid && (Native.ifExited(st) || Native.ifSignaled(st))) break;
        }
        exited = true;
        threads.clear();
        try { if (mem != null) mem.close(); } catch (IOException ignore) { /* closing */ }
        mem = null;
    }

    public void detach() {
        for (Integer tid : new ArrayList<>(threads.keySet())) {
            Native.ptrace(cap, Native.DETACH, tid, 0L, 0L);
        }
        exited = true;
    }

    /** The raw bytes of /proc/pid/auxv, as gdb's qXfer:auxv:read wants them. */
    public byte[] auxv() {
        try {
            return Files.readAllBytes(Path.of("/proc/" + pid + "/auxv"));
        } catch (IOException e) {
            return new byte[0];
        }
    }
}
