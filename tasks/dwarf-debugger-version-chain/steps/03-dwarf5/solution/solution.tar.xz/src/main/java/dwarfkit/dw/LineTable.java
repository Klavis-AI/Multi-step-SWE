package dwarfkit.dw;

import dwarfkit.elf.Elf;
import dwarfkit.util.Buf;

import java.util.ArrayList;
import java.util.List;

import static dwarfkit.dw.Consts.*;

/** .debug_line state machine for versions 2, 3, 4 and 5. */
public final class LineTable {

    public static final int ABSOLUTE = 0, BASENAME = 1, RELATIVE = 2;

    public static final class Row {
        public long address;
        public int file, line, col, discriminator, isa;
        public boolean isStmt, endSeq, basicBlock, prologueEnd, epilogueBegin;
        public int seq;
    }

    public static final class FileEntry {
        public String name;
        public int dirIndex;
    }

    public int version;
    public int addrSize = 8;
    public final List<String> dirs = new ArrayList<>();
    public final List<FileEntry> files = new ArrayList<>();
    public final List<Row> rows = new ArrayList<>();
    public String compDir;
    /** DWARF 5 numbers files from 0 with file 0 the primary source; <=4 from 1. */
    public int fileBase = 1;

    private Info.Unit unit;

    public static LineTable parse(Elf elf, byte[] sec, int off, Info.Unit u,
                                  byte[] lineStr, byte[] str, Info info) {
        LineTable t = new LineTable();
        t.unit = u;
        t.compDir = u == null ? null : u.compDir;
        Buf b = new Buf(sec);
        b.little = elf.little;
        b.seek(off);
        int offsetSize = 4;
        long len = b.u32();
        if (len == 0xffffffffL) { offsetSize = 8; len = b.u64(); }
        int end = b.pos() + (int) len;
        t.version = b.u16();
        if (t.version >= 5) {
            t.addrSize = b.u8();
            b.u8();                                   // segment_selector_size
        } else {
            t.addrSize = u == null ? 8 : u.addrSize;
        }
        long headerLen = b.uint(offsetSize);
        int programStart = b.pos() + (int) headerLen;
        int minInst = b.u8();
        int maxOps = (t.version >= 4) ? b.u8() : 1;
        if (maxOps <= 0) maxOps = 1;
        boolean defaultIsStmt = b.u8() != 0;
        int lineBase = (byte) b.u8();
        int lineRange = b.u8();
        int opcodeBase = b.u8();
        int[] stdLens = new int[Math.max(opcodeBase, 1)];
        for (int i = 1; i < opcodeBase; i++) stdLens[i] = (int) b.uleb();

        if (t.version >= 5) {
            int dirFormatCount = b.u8();
            int[][] dirFormats = new int[dirFormatCount][2];
            for (int i = 0; i < dirFormatCount; i++) {
                dirFormats[i][0] = (int) b.uleb();
                dirFormats[i][1] = (int) b.uleb();
            }
            long dirCount = b.uleb();
            for (long i = 0; i < dirCount; i++) {
                String name = null;
                for (int[] f : dirFormats) {
                    Object v = readLnct(b, f[1], offsetSize, t.addrSize, lineStr, str, u, info);
                    if (f[0] == DW_LNCT_path && v instanceof String) name = (String) v;
                }
                t.dirs.add(name == null ? "" : name);
            }
            int fileFormatCount = b.u8();
            int[][] fileFormats = new int[fileFormatCount][2];
            for (int i = 0; i < fileFormatCount; i++) {
                fileFormats[i][0] = (int) b.uleb();
                fileFormats[i][1] = (int) b.uleb();
            }
            long fileCount = b.uleb();
            for (long i = 0; i < fileCount; i++) {
                FileEntry fe = new FileEntry();
                for (int[] f : fileFormats) {
                    Object v = readLnct(b, f[1], offsetSize, t.addrSize, lineStr, str, u, info);
                    if (f[0] == DW_LNCT_path && v instanceof String) fe.name = (String) v;
                    else if (f[0] == DW_LNCT_directory_index && v instanceof Long) fe.dirIndex = (int) (long) (Long) v;
                }
                t.files.add(fe);
            }
            t.fileBase = 0;
        } else {
            t.dirs.add(u == null || u.compDir == null ? "" : u.compDir);   // index 0
            while (true) {
                String s = b.cstr();
                if (s.isEmpty()) break;
                t.dirs.add(s);
            }
            FileEntry zero = new FileEntry();
            zero.name = u == null ? null : u.name;
            t.files.add(zero);                                             // placeholder index 0
            while (true) {
                String name = b.cstr();
                if (name.isEmpty()) break;
                FileEntry fe = new FileEntry();
                fe.name = name;
                fe.dirIndex = (int) b.uleb();
                b.uleb();                                                  // mtime
                b.uleb();                                                  // length
                t.files.add(fe);
            }
            t.fileBase = 1;
        }

        b.seek(programStart);
        Row r = t.reset(defaultIsStmt);
        int seq = 0;
        long opIndex = 0;
        while (b.pos() < end) {
            int op = b.u8();
            if (op >= opcodeBase) {
                int adj = op - opcodeBase;
                long advance = adj / lineRange;
                r.address += minInst * ((opIndex + advance) / maxOps);
                opIndex = (opIndex + advance) % maxOps;
                r.line += lineBase + (adj % lineRange);
                t.emit(r, seq);
                r.basicBlock = r.prologueEnd = r.epilogueBegin = false;
                r.discriminator = 0;
            } else if (op == 0) {
                int elen = (int) b.uleb();
                int next = b.pos() + elen;
                int sub = elen > 0 ? b.u8() : 0;
                switch (sub) {
                    case DW_LNE_end_sequence:
                        r.endSeq = true;
                        t.emit(r, seq);
                        seq++;
                        r = t.reset(defaultIsStmt);
                        opIndex = 0;
                        break;
                    case DW_LNE_set_address:
                        r.address = b.uint(Math.min(Math.max(elen - 1, 1), 8));
                        opIndex = 0;
                        break;
                    case DW_LNE_define_file: {
                        FileEntry fe = new FileEntry();
                        fe.name = b.cstr();
                        fe.dirIndex = (int) b.uleb();
                        b.uleb();
                        b.uleb();
                        t.files.add(fe);
                        break;
                    }
                    case DW_LNE_set_discriminator:
                        r.discriminator = (int) b.uleb();
                        break;
                    default:
                        break;
                }
                b.seek(next);
            } else {
                switch (op) {
                    case DW_LNS_copy:
                        t.emit(r, seq);
                        r.basicBlock = r.prologueEnd = r.epilogueBegin = false;
                        r.discriminator = 0;
                        break;
                    case DW_LNS_advance_pc: {
                        long adv = b.uleb();
                        r.address += minInst * ((opIndex + adv) / maxOps);
                        opIndex = (opIndex + adv) % maxOps;
                        break;
                    }
                    case DW_LNS_advance_line: r.line += (int) b.sleb(); break;
                    case DW_LNS_set_file: r.file = (int) b.uleb(); break;
                    case DW_LNS_set_column: r.col = (int) b.uleb(); break;
                    case DW_LNS_negate_stmt: r.isStmt = !r.isStmt; break;
                    case DW_LNS_set_basic_block: r.basicBlock = true; break;
                    case DW_LNS_const_add_pc: {
                        int adj = 255 - opcodeBase;
                        long adv = adj / lineRange;
                        r.address += minInst * ((opIndex + adv) / maxOps);
                        opIndex = (opIndex + adv) % maxOps;
                        break;
                    }
                    case DW_LNS_fixed_advance_pc: r.address += b.u16(); opIndex = 0; break;
                    case DW_LNS_set_prologue_end: r.prologueEnd = true; break;
                    case DW_LNS_set_epilogue_begin: r.epilogueBegin = true; break;
                    case DW_LNS_set_isa: r.isa = (int) b.uleb(); break;
                    default:
                        for (int i = 0; i < stdLens[op]; i++) b.uleb();
                        break;
                }
            }
        }
        t.rows.sort((x, y) -> {
            int c = Long.compareUnsigned(x.address, y.address);
            if (c != 0) return c;
            return Boolean.compare(x.endSeq, y.endSeq);
        });
        return t;
    }

    private static Object readLnct(Buf b, int form, int offsetSize, int addrSize,
                                   byte[] lineStr, byte[] str, Info.Unit u, Info info) {
        switch (form) {
            case DW_FORM_string: return b.cstr();
            case DW_FORM_line_strp: return Buf.cstrAt(lineStr, (int) b.uint(offsetSize));
            case DW_FORM_strp: return Buf.cstrAt(str, (int) b.uint(offsetSize));
            case DW_FORM_strx: return resolveStrx(b.uleb(), u, info);
            case DW_FORM_strx1: return resolveStrx(b.u8(), u, info);
            case DW_FORM_strx2: return resolveStrx(b.u16(), u, info);
            case DW_FORM_strx3: return resolveStrx(b.u8() | ((long) b.u8() << 8) | ((long) b.u8() << 16), u, info);
            case DW_FORM_strx4: return resolveStrx(b.u32(), u, info);
            case DW_FORM_udata: return b.uleb();
            case DW_FORM_data1: return (long) b.u8();
            case DW_FORM_data2: return (long) b.u16();
            case DW_FORM_data4: return b.u32();
            case DW_FORM_data8: return b.u64();
            case DW_FORM_data16: b.bytes(16); return null;
            case DW_FORM_block: { int n = (int) b.uleb(); b.bytes(n); return null; }
            default: return null;
        }
    }

    private static Object resolveStrx(long idx, Info.Unit u, Info info) {
        if (u == null || info == null) return null;
        return info.resolveString(u, DW_FORM_strx, idx);
    }

    private Row reset(boolean defaultIsStmt) {
        Row r = new Row();
        r.address = 0;
        r.file = 1;
        r.line = 1;
        r.col = 0;
        r.isStmt = defaultIsStmt;
        return r;
    }

    private void emit(Row r, int seq) {
        Row c = new Row();
        c.address = r.address;
        c.file = r.file;
        c.line = r.line;
        c.col = r.col;
        c.isStmt = r.isStmt;
        c.endSeq = r.endSeq;
        c.discriminator = r.discriminator;
        c.isa = r.isa;
        c.basicBlock = r.basicBlock;
        c.prologueEnd = r.prologueEnd;
        c.epilogueBegin = r.epilogueBegin;
        c.seq = seq;
        rows.add(c);
        r.endSeq = false;
    }

    /** The row covering pc, or null when pc is past the end of every sequence. */
    public Row lookup(long pc) {
        int lo = 0, hi = rows.size() - 1, best = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (Buf.ule(rows.get(mid).address, pc)) { best = mid; lo = mid + 1; } else hi = mid - 1;
        }
        if (best < 0) return null;
        // walk back over rows at the same address, preferring a non-end_sequence row
        int i = best;
        while (i > 0 && rows.get(i).address == rows.get(best).address && rows.get(i).endSeq) i--;
        Row r = rows.get(i);
        if (r.endSeq && r.address == pc) return null;
        if (r.endSeq) return null;
        return r;
    }

    /** Resolved name of a file index, in llvm-symbolizer's path style. */
    public String fileName(int idx, int style) {
        if (idx < 0 || idx >= files.size()) return null;
        FileEntry fe = files.get(idx);
        if (fe == null || fe.name == null) return null;
        String name = fe.name;
        if (style == BASENAME) {
            int s = name.lastIndexOf('/');
            return s >= 0 ? name.substring(s + 1) : name;
        }
        String path = name;
        if (!path.startsWith("/")) {
            String dir = (fe.dirIndex >= 0 && fe.dirIndex < dirs.size()) ? dirs.get(fe.dirIndex) : null;
            if (dir != null && !dir.isEmpty()) path = dir + "/" + path;
        }
        if (!path.startsWith("/") && compDir != null && !compDir.isEmpty()) {
            path = compDir + "/" + path;
        }
        if (style == RELATIVE && compDir != null && !compDir.isEmpty()
                && path.startsWith(compDir + "/")) {
            return path.substring(compDir.length() + 1);
        }
        return path;
    }
}
