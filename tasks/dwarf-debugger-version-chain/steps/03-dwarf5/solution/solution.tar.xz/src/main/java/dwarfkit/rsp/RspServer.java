package dwarfkit.rsp;

import dwarfkit.dbg.Inferior;
import dwarfkit.dbg.Regs;
import dwarfkit.dbg.Signals;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * The GDB remote serial protocol: all-stop, one process, many threads.
 *
 * The handlers carry notes on the things gdb 16.3 demands that a reading of the
 * protocol chapter alone would not reveal.
 */
public final class RspServer {

    private final Inferior inf;
    private final Packet pkt;
    private int hgTid = -1;          // thread selected by Hg; -1 means "any"
    private boolean running = true;

    public RspServer(Inferior inf, Socket sock) throws IOException {
        this.inf = inf;
        InputStream in = new BufferedInputStream(sock.getInputStream());
        OutputStream out = new BufferedOutputStream(sock.getOutputStream());
        this.pkt = new Packet(in, out);
    }

    public void serve() throws IOException {
        while (running) {
            String p = pkt.read();
            if (p == null) break;
            if (p.equals(Packet.INTERRUPT)) continue;   // we are never asynchronous
            String reply = dispatch(p);
            if (reply != null) pkt.send(reply);
        }
    }

    /* ------------------------------------------------------------------ */

    private String dispatch(String p) throws IOException {
        if (p.isEmpty()) return "";

        if (p.startsWith("qSupported")) return supported();
        if (p.equals("vMustReplyEmpty")) return "";
        if (p.equals("QStartNoAckMode")) {
            pkt.send("OK");
            pkt.setNoAck(true);
            return null;
        }
        if (p.equals("vCont?")) {
            /* Deliberately no 'r': advertising range stepping makes gdb hand us
               address ranges to step through, and plain 's' is enough. */
            return "vCont;c;C;s;S";
        }
        if (p.startsWith("vCont")) return vCont(p);
        if (p.equals("?")) return stopReply(inf.lastStop);
        if (p.equals("g")) return readRegisters();
        if (p.startsWith("G")) return writeRegisters(p.substring(1));
        if (p.startsWith("p")) return readOneRegister(p.substring(1));
        if (p.startsWith("P")) return writeOneRegister(p.substring(1));
        if (p.startsWith("m")) return readMemory(p.substring(1));
        if (p.startsWith("M")) return writeMemory(p.substring(1));
        if (p.startsWith("X")) return "";             // decline; gdb falls back to M
        if (p.startsWith("Z")) return setBreak(p, true);
        if (p.startsWith("z")) return setBreak(p, false);
        if (p.startsWith("H")) return setThread(p);
        if (p.equals("qC")) return "QC " + tid(currentTid());
        if (p.startsWith("qAttached")) return "0";    // we created it, so gdb may kill it
        if (p.equals("qfThreadInfo")) return firstThreadInfo();
        if (p.equals("qsThreadInfo")) return "l";
        if (p.startsWith("qThreadExtraInfo")) return threadExtra(p);
        if (p.startsWith("qXfer:")) return xfer(p);
        if (p.startsWith("qSymbol")) return "OK";
        if (p.equals("qOffsets")) return "";
        if (p.startsWith("QNonStop:")) return p.endsWith("0") ? "OK" : "E01";
        if (p.startsWith("QPassSignals") || p.startsWith("QProgramSignals")) return "OK";
        if (p.startsWith("QCatchSyscalls") || p.startsWith("QThreadEvents")
                || p.startsWith("QThreadOptions") || p.startsWith("QDisableRandomization")
                || p.startsWith("QStartupWithShell") || p.startsWith("QEnvironment")
                || p.startsWith("QSetWorkingDir")) {
            return "OK";
        }
        if (p.startsWith("T")) return inf.hasThread(parseTid(p.substring(1))) ? "OK" : "E01";
        if (p.startsWith("vKill")) {
            inf.kill();
            return "OK";
        }
        if (p.equals("k")) {
            inf.kill();
            running = false;
            return null;
        }
        if (p.startsWith("D")) {
            inf.detach();
            running = false;
            return "OK";
        }
        if (p.equals("!")) return "OK";
        return "";                                    // everything else: unsupported
    }

    /* ------------------------------------------------------------------ */
    /* handshake                                                           */
    /* ------------------------------------------------------------------ */

    private String supported() {
        /* multiprocess+ is not cosmetic: it makes gdb print thread ids in the
           "Thread PID.TID" form that `info threads` shows.  binary-upload is
           deliberately absent, so gdb reads memory with 'm' and not binary 'x'. */
        return "PacketSize=3fff"
                + ";QStartNoAckMode+"
                + ";qXfer:features:read+"
                + ";qXfer:threads:read+"
                + ";qXfer:auxv:read+"
                + ";multiprocess+"
                + ";swbreak+"
                + ";vContSupported+"
                + ";QNonStop+"
                + ";QPassSignals+"
                + ";QProgramSignals+";
    }

    /* ------------------------------------------------------------------ */
    /* thread addressing                                                   */
    /* ------------------------------------------------------------------ */

    private String tid(int t) {
        return "p" + Integer.toHexString(inf.pid) + "." + Integer.toHexString(t);
    }

    private int currentTid() {
        if (hgTid > 0 && inf.hasThread(hgTid)) return hgTid;
        int t = inf.lastStop.tid;
        return inf.hasThread(t) ? t : inf.pid;
    }

    /** Parses "p<pid>.<tid>", "<tid>", "-1" and "0" (both meaning "any"). */
    private int parseTid(String s) {
        if (s.isEmpty()) return -1;
        String t = s;
        if (t.startsWith("p")) {
            int dot = t.indexOf('.');
            t = dot < 0 ? "-1" : t.substring(dot + 1);
        }
        if (t.equals("-1")) return -1;
        try {
            int v = Integer.parseInt(t, 16);
            return v == 0 ? -1 : v;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private String setThread(String p) {
        if (p.length() < 2) return "E01";
        if (p.charAt(1) == 'g') hgTid = parseTid(p.substring(2));
        return "OK";
    }

    private String firstThreadInfo() {
        List<Integer> ts = inf.threadIds();
        if (ts.isEmpty()) return "l";
        StringBuilder sb = new StringBuilder("m");
        for (int i = 0; i < ts.size(); i++) {
            if (i > 0) sb.append(',');
            sb.append(tid(ts.get(i)));
        }
        return sb.toString();
    }

    private String threadExtra(String p) {
        int c = p.indexOf(',');
        int t = c < 0 ? inf.pid : parseTid(p.substring(c + 1));
        return Packet.toHex(inf.threadName(t).getBytes(StandardCharsets.UTF_8));
    }

    /* ------------------------------------------------------------------ */
    /* registers and memory                                                */
    /* ------------------------------------------------------------------ */

    private String readRegisters() {
        int t = currentTid();
        return Packet.toHex(Regs.toG(inf.getRegs(t), inf.getFpRegs(t)));
    }

    private String writeRegisters(String hex) {
        int t = currentTid();
        long[] u = inf.getRegs(t);
        Regs.fromG(Packet.fromHex(hex), u);
        inf.setRegs(t, u);
        return "OK";
    }

    private String readOneRegister(String s) {
        int n;
        try {
            n = Integer.parseInt(s, 16);
        } catch (NumberFormatException e) {
            return "E01";
        }
        int[] slot = Regs.slot(n);
        if (slot == null) return "E01";
        int t = currentTid();
        byte[] g = Regs.toG(inf.getRegs(t), inf.getFpRegs(t));
        byte[] out = new byte[slot[1]];
        System.arraycopy(g, slot[0], out, 0, slot[1]);
        return Packet.toHex(out);
    }

    private String writeOneRegister(String s) {
        int eq = s.indexOf('=');
        if (eq < 0) return "E01";
        int n;
        try {
            n = Integer.parseInt(s.substring(0, eq), 16);
        } catch (NumberFormatException e) {
            return "E01";
        }
        int[] slot = Regs.slot(n);
        if (slot == null) return "E01";
        int t = currentTid();
        long[] u = inf.getRegs(t);
        byte[] g = Regs.toG(u, inf.getFpRegs(t));
        byte[] v = Packet.fromHex(s.substring(eq + 1));
        System.arraycopy(v, 0, g, slot[0], Math.min(v.length, slot[1]));
        Regs.fromG(g, u);
        inf.setRegs(t, u);
        return "OK";
    }

    private String readMemory(String s) {
        int c = s.indexOf(',');
        if (c < 0) return "E01";
        try {
            long addr = Long.parseUnsignedLong(s.substring(0, c), 16);
            int len = Integer.parseInt(s.substring(c + 1), 16);
            if (len <= 0) return "";
            return Packet.toHex(inf.readMem(addr, len));
        } catch (IOException | NumberFormatException e) {
            return "E14";
        }
    }

    private String writeMemory(String s) {
        int c = s.indexOf(',');
        int colon = s.indexOf(':');
        if (c < 0 || colon < 0) return "E01";
        try {
            long addr = Long.parseUnsignedLong(s.substring(0, c), 16);
            inf.writeMem(addr, Packet.fromHex(s.substring(colon + 1)));
            return "OK";
        } catch (IOException | NumberFormatException e) {
            return "E14";
        }
    }

    private String setBreak(String p, boolean insert) {
        /* Only type 0, the software breakpoint, is claimed; declining the
           hardware types makes gdb use 0xCC everywhere. */
        String[] f = p.substring(1).split(",");
        if (f.length < 2) return "E01";
        if (!f[0].equals("0")) return "";
        try {
            long addr = Long.parseUnsignedLong(f[1], 16);
            if (insert) inf.insertBreak(addr); else inf.removeBreak(addr);
            return "OK";
        } catch (IOException | NumberFormatException e) {
            return "E01";
        }
    }

    /* ------------------------------------------------------------------ */
    /* execution                                                           */
    /* ------------------------------------------------------------------ */

    private String vCont(String p) throws IOException {
        List<Inferior.Act> acts = new ArrayList<>();
        for (String part : p.substring(5).split(";")) {
            if (part.isEmpty()) continue;
            int colon = part.indexOf(':');
            String what = colon < 0 ? part : part.substring(0, colon);
            if (what.isEmpty()) continue;
            Inferior.Act a = new Inferior.Act();
            a.tid = colon < 0 ? -1 : parseTid(part.substring(colon + 1));
            char k = what.charAt(0);
            if (k == 's' || k == 'S') {
                a.step = true;
            } else if (k != 'c' && k != 'C') {
                continue;                              // 't' and 'r' are not offered
            }
            if ((k == 'C' || k == 'S') && what.length() > 1) {
                /* The number here is a gdb signal number, not a host one. */
                try {
                    a.sig = Signals.toHost(Integer.parseInt(what.substring(1), 16));
                } catch (NumberFormatException e) {
                    a.sig = 0;
                }
            }
            acts.add(a);
        }
        if (acts.isEmpty()) return "E01";
        return stopReply(inf.resume(acts));
    }

    /* ------------------------------------------------------------------ */
    /* stop replies                                                        */
    /* ------------------------------------------------------------------ */

    private String stopReply(Inferior.Stop s) {
        if (s == null) return "W00;process:" + Integer.toHexString(inf.pid);
        if (s.kind == Inferior.Stop.EXITED) {
            return "W" + two(s.code) + ";process:" + Integer.toHexString(inf.pid);
        }
        if (s.kind == Inferior.Stop.SIGNALLED) {
            return "X" + two(Signals.toGdb(s.sig)) + ";process:"
                    + Integer.toHexString(inf.pid);
        }
        StringBuilder sb = new StringBuilder();
        sb.append('T').append(two(Signals.toGdb(s.sig)));
        if (s.swbreak) sb.append("swbreak:;");
        long[] u = inf.getRegs(s.tid);
        /* Expediting rbp/rsp/rip saves gdb a 'g' round trip; the keys are gdb
           register numbers in hex and the values are little-endian. */
        sb.append("06:").append(Packet.leHex(u[Regs.RBP], 8)).append(';');
        sb.append("07:").append(Packet.leHex(u[Regs.RSP], 8)).append(';');
        sb.append("10:").append(Packet.leHex(u[Regs.RIP], 8)).append(';');
        sb.append("thread:").append(tid(s.tid)).append(';');
        return sb.toString();
    }

    private static String two(int v) {
        String h = Integer.toHexString(v & 0xff);
        return h.length() == 1 ? "0" + h : h;
    }

    /* ------------------------------------------------------------------ */
    /* qXfer                                                               */
    /* ------------------------------------------------------------------ */

    private String xfer(String p) throws IOException {
        String[] f = p.split(":");
        if (f.length < 5) return "E00";
        String object = f[1], op = f[2], annex = f[3];
        if (!op.equals("read")) return "";
        String[] ol = f[4].split(",");
        long off;
        int len;
        try {
            off = Long.parseUnsignedLong(ol[0], 16);
            len = Integer.parseInt(ol[1], 16);
        } catch (NumberFormatException e) {
            return "E00";
        }
        byte[] data;
        if (object.equals("features")) {
            if (!annex.equals("target.xml")) return "E00";
            data = TargetXml.XML.getBytes(StandardCharsets.UTF_8);
        } else if (object.equals("threads")) {
            data = threadsXml().getBytes(StandardCharsets.UTF_8);
        } else if (object.equals("auxv")) {
            data = inf.auxv();
        } else {
            return "";
        }
        return chunk(data, off, len);
    }

    private String chunk(byte[] data, long off, int len) throws IOException {
        if (off >= data.length) return "l";
        int end = (int) Math.min(data.length, off + len);
        int n = end - (int) off;
        byte[] framed = new byte[n + 1];
        framed[0] = (byte) (end >= data.length ? 'l' : 'm');
        System.arraycopy(data, (int) off, framed, 1, n);
        pkt.sendBinary(framed);
        return null;
    }

    /** The name attribute is what `info threads` prints in quotes. */
    private String threadsXml() {
        StringBuilder sb = new StringBuilder("<threads>\n");
        for (int t : inf.threadIds()) {
            sb.append("<thread id=\"").append(tid(t)).append("\" core=\"0\" name=\"")
                    .append(xmlEscape(inf.threadName(t))).append("\"/>\n");
        }
        sb.append("</threads>\n");
        return sb.toString();
    }

    private static String xmlEscape(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;");
    }
}
