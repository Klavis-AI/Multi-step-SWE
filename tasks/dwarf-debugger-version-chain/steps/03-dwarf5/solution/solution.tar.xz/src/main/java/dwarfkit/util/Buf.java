package dwarfkit.util;

/**
 * A cursor over a byte array.  Everything DWARF reads is unsigned; Java has no
 * unsigned integer types, so every accessor here widens explicitly and callers
 * must use the unsigned comparison helpers rather than < and <=.
 */
public final class Buf {
    public final byte[] a;
    public final int base;
    public final int limit;
    public int p;
    public boolean little = true;

    public Buf(byte[] a) { this(a, 0, a.length); }

    public Buf(byte[] a, int off, int len) {
        this.a = a;
        this.base = off;
        this.limit = off + len;
        this.p = off;
    }

    public Buf slice(int off, int len) {
        Buf b = new Buf(a, base + off, len);
        b.little = little;
        return b;
    }

    public Buf dup() {
        Buf b = new Buf(a, base, limit - base);
        b.p = p;
        b.little = little;
        return b;
    }

    public int pos() { return p - base; }
    public void seek(int off) { p = base + off; }
    public int remaining() { return limit - p; }
    public boolean eof() { return p >= limit; }
    public void skip(int n) { p += n; }

    public int u8() {
        if (p >= limit) throw new IndexOutOfBoundsException("u8 past end");
        return a[p++] & 0xff;
    }

    public int i8() {
        if (p >= limit) throw new IndexOutOfBoundsException("i8 past end");
        return a[p++];
    }

    public int u16() {
        int x0 = u8(), x1 = u8();
        return little ? (x0 | (x1 << 8)) : ((x0 << 8) | x1);
    }

    public long u32() {
        long x0 = u8(), x1 = u8(), x2 = u8(), x3 = u8();
        return little ? (x0 | (x1 << 8) | (x2 << 16) | (x3 << 24))
                      : ((x0 << 24) | (x1 << 16) | (x2 << 8) | x3);
    }

    public int i32() { return (int) u32(); }

    public long u64() {
        long lo = u32(), hi = u32();
        return little ? (lo | (hi << 32)) : ((lo << 32) | hi);
    }

    /** Reads an address or offset of the given byte width (4 or 8). */
    public long uint(int size) {
        switch (size) {
            case 1: return u8();
            case 2: return u16();
            case 4: return u32();
            case 8: return u64();
            default: throw new IllegalArgumentException("width " + size);
        }
    }

    /** Sign-extends a value of the given byte width. */
    public long sint(int size) {
        long v = uint(size);
        if (size < 8) {
            long sign = 1L << (size * 8 - 1);
            if ((v & sign) != 0) v -= (sign << 1);
        }
        return v;
    }

    public long uleb() {
        long r = 0;
        int shift = 0;
        while (true) {
            int b = u8();
            if (shift < 64) r |= ((long) (b & 0x7f)) << shift;
            shift += 7;
            if ((b & 0x80) == 0) return r;
        }
    }

    public long sleb() {
        long r = 0;
        int shift = 0, b;
        do {
            b = u8();
            if (shift < 64) r |= ((long) (b & 0x7f)) << shift;
            shift += 7;
        } while ((b & 0x80) != 0);
        if (shift < 64 && (b & 0x40) != 0) r |= -(1L << shift);
        return r;
    }

    public String cstr() {
        int s = p;
        while (p < limit && a[p] != 0) p++;
        String out = new String(a, s, p - s, java.nio.charset.StandardCharsets.UTF_8);
        if (p < limit) p++;
        return out;
    }

    public static String cstrAt(byte[] a, int off) {
        if (off < 0 || off >= a.length) return null;
        int e = off;
        while (e < a.length && a[e] != 0) e++;
        return new String(a, off, e - off, java.nio.charset.StandardCharsets.UTF_8);
    }

    public byte[] bytes(int n) {
        byte[] out = new byte[n];
        System.arraycopy(a, p, out, 0, n);
        p += n;
        return out;
    }

    /* Unsigned comparisons: an address with bit 63 set is a normal address. */
    public static boolean ult(long x, long y) { return Long.compareUnsigned(x, y) < 0; }
    public static boolean ule(long x, long y) { return Long.compareUnsigned(x, y) <= 0; }
    public static boolean inRange(long pc, long lo, long hi) { return ule(lo, pc) && ult(pc, hi); }
}
