package dwarfkit.demangle;

import java.util.ArrayList;
import java.util.List;

/**
 * A recursive-descent demangler for the Itanium C++ ABI mangling grammar
 * (https://itanium-cxx-abi.github.io/cxx-abi/abi.html#mangling).
 *
 * <p>Output is intended to be byte-identical to LLVM's {@code llvm-cxxfilt}.
 * The implementation mirrors LLVM's two-phase ("printLeft" / "printRight")
 * node printing so that C declarator shapes -- arrays, function pointers,
 * pointers-to-member -- come out with the correct parenthesisation.
 *
 * <p>Depends only on {@code java.base} and never throws: malformed input
 * yields {@code null}.
 */
public final class Itanium {

    private Itanium() { }

    /**
     * Returns the demangled form of an Itanium C++ ABI mangled name, or null
     * if {@code s} is not a mangled name or cannot be demangled.
     */
    public static String demangle(String s) {
        if (s == null || s.length() < 2) {
            return null;
        }
        try {
            Parser p = new Parser(s);
            Node n = p.parseTopLevel();
            if (n == null || !p.atEnd()) {
                return null;
            }
            Out o = new Out();
            n.print(o);
            String r = o.toString();
            return r.isEmpty() ? null : r;
        } catch (Throwable t) {
            // Includes StackOverflowError from pathological nesting.
            return null;
        }
    }

    // ---------------------------------------------------------------- output

    /** Append-only buffer plus the pack-expansion cursor LLVM threads through printing. */
    static final class Out {
        static final int PACK_NONE = Integer.MAX_VALUE;

        private final StringBuilder sb = new StringBuilder();
        int packIndex = PACK_NONE;
        int packMax = PACK_NONE;
        int gtInsideTemplateArgs;

        void add(String s) {
            sb.append(s);
        }

        void add(char c) {
            sb.append(c);
        }

        char back() {
            return sb.length() == 0 ? '\0' : sb.charAt(sb.length() - 1);
        }

        int pos() {
            return sb.length();
        }

        void truncate(int p) {
            if (p < sb.length()) {
                sb.setLength(p);
            }
        }

        @Override
        public String toString() {
            return sb.toString();
        }
    }

    /** Mirrors LLVM's Prec enum; lower binds tighter. */
    static final class Prec {
        static final int PRIMARY = 0;
        static final int POSTFIX = 1;
        static final int UNARY = 2;
        static final int CAST = 3;
        static final int PTR_MEM = 4;
        static final int MULTIPLICATIVE = 5;
        static final int ADDITIVE = 6;
        static final int SHIFT = 7;
        static final int SPACESHIP = 8;
        static final int RELATIONAL = 9;
        static final int EQUALITY = 10;
        static final int AND = 11;
        static final int XOR = 12;
        static final int IOR = 13;
        static final int AND_IF = 14;
        static final int OR_IF = 15;
        static final int CONDITIONAL = 16;
        static final int ASSIGN = 17;
        static final int COMMA = 18;
        static final int DEFAULT = 19;

        private Prec() { }
    }

    // ----------------------------------------------------------------- nodes

    abstract static class Node {
        abstract void printLeft(Out o);

        void printRight(Out o) { }

        final void print(Out o) {
            printLeft(o);
            printRight(o);
        }

        /** True when the node prints a trailing component after an embedded name. */
        boolean hasRhs() {
            return false;
        }

        boolean isArrayLike() {
            return false;
        }

        boolean isFunctionLike() {
            return false;
        }

        /** Unqualified spelling used to build constructor / destructor names. */
        String baseName() {
            return null;
        }

        /** Resolves pack references to the element currently being printed. */
        Node resolve(Out o) {
            return this;
        }

        /** Pack-independent resolution, for structural queries made off-line. */
        Node resolveStatic() {
            return this;
        }

        /** Precedence for expression printing. */
        int prec() {
            return Prec.PRIMARY;
        }

        final void printAsOperand(Out o, int p, boolean strictlyWorse) {
            boolean paren = prec() >= p && (prec() > p || strictlyWorse);
            if (paren) {
                o.add('(');
            }
            print(o);
            if (paren) {
                o.add(')');
            }
        }
    }

    /** Joins nodes, skipping elements that print nothing (empty parameter packs). */
    static void printList(Out o, List<Node> elems, String sep) {
        boolean first = true;
        for (Node n : elems) {
            int beforeSep = o.pos();
            if (!first) {
                o.add(sep);
            }
            int afterSep = o.pos();
            n.print(o);
            if (o.pos() == afterSep) {
                o.truncate(beforeSep);
                continue;
            }
            first = false;
        }
    }

    static final class NameType extends Node {
        final String name;

        NameType(String n) {
            this.name = n;
        }

        @Override
        void printLeft(Out o) {
            o.add(name);
        }

        @Override
        String baseName() {
            return name;
        }
    }

    /** Standard abbreviations St/Sa/Sb/Ss/Si/So/Sd in plain or expanded spelling. */
    static final class SpecialSub extends Node {
        final String text;
        final String base;

        SpecialSub(String text, String base) {
            this.text = text;
            this.base = base;
        }

        @Override
        void printLeft(Out o) {
            o.add(text);
        }

        @Override
        String baseName() {
            return base;
        }
    }

    static final class AbiTag extends Node {
        final Node child;
        final String tag;

        AbiTag(Node c, String t) {
            this.child = c;
            this.tag = t;
        }

        @Override
        void printLeft(Out o) {
            child.printLeft(o);
            o.add("[abi:");
            o.add(tag);
            o.add(']');
        }

        @Override
        void printRight(Out o) {
            child.printRight(o);
        }

        @Override
        String baseName() {
            return child.baseName();
        }
    }

    static final class NestedName extends Node {
        final Node qual;
        final Node name;

        NestedName(Node q, Node n) {
            this.qual = q;
            this.name = n;
        }

        @Override
        void printLeft(Out o) {
            qual.print(o);
            o.add("::");
            name.print(o);
        }

        @Override
        String baseName() {
            return name.baseName();
        }
    }

    static final class TemplateArgsNode extends Node {
        final List<Node> args;

        TemplateArgsNode(List<Node> a) {
            this.args = a;
        }

        @Override
        void printLeft(Out o) {
            o.add('<');
            o.gtInsideTemplateArgs++;
            printList(o, args, ", ");
            o.gtInsideTemplateArgs--;
            o.add('>');
        }
    }

    static final class NameWithTemplateArgs extends Node {
        final Node name;
        final Node args;

        NameWithTemplateArgs(Node n, Node a) {
            this.name = n;
            this.args = a;
        }

        @Override
        void printLeft(Out o) {
            name.print(o);
            args.print(o);
        }

        @Override
        String baseName() {
            return name.baseName();
        }
    }

    static final class PointerType extends Node {
        final Node pointee;

        PointerType(Node p) {
            this.pointee = p;
        }

        @Override
        boolean hasRhs() {
            return pointee.hasRhs();
        }

        @Override
        void printLeft(Out o) {
            pointee.printLeft(o);
            if (pointee.isArrayLike()) {
                o.add(' ');
            }
            if (pointee.isArrayLike() || pointee.isFunctionLike()) {
                o.add('(');
            }
            o.add('*');
        }

        @Override
        void printRight(Out o) {
            if (pointee.isArrayLike() || pointee.isFunctionLike()) {
                o.add(')');
            }
            pointee.printRight(o);
        }
    }

    static final class ReferenceType extends Node {
        final Node pointee;
        final boolean lvalue;

        ReferenceType(Node p, boolean lv) {
            this.pointee = p;
            this.lvalue = lv;
        }

        /** Reference collapsing: an lvalue ref anywhere in the chain wins. */
        private Node collapse(Out o, boolean[] isLvalue) {
            boolean lv = lvalue;
            Node cur = pointee;
            for (int i = 0; i < 256; i++) {
                Node sn = o == null ? cur.resolveStatic() : cur.resolve(o);
                if (!(sn instanceof ReferenceType)) {
                    isLvalue[0] = lv;
                    return sn;
                }
                ReferenceType r = (ReferenceType) sn;
                lv = lv || r.lvalue;
                cur = r.pointee;
            }
            isLvalue[0] = lv;
            return cur;
        }

        @Override
        boolean hasRhs() {
            return collapse(null, new boolean[1]).hasRhs();
        }

        @Override
        void printLeft(Out o) {
            boolean[] lv = new boolean[1];
            Node n = collapse(o, lv);
            n.printLeft(o);
            if (n.isArrayLike()) {
                o.add(' ');
            }
            if (n.isArrayLike() || n.isFunctionLike()) {
                o.add('(');
            }
            o.add(lv[0] ? "&" : "&&");
        }

        @Override
        void printRight(Out o) {
            Node n = collapse(o, new boolean[1]);
            if (n.isArrayLike() || n.isFunctionLike()) {
                o.add(')');
            }
            n.printRight(o);
        }
    }

    static final class PointerToMemberType extends Node {
        final Node cls;
        final Node member;

        PointerToMemberType(Node c, Node m) {
            this.cls = c;
            this.member = m;
        }

        @Override
        boolean hasRhs() {
            return member.hasRhs();
        }

        @Override
        void printLeft(Out o) {
            member.printLeft(o);
            if (member.isArrayLike() || member.isFunctionLike()) {
                o.add('(');
            } else {
                o.add(' ');
            }
            cls.print(o);
            o.add("::*");
        }

        @Override
        void printRight(Out o) {
            if (member.isArrayLike() || member.isFunctionLike()) {
                o.add(')');
            }
            member.printRight(o);
        }
    }

    static final class ArrayType extends Node {
        final Node base;
        final String dim;

        ArrayType(Node b, String d) {
            this.base = b;
            this.dim = d;
        }

        @Override
        boolean hasRhs() {
            return true;
        }

        @Override
        boolean isArrayLike() {
            return true;
        }

        @Override
        void printLeft(Out o) {
            base.printLeft(o);
        }

        @Override
        void printRight(Out o) {
            if (o.back() != ']') {
                o.add(' ');
            }
            o.add('[');
            o.add(dim);
            o.add(']');
            base.printRight(o);
        }
    }

    static final int Q_CONST = 1;
    static final int Q_VOLATILE = 2;
    static final int Q_RESTRICT = 4;

    static void printQuals(Out o, int q) {
        if ((q & Q_CONST) != 0) {
            o.add(" const");
        }
        if ((q & Q_VOLATILE) != 0) {
            o.add(" volatile");
        }
        if ((q & Q_RESTRICT) != 0) {
            o.add(" restrict");
        }
    }

    static final int REF_NONE = 0;
    static final int REF_LVALUE = 1;
    static final int REF_RVALUE = 2;

    static void printRefQual(Out o, int refQual) {
        if (refQual == REF_LVALUE) {
            o.add(" &");
        } else if (refQual == REF_RVALUE) {
            o.add(" &&");
        }
    }

    static final class FunctionType extends Node {
        final Node ret;
        final List<Node> params;
        final int cv;
        final int refQual;

        FunctionType(Node r, List<Node> p, int cv, int refQual) {
            this.ret = r;
            this.params = p;
            this.cv = cv;
            this.refQual = refQual;
        }

        @Override
        boolean hasRhs() {
            return true;
        }

        @Override
        boolean isFunctionLike() {
            return true;
        }

        @Override
        void printLeft(Out o) {
            ret.printLeft(o);
            o.add(' ');
        }

        @Override
        void printRight(Out o) {
            o.add('(');
            printList(o, params, ", ");
            o.add(')');
            ret.printRight(o);
            printQuals(o, cv);
            printRefQual(o, refQual);
        }
    }

    static final class QualType extends Node {
        final Node child;
        final int quals;

        QualType(Node c, int q) {
            this.child = c;
            this.quals = q;
        }

        @Override
        boolean hasRhs() {
            return child.hasRhs();
        }

        @Override
        boolean isArrayLike() {
            return child.isArrayLike();
        }

        @Override
        boolean isFunctionLike() {
            return child.isFunctionLike();
        }

        @Override
        void printLeft(Out o) {
            child.printLeft(o);
            printQuals(o, quals);
        }

        @Override
        void printRight(Out o) {
            child.printRight(o);
        }
    }

    /** {@code U <source-name> <type>} -- prints as {@code <type> <ext>}. */
    static final class VendorExtQualType extends Node {
        final Node ty;
        final String ext;
        final Node args;

        VendorExtQualType(Node t, String e, Node a) {
            this.ty = t;
            this.ext = e;
            this.args = a;
        }

        @Override
        void printLeft(Out o) {
            ty.print(o);
            o.add(' ');
            o.add(ext);
            if (args != null) {
                args.print(o);
            }
        }
    }

    /** {@code T vector[N]}, {@code T complex}, {@code T imaginary}. */
    static final class SuffixType extends Node {
        final Node base;
        final String suffix;

        SuffixType(Node b, String s) {
            this.base = b;
            this.suffix = s;
        }

        @Override
        void printLeft(Out o) {
            base.print(o);
            o.add(suffix);
        }
    }

    static final class FunctionEncoding extends Node {
        final Node ret;
        final Node name;
        final List<Node> params;
        final int cv;
        final int refQual;

        FunctionEncoding(Node r, Node n, List<Node> p, int cv, int refQual) {
            this.ret = r;
            this.name = n;
            this.params = p;
            this.cv = cv;
            this.refQual = refQual;
        }

        @Override
        boolean hasRhs() {
            return true;
        }

        @Override
        boolean isFunctionLike() {
            return true;
        }

        @Override
        void printLeft(Out o) {
            if (ret != null) {
                ret.printLeft(o);
                if (!ret.hasRhs()) {
                    o.add(' ');
                }
            }
            name.print(o);
        }

        @Override
        void printRight(Out o) {
            o.add('(');
            printList(o, params, ", ");
            o.add(')');
            if (ret != null) {
                ret.printRight(o);
            }
            printQuals(o, cv);
            printRefQual(o, refQual);
        }
    }

    /** "vtable for ", "typeinfo for ", "non-virtual thunk to ", ... */
    static final class SpecialName extends Node {
        final String prefix;
        final Node child;

        SpecialName(String p, Node c) {
            this.prefix = p;
            this.child = c;
        }

        @Override
        void printLeft(Out o) {
            o.add(prefix);
            child.print(o);
        }
    }

    static final class CtorVtableSpecialName extends Node {
        final Node firstType;
        final Node secondType;

        CtorVtableSpecialName(Node a, Node b) {
            this.firstType = a;
            this.secondType = b;
        }

        @Override
        void printLeft(Out o) {
            o.add("construction vtable for ");
            firstType.print(o);
            o.add("-in-");
            secondType.print(o);
        }
    }

    static final class CtorDtorName extends Node {
        final Node basis;
        final boolean isDtor;

        CtorDtorName(Node b, boolean d) {
            this.basis = b;
            this.isDtor = d;
        }

        @Override
        void printLeft(Out o) {
            if (isDtor) {
                o.add('~');
            }
            String b = basis == null ? null : basis.baseName();
            if (b != null) {
                o.add(b);
            }
        }
    }

    static final class ConversionOperatorName extends Node {
        final Node type;

        ConversionOperatorName(Node t) {
            this.type = t;
        }

        @Override
        void printLeft(Out o) {
            o.add("operator ");
            type.print(o);
        }
    }

    static final class LocalName extends Node {
        final Node encoding;
        final Node entity;

        LocalName(Node e, Node n) {
            this.encoding = e;
            this.entity = n;
        }

        @Override
        void printLeft(Out o) {
            encoding.print(o);
            o.add("::");
            entity.print(o);
        }

        @Override
        String baseName() {
            return entity.baseName();
        }
    }

    /** A {@code J...E} pack as displayed in a template argument list. */
    static final class TemplateArgumentPack extends Node {
        final List<Node> elems;

        TemplateArgumentPack(List<Node> e) {
            this.elems = e;
        }

        @Override
        void printLeft(Out o) {
            printList(o, elems, ", ");
        }
    }

    /** Table entry for a pack-valued template parameter; prints one element. */
    static final class ParameterPack extends Node {
        final List<Node> elems;

        ParameterPack(List<Node> e) {
            this.elems = e;
        }

        private void init(Out o) {
            if (o.packMax == Out.PACK_NONE) {
                o.packMax = elems.size();
                o.packIndex = 0;
            }
        }

        private Node first() {
            return elems.isEmpty() ? null : elems.get(0);
        }

        @Override
        Node resolve(Out o) {
            init(o);
            return o.packIndex < elems.size() ? elems.get(o.packIndex).resolve(o) : this;
        }

        @Override
        Node resolveStatic() {
            Node f = first();
            return f == null ? this : f.resolveStatic();
        }

        @Override
        boolean hasRhs() {
            Node f = first();
            return f != null && f.hasRhs();
        }

        @Override
        boolean isArrayLike() {
            Node f = first();
            return f != null && f.isArrayLike();
        }

        @Override
        boolean isFunctionLike() {
            Node f = first();
            return f != null && f.isFunctionLike();
        }

        @Override
        void printLeft(Out o) {
            init(o);
            if (o.packIndex < elems.size()) {
                elems.get(o.packIndex).printLeft(o);
            }
        }

        @Override
        void printRight(Out o) {
            init(o);
            if (o.packIndex < elems.size()) {
                elems.get(o.packIndex).printRight(o);
            }
        }
    }

    static final class ParameterPackExpansion extends Node {
        final Node child;

        ParameterPackExpansion(Node c) {
            this.child = c;
        }

        @Override
        void printLeft(Out o) {
            int savedIdx = o.packIndex;
            int savedMax = o.packMax;
            o.packIndex = Out.PACK_NONE;
            o.packMax = Out.PACK_NONE;
            int start = o.pos();
            try {
                child.print(o);
                if (o.packMax == Out.PACK_NONE) {
                    // No pack underneath: this is a pack expansion of a plain entity.
                    o.add("...");
                    return;
                }
                if (o.packMax == 0) {
                    o.truncate(start);
                    return;
                }
                int max = o.packMax;
                for (int i = 1; i < max; i++) {
                    o.add(", ");
                    o.packIndex = i;
                    child.print(o);
                }
            } finally {
                o.packIndex = savedIdx;
                o.packMax = savedMax;
            }
        }
    }

    static final class IntegerLiteral extends Node {
        final String type;
        final String value;

        IntegerLiteral(String t, String v) {
            this.type = t;
            this.value = v;
        }

        @Override
        void printLeft(Out o) {
            if (type.length() > 3) {
                o.add('(');
                o.add(type);
                o.add(')');
            }
            if (!value.isEmpty() && value.charAt(0) == 'n') {
                o.add('-');
                o.add(value.substring(1));
            } else {
                o.add(value);
            }
            if (type.length() <= 3) {
                o.add(type);
            }
        }
    }

    /** {@code (SomeEnum)3}, {@code (void*)0} style literals. */
    static final class TypedLiteral extends Node {
        final Node type;
        final String value;

        TypedLiteral(Node t, String v) {
            this.type = t;
            this.value = v;
        }

        @Override
        void printLeft(Out o) {
            o.add('(');
            type.print(o);
            o.add(')');
            if (!value.isEmpty() && value.charAt(0) == 'n') {
                o.add('-');
                o.add(value.substring(1));
            } else {
                o.add(value);
            }
        }
    }

    static final class DecltypeNode extends Node {
        final Node expr;

        DecltypeNode(Node e) {
            this.expr = e;
        }

        @Override
        void printLeft(Out o) {
            o.add("decltype(");
            expr.print(o);
            o.add(')');
        }
    }

    static final class BinaryExpr extends Node {
        final Node lhs;
        final String op;
        final Node rhs;
        final int precedence;

        BinaryExpr(Node l, String op, Node r, int p) {
            this.lhs = l;
            this.op = op;
            this.rhs = r;
            this.precedence = p;
        }

        @Override
        int prec() {
            return precedence;
        }

        @Override
        void printLeft(Out o) {
            boolean parenAll = o.gtInsideTemplateArgs > 0
                    && (op.equals(">") || op.equals(">>"));
            if (parenAll) {
                o.add('(');
            }
            boolean isAssign = precedence == Prec.ASSIGN;
            lhs.printAsOperand(o, isAssign ? Prec.OR_IF : precedence, !isAssign);
            if (!op.equals(",")) {
                o.add(' ');
            }
            o.add(op);
            o.add(' ');
            rhs.printAsOperand(o, precedence, isAssign);
            if (parenAll) {
                o.add(')');
            }
        }
    }

    static final class PrefixExpr extends Node {
        final String op;
        final Node child;
        final int precedence;

        PrefixExpr(String op, Node c, int p) {
            this.op = op;
            this.child = c;
            this.precedence = p;
        }

        @Override
        int prec() {
            return precedence;
        }

        @Override
        void printLeft(Out o) {
            o.add(op);
            child.printAsOperand(o, precedence, false);
        }
    }

    static final class PostfixExpr extends Node {
        final Node child;
        final String op;
        final int precedence;

        PostfixExpr(Node c, String op, int p) {
            this.child = c;
            this.op = op;
            this.precedence = p;
        }

        @Override
        int prec() {
            return precedence;
        }

        @Override
        void printLeft(Out o) {
            child.printAsOperand(o, precedence, true);
            o.add(op);
        }
    }

    /** {@code sizeof (x)}, {@code alignof (T)}, ... */
    static final class EnclosingExpr extends Node {
        final String prefix;
        final Node infix;

        EnclosingExpr(String p, Node i) {
            this.prefix = p;
            this.infix = i;
        }

        @Override
        void printLeft(Out o) {
            o.add(prefix);
            o.add('(');
            infix.print(o);
            o.add(')');
        }
    }

    static final class CallExpr extends Node {
        final Node callee;
        final List<Node> args;

        CallExpr(Node c, List<Node> a) {
            this.callee = c;
            this.args = a;
        }

        @Override
        int prec() {
            return Prec.POSTFIX;
        }

        @Override
        void printLeft(Out o) {
            callee.print(o);
            o.add('(');
            printList(o, args, ", ");
            o.add(')');
        }
    }

    static final class MemberExpr extends Node {
        final Node lhs;
        final String kind;
        final Node rhs;

        MemberExpr(Node l, String k, Node r) {
            this.lhs = l;
            this.kind = k;
            this.rhs = r;
        }

        @Override
        int prec() {
            return Prec.POSTFIX;
        }

        @Override
        void printLeft(Out o) {
            lhs.printAsOperand(o, Prec.POSTFIX, true);
            o.add(kind);
            rhs.print(o);
        }
    }

    static final class ArraySubscriptExpr extends Node {
        final Node op1;
        final Node op2;

        ArraySubscriptExpr(Node a, Node b) {
            this.op1 = a;
            this.op2 = b;
        }

        @Override
        int prec() {
            return Prec.POSTFIX;
        }

        @Override
        void printLeft(Out o) {
            op1.printAsOperand(o, Prec.POSTFIX, true);
            o.add('[');
            op2.print(o);
            o.add(']');
        }
    }

    static final class ConditionalExpr extends Node {
        final Node cond;
        final Node then;
        final Node els;

        ConditionalExpr(Node c, Node t, Node e) {
            this.cond = c;
            this.then = t;
            this.els = e;
        }

        @Override
        int prec() {
            return Prec.CONDITIONAL;
        }

        @Override
        void printLeft(Out o) {
            cond.printAsOperand(o, Prec.CONDITIONAL, true);
            o.add(" ? ");
            then.printAsOperand(o, Prec.ASSIGN, false);
            o.add(" : ");
            els.printAsOperand(o, Prec.ASSIGN, true);
        }
    }

    static final class CastExpr extends Node {
        final String castKind;
        final Node to;
        final Node from;

        CastExpr(String k, Node t, Node f) {
            this.castKind = k;
            this.to = t;
            this.from = f;
        }

        @Override
        int prec() {
            return Prec.POSTFIX;
        }

        @Override
        void printLeft(Out o) {
            o.add(castKind);
            o.add('<');
            to.print(o);
            o.add(">(");
            from.printAsOperand(o, Prec.PRIMARY, false);
            o.add(')');
        }
    }

    /** {@code (T)(a, b)} functional / C-style conversion. */
    static final class ConversionExpr extends Node {
        final Node type;
        final List<Node> expressions;

        ConversionExpr(Node t, List<Node> e) {
            this.type = t;
            this.expressions = e;
        }

        @Override
        int prec() {
            return Prec.CAST;
        }

        @Override
        void printLeft(Out o) {
            o.add('(');
            type.print(o);
            o.add(')');
            o.add('(');
            printList(o, expressions, ", ");
            o.add(')');
        }
    }

    // ---------------------------------------------------------------- parser

    /** Thrown internally when the recursion guard trips. */
    static final class TooDeep extends RuntimeException {
        private static final long serialVersionUID = 1L;

        TooDeep() {
            super(null, null, false, false);
        }
    }

    /** Out-parameters threaded through name parsing, as in LLVM's NameState. */
    static final class NameState {
        int cvQualifiers;
        int refQualifier = REF_NONE;
        boolean endsWithTemplateArgs;
        boolean ctorDtorConversion;
    }

    static final class Parser {
        private final String s;
        private int p;
        /** Substitution table: S_ is index 0, S0_ index 1, S1_ index 2, ... */
        private final List<Node> subs = new ArrayList<>();
        private List<Node> templateParams = new ArrayList<>();
        private boolean tryToParseTemplateArgs = true;
        private int depth;

        Parser(String s) {
            this.s = s;
        }

        // ---- character helpers

        boolean atEnd() {
            return p >= s.length();
        }

        char peek() {
            return p < s.length() ? s.charAt(p) : '\0';
        }

        char peek(int k) {
            return p + k < s.length() ? s.charAt(p + k) : '\0';
        }

        void advance() {
            p++;
        }

        boolean consumeIf(char c) {
            if (peek() == c) {
                p++;
                return true;
            }
            return false;
        }

        boolean consumeIf(String t) {
            if (s.startsWith(t, p)) {
                p += t.length();
                return true;
            }
            return false;
        }

        private void enter() {
            if (++depth > 300) {
                throw new TooDeep();
            }
        }

        private void leave() {
            depth--;
        }

        private static boolean isDigit(char c) {
            return c >= '0' && c <= '9';
        }

        // ---- top level

        Node parseTopLevel() {
            if (!consumeIf("_Z") && !consumeIf("__Z")) {
                return null;
            }
            Node n = parseEncoding();
            if (n == null) {
                return null;
            }
            if (peek() == '.') {
                // Clone / transformation suffix, e.g. "_Z3foov.cold".
                String suffix = s.substring(p);
                p = s.length();
                Out o = new Out();
                n.print(o);
                return new NameType(o + " [clone " + suffix + "]");
            }
            return n;
        }

        private boolean isEndOfEncoding() {
            return atEnd() || peek() == 'E' || peek() == '.';
        }

        Node parseEncoding() {
            enter();
            try {
                if (peek() == 'G' || peek() == 'T') {
                    return parseSpecialName();
                }
                NameState st = new NameState();
                Node name = parseName(st);
                if (name == null) {
                    return null;
                }
                if (isEndOfEncoding()) {
                    return name;
                }
                // The return type is mangled only for function templates, and
                // never for constructors, destructors or conversion operators.
                Node ret = null;
                if (st.endsWithTemplateArgs && !st.ctorDtorConversion) {
                    ret = parseType();
                    if (ret == null) {
                        return null;
                    }
                }
                List<Node> params = new ArrayList<>();
                if (!consumeIf('v')) {
                    while (!isEndOfEncoding()) {
                        Node t = parseType();
                        if (t == null) {
                            return null;
                        }
                        params.add(t);
                    }
                }
                return new FunctionEncoding(ret, name, params,
                        st.cvQualifiers, st.refQualifier);
            } finally {
                leave();
            }
        }

        // ---- special names

        Node parseSpecialName() {
            enter();
            try {
                if (consumeIf('T')) {
                    char c = peek();
                    switch (c) {
                        case 'V':
                            advance();
                            return wrapType("vtable for ");
                        case 'T':
                            advance();
                            return wrapType("VTT for ");
                        case 'I':
                            advance();
                            return wrapType("typeinfo for ");
                        case 'S':
                            advance();
                            return wrapType("typeinfo name for ");
                        case 'W':
                            advance();
                            return wrapName("thread-local wrapper routine for ");
                        case 'H':
                            advance();
                            return wrapName("thread-local initialization routine for ");
                        case 'h':
                            advance();
                            return thunk("non-virtual thunk to ", false);
                        case 'v':
                            advance();
                            return thunk("virtual thunk to ", true);
                        case 'c': {
                            advance();
                            if (!parseCallOffset() || !parseCallOffset()) {
                                return null;
                            }
                            Node e = parseEncoding();
                            return e == null ? null
                                    : new SpecialName("covariant return thunk to ", e);
                        }
                        case 'C': {
                            advance();
                            Node first = parseType();
                            if (first == null || parseNumber(true) == null
                                    || !consumeIf('_')) {
                                return null;
                            }
                            Node second = parseType();
                            return second == null ? null
                                    : new CtorVtableSpecialName(second, first);
                        }
                        default:
                            return null;
                    }
                }
                if (consumeIf('G')) {
                    if (consumeIf('V')) {
                        return wrapName("guard variable for ");
                    }
                    if (consumeIf('R')) {
                        Node n = parseName(null);
                        if (n == null) {
                            return null;
                        }
                        parseSeqId();
                        consumeIf('_');
                        return new SpecialName("reference temporary for ", n);
                    }
                }
                return null;
            } finally {
                leave();
            }
        }

        private Node wrapType(String prefix) {
            Node t = parseType();
            return t == null ? null : new SpecialName(prefix, t);
        }

        private Node wrapName(String prefix) {
            Node n = parseName(null);
            return n == null ? null : new SpecialName(prefix, n);
        }

        private Node thunk(String prefix, boolean virt) {
            if (parseOffsetThenUnderscore() == null) {
                return null;
            }
            if (virt && parseOffsetThenUnderscore() == null) {
                return null;
            }
            Node e = parseEncoding();
            return e == null ? null : new SpecialName(prefix, e);
        }

        private String parseOffsetThenUnderscore() {
            String n = parseNumber(true);
            if (n == null || !consumeIf('_')) {
                return null;
            }
            return n;
        }

        private boolean parseCallOffset() {
            if (consumeIf('h')) {
                return parseOffsetThenUnderscore() != null;
            }
            if (consumeIf('v')) {
                return parseOffsetThenUnderscore() != null
                        && parseOffsetThenUnderscore() != null;
            }
            return false;
        }

        // ---- numbers and identifiers

        String parseNumber(boolean allowNegative) {
            int start = p;
            if (allowNegative && peek() == 'n') {
                advance();
            }
            if (!isDigit(peek())) {
                p = start;
                return null;
            }
            while (isDigit(peek())) {
                advance();
            }
            return s.substring(start, p);
        }

        /** Base-36 seq-id; returns -1 on overflow, -2 when absent. */
        private int parseSeqId() {
            int start = p;
            int v = 0;
            while (true) {
                char c = peek();
                int d;
                if (isDigit(c)) {
                    d = c - '0';
                } else if (c >= 'A' && c <= 'Z') {
                    d = c - 'A' + 10;
                } else {
                    break;
                }
                v = v * 36 + d;
                if (v > 1000000) {
                    return -1;
                }
                advance();
            }
            return p == start ? -2 : v;
        }

        Node parseSourceName() {
            String num = parseNumber(false);
            if (num == null || num.length() > 9) {
                return null;
            }
            int len = Integer.parseInt(num);
            if (len <= 0 || p + len > s.length()) {
                return null;
            }
            String name = s.substring(p, p + len);
            p += len;
            if (name.startsWith("_GLOBAL__N_")) {
                return new NameType("(anonymous namespace)");
            }
            return new NameType(name);
        }

        // ---- names

        Node parseName(NameState st) {
            enter();
            try {
                if (peek() == 'N') {
                    return parseNestedName(st);
                }
                if (peek() == 'Z') {
                    return parseLocalName(st);
                }
                boolean[] isSubst = new boolean[1];
                Node result = parseUnscopedName(st, isSubst);
                if (result == null) {
                    return null;
                }
                if (peek() == 'I') {
                    // <unscoped-template-name> <template-args>: the template name
                    // is a substitution candidate, the instantiation is not.
                    if (!isSubst[0]) {
                        subs.add(result);
                    }
                    Node ta = parseTemplateArgs(st != null);
                    if (ta == null) {
                        return null;
                    }
                    if (st != null) {
                        st.endsWithTemplateArgs = true;
                    }
                    result = new NameWithTemplateArgs(result, ta);
                }
                return result;
            } finally {
                leave();
            }
        }

        Node parseUnscopedName(NameState st, boolean[] isSubst) {
            Node std = null;
            if (consumeIf("St")) {
                std = new NameType("std");
            }
            if (peek() == 'S' && std == null) {
                Node sub = parseSubstitution();
                if (sub == null) {
                    return null;
                }
                if (isSubst != null) {
                    isSubst[0] = true;
                }
                return sub;
            }
            Node n = parseUnqualifiedName(st, std);
            if (n == null) {
                return null;
            }
            return std == null ? n : new NestedName(std, n);
        }

        Node parseNestedName(NameState st) {
            enter();
            try {
                if (!consumeIf('N')) {
                    return null;
                }
                int cv = parseCVQualifiers();
                if (st != null) {
                    st.cvQualifiers = cv;
                }
                if (consumeIf('O')) {
                    if (st != null) {
                        st.refQualifier = REF_RVALUE;
                    }
                } else if (consumeIf('R')) {
                    if (st != null) {
                        st.refQualifier = REF_LVALUE;
                    }
                }

                Node soFar = null;
                if (consumeIf("St")) {
                    soFar = new NameType("std");
                }

                while (!consumeIf('E')) {
                    if (atEnd()) {
                        return null;
                    }
                    consumeIf('L');

                    if (consumeIf('M')) {
                        // <data-member-prefix>
                        if (soFar == null) {
                            return null;
                        }
                        continue;
                    }
                    if (peek() == 'T') {
                        Node tp = parseTemplateParam();
                        if (tp == null) {
                            return null;
                        }
                        soFar = soFar == null ? tp : new NestedName(soFar, tp);
                        clearTemplateArgFlag(st);
                        subs.add(soFar);
                        continue;
                    }
                    if (peek() == 'I') {
                        if (soFar == null) {
                            return null;
                        }
                        Node ta = parseTemplateArgs(st != null);
                        if (ta == null) {
                            return null;
                        }
                        soFar = new NameWithTemplateArgs(soFar, ta);
                        if (st != null) {
                            st.endsWithTemplateArgs = true;
                        }
                        subs.add(soFar);
                        continue;
                    }
                    if (peek() == 'D' && (peek(1) == 't' || peek(1) == 'T')) {
                        Node dt = parseDecltype();
                        if (dt == null) {
                            return null;
                        }
                        soFar = soFar == null ? dt : new NestedName(soFar, dt);
                        clearTemplateArgFlag(st);
                        subs.add(soFar);
                        continue;
                    }
                    if (peek() == 'S' && peek(1) != 't') {
                        Node sub = parseSubstitution();
                        if (sub == null) {
                            return null;
                        }
                        Node prev = soFar;
                        soFar = soFar == null ? sub : new NestedName(soFar, sub);
                        clearTemplateArgFlag(st);
                        // A leading substitution is already in the table.
                        if (prev != null) {
                            subs.add(soFar);
                        }
                        continue;
                    }
                    Node comp = parseUnqualifiedName(st, soFar);
                    if (comp == null) {
                        return null;
                    }
                    soFar = soFar == null ? comp : new NestedName(soFar, comp);
                    clearTemplateArgFlag(st);
                    subs.add(soFar);
                }

                if (soFar == null || subs.isEmpty()) {
                    return null;
                }
                // The complete nested-name is not itself a candidate; parseType()
                // re-adds it when the name denotes a type.
                subs.remove(subs.size() - 1);
                return soFar;
            } finally {
                leave();
            }
        }

        private static void clearTemplateArgFlag(NameState st) {
            if (st != null) {
                st.endsWithTemplateArgs = false;
            }
        }

        Node parseLocalName(NameState st) {
            enter();
            try {
                if (!consumeIf('Z')) {
                    return null;
                }
                Node enc = parseEncoding();
                if (enc == null || !consumeIf('E')) {
                    return null;
                }
                if (consumeIf('s')) {
                    parseDiscriminator();
                    return new LocalName(enc, new NameType("string literal"));
                }
                if (consumeIf('d')) {
                    parseNumber(true);
                    if (!consumeIf('_')) {
                        return null;
                    }
                    Node ent = parseName(st);
                    return ent == null ? null : new LocalName(enc, ent);
                }
                Node ent = parseName(st);
                if (ent == null) {
                    return null;
                }
                parseDiscriminator();
                return new LocalName(enc, ent);
            } finally {
                leave();
            }
        }

        private void parseDiscriminator() {
            int start = p;
            if (!consumeIf('_')) {
                return;
            }
            if (consumeIf('_')) {
                if (parseNumber(false) == null || !consumeIf('_')) {
                    p = start;
                }
                return;
            }
            if (!isDigit(peek())) {
                p = start;
                return;
            }
            advance();
        }

        Node parseUnqualifiedName(NameState st, Node scope) {
            enter();
            try {
                consumeIf('L');
                Node result;
                char c = peek();
                if (c >= '1' && c <= '9') {
                    result = parseSourceName();
                } else if (c == 'U') {
                    result = parseUnnamedTypeName();
                } else if (c == 'D' && peek(1) == 'C') {
                    result = parseStructuredBindingName();
                } else if (isCtorDtorStart()) {
                    boolean isDtor = peek() == 'D';
                    p += 2;
                    if (st != null) {
                        st.ctorDtorConversion = true;
                    }
                    result = new CtorDtorName(scope, isDtor);
                } else {
                    result = parseOperatorName(st);
                }
                if (result == null) {
                    return null;
                }
                return parseAbiTags(result);
            } finally {
                leave();
            }
        }

        private Node parseStructuredBindingName() {
            p += 2;
            StringBuilder sb = new StringBuilder("[");
            boolean first = true;
            while (!consumeIf('E')) {
                if (atEnd()) {
                    return null;
                }
                Node n = parseSourceName();
                if (n == null) {
                    return null;
                }
                if (!first) {
                    sb.append(", ");
                }
                sb.append(n.baseName());
                first = false;
            }
            return new NameType(sb.append(']').toString());
        }

        private Node parseAbiTags(Node n) {
            Node r = n;
            while (peek() == 'B') {
                advance();
                Node tag = parseSourceName();
                if (tag == null) {
                    return null;
                }
                r = new AbiTag(r, tag.baseName());
            }
            return r;
        }

        private boolean isCtorDtorStart() {
            char c = peek();
            char d = peek(1);
            if (c == 'C') {
                return d >= '1' && d <= '5';
            }
            if (c == 'D') {
                return d == '0' || d == '1' || d == '2' || d == '4' || d == '5';
            }
            return false;
        }

        private Node parseUnnamedTypeName() {
            if (consumeIf("Ut")) {
                String n = parseNumber(false);
                if (!consumeIf('_')) {
                    return null;
                }
                return new NameType("'unnamed" + (n == null ? "" : n) + "'");
            }
            if (consumeIf("Ul")) {
                List<Node> params = new ArrayList<>();
                if (consumeIf('v')) {
                    if (!consumeIf('E')) {
                        return null;
                    }
                } else {
                    while (!consumeIf('E')) {
                        if (atEnd()) {
                            return null;
                        }
                        Node t = parseType();
                        if (t == null) {
                            return null;
                        }
                        params.add(t);
                    }
                }
                String n = parseNumber(false);
                if (!consumeIf('_')) {
                    return null;
                }
                Out o = new Out();
                o.add("'lambda");
                o.add(n == null ? "" : n);
                o.add("'(");
                printList(o, params, ", ");
                o.add(')');
                return new NameType(o.toString());
            }
            return null;
        }

        // ---- operator names

        private Node parseOperatorName(NameState st) {
            if (p + 2 > s.length()) {
                return null;
            }
            String code = s.substring(p, p + 2);
            if (code.equals("cv")) {
                p += 2;
                // A following 'I' belongs to the enclosing name, not to the type.
                boolean saved = tryToParseTemplateArgs;
                tryToParseTemplateArgs = false;
                Node ty;
                try {
                    ty = parseType();
                } finally {
                    tryToParseTemplateArgs = saved;
                }
                if (ty == null) {
                    return null;
                }
                if (st != null) {
                    st.ctorDtorConversion = true;
                }
                return new ConversionOperatorName(ty);
            }
            if (code.equals("li")) {
                p += 2;
                Node n = parseSourceName();
                return n == null ? null : new NameType("operator\"\" " + n.baseName());
            }
            String sym = OperatorTable.nameFor(code);
            if (sym == null) {
                return null;
            }
            p += 2;
            return new NameType(sym);
        }

        // ---- CV qualifiers

        int parseCVQualifiers() {
            int q = 0;
            if (consumeIf('r')) {
                q |= Q_RESTRICT;
            }
            if (consumeIf('V')) {
                q |= Q_VOLATILE;
            }
            if (consumeIf('K')) {
                q |= Q_CONST;
            }
            return q;
        }

        // ---- substitutions

        Node parseSubstitution() {
            if (!consumeIf('S')) {
                return null;
            }
            String[] special = specialSubFor(peek());
            if (special != null) {
                advance();
                // ABI 5.1.5.2: when a standard abbreviation is the prefix of a
                // <ctor-dtor-name>, the expanded spelling is used instead.
                boolean expand = peek() == 'C' || (peek() == 'D' && peek(1) != 'C');
                return new SpecialSub(expand ? special[1] : special[0], special[2]);
            }
            if (peek() == '_') {
                advance();
                return subs.isEmpty() ? null : subs.get(0);
            }
            int id = parseSeqId();
            if (id < 0 || !consumeIf('_')) {
                return null;
            }
            int idx = id + 1;
            return idx >= subs.size() ? null : subs.get(idx);
        }

        /** {plain, expanded, base name} for the standard abbreviations. */
        private static String[] specialSubFor(char c) {
            switch (c) {
                case 'a':
                    return new String[] {"std::allocator", "std::allocator", "allocator"};
                case 'b':
                    return new String[] {"std::basic_string", "std::basic_string",
                        "basic_string"};
                case 's':
                    return new String[] {"std::string",
                        "std::basic_string<char, std::char_traits<char>, "
                                + "std::allocator<char>>", "basic_string"};
                case 'i':
                    return new String[] {"std::istream",
                        "std::basic_istream<char, std::char_traits<char>>", "basic_istream"};
                case 'o':
                    return new String[] {"std::ostream",
                        "std::basic_ostream<char, std::char_traits<char>>", "basic_ostream"};
                case 'd':
                    return new String[] {"std::iostream",
                        "std::basic_iostream<char, std::char_traits<char>>", "basic_iostream"};
                default:
                    return null;
            }
        }

        // ---- template parameters and arguments

        Node parseTemplateParam() {
            if (!consumeIf('T')) {
                return null;
            }
            if (consumeIf('L')) {
                // TL <level> __ <idx> _ ; only the innermost level is modelled.
                if (parseNumber(false) == null || !consumeIf("__")) {
                    return null;
                }
            }
            int index = 0;
            if (!consumeIf('_')) {
                String n = parseNumber(false);
                if (n == null || n.length() > 8 || !consumeIf('_')) {
                    return null;
                }
                index = Integer.parseInt(n) + 1;
            }
            if (index >= templateParams.size()) {
                return null;
            }
            return templateParams.get(index);
        }

        Node parseTemplateArgs(boolean tagTemplates) {
            enter();
            try {
                if (!consumeIf('I')) {
                    return null;
                }
                List<Node> args = new ArrayList<>();
                List<Node> table = null;
                if (tagTemplates) {
                    table = new ArrayList<>();
                    templateParams = table;
                }
                while (!consumeIf('E')) {
                    if (atEnd()) {
                        return null;
                    }
                    Node arg = parseTemplateArg();
                    if (arg == null) {
                        return null;
                    }
                    args.add(arg);
                    if (table != null) {
                        // A pack is displayed expanded but indexed element-wise.
                        table.add(arg instanceof TemplateArgumentPack
                                ? new ParameterPack(((TemplateArgumentPack) arg).elems)
                                : arg);
                    }
                }
                return new TemplateArgsNode(args);
            } finally {
                leave();
            }
        }

        private boolean isTemplateParamDeclStart() {
            if (peek() != 'T') {
                return false;
            }
            char c = peek(1);
            return c == 'y' || c == 'n' || c == 't' || c == 'p' || c == 'k';
        }

        /** Ty | Tk <name> | Tn <type> | Tt <decl>* E | Tp <decl> -- consumed, not printed. */
        private boolean parseTemplateParamDecl() {
            if (consumeIf("Ty")) {
                return true;
            }
            if (consumeIf("Tk")) {
                return parseName(null) != null;
            }
            if (consumeIf("Tn")) {
                return parseType() != null;
            }
            if (consumeIf("Tt")) {
                while (!consumeIf('E')) {
                    if (atEnd() || !parseTemplateParamDecl()) {
                        return false;
                    }
                }
                return true;
            }
            if (consumeIf("Tp")) {
                return parseTemplateParamDecl();
            }
            return false;
        }

        Node parseTemplateArg() {
            enter();
            try {
                while (isTemplateParamDeclStart()) {
                    if (!parseTemplateParamDecl()) {
                        return null;
                    }
                }
                switch (peek()) {
                    case 'X': {
                        advance();
                        Node e = parseExpr();
                        return e == null || !consumeIf('E') ? null : e;
                    }
                    case 'J': {
                        advance();
                        List<Node> elems = new ArrayList<>();
                        while (!consumeIf('E')) {
                            if (atEnd()) {
                                return null;
                            }
                            Node a = parseTemplateArg();
                            if (a == null) {
                                return null;
                            }
                            elems.add(a);
                        }
                        return new TemplateArgumentPack(elems);
                    }
                    case 'L':
                        return parseExprPrimary();
                    default:
                        return parseType();
                }
            } finally {
                leave();
            }
        }

        // ---- types

        Node parseType() {
            enter();
            try {
                return parseTypeImpl();
            } finally {
                leave();
            }
        }

        private Node parseTypeImpl() {
            Node result;
            char c = peek();

            // <qualified-type>; cv-qualifiers directly before F bind to the
            // function type itself and print after the parameter list.
            if (c == 'r' || c == 'V' || c == 'K') {
                int after = 0;
                if (peek(after) == 'r') {
                    after++;
                }
                if (peek(after) == 'V') {
                    after++;
                }
                if (peek(after) == 'K') {
                    after++;
                }
                if (peek(after) == 'F'
                        || (peek(after) == 'D' && peek(after + 1) == 'o')) {
                    result = parseFunctionType();
                } else {
                    int quals = parseCVQualifiers();
                    Node ty = parseType();
                    if (ty == null) {
                        return null;
                    }
                    result = new QualType(ty, quals);
                }
                if (result == null) {
                    return null;
                }
                subs.add(result);
                return result;
            }

            // <builtin-type>: never a substitution candidate, so return directly.
            String builtin = builtinFor(c);
            if (builtin != null) {
                advance();
                return new NameType(builtin);
            }

            if (c == 'u') {
                advance();
                Node n = parseSourceName();
                if (n == null) {
                    return null;
                }
                result = n;
                if (peek() == 'I') {
                    Node ta = parseTemplateArgs(false);
                    if (ta == null) {
                        return null;
                    }
                    result = new NameWithTemplateArgs(result, ta);
                }
                subs.add(result);
                return result;
            }

            if (c == 'D') {
                return parseDTypes();
            }

            switch (c) {
                case 'F':
                    result = parseFunctionType();
                    break;
                case 'A':
                    result = parseArrayType();
                    break;
                case 'M': {
                    advance();
                    Node cls = parseType();
                    if (cls == null) {
                        return null;
                    }
                    Node member = parseType();
                    if (member == null) {
                        return null;
                    }
                    result = new PointerToMemberType(cls, member);
                    break;
                }
                case 'T': {
                    result = parseTemplateParam();
                    if (result == null) {
                        return null;
                    }
                    if (tryToParseTemplateArgs && peek() == 'I') {
                        Node ta = parseTemplateArgs(false);
                        if (ta == null) {
                            return null;
                        }
                        result = new NameWithTemplateArgs(result, ta);
                    }
                    break;
                }
                case 'P': {
                    advance();
                    Node t = parseType();
                    if (t == null) {
                        return null;
                    }
                    result = new PointerType(t);
                    break;
                }
                case 'R': {
                    advance();
                    Node t = parseType();
                    if (t == null) {
                        return null;
                    }
                    result = new ReferenceType(t, true);
                    break;
                }
                case 'O': {
                    advance();
                    Node t = parseType();
                    if (t == null) {
                        return null;
                    }
                    result = new ReferenceType(t, false);
                    break;
                }
                case 'C': {
                    advance();
                    Node t = parseType();
                    if (t == null) {
                        return null;
                    }
                    result = new SuffixType(t, " complex");
                    break;
                }
                case 'G': {
                    advance();
                    Node t = parseType();
                    if (t == null) {
                        return null;
                    }
                    result = new SuffixType(t, " imaginary");
                    break;
                }
                case 'U': {
                    advance();
                    Node n = parseSourceName();
                    if (n == null) {
                        return null;
                    }
                    Node ta = null;
                    if (peek() == 'I') {
                        ta = parseTemplateArgs(false);
                        if (ta == null) {
                            return null;
                        }
                    }
                    Node t = parseType();
                    if (t == null) {
                        return null;
                    }
                    result = new VendorExtQualType(t, n.baseName(), ta);
                    break;
                }
                case 'S': {
                    if (peek(1) != 't') {
                        Node sub = parseSubstitution();
                        if (sub == null) {
                            return null;
                        }
                        if (peek() != 'I') {
                            // A bare substitution is already in the table.
                            return sub;
                        }
                        Node ta = parseTemplateArgs(false);
                        if (ta == null) {
                            return null;
                        }
                        result = new NameWithTemplateArgs(sub, ta);
                        break;
                    }
                    result = parseClassEnumType();
                    break;
                }
                default:
                    result = parseClassEnumType();
                    break;
            }

            if (result == null) {
                return null;
            }
            subs.add(result);
            return result;
        }

        private static String builtinFor(char c) {
            switch (c) {
                case 'v': return "void";
                case 'w': return "wchar_t";
                case 'b': return "bool";
                case 'c': return "char";
                case 'a': return "signed char";
                case 'h': return "unsigned char";
                case 's': return "short";
                case 't': return "unsigned short";
                case 'i': return "int";
                case 'j': return "unsigned int";
                case 'l': return "long";
                case 'm': return "unsigned long";
                case 'x': return "long long";
                case 'y': return "unsigned long long";
                case 'n': return "__int128";
                case 'o': return "unsigned __int128";
                case 'f': return "float";
                case 'd': return "double";
                case 'e': return "long double";
                case 'g': return "__float128";
                case 'z': return "...";
                default: return null;
            }
        }

        /** Types spelled with a leading 'D'. */
        private Node parseDTypes() {
            char c1 = peek(1);
            switch (c1) {
                case 'd': p += 2; return new NameType("decimal64");
                case 'e': p += 2; return new NameType("decimal128");
                case 'f': p += 2; return new NameType("decimal32");
                case 'h': p += 2; return new NameType("half");
                case 'i': p += 2; return new NameType("char32_t");
                case 's': p += 2; return new NameType("char16_t");
                case 'u': p += 2; return new NameType("char8_t");
                case 'a': p += 2; return new NameType("auto");
                case 'c': p += 2; return new NameType("decltype(auto)");
                case 'n': p += 2; return new NameType("std::nullptr_t");
                case 'F': {
                    p += 2;
                    String n = parseNumber(false);
                    if (n == null || !consumeIf('_')) {
                        return null;
                    }
                    return new NameType("_Float" + n);
                }
                case 'B':
                case 'U': {
                    boolean unsigned = c1 == 'U';
                    p += 2;
                    String inner = parseNumber(false);
                    if (inner == null) {
                        Node e = parseExpr();
                        if (e == null) {
                            return null;
                        }
                        Out o = new Out();
                        e.print(o);
                        inner = o.toString();
                    }
                    if (!consumeIf('_')) {
                        return null;
                    }
                    Node r = new NameType(
                            (unsigned ? "unsigned " : "") + "_BitInt(" + inner + ")");
                    subs.add(r);
                    return r;
                }
                case 'v': {
                    p += 2;
                    String dim = parseNumber(false);
                    if (dim == null) {
                        if (!consumeIf('_')) {
                            return null;
                        }
                        Node e = parseExpr();
                        if (e == null || !consumeIf('_')) {
                            return null;
                        }
                        Out o = new Out();
                        e.print(o);
                        dim = o.toString();
                    } else if (!consumeIf('_')) {
                        return null;
                    }
                    Node base = parseType();
                    if (base == null) {
                        return null;
                    }
                    Node r = new SuffixType(base, " vector[" + dim + "]");
                    subs.add(r);
                    return r;
                }
                case 'p': {
                    p += 2;
                    Node t = parseType();
                    if (t == null) {
                        return null;
                    }
                    Node r = new ParameterPackExpansion(t);
                    subs.add(r);
                    return r;
                }
                case 't':
                case 'T': {
                    Node d = parseDecltype();
                    if (d == null) {
                        return null;
                    }
                    subs.add(d);
                    return d;
                }
                default:
                    return null;
            }
        }

        Node parseDecltype() {
            if (peek() != 'D' || (peek(1) != 't' && peek(1) != 'T')) {
                return null;
            }
            p += 2;
            Node e = parseExpr();
            if (e == null || !consumeIf('E')) {
                return null;
            }
            return new DecltypeNode(e);
        }

        private Node parseArrayType() {
            if (!consumeIf('A')) {
                return null;
            }
            String dim = "";
            if (peek() != '_') {
                String n = parseNumber(false);
                if (n != null) {
                    dim = n;
                } else {
                    Node e = parseExpr();
                    if (e == null) {
                        return null;
                    }
                    Out o = new Out();
                    e.print(o);
                    dim = o.toString();
                }
            }
            if (!consumeIf('_')) {
                return null;
            }
            Node base = parseType();
            return base == null ? null : new ArrayType(base, dim);
        }

        private Node parseFunctionType() {
            int cv = parseCVQualifiers();
            if (consumeIf("Do")) {
                // noexcept
            } else if (consumeIf("DO")) {
                Node e = parseExpr();
                if (e == null || !consumeIf('E')) {
                    return null;
                }
            } else if (consumeIf("Dw")) {
                while (!consumeIf('E')) {
                    if (atEnd() || parseType() == null) {
                        return null;
                    }
                }
            }
            if (!consumeIf('F')) {
                return null;
            }
            consumeIf('Y');
            Node ret = parseType();
            if (ret == null) {
                return null;
            }
            List<Node> params = new ArrayList<>();
            int refQual = REF_NONE;
            while (true) {
                if (consumeIf('E')) {
                    break;
                }
                if (consumeIf('v')) {
                    continue;
                }
                if (consumeIf("RE")) {
                    refQual = REF_LVALUE;
                    break;
                }
                if (consumeIf("OE")) {
                    refQual = REF_RVALUE;
                    break;
                }
                if (atEnd()) {
                    return null;
                }
                Node t = parseType();
                if (t == null) {
                    return null;
                }
                params.add(t);
            }
            return new FunctionType(ret, params, cv, refQual);
        }

        Node parseClassEnumType() {
            return parseName(null);
        }

        // ---- expressions

        Node parseExpr() {
            enter();
            try {
                return parseExprImpl();
            } finally {
                leave();
            }
        }

        private Node parseExprImpl() {
            if (peek() == 'L') {
                return parseExprPrimary();
            }
            if (peek() == 'T') {
                return parseTemplateParam();
            }
            if (peek() == 'f' && (peek(1) == 'p' || peek(1) == 'L')) {
                return parseFunctionParam();
            }
            if (peek() >= '1' && peek() <= '9') {
                return parseUnresolvedName();
            }
            if (consumeIf("sp")) {
                Node e = parseExpr();
                return e == null ? null : new ParameterPackExpansion(e);
            }
            if (consumeIf("sZ")) {
                Node e = peek() == 'T' ? parseTemplateParam() : parseFunctionParam();
                return e == null ? null : new EnclosingExpr("sizeof... ", e);
            }
            if (peek() == 's' && peek(1) == 'r') {
                return parseUnresolvedName();
            }
            if (consumeIf("gs")) {
                return parseExpr();
            }
            if (consumeIf("on")) {
                return parseUnresolvedName();
            }

            if (p + 2 > s.length()) {
                return null;
            }
            String code = s.substring(p, p + 2);

            switch (code) {
                case "cl": {
                    p += 2;
                    Node callee = parseExpr();
                    if (callee == null) {
                        return null;
                    }
                    List<Node> args = new ArrayList<>();
                    while (!consumeIf('E')) {
                        if (atEnd()) {
                            return null;
                        }
                        Node a = parseExpr();
                        if (a == null) {
                            return null;
                        }
                        args.add(a);
                    }
                    return new CallExpr(callee, args);
                }
                case "cv": {
                    p += 2;
                    Node ty = parseType();
                    if (ty == null) {
                        return null;
                    }
                    List<Node> args = new ArrayList<>();
                    if (consumeIf('_')) {
                        while (!consumeIf('E')) {
                            if (atEnd()) {
                                return null;
                            }
                            Node a = parseExpr();
                            if (a == null) {
                                return null;
                            }
                            args.add(a);
                        }
                    } else {
                        Node e = parseExpr();
                        if (e == null) {
                            return null;
                        }
                        args.add(e);
                    }
                    return new ConversionExpr(ty, args);
                }
                case "dc":
                case "sc":
                case "cc":
                case "rc": {
                    p += 2;
                    Node ty = parseType();
                    if (ty == null) {
                        return null;
                    }
                    Node e = parseExpr();
                    if (e == null) {
                        return null;
                    }
                    String kind = code.equals("dc") ? "dynamic_cast"
                            : code.equals("sc") ? "static_cast"
                            : code.equals("cc") ? "const_cast" : "reinterpret_cast";
                    return new CastExpr(kind, ty, e);
                }
                case "ix": {
                    p += 2;
                    Node a = parseExpr();
                    if (a == null) {
                        return null;
                    }
                    Node b = parseExpr();
                    return b == null ? null : new ArraySubscriptExpr(a, b);
                }
                case "qu": {
                    p += 2;
                    Node a = parseExpr();
                    Node b = a == null ? null : parseExpr();
                    Node d = b == null ? null : parseExpr();
                    return d == null ? null : new ConditionalExpr(a, b, d);
                }
                case "dt":
                case "pt": {
                    p += 2;
                    Node lhs = parseExpr();
                    if (lhs == null) {
                        return null;
                    }
                    Node rhs = parseBaseUnresolvedName();
                    return rhs == null ? null
                            : new MemberExpr(lhs, code.equals("dt") ? "." : "->", rhs);
                }
                case "st":
                case "at": {
                    p += 2;
                    Node ty = parseType();
                    return ty == null ? null
                            : new EnclosingExpr(code.equals("st") ? "sizeof " : "alignof ", ty);
                }
                case "ti": {
                    p += 2;
                    Node ty = parseType();
                    return ty == null ? null : new EnclosingExpr("typeid ", ty);
                }
                case "te": {
                    p += 2;
                    Node e = parseExpr();
                    return e == null ? null : new EnclosingExpr("typeid ", e);
                }
                case "sz":
                case "az": {
                    p += 2;
                    Node e = parseExpr();
                    return e == null ? null
                            : new EnclosingExpr(code.equals("sz") ? "sizeof " : "alignof ", e);
                }
                case "nx": {
                    p += 2;
                    Node e = parseExpr();
                    return e == null ? null : new EnclosingExpr("noexcept ", e);
                }
                case "tw": {
                    p += 2;
                    Node e = parseExpr();
                    return e == null ? null : new PrefixExpr("throw ", e, Prec.UNARY);
                }
                case "tr":
                    p += 2;
                    return new NameType("throw");
                default:
                    break;
            }

            OperatorTable.Info info = OperatorTable.exprInfo(code);
            if (info == null) {
                return null;
            }
            p += 2;
            if (info.kind == OperatorTable.PREFIX) {
                Node e = parseExpr();
                return e == null ? null : new PrefixExpr(info.symbol, e, info.prec);
            }
            if (info.kind == OperatorTable.BINARY) {
                Node a = parseExpr();
                if (a == null) {
                    return null;
                }
                Node b = parseExpr();
                return b == null ? null : new BinaryExpr(a, info.symbol, b, info.prec);
            }
            return null;
        }

        private Node parseFunctionParam() {
            if (consumeIf("fp")) {
                parseCVQualifiers();
                if (consumeIf('_')) {
                    return new NameType("fp");
                }
                String n = parseNumber(false);
                if (n == null || !consumeIf('_')) {
                    return null;
                }
                return new NameType("fp" + n);
            }
            if (consumeIf("fL")) {
                if (parseNumber(false) == null || !consumeIf('p')) {
                    return null;
                }
                parseCVQualifiers();
                if (consumeIf('_')) {
                    return new NameType("fp");
                }
                String n = parseNumber(false);
                if (n == null || !consumeIf('_')) {
                    return null;
                }
                return new NameType("fp" + n);
            }
            return null;
        }

        /** <simple-id> ::= <source-name> [<template-args>] */
        private Node parseSimpleId() {
            Node n = parseSourceName();
            if (n == null) {
                return null;
            }
            if (peek() == 'I') {
                Node ta = parseTemplateArgs(false);
                return ta == null ? null : new NameWithTemplateArgs(n, ta);
            }
            return n;
        }

        /** <base-unresolved-name> ::= <simple-id> | on <operator-name> | dn <destructor-name> */
        private Node parseBaseUnresolvedName() {
            if (consumeIf("on")) {
                if (p + 2 > s.length()) {
                    return null;
                }
                String sym = OperatorTable.nameFor(s.substring(p, p + 2));
                if (sym == null) {
                    return null;
                }
                p += 2;
                Node n = new NameType(sym);
                if (peek() == 'I') {
                    Node ta = parseTemplateArgs(false);
                    return ta == null ? null : new NameWithTemplateArgs(n, ta);
                }
                return n;
            }
            if (consumeIf("dn")) {
                Node n = parseSimpleId();
                return n == null ? null : new PrefixExpr("~", n, Prec.PRIMARY);
            }
            return parseSimpleId();
        }

        /** <unresolved-type> ::= <template-param> | <decltype> | <substitution> */
        private Node parseUnresolvedType() {
            if (peek() == 'T') {
                Node n = parseTemplateParam();
                if (n == null) {
                    return null;
                }
                if (peek() == 'I') {
                    Node ta = parseTemplateArgs(false);
                    if (ta == null) {
                        return null;
                    }
                    n = new NameWithTemplateArgs(n, ta);
                }
                subs.add(n);
                return n;
            }
            if (peek() == 'D' && (peek(1) == 't' || peek(1) == 'T')) {
                Node n = parseDecltype();
                if (n != null) {
                    subs.add(n);
                }
                return n;
            }
            if (peek() == 'S' && peek(1) != 't') {
                return parseSubstitution();
            }
            return null;
        }

        /** The full <unresolved-name> production. */
        private Node parseUnresolvedName() {
            consumeIf("gs");
            if (!consumeIf("sr")) {
                return parseBaseUnresolvedName();
            }
            if (consumeIf('N')) {
                Node soFar = parseUnresolvedType();
                if (soFar == null) {
                    return null;
                }
                while (!consumeIf('E')) {
                    if (atEnd()) {
                        return null;
                    }
                    Node lvl = parseSimpleId();
                    if (lvl == null) {
                        return null;
                    }
                    soFar = new NestedName(soFar, lvl);
                }
                Node base = parseBaseUnresolvedName();
                return base == null ? null : new NestedName(soFar, base);
            }
            int mark = p;
            Node ty = parseUnresolvedType();
            if (ty != null) {
                Node base = parseBaseUnresolvedName();
                if (base != null) {
                    return new NestedName(ty, base);
                }
                p = mark;
            }
            Node soFar = null;
            while (!consumeIf('E')) {
                if (atEnd()) {
                    return null;
                }
                Node lvl = parseSimpleId();
                if (lvl == null) {
                    return null;
                }
                soFar = soFar == null ? lvl : new NestedName(soFar, lvl);
            }
            if (soFar == null) {
                return null;
            }
            Node base = parseBaseUnresolvedName();
            return base == null ? null : new NestedName(soFar, base);
        }

        Node parseExprPrimary() {
            if (!consumeIf('L')) {
                return null;
            }
            char c = peek();
            if (c == '_' && peek(1) == 'Z') {
                p += 2;
                Node e = parseEncoding();
                return e == null || !consumeIf('E') ? null : e;
            }
            String suffix = integerSuffixFor(c);
            if (suffix != null) {
                advance();
                String v = parseNumber(true);
                return v == null || !consumeIf('E') ? null : new IntegerLiteral(suffix, v);
            }
            if (c == 'b') {
                advance();
                String v;
                if (consumeIf('0')) {
                    v = "false";
                } else if (consumeIf('1')) {
                    v = "true";
                } else {
                    return null;
                }
                return consumeIf('E') ? new NameType(v) : null;
            }
            if (c == 'f' || c == 'd' || c == 'e') {
                advance();
                int width = c == 'f' ? 8 : c == 'd' ? 16 : 20;
                if (p + width > s.length()) {
                    return null;
                }
                String hex = s.substring(p, p + width);
                for (int i = 0; i < width; i++) {
                    if (!isHex(hex.charAt(i))) {
                        return null;
                    }
                }
                p += width;
                if (!consumeIf('E')) {
                    return null;
                }
                String txt = formatFloat(c, hex);
                return txt == null ? null : new NameType(txt);
            }
            // L <type> [<value>] E -- enumerations, pointers, ...
            Node ty = parseType();
            if (ty == null) {
                return null;
            }
            if (consumeIf('E')) {
                return new TypedLiteral(ty, "");
            }
            String v = parseNumber(true);
            return v == null || !consumeIf('E') ? null : new TypedLiteral(ty, v);
        }

        private static boolean isHex(char c) {
            return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f')
                    || (c >= 'A' && c <= 'F');
        }

        private static String integerSuffixFor(char c) {
            switch (c) {
                case 'i': return "";
                case 'j': return "u";
                case 'l': return "l";
                case 'm': return "ul";
                case 'x': return "ll";
                case 'y': return "ull";
                case 'c': return "char";
                case 'a': return "signed char";
                case 'h': return "unsigned char";
                case 's': return "short";
                case 't': return "unsigned short";
                case 'w': return "wchar_t";
                case 'n': return "__int128";
                case 'o': return "unsigned __int128";
                default: return null;
            }
        }

        /** Reproduces C's "%a" / "%af" rendering that llvm-cxxfilt uses. */
        private static String formatFloat(char kind, String hex) {
            try {
                if (kind == 'f') {
                    int bits = (int) Long.parseLong(hex, 16);
                    return cHexFloat(Float.toHexString(Float.intBitsToFloat(bits))) + "f";
                }
                if (kind == 'd') {
                    long bits = Long.parseUnsignedLong(hex, 16);
                    return cHexFloat(Double.toHexString(Double.longBitsToDouble(bits)));
                }
                return null;
            } catch (RuntimeException e) {
                return null;
            }
        }

        /** Converts Java's "0x1.8p1" spelling into C's "0x1.8p+1". */
        private static String cHexFloat(String javaHex) {
            boolean neg = javaHex.startsWith("-");
            String t = neg ? javaHex.substring(1) : javaHex;
            int pi = t.indexOf('p');
            if (pi < 0) {
                return javaHex;
            }
            String mant = t.substring(0, pi);
            String exp = t.substring(pi + 1);
            int dot = mant.indexOf('.');
            if (dot >= 0) {
                String frac = mant.substring(dot + 1);
                int end = frac.length();
                while (end > 0 && frac.charAt(end - 1) == '0') {
                    end--;
                }
                mant = end == 0 ? mant.substring(0, dot)
                        : mant.substring(0, dot + 1) + frac.substring(0, end);
            }
            if (!exp.startsWith("-") && !exp.startsWith("+")) {
                exp = "+" + exp;
            }
            return (neg ? "-" : "") + mant + "p" + exp;
        }
    }

    // -------------------------------------------------------- operator table

    /** The {@code <operator-name>} codes, with the data needed in both contexts. */
    static final class OperatorTable {
        static final int BINARY = 1;
        static final int PREFIX = 2;
        static final int OTHER = 3;

        static final class Info {
            final String symbol;
            final int kind;
            final int prec;

            Info(String sym, int k, int pr) {
                this.symbol = sym;
                this.kind = k;
                this.prec = pr;
            }
        }

        // {code, operator-function spelling or null, expression symbol, kind, precedence}
        private static final String[][] TABLE = {
            {"aN", "operator&=", "&=", "B", "ASSIGN"},
            {"aS", "operator=", "=", "B", "ASSIGN"},
            {"aa", "operator&&", "&&", "B", "AND_IF"},
            {"ad", "operator&", "&", "P", "UNARY"},
            {"an", "operator&", "&", "B", "AND"},
            {"at", null, "alignof ", "O", "UNARY"},
            {"aw", "operator co_await", "co_await ", "O", "UNARY"},
            {"az", null, "alignof ", "O", "UNARY"},
            {"cl", "operator()", "()", "O", "POSTFIX"},
            {"cm", "operator,", ",", "B", "COMMA"},
            {"co", "operator~", "~", "P", "UNARY"},
            {"dV", "operator/=", "/=", "B", "ASSIGN"},
            {"da", "operator delete[]", "delete[] ", "O", "UNARY"},
            {"de", "operator*", "*", "P", "UNARY"},
            {"dl", "operator delete", "delete ", "O", "UNARY"},
            {"ds", "operator.*", ".*", "B", "PTR_MEM"},
            {"dv", "operator/", "/", "B", "MULTIPLICATIVE"},
            {"eO", "operator^=", "^=", "B", "ASSIGN"},
            {"eo", "operator^", "^", "B", "XOR"},
            {"eq", "operator==", "==", "B", "EQUALITY"},
            {"ge", "operator>=", ">=", "B", "RELATIONAL"},
            {"gt", "operator>", ">", "B", "RELATIONAL"},
            {"ix", "operator[]", "[]", "O", "POSTFIX"},
            {"lS", "operator<<=", "<<=", "B", "ASSIGN"},
            {"le", "operator<=", "<=", "B", "RELATIONAL"},
            {"ls", "operator<<", "<<", "B", "SHIFT"},
            {"lt", "operator<", "<", "B", "RELATIONAL"},
            {"mI", "operator-=", "-=", "B", "ASSIGN"},
            {"mL", "operator*=", "*=", "B", "ASSIGN"},
            {"mi", "operator-", "-", "B", "ADDITIVE"},
            {"ml", "operator*", "*", "B", "MULTIPLICATIVE"},
            {"mm", "operator--", "--", "P", "UNARY"},
            {"na", "operator new[]", "new[] ", "O", "UNARY"},
            {"ne", "operator!=", "!=", "B", "EQUALITY"},
            {"ng", "operator-", "-", "P", "UNARY"},
            {"nt", "operator!", "!", "P", "UNARY"},
            {"nw", "operator new", "new ", "O", "UNARY"},
            {"oR", "operator|=", "|=", "B", "ASSIGN"},
            {"oo", "operator||", "||", "B", "OR_IF"},
            {"or", "operator|", "|", "B", "IOR"},
            {"pL", "operator+=", "+=", "B", "ASSIGN"},
            {"pl", "operator+", "+", "B", "ADDITIVE"},
            {"pm", "operator->*", "->*", "B", "PTR_MEM"},
            {"pp", "operator++", "++", "P", "UNARY"},
            {"ps", "operator+", "+", "P", "UNARY"},
            {"pt", "operator->", "->", "B", "POSTFIX"},
            {"qu", "operator?", "?", "O", "CONDITIONAL"},
            {"rM", "operator%=", "%=", "B", "ASSIGN"},
            {"rS", "operator>>=", ">>=", "B", "ASSIGN"},
            {"rm", "operator%", "%", "B", "MULTIPLICATIVE"},
            {"rs", "operator>>", ">>", "B", "SHIFT"},
            {"ss", "operator<=>", "<=>", "B", "SPACESHIP"},
            {"st", null, "sizeof ", "O", "UNARY"},
            {"sz", null, "sizeof ", "O", "UNARY"},
        };

        private OperatorTable() { }

        private static String[] row(String code) {
            int lo = 0;
            int hi = TABLE.length - 1;
            while (lo <= hi) {
                int mid = (lo + hi) >>> 1;
                int c = TABLE[mid][0].compareTo(code);
                if (c == 0) {
                    return TABLE[mid];
                }
                if (c < 0) {
                    lo = mid + 1;
                } else {
                    hi = mid - 1;
                }
            }
            return null;
        }

        private static int precOf(String n) {
            switch (n) {
                case "POSTFIX": return Prec.POSTFIX;
                case "UNARY": return Prec.UNARY;
                case "PTR_MEM": return Prec.PTR_MEM;
                case "MULTIPLICATIVE": return Prec.MULTIPLICATIVE;
                case "ADDITIVE": return Prec.ADDITIVE;
                case "SHIFT": return Prec.SHIFT;
                case "SPACESHIP": return Prec.SPACESHIP;
                case "RELATIONAL": return Prec.RELATIONAL;
                case "EQUALITY": return Prec.EQUALITY;
                case "AND": return Prec.AND;
                case "XOR": return Prec.XOR;
                case "IOR": return Prec.IOR;
                case "AND_IF": return Prec.AND_IF;
                case "OR_IF": return Prec.OR_IF;
                case "CONDITIONAL": return Prec.CONDITIONAL;
                case "ASSIGN": return Prec.ASSIGN;
                case "COMMA": return Prec.COMMA;
                default: return Prec.DEFAULT;
            }
        }

        /** The {@code operator...} spelling used when the code names a function. */
        static String nameFor(String code) {
            String[] r = row(code);
            return r == null ? null : r[1];
        }

        /** Operator description used when the code appears inside an expression. */
        static Info exprInfo(String code) {
            String[] r = row(code);
            if (r == null) {
                return null;
            }
            int kind = r[3].equals("B") ? BINARY : r[3].equals("P") ? PREFIX : OTHER;
            return new Info(r[2], kind, precOf(r[4]));
        }
    }
}
