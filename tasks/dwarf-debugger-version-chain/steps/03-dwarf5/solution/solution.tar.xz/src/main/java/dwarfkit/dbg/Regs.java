package dwarfkit.dbg;

/**
 * x86-64 register layout: the kernel's {@code user_regs_struct} on one side and
 * the RSP 'g' packet described by {@link dwarfkit.rsp.TargetXml} on the other.
 */
public final class Regs {
    private Regs() {}

    /** user_regs_struct is 27 unsigned longs. */
    public static final int URS_LONGS = 27;
    public static final int URS_BYTES = URS_LONGS * 8;

    /* Indices into user_regs_struct, in kernel declaration order. */
    public static final int R15 = 0, R14 = 1, R13 = 2, R12 = 3, RBP = 4, RBX = 5,
            R11 = 6, R10 = 7, R9 = 8, R8 = 9, RAX = 10, RCX = 11, RDX = 12,
            RSI = 13, RDI = 14, ORIG_RAX = 15, RIP = 16, CS = 17, EFLAGS = 18,
            RSP = 19, SS = 20, FS_BASE = 21, GS_BASE = 22, DS = 23, ES = 24,
            FS = 25, GS = 26;

    /** user_fpregs_struct is 512 bytes (the FXSAVE area). */
    public static final int FPREGS_BYTES = 512;

    /** Total size of the 'g' packet for the description we publish. */
    public static final int G_BYTES = 560;

    /* The 16 general registers in gdb's regnum order 0..15. */
    private static final int[] GP = {RAX, RBX, RCX, RDX, RSI, RDI, RBP, RSP,
            R8, R9, R10, R11, R12, R13, R14, R15};

    private static void put64(byte[] b, int off, long v) {
        for (int i = 0; i < 8; i++) b[off + i] = (byte) (v >>> (8 * i));
    }

    private static void put32(byte[] b, int off, long v) {
        for (int i = 0; i < 4; i++) b[off + i] = (byte) (v >>> (8 * i));
    }

    private static long get64(byte[] b, int off) {
        long v = 0;
        for (int i = 7; i >= 0; i--) v = (v << 8) | (b[off + i] & 0xffL);
        return v;
    }

    private static long get32(byte[] b, int off) {
        long v = 0;
        for (int i = 3; i >= 0; i--) v = (v << 8) | (b[off + i] & 0xffL);
        return v;
    }

    /**
     * Builds the 'g' packet payload.  Registers gdb never prints for these
     * sessions (x87 and SSE state) are filled from the FXSAVE area when it is
     * available and zeroed otherwise; the AVX high halves are not published.
     */
    public static byte[] toG(long[] u, byte[] fp) {
        byte[] g = new byte[G_BYTES];
        for (int i = 0; i < 16; i++) put64(g, i * 8, u[GP[i]]);
        put64(g, 128, u[RIP]);
        put32(g, 136, u[EFLAGS]);
        put32(g, 140, u[CS]);
        put32(g, 144, u[SS]);
        put32(g, 148, u[DS]);
        put32(g, 152, u[ES]);
        put32(g, 156, u[FS]);
        put32(g, 160, u[GS]);
        if (fp != null && fp.length >= FPREGS_BYTES) {
            /* st0..st7 live at FXSAVE offset 32, 16 bytes apart, 10 bytes wide. */
            for (int i = 0; i < 8; i++) System.arraycopy(fp, 32 + i * 16, g, 164 + i * 10, 10);
            long cwd = get16(fp, 0), swd = get16(fp, 2), ftw = get16(fp, 4), fop = get16(fp, 6);
            long fip = get64(fp, 8), fdp = get64(fp, 16);
            put32(g, 244, cwd);
            put32(g, 248, swd);
            put32(g, 252, ftw);
            put32(g, 256, fip >>> 32);          // fiseg
            put32(g, 260, fip & 0xffffffffL);   // fioff
            put32(g, 264, fdp >>> 32);          // foseg
            put32(g, 268, fdp & 0xffffffffL);   // fooff
            put32(g, 272, fop);
            System.arraycopy(fp, 160, g, 276, 256);   // xmm0..15
            put32(g, 532, get32(fp, 24));             // mxcsr
        }
        put64(g, 536, u[ORIG_RAX]);
        put64(g, 544, u[FS_BASE]);
        put64(g, 552, u[GS_BASE]);
        return g;
    }

    private static long get16(byte[] b, int off) {
        return (b[off] & 0xffL) | ((b[off + 1] & 0xffL) << 8);
    }

    /** Applies a 'g' packet back onto a user_regs_struct image. */
    public static void fromG(byte[] g, long[] u) {
        for (int i = 0; i < 16; i++) u[GP[i]] = get64(g, i * 8);
        u[RIP] = get64(g, 128);
        u[EFLAGS] = get32(g, 136);
        u[CS] = get32(g, 140);
        u[SS] = get32(g, 144);
        u[DS] = get32(g, 148);
        u[ES] = get32(g, 152);
        u[FS] = get32(g, 156);
        u[GS] = get32(g, 160);
        if (g.length >= 544) u[ORIG_RAX] = get64(g, 536);
    }

    /** Byte offset and width of gdb register number {@code n} in the 'g' packet. */
    public static int[] slot(int n) {
        if (n < 16) return new int[]{n * 8, 8};
        if (n == 16) return new int[]{128, 8};
        if (n == 17) return new int[]{136, 4};
        if (n <= 23) return new int[]{140 + (n - 18) * 4, 4};
        if (n <= 31) return new int[]{164 + (n - 24) * 10, 10};
        if (n <= 39) return new int[]{244 + (n - 32) * 4, 4};
        if (n <= 55) return new int[]{276 + (n - 40) * 16, 16};
        if (n == 56) return new int[]{532, 4};
        if (n == 57) return new int[]{536, 8};
        if (n == 58) return new int[]{544, 8};
        if (n == 59) return new int[]{552, 8};
        return null;
    }
}
