package dwarfkit.sym;

import dwarfkit.dw.Consts;
import dwarfkit.dw.Info;
import dwarfkit.dw.LineTable;
import dwarfkit.elf.Elf;
import dwarfkit.util.Buf;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import static dwarfkit.dw.Consts.*;

/** Address to function/file/line, following llvm-symbolizer's resolution rules. */
public final class Symbolizer {

    public static final class Frame {
        public String function;          // null when unknown
        public String file;              // null when unknown
        public int line, column;
        public int discriminator;
        public long startAddress = -1;
        public String startFile;
        public int startLine;
        public boolean inlined;
    }

    public static final class DataInfo {
        public String name;
        public long start, size;
        public String file;
        public int line;
    }

    private static final class FuncRange {
        long lo, hi;
        Info.Die die;
        Info.Unit unit;
    }

    public final Elf elf;
    public final Info info;
    private final List<FuncRange> funcs = new ArrayList<>();
    private final List<FuncRange> cuRanges = new ArrayList<>();
    private List<Elf.Sym> funcSyms, objSyms;
    private Info dwoInfo;
    private final String path;

    public Symbolizer(String path, Elf elf) {
        this.path = path;
        this.elf = elf;
        this.info = new Info(elf);
        index();
    }

    private void index() {
        for (Info.Unit u : info.effectiveUnits()) {
            if (u.root == null || u.isTypeUnit) continue;
            for (long[] r : u.root.ranges()) {
                FuncRange fr = new FuncRange();
                fr.lo = r[0];
                fr.hi = r[1];
                fr.unit = u;
                fr.die = u.root;
                cuRanges.add(fr);
            }
            collect(u, u.root);
        }
        Comparator<FuncRange> byLo = (x, y) -> Long.compareUnsigned(x.lo, y.lo);
        funcs.sort(byLo);
        cuRanges.sort(byLo);
    }

    private void collect(Info.Unit u, Info.Die d) {
        for (Info.Die c : d.children) {
            if (c.tag == DW_TAG_subprogram || c.tag == DW_TAG_inlined_subroutine) {
                for (long[] r : c.ranges()) {
                    if (Long.compareUnsigned(r[1], r[0]) <= 0) continue;
                    FuncRange fr = new FuncRange();
                    fr.lo = r[0];
                    fr.hi = r[1];
                    fr.die = c;
                    fr.unit = u;
                    funcs.add(fr);
                }
            }
            collect(u, c);
        }
    }

    private List<Elf.Sym> allSymbols() {
        if (funcSyms == null) {
            funcSyms = new ArrayList<>();
            for (Elf.Sym s : elf.symbols()) {
                int t = s.type();
                if (s.shndx == 0 || t == 3 /* SECTION */ || t == 4 /* FILE */ || t == 6 /* TLS */) continue;
                funcSyms.add(s);
            }
            funcSyms.sort((x, y) -> Long.compareUnsigned(x.value, y.value));
        }
        return funcSyms;
    }

    /** Greatest defined symbol at or below pc; no size containment check. */
    private Elf.Sym symbolAt(long pc) {
        List<Elf.Sym> list = allSymbols();
        int lo = 0, hi = list.size() - 1, best = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (Buf.ule(list.get(mid).value, pc)) { best = mid; lo = mid + 1; } else hi = mid - 1;
        }
        if (best < 0) return null;
        long addr = list.get(best).value;
        Elf.Sym pick = list.get(best);
        for (int i = best; i >= 0 && list.get(i).value == addr; i--) {
            Elf.Sym c = list.get(i);
            if (c.size != 0 && Buf.ult(pc - c.value, c.size)) return c;
            if (c.bind() == 1 /* GLOBAL */ && pick.bind() != 1) pick = c;
        }
        return pick;
    }

    /** Innermost-first chain of DIEs covering pc (inlined frames first). */
    private List<FuncRange> chainAt(long pc) {
        List<FuncRange> hits = new ArrayList<>();
        for (FuncRange f : funcs) {
            if (Buf.inRange(pc, f.lo, f.hi)) hits.add(f);
        }
        // innermost = deepest DIE; range size is not a reliable proxy because a
        // cold range of an outer function can be smaller than an inlined range
        hits.sort((x, y) -> {
            int d = Integer.compare(depthOf(y.die), depthOf(x.die));
            if (d != 0) return d;
            return Long.compareUnsigned(x.hi - x.lo, y.hi - y.lo);
        });
        return hits;
    }

    private static int depthOf(Info.Die d) {
        int n = 0;
        while (d != null && n < 64) { d = d.parent; n++; }
        return n;
    }

    private Info.Unit unitAt(long pc) {
        for (FuncRange c : cuRanges) if (Buf.inRange(pc, c.lo, c.hi)) return c.unit;
        for (FuncRange f : funcs) if (Buf.inRange(pc, f.lo, f.hi)) return f.unit;
        return null;
    }

    /** The name elfutils reports: the symbol whose size covers pc, preferring a
     *  global over a weak alias at the same address, then table order. */
    public String symbolNameEarliest(long pc, boolean demangle) {
        Elf.Sym s = symbolAt(pc);
        if (s == null) return null;
        Elf.Sym pick = null;
        for (Elf.Sym c : allSymbols()) {
            if (c.name == null || c.size == 0) continue;
            if (!Buf.ule(c.value, pc) || !Buf.ult(pc - c.value, c.size)) continue;
            if (pick == null
                    || Long.compareUnsigned(c.value, pick.value) > 0
                    || (c.value == pick.value && pick.bind() == 2 && c.bind() != 2)
                    || (c.value == pick.value && c.bind() == pick.bind() && c.index < pick.index)) {
                pick = c;
            }
        }
        if (pick == null) pick = s;
        for (Elf.Sym c : allSymbols()) {
            if (c.value != pick.value || c.name == null) continue;
            if (pick.bind() == 2 && c.bind() != 2) pick = c;          // global beats weak
        }
        if (pick.name == null) return null;
        if (demangle) {
            String d = dwarfkit.demangle.Itanium.demangle(pick.name);
            if (d != null) return d;
        }
        return pick.name;
    }

    /** The symbol-table name at pc, demangled when asked. */
    public String symbolName(long pc, boolean demangle) {
        Elf.Sym s = symbolAt(pc);
        if (s == null || s.name == null) return null;
        if (demangle) {
            String d = dwarfkit.demangle.Itanium.demangle(s.name);
            if (d != null) return d;
        }
        return s.name;
    }

    public static String nameOf(Info.Die d, int functionsStyle, boolean demangle) {
        if (d == null) return null;
        String n;
        if (functionsStyle == 2 /* linkage */) {
            n = d.linkageName();
            if (n == null) n = d.nameDeep();
            else if (demangle) {
                String dm = dwarfkit.demangle.Itanium.demangle(n);
                if (dm != null) n = dm;
            }
        } else {
            n = d.nameDeep();
        }
        return n;
    }

    /**
     * Resolve pc.  With inlines=false a single frame is returned: the name of the
     * containing subprogram and the innermost line-table position, which is what
     * llvm-symbolizer --no-inlines prints.
     */
    public List<Frame> code(long pc, boolean inlines, int functionsStyle, boolean demangle,
                            int pathStyle) {
        return code(pc, inlines, functionsStyle, demangle, pathStyle, true);
    }

    public List<Frame> code(long pc, boolean inlines, int functionsStyle, boolean demangle,
                            int pathStyle, boolean symtabOverride) {
        List<Frame> out = new ArrayList<>();
        Info.Unit u = unitAt(pc);
        LineTable lt = u == null ? null : u.lineTable();
        LineTable.Row row = lt == null ? null : lt.lookup(pc);
        List<FuncRange> chain = chainAt(pc);

        // the real (non-inlined) subprogram containing pc
        FuncRange sub = null;
        for (FuncRange f : chain) {
            if (f.die.tag == DW_TAG_subprogram) { sub = f; break; }
        }
        if (chain.isEmpty() || (row == null && sub == null)) {
            Frame f = new Frame();
            if (functionsStyle == 2 && symtabOverride) {
                Elf.Sym s = symbolAt(pc);
                f.function = symbolName(pc, demangle);
                if (s != null) {
                    f.startAddress = s.value;
                    if (s.file != null && !s.file.isEmpty()) { f.file = s.file; f.line = 0; f.column = 0; }
                }
            }
            out.add(f);
            return out;
        }
        if (!inlines) {
            Frame f = new Frame();
            f.function = nameOf(chain.get(0).die, functionsStyle, demangle);
            if (functionsStyle == 2) {
                String sn = symbolName(pc, demangle);
                if (sn != null) f.function = sn;
            }
            if (row != null && lt != null) {
                f.file = lt.fileName(row.file, pathStyle);
                f.line = row.line;
                f.column = row.col;
                f.discriminator = row.discriminator;
            }
            fillStart(f, chain.get(0), lt, pathStyle);
            if (sub != null) f.startAddress = sub.lo;
            if (functionsStyle == 2) {
                Elf.Sym s = symbolAt(pc);
                if (s != null) f.startAddress = s.value;
            }
            out.add(f);
            return out;
        }
        // innermost first: inlined_subroutine frames, then the subprogram
        List<FuncRange> ordered = new ArrayList<>();
        for (FuncRange f : chain) if (f.die.tag == DW_TAG_inlined_subroutine) ordered.add(f);
        if (sub != null) ordered.add(sub);
        String pendingFile = row != null && lt != null ? lt.fileName(row.file, pathStyle) : null;
        int pendingLine = row == null ? 0 : row.line;
        int pendingCol = row == null ? 0 : row.col;
        int pendingDisc = row == null ? 0 : row.discriminator;
        for (int i = 0; i < ordered.size(); i++) {
            FuncRange fr = ordered.get(i);
            Frame f = new Frame();
            f.function = nameOf(fr.die, functionsStyle, demangle);
            f.file = pendingFile;
            f.line = pendingLine;
            f.column = pendingCol;
            f.discriminator = pendingDisc;
            f.inlined = fr.die.tag == DW_TAG_inlined_subroutine;
            if (!f.inlined && functionsStyle == 2 && symtabOverride) {
                String sn = symbolName(pc, demangle);
                if (sn != null) f.function = sn;
            }
            Object lowpc = fr.die.raw(DW_AT_low_pc);
            f.startAddress = (lowpc instanceof Long)
                    ? fr.unit.resolveAddr(fr.die.formOf(DW_AT_low_pc), (Long) lowpc)
                    : -1;
            fillStart(f, i == 0 ? ordered.get(0) : fr, lt, pathStyle);
            if (!f.inlined && functionsStyle == 2) {
                Elf.Sym sy = symbolAt(pc);
                if (sy != null) f.startAddress = sy.value;
            }
            out.add(f);
            // the caller's position comes from this DIE's call site attributes
            if (fr.die.tag == DW_TAG_inlined_subroutine && lt != null) {
                long cf = fr.die.num(DW_AT_call_file, -1);
                long cl = fr.die.num(DW_AT_call_line, 0);
                long cc = fr.die.num(DW_AT_call_column, 0);
                pendingFile = cf >= 0 ? lt.fileName((int) cf, pathStyle) : pendingFile;
                pendingLine = (int) cl;
                pendingCol = (int) cc;
                pendingDisc = 0;
            }
        }
        if (out.isEmpty()) out.add(new Frame());
        return out;
    }

    private void fillStart(Frame f, FuncRange fr, LineTable lt, int pathStyle) {
        Info.Die d = fr.die;
        long df = d.numDeep(DW_AT_decl_file, -1);
        long dl = d.numDeep(DW_AT_decl_line, 0);
        if (lt != null && df >= 0) f.startFile = lt.fileName((int) df, pathStyle);
        f.startLine = (int) dl;
    }

    public static final class Var {
        public String function, name, file;
        public int line;
        public String offset = "??";     // frame offset, or ?? when not a simple fbreg
        public String size = "??";
        public String tagOffset = "??";
    }

    /**
     * The variables in scope at pc: every function-like DIE containing pc
     * contributes its own parameters and locals, outermost scope first, each
     * under its own DW_AT_name.
     */
    public List<Var> frame(long pc, int pathStyle) {
        List<Var> out = new ArrayList<>();
        // The scope is the innermost DIE that *covers* pc; everything nested
        // inside it is reported whether or not it covers pc itself.
        List<FuncRange> chain = new ArrayList<>();
        for (FuncRange f : chainAt(pc)) {
            if (!f.unit.dwo) chain.add(f);         // FRAME does not follow a .dwo
        }
        if (chain.isEmpty()) return null;          // null prints ??
        FuncRange root = chain.get(0);
        LineTable lt = root.unit.lineTable();
        collectScope(root.die, root.unit, lt, pathStyle, nameOf(root.die, 1, false), out);
        return out;
    }

    /** Every variable in this subtree, named by its nearest enclosing function. */
    private void collectScope(Info.Die d, Info.Unit u, LineTable lt, int pathStyle,
                              String fname, List<Var> out) {
        for (Info.Die c : d.children) {
            if (c.tag == DW_TAG_formal_parameter || c.tag == DW_TAG_variable) {
                Var v = new Var();
                v.function = fname;
                v.name = c.nameDeep();
                if (v.name == null) continue;
                long df = c.numDeep(DW_AT_decl_file, -1);
                v.line = (int) c.numDeep(DW_AT_decl_line, 0);
                if (lt != null && df >= 0) v.file = lt.fileName((int) df, pathStyle);
                Object loc = c.raw(DW_AT_location);
                if (loc instanceof byte[]) {
                    byte[] e = (byte[]) loc;
                    if (e.length >= 2 && (e[0] & 0xff) == 0x91) {      // DW_OP_fbreg
                        Buf b = new Buf(e);
                        b.little = elf.little;
                        b.seek(1);
                        v.offset = Long.toString(b.sleb());
                    }
                }
                if (v.offset.equals("??")) {
                    String fb = fbregFromLocationList(c, u);
                    if (fb != null) v.offset = fb;
                }
                long sz = typeSize(c, u, 0);
                if (sz >= 0) v.size = Long.toString(sz);
                out.add(v);
            } else if (c.tag == DW_TAG_lexical_block) {
                collectScope(c, u, lt, pathStyle, fname, out);
            } else if (c.tag == DW_TAG_inlined_subroutine) {
                String inner = nameOf(c, 1, false);
                collectScope(c, u, lt, pathStyle, inner == null ? fname : inner, out);
            }
        }
    }

    /** First DW_OP_fbreg offset in a variable's location list, or null. */
    private String fbregFromLocationList(Info.Die c, Info.Unit u) {
        Object loc = c.raw(DW_AT_location);
        if (!(loc instanceof Long)) return null;
        int form = c.formOf(DW_AT_location);
        byte[] sec = (u.version >= 5) ? u.info.loclistsSection() : u.info.locSection();
        if (sec == null) return null;
        long off = (Long) loc;
        if (form == Consts.DW_FORM_loclistx) {
            long b0 = u.loclistsBase >= 0 ? u.loclistsBase : 12;
            Buf ib = new Buf(sec);
            ib.little = elf.little;
            int at = (int) (b0 + off * u.offsetSize);
            if (at < 0 || at + u.offsetSize > sec.length) return null;
            ib.seek(at);
            off = b0 + ib.uint(u.offsetSize);
        }
        if (off < 0 || off >= sec.length) return null;
        Buf b = new Buf(sec);
        b.little = elf.little;
        b.seek((int) off);
        try {
            for (int guard = 0; guard < 4096 && b.remaining() > 0; guard++) {
                byte[] expr = null;
                if (u.version >= 5) {
                    int kind = b.u8();
                    if (kind == Consts.DW_LLE_end_of_list) break;
                    switch (kind) {
                        case Consts.DW_LLE_base_addressx: b.uleb(); continue;
                        case Consts.DW_LLE_base_address: b.uint(u.addrSize); continue;
                        case Consts.DW_LLE_startx_endx: b.uleb(); b.uleb(); break;
                        case Consts.DW_LLE_startx_length: b.uleb(); b.uleb(); break;
                        case Consts.DW_LLE_offset_pair: b.uleb(); b.uleb(); break;
                        case Consts.DW_LLE_start_end: b.uint(u.addrSize); b.uint(u.addrSize); break;
                        case Consts.DW_LLE_start_length: b.uint(u.addrSize); b.uleb(); break;
                        case Consts.DW_LLE_default_location: break;
                        default: return null;
                    }
                    expr = b.bytes((int) b.uleb());
                } else {
                    long lo = b.uint(u.addrSize), hi = b.uint(u.addrSize);
                    if (lo == 0 && hi == 0) break;
                    long allOnes = u.addrSize == 8 ? -1L : 0xffffffffL;
                    if (lo == allOnes) continue;
                    expr = b.bytes(b.u16());
                }
                if (expr != null && expr.length >= 2 && (expr[0] & 0xff) == 0x91) {
                    Buf eb = new Buf(expr);
                    eb.little = elf.little;
                    eb.seek(1);
                    long v = eb.sleb();
                    if (eb.remaining() == 0) return Long.toString(v);
                }
            }
        } catch (RuntimeException e) {
            return null;
        }
        return null;
    }

    /** Byte size of a DIE's DW_AT_type, following qualifiers and typedefs. */
    private long typeSize(Info.Die d, Info.Unit u, int depth) {
        if (depth > 16) return -1;
        Object t = d.rawDeep(DW_AT_type);
        if (!(t instanceof Long)) return -1;
        Info.Die ty = u.info.dieAt(u, formOfDeep(d, DW_AT_type), (Long) t);
        if (ty == null) return -1;
        return sizeOfType(ty, ty.unit, depth);
    }

    private int formOfDeep(Info.Die d, int at) {
        Info.Die x = d;
        for (int i = 0; i < 8 && x != null; i++) {
            if (x.raw(at) != null) return x.formOf(at);
            x = x.originOrSpec();
        }
        return 0;
    }

    private long sizeOfType(Info.Die ty, Info.Unit u, int depth) {
        if (depth > 16) return -1;
        switch (ty.tag) {
            case DW_TAG_pointer_type:
            case DW_TAG_reference_type:
            case DW_TAG_rvalue_reference_type:
                return ty.num(DW_AT_byte_size, u.addrSize);
            case DW_TAG_typedef:
            case DW_TAG_const_type:
            case DW_TAG_volatile_type:
            case DW_TAG_restrict_type:
            case DW_TAG_atomic_type: {
                Object t = ty.raw(DW_AT_type);
                if (!(t instanceof Long)) return -1;
                Info.Die n = u.info.dieAt(u, ty.formOf(DW_AT_type), (Long) t);
                return n == null ? -1 : sizeOfType(n, n.unit, depth + 1);
            }
            case DW_TAG_array_type: {
                Object t = ty.raw(DW_AT_type);
                long elem = -1;
                if (t instanceof Long) {
                    Info.Die n = u.info.dieAt(u, ty.formOf(DW_AT_type), (Long) t);
                    if (n != null) elem = sizeOfType(n, n.unit, depth + 1);
                }
                if (elem < 0) return ty.num(DW_AT_byte_size, -1);
                long count = 1;
                for (Info.Die c : ty.children) {
                    if (c.tag != DW_TAG_subrange_type) continue;
                    long n = c.num(DW_AT_count, -1);
                    if (n < 0) {
                        long ub = c.num(DW_AT_upper_bound, -1);
                        n = ub >= 0 ? ub + 1 : -1;
                    }
                    if (n < 0) return ty.num(DW_AT_byte_size, -1);
                    count *= n;
                }
                return elem * count;
            }
            default:
                return ty.num(DW_AT_byte_size, -1);
        }
    }

    public DataInfo data(long pc, int pathStyle) {
        DataInfo di = new DataInfo();
        Elf.Sym s = symbolAt(pc);
        if (s != null) {
            di.name = s.name;
            di.start = s.value;
            di.size = s.size;
        }
        // decl file/line from a matching DW_TAG_variable
        for (Info.Unit u : info.units) {
            if (u.root == null) continue;
            Info.Die v = findVar(u.root, s == null ? pc : s.value, u);
            if (v != null) {
                LineTable lt = u.lineTable();
                long df = v.numDeep(DW_AT_decl_file, -1);
                long dl = v.numDeep(DW_AT_decl_line, 0);
                if (lt != null && df >= 0) di.file = lt.fileName((int) df, pathStyle);
                di.line = (int) dl;
                if (di.name == null) di.name = v.nameDeep();
                return di;
            }
        }
        if (s != null && s.file != null && !s.file.isEmpty()) {
            di.file = s.file;
            di.line = 0;
        }
        return di;
    }

    private Info.Die findVar(Info.Die d, long addr, Info.Unit u) {
        for (Info.Die c : d.children) {
            if (c.tag == DW_TAG_variable) {
                Object loc = c.raw(DW_AT_location);
                if (loc instanceof byte[]) {
                    byte[] e = (byte[]) loc;
                    if (e.length >= 1 && (e[0] & 0xff) == 0x03 && e.length >= 1 + u.addrSize) {
                        Buf b = new Buf(e);
                        b.little = elf.little;
                        b.seek(1);
                        if (b.uint(u.addrSize) == addr) return c;
                    } else if (e.length >= 2 && (e[0] & 0xff) == 0xa1) {   // DW_OP_addrx
                        Buf b = new Buf(e);
                        b.little = elf.little;
                        b.seek(1);
                        if (u.resolveAddr(Consts.DW_FORM_addrx, b.uleb()) == addr) return c;
                    }
                }
            }
            Info.Die r = findVar(c, addr, u);
            if (r != null) return r;
        }
        return null;
    }

    public String modulePath() { return path; }
}
