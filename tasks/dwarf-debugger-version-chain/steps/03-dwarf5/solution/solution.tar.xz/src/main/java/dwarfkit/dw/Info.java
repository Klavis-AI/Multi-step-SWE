package dwarfkit.dw;

import dwarfkit.elf.Elf;
import dwarfkit.util.Buf;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static dwarfkit.dw.Consts.*;

/** .debug_abbrev + .debug_info/.debug_types reader for DWARF 2, 3, 4 and 5. */
public final class Info {

    /* ------------------------------------------------------------------ DIE */
    public static final class Die {
        public int tag;
        public long offset;                 // absolute offset in the section
        public Unit unit;
        public Die parent;
        public final List<Die> children = new ArrayList<>();
        public int[] atName = new int[0];
        public int[] atForm = new int[0];
        public Object[] atVal = new Object[0];

        public Object raw(int at) {
            for (int i = 0; i < atName.length; i++) if (atName[i] == at) return atVal[i];
            return null;
        }

        public int formOf(int at) {
            for (int i = 0; i < atName.length; i++) if (atName[i] == at) return atForm[i];
            return 0;
        }

        public boolean has(int at) { return raw(at) != null; }

        public long num(int at, long dflt) {
            Object o = raw(at);
            return (o instanceof Long) ? (Long) o : dflt;
        }

        public String str(int at) {
            Object o = raw(at);
            if (o instanceof String) return (String) o;
            if (o instanceof Long) return unit.resolveString(formOf(at), (Long) o);
            return null;
        }

        /** DW_AT_name following DW_AT_specification / DW_AT_abstract_origin. */
        public String nameDeep() {
            Die d = this;
            for (int i = 0; i < 8 && d != null; i++) {
                String n = d.str(DW_AT_name);
                if (n != null) return n;
                d = d.originOrSpec();
            }
            return null;
        }

        public String linkageName() {
            Die d = this;
            for (int i = 0; i < 8 && d != null; i++) {
                String n = d.str(DW_AT_linkage_name);
                if (n == null) n = d.str(DW_AT_MIPS_linkage_name);
                if (n != null) return n;
                d = d.originOrSpec();
            }
            return null;
        }

        public Die originOrSpec() {
            Object o = raw(DW_AT_abstract_origin);
            int form = DW_AT_abstract_origin;
            if (o == null) { o = raw(DW_AT_specification); form = DW_AT_specification; }
            if (!(o instanceof Long)) return null;
            return unit.info.dieAt(unit, formOf(form), (Long) o);
        }

        /** Attribute lookup that follows abstract_origin/specification. */
        public Object rawDeep(int at) {
            Die d = this;
            for (int i = 0; i < 8 && d != null; i++) {
                Object o = d.raw(at);
                if (o != null) return o;
                d = d.originOrSpec();
            }
            return null;
        }

        public long numDeep(int at, long dflt) {
            Die d = this;
            for (int i = 0; i < 8 && d != null; i++) {
                Object o = d.raw(at);
                if (o instanceof Long) return (Long) o;
                d = d.originOrSpec();
            }
            return dflt;
        }

        /** [lo,hi) ranges of this DIE: low_pc/high_pc or DW_AT_ranges. */
        public List<long[]> ranges() {
            Object r = raw(DW_AT_ranges);
            if (r instanceof Long) {
                return unit.info.rangeList(unit, formOf(DW_AT_ranges), (Long) r);
            }
            Object lo = raw(DW_AT_low_pc);
            if (!(lo instanceof Long)) return List.of();
            long low = unit.resolveAddr(formOf(DW_AT_low_pc), (Long) lo);
            Object hi = raw(DW_AT_high_pc);
            if (!(hi instanceof Long)) return List.of(new long[]{low, low + 1});
            int hf = formOf(DW_AT_high_pc);
            long high;
            if (hf == DW_FORM_addr) {
                high = (Long) hi;                       // DWARF 2/3: an address
            } else if (hf == DW_FORM_addrx || (hf >= DW_FORM_addrx1 && hf <= DW_FORM_addrx4)) {
                high = unit.resolveAddr(hf, (Long) hi);
            } else {
                high = low + (Long) hi;                 // DWARF 4+: an offset from low_pc
            }
            return List.of(new long[]{low, high});
        }
    }

    /* ----------------------------------------------------------------- Unit */
    public static final class Unit {
        public Info info;
        public Elf elf;
        public long offset;                 // offset of the unit header in its section
        public long length;                 // total size including the length field
        public int version, addrSize, offsetSize = 4, unitType = DW_UT_compile;
        public long abbrevOff, typeSignature, typeOffset;
        public boolean isTypeUnit, dwo;
        public String sectionName = ".debug_info";
        public Die root;
        public String name, compDir, dwoName;
        public long strOffBase = -1, addrBase = -1, rnglistsBase = -1, loclistsBase = -1;
        public LineTable lines;
        public Unit skeleton;                // set on a .dwo unit
        private boolean linesLoaded;
        public Info dwoInfo;                 // split DWARF companion, if any

        public LineTable lineTable() {
            if (lines != null) return lines;
            if (!linesLoaded) {
                linesLoaded = true;
                Object o = root == null ? null : root.raw(DW_AT_stmt_list);
                if (o instanceof Long) lines = info.lineTableAt(this, (Long) o);
            }
            return lines;
        }

        public String resolveString(int form, long v) {
            return info.resolveString(this, form, v);
        }

        public long resolveAddr(int form, long v) {
            return info.resolveAddr(this, form, v);
        }
    }

    /* ------------------------------------------------------------ abbrevs */
    private static final class Abbrev {
        int tag;
        boolean children;
        int[] at, form;
        long[] implicitConst;
    }

    public final Elf elf;
    public final boolean dwo;
    public final List<Unit> units = new ArrayList<>();
    private final Map<Long, Die> byOffset = new HashMap<>();
    private final Map<Long, Unit> typeUnits = new HashMap<>();
    private byte[] str, lineStr, strOffsets, addrSec, rnglists, ranges, loclists, loc;
    Info addrSource;                          // where .debug_addr lives for a .dwo

    public Info(Elf elf) { this(elf, false); }

    public Info(Elf elf, boolean dwo) {
        this.elf = elf;
        this.dwo = dwo;
        String sfx = dwo ? ".dwo" : "";
        str = elf.sectionData(".debug_str" + sfx);
        lineStr = elf.sectionData(".debug_line_str");
        strOffsets = elf.sectionData(".debug_str_offsets" + sfx);
        addrSec = elf.sectionData(".debug_addr");
        rnglists = elf.sectionData(".debug_rnglists" + sfx);
        ranges = elf.sectionData(".debug_ranges");
        loclists = elf.sectionData(".debug_loclists" + sfx);
        loc = elf.sectionData(".debug_loc");
        parseSection(".debug_info" + sfx);
        if (!dwo) parseSection(".debug_types");
    }

    private void parseSection(String secName) {
        byte[] d = elf.sectionData(secName);
        if (d == null || d.length == 0) return;
        Buf b = new Buf(d);
        b.little = elf.little;
        while (b.remaining() > 11) {
            int start = b.pos();
            Unit u = new Unit();
            u.info = this;
            u.elf = elf;
            u.sectionName = secName;
            u.dwo = dwo;
            u.offset = start;
            long len = b.u32();
            if (len == 0xffffffffL) { u.offsetSize = 8; len = b.u64(); }
            long end = b.pos() + len;
            u.length = end - start;
            u.version = b.u16();
            if (u.version >= 5) {
                u.unitType = b.u8();
                u.addrSize = b.u8();
                u.abbrevOff = b.uint(u.offsetSize);
                if (u.unitType == DW_UT_type || u.unitType == DW_UT_split_type) {
                    u.typeSignature = b.u64();
                    u.typeOffset = b.uint(u.offsetSize);
                    u.isTypeUnit = true;
                } else if (u.unitType == DW_UT_skeleton || u.unitType == DW_UT_split_compile) {
                    u.typeSignature = b.u64();      // DWO id
                }
            } else {
                u.abbrevOff = b.uint(u.offsetSize);
                u.addrSize = b.u8();
                if (secName.equals(".debug_types")) {
                    u.typeSignature = b.u64();
                    u.typeOffset = b.uint(u.offsetSize);
                    u.isTypeUnit = true;
                    u.unitType = DW_UT_type;
                }
            }
            if (u.addrSize <= 0 || u.addrSize > 8 || end > b.limit - b.base) break;
            Map<Long, Abbrev> ab = abbrevs(u.abbrevOff);
            try {
                u.root = readDie(b, u, ab, (int) end, null);
            } catch (RuntimeException e) {
                u.root = null;
            }
            if (u.root != null) {
                u.name = u.root.str(DW_AT_name);
                u.compDir = u.root.str(DW_AT_comp_dir);
                u.dwoName = u.root.str(DW_AT_dwo_name);
                if (u.dwoName == null) u.dwoName = u.root.str(DW_AT_GNU_dwo_name);
            }
            units.add(u);
            if (u.isTypeUnit) typeUnits.putIfAbsent(u.typeSignature, u);
            b.seek((int) end);
        }
    }

    /** Unit-level bases must be read before other attributes resolve. */
    private void readBases(Unit u, Die root) {
        u.strOffBase = root.num(DW_AT_str_offsets_base, -1);
        u.addrBase = root.num(DW_AT_addr_base, root.num(DW_AT_GNU_addr_base, -1));
        u.rnglistsBase = root.num(DW_AT_rnglists_base, root.num(DW_AT_GNU_ranges_base, -1));
        u.loclistsBase = root.num(DW_AT_loclists_base, -1);
    }

    private Die readDie(Buf b, Unit u, Map<Long, Abbrev> ab, int end, Die parent) {
        if (b.pos() >= end) return null;
        long off = b.pos();
        long code = b.uleb();
        if (code == 0) return null;
        Abbrev a = ab.get(code);
        if (a == null) throw new IllegalStateException("bad abbrev " + code);
        Die die = new Die();
        die.offset = off;
        die.unit = u;
        die.parent = parent;
        die.tag = a.tag;
        int n = a.at.length;
        die.atName = a.at;
        die.atForm = a.form;
        die.atVal = new Object[n];
        for (int i = 0; i < n; i++) {
            die.atVal[i] = readForm(b, u, a.form[i], a.implicitConst[i]);
        }
        byOffset.put(key(u, die.offset), die);
        if (parent == null) readBases(u, die);
        if (a.children) {
            while (true) {
                Die c = readDie(b, u, ab, end, die);
                if (c == null) break;
                die.children.add(c);
            }
        }
        return die;
    }

    private long key(Unit u, long off) {
        return (u.sectionName.equals(".debug_types") ? 0x4000000000000000L : 0) + off;
    }

    private Object readForm(Buf b, Unit u, int form, long implicitConst) {
        switch (form) {
            case DW_FORM_addr: return b.uint(u.addrSize);
            case DW_FORM_block2: { int n = b.u16(); return b.bytes(n); }
            case DW_FORM_block4: { int n = (int) b.u32(); return b.bytes(n); }
            case DW_FORM_data2: return b.u16() & 0xffffL;
            case DW_FORM_data4: return b.u32();
            case DW_FORM_data8: return b.u64();
            case DW_FORM_data16: return b.bytes(16);
            case DW_FORM_string: return b.cstr();
            case DW_FORM_block:
            case DW_FORM_exprloc: { int n = (int) b.uleb(); return b.bytes(n); }
            case DW_FORM_block1: { int n = b.u8(); return b.bytes(n); }
            case DW_FORM_data1: return (long) b.u8();
            case DW_FORM_flag: return (long) b.u8();
            case DW_FORM_sdata: return b.sleb();
            case DW_FORM_strp:
            case DW_FORM_line_strp:
            case DW_FORM_sec_offset:
            case DW_FORM_strp_sup: return b.uint(u.offsetSize);
            case DW_FORM_udata: return b.uleb();
            case DW_FORM_ref_addr: return b.uint(u.offsetSize);
            case DW_FORM_ref1: return u.offset + b.u8();
            case DW_FORM_ref2: return u.offset + b.u16();
            case DW_FORM_ref4: return u.offset + b.u32();
            case DW_FORM_ref8: return u.offset + b.u64();
            case DW_FORM_ref_udata: return u.offset + b.uleb();
            case DW_FORM_ref_sup4: return b.u32();
            case DW_FORM_ref_sup8: return b.u64();
            case DW_FORM_indirect: return readForm(b, u, (int) b.uleb(), 0);
            case DW_FORM_flag_present: return 1L;
            case DW_FORM_implicit_const: return implicitConst;
            case DW_FORM_strx: case DW_FORM_addrx:
            case DW_FORM_loclistx: case DW_FORM_rnglistx: return b.uleb();
            case DW_FORM_strx1: case DW_FORM_addrx1: return (long) b.u8();
            case DW_FORM_strx2: case DW_FORM_addrx2: return b.u16() & 0xffffL;
            case DW_FORM_strx3: case DW_FORM_addrx3: {
                long v = b.u8() | ((long) b.u8() << 8) | ((long) b.u8() << 16);
                return v;
            }
            case DW_FORM_strx4: case DW_FORM_addrx4: return b.u32();
            case DW_FORM_ref_sig8: return b.u64();
            default: throw new IllegalStateException("unknown form 0x" + Integer.toHexString(form));
        }
    }

    private final Map<Long, Map<Long, Abbrev>> abbrevCache = new HashMap<>();

    private Map<Long, Abbrev> abbrevs(long off) {
        Map<Long, Abbrev> m = abbrevCache.get(off);
        if (m != null) return m;
        m = new HashMap<>();
        byte[] d = elf.sectionData(".debug_abbrev" + (dwo ? ".dwo" : ""));
        if (d != null && off < d.length) {
            Buf b = new Buf(d);
            b.little = elf.little;
            b.seek((int) off);
            while (b.remaining() > 0) {
                long code = b.uleb();
                if (code == 0) break;
                Abbrev a = new Abbrev();
                a.tag = (int) b.uleb();
                a.children = b.u8() != 0;
                List<int[]> pairs = new ArrayList<>();
                List<Long> ics = new ArrayList<>();
                while (true) {
                    int at = (int) b.uleb();
                    int form = (int) b.uleb();
                    long ic = (form == DW_FORM_implicit_const) ? b.sleb() : 0;
                    if (at == 0 && form == 0) break;
                    pairs.add(new int[]{at, form});
                    ics.add(ic);
                }
                a.at = new int[pairs.size()];
                a.form = new int[pairs.size()];
                a.implicitConst = new long[pairs.size()];
                for (int i = 0; i < pairs.size(); i++) {
                    a.at[i] = pairs.get(i)[0];
                    a.form[i] = pairs.get(i)[1];
                    a.implicitConst[i] = ics.get(i);
                }
                m.put(code, a);
            }
        }
        abbrevCache.put(off, m);
        return m;
    }

    /* --------------------------------------------------------- resolution */
    public String resolveString(Unit u, int form, long v) {
        switch (form) {
            case DW_FORM_strp: return Buf.cstrAt(str, (int) v);
            case DW_FORM_line_strp: return Buf.cstrAt(lineStr, (int) v);
            case DW_FORM_strx: case DW_FORM_strx1: case DW_FORM_strx2:
            case DW_FORM_strx3: case DW_FORM_strx4: {
                if (strOffsets == null) return null;
                long base = u.strOffBase >= 0 ? u.strOffBase : (u.version >= 5 ? 8 : 0);
                int at = (int) (base + v * u.offsetSize);
                if (at < 0 || at + u.offsetSize > strOffsets.length) return null;
                Buf b = new Buf(strOffsets);
                b.little = elf.little;
                b.seek(at);
                return Buf.cstrAt(str, (int) b.uint(u.offsetSize));
            }
            default: return null;
        }
    }

    public long resolveAddr(Unit u, int form, long v) {
        switch (form) {
            case DW_FORM_addrx: case DW_FORM_addrx1: case DW_FORM_addrx2:
            case DW_FORM_addrx3: case DW_FORM_addrx4: {
                if (addrSec == null && addrSource != null) return addrSource.resolveAddr(u, form, v);
                if (addrSec == null) return 0;
                long base = u.addrBase >= 0 ? u.addrBase : 8;
                int at = (int) (base + v * u.addrSize);
                if (at < 0 || at + u.addrSize > addrSec.length) return 0;
                Buf b = new Buf(addrSec);
                b.little = elf.little;
                b.seek(at);
                return b.uint(u.addrSize);
            }
            default: return v;
        }
    }

    public Die dieAt(Unit u, int form, long v) {
        if (form == DW_FORM_ref_sig8) {
            Unit tu = typeUnits.get(v);
            if (tu == null) return null;
            return byOffset.get(key(tu, tu.offset + tu.typeOffset));
        }
        Die d = byOffset.get(key(u, v));
        if (d == null) d = byOffset.get(v);
        return d;
    }

    public LineTable lineTableAt(Unit u, long off) {
        byte[] d = elf.sectionData(".debug_line" + (dwo ? ".dwo" : ""));
        if (d == null || off >= d.length) return null;
        try {
            return LineTable.parse(elf, d, (int) off, u, lineStr, str, this);
        } catch (RuntimeException e) {
            return null;
        }
    }

    /** [lo,hi) list for DW_AT_ranges, for both .debug_ranges and .debug_rnglists. */
    public List<long[]> rangeList(Unit u, int form, long v) {
        List<long[]> out = new ArrayList<>();
        long base = 0;
        Unit baseUnit = (u.skeleton != null) ? u.skeleton : u;
        Object lo = baseUnit.root == null ? null : baseUnit.root.raw(DW_AT_low_pc);
        if (lo instanceof Long) {
            base = baseUnit.resolveAddr(baseUnit.root.formOf(DW_AT_low_pc), (Long) lo);
        }
        if (u.version >= 5) {
            if (rnglists == null) return out;
            long off;
            if (form == DW_FORM_rnglistx) {
                long b0 = u.rnglistsBase >= 0 ? u.rnglistsBase : 12;
                Buf ib = new Buf(rnglists);
                ib.little = elf.little;
                int at = (int) (b0 + v * u.offsetSize);
                if (at < 0 || at + u.offsetSize > rnglists.length) return out;
                ib.seek(at);
                off = b0 + ib.uint(u.offsetSize);
            } else {
                off = v;
            }
            if (off < 0 || off >= rnglists.length) return out;
            Buf b = new Buf(rnglists);
            b.little = elf.little;
            b.seek((int) off);
            while (b.remaining() > 0) {
                int kind = b.u8();
                if (kind == DW_RLE_end_of_list) break;
                switch (kind) {
                    case DW_RLE_base_addressx:
                        base = resolveAddr(u, DW_FORM_addrx, b.uleb());
                        break;
                    case DW_RLE_startx_endx: {
                        long s = resolveAddr(u, DW_FORM_addrx, b.uleb());
                        long e = resolveAddr(u, DW_FORM_addrx, b.uleb());
                        out.add(new long[]{s, e});
                        break;
                    }
                    case DW_RLE_startx_length: {
                        long s = resolveAddr(u, DW_FORM_addrx, b.uleb());
                        out.add(new long[]{s, s + b.uleb()});
                        break;
                    }
                    case DW_RLE_offset_pair: {
                        long s = b.uleb(), e = b.uleb();
                        out.add(new long[]{base + s, base + e});
                        break;
                    }
                    case DW_RLE_base_address:
                        base = b.uint(u.addrSize);
                        break;
                    case DW_RLE_start_end: {
                        long s = b.uint(u.addrSize), e = b.uint(u.addrSize);
                        out.add(new long[]{s, e});
                        break;
                    }
                    case DW_RLE_start_length: {
                        long s = b.uint(u.addrSize);
                        out.add(new long[]{s, s + b.uleb()});
                        break;
                    }
                    default: return out;
                }
            }
            return out;
        }
        if (ranges == null || v >= ranges.length) return out;
        Buf b = new Buf(ranges);
        b.little = elf.little;
        b.seek((int) v);
        long allOnes = u.addrSize == 8 ? -1L : 0xffffffffL;
        while (b.remaining() >= u.addrSize * 2) {
            long s = b.uint(u.addrSize), e = b.uint(u.addrSize);
            if (s == 0 && e == 0) break;
            if (s == allOnes) { base = e; continue; }
            out.add(new long[]{base + s, base + e});
        }
        return out;
    }

    /** Units to symbolize with: a skeleton unit is replaced by its .dwo units. */
    public List<Unit> effectiveUnits() {
        List<Unit> out = new ArrayList<>();
        for (Unit u : units) {
            List<Unit> dw = dwoUnits(u);
            if (dw != null) out.addAll(dw);
            else out.add(u);
        }
        return out;
    }

    private final Map<Unit, List<Unit>> dwoCache = new HashMap<>();

    private List<Unit> dwoUnits(Unit u) {
        if (dwoCache.containsKey(u)) return dwoCache.get(u);
        List<Unit> result = null;
        if (u.dwoName != null && !dwo) {
            java.io.File f = new java.io.File(u.dwoName);
            if (!f.isAbsolute() && u.compDir != null) f = new java.io.File(u.compDir, u.dwoName);
            if (!f.exists() && elf.path != null) {
                java.io.File dir = new java.io.File(elf.path).getAbsoluteFile().getParentFile();
                f = new java.io.File(dir, new java.io.File(u.dwoName).getName());
            }
            if (f.exists()) {
                try {
                    Info di = new Info(Elf.open(f.getPath()), true);
                    di.addrSource = this;
                    result = new ArrayList<>();
                    for (Unit du : di.units) {
                        du.addrBase = u.addrBase >= 0 ? u.addrBase : 8;
                        du.rnglistsBase = u.rnglistsBase;
                        du.compDir = u.compDir != null ? u.compDir : du.compDir;
                        du.skeleton = u;
                        du.lines = u.lineTable();
                        result.add(du);
                    }
                } catch (Exception e) {
                    result = null;
                }
            }
        }
        dwoCache.put(u, result);
        return result;
    }

    public byte[] locSection() { return loc; }
    public byte[] loclistsSection() { return loclists; }
}
