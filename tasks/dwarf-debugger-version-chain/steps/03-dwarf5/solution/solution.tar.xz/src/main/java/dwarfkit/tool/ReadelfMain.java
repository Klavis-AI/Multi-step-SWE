package dwarfkit.tool;

import dwarfkit.dw.Cfi;
import dwarfkit.elf.Elf;

import java.io.BufferedOutputStream;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * A {@code readelf} work-alike front end.
 *
 * <p>Implements {@code --debug-dump=frames-interp} (the interpreted unwind
 * table), {@code --debug-dump=frames} (the raw DW_CFA instruction dump) and
 * {@code --debug-dump=loc} (the {@code .debug_loc} location-list dump), each
 * byte-for-byte identical to GNU binutils 2.44.  New {@code --debug-dump=}
 * keywords plug in by registering another {@link Dumper} in {@link #DUMPERS};
 * nothing else has to change.
 */
public final class ReadelfMain {

    /** Handler for one {@code --debug-dump=} keyword. */
    public interface Dumper {
        void dump(Elf elf, PrintStream out) throws Exception;
    }

    /** Keyword -> handler.  Add new dump kinds here. */
    private static final Map<String, Dumper> DUMPERS = new LinkedHashMap<>();

    /** Single-letter aliases readelf accepts after {@code -w}. */
    private static final Map<String, String> LETTERS = new LinkedHashMap<>();

    static {
        DUMPERS.put("frames-interp", ReadelfMain::dumpFramesInterp);
        DUMPERS.put("frames", ReadelfMain::dumpFramesRaw);
        DUMPERS.put("loc", ReadelfMain::dumpLoc);
        DUMPERS.put("gdb_index", ReadelfMain::dumpGdbIndex);
        LETTERS.put("F", "frames-interp");
        LETTERS.put("f", "frames");
        LETTERS.put("o", "loc");
        LETTERS.put("k", "gdb_index");
    }

    public static void main(String[] args) {
        PrintStream out = new PrintStream(
                new BufferedOutputStream(new FileOutputStream(FileDescriptor.out), 1 << 16),
                false);
        int rc;
        try {
            rc = run(args, out, System.err);
        } catch (Throwable t) {
            out.flush();
            System.err.println("readelf: Error: " + describe(t));
            rc = 1;
        }
        out.flush();
        System.exit(rc);
    }

    /** Runs the tool; returns the process exit status.  Never throws. */
    public static int run(String[] args, PrintStream out, PrintStream err) {
        List<String> keywords = new ArrayList<>();
        List<String> files = new ArrayList<>();

        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--help") || a.equals("-H")) {
                usage(out);
                return 0;
            } else if (a.startsWith("--debug-dump=")) {
                String kw = a.substring("--debug-dump=".length());
                if (kw.isEmpty()) {
                    err.println("readelf: Error: Missing keyword for --debug-dump");
                    return 1;
                }
                keywords.add(kw);
            } else if (a.equals("--debug-dump") || a.equals("-w")) {
                if (i + 1 >= args.length) {
                    err.println("readelf: Error: Missing keyword for " + a);
                    return 1;
                }
                keywords.add(args[++i]);
            } else if (a.startsWith("-w") && a.length() > 2) {
                String letters = a.substring(2);
                String kw = LETTERS.get(letters);
                if (kw == null) {
                    err.println("readelf: Error: Unrecognized debug option '" + letters + "'");
                    return 1;
                }
                keywords.add(kw);
            } else if (a.startsWith("-") && a.length() > 1) {
                err.println("readelf: Error: Invalid option '" + a + "'");
                usage(err);
                return 1;
            } else {
                files.add(a);
            }
        }

        if (keywords.isEmpty()) {
            err.println("readelf: Error: No dump requested; use --debug-dump=<keyword>");
            usage(err);
            return 1;
        }
        for (String kw : keywords) {
            if (!DUMPERS.containsKey(kw)) {
                err.println("readelf: Error: Unrecognized debug option '" + kw + "'");
                err.println("readelf: supported keywords: " + String.join(", ", DUMPERS.keySet()));
                return 1;
            }
        }
        if (files.isEmpty()) {
            err.println("readelf: Error: No input file specified");
            usage(err);
            return 1;
        }

        int rc = 0;
        for (String f : files) {
            if (files.size() > 1) out.print("\nFile: " + f + "\n");
            Elf elf;
            try {
                elf = Elf.open(f);
            } catch (Throwable t) {
                out.flush();
                err.println("readelf: Error: " + f + ": " + describe(t));
                rc = 1;
                continue;
            }
            for (String kw : keywords) {
                try {
                    DUMPERS.get(kw).dump(elf, out);
                } catch (Throwable t) {
                    out.flush();
                    err.println("readelf: Error: " + f + ": " + describe(t));
                    rc = 1;
                }
            }
        }
        return rc;
    }

    private static void usage(PrintStream s) {
        s.println("Usage: ReadelfMain --debug-dump=<keyword> <elf-file>");
        s.println("  Supported keywords: " + String.join(", ", DUMPERS.keySet()));
    }

    private static String describe(Throwable t) {
        String m = t.getMessage();
        String n = t.getClass().getSimpleName();
        return (m == null || m.isEmpty()) ? n : (n + ": " + m);
    }

    /* ------------------------------------------------------------------ */
    /* --debug-dump=frames-interp                                          */
    /* ------------------------------------------------------------------ */

    /**
     * Reproduces {@code readelf --debug-dump=frames-interp}.  Sections are
     * visited in ELF section-header order, which is what readelf does; the
     * {@code .eh_frame_hdr} dump readelf also emits is deliberately omitted.
     */
    static void dumpFramesInterp(Elf elf, PrintStream out) {
        Cfi cfi = Cfi.of(elf);
        for (Cfi.FrameSection fs : cfi.sections) {
            out.print("Contents of the " + fs.name + " section:\n\n");
            for (Cfi.Entry e : fs.entries) {
                out.print("\n");
                if (e.kind == Cfi.Kind.ZERO) {
                    out.print(off8(e.offset) + " ZERO terminator\n\n");
                    continue;
                }
                out.print(entryHeader(e, false));
                boolean needHeader = true;
                for (Object item : e.items) {
                    if (item instanceof String) {
                        out.print(item);
                        out.print("\n");
                        continue;
                    }
                    Cfi.Row r = (Cfi.Row) item;
                    if (needHeader) {
                        needHeader = false;
                        out.print(headerLine(r));
                    }
                    out.print(rowLine(r));
                }
            }
            out.print("\n");
        }
    }

    /* ------------------------------------------------------------------ */
    /* --debug-dump=frames  (raw DW_CFA instruction dump)                  */
    /* ------------------------------------------------------------------ */

    /** Reproduces {@code readelf --debug-dump=frames}. */
    static void dumpFramesRaw(Elf elf, PrintStream out) {
        Cfi cfi = Cfi.of(elf);
        for (Cfi.FrameSection fs : cfi.sections) {
            out.print("Contents of the " + fs.name + " section:\n\n");
            for (Cfi.Entry e : fs.entries) {
                out.print("\n");
                if (e.kind == Cfi.Kind.ZERO) {
                    out.print(off8(e.offset) + " ZERO terminator\n\n");
                    continue;
                }
                out.print(entryHeader(e, true));
                if (e.kind == Cfi.Kind.CIE) {
                    out.print("  Version:               " + e.version + "\n");
                    out.print("  Augmentation:          \"" + e.augmentation + "\"\n");
                    if (e.version >= 4) {
                        out.print("  Pointer Size:          " + e.ptrSize + "\n");
                        out.print("  Segment Size:          " + e.segmentSize + "\n");
                    }
                    out.print("  Code alignment factor: " + Integer.toUnsignedString(e.codeFactor) + "\n");
                    out.print("  Data alignment factor: " + e.dataFactor + "\n");
                    out.print("  Return address column: " + e.ra + "\n");
                    if (e.augData != null && e.augData.length > 0)
                        out.print(augmentationData(e.augData));
                    /* binutils emits this unconditionally, so a CIE with no
                       augmentation data still gets a blank line here. */
                    out.print("\n");
                } else if (e.augData != null && e.augData.length > 0) {
                    out.print(augmentationData(e.augData));
                    out.print("\n");
                }
                for (String ln : e.rawLines) {
                    out.print(ln);
                    out.print("\n");
                }
            }
            out.print("\n");
        }
    }

    /** binutils {@code display_augmentation_data} + {@code display_data}. */
    private static String augmentationData(byte[] data) {
        StringBuilder sb = new StringBuilder("  Augmentation data:    ");
        int printed = sb.length();
        if (data.length < (80 - printed) / 3) {
            for (byte b : data) sb.append(String.format(" %02x", b & 0xff));
        } else {
            for (int i = 0; i < data.length; i++) {
                if (i % (80 / 3) == 0) sb.append('\n');
                sb.append(String.format(" %02x", data[i] & 0xff));
            }
        }
        return sb.toString();
    }

    /** The shared CIE/FDE header line (identical in raw and interp modes). */
    private static String entryHeader(Cfi.Entry e, boolean raw) {
        StringBuilder sb = new StringBuilder();
        sb.append(off8(e.offset)).append(' ');
        sb.append(Cfi.hex(e.length, e.lengthWidth));
        sb.append(Cfi.hex(e.cieId, e.offsetSize));
        if (e.kind == Cfi.Kind.CIE) {
            if (raw) sb.append("CIE\n");
            else sb.append("CIE \"").append(e.augmentation).append("\" cf=")
                   .append(Integer.toUnsignedString(e.codeFactor))
                   .append(" df=").append(e.dataFactor)
                   .append(" ra=").append(e.ra).append('\n');
        } else {
            sb.append("FDE ");
            if (e.cieOffset >= 0) sb.append("cie=").append(off8(e.cieOffset));
            else sb.append("cie=invalid ");
            sb.append(" pc=");
            if (e.segmentSize != 0) sb.append(String.format("%04x:", e.segmentSelector));
            sb.append(Cfi.hexNs(e.pcBegin, e.ptrSize)).append("..")
              .append(Cfi.hexNs(e.pcBegin + e.pcRange, e.ptrSize)).append('\n');
        }
        return sb.toString();
    }

    /* ------------------------------------------------------------------ */
    /* --debug-dump=loc                                                    */
    /* ------------------------------------------------------------------ */

    /** Reproduces {@code readelf --debug-dump=loc} for {@code .debug_loc}. */
    static void dumpLoc(Elf elf, PrintStream out) {
        Cfi cfi = Cfi.of(elf);
        for (Elf.Section s : elf.sections) {
            if (!Cfi.isLocSectionName(s.name)) continue;
            if (s.type == 8 /* SHT_NOBITS */) continue;
            byte[] d;
            try {
                d = elf.data(s);
            } catch (RuntimeException ex) {
                continue;
            }
            if (d == null) continue;
            if (d.length == 0) {
                out.print("\nThe " + s.name + " section is empty.\n");
                continue;
            }
            List<String> lines = cfi.locLines(s.name, d, s.addr);
            if (lines == null) continue;
            for (String ln : lines) {
                out.print(ln);
                out.print("\n");
            }
            out.print("\n");
        }
    }

    /* ------------------------------------------------------------------ */
    /* --debug-dump=gdb_index  (.debug_names)                              */
    /* ------------------------------------------------------------------ */

    /**
     * Reproduces {@code readelf --debug-dump=gdb_index} for {@code .debug_names}.
     * readelf routes both {@code .gdb_index} and {@code .debug_names} to this
     * keyword; only the DWARF 5 {@code .debug_names} form is implemented here.
     */
    static void dumpGdbIndex(Elf elf, PrintStream out) {
        Cfi cfi = Cfi.of(elf);
        for (Elf.Section s : elf.sections) {
            if (!Cfi.isNamesSectionName(s.name)) continue;
            if (s.type == 8 /* SHT_NOBITS */) continue;
            byte[] d;
            try {
                d = elf.data(s);
            } catch (RuntimeException ex) {
                continue;
            }
            if (d == null || d.length == 0) continue;
            List<String> lines = cfi.namesLines(s.name, d);
            if (lines == null) continue;
            for (String ln : lines) {
                out.print(ln);
                out.print("\n");
            }
        }
    }

    /* ------------------------------------------------------------------ */
    /* Shared row rendering                                                */
    /* ------------------------------------------------------------------ */

    private static String off8(int v) {
        return String.format("%08x", v & 0xffffffffL);
    }

    /** The {@code   LOC  CFA  <regs>} header, laid out exactly like binutils. */
    static String headerLine(Cfi.Row r) {
        StringBuilder sb = new StringBuilder();
        sb.append(pad("   LOC", r.addressSize() * 2)).append(" CFA      ");
        for (int i = 0; i < r.columns(); i++) {
            if (r.ruleKind(i) == Cfi.RULE_UNREFERENCED) continue;
            if (i == r.returnAddressColumn()) sb.append("ra    ");
            else sb.append(pad(r.registers().name(i, true), 5)).append(' ');
        }
        return sb.append('\n').toString();
    }

    /** One unwind-table row, laid out exactly like binutils. */
    static String rowLine(Cfi.Row r) {
        StringBuilder sb = new StringBuilder();
        sb.append(Cfi.hex(r.pc, r.addressSize()));
        sb.append(pad(r.cfaText(), 8)).append(' ');
        for (int i = 0; i < r.columns(); i++) {
            if (r.ruleKind(i) == Cfi.RULE_UNREFERENCED) continue;
            sb.append(pad(r.ruleText(i), 5)).append(' ');
        }
        return sb.append('\n').toString();
    }

    private static String pad(String s, int width) {
        if (width <= s.length()) return s;
        StringBuilder sb = new StringBuilder(width);
        sb.append(s);
        while (sb.length() < width) sb.append(' ');
        return sb.toString();
    }
}
