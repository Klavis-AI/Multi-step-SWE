package dwarfkit.core;

import dwarfkit.elf.Elf;
import dwarfkit.util.Buf;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * An ELF core file: the PT_LOAD image and one register set per NT_PRSTATUS
 * note, keyed by DWARF register number.
 */
public final class CoreFile {
    public static final int NT_PRSTATUS = 1, NT_PRPSINFO = 3, NT_FILE = 0x46494c45;

    /** Offsets inside struct elf_prstatus (same on x86-64 and aarch64). */
    private static final int PR_PID_OFF = 32, PR_REG_OFF = 112;

    /* user_regs_struct order -> DWARF register number, x86-64 psABI table 3.36 */
    private static final int[] X86_64_MAP = {
        15, 14, 13, 12, 6, 3, 11, 10, 9, 8, 0, 2, 1, 4, 5, -1, 16, -1, 49, 7, -1,
        58, 59, -1, -1, 54, 55
    };

    public static final class Thread {
        public int tid;
        public final Map<Integer, Long> regs = new LinkedHashMap<>();
        public long pc, sp;
    }

    public final Elf core;
    public final List<Thread> threads = new ArrayList<>();
    public int pid;

    public CoreFile(Elf core) {
        this.core = core;
        for (Elf.Note n : core.notes()) {
            if (n.type != NT_PRSTATUS) continue;
            Thread t = parsePrstatus(n.desc);
            if (t != null) {
                threads.add(t);
                if (pid == 0) pid = t.tid;
            }
        }
    }

    private Thread parsePrstatus(byte[] d) {
        if (d.length < PR_REG_OFF + 8) return null;
        Buf b = new Buf(d);
        b.little = core.little;
        b.seek(PR_PID_OFF);
        Thread t = new Thread();
        t.tid = (int) b.u32();
        b.seek(PR_REG_OFF);
        if (core.machine == Elf.EM_AARCH64) {
            for (int i = 0; i < 31 && b.remaining() >= 8; i++) t.regs.put(i, b.u64());
            if (b.remaining() >= 8) { t.sp = b.u64(); t.regs.put(31, t.sp); }
            if (b.remaining() >= 8) t.pc = b.u64();
        } else {
            long[] raw = new long[X86_64_MAP.length];
            for (int i = 0; i < raw.length && b.remaining() >= 8; i++) raw[i] = b.u64();
            for (int i = 0; i < X86_64_MAP.length; i++) {
                if (X86_64_MAP[i] >= 0) t.regs.put(X86_64_MAP[i], raw[i]);
            }
            t.pc = t.regs.getOrDefault(16, 0L);
            t.sp = t.regs.getOrDefault(7, 0L);
        }
        return t;
    }

    /** Reads len bytes of the process image at addr, or null if not mapped. */
    public byte[] read(long addr, int len) {
        for (Elf.Phdr p : core.phdrs) {
            if (p.type != Elf.PT_LOAD || p.filesz == 0) continue;
            if (Buf.ule(p.vaddr, addr) && Buf.ult(addr, p.vaddr + p.filesz)) {
                long off = p.offset + (addr - p.vaddr);
                long avail = p.filesz - (addr - p.vaddr);
                if (Long.compareUnsigned(avail, len) < 0) return null;
                if (off + len > core.image.length) return null;
                byte[] out = new byte[len];
                System.arraycopy(core.image, (int) off, out, 0, len);
                return out;
            }
        }
        return null;
    }

    public Long readWord(long addr, int size) {
        byte[] d = read(addr, size);
        if (d == null) return null;
        Buf b = new Buf(d);
        b.little = core.little;
        return b.uint(size);
    }
}
