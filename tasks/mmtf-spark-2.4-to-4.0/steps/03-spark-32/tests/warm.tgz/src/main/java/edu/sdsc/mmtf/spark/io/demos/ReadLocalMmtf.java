package edu.sdsc.mmtf.spark.io.demos;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.SparkSession;
import org.rcsb.mmtf.api.StructureDataInterface;

import edu.sdsc.mmtf.spark.io.MmtfReader;

/**
 * Example reading a list of PDB IDs from a local 
 * MMTF file into a JavaPairRDD.
 * 
 * @author Peter Rose
 * @since 0.1.0
 *
 */
public class ReadLocalMmtf {

	public static void main(String[] args) {  
		
		if (args.length != 1) {
			System.err.println("Usage: " + ReadLocalMmtf.class.getSimpleName() + " <inputFilePath>");
			System.exit(1);
		}
	    
	    // instantiate Spark. Each Spark application needs these two lines of code.
	    SparkConf conf = new SparkConf().setMaster("local[*]").setAppName(ReadLocalMmtf.class.getSimpleName());
	    JavaSparkContext sc = new JavaSparkContext(conf);
		 
	    // read a local MMTF file
	    JavaPairRDD<String, StructureDataInterface> pdb = MmtfReader.readMmtfFiles(args[0], sc);
	    
	    // print structural details
	    pdb.foreach(t -> TraverseStructureHierarchy.printStructureData(t._2));
	    // take the count through the SQL engine: counting a typed
	    // Dataset of the structure ids runs the read, the filters and
	    // the mappers inside one SQL execution
	    SparkSession spark = SparkSession.builder().getOrCreate();
	    Dataset<String> ids = spark.createDataset(pdb.keys().rdd(), Encoders.STRING());
	    System.out.println("# structures: " + ids.count());
	    
	    // close Spark
	    sc.close();
	}
}
