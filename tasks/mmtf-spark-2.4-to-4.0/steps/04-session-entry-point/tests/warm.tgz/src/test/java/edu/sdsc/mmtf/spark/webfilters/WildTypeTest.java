package edu.sdsc.mmtf.spark.webfilters;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.rcsb.mmtf.api.StructureDataInterface;

import edu.sdsc.mmtf.spark.io.MmtfReader;
import edu.sdsc.mmtf.spark.webfilters.WildType;

public class WildTypeTest {
	private static JavaSparkContext sc;
	private static JavaPairRDD<String, StructureDataInterface> pdb;
	
	@Before
	public void setUp() throws Exception {
		SparkConf conf = new SparkConf().setMaster("local[*]").setAppName(WildTypeTest.class.getSimpleName());
	    sc = new JavaSparkContext(conf);
	    
		// 1PEN wildtype query 100 matches: 1PEN:1
		// 1OCZ two entities wildtype query 100 matches: 1OCZ:1, 1OCZ:2
		// 2ONX structure result for author query
		List<String> pdbIds = Arrays.asList("1PEN","1OCZ","2ONX");
	    pdb = MmtfReader.downloadReducedMmtfFiles(pdbIds, sc);
	}

	@After
	public void tearDown() throws Exception {
		sc.close();
	}

//  TODO the wildtype webservice of RCSB PDB is currently broken
// 	@Test
	public void test1() throws IOException {
	    pdb = pdb.filter(new WildType(true, 100));    
	    List<String> results = pdb.keys().collect();
	    
	    assertTrue(results.contains("1PEN"));
	    assertTrue(results.contains("1OCZ"));
	    assertFalse(results.contains("2ONX"));
	}
}
