package edu.sdsc.mmtf.spark.io.demos;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.SparkSession;
import org.rcsb.mmtf.api.StructureDataInterface;

import edu.sdsc.mmtf.spark.io.MmtfReader;

/**
 * Example reading an MMTF Hadoop Sequence file into a JavaPairRDD.
 * 
 * @author Peter Rose
 * @since 0.2.0
 *
 */
public class ReadLocalMmtfHadoopFile {

	public static void main(String[] args) {  
		
		if (args.length != 1) {
			System.err.println("Usage: " + ReadLocalMmtfHadoopFile.class.getSimpleName() + " <inputFilePath>");
			System.exit(1);
		}
	    
	    // instantiate Spark. Each Spark application needs these two lines of code.
	    SparkSession spark = SparkSession.builder()
	    		.master("local[*]")
	    		.appName(ReadLocalMmtfHadoopFile.class.getSimpleName())
	    		.config("spark.sql.ansi.enabled", "true")
	    		.getOrCreate();
	    JavaSparkContext sc = new JavaSparkContext(spark.sparkContext());
		 
	    // read a local MMTF file
	    JavaPairRDD<String, StructureDataInterface> pdb = MmtfReader.readSequenceFile(args[0], sc);
	    
	    // take the count through the SQL engine: counting a typed
	    // Dataset of the structure ids runs the read, the filters and
	    // the mappers inside one SQL execution
	    Dataset<String> ids = spark.createDataset(pdb.keys().rdd(), Encoders.STRING());
	    System.out.println("# structures: " + ids.count());
	    
	    // print structural details
        pdb = pdb.sample(false, 0.01);
	    pdb.foreach(t -> TraverseStructureHierarchy.printStructureData(t._2));
	    
	    // close Spark
	    sc.close();
	}
}
