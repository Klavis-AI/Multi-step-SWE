package edu.sdsc.mmtf.spark.datasets.demos;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.rcsb.mmtf.api.StructureDataInterface;

import edu.sdsc.mmtf.spark.datasets.SecondaryStructureExtractor;
import edu.sdsc.mmtf.spark.io.MmtfReader;
import edu.sdsc.mmtf.spark.mappers.StructureToPolymerChains;

/**
 * This demos shows how to create a dataset with DSSP secondary structure information.
 * 
 * @author Peter Rose
 * @since 0.1.0
 */
public class DSSPDemo {
	public static void main(String[] args) throws IOException {    
	    long start = System.nanoTime();
	    
	    SparkSession spark = SparkSession.builder()
	    		.master("local[1]")
	    		.appName(CustomReportDemo.class.getSimpleName())
	    		.config("spark.sql.ansi.enabled", "true")
	    		.getOrCreate();
	    JavaSparkContext sc = new JavaSparkContext(spark.sparkContext());
	    List<String> pdbIds = Arrays.asList("1STP"); // single protein chain
	    JavaPairRDD<String, StructureDataInterface> pdb = MmtfReader.downloadFullMmtfFiles(pdbIds, sc).cache(); 
	    pdb = pdb.flatMapToPair(new StructureToPolymerChains());
	    Dataset<Row> ds = SecondaryStructureExtractor.getDataset(pdb);
	    
	    // show the schema of this dataset
	    ds.printSchema();
	    ds.show(2, false);

	    long end = System.nanoTime();
	    
	    System.out.println("Time:     " + (end-start)/1E9 + "sec.");
	    
	    sc.close();
	}
}
