package edu.sdsc.mmtf.spark.filters.demos;

import java.io.FileNotFoundException;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;

import edu.sdsc.mmtf.spark.filters.Resolution;
import edu.sdsc.mmtf.spark.io.MmtfReader;

/**
 * Example how to filter PDB entries by r-free value range.
 * 
 * @see <a href="http://pdb101.rcsb.org/learn/guide-to-understanding-pdb-data/r-value-and-r-free">rfree</a>
 * 
 * @author Peter Rose
 *
 */
public class FilterByRFree {

	public static void main(String[] args) throws FileNotFoundException {

		String path = MmtfReader.getMmtfReducedPath();
	    
	    SparkSession spark = SparkSession.builder()
	    		.master("local[*]")
	    		.appName(FilterByRFree.class.getSimpleName())
	    		.config("spark.sql.ansi.enabled", "true")
	    		.getOrCreate();
	    JavaSparkContext sc = new JavaSparkContext(spark.sparkContext());
		 
	    // here the methods are chained together
	    long count = MmtfReader
	    		.readSequenceFile(path, sc)
	    		.filter(new Resolution(0.0, 2.0))
	    		.count();
	    
	    System.out.println("# structures: " + count);
	    
	    sc.close();
	}
}
