package edu.sdsc.mmtf.spark.mappers.demos;

import java.util.Arrays;
import java.util.List;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.SparkSession;
import org.rcsb.mmtf.api.StructureDataInterface;

import edu.sdsc.mmtf.spark.datasets.demos.CustomReportDemo;
import edu.sdsc.mmtf.spark.io.MmtfReader;
import edu.sdsc.mmtf.spark.mappers.StructureToBioassembly;

/**
 * Example demonstrating how to generate Biological assemblies for a PDB entry.
 * 
 * @author Peter Rose
 * @since 0.1.0
 *
 */
public class MapToBioAssembly {

	public static void main(String[] args) {

		SparkSession spark = SparkSession.builder()
				.master("local[*]")
				.appName(CustomReportDemo.class.getSimpleName())
				.config("spark.sql.ansi.enabled", "true")
				.getOrCreate();
		JavaSparkContext sc = new JavaSparkContext(spark.sparkContext());

		List<String> pdbIds = Arrays.asList("1HV4");
		JavaPairRDD<String, StructureDataInterface> bioassemblies = MmtfReader
				.downloadFullMmtfFiles(pdbIds, sc)
				.flatMapToPair(new StructureToBioassembly());

		// take the count through the SQL engine: counting a typed
		// Dataset of the structure ids runs the read, the filters and
		// the mappers inside one SQL execution
		Dataset<String> ids = spark.createDataset(bioassemblies.keys().rdd(), Encoders.STRING());
		System.out.println("Number of bioassemblies for 1HV4: " + ids.count());

		sc.close();
	}
}
