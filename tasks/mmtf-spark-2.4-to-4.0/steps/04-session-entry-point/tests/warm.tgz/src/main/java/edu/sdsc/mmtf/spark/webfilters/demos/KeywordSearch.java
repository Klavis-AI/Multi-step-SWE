package edu.sdsc.mmtf.spark.webfilters.demos;

import java.io.IOException;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.SparkSession;
import org.rcsb.mmtf.api.StructureDataInterface;

import edu.sdsc.mmtf.spark.io.MmtfReader;
import edu.sdsc.mmtf.spark.webfilters.PdbjMineSearch;

/**
 * KeywordSearch shows how to select a subset of PDB structures by 
 * a keyword search using the PDBj Mine 2 Search web service.
 * 
 * @author Gert-Jan Bekker
 * @since 0.1.0
 */
public class KeywordSearch {
	public static void main(String[] args) throws IOException {
		
		SparkSession spark = SparkSession.builder()
				.master("local[*]")
				.appName(KeywordSearch.class.getSimpleName())
				.config("spark.sql.ansi.enabled", "true")
				.getOrCreate();
		JavaSparkContext sc = new JavaSparkContext(spark.sparkContext());

		String sqlQuery = "SELECT pdbid from keyword_search('porin')";

		// read PDB and filter by keyword search
		JavaPairRDD<String, StructureDataInterface> pdb = MmtfReader
				.readReducedSequenceFile(sc)
				.filter(new PdbjMineSearch(sqlQuery));

		pdb.keys().foreach(k -> System.out.println(k));
		
		// take the count through the SQL engine: counting a typed
		// Dataset of the structure ids runs the read, the filters and
		// the mappers inside one SQL execution
		Dataset<String> ids = spark.createDataset(pdb.keys().rdd(), Encoders.STRING());
		System.out.println("Number of entries matching query: " + ids.count());

		sc.close();
	}
}
