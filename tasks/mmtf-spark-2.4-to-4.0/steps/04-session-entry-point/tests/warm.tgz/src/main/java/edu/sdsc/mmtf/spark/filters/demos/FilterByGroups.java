package edu.sdsc.mmtf.spark.filters.demos;

import java.io.FileNotFoundException;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;

import edu.sdsc.mmtf.spark.filters.ContainsGroup;
import edu.sdsc.mmtf.spark.io.MmtfReader;

/**
 * Example how to filter PDB entries by the presence of specified groups (residues).
 * Groups are specified by their upper case one, two, or three-letter codes,
 * e.g. "F", "MG", "ATP", as defined in the 
 * <a href="https://www.wwpdb.org/data/ccd">wwPDB Chemical Component Dictionary</a>.
 * 
 * @author Peter Rose
 * @since 0.1.0
 *
 */
public class FilterByGroups {

	public static void main(String[] args) throws FileNotFoundException {

		String path = MmtfReader.getMmtfReducedPath();
	    
	    SparkSession spark = SparkSession.builder()
	    		.master("local[*]")
	    		.appName(FilterByGroups.class.getSimpleName())
	    		.config("spark.sql.ansi.enabled", "true")
	    		.getOrCreate();
	    JavaSparkContext sc = new JavaSparkContext(spark.sparkContext());
		 
	    // find all structure that contain ATP and MG
	    long count = MmtfReader
	    		.readSequenceFile(path, sc)
	    		.filter(new ContainsGroup("ATP"))
	    		.filter(new ContainsGroup("MG"))
	    		.count();
	    
	    System.out.println("Structures with ATP + MG: " + count);
	    
	    sc.close();
	}
}
