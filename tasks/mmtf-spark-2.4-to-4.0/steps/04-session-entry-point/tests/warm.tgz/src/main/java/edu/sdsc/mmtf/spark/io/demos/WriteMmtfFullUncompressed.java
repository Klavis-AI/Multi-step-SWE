package edu.sdsc.mmtf.spark.io.demos;

import java.io.FileNotFoundException;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.rcsb.mmtf.api.StructureDataInterface;

import edu.sdsc.mmtf.spark.io.MmtfReader;
import edu.sdsc.mmtf.spark.io.MmtfWriter;

/**
 * Example reading all PDB entries from a local 
 * full MMTF-Hadoop sequence file and saving it as 
 * an uncompressed MMTF-Hadoop sequence file. 
 * The uncompressed files are preferable for local files
 * on Solid State Drives, since they can be read faster.
 * 
 * @author Peter Rose
 * @since 0.1.0
 *
 */
public class WriteMmtfFullUncompressed {

	public static void main(String[] args) throws FileNotFoundException {  
		
		String path = MmtfReader.getMmtfFullPath();
	   
	    long start = System.nanoTime();
	    
	    // instantiate Spark. Each Spark application needs these two lines of code.
	    SparkSession spark = SparkSession.builder()
	    		.master("local[*]")
	    		.appName(WriteMmtfFullUncompressed.class.getSimpleName())
	    		.config("spark.sql.ansi.enabled", "true")
	    		.getOrCreate();
	    JavaSparkContext sc = new JavaSparkContext(spark.sparkContext());
		 
	    // read all PDB entries from a local Hadoop sequence file
	    JavaPairRDD<String, StructureDataInterface> pdb = MmtfReader.readSequenceFile(path, sc);
	    
	    System.out.println("# structures: " + pdb.count());
	    
	    // write an uncompressed Hadoop sequence file
	    boolean compressed = false;
        MmtfWriter.writeSequenceFile(path + "_uncompressed", sc, pdb, compressed);
		
        // close Spark
	    sc.close();
	    
	    long end = System.nanoTime();
	    System.out.println((end-start)/1E9 + " sec."); 
	}
}
