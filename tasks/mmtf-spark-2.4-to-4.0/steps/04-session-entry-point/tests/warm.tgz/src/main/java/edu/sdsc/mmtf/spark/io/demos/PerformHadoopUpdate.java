package edu.sdsc.mmtf.spark.io.demos;

import java.io.FileNotFoundException;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;

import edu.sdsc.mmtf.spark.io.HadoopUpdate;
/**
 * Example reading a list of PDB IDs from a local 
 * reduced MMTF Hadoop sequence file into a JavaPairRDD.
 * 
 * @author Peter Rose
 * @since 0.1.0
 */
public class PerformHadoopUpdate {

	public static void main(String[] args) throws FileNotFoundException {  
		

	    
	    // instantiate Spark. Each Spark application needs these two lines of code.
	    SparkSession spark = SparkSession.builder()
	    		.master("local[*]")
	    		.appName(ReadMmtfReduced.class.getSimpleName())
	    		.config("spark.sql.ansi.enabled", "true")
	    		.getOrCreate();
	    JavaSparkContext sc = new JavaSparkContext(spark.sparkContext());
		
	    HadoopUpdate.performUpdate(sc);
	    
	    sc.close();
	}
}
