def foo():

	print "foo"
