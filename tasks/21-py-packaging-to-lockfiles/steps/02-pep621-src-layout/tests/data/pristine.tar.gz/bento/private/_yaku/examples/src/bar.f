        program foo
        end
