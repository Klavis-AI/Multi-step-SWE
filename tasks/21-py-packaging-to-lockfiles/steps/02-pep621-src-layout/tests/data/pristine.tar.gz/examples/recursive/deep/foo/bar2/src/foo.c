int foo()
{
}
