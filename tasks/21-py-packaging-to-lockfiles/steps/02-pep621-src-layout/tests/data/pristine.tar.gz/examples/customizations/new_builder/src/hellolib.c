void foo(void)
{
}
