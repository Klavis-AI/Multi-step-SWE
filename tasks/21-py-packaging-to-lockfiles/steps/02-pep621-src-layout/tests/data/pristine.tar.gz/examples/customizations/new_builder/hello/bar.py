def foo():
    print "foo"
