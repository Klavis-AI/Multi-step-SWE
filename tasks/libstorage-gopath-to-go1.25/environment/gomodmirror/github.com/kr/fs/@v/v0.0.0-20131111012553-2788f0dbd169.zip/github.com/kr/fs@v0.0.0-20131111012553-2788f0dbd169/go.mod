module github.com/kr/fs

go 1.17
