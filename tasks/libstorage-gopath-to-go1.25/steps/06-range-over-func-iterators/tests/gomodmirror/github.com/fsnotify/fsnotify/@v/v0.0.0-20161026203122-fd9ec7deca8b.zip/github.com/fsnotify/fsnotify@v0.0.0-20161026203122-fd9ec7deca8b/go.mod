module github.com/fsnotify/fsnotify

go 1.17
