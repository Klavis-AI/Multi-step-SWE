module github.com/pkg/errors

go 1.17
