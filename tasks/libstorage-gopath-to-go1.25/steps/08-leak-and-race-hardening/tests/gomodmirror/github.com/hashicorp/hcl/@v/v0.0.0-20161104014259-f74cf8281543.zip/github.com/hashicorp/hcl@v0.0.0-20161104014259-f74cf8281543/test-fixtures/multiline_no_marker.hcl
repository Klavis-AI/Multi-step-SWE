foo = <<
