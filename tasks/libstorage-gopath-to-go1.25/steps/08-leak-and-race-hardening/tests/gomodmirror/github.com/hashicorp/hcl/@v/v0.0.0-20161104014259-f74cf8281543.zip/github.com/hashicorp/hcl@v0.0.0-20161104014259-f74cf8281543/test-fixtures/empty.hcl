resource "foo" {}
