module github.com/dgrijalva/jwt-go

go 1.17
