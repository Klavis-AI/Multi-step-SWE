module github.com/davecgh/go-spew

go 1.17
